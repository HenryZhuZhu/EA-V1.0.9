// Inlines the Vite JS + CSS into a single self-contained index.html
// so it can be opened directly via file:// (double-click) without a server.
import { readFileSync, writeFileSync, readdirSync } from "node:fs";
import { join, resolve } from "node:path";

const dist = join(process.cwd(), "dist");
const assetsDir = join(dist, "assets");
const files = readdirSync(assetsDir);
const jsFile = files.find((f) => f.endsWith(".js"));
const cssFile = files.find((f) => f.endsWith(".css"));

const js = readFileSync(join(assetsDir, jsFile), "utf8");
const css = readFileSync(join(assetsDir, cssFile), "utf8");

// Neutralize any literal </script> inside the bundle so it can't close the tag early.
const safeJs = js.replace(/<\/script>/gi, "<\\/script>");

let html = readFileSync(join(dist, "index.html"), "utf8");

// Replace the external <link> stylesheet with an inline <style>.
// NOTE: use replacement FUNCTIONS so $-sequences ($&, $`, $') in the
// minified asset content are inserted literally, not interpreted.
html = html.replace(
  /<link[^>]*rel="stylesheet"[^>]*>/i,
  () => `<style>\n${css}\n</style>`
);

// Replace the external <script src> with an inline module script.
html = html.replace(
  /<script[^>]*type="module"[^>]*src="[^"]*"[^>]*><\/script>/i,
  () => `<script type="module">\n${safeJs}\n</script>`
);

const out = process.argv[2] ? resolve(process.cwd(), process.argv[2]) : join(process.cwd(), "V1.0.9.html");
writeFileSync(out, html, "utf8");
console.log("Wrote", out, "(" + (Buffer.byteLength(html) / 1024 / 1024).toFixed(2) + " MB)");
