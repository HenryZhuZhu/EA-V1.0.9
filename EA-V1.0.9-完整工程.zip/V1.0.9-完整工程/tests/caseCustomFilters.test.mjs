import assert from "node:assert/strict";
import test from "node:test";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import vm from "node:vm";
import { build } from "esbuild";

// Bundle the real engine and catalog together. No store, data, React, or browser mocks.
const components = new URL("../src/app/components/", import.meta.url);
const { outputFiles } = await build({
  stdin: {
    contents: 'export * from "./caseCustomFilters"; export { CASE_CUSTOM_FIELDS } from "./caseCustomFilterFields";',
    resolveDir: fileURLToPath(components), loader: "ts",
  },
  bundle: true, write: false, platform: "node", format: "cjs",
});
const sandbox = {
  module: { exports: {} },
  require: name => { throw new Error(`Unexpected pure-engine dependency: ${name}`); },
};
vm.runInNewContext(outputFiles[0].text, sandbox, { timeout: 5000 });
const {
  CASE_CUSTOM_FIELDS, CUSTOM_FILTER_OPERATORS, customFieldOperators,
  customFieldValues, customValueLabel, customRuleError, activeCustomRules,
  matchesCustomRules, customFilterOptions, buildCustomFilterRecords, customFieldCatalog, customSelectionRules,
} = sandbox.module.exports;
const plain = value => JSON.parse(JSON.stringify(value));
function freeze(value, seen = new WeakSet()) {
  if (value && typeof value === "object" && !seen.has(value)) {
    seen.add(value);
    Object.values(value).forEach(child => freeze(child, seen));
    Object.freeze(value);
  }
  return value;
}
freeze(CASE_CUSTOM_FIELDS);
const field = id => {
  const found = CASE_CUSTOM_FIELDS.find(item => item.id === id);
  assert.ok(found, `Missing static field ${id}`);
  return found;
};
const rule = (fieldId, operator = "in", values = [], id = `${fieldId}/${operator}`) => freeze({ id, fieldId, operator, values });
const record = (caseData = {}, tasks = []) => freeze({ caseData, tasks });
const values = (root, id) => plain(customFieldValues(freeze(root), field(id)));
const matches = (row, rules, fields = CASE_CUSTOM_FIELDS) => matchesCustomRules(row, freeze(rules), fields);
const options = (rows, id) => plain(customFilterOptions(freeze(rows), field(id)));
const action = (id, patch = {}) => freeze({
  id, code: `TASK-${id}`, title: `执行 ${id}`, owner: "李娜", department: "DA",
  urgency: "一般", progress: 0, status: "进行中", children: [], ...patch,
});
const c = (id, patch = {}) => freeze({
  id, code: `CASE-${id}`, name: `问题 ${id}`, owner: "张伟", level: "L1", urgency: "一般",
  status: "进行中", reason: "测试原因", background: "测试背景", levelReason: "测试层级原因",
  product: "DDR5", material: "Die/IC", density: "16Gb", ioType: "x16", failStage: "CP",
  customer: "Customer", failPlatform: "Platform", failMode: "Mode", ppm: "0", pdId: "PD-1",
  createdAt: "2026-09-01", updatedAt: "2026-09-10", dueIn: 0, departments: [], tasks: [],
  aiSummary: { progress: "", method: "", conclusion: "", solution: "", risk: "" }, timeline: [], ...patch,
});
function buildRecords(cases, { loadTree = item => item.tasks, status = item => item.status, closure = () => undefined } = {}) {
  return freeze(buildCustomFilterRecords(freeze(cases), { loadTree, status, closure }));
}

// Dependency-free declaration coverage: strip comments without touching strings,
// balance braces, and split only TOP-LEVEL property signatures. This intentionally
// fails on an unsupported declaration rather than silently dropping a new field.
const source = name => readFileSync(new URL(name, components), "utf8").replace(
  /"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|`(?:\\.|[^`\\])*`|\/\/[^\n]*|\/\*[\s\S]*?\*\//g,
  token => token.startsWith("//") || token.startsWith("/*") ? " " : token,
);
const dataSource = source("data.ts");
const closureSource = source("closures.ts");
const activitySource = source("taskActivity.ts");
const visibilitySource = source("taskVisibility.ts");
function quotedEnd(text, start) {
  for (let i = start + 1; i < text.length; i++) {
    if (text[i] === "\\") { i++; continue; }
    if (text[i] === text[start]) return i + 1;
  }
  assert.fail("Unterminated string in declaration");
}
function blockAt(text, start) {
  assert.equal(text[start], "{");
  let depth = 0;
  for (let i = start; i < text.length; i++) {
    if ('"\'`'.includes(text[i])) { i = quotedEnd(text, i) - 1; continue; }
    if (text[i] === "{") depth++;
    if (text[i] === "}" && --depth === 0) return { body: text.slice(start + 1, i), end: i + 1 };
  }
  assert.fail("Unbalanced declaration braces");
}
function properties(body) {
  const segments = [];
  const stack = [];
  const pairs = { "}": "{", "]": "[", ")": "(" };
  let start = 0;
  for (let i = 0; i < body.length; i++) {
    const char = body[i];
    if ('"\'`'.includes(char)) { i = quotedEnd(body, i) - 1; continue; }
    if ("{[(".includes(char)) stack.push(char);
    else if (Object.hasOwn(pairs, char)) assert.equal(stack.pop(), pairs[char]);
    else if (char === ";" && !stack.length) { segments.push(body.slice(start, i)); start = i + 1; }
  }
  assert.equal(stack.length, 0);
  segments.push(body.slice(start));
  return Object.fromEntries(segments.filter(item => item.trim()).map(item => {
    const match = /^\s*(?:readonly\s+)?([A-Za-z_$][\w$]*)\??\s*:\s*([\s\S]+?)\s*$/.exec(item);
    assert.ok(match, `Unsupported property signature: ${item}`);
    return [match[1], match[2]];
  }));
}
function declaration(text, name) {
  const match = new RegExp(`\\binterface\\s+${name}\\s*\\{`).exec(text);
  assert.ok(match, `Missing interface ${name}`);
  return properties(blockAt(text, match.index + match[0].lastIndexOf("{")).body);
}
function inlineProperties(type) {
  const result = {};
  for (let i = 0; i < type.length; i++) {
    if ('"\'`'.includes(type[i])) { i = quotedEnd(type, i) - 1; continue; }
    if (type[i] === "{") {
      const block = blockAt(type, i);
      Object.assign(result, properties(block.body));
      i = block.end - 1;
    }
  }
  assert.ok(Object.keys(result).length, `Expected inline object: ${type}`);
  return result;
}
function assertCovered(entity, prefix, members) {
  const parent = prefix ? prefix.split(".") : [];
  for (const key of Object.keys(members)) {
    const path = [...parent, key];
    assert.ok(CASE_CUSTOM_FIELDS.some(item => item.entity === entity && path.every((part, i) => item.path[i] === part)),
      `Unregistered declared field ${entity}:${path.join(".")}`);
  }
}

test("static catalog has 295 unique, well-formed fields and retains known fields with no samples", () => {
  assert.equal(CASE_CUSTOM_FIELDS.length, 295);
  assert.equal(new Set(CASE_CUSTOM_FIELDS.map(item => item.id)).size, 295);
  assert.deepEqual(plain(customFieldCatalog([])), plain(CASE_CUSTOM_FIELDS));
  for (const item of CASE_CUSTOM_FIELDS) {
    assert.ok(["case", "task"].includes(item.entity));
    assert.ok(["text", "number", "date", "boolean"].includes(item.type));
    assert.ok(item.label && item.group && item.path.length);
    assert.equal(item.id, `${item.entity}:${item.path.join(".")}${item.mode === "value" ? "" : `#${item.mode}`}`);
    if (item.mode === "count") assert.equal(item.type, "number");
    if (item.mode === "present") assert.equal(item.type, "boolean");
    assert.deepEqual(plain(customFilterOptions([], item)), []);
  }
  assert.ok(!CASE_CUSTOM_FIELDS.some(item => item.entity === "case" && item.path[0] === "tasks" && item.path.length > 1));
  assert.ok(!CASE_CUSTOM_FIELDS.some(item => item.entity === "task" && item.path[0] === "children" && item.path.length > 1));
  assert.equal(CUSTOM_FILTER_OPERATORS.length, 11);
});

test("static top-level coverage equals every current keyof CaseItem and TaskNode, not sample keys", () => {
  assert.deepEqual(Object.keys(properties('id: string; nested?: { child: string; x: { y: number } }; rows: { a: string }[]; status: TaskNode["status"];')), ["id", "nested", "rows", "status"]);
  for (const [entity, name, extras] of [["case", "CaseItem", ["storedStatus", "closure"]], ["task", "TaskNode", []]]) {
    const declared = declaration(dataSource, name);
    assertCovered(entity, "", declared);
    const registered = [...new Set(CASE_CUSTOM_FIELDS.filter(item => item.entity === entity).map(item => item.path[0]))].sort();
    assert.deepEqual(registered, [...Object.keys(declared), ...extras].sort());
  }
});

test("nested declaration coverage includes samples, chip trees, closure, EFA, comments, activity and inline objects", () => {
  const named = [
    ["case", "participants", dataSource, "Participant"], ["task", "collaborators", dataSource, "Participant"],
    ["case", "granules", dataSource, "CaseGranule"], ["case", "granules.icTree", dataSource, "DimmIcTree"],
    ["case", "granules.icTree.ics", dataSource, "DimmIc"], ["case", "granules.icTree.ics.dies", dataSource, "DimmDie"],
    ["case", "returnedSamples", dataSource, "ReturnedSample"], ["case", "pipeline", dataSource, "CrStageState"],
    ["case", "closure", closureSource, "ClosureRecord"], ["task", "comments", dataSource, "TaskComment"],
    ["task", "comments.replies", dataSource, "CommentReply"], ["task", "efaTicket", dataSource, "EfaTicket"],
    ["task", "efaAnalysis", dataSource, "EfaAnalysisCard"], ["task", "efaAnalysis.chipList", dataSource, "EfaChipItem"],
    ["task", "activityLog", activitySource, "TaskActivity"], ["task", "standaloneTaskContext.visibility", visibilitySource, "TaskVisibility"],
  ];
  named.forEach(([entity, path, text, name]) => assertCovered(entity, path, declaration(text, name)));
  const cases = declaration(dataSource, "CaseItem"), tasks = declaration(dataSource, "TaskNode");
  for (const key of ["caseAttachments", "splitGranule", "aiSummary", "timeline"]) assertCovered("case", key, inlineProperties(cases[key]));
  for (const key of ["standaloneTaskContext", "skillRun", "attachments", "manualPos", "patternParams", "statusHistory"]) assertCovered("task", key, inlineProperties(tasks[key]));
  assertCovered("task", "standaloneTaskContext.involvement", inlineProperties(inlineProperties(tasks.standaloneTaskContext).involvement));
  assertCovered("task", "activityLog.changes", inlineProperties(declaration(activitySource, "TaskActivity").changes));
  assertCovered("task", "efaTicket.attachments", inlineProperties(declaration(dataSource, "EfaTicket").attachments));
  assertCovered("case", "closure.files", inlineProperties(declaration(closureSource, "ClosureRecord").files));
});

test("exact text equality preserves IDs, case, leading spaces and internal spaces", () => {
  const rows = freeze([record({ productId: "P-01", name: " Alpha  Beta " }), record({ productId: "p-01", name: "Alpha Beta" }), record({ productId: " P-01 " })]);
  for (const [query, expected] of [["P-01", [true, false, false]], ["p-01", [false, true, false]], [" P-01 ", [false, false, true]], ["P-0", [false, false, false]]]) {
    assert.deepEqual(rows.map(row => matches(row, [rule("case:productId", "in", [query])])), expected);
  }
  assert.equal(matches(rows[0], [rule("case:name", "in", [" Alpha  Beta "])]), true);
  for (const query of ["Alpha  Beta", " Alpha Beta ", " alpha  beta "]) assert.equal(matches(rows[0], [rule("case:name", "in", [query])]), false);
  assert.deepEqual(values(rows[0].caseData, "case:name"), [" Alpha  Beta "]);
  assert.deepEqual(values({ name: [1, "1", 0, false, true, null, undefined, {}, [], "   "] }, "case:name"), ["1", "0", "false", "true"]);
});

test("multiselect values use OR while separate Case and task rules use AND", () => {
  const row = record({ level: "L2", departments: ["PTE", "DA"] }, [action("one", { owner: "李娜" })]);
  const rules = [rule("case:level", "in", ["L1", "L2"]), rule("case:departments", "in", ["FT", "DA"]), rule("task:owner", "in", ["张伟", "李娜"])];
  assert.equal(matches(row, rules), true);
  assert.equal(matches(row, [...rules, rule("case:departments", "notIn", ["EFA", "DA"])]), false);
  assert.equal(matches(row, [...rules, rule("case:level", "in", ["L3"], "second-level-rule")]), false);
  assert.equal(matches(row, []), true);
});

test("all task rules must match the same executable node, never two tasks or two Cases", () => {
  const rules = [rule("task:owner", "in", ["张伟"]), rule("task:status", "in", ["已完成"])];
  const split = record({}, [action("mine", { owner: "张伟" }), action("done", { status: "已完成" })]);
  assert.equal(matches(split, rules), false);
  assert.equal(matches(record({}, [...split.tasks, action("both", { owner: "张伟", status: "已完成" })]), rules), true);
  assert.equal(matches(split, [rules[0], rule("task:status", "notIn", ["进行中"])]), false);
  assert.equal(matches(record({ owner: "张伟" }, [action("other")]), [rule("case:owner", "in", ["张伟"]), rules[0]]), false);
  for (const row of [record({}, [split.tasks[0]]), record({}, [split.tasks[1]])]) assert.equal(matches(row, rules), false);
});

test("recursive tree flattening keeps coded parents and descendants but excludes every thought", () => {
  const deep = action("deep", { owner: "深层执行人" });
  const parent = action("parent", { children: [freeze({ id: "inner-thought", owner: "仅思路人员", children: [deep] })] });
  const item = c("tree", { tasks: [freeze({ id: "thought", owner: "仅思路人员", children: [parent] }), action("root"), freeze({ id: "empty-code", code: "", owner: "仅思路人员" })] });
  const [row] = buildRecords([item]);
  assert.deepEqual(plain(row.tasks.map(task => task.id)), ["parent", "deep", "root"]);
  assert.equal(row.tasks[0], parent);
  assert.equal(row.tasks[1], deep);
  assert.equal(row.caseData.tasks, row.tasks);
  assert.deepEqual(values(row.caseData, "case:tasks#count"), ["3"]);
  assert.equal(matches(row, [rule("task:owner", "in", ["深层执行人"])]), true);
  assert.equal(matches(row, [rule("task:owner", "in", ["仅思路人员"])]), false);
  assert.ok(!options([row], "task:owner").includes("仅思路人员"));
});

test("builder uses the actual read-tree callback for every Case, including authoritative empty trees", () => {
  const cases = freeze([c("saved", { tasks: [action("stale")] }), c("removed", { tasks: [action("also-stale")] }), c("original", { tasks: [action("original")] })]);
  const saved = freeze([action("persisted", { owner: "当前执行人" })]);
  const calls = [];
  const before = JSON.stringify([cases, saved]);
  const rows = buildRecords(cases, { loadTree: item => { calls.push(item); return item.id === "saved" ? saved : item.id === "removed" ? [] : item.tasks; } });
  assert.equal(calls.length, 3);
  calls.forEach((item, i) => assert.equal(item, cases[i]));
  assert.deepEqual(plain(rows.map(row => row.tasks.map(task => task.id))), [["persisted"], [], ["original"]]);
  assert.deepEqual(options(rows, "task:id"), ["original", "persisted"]);
  assert.equal(JSON.stringify([cases, saved]), before);
});

test("zero executable tasks cannot satisfy even task-empty rules; explicit task count zero can match", () => {
  const [row] = buildRecords([c("empty", { tasks: [freeze({ id: "thought-only", children: [] })] })]);
  assert.equal(matches(row, [rule("task:owner", "empty")]), false);
  assert.equal(matches(row, [rule("task:owner", "notEmpty")]), false);
  assert.equal(matches(row, [rule("case:tasks#count", "in", ["0"])]), true);
  assert.equal(matches(record({}, [action("missing", { conclusion: undefined })]), [rule("task:conclusion", "empty")]), true);
  assert.equal(matches(row, [rule("task:owner", "in", [])]), true, "unfinished task rules are inactive");
});

test("date values validate calendar days, leap years and day-normalized timestamp options", () => {
  for (const date of ["2024-02-29", "2000-02-29", "2026-09-10"]) assert.deepEqual(values({ dueDate: date }, "case:dueDate"), [date]);
  for (const date of ["2023-02-29", "1900-02-29", "2026-02-30", "2026-04-31", "2026-00-10", "2026-13-01", "2026-09-00", "2026-9-10", "", "   ", "not-a-date", 0, false, null]) {
    assert.deepEqual(values({ dueDate: date }, "case:dueDate"), [], String(date));
  }
  const rows = [record({ dueDate: "2024-02-29T23:59:59-08:00" }), record({ dueDate: "2024-02-29 00:01" }), record({ dueDate: "2024-03-01" })];
  assert.deepEqual(options(rows, "case:dueDate"), ["2024-02-29", "2024-03-01"]);
  assert.equal(matches(rows[0], [rule("case:dueDate", "in", ["2024-02-29"])]), true, "compare stored calendar day, not UTC-converted instant");
});

test("date comparisons are inclusive where requested and reject invalid or reversed ranges", () => {
  const rows = ["2024-02-28", "2024-02-29T23:59:59Z", "2024-03-01", "2024-03-02"].map(dueDate => record({ dueDate }));
  const table = [
    ["gt", ["2024-02-29"], [false, false, true, true]], ["gte", ["2024-02-29"], [false, true, true, true]],
    ["lt", ["2024-03-01"], [true, true, false, false]], ["lte", ["2024-03-01"], [true, true, true, false]],
    ["between", ["2024-02-29", "2024-03-01"], [false, true, true, false]],
    ["between", ["2024-02-29", "2024-02-29"], [false, true, false, false]],
  ];
  for (const [operator, selected, expected] of table) assert.deepEqual(rows.map(row => matches(row, [rule("case:dueDate", operator, selected)])), expected, operator);
  for (const selected of [["2024-03-01", "2024-02-29"], ["2023-02-29", "2024-03-01"], ["", "2024-03-01"], ["2024-02-29"]]) {
    const unfinished = rule("case:dueDate", "between", selected);
    assert.ok(customRuleError(unfinished, field(unfinished.fieldId)));
    assert.equal(activeCustomRules([unfinished], CASE_CUSTOM_FIELDS).length, 0);
  }
});

test("numeric coercion keeps zero, normalizes finite numeric strings and excludes blanks and non-numbers", () => {
  const root = freeze({ dueIn: [0, -0, "0", " 02 ", 2, -1, "1.5", "1e2", null, false, true, "", " ", "2ms", Infinity, NaN, {}, []] });
  assert.deepEqual(values(root, "case:dueIn"), ["0", "2", "-1", "1.5", "100"]);
  assert.deepEqual(options([record(root)], "case:dueIn"), ["-1", "0", "1.5", "2", "100"]);
  const row = record({ dueIn: 0 });
  for (const [operator, selected, expected] of [["in", ["00"], true], ["gt", ["0"], false], ["gte", ["0"], true], ["lt", ["0"], false], ["lte", ["0"], true], ["between", ["0", "0"], true], ["between", ["1", "2"], false]]) {
    assert.equal(matches(row, [rule("case:dueIn", operator, selected)]), expected, operator);
  }
  assert.ok(customRuleError(rule("case:dueIn", "between", ["2", "1"]), field("case:dueIn")));
  for (const invalid of ["", " ", "NaN", "Infinity", "3%", false, null, {}]) assert.ok(customRuleError(rule("case:dueIn", "in", [invalid]), field("case:dueIn")));
  assert.equal(field("case:ppm").type, "text");
  assert.deepEqual(values({ ppm: "003.5%" }, "case:ppm"), ["003.5%"]);
});

test("boolean false is a real value, string options coerce correctly, and unsupported operators are rejected", () => {
  const item = field("task:likedByMe");
  assert.deepEqual(plain(customFieldOperators(item).map(option => option.value)), ["in", "notIn", "empty", "notEmpty"]);
  assert.deepEqual(values({ likedByMe: [false, true, false, "false", "true", 0, 1, null] }, item.id), ["false", "true"]);
  const row = record({}, [action("boolean", { likedByMe: false })]);
  assert.equal(matches(row, [rule(item.id, "in", ["false"])]), true);
  assert.equal(matches(row, [rule(item.id, "in", ["true"])]), false);
  assert.equal(matches(row, [rule(item.id, "notIn", ["true"])]), true);
  assert.equal(matches(row, [rule(item.id, "notEmpty")]), true);
  assert.equal(customValueLabel("false", item), "否");
  assert.equal(customValueLabel("true", item), "是");
  assert.equal(customValueLabel("P-01", field("case:productId")), "P-01");
  for (const invalid of ["False", "0", "yes", "", false, true, null, {}]) assert.ok(customRuleError(rule(item.id, "in", [invalid]), item));
  for (const operator of ["contains", "gt", "between"]) assert.ok(customRuleError(rule(item.id, operator, ["false"]), item));
});

test("missing values never satisfy negative predicates and are distinct from count zero or boolean false", () => {
  for (const missing of [undefined, null, "", " \t ", [], [null, "", " "]]) {
    const row = record({ remark: missing, dueDate: missing, dueIn: missing }, [action("missing", { conclusion: missing, likedByMe: missing })]);
    for (const id of ["case:remark", "task:conclusion"]) {
      assert.equal(matches(row, [rule(id, "empty")]), true);
      assert.equal(matches(row, [rule(id, "notEmpty")]), false);
      assert.equal(matches(row, [rule(id, "notIn", ["other"])]), false);
      assert.equal(matches(row, [rule(id, "notContains", ["other"])]), false);
    }
    assert.equal(matches(row, [rule("case:dueDate", "notIn", ["2026-09-10"])]), false);
    assert.equal(matches(row, [rule("case:dueIn", "notIn", ["0"])]), false);
    assert.equal(matches(row, [rule("task:likedByMe", "notIn", ["true"])]), false);
  }
  assert.equal(matches(record({ departments: [] }), [rule("case:departments#count", "empty")]), false);
  assert.equal(matches(record({ departments: [] }), [rule("case:departments#count", "in", ["0"])]), true);
  assert.equal(matches(record({ remark: ["", "present"] }), [rule("case:remark", "empty")]), false);
});

test("contains is case-insensitive literal text, not regex, with trimmed query and safe negative semantics", () => {
  const row = record({ name: "Alpha [a-z]+ (x.*) $^ \\ path 中文", departments: ["PTE", "DA"] });
  for (const query of [" alpha ", "[a-z]+", "(x.*)", "$^", "\\", "中文"]) assert.equal(matches(row, [rule("case:name", "contains", [query])]), true, query);
  for (const query of ["^Alpha", "A.*中文", "[invalid", "(a+)+$"]) {
    assert.equal(matches(row, [rule("case:name", "contains", [query])]), false, query);
    assert.equal(matches(row, [rule("case:name", "notContains", [query])]), true, query);
  }
  assert.equal(matches(row, [rule("case:departments", "notContains", ["pt"])]), false);
  assert.equal(matches(row, [rule("case:departments", "notContains", ["efa"])]), true);
});

test("arrays, object wildcards and nested counts expose values rather than serialized objects", () => {
  const row = record({
    departments: ["PTE", "DA", "PTE"], participants: [{ name: "张伟", department: "PTE" }, { name: "李娜", department: "DA" }],
    closure: { krByProduct: { "P-2": "李娜", "P-1": "张伟", "P-3": "李娜" } },
    granules: [{ icTree: { sn: "SN-1", ics: [{ icId: "IC-1", dies: [{ dieId: "D1", chipId: "C1" }, { dieId: "D2", chipId: "C2" }] }, { icId: "IC-2", dies: [] }] } }],
  }, [action("nested", { comments: [{ id: "comment", user: "张伟", time: "2026-09-10", content: "内容", replies: [{ id: "reply", user: "李娜", time: "2026-09-10", content: "回复" }] }, { id: "empty", replies: [] }] })]);
  for (const [id, expected] of [
    ["case:departments", ["PTE", "DA"]], ["case:departments#count", ["3"]], ["case:participants.name", ["张伟", "李娜"]],
    ["case:closure.krByProduct.*", ["李娜", "张伟"]], ["case:closure.krByProduct#count", ["3"]],
    ["case:granules.icTree.ics#count", ["2"]], ["case:granules.icTree.ics.dies#count", ["2", "0"]],
    ["case:granules.icTree.ics.dies.chipId", ["C1", "C2"]],
  ]) assert.deepEqual(values(row.caseData, id), expected, id);
  assert.deepEqual(values(row.tasks[0], "task:comments.replies#count"), ["1", "0"]);
  assert.deepEqual(values(row.tasks[0], "task:comments.replies.content"), ["回复"]);
  assert.equal(matches(row, [rule("case:closure.krByProduct.*", "in", ["张伟"]), rule("task:comments.replies.content", "contains", ["回复"])]), true);
});

test("attachments expose names, kinds, counts and presence, never file, voice or map payloads", () => {
  const files = freeze([{ name: "report.pdf", kind: "pdf", url: "data:application/pdf;base64,PRIVATE" }, { name: "image.png", kind: "image", url: "blob:PRIVATE" }, { name: "missing.txt", kind: "file" }]);
  const row = record({ caseAttachments: files, closure: { files } }, [action("files", {
    attachments: files, voiceNote: "data:audio/wav;base64,PRIVATE", efaTicket: { attachments: files },
    efaAnalysis: { map: "data:image/png;base64,PRIVATE", chipList: [{ map: "blob:PRIVATE" }, { map: "" }] },
  })]);
  for (const [root, prefix] of [[row.caseData, "case:caseAttachments"], [row.caseData, "case:closure.files"], [row.tasks[0], "task:attachments"], [row.tasks[0], "task:efaTicket.attachments"]]) {
    assert.deepEqual(values(root, `${prefix}#count`), ["3"]);
    assert.deepEqual(values(root, `${prefix}.name`), ["report.pdf", "image.png", "missing.txt"]);
    assert.deepEqual(values(root, `${prefix}.kind`), ["pdf", "image", "file"]);
    assert.deepEqual(values(root, `${prefix}.url#present`), ["true", "false"]);
    assert.deepEqual(plain(customFieldValues(root, { ...field(`${prefix}.url#present`), mode: "value", type: "text" })), []);
  }
  for (const id of ["task:voiceNote#present", "task:efaAnalysis.map#present"]) assert.deepEqual(values(row.tasks[0], id), ["true"]);
  assert.deepEqual(values(row.tasks[0], "task:efaAnalysis.chipList.map#present"), ["true", "false"]);
  assert.deepEqual(values(action("no-files"), "task:voiceNote#present"), ["false"]);
  assert.deepEqual(values({ remark: [" data:private", "BLOB:private", "safe"] }, "case:remark"), ["safe"]);
  const allOptions = CASE_CUSTOM_FIELDS.flatMap(item => plain(customFilterOptions([row], item)));
  assert.ok(!allOptions.some(value => /PRIVATE|data:|blob:|\[object Object\]/i.test(value)));
});

test("effective status and closure metadata remain separately filterable from immutable raw status", () => {
  const cases = freeze([c("closed", { status: "Pending" }), c("verified", { status: "进行中" }), c("no-closure", { status: "已关闭" })]);
  const closures = freeze({ closed: { caseId: "closed", state: "closed", closedAt: "2026-09-10 23:59", conclusion: "确认" }, verified: { caseId: "verified", state: "rootcause", domain: "Testing" } });
  const effective = { closed: "已结案", verified: "验证中", "no-closure": "已结案" };
  const statusCalls = [], closureCalls = [];
  const before = JSON.stringify([cases, closures]);
  const rows = buildRecords(cases, {
    status: item => { statusCalls.push(item); return effective[item.id]; },
    closure: id => { closureCalls.push(id); return closures[id]; },
  });
  assert.deepEqual(plain(rows.map(row => [row.caseData.status, row.caseData.storedStatus])), [["已结案", "Pending"], ["验证中", "进行中"], ["已结案", "已关闭"]]);
  statusCalls.forEach((item, i) => assert.equal(item, cases[i]));
  assert.deepEqual(closureCalls, cases.map(item => item.id));
  assert.equal(rows[0].caseData.closure, closures.closed);
  assert.deepEqual(plain(rows[2].caseData.closure), {});
  assert.equal(matches(rows[0], [rule("case:status", "in", ["已结案"]), rule("case:storedStatus", "in", ["Pending"]), rule("case:closure.closedAt", "in", ["2026-09-10"])]), true);
  assert.equal(matches(rows[1], [rule("case:status", "in", ["进行中"])]), false);
  assert.equal(matches(rows[2], [rule("case:closure.state", "notIn", ["rootcause"])]), false);
  assert.equal(JSON.stringify([cases, closures]), before);
});

test("standalone and historical references use only explicit stored fields, never Case or title inference", () => {
  const tasks = [action("tf", { sourceStandaloneTaskId: "old-TF", standaloneTaskContext: { involvement: { kind: "TF", id: "tf-1", name: "历史 TF" } } }),
    action("project", { standaloneTaskContext: { involvement: { kind: "Project", id: "project-1", name: " 同名项目 " } } }),
    action("none", { standaloneTaskContext: { involvement: { kind: "无" } } }), action("unlinked", { title: "old-TF tf-1 同名项目 DDR5", department: "" })];
  const [row] = buildRecords([c("source", { productId: "case-product", projectName: "同名项目", sourceStandaloneTaskId: "legacy-single", sourceStandaloneTaskIds: ["new-A", "new-B"], departments: ["PTE"], tasks })]);
  assert.deepEqual(values(row.caseData, "case:sourceStandaloneTaskId"), ["legacy-single"]);
  assert.deepEqual(values(row.caseData, "case:sourceStandaloneTaskIds"), ["new-A", "new-B"]);
  assert.deepEqual(options([row], "task:sourceStandaloneTaskId"), ["old-TF"]);
  assert.deepEqual(options([row], "task:standaloneTaskContext.involvement.id"), ["project-1", "tf-1"]);
  assert.equal(matches(row, [rule("task:standaloneTaskContext.involvement.kind", "in", ["TF"]), rule("task:standaloneTaskContext.involvement.id", "in", ["project-1"])]), false);
  assert.equal(matches(row, [rule("task:standaloneTaskContext.involvement.name", "in", [" 同名项目 "])]), true);
  assert.deepEqual(values(tasks[3], "task:standaloneTaskContext.involvement.id"), []);
  assert.deepEqual(values(tasks[3], "task:department"), []);
  const [legacy] = buildRecords([c("legacy", { product: "case-product", sourceStandaloneTaskId: "single" })]);
  assert.deepEqual(values(legacy.caseData, "case:productId"), []);
  assert.deepEqual(values(legacy.caseData, "case:sourceStandaloneTaskIds"), []);
});

test("extension fields register scalar types and array paths without overriding known fields or wildcards", () => {
  const row = record({ extra: { score: 0, enabled: false, labels: ["A", "B"], rows: [{ code: "X" }, { code: "Y" }] }, closure: { krByProduct: { "dynamic-product": "张伟" } } }, [action("extension", { extra: { rank: 2, legacy: "TF" } })]);
  const before = JSON.stringify(row);
  const catalog = freeze(customFieldCatalog([row]));
  for (const [id, type, expected] of [["case:extra.score", "number", ["0"]], ["case:extra.enabled", "boolean", ["false"]], ["case:extra.labels", "text", ["A", "B"]], ["case:extra.rows.code", "text", ["X", "Y"]], ["task:extra.rank", "number", ["2"]], ["task:extra.legacy", "text", ["TF"]]]) {
    const item = catalog.find(candidate => candidate.id === id);
    assert.ok(item, id);
    assert.equal(item.type, type);
    assert.deepEqual(plain(customFieldValues(item.entity === "case" ? row.caseData : row.tasks[0], item)), expected);
    assert.equal(matches(row, [rule(id, "in", [expected[0]])], catalog), true);
  }
  CASE_CUSTOM_FIELDS.forEach(item => assert.equal(catalog.find(candidate => candidate.id === item.id), item));
  assert.equal(catalog.length, 301);
  assert.ok(!catalog.some(item => item.id === "case:closure.krByProduct.dynamic-product"));
  assert.equal(JSON.stringify(row), before);
});

test("extension discovery is cycle-safe and excludes payloads, inherited properties and prototype paths", () => {
  const extra = Object.assign(Object.create(freeze({ inherited: "not-own" })), { safe: "visible", url: "https://private", voiceNote: "private", map: "private", password: "private", TOKEN: "private", secret: "private", dataUrl: "private", base64: "private", disguised: "data:private", blob: "blob:private" });
  Object.assign(extra, JSON.parse('{"constructor":{"leak":"private"},"prototype":{"leak":"private"}}'));
  // Define __proto__ as an own data property, not an assignment to the legacy setter.
  Object.defineProperty(extra, "__proto__", { value: { leak: "private" }, enumerable: true });
  extra.self = extra;
  extra.arrayCycle = [];
  extra.arrayCycle.push(extra.arrayCycle);
  const row = record({ extra }, [action("safe", { privateData: { token: "private", safe: "task-safe" } })]);
  const catalog = customFieldCatalog([row]);
  const additions = plain(catalog.filter(item => !CASE_CUSTOM_FIELDS.some(known => known.id === item.id)).map(item => item.id)).sort();
  assert.deepEqual(additions, ["case:extra.safe", "task:privateData.safe"]);
  assert.deepEqual(plain(customFieldValues(extra, { ...field("case:remark"), path: ["inherited"] })), []);
  for (const path of [["constructor", "leak"], ["__proto__", "leak"], ["prototype", "leak"]]) {
    assert.deepEqual(plain(customFieldValues(extra, { ...field("case:remark"), path })), []);
    assert.deepEqual(plain(customFieldValues(extra, { ...field("task:voiceNote#present"), path })), []);
  }
  assert.equal(extra.self, extra);
  assert.equal(extra.arrayCycle[0], extra.arrayCycle);
  assert.ok(Object.isFrozen(extra));
});

test("candidate generation uses full supplied records independent of matches and never mutates inputs", () => {
  const cases = freeze([c("a", { owner: "张伟", productId: "P-2", tasks: [action("a", { owner: "张伟" })] }), c("b", { owner: "李娜", productId: "P-1", tasks: [action("b", { owner: "李娜" })] })]);
  const rows = buildRecords(cases);
  const catalog = freeze(customFieldCatalog(rows));
  const rules = freeze([rule("case:owner", "in", ["张伟"])]);
  const before = JSON.stringify([cases, rows, rules, catalog]);
  const selected = rows.filter(row => matches(row, rules, catalog));
  assert.equal(selected.length, 1);
  assert.equal(selected[0], rows[0]);
  assert.deepEqual(options(rows, "case:productId"), ["P-1", "P-2"]);
  assert.deepEqual(options(selected, "case:productId"), ["P-2"]);
  assert.equal(options(rows, "task:owner").length, 2);
  assert.deepEqual(plain(customFieldCatalog([]).map(item => item.id)), plain(CASE_CUSTOM_FIELDS.map(item => item.id)));
  assert.deepEqual(options(rows, "task:efaTicket.syncedAt"), []);
  const returned = customFilterOptions(rows, field("case:productId"));
  returned.push("consumer-only");
  assert.deepEqual(options(rows, "case:productId"), ["P-1", "P-2"]);
  assert.equal(JSON.stringify([cases, rows, rules, catalog]), before);
});

test("invalid and unfinished rules are inactive and only valid rules contribute to the active count", () => {
  const invalid = [rule("case:no-such-field", "empty"), rule("case:owner", "bogus", ["张伟"]),
    rule("case:owner", "in", []), rule("task:owner", "notIn", []), rule("case:name", "contains", [" "]),
    rule("case:name", "notContains", ["data:private"]), rule("case:dueDate", "between", ["2026-09-10"]),
    rule("case:dueDate", "in", ["2026-02-30"]), rule("case:dueIn", "gte", [""]),
    rule("case:dueIn", "between", ["2", "1"]), rule("task:likedByMe", "in", ["not-boolean"]),
    rule("case:name", "gte", ["2"]), rule("case:dueIn", "contains", ["0"])];
  invalid.forEach(item => assert.ok(customRuleError(item, CASE_CUSTOM_FIELDS.find(candidate => candidate.id === item.fieldId)), item.id));
  assert.equal(activeCustomRules(invalid, CASE_CUSTOM_FIELDS).length, 0);
  assert.equal(matches(record(), invalid), true);
  const valid = [rule("case:owner", "in", ["张伟"]), rule("case:remark", "empty"), rule("case:name", "notEmpty")];
  assert.deepEqual(plain(activeCustomRules([...invalid, ...valid], CASE_CUSTOM_FIELDS).map(item => item.id)), valid.map(item => item.id));
  assert.equal(activeCustomRules([...invalid, ...valid], CASE_CUSTOM_FIELDS).length, 3);
  assert.equal(matches(record({ owner: "张伟", name: "Name" }), [...invalid, ...valid]), true);
  assert.equal(matches(record({ owner: "李娜", name: "Name" }), [...invalid, ...valid]), false);
});

test("more than 500 distinct Case and task options are retained, deduplicated and naturally sorted", () => {
  const rows = freeze(Array.from({ length: 650 }, (_, i) => {
    const n = 649 - i;
    return record({ productId: `P-${n}` }, [action(`task-${n}`, { owner: `Owner-${n}` }), action(`duplicate-${n}`, { owner: `Owner-${n}` })]);
  }));
  const before = JSON.stringify(rows);
  assert.deepEqual(options(rows, "case:productId"), Array.from({ length: 650 }, (_, i) => `P-${i}`));
  assert.deepEqual(options(rows, "task:owner"), Array.from({ length: 650 }, (_, i) => `Owner-${i}`));
  assert.equal(matches(rows[0], [rule("case:productId", "in", ["P-649"]), rule("task:owner", "in", ["Owner-649"])]), true);
  assert.equal(JSON.stringify(rows), before);
});

test("malformed non-string contains options are invalid rather than throwing or silently becoming active", () => {
  // Deliberate regression assertion: malformed persisted values can bypass TS types.
  // Keep the expected safe contract; do not mask a runtime failure with todo/skip.
  for (const value of [0, 42, false, true, {}, [], null, undefined]) {
    for (const operator of ["contains", "notContains"]) {
      const malformed = rule("case:name", operator, [value]);
      let error;
      assert.doesNotThrow(() => { error = customRuleError(malformed, field("case:name")); }, `${operator}/${String(value)}`);
      assert.ok(error, `${operator}/${String(value)} must be inactive`);
      assert.equal(activeCustomRules([malformed], CASE_CUSTOM_FIELDS).length, 0);
      assert.equal(matches(record({ name: "anything" }), [malformed]), true);
    }
  }
});

test("selection normalization preserves valid in-rule identity, raw values and text/number/date/boolean field types", () => {
  const rules = freeze([
    rule("case:name", "in", [" Alpha  Beta "]), rule("case:dueIn", "in", ["-1.50", "0"]),
    rule("case:dueDate", "in", ["2024-02-29", "2026-09-10"]), rule("task:likedByMe", "in", ["false"]),
  ]);
  const before = JSON.stringify([rules, CASE_CUSTOM_FIELDS]);
  const normalized = customSelectionRules(rules);
  assert.notEqual(normalized, rules);
  assert.deepEqual(plain(normalized), plain(rules));
  normalized.forEach((item, i) => { assert.equal(item, rules[i]); assert.equal(item.values, rules[i].values); });
  assert.deepEqual(rules.map(item => field(item.fieldId).type), ["text", "number", "date", "boolean"]);
  assert.equal(activeCustomRules(normalized, CASE_CUSTOM_FIELDS).length, 4);
  const row = record({ name: " Alpha  Beta ", dueIn: -1.5, dueDate: "2024-02-29T23:59:59Z" }, [action("boolean", { likedByMe: false })]);
  assert.equal(matches(row, normalized), true);
  assert.equal(matches(record({ ...row.caseData, name: "Alpha  Beta" }, row.tasks), normalized), false);
  assert.equal(JSON.stringify([rules, CASE_CUSTOM_FIELDS]), before);
});

test("selection normalization clears every non-in operator into an empty inert rule without mutating legacy predicates", () => {
  const rules = freeze([
    ...CUSTOM_FILTER_OPERATORS.filter(option => option.value !== "in").map(({ value: operator }) =>
      rule(["gt", "gte", "lt", "lte", "between"].includes(operator) ? "case:dueIn" : "case:name", operator,
        ["empty", "notEmpty"].includes(operator) ? [] : operator === "between" ? ["0", "10"] : ["gt", "gte", "lt", "lte"].includes(operator) ? ["1"] : ["never"])),
    rule("case:dueDate", "between", ["2026-09-01", "2026-09-30"]),
    rule("task:likedByMe", "notIn", ["true"]), rule("case:name", "unknown", ["old"]),
  ]);
  const before = JSON.stringify(rules);
  rules.slice(0, -1).forEach(item => assert.equal(customRuleError(item, field(item.fieldId)), "", "Legacy engine operators remain valid before UI normalization"));
  const normalized = customSelectionRules(rules);
  assert.equal(normalized.length, rules.length);
  normalized.forEach((item, i) => {
    assert.notEqual(item, rules[i]); assert.notEqual(item.values, rules[i].values);
    assert.deepEqual(plain(item), { ...plain(rules[i]), operator: "in", values: [] });
    assert.equal(customRuleError(item, field(item.fieldId)), "请选择筛选项");
  });
  assert.equal(activeCustomRules(normalized, CASE_CUSTOM_FIELDS).length, 0);
  for (const row of [record(), record({ name: "never", dueIn: 100, dueDate: "2026-09-10" }, [action("true", { likedByMe: true })])]) {
    assert.equal(matches(row, normalized), true, "Removed operators cannot survive as hidden predicates");
  }
  const twice = customSelectionRules(normalized);
  assert.deepEqual(plain(twice), plain(normalized)); normalized.forEach((item, i) => assert.equal(twice[i], item));
  assert.equal(JSON.stringify(rules), before);
});

test("selection normalization does not repair or discard invalid in-values; only valid selections count in mixed drafts", () => {
  const valid = rule("case:owner", "in", ["张伟"]);
  const invalid = [rule("case:name"), rule("case:dueIn", "in", ["NaN"]),
    rule("case:dueDate", "in", ["2026-02-29"]), rule("task:likedByMe", "in", ["False"]),
    rule("case:missing", "in", ["old"]), rule("case:dueIn", "in", [0]), rule("case:name", "in", [" "])];
  const old = rule("case:owner", "contains", ["李娜"]);
  const rules = freeze([valid, ...invalid, old]); const before = JSON.stringify(rules);
  const normalized = customSelectionRules(rules);
  [valid, ...invalid].forEach((item, i) => assert.equal(normalized[i], item));
  assert.deepEqual(plain(normalized.at(-1)), { ...plain(old), operator: "in", values: [] });
  assert.deepEqual(plain(activeCustomRules(normalized, CASE_CUSTOM_FIELDS)), [plain(valid)]);
  assert.equal(matches(record({ owner: "张伟" }), normalized), true);
  assert.equal(matches(record({ owner: "李娜" }), normalized), false);
  assert.equal(JSON.stringify(rules), before);
  assert.deepEqual(plain(customSelectionRules([])), []);
});