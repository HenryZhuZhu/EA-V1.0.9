import test from "node:test";
import assert from "node:assert/strict";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";
import vm from "node:vm";
import { build } from "esbuild";
import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";

const { outputFiles } = await build({
  entryPoints: [fileURLToPath(new URL("../src/app/components/TaskBusinessFilter.tsx", import.meta.url))],
  bundle: true, write: false, platform: "node", format: "cjs", jsx: "automatic",
  packages: "external",
});
const sandbox = { module: { exports: {} }, require: createRequire(import.meta.url) };
vm.runInNewContext(outputFiles[0].text, sandbox);
const { TaskBusinessFilter, businessKindFilter, businessObjectFilter, searchBusinessOptions } = sandbox.module.exports;
const options = [
  { key: "产品:p1", kind: "产品", name: "产品一", origin: "case" },
  { key: "Project:name:同名项目", kind: "Project", name: "同名项目", origin: "case", nameOnly: true },
  { key: "Project:id:1", kind: "Project", name: "同名项目", origin: "task" },
  { key: "TF:tf1", kind: "TF", name: "专项一", origin: "task" },
];
const props = { filters: { businessKind: "all", businessKey: "" }, options, className: "field", onChange() {} };
const render = filters => renderToStaticMarkup(createElement(TaskBusinessFilter, { ...props, filters }));
const plain = value => JSON.parse(JSON.stringify(value));

test("joined selector keeps five types and compact defaults inside a single shared border", () => {
  for (const kind of ["all", "none", "产品", "Project", "TF"]) {
    const html = render({ businessKind: kind, businessKey: "" });
    assert.equal((html.match(/<select /g) ?? []).length, 1);
    assert.equal((html.match(/<option /g) ?? []).length, 5);
    assert.doesNotMatch(html, /<optgroup /);
    assert.ok(html.includes(`value="${kind}" selected=""`));
    assert.match(html, /aria-label="任务涉及类型"/);
    assert.match(html, /aria-label="具体涉及对象"/);
    assert.match(html, /data-slot="task-business-filter"/);
    assert.match(html, /h-4 w-px shrink-0 bg-slate-200/);
    assert.equal((html.match(/!border-0 !bg-transparent/g) ?? []).length, 2);
    assert.doesNotMatch(html, /全部涉及|先选择类型|不适用/);
    if (kind === "all" || kind === "none") assert.match(html, /<span class="truncate">—<\/span>/);
    for (const ref of options) assert.ok(!html.includes(ref.name));
    assert.equal(/disabled=""/.test(html), kind === "all" || kind === "none");
  }
});

test("switching type always clears the old object and rejects unknown types", () => {
  for (const kind of ["all", "none", "产品", "Project", "TF"]) {
    assert.deepEqual(plain(businessKindFilter(kind)), { businessKind: kind, businessKey: "" });
  }
  for (const invalid of ["", "kind:产品", "object:missing", "invalid"]) assert.equal(businessKindFilter(invalid), undefined);
});

test("second level preserves exact IDs and cannot choose an object from a different type", () => {
  const before = JSON.stringify(options);
  for (const ref of options) {
    assert.deepEqual(plain(businessObjectFilter(ref.kind, ref.key, options)), { businessKind: ref.kind, businessKey: ref.key });
    assert.deepEqual(plain(businessObjectFilter(ref.kind, "", options)), { businessKind: ref.kind, businessKey: "" });
  }
  assert.equal(businessObjectFilter("产品", "Project:id:1", options), undefined);
  assert.equal(businessObjectFilter("产品", "产品:missing", options), undefined);
  assert.equal(businessObjectFilter("all", "", options), undefined);
  assert.equal(businessObjectFilter("none", "产品:p1", options), undefined);
  assert.equal(JSON.stringify(options), before);
});

test("a saved object unavailable in the current relation remains visible without fabricating a match", () => {
  const html = render({ businessKind: "产品", businessKey: "产品:unavailable" });
  assert.match(html, /value="产品" selected=""/);
  assert.match(html, /已选对象（当前视角无任务）/);
  assert.doesNotMatch(html, /disabled=""/);
  assert.match(render({ businessKind: "Project", businessKey: "Project:name:同名项目" }), /同名项目（名称记录）/);
  assert.doesNotMatch(render({ businessKind: "Project", businessKey: "Project:id:1" }), /名称记录/);
});

test("object search is type-scoped, case-insensitive and matches all name or code terms", () => {
  const list = [...options, { key: "产品:p2", kind: "产品", name: "DDR5-X-6400 · DDR5 X-die 6400", origin: "case" }];
  const before = JSON.stringify(list);
  assert.deepEqual(plain(searchBusinessOptions(list, "产品", "  ddr5  6400 ").map(r => r.key)), ["产品:p2"]);
  assert.deepEqual(plain(searchBusinessOptions(list, "Project", "同名").map(r => r.key)), ["Project:name:同名项目", "Project:id:1"]);
  assert.equal(searchBusinessOptions(list, "产品", "同名").length, 0);
  assert.equal(searchBusinessOptions(list, "all").length, 0);
  assert.equal(searchBusinessOptions(list, "none").length, 0);
  assert.equal(searchBusinessOptions(list, "产品", "not-found").length, 0);
  assert.equal(searchBusinessOptions(list, "产品", "ddr5")[0], list.at(-1));
  assert.equal(JSON.stringify(list), before);
});

test("large catalogs do not populate the type dropdown and search retains the complete object set", () => {
  const list = Array.from({ length: 500 }, (_, i) => ({ key: `产品:p${i}`, kind: "产品", name: `产品型号 ${String(i).padStart(3, "0")}`, origin: "case" }));
  const html = renderToStaticMarkup(createElement(TaskBusinessFilter, { ...props, options: list, filters: { businessKind: "产品", businessKey: "" } }));
  assert.equal((html.match(/<option /g) ?? []).length, 5);
  assert.doesNotMatch(html, /产品型号/);
  assert.equal(searchBusinessOptions(list, "产品").length, 500);
  assert.deepEqual(plain(searchBusinessOptions(list, "产品", "499").map(r => r.key)), ["产品:p499"]);
});

test("selected product shows its short code while tooltip and search retain the full reference", () => {
  const ref = { key: "产品:full-id", kind: "产品", name: "DDR5-X-6400 · DDR5 X-die 6400", origin: "case" };
  const before = JSON.stringify(ref);
  const html = renderToStaticMarkup(createElement(TaskBusinessFilter, { ...props, options: [ref], filters: { businessKind: "产品", businessKey: ref.key } }));
  assert.match(html, /<span class="truncate">DDR5-X-6400<\/span>/);
  assert.match(html, /title="DDR5-X-6400 · DDR5 X-die 6400"/);
  assert.deepEqual(plain(searchBusinessOptions([ref], "产品", "x-die").map(r => r.key)), [ref.key]);
  assert.match(render({ businessKind: "产品", businessKey: "产品:p1" }), /<span class="truncate">产品一<\/span>/);
  assert.equal(JSON.stringify(ref), before);
});