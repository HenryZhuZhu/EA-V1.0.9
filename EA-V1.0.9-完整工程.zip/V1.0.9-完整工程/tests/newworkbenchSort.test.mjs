import assert from "node:assert/strict";
import test from "node:test";
import { readFileSync } from "node:fs";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";
import vm from "node:vm";
import { build } from "esbuild";
import { createElement, isValidElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";

const require = createRequire(import.meta.url);
const React = require("react");
const { ArrowDownUp } = require("lucide-react");
const directory = new URL("../src/app/components/", import.meta.url);
// Read state declarations, not magic hook indices. Only a root's useState slots
// are externalized for callbacks; all child hooks, shared controls and models run.
const stateNames = Object.fromEntries(["CaseList", "MyCaseWorkbench"].map(name => {
  const source = readFileSync(new URL(`${name}.tsx`, directory), "utf8");
  const start = source.indexOf(`export function ${name}(`);
  assert.notEqual(start, -1);
  const rest = source.slice(start);
  const nextFunction = /\n(?:export )?function \w+\(/.exec(rest);
  const body = nextFunction ? rest.slice(0, nextFunction.index) : rest;
  return [name, Array.from(body.matchAll(/^\s*const\s+\[\s*(\w+)[^\]\n]*\]\s*=\s*useState\b/gm), match => match[1])];
}));
const { outputFiles } = await build({
  stdin: {
    contents: `export { WorkbenchSort } from './WorkbenchSort';
      export { CaseList } from './CaseList';
      export { MyCaseWorkbench } from './MyCaseWorkbench';
      export { TaskSourceColumn, TASK_COLUMN_SORT_OPTIONS } from './TaskSourceColumn';
      export { CaseFilterPanel } from './CaseFilterPanel';
      export { CaseWorkbenchFilters } from './CaseWorkbenchFilters';
      export { CASE_WORKBENCH_SORT_OPTIONS } from './caseWorkbenchModel';`,
    resolveDir: fileURLToPath(directory), sourcefile: "workbench-sort-test-entry.ts", loader: "ts",
  },
  bundle: true, write: false, platform: "node", format: "cjs", jsx: "automatic", packages: "external",
  external: ["./data", "./subscriptions", "./closures", "./caseTaskTrees",
    "./CategoryTimeline", "./IssueHub", "./ProductCenter", "./ProductAnalysisRestored"],
});
const plain = value => JSON.parse(JSON.stringify(value));
function freeze(value) {
  if (value && typeof value === "object" && !Object.isFrozen(value)) {
    Object.values(value).forEach(freeze); Object.freeze(value);
  }
  return value;
}
function elements(tree) {
  if (Array.isArray(tree)) return Array.from(tree).flatMap(elements);
  return isValidElement(tree) ? [tree, ...elements(tree.props.children)] : [];
}
function text(tree) {
  if (Array.isArray(tree)) return Array.from(tree).map(text).join("");
  if (isValidElement(tree)) return text(tree.props.children);
  return typeof tree === "string" || typeof tree === "number" ? String(tree) : "";
}
function one(tree, predicate, description) {
  const matches = elements(tree).filter(predicate);
  assert.equal(matches.length, 1, `Expected one ${description}`);
  return matches[0];
}
const render = (Component, props) => renderToStaticMarkup(createElement(Component, props));
const taskOptions = freeze([{ value: "priority", label: "紧急程度" }, { value: "due", label: "截止日期" }, { value: "updated", label: "最近更新" }]);
const caseOptions = freeze([{ value: "urgency", label: "紧迫度" }, { value: "level", label: "层级" }, { value: "progress", label: "进度(低→高)" }, { value: "updated", label: "最近更新" }]);
const expectedShell = "inline-flex h-8 min-w-0 shrink-0 items-center gap-1 rounded-lg border border-slate-200 bg-white pl-2.5 pr-0.5 text-xs transition-colors";
const expectedSelect = "h-7 min-w-0 max-w-[130px] cursor-pointer appearance-none bg-transparent pl-1 pr-5 text-xs text-slate-700 outline-none focus-visible:ring-2 focus-visible:ring-[#0052D9]/30";
const chevron = {
  backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%2394a3b8' stroke-width='2'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E\")",
  backgroundRepeat: "no-repeat", backgroundPosition: "right 6px center",
};
function flattenTasks(nodes, depth = 0, path = []) {
  return nodes.flatMap(task => [{ task, depth, path }, ...flattenTasks(task.children ?? [], depth + 1, [...path, task.title])]);
}
function harness({ root, cases = [] } = {}) {
  let capturing = false; let cursor = 0; let tree;
  const slots = new Map(); const updates = []; const writes = [];
  const forbidden = name => (...args) => { writes.push([name, ...args]); throw new Error(`Unexpected ${name}`); };
  const stubs = {
    react: { ...React, useState(initial) {
      if (!capturing) return React.useState(initial);
      const name = stateNames[root][cursor++];
      assert.ok(name, `Unexpected state slot in ${root}`);
      if (!slots.has(name)) slots.set(name, typeof initial === "function" ? initial() : initial);
      return [slots.get(name), next => {
        const previous = slots.get(name); const value = typeof next === "function" ? next(previous) : next;
        slots.set(name, value); updates.push({ name, previous, value });
      }];
    } },
    "./data": {
      mockCases: cases, mockProducts: [], currentUser: { name: "张伟", department: "PTE" }, flattenTasks,
      myTasksInCase: (record, actor) => flattenTasks(record.tasks).filter(({ task }) => task.owner === actor),
      ownerToDepartment: { 张伟: "PTE", 李娜: "DA" }, levelColors: { L1: "level-l1" }, urgencyBar: { 一般: "bg-blue-400" },
      caseProductOf: () => undefined, caseMarkCode: () => null, issueOfCase: () => undefined, issueStatusColors: {},
    },
    "./subscriptions": { useSubscriptions: () => ({ isSubscribed: () => false, toggle: forbidden("subscription write") }) },
    "./closures": { useClosures: () => ({ get: () => undefined, isClosed: () => false, isRootCaused: () => false }) },
    "./caseTaskTrees": { useCaseTaskRevision: () => 0, loadCaseTaskTree: (_id, fallback) => fallback },
    "./CategoryTimeline": { CategoryTimeline: forbidden("CategoryTimeline render"), PRODUCT_STAGES: [], PLATFORM_STAGES: [], platformOf: record => record.failPlatform },
    "./IssueHub": { IssueHub: forbidden("IssueHub render") },
    "./ProductCenter": { ProductCenter: forbidden("ProductCenter render") },
    "./ProductAnalysisRestored": { ProductAnalysisRestored: forbidden("ProductAnalysis render") },
  };
  const sandbox = { module: { exports: {} }, require(name) {
    if (Object.hasOwn(stubs, name)) return stubs[name];
    assert.ok(!name.startsWith(".") && !name.startsWith("/"), `Unexpected app dependency ${name}`);
    return require(name);
  } };
  for (const name of ["localStorage", "sessionStorage"]) Object.defineProperty(sandbox, name, { get: forbidden(`${name} access`) });
  vm.runInNewContext(outputFiles[0].text, sandbox);
  const api = sandbox.module.exports;
  return { ...api, slots, updates, writes, get tree() { return tree; },
    renderRoot(props) {
      function Probe() {
        capturing = Boolean(root); cursor = 0;
        try { tree = api[root ?? "TaskSourceColumn"](props); } finally { capturing = false; }
        if (root) assert.equal(cursor, stateNames[root].length, `Update the bounded ${root} harness`);
        return tree;
      }
      return renderToStaticMarkup(createElement(Probe));
    },
  };
}
function native(api, props) { return one(api.WorkbenchSort(props), node => node.type === "select", "native sorter"); }

test("WorkbenchSort has the exact shared 32px white thin-border shell, ArrowDownUp label, native capped value and stable styles for all seven choices", () => {
  const api = harness();
  for (const options of [taskOptions, caseOptions]) for (const option of options) {
    const props = freeze({ value: option.value, options, onChange() {}, ariaLabel: "测试排序" });
    const tree = api.WorkbenchSort(props); const select = native(api, props); const html = render(api.WorkbenchSort, props);
    assert.equal(tree.type, "label"); assert.equal(tree.props.className, expectedShell);
    const icon = one(tree, node => node.type === ArrowDownUp, "real ArrowDownUp icon");
    assert.equal(icon.props.size, 12); assert.equal(icon.props.className, "shrink-0 text-slate-400");
    const label = one(tree, node => node.type === "span", "visible 排序 label");
    assert.equal(label.props.children, "排序"); assert.equal(label.props.className, "shrink-0 text-slate-400");
    assert.equal(select.props.className, expectedSelect);
    assert.deepEqual(plain(select.props.style), chevron);
    assert.equal(select.props.value, option.value); assert.equal(select.props.title, option.label);
    assert.equal(select.props["aria-label"], "测试排序"); assert.equal(select.props.defaultValue, undefined);
    assert.equal(select.props.multiple, undefined); assert.equal(select.props.disabled, undefined);
    const choices = elements(select).filter(node => node.type === "option");
    assert.deepEqual(choices.map(node => [node.key, node.props.value, text(node)]), options.map(item => [item.value, item.value, item.label]));
    for (const choice of choices) assert.equal(choice.props.className, "font-normal text-slate-700");
    assert.equal((html.match(/<select\b/g) ?? []).length, 1);
    assert.equal((html.match(/lucide-arrow-down-up/g) ?? []).length, 1);
    const selected = (html.match(/<option\b[^>]*>/g) ?? []).filter(tag => /\bselected=""/.test(tag));
    assert.equal(selected.length, 1); assert.ok(selected[0].includes(`value="${option.value}"`));
    assert.doesNotMatch(html, /<button\b|role="listbox"|role="menu"|筛选|清除|font-semibold|border-2|bg-purple/);
  }
  assert.equal(native(api, { value: "due", options: taskOptions, onChange() {} }).props["aria-label"], "排序");
  assert.deepEqual(api.writes, []);
});

test("WorkbenchSort emits exactly one callback for known values, guards unknown values, and remains controlled with frozen options and long escaped labels", () => {
  const api = harness();
  for (const options of [taskOptions, caseOptions]) {
    const calls = []; const props = freeze({ value: options[0].value, options, onChange: value => calls.push(value) });
    const before = JSON.stringify(props); const html = render(api.WorkbenchSort, props); const select = native(api, props);
    assert.deepEqual(calls, []);
    for (const value of [undefined, null, "", "unknown", "__proto__", "UPDATED", " updated ", 0, false,
      ...["priority", "due", "urgency", "level", "progress"].filter(value => !options.some(option => option.value === value))]) {
      select.props.onChange({ target: { value } });
      assert.deepEqual(calls, []);
    }
    for (const option of options) {
      const count = calls.length;
      select.props.onChange({ target: { value: option.value } });
      assert.equal(calls.length, count + 1); assert.equal(calls.at(-1), option.value);
      assert.equal(select.props.value, props.value); assert.equal(render(api.WorkbenchSort, props), html);
      const updated = { ...props, value: option.value };
      assert.equal(native(api, updated).props.value, option.value);
      assert.equal(native(api, updated).props.title, option.label);
    }
    // Repeat events are not silently dropped by the reusable control; reducers
    // own no-op handling, and still receive exactly one event per valid selection.
    select.props.onChange({ target: { value: props.value } }); assert.equal(calls.length, options.length + 1);
    assert.equal(JSON.stringify(props), before);
  }
  const options = freeze([{ value: "long<&\"", label: "完整排序名称".repeat(40) + '<script>坏标签</script>&"' }]);
  const calls = []; const props = { value: options[0].value, options, onChange: value => calls.push(value) };
  const html = render(api.WorkbenchSort, props);
  assert.doesNotMatch(html, /<script>/); assert.match(html, /&lt;script&gt;/);
  assert.equal(native(api, props).props.title, options[0].label);
  assert.equal(native(api, props).props.className, expectedSelect);
  native(api, props).props.onChange({ target: { value: options[0].value } }); assert.deepEqual(calls, [options[0].value]);
  assert.deepEqual(api.writes, []);
});

test("actual CaseList, MyCaseWorkbench and both TaskSourceColumn headers mount the same sorter with four Case or three task choices and no filter-badge contribution", () => {
  for (const root of ["CaseList", "MyCaseWorkbench"]) {
    const cases = freeze([]); const api = harness({ root, cases });
    const props = root === "CaseList" ? { initialView: "list", onOpenCase() {} } : { cases, onOpenCase() {} };
    const ariaLabel = root === "CaseList" ? "分析中心 Case 排序" : "我的 Case 排序";
    const sorter = () => one(api.tree, node => node.type === api.WorkbenchSort, `${root} actual shared sorter`);
    function check(count) {
      const html = api.renderRoot(props); const control = sorter();
      assert.equal(control.props.ariaLabel, ariaLabel); assert.deepEqual(plain(control.props.options), caseOptions);
      assert.equal((html.match(/<select\b/g) ?? []).length, 1);
      assert.ok(html.includes(`aria-label="${ariaLabel}"`));
      assert.ok(html.includes(`aria-label="筛选${count ? ` ${count}` : ""}"`));
      assert.equal(api.WorkbenchSort(control.props).props.className, expectedShell);
      assert.equal(native(api, control.props).props.className, expectedSelect);
      assert.equal((html.match(/lucide-arrow-down-up/g) ?? []).length, 1);
      assert.doesNotMatch(html, /清除[^<>]*排序|aria-label="筛选 [2-9]/);
      assert.deepEqual(api.writes, []);
    }
    check(0);
    assert.equal(sorter().props.value, "urgency");
    const panel = () => one(api.tree, node => node.type === (root === "CaseList" ? api.CaseFilterPanel : api.CaseWorkbenchFilters), "actual Case filter interface");
    for (const count of [0, 1]) {
      if (count) {
        if (root === "CaseList") panel().props.onChange("level", "L1");
        else panel().props.onChange({ level: "L1" });
        check(1);
      }
      for (const option of caseOptions) {
        const previous = new Map(api.slots); const calls = api.updates.length;
        const select = native(api, sorter().props);
        select.props.onChange({ target: { value: "priority" } });
        assert.equal(api.updates.length, calls, "Task-only values cannot reach Case callbacks");
        select.props.onChange({ target: { value: option.value } });
        assert.equal(api.updates.length, calls + 1);
        if (root === "CaseList") {
          assert.equal(api.slots.get("sort"), option.value);
          for (const [name, value] of previous) if (name !== "sort") assert.equal(api.slots.get(name), value);
        } else {
          const old = previous.get("state"); const next = api.slots.get("state");
          assert.equal(next.status, old.status);
          assert.equal(next.views[next.status].filters, old.views[old.status].filters);
          for (const status of ["验证中", "已结案"]) assert.equal(next.views[status], old.views[status]);
        }
        check(count); assert.equal(sorter().props.value, option.value);
      }
    }
    panel().props.onReset(); check(0); assert.equal(sorter().props.value, "updated", "Filter reset preserves display sorting");
    assert.deepEqual(plain(api.CASE_WORKBENCH_SORT_OPTIONS), caseOptions);
  }
  for (const source of ["case", "standalone"]) {
    const api = harness(); const calls = [];
    const props = { source, rows: freeze([]), resetKey: "fixed", businessKey: "", sortBy: "due", onSortChange: value => calls.push(value),
      onShowTask() {}, onOpenCase() {}, onTakeAction() {}, onReject() {},
    };
    const html = api.renderRoot(props);
    const header = one(api.tree, node => node.type === "header", "source header");
    const control = one(header, node => node.type === api.WorkbenchSort, "same shared WorkbenchSort");
    assert.deepEqual(plain(control.props.options), taskOptions); assert.equal(control.props.options, api.TASK_COLUMN_SORT_OPTIONS);
    assert.equal(control.props.ariaLabel, `${source === "case" ? "Case 任务" : "自由任务"}排序`);
    assert.equal((html.match(/<select\b/g) ?? []).length, 1);
    assert.equal(api.WorkbenchSort(control.props).props.className, expectedShell);
    assert.doesNotMatch(html, /筛选|清除/);
    const select = native(api, control.props);
    for (const value of ["urgency", "level", "progress"]) select.props.onChange({ target: { value } });
    assert.deepEqual(calls, []);
    select.props.onChange({ target: { value: "updated" } }); assert.deepEqual(calls, ["updated"]);
    assert.equal(control.props.value, "due"); assert.deepEqual(api.writes, []);
  }
});