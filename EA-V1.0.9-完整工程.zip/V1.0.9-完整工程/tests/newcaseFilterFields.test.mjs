import assert from "node:assert/strict";
import test from "node:test";
import { readFileSync } from "node:fs";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";
import vm from "node:vm";
import { build } from "esbuild";
import { createElement, isValidElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";

const require = createRequire(import.meta.url);
const directory = new URL("../src/app/components/", import.meta.url);
const { outputFiles } = await build({
  stdin: {
    contents: `export { CaseFilterFields, caseFilterOptions, CASE_LEVEL_OPTIONS, CASE_URGENCY_OPTIONS, CASE_ANALYSIS_STATUS_OPTIONS } from "./CaseFilterFields";
      export { CaseWorkbenchFilters } from "./CaseWorkbenchFilters";
      export { CaseFilterPanel, CASE_FILTER_PANEL_CLASS_NAME } from "./CaseFilterPanel";
      export { CaseCustomFilterEditor } from "./CaseCustomFilterEditor";
      export { DEFAULT_CASE_FILTERS } from "./caseWorkbenchModel";`,
    resolveDir: fileURLToPath(directory), sourcefile: "case-filter-fields-test-entry.ts", loader: "ts",
  },
  bundle: true, write: false, platform: "node", format: "cjs", jsx: "automatic",
  packages: "external", external: ["./data"],
});
const sandbox = { module: { exports: {} }, require(name) {
  // Preserve the actual recursive raw tree; no precomputed candidate outputs.
  if (name === "./data") return { flattenTasks: function walk(nodes) {
    return nodes.flatMap(task => [{ task }, ...walk(task.children ?? [])]);
  } };
  return require(name);
} };
for (const name of ["localStorage", "sessionStorage"]) Object.defineProperty(sandbox, name, {
  get() { throw new Error(`${name} must not be accessed by field tests`); },
});
vm.runInNewContext(outputFiles[0].text, sandbox);
const { CaseFilterFields, caseFilterOptions, CaseWorkbenchFilters, DEFAULT_CASE_FILTERS,
  CaseFilterPanel, CASE_FILTER_PANEL_CLASS_NAME, CaseCustomFilterEditor,
  CASE_LEVEL_OPTIONS, CASE_URGENCY_OPTIONS, CASE_ANALYSIS_STATUS_OPTIONS } = sandbox.module.exports;
const plain = value => JSON.parse(JSON.stringify(value));
const dimensions = [["level", "层级"], ["urgency", "紧急程度"], ["status", "状态"], ["product", "产品"], ["department", "部门"], ["creator", "创建 / 分派人"]];
const primaryStatuses = ["进行中", "验证中", "已结案"];
const analysisStatuses = ["全部", "进行中", "验证中", "暂存", "已结案"];
const defaultValues = Object.freeze({ level: "全部", urgency: "全部", status: "全部", product: "全部", department: "全部", creator: "全部" });
function freeze(value) {
  if (value && typeof value === "object" && !Object.isFrozen(value)) {
    Object.values(value).forEach(freeze); Object.freeze(value);
  }
  return value;
}
function elements(tree) {
  if (Array.isArray(tree)) return Array.from(tree).flatMap(elements);
  return isValidElement(tree) ? [tree, ...elements(tree.props.children)] : [];
}
function text(tree) {
  if (Array.isArray(tree)) return Array.from(tree).map(text).join("");
  if (isValidElement(tree)) return text(tree.props.children);
  return typeof tree === "string" || typeof tree === "number" ? String(tree) : "";
}
const render = props => renderToStaticMarkup(createElement(CaseFilterFields, props));
const controls = props => elements(CaseFilterFields(props)).filter(node => node.type === "select");
const choices = select => elements(select).filter(node => node.type === "option").map(node => [node.props.value, text(node)]);
const propsFor = (patch = {}) => ({ values: defaultValues, products: ["全部"], departments: ["全部"], creators: ["全部"], onChange() {}, ...patch });
function assertClasses(className, expected) {
  const tokens = className.split(/\s+/);
  for (const token of expected) assert.ok(tokens.includes(token), `Missing class ${token}: ${className}`);
}
function sharedFields(props) {
  const tree = CaseWorkbenchFilters(props);
  const panels = elements(tree).filter(node => node.type === CaseFilterPanel);
  assert.equal(panels.length, 1, "Workbench must mount the actual shared panel once");
  const matches = elements(CaseFilterPanel(panels[0].props)).filter(node => node.type === CaseFilterFields);
  assert.equal(matches.length, 1, "Workbench must mount the actual shared fields once");
  return matches[0];
}
const workbenchProps = (cases, status, filters = DEFAULT_CASE_FILTERS) => ({ cases, status, filters, open: true,
  onOpenChange() {}, onChange() {}, onStatusChange() {}, onReset() {} });

test("optional legacy creator defaults to 全部 without an active or duplicate field", () => {
  for (const creator of [undefined, null, "", "全部"]) {
    const props = propsFor({ values: { ...defaultValues, creator }, creators: undefined });
    const select = controls(props).find(node => node.props["aria-label"] === "Case 创建 / 分派人");
    assert.equal(select.props.value, "全部"); assert.deepEqual(choices(select), [["全部", "全部"]]);
    assert.doesNotMatch(select.props.className, /font-medium/);
    assert.equal(controls(props).length, 6);
  }
});

test("creator options merge actual Case creators and deep coded-task dispatchers, not owners or thought metadata", () => {
  const cases = freeze([{ product: "DDR5", departments: [], createdBy: "李娜", owner: "Case负责人", tasks: [
    { supervisor: "思路人员", children: [{ code: "t1", supervisor: "王强", owner: "任务负责人", children: [{ children: [{ code: "t2", supervisor: "李娜" }] }] }] },
    { code: "t3", supervisor: " " }, { code: "", supervisor: "无编码人员" },
  ] }, { product: "DDR5", departments: [], createdBy: "李娜甲" }, { product: "DDR5", departments: [] }]);
  const before = JSON.stringify(cases);
  assert.deepEqual(plain(caseFilterOptions(cases).creators), ["全部", "李娜", "王强", "李娜甲"]);
  assert.deepEqual(plain(caseFilterOptions([{ product: "DDR5", departments: [] }]).creators), ["全部"], "Old helper callers need no tasks/createdBy");
  assert.equal(JSON.stringify(cases), before);
});

test("shared fields SSR has exactly six labels, default 全部 values and unchanged analysis level/urgency/status choices", () => {
  assert.deepEqual(plain(CASE_LEVEL_OPTIONS), ["全部", "L0", "L1", "L2", "L3"]);
  assert.deepEqual(plain(CASE_URGENCY_OPTIONS), ["全部", "非常紧急", "紧急", "一般", "不紧急"]);
  assert.deepEqual(plain(CASE_ANALYSIS_STATUS_OPTIONS), analysisStatuses);
  const props = propsFor({ products: freeze(["全部", "DDR5", "LPDDR"]), departments: freeze(["全部", "PTE", "DA"]) });
  const before = JSON.stringify(props); const selects = controls(props); const html = render(props);
  assert.deepEqual(selects.map(node => node.props["aria-label"]), dimensions.map(([, label]) => `Case ${label}`));
  const labels = elements(CaseFilterFields(props)).filter(node => node.type === "label");
  assert.deepEqual(labels.map(node => text(elements(node).find(child => child.type === "span"))), dimensions.map(([, label]) => label));
  const expected = [["全部", "L0", "L1", "L2", "L3"], ["全部", "非常紧急", "紧急", "一般", "不紧急"], analysisStatuses, props.products, props.departments, props.creators];
  selects.forEach((node, i) => {
    assert.equal(node.props.value, "全部"); assert.equal(node.props.title, "全部");
    assert.equal(node.props.disabled, undefined);
    assert.deepEqual(choices(node), expected[i].map(value => [value, value]));
  });
  assert.equal((html.match(/<select\b/g) ?? []).length, 6);
  assert.equal((html.match(/<label\b/g) ?? []).length, 6);
  assert.equal((html.match(/<option\b(?=[^>]*\bvalue="全部")(?=[^>]*\bselected="")[^>]*>/g) ?? []).length, 6);
  assert.doesNotMatch(html, /创建人|L4|L5|任务涉及|Project|\bTF\b|Pending/);
  assert.equal(JSON.stringify(props), before);
});

test("caseFilterOptions deduplicates exact original product/department strings in first-seen order without ID or owner inference", () => {
  const cases = freeze([
    { product: "DDR5", productId: "catalog-only", productIds: ["another-id"], projectName: "项目不是产品", owner: "负责人", departments: ["DA", "PTE", "DA"], tasks: [{ department: "任务部门" }] },
    { product: "LPDDR", departments: ["PTE", "FT"] },
    { product: "DDR5", departments: ["DA"] },
    { product: " DDR5 ", departments: [" DA "] },
    { product: "ddr5", departments: ["pte"] },
    { product: "p1", departments: [] },
    { productId: "only-id", productIds: ["multi-id"], owner: "仅有负责人", initiatingDepartment: "发起部门", tasks: [{ department: "任务部门" }] },
  ]);
  const before = JSON.stringify(cases);
  const options = caseFilterOptions(cases);
  assert.deepEqual(plain(options), {
    products: ["全部", "DDR5", "LPDDR", " DDR5 ", "ddr5", "p1"],
    departments: ["全部", "DA", "PTE", "FT", " DA ", "pte"],
    creators: ["全部"],
  });
  assert.equal(new Set(options.products).size, options.products.length);
  assert.equal(new Set(options.departments).size, options.departments.length);
  assert.equal(JSON.stringify(cases), before);
  assert.notEqual(options.departments, cases[0].departments);
  assert.deepEqual(plain(caseFilterOptions(cases)), plain(options));
});

test("empty or missing Case fields yield only 全部 without invented products/departments or mutation", () => {
  for (const cases of [[], [{}, { product: "", departments: [] }, { product: null, departments: null },
    { productId: "p1", productIds: ["p2"], owner: "张伟", department: "推导部门", tasks: [{ department: "任务部门" }] }]]) {
    freeze(cases); const before = JSON.stringify(cases);
    const options = caseFilterOptions(cases);
    assert.deepEqual(plain(options), { products: ["全部"], departments: ["全部"], creators: ["全部"] });
    const props = propsFor(options); const selects = controls(props);
    for (const select of selects.slice(3)) assert.deepEqual(choices(select), [["全部", "全部"]]);
    assert.equal((render(props).match(/<select\b/g) ?? []).length, 6, "Empty candidates must not hide fields");
    assert.equal(JSON.stringify(cases), before);
  }
});

test("all six real select callbacks emit exact field/raw-value pairs and leave controlled values and option arrays untouched", () => {
  const calls = []; const props = propsFor({
    values: freeze({ level: "L2", urgency: "紧急", status: "暂存", product: " DDR5 ", department: " DA ", creator: "李娜" }),
    products: freeze(["全部", " DDR5 "]), departments: freeze(["全部", " DA "]),
    onChange: (key, value) => calls.push([key, value]),
  });
  const before = JSON.stringify(props); const html = render(props); const selects = controls(props);
  assert.deepEqual(calls, []);
  const expected = [];
  selects.forEach((node, i) => {
    const key = dimensions[i][0]; const value = props.values[key];
    node.props.onChange({ target: { value } }); expected.push([key, value]);
    assert.deepEqual(calls, expected, "Exactly one callback per change");
    node.props.onChange({ target: { value: "全部" } }); expected.push([key, "全部"]);
    assert.deepEqual(calls, expected);
    assert.equal(node.props.value, value);
  });
  assert.equal(calls.length, 12);
  assert.equal(render(props), html, "No internal selected-value mutation before a parent update");
  assert.equal(JSON.stringify(props), before);
});

test("missing selections remain visible selected fallback options with exact values instead of silently broadening to 全部", () => {
  const values = freeze({ level: "L9", urgency: "旧紧急值", status: "旧状态", product: '已移除产品 <片>&"', department: "已移除部门", creator: "已移除分派人" });
  const props = propsFor({ values, products: freeze(["全部"]), departments: freeze(["全部"]) });
  const before = JSON.stringify(props); const html = render(props);
  assert.equal((html.match(/（当前无可选项）/g) ?? []).length, 6);
  assert.equal((html.match(/selected=""/g) ?? []).length, 6);
  assert.doesNotMatch(html, /value="全部" selected=""|<片>/);
  assert.match(html, /&lt;片&gt;&amp;&quot;/);
  controls(props).forEach((select, i) => {
    const value = values[dimensions[i][0]];
    assert.equal(select.props.value, value); assert.equal(select.props.title, value);
    assert.deepEqual(choices(select)[0], [value, `${value}（当前无可选项）`]);
    assert.equal(choices(select).filter(([option]) => option === value).length, 1);
    assert.ok(choices(select).some(([option]) => option === "全部"));
  });
  assert.equal(JSON.stringify(props), before);
});

test("six shared field shells retain 32px height and selects cap at 130px in a two-column 480px popup contract", () => {
  const longProduct = "完整产品名称用于验证超长字段".repeat(12);
  for (const values of [defaultValues, { level: "L2", urgency: "非常紧急", status: "验证中", product: longProduct, department: "长部门名称".repeat(12), creator: "长人员名称".repeat(12) }]) {
    const props = propsFor({ values }); const root = CaseFilterFields(props);
    assertClasses(root.props.className, ["grid", "grid-cols-2", "gap-2"]);
    const labels = elements(root).filter(node => node.type === "label");
    assert.equal(labels.length, 6);
    labels.forEach((label, i) => {
      const key = dimensions[i][0]; const active = values[key] !== "全部";
      assertClasses(label.props.className, ["inline-flex", "min-w-0", "items-center", "gap-1", "h-8", "pl-2.5", "pr-0.5", "rounded-lg", "border",
        ...(active ? ["border-[#0052D9]/40", "bg-[#0052D9]/5"] : ["border-slate-200", "bg-white"])]);
      const select = elements(label).find(node => node.type === "select");
      assertClasses(select.props.className, ["min-w-0", "h-7", "max-w-[130px]", "pl-1", "pr-5", "appearance-none", "bg-transparent"]);
      assert.equal(select.props.title, values[key], "Truncated selections retain their full native tooltip");
      assert.equal(select.props.style.backgroundPosition, "right 6px center");
      assert.equal(select.props.style.backgroundRepeat, "no-repeat");
      assert.match(select.props.style.backgroundImage, /data:image\/svg\+xml/);
    });
    assert.equal((render(props).match(/max-w-\[130px\]/g) ?? []).length, 6);
    const popupTree = CaseWorkbenchFilters(workbenchProps([], "验证中"));
    const content = elements(popupTree).find(node => node.props["aria-label"] === "Case 筛选条件");
    assertClasses(content.props.className, ["w-[480px]", "p-0", "overflow-hidden"]);
  }
  // Class/prop contracts only: SSR does not measure browser layout or portals.
});

test("actual CaseList and MyCase import/use the same complete panel/options, with exact rendered auxiliary parity and only status choices differing", () => {
  const listSource = readFileSync(new URL("CaseList.tsx", directory), "utf8");
  const workbenchSource = readFileSync(new URL("MyCaseWorkbench.tsx", directory), "utf8");
  const filterSource = readFileSync(new URL("CaseWorkbenchFilters.tsx", directory), "utf8");
  for (const source of [listSource, filterSource]) {
    const imported = /import\s*\{([^}]+)\}\s*from\s*["']\.\/CaseFilterFields["']/.exec(source);
    assert.ok(imported, "Consumers must import the production shared module");
    assert.match(imported[1], /\bcaseFilterOptions\b/);
    assert.match(source, /import\s*\{\s*CaseFilterPanel,\s*CASE_FILTER_PANEL_CLASS_NAME\s*\}\s*from\s*["']\.\/CaseFilterPanel["']/);
    assert.equal((source.match(/<CaseFilterPanel\b/g) ?? []).length, 1);
    assert.equal((source.match(/<CaseFilterFields\b/g) ?? []).length, 0);
    assert.doesNotMatch(source, /function\s+(?:CaseFilterFields|caseFilterOptions)\b/);
  }
  assert.match(listSource, /const\s*\{\s*products:\s*productOpts,\s*departments:\s*deptOpts,\s*creators:\s*creatorOpts\s*\}\s*=\s*caseFilterOptions\(currentCases\)/);
  assert.match(listSource, /const\s+statusOpts\s*=\s*CASE_ANALYSIS_STATUS_OPTIONS/);
  const usage = /<CaseFilterPanel\b[\s\S]*?\/>/.exec(listSource)[0];
  assert.match(usage, /values=\{\{\s*level,\s*urgency,\s*status,\s*product,\s*department:\s*deptFilter,\s*creator:\s*creatorFilter\s*\}\}/);
  assert.match(usage, /products=\{productOpts\}\s+departments=\{deptOpts\}\s+creators=\{creatorOpts\}/);
  assert.match(usage, /department:\s*setDeptFilter,\s*creator:\s*setCreator\s*\}\)\[field\]\(value\)\}/);
  assert.doesNotMatch(usage, /statusOptions=/, "CaseList must retain the analysis default including 全部/暂存");
  assert.match(workbenchSource, /import\s*\{\s*CaseWorkbenchFilters\s*\}\s*from\s*["']\.\/CaseWorkbenchFilters["']/);
  assert.match(workbenchSource, /<CaseWorkbenchFilters\s+cases=\{currentCases\}/);
  assert.doesNotMatch(workbenchSource, /TaskBusinessFilter|result\.(?:businessOptions|creators)|filters\.(?:businessKind|businessKey|creator)/);
  assert.match(filterSource, /caseFilterOptions\(cases\)/);
  assert.match(filterSource, /statusOptions=\{fanout\s*\?\s*\["全部",\s*\.\.\.CASE_WORKBENCH_STATUSES\]\s*:\s*CASE_WORKBENCH_STATUSES\}/);
  for (const source of [listSource, filterSource]) assert.ok(source.includes("className={CASE_FILTER_PANEL_CLASS_NAME}"));
  assertClasses(CASE_FILTER_PANEL_CLASS_NAME, ["w-[480px]", "max-h-[min(80vh,var(--radix-popover-content-available-height))]"]);

  const cases = freeze([{ product: "原始产品", departments: ["原始部门"], createdBy: "李娜" }, { product: "另一个产品", departments: ["原始部门", "另一部门"], tasks: [{ code: "t1", supervisor: "张伟" }] }]);
  const options = caseFilterOptions(cases);
  for (const patch of [{}, { level: "L3", urgency: "一般", product: "原始产品", department: "原始部门", creator: "张伟" }, { product: "已移除产品", department: "已移除部门", creator: "旧人" }]) for (const status of primaryStatuses) {
    const mine = sharedFields(workbenchProps(cases, status, { ...DEFAULT_CASE_FILTERS, ...patch }));
    // The import/usage checks above bind this default-prop rendering to actual
    // CaseList. We do not substitute a fake CaseList or claim to SSR its shell.
    const analysis = propsFor({ ...options, values: { ...defaultValues, ...patch, status } });
    const mineControls = controls(mine.props); const analysisControls = controls(analysis);
    assert.deepEqual(mineControls.map(node => node.props["aria-label"]), analysisControls.map(node => node.props["aria-label"]));
    const mineLabels = render(mine.props).match(/<label\b[^>]*>[\s\S]*?<\/label>/g);
    const analysisLabels = render(analysis).match(/<label\b[^>]*>[\s\S]*?<\/label>/g);
    assert.equal(mineLabels.length, 6); assert.equal(analysisLabels.length, 6);
    for (const i of [0, 1, 3, 4, 5]) {
      assert.equal(mineLabels[i], analysisLabels[i], `Exact ${dimensions[i][1]} markup parity`);
      assert.deepEqual(choices(mineControls[i]), choices(analysisControls[i]));
    }
    assert.deepEqual(choices(mineControls[2]), primaryStatuses.map(value => [value, value]));
    assert.deepEqual(choices(analysisControls[2]), analysisStatuses.map(value => [value, value]));
    assert.equal(mineControls[2].props.value, analysisControls[2].props.value);
    assert.equal(mineControls[2].props.className, analysisControls[2].props.className);
    assert.equal(mineLabels[2].replace(/<option\b[^>]*>[\s\S]*?<\/option>/g, ""), analysisLabels[2].replace(/<option\b[^>]*>[\s\S]*?<\/option>/g, ""));
  }
});

test("shared panel renders optional scope first, real fields/editor/display inside bounded scroll and a fixed controlled footer", () => {
  const calls = [];
  const field = { id: "case:owner", entity: "case", path: ["owner"], type: "text", label: "负责人", group: "基本信息" };
  const editor = { fields: [field], rules: [{ id: "rule", fieldId: field.id, operator: "in", values: ["张伟"] }], optionsFor: () => ["张伟"], onChange: rules => calls.push(["rules", rules]) };
  const props = { ...propsFor(), customEditor: editor,
    scopeContent: createElement("section", { "aria-label": "原始范围" }, "范围"),
    displaySettings: createElement("section", { "aria-label": "原始显示设置" }, "显示设置"),
    onReset: () => calls.push(["reset"]), onDone: () => calls.push(["done"]),
  };
  const tree = CaseFilterPanel(props); const children = tree.props.children;
  assertClasses(tree.props.className, ["flex", "min-h-0", "flex-col", "overflow-hidden"]);
  assertClasses(children[0].props.className, ["min-h-0", "overflow-y-auto", "overscroll-contain", "p-4"]);
  assertClasses(children[1].props.className, ["shrink-0", "border-t", "px-4", "py-3"]);
  const mountedEditor = elements(tree).find(node => node.type === CaseCustomFilterEditor);
  assert.equal(mountedEditor.props.rules, editor.rules); assert.equal(mountedEditor.props.optionsFor, editor.optionsFor);
  const html = renderToStaticMarkup(createElement(CaseFilterPanel, props));
  const positions = ["原始范围", "Case 层级", "自定义筛选条件", "原始显示设置", "重置全部"].map(label => html.indexOf(label));
  assert.ok(positions.every((position, i) => position >= 0 && (!i || position > positions[i - 1])));
  for (const label of ["重置全部", "完成"]) elements(children[1]).find(node => node.type === "button" && text(node) === label).props.onClick();
  assert.deepEqual(calls, [["reset"], ["done"]]);
  const minimal = renderToStaticMarkup(createElement(CaseFilterPanel, { ...propsFor(), onReset() {}, onDone() {} }));
  assert.doesNotMatch(minimal, /原始范围|原始显示设置|自定义筛选条件/);
  const listSource = readFileSync(new URL("CaseList.tsx", directory), "utf8");
  assert.match(listSource, /scopeContent=\{/); assert.match(listSource, /displaySettings=\{/); assert.match(listSource, /customEditor=\{\{/);
  assert.doesNotMatch(readFileSync(new URL("CaseWorkbenchFilters.tsx", directory), "utf8"), /scopeContent=|displaySettings=|查看 Fanout/);
});

test("Fanout alone adds optional 全部 status to shared fields and accepts all three statuses without a lifecycle mutation", () => {
  const calls = [];
  for (const status of ["全部", ...primaryStatuses]) {
    const props = { ...workbenchProps([], status), fanout: true, onStatusChange: value => calls.push(value) };
    const fields = sharedFields(props); const control = controls(fields.props).find(node => node.props["aria-label"] === "Case 状态");
    assert.deepEqual(choices(control), ["全部", ...primaryStatuses].map(value => [value, value]));
    assert.equal(control.props.value, status);
    assert.doesNotMatch(render(fields.props), /暂存|Pending|待接受/);
    control.props.onChange({ target: { value: status } });
    const before = calls.length;
    for (const value of ["Fanout", "Pending", "暂存"]) control.props.onChange({ target: { value } });
    assert.equal(calls.length, before);
    const html = renderToStaticMarkup(createElement(CaseWorkbenchFilters, props));
    assert.ok(html.includes(`aria-label="筛选${status === "全部" ? "" : " 1"}"`));
  }
  assert.deepEqual(calls, ["全部", ...primaryStatuses]);
});