import test from "node:test";
import assert from "node:assert/strict";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";
import vm from "node:vm";
import { build } from "esbuild";
import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";

const { outputFiles } = await build({
  entryPoints: [fileURLToPath(new URL("../src/app/components/VoiceNote.tsx", import.meta.url))],
  bundle: true, write: false, platform: "node", format: "cjs", jsx: "automatic", packages: "external",
});
const sandbox = { module: { exports: {} }, require: createRequire(import.meta.url) };
vm.runInNewContext(outputFiles[0].text, sandbox);
const { VoiceRecorder } = sandbox.module.exports;
const render = props => renderToStaticMarkup(createElement(VoiceRecorder, { onChange() {}, ...props }));

test("icon recorder starts with one microphone button and no visible label or player", () => {
  const html = render({ iconOnly: true });
  assert.equal((html.match(/<button /g) ?? []).length, 1);
  assert.match(html, /aria-label="录制语音备注"/);
  assert.match(html, /lucide-mic/);
  assert.doesNotMatch(html.replace(/<[^>]*>/g, ""), /录制|语音|重录|播放/);
  assert.doesNotMatch(html, /<audio|<input/);
});

test("a recorded note keeps an icon entry and defers playback tools to its popover", () => {
  const html = render({ iconOnly: true, value: "data:audio/wav;base64,UklGRg==" });
  assert.match(html, /aria-label="查看语音备注"/);
  assert.equal((html.match(/<button /g) ?? []).length, 1);
  assert.match(html, /right-1 top-1 h-1 w-1/);
  assert.doesNotMatch(html, /title="删除录音"|title="重新录制"/);
});

test("existing non-icon recorder calls retain their labels and saved-note controls", () => {
  assert.match(render({}), /录制语音/);
  assert.match(render({ compact: true, idleLabel: "语音备注" }), /语音备注/);
  const html = render({ value: "data:audio/wav;base64,UklGRg==" });
  assert.match(html, /title="删除录音"/);
  assert.match(html, /title="重新录制"/);
});