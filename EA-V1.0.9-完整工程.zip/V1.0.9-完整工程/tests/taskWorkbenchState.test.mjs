import assert from "node:assert/strict";
import test from "node:test";
import { build } from "esbuild";
import { fileURLToPath } from "node:url";
import vm from "node:vm";

const { outputFiles } = await build({
  entryPoints: [fileURLToPath(new URL("../src/app/components/taskWorkbenchState.ts", import.meta.url))],
  bundle: true, write: false, platform: "node", format: "cjs", external: ["./data"],
});
const sandbox = { module: { exports: {} }, require: name => { if (name === "./data") return {}; throw new Error(name); } };
vm.runInNewContext(outputFiles[0].text, sandbox);
const { createTaskWorkbenchState: create, updateTaskWorkbenchState: update, selectTaskWorkbenchViews: select, selectTaskWorkbenchOverview: overview, statusViewRows, taskScopeLabel } = sandbox.module.exports;
const plain = value => JSON.parse(JSON.stringify(value));
const statuses = ["待接受", "进行中", "已完成"];
const row = (id, status, patch = {}) => ({ key: id, id, title: id, status, source: "standalone", owner: "张伟", creator: "刘洋", participants: [], business: [], ...patch });

test("pending owner and collaborator labels reflect unaccepted work without changing relations or records", () => {
  for (const status of statuses) {
    assert.equal(taskScopeLabel(status, "mine"), status === "待接受" ? "待我接受" : "我负责");
    assert.equal(taskScopeLabel(status, "assigned"), "我分派");
    assert.equal(taskScopeLabel(status, "participating"), status === "待接受" ? "待我协作" : "我参与");
    const state = update(create(), { type: "status", status });
    const own = row("own", status);
    const before = JSON.stringify(own);
    assert.equal(state.views[status].filters.scope, "mine");
    assert.deepEqual(plain(select([own], state, "张伟").selection.rows), [own]);
    assert.equal(JSON.stringify(own), before);
    const collaboratorState = update(state, { type: "filters", patch: { scope: "participating" } });
    const joined = row("joined", status, { owner: "李娜", participants: ["张伟"] });
    const original = JSON.stringify(joined);
    assert.deepEqual(plain(select([own, joined], collaboratorState, "张伟").selection.rows), [joined]);
    assert.equal(JSON.stringify(joined), original);
    assert.equal(select([own, joined], collaboratorState, "张伟").counts[status], 1);
  }
});

test("primary states keep independent filters, grouping, expansion and page on switching", () => {
  const initial = create(); const before = JSON.stringify(initial);
  let state = update(initial, { type: "filters", patch: { source: "case", caseId: "c1", scope: "assigned", businessKind: "产品" } });
  state = update(state, { type: "group", groupBy: "case" });
  state = update(state, { type: "business" });
  state = update(state, { type: "page", page: 2 });
  const pending = plain(state.views.待接受);
  state = update(state, { type: "status", status: "进行中" });
  assert.deepEqual(plain(state.views.进行中), plain(initial.views.进行中));
  state = update(state, { type: "filters", patch: { creator: "李娜" } });
  state = update(state, { type: "group", groupBy: "due" });
  state = update(state, { type: "status", status: "已完成" });
  state = update(state, { type: "filters", patch: { source: "standalone" } });
  state = update(state, { type: "status", status: "待接受" });
  assert.deepEqual(plain(state.views.待接受), pending);
  assert.equal(state.views.进行中.filters.creator, "李娜");
  assert.equal(state.views.进行中.groupBy, "due");
  assert.equal(state.views.已完成.filters.source, "standalone");
  assert.equal(JSON.stringify(initial), before);
});

test("repeat clicks and resets never exit status or affect other status views", () => {
  for (const status of statuses) {
    let state = update(create(), { type: "status", status });
    assert.equal(update(state, { type: "status", status }), state);
    state = update(state, { type: "filters", patch: { status: null, query: "hidden", showUpgraded: true, scope: "participating", source: "case", caseId: "c" } });
    assert.equal(state.views[status].filters.status, status);
    assert.equal(state.views[status].filters.showUpgraded, false);
    assert.equal(state.views[status].filters.query, "");
    state = update(state, { type: "group", groupBy: "owner" });
    state = update(state, { type: "page", page: 3 });
    const prev = state;
    state = update(state, { type: "reset" });
    assert.equal(state.status, status);
    assert.equal(state.views[status].filters.status, status);
    assert.equal(state.views[status].filters.scope, "participating");
    assert.equal(state.views[status].filters.source, "case");
    assert.equal(state.views[status].filters.caseId, "");
    assert.equal(state.views[status].groupBy, "none");
    assert.equal(state.views[status].page, 1);
    for (const other of statuses.filter(s => s !== status)) assert.equal(state.views[other], prev.views[other]);
  }
});

test("Case filters clear on leaving the Case tab without affecting other status views", () => {
  let state = update(create(), { type: "filters", patch: { source: "case", caseId: "c" } });
  state = update(state, { type: "filters", patch: { source: "all" } });
  assert.equal(state.views.待接受.filters.caseId, "");
  state = update(state, { type: "filters", patch: { source: "case", caseId: "c" } });
  state = update(state, { type: "status", status: "进行中" });
  state = update(state, { type: "filters", patch: { source: "standalone", caseId: "invalid" } });
  assert.equal(state.views.进行中.filters.caseId, "");
  assert.equal(state.views.待接受.filters.caseId, "c");
});

test("responsibility totals are fixed while relation choices stay state-local", () => {
  const rows = [row("pending", "待接受"), row("active", "进行中"), row("done", "已完成"), row("outgoing", "进行中", { owner: "李娜", creator: "张伟" }), row("joined", "已完成", { owner: "李娜", participants: ["张伟"] }), row("old", "待接受", { convertedCaseId: "c" }), row("rejected", "已拒绝")];
  let state = create();
  const first = select(rows, state, "张伟");
  assert.deepEqual(plain(first.counts), { 待接受: 1, 进行中: 1, 已完成: 1 });
  assert.deepEqual(plain(first.selection.scopeCounts), { mine: 1, assigned: 0, participating: 0 });
  state = update(state, { type: "filters", patch: { source: "case" } });
  const narrowed = select(rows, state, "张伟");
  assert.deepEqual(plain(narrowed.counts), { 待接受: 1, 进行中: 1, 已完成: 1 });
  assert.equal(narrowed.selection.taskCount, 0);
  state = update(state, { type: "status", status: "进行中" });
  state = update(state, { type: "filters", patch: { scope: "assigned" } });
  const active = select(rows, state, "张伟");
  assert.deepEqual(plain(active.selection.rows.map(r => r.id)), ["outgoing"]);
  assert.deepEqual(plain(active.selection.scopeCounts), { mine: 1, assigned: 1, participating: 0 });
  assert.deepEqual(plain(statusViewRows(rows, "待接受").map(r => r.id)), ["pending"]);
  assert.equal(select([], state, "张伟").selection.taskCount, 0);
  assert.equal(state.status, "进行中");
});

test("overview role totals equal their linked status-card sums for mine and assigned scopes", () => {
  const rows = statuses.flatMap(status => [
    row(`mine-${status}`, status),
    row(`mine-case-${status}`, status, { source: "case", caseItem: { id: "c" } }),
    row(`assigned-${status}`, status, { owner: "李娜", creator: "张伟" }),
    row(`joined-${status}`, status, { owner: "王强", participants: ["张伟"] }),
  ]).concat([row("rejected", "已拒绝"), row("converted", "待接受", { convertedCaseId: "c" })]);
  const state = create();
  for (const [scope, expectedCounts, expectedRows] of [
    ["mine", { 待接受: 2, 进行中: 2, 已完成: 2 }, ["mine-case-待接受", "mine-待接受"]],
    ["assigned", { 待接受: 1, 进行中: 1, 已完成: 1 }, ["assigned-待接受"]],
  ]) {
    const selected = overview(rows, state, scope, "张伟");
    assert.deepEqual(plain(selected.counts), expectedCounts);
    assert.deepEqual(plain(selected.scopeCounts), { mine: 6, assigned: 3, participating: 3 });
    assert.equal(selected.scopeCounts[scope], Object.values(selected.counts).reduce((sum, count) => sum + count, 0));
    assert.deepEqual(plain([...selected.caseRows, ...selected.standaloneRows].map(item => item.id).sort()), expectedRows.sort());
  }
});

test("all auxiliary filters and view preferences cannot change my responsibility totals", () => {
  const rows = statuses.flatMap(status => [row(`self-${status}`, status), row(`case-${status}`, status, { source: "case", caseItem: { id: "c" }, business: [{ key: "产品:p", kind: "产品", name: "产品" }] }), row(`outgoing-${status}`, status, { owner: "李娜", creator: "张伟", participants: ["张伟"] })]);
  const before = JSON.stringify(rows);
  let state = create();
  const expected = { 待接受: 2, 进行中: 2, 已完成: 2 };
  for (const status of statuses) {
    state = update(state, { type: "status", status });
    for (const patch of [{ source: "standalone" }, { source: "case", caseId: "c" }, { source: "all", caseId: "missing" }, { businessKind: "产品", businessKey: "产品:p" }, { businessKind: "none", businessKey: "" }, { creator: "missing" }, { scope: "assigned" }, { scope: "participating" }]) {
      state = update(state, { type: "filters", patch });
      assert.deepEqual(plain(select(rows, state, "张伟").counts), expected);
    }
    state = update(state, { type: "group", groupBy: "case" });
    state = update(state, { type: "page", page: 2 });
    state = update(state, { type: "business" });
    assert.deepEqual(plain(select(rows, state, "张伟").counts), expected);
    state = update(state, { type: "reset" });
    assert.deepEqual(plain(select(rows, state, "张伟").counts), expected);
    assert.equal(state.views[status].filters.scope, "participating");
    assert.equal(select(rows, state, "张伟").selection.taskCount, 1);
  }
  assert.equal(JSON.stringify(rows), before);
});

test("responsibility totals follow actual task status and owner changes, never historical sources", () => {
  let rows = [row("work", "待接受"), row("other", "进行中", { owner: "李娜", creator: "张伟" }), row("old", "待接受", { convertedCaseId: "c" }), row("rejected", "已拒绝"), row("stopped", "已中止")];
  const state = update(create(), { type: "filters", patch: { scope: "assigned", source: "case" } });
  assert.deepEqual(plain(select(rows, state, "张伟").counts), { 待接受: 1, 进行中: 0, 已完成: 0 });
  rows = rows.map(r => r.id === "work" ? { ...r, status: "进行中" } : r);
  assert.deepEqual(plain(select(rows, state, "张伟").counts), { 待接受: 0, 进行中: 1, 已完成: 0 });
  rows = rows.map(r => r.id === "work" ? { ...r, status: "已完成" } : r);
  assert.deepEqual(plain(select(rows, state, "张伟").counts), { 待接受: 0, 进行中: 0, 已完成: 1 });
  rows = rows.map(r => r.id === "work" ? { ...r, owner: "李娜" } : r);
  assert.deepEqual(plain(select(rows, state, "张伟").counts), { 待接受: 0, 进行中: 0, 已完成: 0 });
  assert.deepEqual(plain(select([], state, "张伟").counts), { 待接受: 0, 进行中: 0, 已完成: 0 });
});

test("sort defaults are status-local and changing sort resets only its page while switching restores saved views", () => {
  const initial = create(); const separate = create(); const before = JSON.stringify(initial);
  const defaults = { 待接受: "priority", 进行中: "due", 已完成: "updated" };
  const choices = { 待接受: "due", 进行中: "updated", 已完成: "priority" };
  assert.equal(initial.status, "待接受");
  for (const status of statuses) {
    assert.equal(initial.views[status].sortBy, defaults[status]);
    assert.equal(initial.views[status].filters.status, status);
    assert.equal(initial.views[status].page, 1); assert.equal(initial.views[status].groupBy, "none");
    assert.notEqual(initial.views[status], separate.views[status]);
    assert.notEqual(initial.views[status].filters, separate.views[status].filters);
    for (const other of statuses.filter(s => s !== status)) {
      assert.notEqual(initial.views[status], initial.views[other]);
      assert.notEqual(initial.views[status].filters, initial.views[other].filters);
    }
  }
  let state = initial; const saved = {};
  for (const [i, status] of statuses.entries()) {
    const previousViews = state.views;
    state = update(state, { type: "status", status });
    assert.equal(state.views, previousViews);
    state = update(state, { type: "filters", patch: { scope: "assigned", creator: `creator-${i}` } });
    state = update(state, { type: "group", groupBy: "owner" });
    state = update(state, { type: "business" });
    state = update(state, { type: "page", page: 4 });
    const previous = state; const previousSnapshot = JSON.stringify(previous);
    state = update(state, { type: "sort", sortBy: choices[status] });
    assert.deepEqual(plain(state.views[status]), { ...plain(previous.views[status]), sortBy: choices[status], page: 1 });
    assert.equal(state.status, status); assert.equal(state.views[status].filters, previous.views[status].filters);
    for (const other of statuses.filter(s => s !== status)) assert.equal(state.views[other], previous.views[other]);
    assert.equal(JSON.stringify(previous), previousSnapshot);
    state = update(state, { type: "page", page: i + 2 });
    saved[status] = state.views[status];
  }
  for (const status of ["待接受", "已完成", "进行中", "待接受"]) {
    state = update(state, { type: "status", status });
    for (const other of statuses) assert.equal(state.views[other], saved[other]);
    assert.equal(state.views[status].sortBy, choices[status]);
    assert.equal(update(state, { type: "status", status }), state);
  }
  assert.equal(JSON.stringify(initial), before); assert.equal(JSON.stringify(separate), before);
});

test("reset restores each status sort default while preserving its role, status and other saved views", () => {
  const initial = create();
  const defaults = { 待接受: "priority", 进行中: "due", 已完成: "updated" };
  let configured = initial;
  for (const [i, status] of statuses.entries()) {
    configured = update(configured, { type: "status", status });
    configured = update(configured, { type: "filters", patch: { scope: i === 1 ? "assigned" : "participating", source: "case", caseId: `c${i}`, creator: "李娜", businessKind: "产品", businessKey: "产品:p1" } });
    configured = update(configured, { type: "sort", sortBy: defaults[status] === "updated" ? "priority" : "updated" });
    configured = update(configured, { type: "group", groupBy: "business" });
    configured = update(configured, { type: "business" });
    configured = update(configured, { type: "page", page: i + 3 });
  }
  const before = JSON.stringify(configured);
  for (const status of statuses) {
    const previous = update(configured, { type: "status", status });
    const state = update(previous, { type: "reset" });
    assert.equal(state.status, status);
    assert.equal(state.views[status].sortBy, defaults[status]);
    assert.equal(state.views[status].groupBy, "none"); assert.equal(state.views[status].page, 1);
    assert.equal(state.views[status].showBusiness, previous.views[status].showBusiness);
    assert.deepEqual(plain(state.views[status].filters), { ...plain(initial.views[status].filters), source: previous.views[status].filters.source, scope: previous.views[status].filters.scope });
    for (const other of statuses.filter(s => s !== status)) assert.equal(state.views[other], previous.views[other]);
    const restored = update(update(state, { type: "status", status: statuses.find(s => s !== status) }), { type: "status", status });
    assert.equal(restored.views[status], state.views[status]);
  }
  assert.equal(JSON.stringify(configured), before);
});

test("all sort choices leave responsibility totals, relation counts and selected row references unchanged", () => {
  const rows = Object.freeze(statuses.flatMap(status => [
    row(`self-${status}`, status),
    row(`case-${status}`, status, { source: "case", caseItem: { id: "c" }, business: [{ key: "产品:p", kind: "产品", name: "产品" }] }),
    row(`assigned-${status}`, status, { owner: "李娜", creator: "张伟" }),
    row(`joined-${status}`, status, { owner: "王强", participants: ["张伟"] }),
    row(`upgraded-${status}`, status, { convertedCaseId: "c" }),
  ]).map(Object.freeze));
  const before = JSON.stringify(rows);
  let state = create();
  for (const status of statuses) {
    state = update(state, { type: "status", status });
    for (const scope of ["mine", "assigned", "participating"]) {
      state = update(state, { type: "filters", patch: { scope } });
      const baseline = select(rows, state, "张伟");
      assert.deepEqual(plain(baseline.counts), { 待接受: 2, 进行中: 2, 已完成: 2 });
      assert.deepEqual(plain(baseline.selection.scopeCounts), { mine: 2, assigned: 1, participating: 1 });
      assert.equal(baseline.selection.taskCount, scope === "mine" ? 2 : 1);
      for (const sortBy of ["priority", "due", "updated"]) {
        state = update(state, { type: "group", groupBy: "case" });
        state = update(state, { type: "page", page: 3 });
        state = update(state, { type: "sort", sortBy });
        assert.equal(state.views[status].sortBy, sortBy); assert.equal(state.views[status].page, 1);
        const selected = select(rows, state, "张伟");
        assert.deepEqual(plain(selected), plain(baseline));
        selected.selection.rows.forEach((r, i) => {
          assert.equal(r, baseline.selection.rows[i]);
          assert.equal(r, rows.find(original => original.key === r.key));
        });
      }
    }
  }
  assert.equal(JSON.stringify(rows), before);
});

test("source tabs navigate without becoming resettable filters or changing other primary states", () => {
  const initial = create();
  let state = update(initial, { type: "filters", patch: { caseId: "c1", creator: "李娜", scope: "assigned" } });
  assert.equal(state.views.待接受.filters.caseId, "");
  state = update(state, { type: "page", page: 3 });
  state = update(state, { type: "source", source: "case" });
  assert.equal(state.views.待接受.filters.caseId, "");
  state = update(state, { type: "filters", patch: { caseId: "c1" } });
  assert.equal(state.views.待接受.filters.caseId, "c1");
  assert.equal(state.views.待接受.filters.creator, "李娜");
  assert.equal(state.views.待接受.page, 1);
  state = update(state, { type: "page", page: 2 });
  assert.equal(update(state, { type: "source", source: "case" }), state);
  state = update(state, { type: "source", source: "standalone" });
  assert.equal(state.views.待接受.filters.caseId, "");
  assert.equal(state.views.待接受.filters.creator, "李娜");
  assert.equal(state.views.待接受.filters.scope, "assigned");
  assert.equal(state.views.待接受.page, 1);
  const saved = state.views.待接受;
  state = update(state, { type: "status", status: "进行中" });
  assert.equal(state.views.进行中.filters.source, "all");
  state = update(state, { type: "source", source: "case" });
  state = update(state, { type: "reset" });
  assert.equal(state.views.进行中.filters.source, "case");
  state = update(state, { type: "status", status: "待接受" });
  assert.equal(state.views.待接受, saved);
  assert.equal(state.views.已完成, initial.views.已完成);
});

test("reset keeps each source tab and its task scope while clearing only view settings", () => {
  const defaults = create();
  for (const status of statuses) {
    const rows = [row("independent", status), row("case", status, { source: "case", caseItem: { id: "c" } })];
    const original = JSON.stringify(rows);
    for (const source of ["all", "standalone", "case"]) {
      let state = update(create(), { type: "status", status });
      state = update(state, { type: "source", source });
      state = update(state, { type: "filters", patch: { creator: "missing" } });
      state = update(state, { type: "sort", sortBy: "updated" });
      state = update(state, { type: "group", groupBy: "owner" });
      state = update(state, { type: "business" });
      state = update(state, { type: "page", page: 3 });
      assert.equal(select(rows, state, "张伟").selection.taskCount, 0);
      const before = state;
      state = update(state, { type: "reset" });
      assert.equal(state.status, status);
      assert.equal(state.views[status].filters.source, source);
      assert.equal(state.views[status].filters.scope, "mine");
      assert.equal(state.views[status].filters.creator, "");
      assert.equal(state.views[status].sortBy, defaults.views[status].sortBy);
      assert.equal(state.views[status].groupBy, "none");
      assert.equal(state.views[status].page, 1);
      assert.equal(state.views[status].showBusiness, true);
      for (const other of statuses.filter(s => s !== status)) assert.equal(state.views[other], before.views[other]);
      const selected = select(rows, state, "张伟");
      assert.equal(selected.selection.taskCount, source === "all" ? 2 : 1);
      assert.ok(selected.selection.rows.every(r => source === "all" || r.source === source));
      assert.deepEqual(plain(selected.counts), plain(select(rows, create(), "张伟").counts));
    }
    assert.equal(JSON.stringify(rows), original);
  }
});