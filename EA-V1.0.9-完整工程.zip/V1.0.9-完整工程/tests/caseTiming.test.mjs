import test from 'node:test';
import assert from 'node:assert/strict';
import { build } from 'esbuild';
import vm from 'node:vm';
import { webcrypto } from 'node:crypto';
import { fileURLToPath } from 'node:url';

const {outputFiles}=await build({stdin:{contents:"export * from './caseTiming';export * from './closures';export * from './caseTaskTrees';export {createManualCase} from './domainStore';export {currentUser,mockCases} from './data';",resolveDir:fileURLToPath(new URL('../src/app/components/',import.meta.url))},bundle:true,write:false,platform:'node',format:'cjs',plugins:[{name:'hooks',setup(builder){builder.onResolve({filter:/^react$/},()=>({path:'react',namespace:'stub'}));builder.onLoad({filter:/.*/,namespace:'stub'},()=>({contents:'export const useEffect=()=>{};export const useState=()=>[0,()=>{}];'}));}}]});
function setup(storage=new Map()){const box={module:{exports:{}},crypto:webcrypto,btoa,atob,localStorage:{getItem:key=>storage.get(key)??null,setItem:(key,value)=>storage.set(key,value)}};vm.runInNewContext(outputFiles[0].text,box);return box.module.exports;}
test('task creation time only uses explicit creation or create events, never Case/update/status timestamps',()=>{
  const api=setup();const task={createdAt:'bad',activityLog:[{kind:'edit',at:'2026-09-01'},{kind:'create',at:'2026-09-04'},{kind:'create',at:'2026-09-03'}]};const before=JSON.stringify(task);
  assert.equal(api.taskCreationTime(task),'2026-09-03');assert.equal(api.taskCreationTime({...task,createdAt:'2026-09-02'}),'2026-09-02');assert.equal(api.taskCreationTime({updatedAt:'2026-09-01',statusHistory:[{at:'2026-09-01'}]}),undefined);assert.equal(api.formatCaseTime(), '未记录');assert.equal(JSON.stringify(task),before);
});
test('new nested Case tasks get immutable creation times and legacy missing times stay unknown',()=>{
  const storage=new Map();const api=setup(storage);const item={...api.mockCases[0],id:'timing-case',owner:'张伟',status:'进行中',tasks:[{id:'old',code:'OLD',owner:'张伟',status:'进行中',title:'旧任务'}]};api.mockCases.push(item);
  const saved=api.saveCaseTaskTree(item.id,[...item.tasks,{id:'thought',children:[{id:'new',code:'NEW',owner:'张伟',title:'新任务',status:'进行中'}]}],true);
  assert.equal(saved[0].createdAt,undefined);const createdAt=saved[1].children[0].createdAt;assert.ok(createdAt);api.updateCaseTask(item.id,'new',{createdAt:'2000-01-01',conclusion:'新结论'});assert.equal(api.loadCaseTaskTree(item.id,[])[1].children[0].createdAt,createdAt);
  const manual=api.createManualCase({name:'创建时间验收',owner:'张伟',level:'L3',urgency:'一般',reason:'验证',background:'背景',tasks:[{id:'draft',code:'DRAFT',owner:'张伟',title:'新任务',status:'待接受'}]});assert.ok(manual.tasks[0].createdAt);
});
test('verification starts on root cause, ends only on actual closure, and resets on return preserving prior snapshot',()=>{
  const api=setup();const item={...api.mockCases[0],id:'verify-case',owner:'张伟',level:'L3',status:'进行中',tasks:[]};api.mockCases.push(item);
  api.submitRootCause({caseId:item.id,domain:'Testing',problemType:'Others',krByProduct:{},by:'张伟'});const start=api.getClosure(item.id).verificationStartedAt;assert.ok(start);assert.equal(api.caseVerificationTimes(api.getClosure(item.id)).end,undefined);
  api.submitRootCause({caseId:item.id,domain:'Testing',problemType:'Others',krByProduct:{},by:'张伟'});assert.equal(api.getClosure(item.id).verificationStartedAt,start);
  api.submitClosure({caseId:item.id,conclusion:'验证结束',submittedBy:'张伟'});const end=api.getClosure(item.id).verificationEndedAt;assert.ok(end);
  api.currentUser.name='高总监';api.recoverCase(item.id,'return','补充验证');const reopened=api.getClosure(item.id);assert.equal(api.caseVerificationTimes(reopened).start,undefined);assert.equal(api.caseVerificationTimes(reopened).end,undefined);assert.equal(reopened.recovery[0].before.verificationStartedAt,start);assert.equal(reopened.recovery[0].before.verificationEndedAt,end);
});
test('legacy verification timestamps do not leak from an earlier return cycle or pending approval',()=>{
  const api=setup();assert.equal(api.caseVerificationTimes({state:'closed',rootCauseAt:'2026-09-01',closedAt:'2026-09-02'}).start,'2026-09-01');assert.equal(api.caseVerificationTimes({state:'closed',closedAt:'2026-09-02'}).start,undefined);
  const record={state:'reopened',rootCauseAt:'2026-09-01',closedAt:'2026-09-02',recovery:[{kind:'return',at:'2026-09-03'}]};assert.equal(api.caseVerificationTimes(record).start,undefined);assert.equal(api.caseVerificationTimes(record).end,undefined);
});
test('reviewed verification only ends at approval, and failed writes do not commit timestamps',()=>{
  const storage=new Map([['ea_case_closures_v4',JSON.stringify({'reviewed-timing':{caseId:'reviewed-timing',state:'closed',approvedBy:'高总监',rootCauseAt:'2026-09-01',closedAt:'2026-09-02'}})]]);const api=setup(storage);
  api.mockCases.push({...api.mockCases[0],id:'reviewed-timing',owner:'张伟',status:'已关闭',tasks:[]});api.currentUser.name='高总监';api.recoverCase('reviewed-timing','return','补充');api.currentUser.name='张伟';
  api.submitRootCause({caseId:'reviewed-timing',domain:'Testing',problemType:'Others',krByProduct:{},by:'张伟'});const start=api.caseVerificationTimes(api.getClosure('reviewed-timing')).start;
  api.submitClosure({caseId:'reviewed-timing',conclusion:'复核结果',submittedBy:'张伟'});assert.equal(api.caseVerificationTimes(api.getClosure('reviewed-timing')).end,undefined);
  api.currentUser.name='高总监';const request=api.getClosure('reviewed-timing').approval.id;api.decideCaseRecovery('reviewed-timing',request,true,'通过');assert.equal(api.caseVerificationTimes(api.getClosure('reviewed-timing')).start,start);assert.ok(api.caseVerificationTimes(api.getClosure('reviewed-timing')).end);
  const failed=setup({get:()=>null,set:()=>{throw Error('quota');}});failed.mockCases.push({...failed.mockCases[0],id:'failed-timing',owner:'张伟',status:'进行中',tasks:[]});assert.throws(()=>failed.submitRootCause({caseId:'failed-timing',domain:'Testing',problemType:'Others',krByProduct:{},by:'张伟'}),/保存失败/);assert.equal(failed.getClosure('failed-timing'),undefined);
});