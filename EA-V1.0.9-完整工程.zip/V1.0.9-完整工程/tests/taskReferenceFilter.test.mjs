import assert from "node:assert/strict";
import test from "node:test";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";
import vm from "node:vm";
import { build } from "esbuild";
import { createElement, Fragment, isValidElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";

const { outputFiles } = await build({
  entryPoints: [fileURLToPath(new URL("../src/app/components/TaskReferenceFilter.tsx", import.meta.url))],
  bundle: true, write: false, platform: "node", format: "cjs", jsx: "automatic",
  packages: "external", external: ["./data"],
});
const sandbox = { module: { exports: {} }, require: createRequire(import.meta.url) };
vm.runInNewContext(outputFiles[0].text, sandbox);
const { TaskReferenceFilter, taskReferenceOptions } = sandbox.module.exports;
const plain = value => JSON.parse(JSON.stringify(value));
function freeze(value) {
  if (value && typeof value === "object" && !Object.isFrozen(value)) {
    Object.values(value).forEach(freeze); Object.freeze(value);
  }
  return value;
}
function elements(tree) {
  if (Array.isArray(tree)) return tree.flatMap(elements);
  if (!isValidElement(tree)) return [];
  return [tree, ...elements(tree.props.children)];
}
const kinds = ["产品", "TF", "Project"];
const options = freeze([
  { key: "产品:p1", kind: "产品", name: "DDR5-X-6400 · DDR5 X-die 6400", origin: "case" },
  { key: "TF:t1", kind: "TF", name: "DDR5 Yield Recovery", origin: "task" },
  { key: "Project:name:同名项目", kind: "Project", name: "同名项目", origin: "case", nameOnly: true },
  { key: "Project:id:1", kind: "Project", name: "同名项目", origin: "task" },
]);
const props = { kind: "产品", value: "", options, onChange() {} };
const stripTags = html => html.replace(/<[^>]*>/g, "");
const render = patch => renderToStaticMarkup(createElement(TaskReferenceFilter, { ...props, ...patch }));
const keys = rows => plain(rows.map(ref => ref.key));
// Capture the element tree inside a real React render, never invoke a hook
// component outside React. Render portal content separately for SSR assertions.
function capture(patch) {
  let tree;
  function Probe() { tree = TaskReferenceFilter({ ...props, ...patch }); return tree; }
  const html = renderToStaticMarkup(createElement(Probe));
  const kind = patch?.kind ?? props.kind;
  const content = elements(tree).find(element => element.props["aria-label"] === `选择${kind}`);
  assert.ok(content);
  return { tree, html, content, command: content.props.children,
    popupHtml: renderToStaticMarkup(createElement(Fragment, null, content.props.children)),
  };
}

test("fixed reference fields render one named button with default 全部 and no type selector or none option", () => {
  const calls = []; const before = JSON.stringify(options);
  for (const kind of kinds) {
    const html = render({ kind, onChange: key => calls.push(key) });
    assert.equal((html.match(/<button\b/g) ?? []).length, 1);
    assert.ok(html.includes(`aria-label="${kind}筛选"`));
    assert.ok(html.includes(`title="全部${kind}"`));
    assert.equal(stripTags(html), `${kind}全部`);
    assert.match(html, /type="button"/); assert.match(html, /aria-haspopup="dialog"/);
    assert.match(html, /h-8 min-w-0/); assert.match(html, /border-slate-200 bg-white/);
    assert.doesNotMatch(html, /<select\b|<option\b|<optgroup\b|任务涉及|具体涉及对象|无涉及|disabled=""/);
    for (const ref of options) assert.ok(!html.includes(ref.name));
  }
  assert.deepEqual(calls, []); assert.equal(JSON.stringify(options), before);
});

test("selected products show only their short code while full titles, candidates and search retain the complete name", () => {
  const before = JSON.stringify(options);
  const { html, popupHtml } = capture({ value: "产品:p1" });
  assert.equal(stripTags(html), "产品DDR5-X-6400");
  assert.match(html, /title="DDR5-X-6400 · DDR5 X-die 6400"/);
  assert.match(html, /font-medium text-\[#0052D9\]/);
  assert.match(html, /border-\[#0052D9\]\/40 bg-\[#0052D9\]\/5/);
  assert.match(popupHtml, /DDR5-X-6400 · DDR5 X-die 6400/);
  assert.deepEqual(keys(taskReferenceOptions(options, "产品", "x-die 6400")), ["产品:p1"]);
  const undelimited = freeze([{ key: "产品:legacy", kind: "产品", name: "旧产品完整名称", origin: "task" }]);
  const legacyHtml = render({ value: "产品:legacy", options: undelimited });
  assert.equal(stripTags(legacyHtml), "产品旧产品完整名称");
  assert.match(legacyHtml, /title="旧产品完整名称"/);
  assert.equal(JSON.stringify(options), before);
});

test("stale saved values stay visible and clearable without borrowing a same-key reference from another kind", () => {
  const calls = [];
  for (const kind of kinds) {
    const list = freeze([{ key: "saved-exact-key", kind: kind === "TF" ? "产品" : "TF", name: "不得借用的名称", origin: "task" }]);
    const before = JSON.stringify(list);
    const { html, command } = capture({ kind, value: "saved-exact-key", options: list, onChange: key => calls.push([kind, key]) });
    assert.equal(stripTags(html), `${kind}已选对象`);
    assert.match(html, /title="已选对象（当前范围无任务）"/);
    assert.doesNotMatch(html, /不得借用的名称|disabled=""/);
    const all = elements(command).find(element => element.props.value === "all-references" && element.props.onSelect);
    assert.ok(all); all.props.onSelect();
    assert.deepEqual(calls.at(-1), [kind, ""]);
    assert.equal(JSON.stringify(list), before);
  }
  assert.equal(calls.length, 3);
});

test("same-name Project IDs and name-only references remain distinct in selected text, titles and exact candidate identities", () => {
  for (const [value, text] of [["Project:name:同名项目", "同名项目（名称记录）"], ["Project:id:1", "同名项目"]]) {
    const { html, command, popupHtml } = capture({ kind: "Project", value });
    assert.equal(stripTags(html), `Project${text}`);
    assert.ok(html.includes(`title="${text}"`));
    const candidates = elements(command).filter(element => element.props.onSelect && element.props.value !== "all-references");
    assert.deepEqual(plain(candidates.map(element => [element.key, element.props.value, element.props.title])), [
      ["Project:name:同名项目", "Project:name:同名项目", "同名项目（名称记录）"],
      ["Project:id:1", "Project:id:1", "同名项目"],
    ]);
    assert.match(popupHtml, /同名项目（名称记录）/);
    for (const candidate of candidates) {
      const check = elements(candidate).find(element => ["opacity-100", "opacity-0"].includes(element.props.className));
      assert.ok(check); assert.equal(check.props.className, candidate.props.value === value ? "opacity-100" : "opacity-0");
    }
  }
});

test("taskReferenceOptions is kind-scoped, case-insensitive multiword AND search over full labels without matching hidden keys", () => {
  const list = freeze([...options,
    { key: "产品:private-id", kind: "产品", name: "DDR5-Y-4800 · DDR5 Y-die 4800", origin: "task" },
    { key: "Project:ddr5", kind: "Project", name: "DDR5 Yield Recovery", origin: "task" },
  ]);
  const before = JSON.stringify(list);
  for (const [kind, query, expected] of [
    ["产品", "  DDR5\t6400\nX-DIE  ", ["产品:p1"]],
    ["产品", "4800 ddr5", ["产品:private-id"]],
    ["产品", "ddr5 recovery", []],
    ["TF", " recovery\tDDR5 ", ["TF:t1"]],
    ["Project", "DDR5 recovery", ["Project:ddr5"]],
    ["Project", "同名", ["Project:name:同名项目", "Project:id:1"]],
    ["Project", "同名 名称记录", ["Project:name:同名项目"]],
    ["产品", "private-id", []], ["TF", "产品", []], ["产品", "not-found", []],
  ]) {
    const result = taskReferenceOptions(list, kind, query);
    assert.deepEqual(keys(result), expected);
    for (const ref of result) assert.equal(ref, list.find(item => item.key === ref.key));
  }
  for (const kind of kinds) for (const query of [undefined, "", "  \t\n "]) {
    const result = taskReferenceOptions(list, kind, query);
    assert.deepEqual(keys(result), list.filter(ref => ref.kind === kind).map(ref => ref.key));
    assert.notEqual(result, list);
  }
  assert.deepEqual(plain(taskReferenceOptions([], "产品", "anything")), []);
  assert.equal(JSON.stringify(list), before);
});

test("500 references per kind remain fully searchable in stable input order without truncation or catalog mutation", () => {
  const list = freeze(Array.from({ length: 500 }, (_, i) => kinds.map(kind => ({ key: `${kind}:item-${i}`, kind, name: `Model REV ${String(i).padStart(3, "0")} · 完整名称`, origin: i % 2 ? "case" : "task" }))).flat().reverse());
  const before = JSON.stringify(list);
  for (const kind of kinds) {
    const result = taskReferenceOptions(list, kind);
    assert.equal(result.length, 500);
    assert.deepEqual(keys(result), list.filter(ref => ref.kind === kind).map(ref => ref.key));
    assert.deepEqual(keys(taskReferenceOptions(list, kind, " model\t499 REV ")), [`${kind}:item-499`]);
    assert.deepEqual(keys(taskReferenceOptions(list, kind, "完整名称 rev 000")), [`${kind}:item-0`]);
    assert.equal(taskReferenceOptions(list, kind, "rev 500").length, 0);
    for (const ref of result) assert.equal(ref, list.find(item => item.key === ref.key));
    const html = render({ kind, options: list });
    assert.doesNotMatch(html, /<select\b|<option\b|Model REV/);
    assert.equal((html.match(/<button\b/g) ?? []).length, 1);
  }
  assert.equal(JSON.stringify(list), before);
});

test("reference popup exposes only its own candidates plus 全部 with accessible search and bounded scrolling", () => {
  for (const kind of kinds) {
    const { content, command, popupHtml } = capture({ kind });
    assert.equal(content.props.align, "start");
    assert.match(content.props.className, /w-\[300px\]/);
    assert.equal(command.props.label, `搜索${kind}`);
    assert.equal(command.props.shouldFilter, false);
    assert.equal(command.props.defaultValue, "all-references");
    const input = elements(command).find(element => element.props.placeholder === "搜索");
    assert.ok(input); assert.equal(input.props.value, ""); assert.equal(typeof input.props.onValueChange, "function");
    const list = elements(command).find(element => element.props.label === `${kind}候选`);
    assert.ok(list); assert.equal(list.props.className, "max-h-60");
    const candidates = elements(command).filter(element => element.props.onSelect);
    assert.deepEqual(plain(candidates.map(element => element.props.value)), ["all-references", ...options.filter(ref => ref.kind === kind).map(ref => ref.key)]);
    assert.match(popupHtml, /role="combobox"/); assert.match(popupHtml, /role="listbox"/);
    assert.ok(popupHtml.includes(`aria-label="${kind}候选"`));
    assert.match(stripTags(popupHtml), /全部/);
    assert.doesNotMatch(popupHtml, /<select\b|<optgroup\b|任务涉及类型|具体涉及对象|无涉及/);
    for (const ref of options.filter(ref => ref.kind !== kind)) assert.ok(!popupHtml.includes(ref.key));
  }
});

test("candidate and clear callbacks emit only exact keys, while rendering and opening never commit or mutate references", () => {
  const before = JSON.stringify(options);
  for (const kind of kinds) {
    const calls = [];
    const { tree, command } = capture({ kind, onChange: key => calls.push(key) });
    assert.deepEqual(calls, []);
    tree.props.onOpenChange(true); tree.props.onOpenChange(false);
    assert.deepEqual(calls, []);
    const candidates = elements(command).filter(element => element.props.onSelect);
    for (const candidate of candidates.filter(element => element.props.value !== "all-references")) {
      candidate.props.onSelect();
      assert.equal(calls.at(-1), candidate.props.value);
      assert.ok(options.some(ref => ref.kind === kind && ref.key === calls.at(-1)));
    }
    candidates.find(element => element.props.value === "all-references").props.onSelect();
    assert.deepEqual(calls, [...options.filter(ref => ref.kind === kind).map(ref => ref.key), ""]);
    assert.ok(calls.every(value => typeof value === "string"));
  }
  assert.equal(JSON.stringify(options), before);
});

test("empty catalogs keep the fixed field enabled with an honest empty message and an explicit clear choice", () => {
  for (const kind of kinds) {
    const calls = [];
    const { html, command, popupHtml } = capture({ kind, options: freeze([]), onChange: key => calls.push(key) });
    assert.equal(stripTags(html), `${kind}全部`);
    assert.doesNotMatch(html, /disabled=""/);
    assert.ok(popupHtml.includes(`暂无可选${kind}`));
    const candidates = elements(command).filter(element => element.props.onSelect);
    assert.equal(candidates.length, 1); assert.equal(candidates[0].props.value, "all-references");
    candidates[0].props.onSelect(); assert.deepEqual(calls, [""]);
    assert.deepEqual(plain(taskReferenceOptions([], kind)), []);
  }
});