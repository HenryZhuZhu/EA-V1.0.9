import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";
import vm from "node:vm";
import { build } from "esbuild";
import { renderToStaticMarkup } from "react-dom/server";

const require = createRequire(import.meta.url);
const React = require("react");
const jsxRuntime = require("react/jsx-runtime");
const directory = new URL("../src/app/components/", import.meta.url);
const readSource = name => readFileSync(new URL(name, directory), "utf8");
const editorSource = readSource("CaseCustomFilterEditor.tsx");
const listSource = readSource("CaseList.tsx");
const fieldSource = readSource("CaseFilterFields.tsx");
const panelSource = readSource("CaseFilterPanel.tsx");
const capturedSources = {
  CaseList: listSource,
  CaseFilterPanel: panelSource,
  CaseCustomFilterEditor: editorSource,
  CustomRuleRow: editorSource,
  RuleValuePicker: editorSource,
  OpenValueChoices: editorSource,
  CaseFilterFields: fieldSource,
};

// Bound state slots to actual declarations, not magic indices. Only these seven
// component boundaries are captured; package hooks (React/Radix/cmdk) stay real.
function functionSource(source, name) {
  const start = new RegExp(`^(?:export )?function ${name}\\(`, "m").exec(source);
  assert.ok(start, `Missing component/function ${name}`);
  const rest = source.slice(start.index + start[0].length);
  const end = /^(?:export )?function \w+\(/m.exec(rest);
  return start[0] + (end ? rest.slice(0, end.index) : rest);
}
const stateNames = Object.fromEntries(Object.entries(capturedSources).map(([name, source]) => [name,
  Array.from(functionSource(source, name).matchAll(/^\s*const\s+\[\s*(\w+)[^\]\n]*\]\s*=\s*useState\b/gm), match => match[1]),
]));
const { outputFiles } = await build({
  stdin: {
    contents: `export { CaseList } from './CaseList';
      export { CaseCustomFilterEditor } from './CaseCustomFilterEditor';
      export { CaseFilterFields } from './CaseFilterFields';
      export * from './caseCustomFilters';
      export { CASE_CUSTOM_FIELDS } from './caseCustomFilterFields';`,
    resolveDir: fileURLToPath(directory), loader: "ts",
    sourcefile: "case-custom-filter-presentation-entry.ts",
  },
  bundle: true, write: false, platform: "node", format: "cjs", jsx: "automatic",
  keepNames: true, packages: "external",
  external: ["./data", "./subscriptions", "./closures", "./caseTaskTrees",
    "./CategoryTimeline", "./IssueHub", "./ProductCenter", "./ProductAnalysisRestored"],
});
const plain = value => JSON.parse(JSON.stringify(value));
function freeze(value) {
  if (value && typeof value === "object" && !Object.isFrozen(value)) {
    Object.values(value).forEach(freeze); Object.freeze(value);
  }
  return value;
}
function elements(tree) {
  if (Array.isArray(tree)) return Array.from(tree).flatMap(elements);
  return React.isValidElement(tree) ? [tree, ...elements(tree.props.children)] : [];
}
function text(tree) {
  if (Array.isArray(tree)) return Array.from(tree).map(text).join("");
  if (React.isValidElement(tree)) return text(tree.props.children);
  return typeof tree === "string" || typeof tree === "number" ? String(tree) : "";
}
function one(tree, predicate, description) {
  const matches = elements(tree).filter(predicate);
  assert.equal(matches.length, 1, `Expected exactly one ${description}`);
  return matches[0];
}
const componentName = node => node.type?.original?.name ?? node.type?.name;
const byAria = (tree, label) => one(tree, node => node.props["aria-label"] === label, label);
const button = (tree, label) => one(tree, node => node.type === "button" && text(node).trim() === label, label);
const component = (tree, name) => one(tree, node => componentName(node) === name, name);
const commandItems = tree => elements(tree).filter(node => componentName(node) === "CommandItem");
const actor = freeze({ name: "张伟", department: "PTE" });
const action = (id, patch = {}) => ({
  id, code: `TASK-${id}`, title: `执行 ${id}`, owner: actor.name, department: "PTE",
  urgency: "一般", status: "进行中", progress: 0, dueIn: 9, ...patch,
});
const caseItem = (id, patch = {}) => ({
  id, code: `CASE-${id}`, name: `问题 ${id}`, owner: actor.name, createdBy: "李娜",
  level: "L1", urgency: "一般", status: "进行中", reason: "立案原因", background: "问题背景",
  levelReason: "层级判定", product: "DDR5", material: "Die/IC", density: "16Gb", ioType: "X8",
  failStage: "FT", customer: "测试客户", failPlatform: "测试平台", failMode: "IO", ppm: "10", pdId: "pd-test",
  createdAt: "2026-09-01", updatedAt: "2026-09-10", dueDate: "2026-09-20", dueIn: 10,
  participants: [], departments: ["PTE"], tasks: [], timeline: [],
  aiSummary: { progress: "", method: "", conclusion: "", solution: "", risk: "" }, ...patch,
});
const rule = (fieldId, operator = "in", values = [], id = `rule-${fieldId}`) => ({ id, fieldId, operator, values });

// Read-only data adapters supply raw records/trees, never prefiltered results.
function flattenTasks(nodes, depth = 0, parentPath = []) {
  return nodes.flatMap(task => [{ task, depth, path: parentPath }, ...flattenTasks(task.children ?? [], depth + 1, [...parentPath, task.title])]);
}

function harness({ mode = "editor", rules: initialRules = [], records = [], cases = [], trees = {}, closures = {}, optionsFor, uuid } = {}) {
  freeze(records); freeze(cases); freeze(trees); freeze(closures);
  let rules = plain(initialRules); let api; let activeFrame;
  let snapshots = new Map(); let seen = new Set(); let surfaces = new Map(); let rootHtml;
  const frames = new Map(); const wrappers = new WeakMap();
  const changes = []; const optionReads = []; const treeReads = []; const navigated = [];
  const forbidden = name => () => { throw new Error(`${name} is outside this read-only presentation test`); };
  const depsEqual = (a, b) => a && b && a.length === b.length && a.every((value, i) => Object.is(value, b[i]));

  function wrap(Type, reactKey) {
    if (!Object.hasOwn(capturedSources, Type?.name)) return Type;
    if (!wrappers.has(Type)) wrappers.set(Type, new Map());
    const cache = wrappers.get(Type); const key = String(reactKey ?? "");
    if (cache.has(key)) return cache.get(key);
    function CaptureBoundary(props) {
      const identity = `${Type.name}:${props.rule?.id ?? props.field?.id ?? "root"}:${key}`;
      if (!frames.has(identity)) frames.set(identity, { name: Type.name, state: new Map(), refs: [], memos: [] });
      const frame = frames.get(identity);
      frame.stateCursor = 0; frame.refCursor = 0; frame.memoCursor = 0;
      const previous = activeFrame; activeFrame = frame;
      let tree;
      try { tree = Type(props); } finally { activeFrame = previous; }
      assert.equal(frame.stateCursor, stateNames[Type.name].length, `${Type.name}: update the bounded hook harness`);
      seen.add(identity); snapshots.set(identity, { name: Type.name, props, tree, frame });
      return tree;
    }
    CaptureBoundary.original = Type;
    cache.set(key, CaptureBoundary);
    return CaptureBoundary;
  }
  const controlledReact = {
    ...React,
    useState(initial) {
      if (!activeFrame) return React.useState(initial);
      const frame = activeFrame;
      const name = stateNames[frame.name][frame.stateCursor++];
      assert.ok(name, `Unexpected state hook in ${frame.name}`);
      if (!frame.state.has(name)) frame.state.set(name,
        frame.name === "CaseList" && name === "customRulesDraft" ? rules : typeof initial === "function" ? initial() : initial);
      return [frame.state.get(name), next => frame.state.set(name, typeof next === "function" ? next(frame.state.get(name)) : next)];
    },
    useRef(initial) {
      if (!activeFrame) return React.useRef(initial);
      const index = activeFrame.refCursor++;
      return activeFrame.refs[index] ?? (activeFrame.refs[index] = { current: initial });
    },
    useMemo(factory, deps) {
      if (!activeFrame) return React.useMemo(factory, deps);
      const index = activeFrame.memoCursor++; const old = activeFrame.memos[index];
      if (old && depsEqual(old.deps, deps)) return old.value;
      const value = factory(); activeFrame.memos[index] = { deps, value }; return value;
    },
  };
  const stubs = {
    react: controlledReact,
    "react/jsx-runtime": {
      ...jsxRuntime,
      jsx: (Type, props, key) => jsxRuntime.jsx(wrap(Type, key), props, key),
      jsxs: (Type, props, key) => jsxRuntime.jsxs(wrap(Type, key), props, key),
    },
    "./data": {
      mockCases: cases, currentUser: actor, flattenTasks,
      myTasksInCase: (record, name) => flattenTasks(record.tasks).filter(({ task }) => task.owner === name),
      ownerToDepartment: { 张伟: "PTE", 李娜: "DA" },
      levelColors: { L0: "level-l0", L1: "level-l1", L2: "level-l2", L3: "level-l3" },
      urgencyBar: { 一般: "bg-blue-400", 紧急: "bg-orange-400" },
      caseProductOf: () => undefined, caseMarkCode: record => record.markCode ?? null,
      issueOfCase: () => undefined, issueStatusColors: {},
    },
    "./subscriptions": { useSubscriptions: () => ({ isSubscribed: () => false, toggle: forbidden("subscription write") }) },
    "./closures": { useClosures: () => ({
      get: id => closures[id], isClosed: id => closures[id]?.state === "closed",
      isRootCaused: id => closures[id]?.state === "rootcause",
    }) },
    "./caseTaskTrees": { useCaseTaskRevision: () => 0, loadCaseTaskTree(id, fallback) {
      const value = Object.hasOwn(trees, id) ? trees[id] : fallback;
      treeReads.push({ id, fallback, value }); return value;
    } },
    "./CategoryTimeline": { CategoryTimeline: forbidden("CategoryTimeline"), PRODUCT_STAGES: [], PLATFORM_STAGES: [], platformOf: record => record.failPlatform },
    "./IssueHub": { IssueHub: forbidden("IssueHub") },
    "./ProductCenter": { ProductCenter: forbidden("ProductCenter") },
    "./ProductAnalysisRestored": { ProductAnalysisRestored: forbidden("ProductAnalysis") },
  };
  const sandbox = { module: { exports: {} }, require(name) {
    if (Object.hasOwn(stubs, name)) return stubs[name];
    assert.ok(!name.startsWith(".") && !name.startsWith("/"), `Unexpected application dependency ${name}`);
    return require(name);
  } };
  for (const name of ["localStorage", "sessionStorage"]) Object.defineProperty(sandbox, name, {
    get: forbidden(`${name} access`),
  });
  if (uuid) {
    sandbox.crypto = { randomUUID: uuid };
    sandbox.Date = class extends Date { static now() { return 123456789; } };
  }
  vm.runInNewContext(outputFiles[0].text, sandbox);
  api = sandbox.module.exports;
  const fields = api.customFieldCatalog(records);
  const resolveOptions = field => {
    optionReads.push(field.id);
    return optionsFor ? optionsFor(field) : api.customFilterOptions(records, field);
  };
  function snapshot(name, fieldId) {
    const found = [...snapshots.values()].filter(value => value.name === name &&
      (fieldId === undefined || (value.props.field?.id ?? value.props.rule?.fieldId) === fieldId));
    assert.equal(found.length, 1, `Expected one mounted ${name}${fieldId ? ` for ${fieldId}` : ""}`);
    return found[0];
  }
  function exposePopup(owner, label) {
    const content = byAria(owner.tree, label);
    // Portals do not mount in React SSR. Render only the actual open portal's
    // children in an additional SSR root. No Radix/cmdk/field implementation is
    // replaced, and no closed value picker is walked/mounted speculatively.
    // Callback contracts are covered here, not browser focus, layout or keys.
    surfaces.set(label, renderToStaticMarkup(React.createElement(React.Fragment, null, content.props.children)));
  }
  function render() {
    snapshots = new Map(); seen = new Set(); surfaces = new Map();
    const Type = mode === "list" ? api.CaseList : api.CaseCustomFilterEditor;
    const props = mode === "list" ? { initialView: "list", onOpenCase: id => navigated.push(id) } : {
      fields, rules, optionsFor: resolveOptions,
      onChange(next) { changes.push(plain(next)); rules = next; },
    };
    rootHtml = renderToStaticMarkup(React.createElement(wrap(Type), props));
    if (mode === "list") {
      const list = snapshot("CaseList");
      if (list.frame.state.get("filterOpen")) exposePopup(list, "分析中心 Case 筛选");
    }
    const editor = [...snapshots.values()].find(value => value.name === "CaseCustomFilterEditor");
    if (editor?.frame.state.get("addOpen")) exposePopup(editor, "添加自定义维度");
    for (const picker of [...snapshots.values()].filter(value => value.name === "RuleValuePicker")) {
      if (picker.frame.state.get("open")) {
        const label = elements(picker.tree).find(node => componentName(node) === "PopoverContent").props["aria-label"];
        exposePopup(picker, label);
      }
    }
    // Model component unmounts (including query/cache disposal), not just hides.
    for (const identity of frames.keys()) if (!seen.has(identity)) frames.delete(identity);
    return rootHtml;
  }
  const act = (callback, ...args) => { assert.equal(typeof callback, "function", "Expected a real rendered callback"); callback(...args); render(); };
  const popover = (name, fieldId) => component(snapshot(name, fieldId).tree, "Popover");
  const setOpen = (name, value, fieldId) => act(popover(name, fieldId).props.onOpenChange, value);
  const editorTree = () => snapshot("CaseCustomFilterEditor").tree;
  const fieldItem = id => one(editorTree(), node => componentName(node) === "CommandItem" && node.props.value === id, `field ${id}`);
  const rowTree = id => snapshot("CustomRuleRow", id).tree;
  const valueTree = id => snapshot("OpenValueChoices", id).tree;
  render();
  return {
    api, fields, act, render, snapshot, popover, rowTree, valueTree, fieldItem,
    changes, optionReads, treeReads, navigated,
    get tree() { return snapshot(mode === "list" ? "CaseList" : "CaseCustomFilterEditor").tree; },
    get panelTree() { return snapshot("CaseFilterPanel").tree; },
    get editorTree() { return editorTree(); },
    get rules() { return mode === "list" ? snapshot("CaseList").frame.state.get("customRulesDraft") : rules; },
    get rootHtml() { return rootHtml; },
    get html() { return [rootHtml, ...surfaces.values()].join("\n"); },
    popupHtml: label => { assert.ok(surfaces.has(label), `Popup not open: ${label}`); return surfaces.get(label); },
    openFilters: () => setOpen("CaseList", true),
    openAdd: () => setOpen("CaseCustomFilterEditor", true),
    closeAdd: () => setOpen("CaseCustomFilterEditor", false),
    category: label => act(button(byAria(editorTree(), "维度分类"), label).props.onClick),
    searchFields: value => act(component(editorTree(), "CommandInput").props.onValueChange, value),
    add: id => act(fieldItem(id).props.onSelect, id),
    remove: id => act(one(rowTree(id), node => node.type === "button" && node.props["aria-label"]?.startsWith("删除"), `remove ${id}`).props.onClick),
    openValue: id => setOpen("RuleValuePicker", true, id),
    closeValue: id => setOpen("RuleValuePicker", false, id),
    searchValues: (id, value) => act(component(valueTree(id), "CommandInput").props.onValueChange, value),
    choose: (id, raw) => act(one(valueTree(id), node => componentName(node) === "CommandItem" && node.props.title === raw, `value ${JSON.stringify(raw)}`).props.onSelect, "cmdk-trimmed-internal-value"),
    replaceRules(next) { act(snapshot("CaseCustomFilterEditor").props.onChange, next); },
  };
}

function assertInvalid(h, fieldId, message) {
  const tree = h.rowTree(fieldId);
  assert.match(text(tree), /未生效/);
  const error = one(tree, node => node.type === "p" && node.props["aria-live"] === "polite", "rule validation message");
  assert.equal(text(error), message);
  assert.equal(error.props.className, "sr-only");
  assert.ok(!elements(tree).some(node => node.type === "select" || node.type === "input"));
  if (h.fields.some(field => field.id === fieldId)) {
    const control = one(h.snapshot("RuleValuePicker", fieldId).tree,
      node => node.type === "button" && node.props["aria-label"]?.endsWith("筛选值"), "invalid value picker");
    assert.equal(control.props["aria-invalid"], true);
    assert.equal(control.props["aria-describedby"], error.props.id);
  } else {
    assert.ok(!elements(tree).some(node => componentName(node) === "RuleValuePicker"), "Unavailable fields have no value control");
  }
  assert.equal(h.api.activeCustomRules(h.api.customSelectionRules(h.rules), h.fields).some(value => value.fieldId === fieldId), false);
}
function assertValid(h, fieldId) {
  const tree = h.rowTree(fieldId);
  assert.doesNotMatch(text(tree), /未生效/);
  const message = one(tree, node => node.type === "p" && node.props["aria-live"] === "polite", "rule validation message");
  assert.equal(message.props.className, "sr-only"); assert.equal(text(message), "");
  const control = one(h.snapshot("RuleValuePicker", fieldId).tree,
    node => node.type === "button" && node.props["aria-label"]?.endsWith("筛选值"), "valid value picker");
  assert.equal(control.props["aria-invalid"], undefined); assert.equal(control.props["aria-describedby"], undefined);
  assert.ok(h.api.activeCustomRules(h.api.customSelectionRules(h.rules), h.fields).some(value => value.fieldId === fieldId));
}
function assertFixedPicker(h, fieldId) {
  const tree = h.rowTree(fieldId); const field = h.fields.find(field => field.id === fieldId);
  assert.ok(component(tree, "RuleValuePicker"));
  assert.ok(!elements(tree).some(node => ["select", "option", "input", "small"].includes(node.type)));
  assert.doesNotMatch(text(tree), /是其中之一|不是任一项|不包含|介于（含边界）|为空|不为空/);
  const label = one(tree, node => node.type === "span" && node.props.title, "field title");
  assert.equal(label.props.title, `${field.entity === "task" ? "任务" : "Case"} · ${field.label} · ${field.group} · ${field.path.join(".")}`);
  assert.equal(text(label), field.label);
  assert.ok(!elements(tree).some(node => node.type === "small" ||
    /text-\[(?:10|11)px\]/.test(node.props.className ?? "") && text(node).includes(field.path.join("."))), "No field-path small text");
}
function assertListCount(h, filtered, total) {
  const match = /共\s*<b\b[^>]*>(\d+)<\/b>\s*\/(\d+)/.exec(h.rootHtml);
  assert.ok(match, "Actual CaseList SSR must render its filtered/total count");
  assert.deepEqual(match.slice(1).map(Number), [filtered, total]);
}
function filterButton(h) {
  return one(h.tree, node => node.type === "button" && /^筛选(?: \d+)?$/.test(node.props["aria-label"] ?? ""), "CaseList filter trigger");
}
function addDimension(h, id) {
  h.openAdd();
  h.category(id.startsWith("task:") ? "任务" : "Case");
  h.add(id);
}

test("initial custom section SSR exposes 添加维度 without eagerly reading the full 286+ field value catalog", () => {
  const h = harness({ optionsFor: () => assert.fail("No picker is open: candidate values must not be read") });
  assert.ok(h.fields.length >= 286, "Use the real large catalog, not a small replacement fixture");
  assert.equal(new Set(h.fields.map(field => field.id)).size, h.fields.length);
  assert.match(h.rootHtml, /<section[^>]*aria-label="自定义筛选条件"/);
  assert.match(h.rootHtml, /自定义维度/);
  assert.ok(button(h.tree, "添加维度"));
  assert.equal(h.popover("CaseCustomFilterEditor").props.open, false);
  assert.doesNotMatch(h.rootHtml, /cmdk-item|请选择筛选值|未生效/);
  assert.doesNotMatch(h.rootHtml, /多条件同时满足；任务条件需命中同一条执行任务。|是其中之一|<select|<small/);
  assert.deepEqual(h.optionReads, []);
  assert.deepEqual(h.changes, []);
});

test("add picker SSR separates Case/任务 categories and searches names, groups and nested paths with all query terms", () => {
  const h = harness(); h.openAdd();
  let html = h.popupHtml("添加自定义维度");
  assert.match(html, /搜索名称、分组或字段路径/);
  assert.match(html, /Case 基础信息/);
  assert.match(html, /Case 根因与结案/);
  assert.match(html, /closure\.closedAt/);
  assert.match(html, /max-h-\[240px\]/);
  assert.ok(commandItems(h.editorTree).every(node => node.props.value.startsWith("case:")));
  assert.equal(button(byAria(h.editorTree, "维度分类"), "Case").props["aria-pressed"], true);
  for (const [query, id] of [["基础信息 name", "case:name"], ["根因与结案 CLOSURE.closedAt", "case:closure.closedAt"]]) {
    h.searchFields(query);
    assert.deepEqual(commandItems(h.editorTree).map(node => node.props.value), [id]);
    const field = h.fields.find(field => field.id === id);
    assert.equal(h.fieldItem(id).props.title, `Case · ${field.label} · ${field.group} · ${field.path.join(".")}`);
    assert.equal(text(h.fieldItem(id)), field.label, "Path and group stay in the tooltip/search, not a second small-text line");
    assert.ok(!elements(h.fieldItem(id)).some(node => node.type === "small" || /text-\[(?:10|11)px\]/.test(node.props.className ?? "")));
  }
  h.searchFields("任务图谱位置 MANUALPOS.x");
  assert.equal(commandItems(h.editorTree).length, 0, "Task paths must not leak into the Case category");
  h.category("任务");
  assert.deepEqual(commandItems(h.editorTree).map(node => node.props.value), ["task:manualPos.x"]);
  html = h.popupHtml("添加自定义维度");
  assert.match(html, /任务节点横坐标/); assert.match(html, /manualPos\.x/);
  assert.equal(text(h.fieldItem("task:manualPos.x")), "任务节点横坐标");
  assert.doesNotMatch(html.replace(/<[^>]*>/g, ""), /manualPos\.x/);
  h.searchFields("任务图谱位置 manualPos.x nonexistent-token");
  assert.equal(commandItems(h.editorTree).length, 0, "Search is AND, not OR");
  h.closeAdd(); h.openAdd();
  assert.equal(component(h.editorTree, "CommandInput").props.value, "");
  assert.ok(commandItems(h.editorTree).every(node => node.props.value.startsWith("task:")));
  let stopped = 0;
  byAria(h.editorTree, "添加自定义维度").props.onEscapeKeyDown({ stopPropagation() { stopped++; } });
  assert.equal(stopped, 1, "Child Escape must not propagate to the parent filter popup");
  assert.deepEqual(h.optionReads, []);
});

test("real add callbacks guard duplicate/reentrant selection, survive UUID collisions, and remove only the targeted rule", () => {
  const h = harness({ uuid: () => "deliberately-repeated-uuid" }); h.openAdd();
  const first = h.fieldItem("case:owner").props.onSelect;
  const second = h.fieldItem("case:name").props.onSelect;
  first(); first(); second(); // Same captured render: rulesRef must prevent lost updates and duplicates.
  h.render();
  assert.deepEqual(plain(h.rules.map(value => value.fieldId)), ["case:owner", "case:name"]);
  assert.equal(h.changes.length, 2);
  assert.equal(new Set(h.rules.map(value => value.id)).size, 2);
  assert.equal(h.rules[0].id, "deliberately-repeated-uuid");
  assert.match(h.rules[1].id, /^custom-filter-123456789-\d+$/);
  assert.ok(h.rules.every(value => value.operator === "in" && value.values.length === 0));
  assert.equal(h.popover("CaseCustomFilterEditor").props.open, false);
  h.openAdd();
  assert.ok(!commandItems(h.editorTree).some(node => ["case:owner", "case:name"].includes(node.props.value)));
  h.closeAdd();
  const retained = h.rules[0]; const removedId = h.rules[1].id;
  h.remove("case:name"); assert.equal(h.rules[0], retained);
  addDimension(h, "case:name");
  assert.notEqual(h.rules[1].id, removedId, "Monotonic fallback IDs survive remove/re-add within a mount");
  assert.equal(new Set(h.rules.map(value => value.id)).size, 2);
  h.remove("case:name"); h.remove("case:owner");
  assert.deepEqual(plain(h.rules), []);
  assert.ok(button(h.editorTree, "添加维度"));
  assert.doesNotMatch(h.rootHtml, /未生效/);
  assert.deepEqual(h.optionReads, []);
});

test("fixed pickers keep missing fields and empty catalogs inert, normalize old operators, and select boolean values without operator UI", () => {
  const h = harness({ rules: [rule("case:owner", "contains", ["张伟"]), rule("case:removedField", "in", ["old"])] });
  assertFixedPicker(h, "case:owner"); assertInvalid(h, "case:owner", "请选择筛选项");
  assertInvalid(h, "case:removedField", "字段已不可用，请移除此条件");
  assert.deepEqual(plain(h.snapshot("CustomRuleRow", "case:owner").props.rule), rule("case:owner"));
  assert.deepEqual(h.changes, [], "Rendering a normalized view does not write back the legacy draft");
  h.openValue("case:owner");
  assert.equal(commandItems(h.valueTree("case:owner")).length, 0);
  assert.equal(text(component(h.valueTree("case:owner"), "CommandEmpty")), "暂无候选");
  assert.equal(button(h.valueTree("case:owner"), "全部清空").props.disabled, true);
  h.searchValues("case:owner", "张伟");
  assert.equal(commandItems(h.valueTree("case:owner")).length, 0, "Search cannot create a free-text predicate");
  assert.deepEqual(h.changes, []);
  h.closeValue("case:owner"); h.remove("case:removedField");
  assert.deepEqual(plain(h.rules), [rule("case:owner")], "A real edit commits the normalized rules, not hidden predicates");

  const id = "task:likedByMe"; const boolean = harness({ rules: [rule(id)] });
  assertFixedPicker(boolean, id); assertInvalid(boolean, id, "请选择筛选项");
  boolean.openValue(id);
  assert.deepEqual(commandItems(boolean.valueTree(id)).map(node => node.props.title), ["是", "否"]);
  boolean.searchValues(id, "false");
  assert.deepEqual(commandItems(boolean.valueTree(id)).map(node => node.props.title), ["否"]);
  boolean.choose(id, "否");
  assert.deepEqual(plain(boolean.rules[0].values), ["false"]); assertValid(boolean, id);
  assert.equal(boolean.rules[0].operator, "in");
  const matches = likedByMe => boolean.api.matchesCustomRules({ caseData: {}, tasks: [action("bool", { likedByMe })] }, boolean.rules, boolean.fields);
  assert.deepEqual([false, true, undefined].map(matches), [true, false, false]);
  boolean.searchValues(id, ""); boolean.choose(id, "是");
  assert.deepEqual(plain(boolean.rules[0].values), ["false", "true"]);
  assert.deepEqual([false, true, undefined].map(matches), [true, true, false]);
  boolean.act(button(boolean.valueTree(id), "全部清空").props.onClick);
  assertInvalid(boolean, id, "请选择筛选项");
  assert.equal(boolean.popover("RuleValuePicker", id).props.open, true);
});

test("optionsFor is lazy per actually opened value leaf, memoized during its lifetime and discarded on close", () => {
  const h = harness({ rules: [rule("case:owner"), rule("case:name"), rule("case:dueIn", "in", ["2"])],
    records: [{ caseData: { owner: "张伟", name: "名称" }, tasks: [] }] });
  assert.deepEqual(h.optionReads, []);
  h.openAdd(); h.searchFields("基础信息"); h.closeAdd();
  assert.deepEqual(h.optionReads, [], "Browsing field metadata must not evaluate any candidate values");
  h.openValue("case:owner"); assert.deepEqual(h.optionReads, ["case:owner"]);
  h.searchValues("case:owner", "张"); h.choose("case:owner", "张伟");
  assert.deepEqual(h.optionReads, ["case:owner"], "Stable optionsFor must reuse the mounted leaf's memo");
  assert.equal(h.popover("RuleValuePicker", "case:owner").props.open, true);
  h.closeValue("case:owner"); h.render();
  assert.deepEqual(h.optionReads, ["case:owner"]);
  h.openValue("case:owner");
  assert.deepEqual(h.optionReads, ["case:owner", "case:owner"]);
  assert.equal(component(h.valueTree("case:owner"), "CommandInput").props.value, "");
  assert.deepEqual(plain(h.rules[0].values), ["张伟"]);
  let stopped = 0;
  byAria(h.snapshot("RuleValuePicker", "case:owner").tree, "Case·Case 负责人选择筛选值").props.onEscapeKeyDown({ stopPropagation() { stopped++; } });
  assert.equal(stopped, 1);
  h.closeValue("case:owner"); h.openValue("case:name");
  assert.deepEqual(h.optionReads, ["case:owner", "case:owner", "case:name"]);
  assert.ok(!h.optionReads.includes("case:dueIn"), "Unopened numeric pickers must not read candidates either");
  h.closeValue("case:name"); h.openValue("case:dueIn");
  assert.deepEqual(h.optionReads, ["case:owner", "case:owner", "case:name", "case:dueIn"]);
  assert.deepEqual(commandItems(h.valueTree("case:dueIn")).map(node => node.props.title), ["2"], "Missing numeric catalog retains the selected value");
});

test("multi-choice callbacks preserve raw spaces, stale/hidden selections and stable groups without closing on select or clear", () => {
  const raw = "  Alice  "; const stale = "  已离开目录  ";
  const h = harness({ rules: [rule("case:owner", "in", [stale])], records: [
    { caseData: { owner: raw }, tasks: [] }, { caseData: { owner: "Alice" }, tasks: [] },
    { caseData: { owner: raw }, tasks: [] },
  ] });
  h.openValue("case:owner");
  const choices = () => commandItems(h.valueTree("case:owner"));
  assert.equal(choices().length, 3, "Duplicate catalog values must be deduplicated, not trimmed together");
  assert.ok(choices().every(node => /^custom-value-\d+$/.test(node.props.value)));
  assert.ok(choices().some(node => node.props.title === stale && node.props["aria-label"] === `${stale}（已选）`));
  assert.match(h.popupHtml("Case·Case 负责人选择筛选值"), /已选值/);
  assert.match(h.popupHtml("Case·Case 负责人选择筛选值"), /whitespace-pre/);
  const catalogGroup = () => one(h.valueTree("case:owner"), node => componentName(node) === "CommandGroup" && node.props.heading === "可选值", "stable catalog group");
  const before = commandItems(catalogGroup()).map(node => [node.props.value, node.props.title]);
  h.choose("case:owner", raw);
  assert.deepEqual(plain(h.rules[0].values), [stale, raw]);
  assert.deepEqual(commandItems(catalogGroup()).map(node => [node.props.value, node.props.title]), before);
  assert.equal(h.popover("RuleValuePicker", "case:owner").props.open, true);
  assert.equal(h.api.matchesCustomRules({ caseData: { owner: raw }, tasks: [] }, h.rules, h.fields), true);
  assert.equal(h.api.matchesCustomRules({ caseData: { owner: "Alice" }, tasks: [] }, h.rules, h.fields), false, "Raw spaced and unspaced strings remain different engine values");
  h.searchValues("case:owner", "ALICE");
  assert.equal(choices().length, 2);
  h.choose("case:owner", "Alice");
  assert.deepEqual(plain(h.rules[0].values), [stale, raw, "Alice"], "Search must not drop hidden selected values");
  h.choose("case:owner", raw);
  assert.deepEqual(plain(h.rules[0].values), [stale, "Alice"]);
  h.searchValues("case:owner", "");
  assert.match(text(h.snapshot("RuleValuePicker", "case:owner").tree), /已选 2 项/);
  h.act(button(h.valueTree("case:owner"), "全部清空").props.onClick);
  assert.deepEqual(plain(h.rules[0].values), []);
  assert.equal(h.popover("RuleValuePicker", "case:owner").props.open, true);
  assert.equal(choices().some(node => node.props.title === stale), false);
  assert.equal(button(h.valueTree("case:owner"), "全部清空").props.disabled, true);
  assertInvalid(h, "case:owner", "请选择筛选项");
  h.act(button(h.valueTree("case:owner"), "完成").props.onClick);
  assert.equal(h.popover("RuleValuePicker", "case:owner").props.open, false);
});

test("numeric fixed picker searches canonical values, selects exact numeric alternatives rather than a range, and clears invalid drafts", () => {
  const id = "case:dueIn";
  const h = harness({ rules: [rule(id)], records: [-1.5, "-1.50", 0, "2.75", "bad", null].map(dueIn => ({ caseData: { dueIn }, tasks: [] })) });
  assertFixedPicker(h, id); assertInvalid(h, id, "请选择筛选项");
  assert.deepEqual(h.optionReads, []); h.openValue(id);
  assert.deepEqual(commandItems(h.valueTree(id)).map(node => node.props.title), ["-1.5", "0", "2.75"]);
  h.searchValues(id, "-1.5"); h.choose(id, "-1.5"); assertValid(h, id);
  h.searchValues(id, "2.75"); h.choose(id, "2.75");
  assert.deepEqual(plain(h.rules[0].values), ["-1.5", "2.75"]); assert.equal(h.rules[0].operator, "in");
  const matches = dueIn => h.api.matchesCustomRules({ caseData: { dueIn }, tasks: [] }, h.rules, h.fields);
  assert.deepEqual([-1.51, -1.5, 0, 2.75, 2.76, "-1.50"].map(matches), [false, true, false, true, false, true]);
  h.searchValues(id, "0"); h.choose(id, "0"); assert.equal(matches(0), true);
  assert.equal(h.popover("RuleValuePicker", id).props.open, true);
  assert.doesNotMatch(h.html, /type="number"|type="date"|<select|起始值|结束值|是其中之一/);
  h.closeValue(id); h.replaceRules([rule(id, "in", ["NaN"])]);
  assertInvalid(h, id, "存在无效筛选值"); h.openValue(id);
  assert.ok(commandItems(h.valueTree(id)).some(node => node.props.title === "NaN"));
  h.act(button(h.valueTree(id), "全部清空").props.onClick);
  assert.deepEqual(plain(h.rules[0].values), []); assertInvalid(h, id, "请选择筛选项");
  h.searchValues(id, "0"); h.choose(id, "0"); assertValid(h, id);
});

test("date fixed picker searches real calendar-day options and selects noncontiguous days without native date or range inputs", () => {
  const id = "case:dueDate";
  const h = harness({ rules: [rule(id)], records: ["2024-02-29", "2026-02-28", "2026-03-01T23:59:59Z", "2026-03-01", "2026-03-02", "2026-02-29", "bad"].map(dueDate => ({ caseData: { dueDate }, tasks: [] })) });
  assertFixedPicker(h, id); assertInvalid(h, id, "请选择筛选项");
  assert.deepEqual(h.optionReads, []); h.openValue(id);
  assert.deepEqual(commandItems(h.valueTree(id)).map(node => node.props.title), ["2024-02-29", "2026-02-28", "2026-03-01", "2026-03-02"]);
  h.searchValues(id, "2026-02"); h.choose(id, "2026-02-28"); assertValid(h, id);
  h.searchValues(id, "2026-03-02"); h.choose(id, "2026-03-02");
  assert.deepEqual(plain(h.rules[0].values), ["2026-02-28", "2026-03-02"]); assert.equal(h.rules[0].operator, "in");
  const matches = dueDate => h.api.matchesCustomRules({ caseData: { dueDate }, tasks: [] }, h.rules, h.fields);
  assert.deepEqual(["2026-02-27", "2026-02-28", "2026-03-01T23:59:59Z", "2026-03-02T23:59:59Z"].map(matches), [false, true, false, true]);
  h.searchValues(id, "2026-03-01"); h.choose(id, "2026-03-01");
  assert.equal(matches("2026-03-01T23:59:59Z"), true);
  assert.equal(h.popover("RuleValuePicker", id).props.open, true);
  assert.doesNotMatch(h.html, /type="date"|type="number"|<select|起始值|结束值|是其中之一/);
  h.closeValue(id); h.replaceRules([rule(id, "in", ["2026-02-29"])]);
  assertInvalid(h, id, "存在无效筛选值"); h.openValue(id);
  h.act(button(h.valueTree(id), "全部清空").props.onClick);
  assertInvalid(h, id, "请选择筛选项");
  h.searchValues(id, "2024-02-29"); h.choose(id, "2024-02-29"); assertValid(h, id);
  assert.deepEqual(plain(h.rules[0].values), ["2024-02-29"]);
});

test("CaseList sixth field uses current recursive dispatchers, exact people, query AND, badges and complete reset without changing custom metadata", () => {
  const cases = [caseItem("created", { createdBy: "王强" }),
    caseItem("dispatch", { tasks: [action("old", { supervisor: "旧分派人" })] }),
    caseItem("removed", { createdBy: undefined, tasks: [action("removed-task", { supervisor: "王强" })] }),
    caseItem("owner-only", { createdBy: undefined, owner: "王强", tasks: [{ id: "thought", supervisor: "王强" }] }),
    caseItem("substring", { createdBy: "王强甲" }),
    caseItem("fanout", { source: "fanout验证", createdBy: "王强", status: "验证中" })];
  const trees = { dispatch: [{ id: "root", supervisor: "思路人员", children: [{ id: "nested", children: [action("actual", { supervisor: "王强" })] }] }], removed: [] };
  const before = JSON.stringify([cases, trees]);
  const h = harness({ mode: "list", cases, trees });
  assertListCount(h, 5, 6); h.openFilters();
  const field = label => byAria(h.snapshot("CaseFilterFields").tree, `Case ${label}`);
  const change = (label, value) => {
    const reads = h.treeReads.length;
    h.act(field(label).props.onChange, { target: { value } });
    assert.equal(h.treeReads.length - reads, cases.length, "One persisted read per Case per render");
  };
  const search = value => h.act(one(h.tree, node => node.type === "input" && node.props.placeholder === "搜索Case", "Case search").props.onChange, { target: { value } });
  assert.equal(elements(h.snapshot("CaseFilterFields").tree).filter(node => node.type === "select").length, 6);
  assert.equal(field("创建 / 分派人").props.value, "全部");
  assert.deepEqual(elements(field("创建 / 分派人")).filter(node => node.type === "option").map(node => node.props.value), ["全部", "王强", "李娜", "王强甲"]);
  change("创建 / 分派人", "王强"); assertListCount(h, 2, 6);
  assert.equal(filterButton(h).props["aria-label"], "筛选 1");
  assert.doesNotMatch(h.rootHtml, /问题 removed|问题 owner-only|问题 substring|问题 fanout/);
  for (const value of ["王", "旧分派人", "思路人员", " 王强 "]) { change("创建 / 分派人", value); assertListCount(h, 0, 6); }
  change("创建 / 分派人", "王强"); search("dispatch"); assertListCount(h, 1, 6);
  change("产品", "LPDDR"); assertListCount(h, 0, 6);
  change("产品", "DDR5"); assertListCount(h, 1, 6); assert.equal(filterButton(h).props["aria-label"], "筛选 2");
  change("状态", "验证中"); assertListCount(h, 0, 6); assert.equal(filterButton(h).props["aria-label"], "筛选 3");
  change("状态", "全部");
  h.replaceRules([rule("case:createdBy", "in", ["李娜"]), rule("task:supervisor", "in", ["王强"])]);
  assertListCount(h, 1, 6); assert.equal(filterButton(h).props["aria-label"], "筛选 4");
  search("created"); assertListCount(h, 0, 6);
  h.act(button(h.panelTree, "重置全部").props.onClick);
  assertListCount(h, 5, 6); assert.equal(filterButton(h).props["aria-label"], "筛选");
  assert.ok(elements(h.snapshot("CaseFilterFields").tree).filter(node => node.type === "select").every(node => node.props.value === "全部"));
  assert.equal(h.snapshot("CaseList").frame.state.get("q"), ""); assert.deepEqual(plain(h.rules), []);
  for (const value of [undefined, "", "全部"]) { change("创建 / 分派人", value); assertListCount(h, 5, 6); assert.equal(filterButton(h).props["aria-label"], "筛选"); }
  assert.equal(JSON.stringify([cases, trees]), before); assert.deepEqual(h.navigated, []);
});

test("actual CaseList applies only valid rules before result counts/badges and reset clears custom drafts plus shared fields", () => {
  const cases = [caseItem("mine"), caseItem("other", { owner: "李娜", product: "LPDDR" })];
  const h = harness({ mode: "list", cases });
  assertListCount(h, 2, 2); assert.equal(filterButton(h).props["aria-label"], "筛选");
  h.openFilters();
  assert.ok(component(h.panelTree, "CaseFilterFields"), "CaseList's shared panel must render the actual field UI");
  assert.ok(component(h.panelTree, "CaseCustomFilterEditor"), "The shared panel must render the actual custom editor");
  assert.match(h.popupHtml("分析中心 Case 筛选"), /aria-label="Case 层级"/);
  addDimension(h, "case:owner");
  assertInvalid(h, "case:owner", "请选择筛选项");
  assertListCount(h, 2, 2);
  assert.equal(filterButton(h).props["aria-label"], "筛选");
  assert.equal(elements(filterButton(h)).filter(node => node.type === "span").length, 0, "An invalid draft adds no numeric badge");
  h.openValue("case:owner"); h.searchValues("case:owner", "张"); h.choose("case:owner", "张伟"); h.closeValue("case:owner");
  assertListCount(h, 1, 2); assert.equal(filterButton(h).props["aria-label"], "筛选 1");
  assert.match(h.rootHtml, /问题 mine/); assert.doesNotMatch(h.rootHtml, /问题 other/);
  addDimension(h, "case:dueDate");
  h.openValue("case:dueDate"); h.searchValues("case:dueDate", "2026-09-10");
  assert.equal(commandItems(h.valueTree("case:dueDate")).length, 0, "An unmatched search is not a date predicate");
  h.closeValue("case:dueDate"); assertInvalid(h, "case:dueDate", "请选择筛选项");
  assertListCount(h, 1, 2); assert.equal(filterButton(h).props["aria-label"], "筛选 1");
  h.act(byAria(h.snapshot("CaseFilterFields").tree, "Case 产品").props.onChange, { target: { value: "DDR5" } });
  assert.equal(filterButton(h).props["aria-label"], "筛选 2");
  h.act(button(h.panelTree, "完成").props.onClick);
  assert.equal(h.popover("CaseList").props.open, false);
  assert.equal(h.rules.length, 2, "Closing is not reset");
  assertListCount(h, 1, 2);
  h.openFilters();
  assertInvalid(h, "case:dueDate", "请选择筛选项");
  h.act(button(h.panelTree, "重置全部").props.onClick);
  assert.deepEqual(plain(h.rules), []); assertListCount(h, 2, 2);
  assert.equal(filterButton(h).props["aria-label"], "筛选");
  assert.equal(byAria(h.snapshot("CaseFilterFields").tree, "Case 产品").props.value, "全部");
  assert.equal(h.popover("CaseList").props.open, true, "Reset keeps the settings open");
  assert.doesNotMatch(h.html, /未生效/);
  h.replaceRules([
    rule("case:removedField", "in", ["old"]), rule("case:owner", "gt", ["10"]),
    rule("case:dueDate", "between", ["2026-09-20", "2026-09-10"]),
  ]);
  assertInvalid(h, "case:removedField", "字段已不可用，请移除此条件");
  assertInvalid(h, "case:owner", "请选择筛选项");
  assertInvalid(h, "case:dueDate", "请选择筛选项");
  assert.deepEqual(plain(h.rules.slice(1).map(({ operator, values }) => ({ operator, values }))), [{ operator: "in", values: [] }, { operator: "in", values: [] }]);
  assertListCount(h, 2, 2);
  assert.equal(filterButton(h).props["aria-label"], "筛选", "Unavailable fields and normalized legacy drafts add no badge");
  h.act(button(h.panelTree, "重置全部").props.onClick);
  assert.deepEqual(plain(h.rules), []);
  assert.deepEqual(h.navigated, []);
});

test("CaseList normalizes legacy customRulesDraft on initial read and subsequent callbacks without hidden predicates or badges", () => {
  const cases = [caseItem("mine"), caseItem("other", { owner: "李娜" })];
  const legacy = freeze([rule("case:owner", "contains", ["missing"]), rule("case:dueDate", "between", ["2026-09-01", "2026-09-10"])]);
  const before = JSON.stringify(legacy);
  const h = harness({ mode: "list", cases, rules: legacy });
  assertListCount(h, 2, 2); assert.equal(filterButton(h).props["aria-label"], "筛选");
  assert.deepEqual(plain(h.rules), plain(legacy), "Initial rendering must read the real draft slot without rewriting it");
  h.openFilters();
  for (const id of ["case:owner", "case:dueDate"]) { assertFixedPicker(h, id); assertInvalid(h, id, "请选择筛选项"); }
  assert.deepEqual(plain(h.snapshot("CaseCustomFilterEditor").props.rules), legacy.map(item => ({ ...item, operator: "in", values: [] })));
  h.openValue("case:owner"); h.choose("case:owner", "张伟"); h.closeValue("case:owner");
  assertListCount(h, 1, 2); assert.equal(filterButton(h).props["aria-label"], "筛选 1");
  assertValid(h, "case:owner"); assertInvalid(h, "case:dueDate", "请选择筛选项");
  assert.deepEqual(plain(h.rules), [rule("case:owner", "in", ["张伟"]), rule("case:dueDate")]);
  h.replaceRules(legacy);
  assertListCount(h, 2, 2); assert.equal(filterButton(h).props["aria-label"], "筛选");
  assert.ok(h.rules.every(item => item.operator === "in" && item.values.length === 0));
  assert.equal(JSON.stringify(legacy), before);
});

test("Fanout has one isolated display-settings switch, not a scope toggle, and composes with current custom rules", () => {
  const cases = [
    caseItem("normal", { fanoutTargets: ["product-target"] }),
    caseItem("incoming", { fanoutSourceCaseId: "normal" }),
    caseItem("foreign", { source: "fanout验证", owner: "其他人" }),
    caseItem("created", { source: "fanout验证", createdBy: actor.name }),
  ];
  const h = harness({ mode: "list", cases, rules: [rule("case:owner", "in", [actor.name])] });
  assertListCount(h, 1, 4); h.openFilters();
  const display = () => byAria(h.panelTree, "Case 显示设置");
  const scope = () => byAria(h.panelTree, "Case 筛选范围");
  const toggle = () => one(display(), node => node.props.role === "switch", "Fanout display switch");
  assert.equal(display().type, "section");
  assert.doesNotMatch(h.popupHtml("分析中心 Case 筛选"), /在当前筛选结果中包含 Fanout Case|多条件同时满足；任务条件需命中同一条执行任务。/);
  assert.equal(elements(h.panelTree).filter(node => node.props.role === "switch").length, 1);
  assert.equal(elements(scope()).filter(node => node.props.role === "switch").length, 0);
  assert.doesNotMatch(text(scope()), /查看 Fanout|显示设置/);
  assert.equal(toggle().props["aria-label"], "查看 Fanout"); assert.equal(toggle().props["aria-checked"], false);
  const savedRules = plain(h.rules);
  h.act(toggle().props.onClick);
  assert.equal(toggle().props["aria-checked"], true); assertListCount(h, 3, 4);
  assert.equal(h.snapshot("CaseList").frame.state.get("scope"), "all");
  assert.deepEqual(plain(h.rules), savedRules);
  h.act(button(scope(), "Fanout我").props.onClick);
  assertListCount(h, 1, 4); assert.match(h.rootHtml, /问题 incoming/);
  assert.doesNotMatch(h.rootHtml, /问题 normal|问题 foreign|问题 created/);
  h.act(toggle().props.onClick);
  assert.equal(toggle().props["aria-checked"], false);
  assert.equal(h.snapshot("CaseList").frame.state.get("scope"), "all");
  assertListCount(h, 1, 4); assert.match(h.rootHtml, /问题 normal/);
  assert.deepEqual(plain(h.rules), savedRules);
  h.act(button(scope(), "Fanout我").props.onClick);
  assert.equal(toggle().props["aria-checked"], true, "Entering Fanout scope enables visibility");
});

test("CaseList shares the current recursive task tree across custom matching, search, metrics and expanded rendering", () => {
  const liveOwner = "实时执行人";
  const cases = [caseItem("fresh", { tasks: [action("stale", { owner: "旧执行人", status: "已完成", progress: 100 })] }),
    caseItem("split"), caseItem("thought-only")];
  const trees = {
    fresh: [action("direction", { code: undefined, owner: "待指派", title: "实时思路", children: [
      action("live", { owner: liveOwner, title: "实时任务", status: "已完成", progress: 100 }),
      action("second", { owner: actor.name, title: "另一执行任务", progress: 0 }),
    ] })],
    split: [action("split-owner", { owner: liveOwner, status: "进行中" }), action("split-status", { owner: "其他人", status: "已完成" })],
    "thought-only": [action("not-action", { code: undefined, owner: liveOwner, status: "已完成" })],
  };
  const rules = [rule("task:owner", "in", [liveOwner]), rule("task:status", "in", ["已完成"])];
  const before = JSON.stringify({ cases, trees });
  const h = harness({ mode: "list", cases, trees, rules });
  assertListCount(h, 1, 3);
  assert.deepEqual(h.treeReads.map(read => read.id), cases.map(record => record.id));
  h.treeReads.forEach(read => {
    assert.equal(read.value, trees[read.id]);
    assert.equal(read.fallback, cases.find(record => record.id === read.id).tasks);
  });
  assert.match(h.rootHtml, /title="进度 50%"/);
  assert.match(h.rootHtml, /<b\b[^>]*>2<\/b>\s*任务/);
  const search = () => one(h.tree, node => node.type === "input" && node.props.placeholder === "搜索Case", "Case search");
  const readsBefore = h.treeReads.length;
  h.act(search().props.onChange, { target: { value: liveOwner } });
  assert.equal(h.treeReads.length - readsBefore, cases.length, "Load each persisted tree once per render, not once per consumer");
  assertListCount(h, 1, 3);
  const card = one(h.tree, node => node.key === "fresh", "filtered Case card");
  const expand = one(card, node => node.type === "button" && text(node) === "" && !node.props.title, "Case expand button");
  h.act(expand.props.onClick);
  assert.match(h.rootHtml, /实时任务/); assert.match(h.rootHtml, /另一执行任务/);
  assert.doesNotMatch(h.rootHtml, /执行 stale|旧执行人/);
  h.act(search().props.onChange, { target: { value: "旧执行人" } }); assertListCount(h, 0, 3);

  // Count/matching semantics are additionally checked through the real engine,
  // with no CaseList/Radix fixture logic deciding which records should match.
  const records = h.api.buildCustomFilterRecords(cases, { loadTree: record => trees[record.id], status: record => record.status, closure: () => undefined });
  const fields = h.api.customFieldCatalog(records);
  const matchedIds = selectedRules => plain(records.filter(record => h.api.matchesCustomRules(record, selectedRules, fields)).map(record => record.caseData.id));
  assert.deepEqual(matchedIds(rules), ["fresh"], "All task rules must match the same execution task, not two different tasks or a thought");
  assert.deepEqual(matchedIds([rule("case:tasks#count", "between", ["2", "2"])]), ["fresh", "split"]);
  assert.deepEqual(plain(records[0].tasks.map(task => task.id)), ["live", "second"]);
  assert.equal(JSON.stringify({ cases, trees }), before, "No source snapshot/tree mutation");
});

test("source wiring keeps custom filtering before list totals/render, shares the panel with MyCase, and excludes MyTask/Create", () => {
  const body = functionSource(listSource, "CaseList");
  assert.match(body, /currentCases\s*=\s*mockCases\.map\([\s\S]*?tasks:\s*loadCaseTaskTree\(c\.id,\s*c\.tasks\)/);
  assert.match(body, /buildCustomFilterRecords\(currentCases,\s*\{\s*loadTree:\s*c\s*=>\s*c\.tasks/);
  assert.match(body, /rows:\s*Row\[\]\s*=\s*currentCases\.map\([\s\S]*?m:\s*metrics\(c\)/);
  assert.match(body, /appliedCustomRules\s*=\s*activeCustomRules\(customRules,\s*customFields\)/);
  assert.match(body, /const\s*\[customRulesDraft,\s*setCustomRulesDraft\]\s*=\s*useState/);
  assert.match(body, /const customRules\s*=\s*customSelectionRules\(customRulesDraft\)/);
  assert.match(body, /const setCustomRules\s*=\s*\(rules:\s*CustomFilterRule\[\]\)\s*=>\s*setCustomRulesDraft\(customSelectionRules\(rules\)\)/);
  const filtering = body.indexOf("const filtered = rows.filter(");
  const matching = body.indexOf("matchesCustomRules(customRecordsById.get(c.id)!, appliedCustomRules, customFields)", filtering);
  const sorting = body.indexOf("filtered.sort(", filtering);
  const count = body.indexOf("{filtered.length}", filtering);
  const rendering = body.indexOf("filtered.map(", filtering);
  assert.ok(filtering >= 0 && filtering < matching && matching < sorting && sorting < count && count < rendering,
    "Custom matching must happen within the row predicate before sorting, displayed totals and cards");
  const reset = /const resetFilters\s*=\s*\(\)\s*=>\s*\{([\s\S]*?)\n\s*\};/.exec(body);
  assert.ok(reset); assert.match(reset[1], /setCustomRules\(\[\]\)/);
  const badge = /const activeFilterCount\s*=([\s\S]*?);/.exec(body);
  assert.ok(badge); assert.match(badge[1], /appliedCustomRules\.length/);
  assert.doesNotMatch(badge[1], /\bcustomRules\.length/);
  assert.match(listSource, /import\s*\{[^}]*\bCaseFilterPanel\b[^}]*\}\s*from\s*"\.\/CaseFilterPanel"/);
  assert.match(body, /<CaseFilterPanel\b[\s\S]*?customEditor=\{\{\s*fields:\s*customFields,\s*rules:\s*customRules,\s*optionsFor:\s*field\s*=>\s*customFilterOptions\(customRecords,\s*field\),\s*onChange:\s*setCustomRules\s*\}\}/);
  assert.match(body, /const metrics\s*=\s*\(c:\s*any\)\s*=>\s*\{\s*const actions\s*=\s*flattenTasks\(c\.tasks\)/);
  assert.match(body, /const caseInvolvesPerson[\s\S]*?return flattenTasks\(c\.tasks\)\.some/);
  assert.match(body, /filtered\.map\([\s\S]*?const tasks\s*=\s*flattenTasks\(c\.tasks\)/);
  assert.match(panelSource, /import\s*\{[^}]*\bCaseCustomFilterEditor\b[^}]*\}\s*from\s*"\.\/CaseCustomFilterEditor"/);
  assert.match(panelSource, /<CaseFilterFields\s+\{\.\.\.fields\}\s*\/>/);
  assert.match(panelSource, /customEditor\s*&&\s*<CaseCustomFilterEditor\s+\{\.\.\.customEditor\}\s*\/>/);
  const myCaseSource = readSource("MyCaseWorkbench.tsx");
  const workbenchFiltersSource = readSource("CaseWorkbenchFilters.tsx");
  assert.match(myCaseSource, /import\s*\{\s*CaseWorkbenchFilters\s*\}\s*from\s*"\.\/CaseWorkbenchFilters"/);
  assert.match(myCaseSource, /import\s*\{[^}]*\bcustomFilterOptions\b[^}]*\}\s*from\s*"\.\/caseCustomFilters"/);
  assert.match(myCaseSource, /<CaseWorkbenchFilters\b[\s\S]*?customEditor=\{\{\s*fields:\s*customFields,\s*rules:\s*view\.customRules\s*\?\?\s*\[\],\s*optionsFor:\s*field\s*=>\s*customFilterOptions\(customRecords,\s*field\),\s*onChange:\s*rules\s*=>\s*dispatch\(\{\s*type:\s*"custom-rules",\s*rules\s*\}\)\s*\}\}/);
  assert.match(workbenchFiltersSource, /import\s*\{[^}]*\bCaseFilterPanel\b[^}]*\}\s*from\s*"\.\/CaseFilterPanel"/);
  assert.match(workbenchFiltersSource, /<CaseFilterPanel\b[\s\S]*?customEditor=\{customEditor\}/);
  for (const file of ["MyTaskWorkbench.tsx", "TaskWorkbenchFilters.tsx", "taskWorkbenchModel.ts", "taskWorkbenchState.ts",
    "MyTodo.tsx", "CaseFilterFields.tsx", "CreateCase.tsx", "CreateCaseLab.tsx", "CreateStandaloneTask.tsx"]) {
    assert.doesNotMatch(readSource(file), /CaseCustomFilterEditor|caseCustomFilters|caseCustomFilterFields|CaseFilterPanel|\bcustomEditor\b|\bcustomRules\b|Case 显示设置/,
      `Shared Case custom filtering must not be wired into ${file}`);
  }
});