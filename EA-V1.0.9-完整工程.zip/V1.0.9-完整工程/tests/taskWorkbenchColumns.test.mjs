import assert from "node:assert/strict";
import test from "node:test";
import { build } from "esbuild";
import { fileURLToPath } from "node:url";
import vm from "node:vm";

const { outputFiles } = await build({
  stdin: {
    contents: 'export * from "./taskWorkbenchState"; export * from "./taskWorkbenchModel";',
    resolveDir: fileURLToPath(new URL("../src/app/components/", import.meta.url)),
    sourcefile: "task-workbench-columns-test-entry.ts", loader: "ts",
  },
  bundle: true, write: false, platform: "node", format: "cjs", external: ["./data"],
});
function flattenTasks(nodes) { return nodes.flatMap(task => [{ task }, ...flattenTasks(task.children ?? [])]); }
const sandbox = { module: { exports: {} }, require: name => {
  if (name === "./data") return { flattenTasks };
  throw new Error(`Unexpected dependency: ${name}`);
} };
vm.runInNewContext(outputFiles[0].text, sandbox);
const {
  createTaskWorkbenchState: create, updateTaskWorkbenchState: update,
  selectTaskWorkbenchColumns: select, selectWorkbenchTasks: selectSource,
  buildWorkbenchTasks: buildRows, taskCanAct: canAct, DEFAULT_TASK_FILTERS,
  TASK_REFERENCE_FIELDS, taskColumnFilterCount, taskColumnSorts,
} = sandbox.module.exports;
const plain = value => JSON.parse(JSON.stringify(value));
const statuses = ["待接受", "进行中", "已完成"];
const scopes = ["mine", "participating", "assigned"];
const sources = ["case", "standalone"];
const actor = "张伟";
const now = new Date(2026, 8, 10, 12);
const defaults = { 待接受: "priority", 进行中: "due", 已完成: "updated" };
const sorts = ["priority", "due", "updated"];
function freeze(value) {
  if (value && typeof value === "object" && !Object.isFrozen(value)) {
    Object.values(value).forEach(freeze);
    Object.freeze(value);
  }
  return value;
}
const ref = (key = "产品:p1") => ({ key, kind: key.split(":")[0], name: key, origin: "task" });
const row = (id, status, source = "standalone", patch = {}) => ({
  key: `${source}:${status}:${id}`, id, source, code: `TASK-${id}`, title: `任务 ${id}`,
  description: "实际任务说明", owner: actor, creator: "刘洋", participants: [], participantsFromCase: false,
  status, urgency: "一般", dueDate: "2026-09-12", updatedAt: "2026-09-09T10:00:00Z",
  caseItem: source === "case" ? { id: "c1", name: "问题一", code: "CASE-1", owner: "刘洋", level: "L1" } : undefined,
  caseClosed: false, business: [], attachmentCount: 0, hasVoice: false, record: {}, ...patch,
});
function stateFor(status, patch = {}, viewPatch = {}) {
  const initial = create();
  return { ...initial, status, views: { ...initial.views, [status]: {
    ...initial.views[status], ...viewPatch, filters: { ...initial.views[status].filters, ...patch },
  } } };
}
const keys = rows => plain(rows.map(item => item.key));
const ids = rows => plain(rows.map(item => item.id));
const combined = selection => [...selection.caseRows, ...selection.standaloneRows];
function assertReferences(selected, originals) {
  for (const item of selected) {
    const original = originals.find(candidate => candidate.key === item.key);
    assert.equal(item, original);
    assert.equal(item.record, original.record);
    assert.equal(item.business, original.business);
    assert.equal(item.participants, original.participants);
    assert.equal(item.caseItem, original.caseItem);
  }
}

// Deliberately conflicting priority, due-date and update orders; twelve rows per source.
const expectedOrder = {
  待接受: [11, 7, 3, 10, 6, 2, 9, 5, 1, 8, 4, 0],
  进行中: [11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0],
  已完成: [7, 2, 9, 4, 11, 6, 1, 8, 3, 10, 5, 0],
};
for (const status of statuses) test(`columns use ${defaults[status]} order for ${status}, ignoring legacy source/page/group/sort without dropping or duplicating rows`, () => {
  const rows = freeze(Array.from({ length: 12 }, (_, i) => sources.map(source => row(String(i).padStart(2, "0"), status, source, {
    urgency: ["不紧急", "一般", "紧急", "非常紧急"][i % 4],
    dueDate: `2026-09-${String(12 - i).padStart(2, "0")}`,
    updatedAt: `2026-09-${String((i * 5) % 12 + 1).padStart(2, "0")}T10:00:00Z`,
  }))).flat().reverse());
  const before = JSON.stringify(rows);
  const expected = expectedOrder[status].map(i => String(i).padStart(2, "0"));
  for (const source of ["all", "case", "standalone"]) {
    for (const sortBy of ["priority", "due", "updated"]) {
      for (const groupBy of ["none", "case", "business", "owner", "due"]) {
        for (const page of [1, 2, 999]) {
          const state = freeze(stateFor(status, { source, status: null, query: "hidden no-match query", showUpgraded: true, tfKey: "TF:stale", projectKey: "Project:stale" }, { sortBy, groupBy, page }));
          const snapshot = JSON.stringify(state);
          const selected = select(rows, state, actor, now);
          assert.deepEqual(plain(selected.columnSorts), { case: defaults[status], standalone: defaults[status] });
          assert.deepEqual(ids(selected.caseRows), expected);
          assert.deepEqual(ids(selected.standaloneRows), expected);
          assert.ok(selected.caseRows.every(item => item.source === "case"));
          assert.ok(selected.standaloneRows.every(item => item.source === "standalone"));
          assert.equal(combined(selected).length, 24);
          assert.equal(new Set(combined(selected).map(item => item.key)).size, 24);
          assert.deepEqual([...keys(combined(selected))].sort(), [...keys(rows)].sort());
          assert.deepEqual(plain(selected.filters), { ...plain(state.views[status].filters), productKey: "", tfKey: "", projectKey: "", businessKind: "all", businessKey: "", source: "all", status, query: "", showUpgraded: false });
          assert.equal(selected.counts[status], 24);
          assert.equal(selected.scopeCounts.mine, 24);
          assertReferences(combined(selected), rows);
          assert.equal(JSON.stringify(state), snapshot);
        }
      }
    }
  }
  assert.equal(JSON.stringify(rows), before);
});

test("column sorting handles invalid or missing dates and resolves equal values by stable keys in both sources", () => {
  const fixtures = [
    ["tie-z", { updatedAt: "2026-09-08T10:00:00Z" }],
    ["invalid-due", { urgency: "非常紧急", dueDate: "2026-02-31", updatedAt: "2026-09-11T10:00:00Z" }],
    ["late", { urgency: "非常紧急", dueDate: "2026-09-13", updatedAt: "2026-09-07T10:00:00Z" }],
    ["early", { urgency: "不紧急", dueDate: "2026-09-09", updatedAt: "2026-09-10T10:00:00Z" }],
    ["tie-a", { updatedAt: "2026-09-08T10:00:00Z" }],
    ["missing", { dueDate: undefined, updatedAt: undefined }],
    ["invalid", { dueDate: "not-a-date", updatedAt: "not-a-date" }],
  ];
  const expected = {
    待接受: ["late", "invalid-due", "tie-a", "tie-z", "invalid", "missing", "early"],
    进行中: ["early", "tie-a", "tie-z", "late", "invalid-due", "invalid", "missing"],
    已完成: ["invalid-due", "early", "tie-a", "tie-z", "late", "invalid", "missing"],
  };
  for (const status of statuses) {
    const rows = freeze(sources.flatMap(source => fixtures.map(([id, patch]) => row(id, status, source, patch))));
    for (const input of [rows, freeze([...rows].reverse())]) {
      for (const caseSort of sorts) for (const standaloneSort of sorts) {
        const columnSorts = { case: caseSort, standalone: standaloneSort };
        const state = freeze(stateFor(status, {}, { columnSorts }));
        const selected = select(input, state, actor, now);
        const expectedFor = sort => expected[statuses.find(value => defaults[value] === sort)];
        assert.deepEqual(ids(selected.caseRows), expectedFor(caseSort));
        assert.deepEqual(ids(selected.standaloneRows), expectedFor(standaloneSort));
        assert.deepEqual(plain(selected.columnSorts), columnSorts);
        assertReferences(combined(selected), rows);
      }
    }
  }
});

test("optional columnSorts resolves each missing or invalid source independently to the status default without reading legacy sortBy", () => {
  for (const status of statuses) for (const sortBy of sorts) for (const saved of [
    undefined, null, {}, { case: "updated" }, { standalone: "priority" },
    { case: "due", standalone: "updated" }, { case: "urgency", standalone: "due" },
    { case: "priority", standalone: "progress" }, { case: null, standalone: undefined },
    { case: "", standalone: 0 }, { case: "DUE", standalone: " updated " },
    { case: false, standalone: {} }, { all: "updated", source: "standalone" },
  ]) {
    const state = freeze(stateFor(status, { source: "standalone" }, { sortBy, columnSorts: saved }));
    const before = JSON.stringify(state);
    const expected = Object.fromEntries(sources.map(source => [source,
      sorts.includes(saved?.[source]) ? saved[source] : defaults[status],
    ]));
    assert.deepEqual(plain(taskColumnSorts(state)), expected);
    const selected = select(freeze([]), state, actor, now);
    assert.deepEqual(plain(selected.columnSorts), expected);
    assert.deepEqual(plain(selected.caseRows), []); assert.deepEqual(plain(selected.standaloneRows), []);
    assert.equal(taskColumnFilterCount(selected.filters), 0);
    assert.equal(JSON.stringify(state), before);
  }
});

test("column-sort validates both inputs, returns the same state for repeats or invalid values, and changes only one active source preference", () => {
  const rows = relationRows();
  for (const status of statuses) for (const scope of scopes) for (const source of sources) {
    const otherSource = sources.find(value => value !== source);
    const initial = freeze(stateFor(status, { scope, productKey: "产品:p1", caseId: "c1", creator: scope === "assigned" ? actor : "刘洋" },
      { page: 9, groupBy: "owner", sortBy: "updated", showBusiness: true }));
    const before = JSON.stringify(initial);
    assert.equal(update(initial, { type: "column-sort", source, sortBy: defaults[status] }), initial, "An implicit default is already selected");
    for (const sortBy of sorts.filter(value => value !== defaults[status])) {
      const action = freeze({ type: "column-sort", source, sortBy });
      const next = freeze(update(initial, action));
      assert.notEqual(next, initial); assert.notEqual(next.views, initial.views);
      assert.notEqual(next.views[status], initial.views[status]);
      assert.equal(next.status, initial.status);
      assert.equal(next.views[status].filters, initial.views[status].filters);
      assert.deepEqual(plain(next.views[status]), { ...plain(initial.views[status]), columnSorts: { [source]: sortBy } });
      for (const other of statuses.filter(value => value !== status)) assert.equal(next.views[other], initial.views[other]);
      assert.equal(update(next, action), next);
      const baseline = select(rows, initial, actor, now); const selected = select(rows, next, actor, now);
      for (const field of ["filters", "counts", "scopeCounts"]) assert.deepEqual(plain(selected[field]), plain(baseline[field]));
      assert.equal(taskColumnFilterCount(selected.filters), taskColumnFilterCount(baseline.filters));
      assert.deepEqual(plain(selected.columnSorts), { ...plain(baseline.columnSorts), [source]: sortBy });
      for (const field of ["caseRows", "standaloneRows"]) assert.deepEqual(keys(selected[field]).sort(), keys(baseline[field]).sort());
      assert.deepEqual(keys(selected[`${otherSource}Rows`]), keys(baseline[`${otherSource}Rows`]));
      assertReferences(combined(selected), rows);
      const back = update(next, { type: "column-sort", source, sortBy: defaults[status] });
      assert.deepEqual(plain(select(rows, back, actor, now)), plain(baseline));
      for (const invalidSource of [undefined, null, "", "all", "Case", "__proto__", 0]) {
        assert.equal(update(next, { type: "column-sort", source: invalidSource, sortBy }), next);
      }
      for (const invalidSort of [undefined, null, "", "urgency", "level", "progress", "DUE", " due ", "__proto__", 0, false, {}]) {
        assert.equal(update(next, { type: "column-sort", source, sortBy: invalidSort }), next);
      }
      const sibling = freeze(update(next, { type: "column-sort", source: otherSource, sortBy }));
      assert.deepEqual(plain(sibling.views[status].columnSorts), { case: sortBy, standalone: sortBy });
      assert.equal(sibling.views[status].filters, initial.views[status].filters);
      assert.equal(sibling.views[status].page, 9);
      assert.deepEqual(plain(next.views[status].columnSorts), { [source]: sortBy }, "No mutation of the earlier partial snapshot");
    }
    assert.equal(JSON.stringify(initial), before);
  }
});

test("all nine column-sort pairs apply before display to twelve rows per source in all three states despite obsolete source/page/manual sort preferences", () => {
  const rows = freeze(statuses.flatMap(status => Array.from({ length: 12 }, (_, i) => sources.map(source => row(String(i).padStart(2, "0"), status, source, {
    urgency: ["不紧急", "一般", "紧急", "非常紧急"][i % 4],
    dueDate: `2026-09-${String(12 - i).padStart(2, "0")}`,
    updatedAt: `2026-09-${String((i * 5) % 12 + 1).padStart(2, "0")}T10:00:00Z`,
  }))).flat()));
  const before = JSON.stringify(rows); const permissions = rows.map(item => canAct(item, actor));
  const expectedFor = sort => expectedOrder[statuses.find(status => defaults[status] === sort)].map(i => String(i).padStart(2, "0"));
  assert.equal(new Set(sorts.map(sort => expectedFor(sort).join(","))).size, 3, "Fixtures must distinguish all comparators");
  for (const status of statuses) for (const caseSort of sorts) for (const standaloneSort of sorts) {
    for (const source of ["all", "case", "standalone"]) for (const sortBy of sorts) {
      const state = freeze(stateFor(status, { source, query: "hidden", showUpgraded: true },
        { columnSorts: { case: caseSort, standalone: standaloneSort }, sortBy, groupBy: "owner", page: 999 }));
      const snapshot = JSON.stringify(state);
      for (const input of [rows, freeze([...rows].reverse()), freeze([...rows.slice(17), ...rows.slice(0, 17)])]) {
        const selected = select(input, state, actor, now);
        assert.deepEqual(plain(selected.columnSorts), { case: caseSort, standalone: standaloneSort });
        assert.deepEqual(ids(selected.caseRows), expectedFor(caseSort));
        assert.deepEqual(ids(selected.standaloneRows), expectedFor(standaloneSort));
        assert.equal(selected.caseRows.length, 12); assert.equal(selected.standaloneRows.length, 12);
        assert.ok(selected.caseRows.every(item => item.source === "case" && item.status === status));
        assert.ok(selected.standaloneRows.every(item => item.source === "standalone" && item.status === status));
        assert.deepEqual(keys(combined(selected)).sort(), keys(rows.filter(item => item.status === status)).sort());
        assert.equal(new Set(keys(combined(selected))).size, 24);
        assert.deepEqual(plain(selected.counts), { 待接受: 24, 进行中: 24, 已完成: 24 });
        assert.deepEqual(plain(selected.scopeCounts), { mine: 24, participating: 0, assigned: 0 });
        assert.equal(taskColumnFilterCount(selected.filters), 0);
        assertReferences(combined(selected), rows);
      }
      assert.equal(JSON.stringify(state), snapshot);
    }
  }
  assert.deepEqual(rows.map(item => canAct(item, actor)), permissions);
  assert.equal(JSON.stringify(rows), before);
});

function relationRows() {
  return freeze(statuses.flatMap(status => sources.flatMap(source => [
    row("mine-match", status, source, { business: [ref()], participants: [actor] }),
    row("mine-other-creator", status, source, { business: [ref()], creator: "李娜" }),
    row("mine-other-business", status, source, { business: [ref("产品:p2")] }),
    row("mine-none", status, source),
    row("mine-multi", status, source, { business: [ref(), ref("产品:p2")],
      ...(source === "case" ? { caseItem: { id: "c2", name: "问题二" } } : {}) }),
    row("assigned", status, source, { owner: "李娜", creator: actor, business: [ref()] }),
    row("participating", status, source, { owner: "王强", participants: [actor, actor], business: [ref()] }),
    row("overlap", status, source, { owner: "李娜", creator: actor, participants: [actor], business: [ref()] }),
    row("unrelated", status, source, { owner: "王强", creator: "李娜", business: [ref()] }),
  ])));
}
const allRelations = {
  mine: ["mine-match", "mine-other-creator", "mine-other-business", "mine-none", "mine-multi"],
  assigned: ["assigned", "overlap"], participating: ["participating", "overlap"],
};
const productRelations = {
  mine: ["mine-match", "mine-other-creator", "mine-multi"],
  assigned: ["assigned", "overlap"], participating: ["participating", "overlap"],
};

test("exact product and creator filters apply to both columns while stale TF/Project and legacy business filters do not restrict", () => {
  const rows = relationRows(); const before = JSON.stringify(rows);
  const scenarios = [
    [{}, allRelations],
    [{ businessKind: "产品" }, allRelations],
    [{ businessKind: "产品", businessKey: "产品:p1" }, allRelations],
    [{ businessKind: "none" }, allRelations],
    [{ businessKind: "TF" }, allRelations],
    [{ businessKind: "产品", businessKey: "产品:missing" }, allRelations],
    [{ productKey: "产品:p1" }, productRelations],
    [{ productKey: "产品:p2" }, { mine: ["mine-other-business", "mine-multi"], assigned: [], participating: [] }],
    [{ tfKey: "TF:t1" }, allRelations],
    [{ projectKey: "Project:project1" }, allRelations],
    [{ productKey: "产品:p1", tfKey: "TF:missing", projectKey: "Project:missing", businessKind: "none", businessKey: "hidden" }, productRelations],
    [{ productKey: "产品:missing" }, { mine: [], assigned: [], participating: [] }],
    [{ creator: "刘洋" }, { mine: ["mine-match", "mine-other-business", "mine-none", "mine-multi"], assigned: [], participating: ["participating"] }],
    [{ creator: actor }, { mine: [], assigned: ["assigned", "overlap"], participating: ["overlap"] }],
    [{ creator: "刘洋", productKey: "产品:p1" }, { mine: ["mine-match", "mine-multi"], assigned: [], participating: ["participating"] }],
    [{ creator: "missing" }, { mine: [], assigned: [], participating: [] }],
  ];
  for (const status of statuses) for (const [patch, expected] of scenarios) for (const scope of scopes) {
    const state = freeze(update(stateFor(status), { type: "column-filters", patch: { ...patch, scope } }));
    const selected = select(rows, state, actor, now);
    for (const column of [selected.caseRows, selected.standaloneRows]) {
      assert.deepEqual(ids(column).sort(), [...expected[scope]].sort(), `${status}/${scope}/${JSON.stringify(patch)}`);
    }
    assert.deepEqual(plain(selected.scopeCounts), Object.fromEntries(scopes.map(role => [role, expected[role].length * 2])));
    assert.deepEqual(plain(selected.counts), { 待接受: 10, 进行中: 10, 已完成: 10 });
    assert.equal(state.views[status].filters.tfKey, ""); assert.equal(state.views[status].filters.projectKey, "");
    assert.equal(selected.filters.tfKey, ""); assert.equal(selected.filters.projectKey, "");
    assert.equal(taskColumnFilterCount(selected.filters), Number(Boolean(patch.productKey)) + Number(Boolean(patch.creator)));
    assertReferences(combined(selected), rows);
  }
  assert.equal(JSON.stringify(rows), before);
});

test("raw Case filters restrict only the left column, including unavailable Cases, while clearing restores it", () => {
  const rows = relationRows();
  for (const status of statuses) for (const scope of scopes) {
    const state = update(stateFor(status), { type: "column-filters", patch: { scope, productKey: "产品:p1" } });
    const baseline = select(rows, state, actor, now);
    for (const caseId of ["c1", "c2", "unavailable-case"]) {
      const filtered = freeze(update(state, { type: "column-filters", patch: { caseId } }));
      const snapshot = JSON.stringify(filtered);
      const selected = select(rows, filtered, actor, now);
      assert.equal(selected.filters.source, "all");
      assert.equal(selected.filters.caseId, caseId);
      assert.deepEqual(keys(selected.caseRows), keys(baseline.caseRows.filter(item => item.caseItem.id === caseId)));
      assert.deepEqual(keys(selected.standaloneRows), keys(baseline.standaloneRows));
      selected.standaloneRows.forEach((item, index) => assert.equal(item, baseline.standaloneRows[index]));
      assert.equal(selected.scopeCounts[scope], selected.caseRows.length + selected.standaloneRows.length);
      assert.deepEqual(plain(selected.counts), plain(baseline.counts));
      const cleared = update(filtered, { type: "column-filters", patch: { caseId: "" } });
      assert.deepEqual(plain(select(rows, cleared, actor, now)), plain(baseline));
      assert.equal(JSON.stringify(filtered), snapshot);
    }
  }
});

test("role badges sum both source selections and match each role's rendered rows without counting overlaps twice within a role", () => {
  const rows = relationRows();
  for (const status of statuses) for (const caseId of ["", "c1", "c2", "missing"]) {
    const state = update(stateFor(status), { type: "column-filters", patch: { caseId, productKey: "产品:p1" } });
    const selected = select(rows, state, actor, now);
    // selectWorkbenchTasks is the legacy selector: explicitly prefilter the new reference field.
    const current = rows.filter(item => item.status === status && item.business.some(ref => ref.kind === "产品" && ref.key === "产品:p1"));
    const left = selectSource(current, { ...selected.filters, source: "case" }, actor);
    const right = selectSource(current, { ...selected.filters, source: "standalone", caseId: "" }, actor);
    const leftExpected = caseId === "" ? productRelations : Object.fromEntries(scopes.map(scope => [scope,
      productRelations[scope].filter(id => caseId === "c1" ? id !== "mine-multi" : caseId === "c2" && id === "mine-multi"),
    ]));
    for (const scope of scopes) {
      const scoped = select(rows, update(state, { type: "column-filters", patch: { scope } }), actor, now);
      const expected = leftExpected[scope].length + productRelations[scope].length;
      assert.equal(selected.scopeCounts[scope], expected);
      assert.equal(selected.scopeCounts[scope], left.scopeCounts[scope] + right.scopeCounts[scope]);
      assert.deepEqual(plain(scoped.scopeCounts), plain(selected.scopeCounts));
      assert.equal(combined(scoped).length, expected);
      assert.equal(new Set(combined(scoped).map(item => item.key)).size, expected);
    }
  }
  const state = stateFor("待接受");
  const assigned = select(rows, update(state, { type: "column-filters", patch: { scope: "assigned" } }), actor, now);
  const participating = select(rows, update(state, { type: "column-filters", patch: { scope: "participating" } }), actor, now);
  assert.equal(combined(assigned).filter(item => item.id === "overlap").length, 2);
  assert.equal(combined(participating).filter(item => item.id === "overlap").length, 2);
  assert.equal(combined(participating).some(item => item.owner === actor), false);
});

test("responsibility totals ignore all role/filter/view snapshots but track actual owner and status changes", () => {
  const rows = relationRows();
  let state = create();
  for (const status of statuses) {
    state = update(state, { type: "status", status });
    for (const scope of scopes) {
      state = update(state, { type: "column-filters", patch: { scope, caseId: "missing", creator: "missing", productKey: "产品:missing", tfKey: "TF:missing", projectKey: "Project:missing" } });
      state = update(state, { type: "group", groupBy: "case" });
      state = update(state, { type: "sort", sortBy: "updated" });
      state = update(state, { type: "page", page: 999 });
      state = update(state, { type: "business" });
      const selected = select(rows, state, actor, now);
      assert.deepEqual(plain(selected.counts), { 待接受: 10, 进行中: 10, 已完成: 10 });
      assert.equal(combined(selected).length, 0);
    }
  }
  const target = rows.find(item => item.status === "待接受" && item.id === "mine-match");
  const moved = rows.map(item => item === target ? { ...item, status: "进行中" } : item);
  assert.deepEqual(plain(select(moved, state, actor, now).counts), { 待接受: 9, 进行中: 11, 已完成: 10 });
  const reassigned = rows.map(item => item === target ? { ...item, owner: "李娜" } : item);
  assert.deepEqual(plain(select(reassigned, state, actor, now).counts), { 待接受: 9, 进行中: 10, 已完成: 10 });
  assert.deepEqual(plain(select(rows, state, "陌生人", now).counts), { 待接受: 0, 进行中: 0, 已完成: 0 });
});

test("converted sources stay hidden, closed Case tasks keep their real status, and column selection never changes permissions or records", () => {
  const action = (id, status, patch = {}) => ({ id, code: `EA-${id}`, title: id, owner: actor, supervisor: "刘洋", collaborators: [], urgency: "一般", status, ...patch });
  const standalone = (id, status, patch = {}) => ({ id, code: `TASK-${id}`, title: id, description: "说明", owner: actor, createdBy: "刘洋", collaborators: [], urgency: "一般", status, attachments: [], updatedAt: "2026-09-09T10:00:00Z", ...patch });
  const cases = freeze(statuses.flatMap(status => ["raw", "store", "imported", "open"].map(kind => ({
    id: `${status}-${kind}`, name: kind, code: `CASE-${kind}`, owner: "刘洋", participants: [],
    status: kind === "raw" ? "已结案" : "进行中", updatedAt: "2026-09-09T10:00:00Z",
    sourceStandaloneTaskIds: kind === "imported" ? [`${status}-partial`] : [],
    tasks: [action(`${status}-${kind}`, status)],
  }))));
  const tasks = freeze(statuses.flatMap(status => [standalone(`${status}-normal`, status),
    standalone(`${status}-converted`, status, { convertedCaseId: `${status}-imported` }),
    standalone(`${status}-partial`, status),
    standalone(`${status}-other`, status, { owner: "李娜", createdBy: actor, collaborators: [{ name: actor }] }),
  ]).concat([standalone("rejected", "已拒绝"), standalone("stopped", "已中止")]));
  const before = JSON.stringify([cases, tasks]);
  const rows = freeze(buildRows(cases, tasks, { products: [], isClosed: id => id.endsWith("-store") }));
  const rowSnapshot = JSON.stringify(rows);
  const permissions = rows.map(item => canAct(item, actor));
  for (const item of rows) {
    assert.equal(canAct(item, actor), item.owner === actor && !item.caseClosed && !item.convertedCaseId && ["待接受", "进行中"].includes(item.status));
    assert.equal(item.record, item.source === "case" ? item.caseItem.tasks[0] : tasks.find(task => task.id === item.id));
  }
  for (const status of statuses) for (const scope of scopes) {
    const state = freeze(stateFor(status, { scope, source: "standalone", query: "hidden", showUpgraded: true }, { page: 999 }));
    const selected = select(rows, state, actor, now);
    assert.deepEqual(plain(selected.counts), { 待接受: 5, 进行中: 5, 已完成: 5 });
    assert.deepEqual(plain(selected.scopeCounts), { mine: 5, participating: 1, assigned: 1 });
    assert.ok(combined(selected).every(item => item.status === status && !item.convertedCaseId));
    if (scope === "mine") {
      assert.equal(selected.caseRows.length, 4); assert.equal(selected.standaloneRows.length, 1);
      assert.equal(selected.caseRows.filter(item => item.caseClosed).length, 2);
      assert.ok(selected.caseRows.filter(item => item.caseClosed).every(item => !canAct(item, actor)));
    } else {
      assert.equal(selected.caseRows.length, 0); assert.equal(selected.standaloneRows.length, 1);
      assert.equal(canAct(selected.standaloneRows[0], actor), false);
    }
    assertReferences(combined(selected), rows);
  }
  assert.deepEqual(rows.map(item => canAct(item, actor)), permissions);
  assert.equal(JSON.stringify(rows), rowSnapshot);
  assert.equal(JSON.stringify([cases, tasks]), before);
});

test("column-filters keeps raw caseId at source all and normalizes only the active snapshot without mutating prior state", () => {
  for (const status of statuses) for (const source of ["all", "case", "standalone"]) {
    const previous = freeze(stateFor(status, { source, caseId: "old-case", query: "hidden", showUpgraded: true, status: null, creator: "刘洋", businessKind: "none", businessKey: "legacy-hidden", productKey: "产品:p2", tfKey: "TF:t1", projectKey: "Project:project1" },
      { page: 9, groupBy: "business", sortBy: "updated", showBusiness: true }));
    const patch = freeze({ caseId: "raw-unavailable-case", scope: "participating", productKey: "产品:p1", tfKey: "TF:patched", projectKey: "Project:patched", businessKind: "产品", businessKey: "产品:p2" });
    const before = JSON.stringify([previous, patch]);
    const next = update(previous, { type: "column-filters", patch });
    assert.notEqual(next, previous); assert.notEqual(next.views, previous.views);
    assert.notEqual(next.views[status], previous.views[status]);
    assert.notEqual(next.views[status].filters, previous.views[status].filters);
    assert.equal(next.status, status);
    assert.deepEqual(plain(next.views[status]), { ...plain(previous.views[status]), page: 1,
      filters: { ...plain(previous.views[status].filters), ...patch, tfKey: "", projectKey: "", businessKind: "all", businessKey: "", source: "all", status, query: "", showUpgraded: false },
    });
    for (const other of statuses.filter(value => value !== status)) assert.equal(next.views[other], previous.views[other]);
    for (const followup of [{}, { creator: "李娜" }, { scope: "assigned" }, { tfKey: "TF:t2" }, { projectKey: "Project:project2" }, { tfKey: "TF:t2", projectKey: "Project:project2" }, { businessKind: "none", businessKey: "old-hidden" }]) {
      const changed = update(next, { type: "column-filters", patch: followup });
      assert.equal(changed.views[status].filters.caseId, patch.caseId);
      assert.equal(changed.views[status].filters.source, "all");
      assert.deepEqual(plain(changed.views[status].filters), { ...plain(next.views[status].filters), ...followup, tfKey: "", projectKey: "", businessKind: "all", businessKey: "" });
      // Even an empty/unrelated patch must clean an already-stale snapshot.
      const fromStale = update(previous, { type: "column-filters", patch: followup });
      assert.equal(fromStale.views[status].filters.tfKey, ""); assert.equal(fromStale.views[status].filters.projectKey, "");
      assert.equal(fromStale.views[status].filters.productKey, "产品:p2");
      assert.equal(fromStale.views[status].filters.caseId, "old-case");
      assert.equal(fromStale.views[status].page, 1);
      assert.equal(fromStale.views[status].showBusiness, true);
      for (const other of statuses.filter(value => value !== status)) assert.equal(fromStale.views[other], previous.views[other]);
    }
    assert.equal(JSON.stringify([previous, patch]), before);
  }
});

test("column filters, scope and expansion restore independently on primary-status switches with unchanged view references", () => {
  let state = create(); const saved = {};
  for (const [index, status] of statuses.entries()) {
    const views = state.views;
    state = update(state, { type: "status", status });
    assert.equal(state.views, views);
    state = update(state, { type: "column-filters", patch: { scope: scopes[index], caseId: `case-${index}`, creator: `creator-${index}`, productKey: `产品:p${index}`, tfKey: `TF:t${index}`, projectKey: `Project:project${index}` } });
    state = update(state, { type: "column-sort", source: "case", sortBy: sorts[(index + 1) % 3] });
    state = update(state, { type: "column-sort", source: "standalone", sortBy: sorts[(index + 2) % 3] });
    assert.equal(state.views[status].filters.tfKey, ""); assert.equal(state.views[status].filters.projectKey, "");
    if (index !== 1) state = update(state, { type: "business" });
    saved[status] = state.views[status];
  }
  freeze(state);
  const before = JSON.stringify(state);
  for (const status of ["待接受", "已完成", "进行中", "待接受"]) {
    const views = state.views;
    state = update(state, { type: "status", status });
    assert.equal(state.views, views);
    assert.equal(update(state, { type: "status", status }), state);
    for (const value of statuses) assert.equal(state.views[value], saved[value]);
    const index = statuses.indexOf(status);
    const selected = select([], state, actor, now);
    assert.deepEqual(plain(selected.columnSorts), { case: sorts[(index + 1) % 3], standalone: sorts[(index + 2) % 3] });
    assert.equal(selected.filters.productKey, `产品:p${index}`);
    assert.equal(selected.filters.caseId, `case-${index}`); assert.equal(selected.filters.creator, `creator-${index}`);
    assert.equal(selected.filters.scope, scopes[index]); assert.equal(state.views[status].showBusiness, index !== 1);
    assert.equal(selected.filters.tfKey, ""); assert.equal(selected.filters.projectKey, "");
    assert.equal(taskColumnFilterCount(selected.filters), 3);
  }
  assert.equal(JSON.stringify({ ...state, status: "已完成" }), before);
});

test("clearing product, Case or creator preserves other active conditions while discarding stale TF/Project and keeping role, expansion and inactive views", () => {
  for (const status of statuses) {
    const initial = freeze(stateFor(status, { scope: "assigned", source: "all", productKey: "产品:p1", tfKey: "TF:t1", projectKey: "Project:project1", caseId: "c1", creator: actor }, { showBusiness: true, page: 4 }));
    const before = JSON.stringify(initial);
    for (const patch of [{ productKey: "" }, { caseId: "" }, { creator: "" }, { tfKey: "" }, { projectKey: "" }]) {
      const cleared = update(initial, { type: "column-filters", patch });
      assert.deepEqual(plain(cleared.views[status].filters), { ...plain(initial.views[status].filters), ...patch, tfKey: "", projectKey: "" });
      const activeFieldCleared = ["productKey", "caseId", "creator"].some(key => Object.hasOwn(patch, key));
      assert.equal(taskColumnFilterCount(cleared.views[status].filters), activeFieldCleared ? 2 : 3);
      assert.equal(cleared.status, status);
      assert.equal(cleared.views[status].page, 1);
      assert.equal(cleared.views[status].showBusiness, true);
      for (const other of statuses.filter(value => value !== status)) assert.equal(cleared.views[other], initial.views[other]);
    }
    assert.equal(JSON.stringify(initial), before);
  }
});

test("reset clears current column conditions and legacy preferences while preserving columnSorts, scope, status, expansion and other views", () => {
  const rows = relationRows();
  for (const status of statuses) for (const scope of scopes) for (const showBusiness of [false, true]) {
    const state = freeze(stateFor(status, { scope, businessKind: "产品", businessKey: "产品:missing", productKey: "产品:missing", tfKey: "TF:missing", projectKey: "Project:missing", creator: "missing", caseId: "missing" },
      { page: 4, groupBy: "case", sortBy: defaults[status] === "updated" ? "priority" : "updated", columnSorts: { case: "updated", standalone: "priority" }, showBusiness }));
    const before = JSON.stringify(state);
    assert.equal(combined(select(rows, state, actor, now)).length, 0);
    const reset = update(state, { type: "reset" });
    assert.equal(reset.status, status);
    assert.deepEqual(plain(reset.views[status]), {
      filters: { ...plain(DEFAULT_TASK_FILTERS), status, scope }, groupBy: "none", sortBy: defaults[status], columnSorts: { case: "updated", standalone: "priority" }, showBusiness, page: 1,
    });
    assert.equal(reset.views[status].columnSorts, state.views[status].columnSorts);
    for (const other of statuses.filter(value => value !== status)) assert.equal(reset.views[other], state.views[other]);
    const selected = select(rows, reset, actor, now);
    assert.deepEqual(plain(selected.columnSorts), { case: "updated", standalone: "priority" });
    assert.equal(selected.filters.productKey, ""); assert.equal(selected.filters.tfKey, ""); assert.equal(selected.filters.projectKey, "");
    assert.equal(taskColumnFilterCount(selected.filters), 0);
    assert.deepEqual(ids(selected.caseRows).sort(), [...allRelations[scope]].sort());
    assert.deepEqual(ids(selected.standaloneRows).sort(), [...allRelations[scope]].sort());
    assertReferences(combined(selected), rows);
    assert.equal(JSON.stringify(state), before);
  }
});

test("empty input and one-sided results keep both column arrays and honest counts in every primary status", () => {
  for (const status of statuses) {
    const state = freeze(stateFor(status, { caseId: "missing" }, { page: 999 }));
    const empty = select(freeze([]), state, actor, now);
    assert.deepEqual(plain(empty.caseRows), []); assert.deepEqual(plain(empty.standaloneRows), []);
    assert.deepEqual(plain(empty.counts), { 待接受: 0, 进行中: 0, 已完成: 0 });
    assert.deepEqual(plain(empty.scopeCounts), { mine: 0, participating: 0, assigned: 0 });
    const standalone = freeze(row("right-only", status));
    const right = select(freeze([standalone]), state, actor, now);
    assert.equal(right.caseRows.length, 0); assert.equal(right.standaloneRows[0], standalone);
    assert.equal(right.scopeCounts.mine, 1); assert.equal(right.counts[status], 1);
    const caseRow = freeze(row("left-only", status, "case"));
    const left = select(freeze([caseRow]), stateFor(status), actor, now);
    assert.equal(left.caseRows[0], caseRow); assert.equal(left.standaloneRows.length, 0);
    assert.equal(left.scopeCounts.mine, 1); assert.equal(left.counts[status], 1);
  }
});

test("only product is a reference filter, optional/stale keys normalize safely and badges count product plus Case and creator up to three", () => {
  assert.deepEqual(plain(TASK_REFERENCE_FIELDS), [{ key: "productKey", kind: "产品" }]);
  const fields = ["productKey", "tfKey", "projectKey", "caseId", "creator"];
  const values = ["产品:p1", "TF:t1", "Project:project1", "c1", "刘洋"];
  for (const status of statuses) for (const patch of [{}, { productKey: undefined, tfKey: undefined, projectKey: undefined }, { productKey: "", tfKey: "", projectKey: "" }, { tfKey: "TF:stale", projectKey: "Project:stale" }]) {
    const state = freeze(stateFor(status, patch)); const before = JSON.stringify(state);
    const selected = select([], state, actor, now);
    for (const key of fields.slice(0, 3)) {
      assert.ok(Object.hasOwn(selected.filters, key)); assert.equal(selected.filters[key], "");
    }
    assert.equal(selected.filters.businessKind, "all"); assert.equal(selected.filters.businessKey, "");
    assert.equal(taskColumnFilterCount(selected.filters), 0);
    assert.equal(JSON.stringify(state), before);
  }
  for (let mask = 0; mask < 32; mask++) {
    const filters = freeze({ ...plain(DEFAULT_TASK_FILTERS), source: "case", scope: "assigned", status: "已完成", query: "hidden", showUpgraded: true,
      businessKind: "none", businessKey: "legacy", ...Object.fromEntries(fields.map((key, i) => [key, mask & (1 << i) ? values[i] : ""])),
    });
    const before = JSON.stringify(filters);
    // All 32 populated/empty combinations include the two obsolete keys.
    const expected = Number(Boolean(mask & 1)) + Number(Boolean(mask & 8)) + Number(Boolean(mask & 16));
    assert.equal(taskColumnFilterCount(filters), expected);
    assert.ok(taskColumnFilterCount(filters) <= 3);
    assert.equal(JSON.stringify(filters), before);
  }
});

test("raw stale TF/Project and hidden business filters never restrict either column or counts and do not rewrite saved snapshots", () => {
  const rows = relationRows(); const before = JSON.stringify(rows);
  for (const status of statuses) for (const scope of scopes) for (const productKey of ["", "产品:p1"]) {
    const baseline = select(rows, stateFor(status, { scope, productKey }), actor, now);
    for (const businessKind of ["all", "none", "产品", "TF", "Project"]) for (const businessKey of ["", "产品:p2", "Project:missing"]) for (const stale of [
      {}, { tfKey: "TF:t1" }, { projectKey: "Project:project1" }, { tfKey: "TF:missing", projectKey: "Project:missing" },
    ]) {
      const state = freeze(stateFor(status, { scope, productKey, ...stale, businessKind, businessKey, source: "standalone", query: "invisible-no-match", showUpgraded: true }, { page: 999, groupBy: "business", sortBy: "updated" }));
      const snapshot = JSON.stringify(state);
      const selected = select(rows, state, actor, now);
      assert.deepEqual(plain(selected), plain(baseline));
      assert.equal(selected.filters.businessKind, "all"); assert.equal(selected.filters.businessKey, "");
      assert.equal(selected.filters.tfKey, ""); assert.equal(selected.filters.projectKey, "");
      assert.equal(taskColumnFilterCount(selected.filters), Number(Boolean(productKey)));
      assertReferences(combined(selected), rows);
      assert.equal(state.views[status].filters.businessKind, businessKind);
      assert.equal(state.views[status].filters.businessKey, businessKey);
      assert.equal(state.views[status].filters.tfKey, stale.tfKey);
      assert.equal(state.views[status].filters.projectKey, stale.projectKey);
      assert.equal(JSON.stringify(state), snapshot);
    }
  }
  assert.equal(JSON.stringify(rows), before);
});

test("all eight product/Case/creator combinations use AND with Case left-only, ignore stale TF/Project and preserve fixed totals and summed roles", () => {
  const rows = freeze(statuses.flatMap(status => sources.flatMap(source => Array.from({ length: 8 }, (_, mask) => scopes.map(scope => row(`${mask}-${scope}`, status, source, {
    business: ["产品:p1", "TF:t1", "Project:project1"].filter((_, i) => mask & (1 << i)).map(key => ref(key)),
    creator: mask & 4 ? "刘洋" : "李娜",
    ...(source === "case" ? { caseItem: { id: mask & 2 ? "c1" : "c2", name: "问题" } } : {}),
    ...(scope === "mine" ? { participants: [actor] } : scope === "assigned" ? { owner: "李娜", creator: actor, participants: [actor] } : { owner: "王强", participants: [actor] }),
  }))).flat())));
  const before = JSON.stringify(rows);
  for (const status of statuses) for (let mask = 0; mask < 8; mask++) {
    // Independent fixture-bit oracle: product and creator constrain both sources;
    // Case constrains only the left, and assigned fixtures were created by actor.
    const expectedIds = (source, scope) => Array.from({ length: 8 }, (_, i) => i).flatMap(i => {
      if ((mask & 1) && !(i & 1)) return [];
      if (source === "case" && (mask & 2) && !(i & 2)) return [];
      const roles = scope === "participating" ? ["participating", "assigned"] : [scope];
      return roles.filter(role => !(mask & 4) || (role !== "assigned" && Boolean(i & 4))).map(role => `${i}-${role}`);
    }).sort();
    const patch = { productKey: mask & 1 ? "产品:p1" : "", caseId: mask & 2 ? "c1" : "", creator: mask & 4 ? "刘洋" : "" };
    for (const scope of scopes) {
      const state = freeze(stateFor(status, { ...patch, scope, tfKey: "TF:t1", projectKey: "Project:project1", businessKind: "none", businessKey: "legacy" }));
      const snapshot = JSON.stringify(state);
      const selected = select(rows, state, actor, now);
      assert.deepEqual(ids(selected.caseRows).sort(), expectedIds("case", scope));
      assert.deepEqual(ids(selected.standaloneRows).sort(), expectedIds("standalone", scope));
      assert.deepEqual(plain(selected.scopeCounts), Object.fromEntries(scopes.map(role => [role, expectedIds("case", role).length + expectedIds("standalone", role).length])));
      assert.equal(selected.scopeCounts[scope], combined(selected).length);
      assert.equal(new Set(keys(combined(selected))).size, combined(selected).length);
      assert.deepEqual(plain(selected.counts), { 待接受: 16, 进行中: 16, 已完成: 16 });
      assert.equal(taskColumnFilterCount(selected.filters), Number(Boolean(mask & 1)) + Number(Boolean(mask & 2)) + Number(Boolean(mask & 4)));
      assert.equal(selected.filters.tfKey, ""); assert.equal(selected.filters.projectKey, "");
      assertReferences(combined(selected), rows);
      assert.equal(JSON.stringify(state), snapshot);
    }
  }
  assert.equal(JSON.stringify(rows), before);
});

test("explicit products filter exactly while historical TF/Project references and records remain intact without inferred related products", () => {
  const products = freeze([{ id: "p1", code: "DDR5", name: "产品一" }, { id: "p2", code: "LPDDR", name: "产品二" }]);
  const involvement = (kind, id, name) => ({ kind, id, name });
  const action = (id, direct) => ({ id, code: `EA-${id}`, title: id, owner: actor, supervisor: "刘洋", collaborators: [], status: "待接受", urgency: "一般",
    ...(direct ? { standaloneTaskContext: { involvement: direct } } : {}),
  });
  const cases = freeze([{ id: "c1", code: "CASE-1", name: "问题", productId: "p1", projectName: " 同名项目 ", status: "进行中", updatedAt: "2026-09-09", tasks: [
    action("inherited"), action("direct-product", involvement("产品", "p2", "产品二")),
    action("direct-tf", involvement("TF", "t1", "专项一")), action("direct-project", involvement("Project", "id:1", "同名项目")),
  ] }, { id: "project-only-case", code: "CASE-2", name: "DDR5 同名项目", projectName: "同名项目", status: "进行中", updatedAt: "2026-09-09", tasks: [
    action("project-only-case", involvement("TF", "t1", "专项一")),
  ] }]);
  const tasks = freeze([
    ["product", involvement("产品", "p1", "产品一")], ["tf", involvement("TF", "t1", "专项一")],
    ["project", involvement("Project", "id:1", "同名项目")], ["none", undefined],
  ].map(([id, involvement]) => ({ id, code: `TASK-${id}`, title: `DDR5 同名项目 ${id}`, description: "专项一", owner: actor, createdBy: "刘洋", collaborators: [], status: "待接受", urgency: "一般", updatedAt: "2026-09-09", attachments: [], involvement })));
  const before = JSON.stringify([products, cases, tasks]);
  const rows = freeze(buildRows(cases, tasks, { products }));
  const rowSnapshot = JSON.stringify(rows);
  assert.deepEqual(plain(rows.find(item => item.id === "direct-tf").business), [
    { key: "TF:t1", kind: "TF", name: "专项一", origin: "task" },
    { key: "产品:p1", kind: "产品", name: "DDR5 · 产品一", origin: "case" },
    { key: "Project:name:同名项目", kind: "Project", name: "同名项目", origin: "case", nameOnly: true },
  ]);
  assert.deepEqual(plain(rows.find(item => item.id === "direct-product").business.map(item => [item.key, item.origin])), [["产品:p2", "task"], ["产品:p1", "case"], ["Project:name:同名项目", "case"]]);
  assert.deepEqual(plain(rows.find(item => item.id === "direct-project").business), [
    { key: "Project:id:1", kind: "Project", name: "同名项目", origin: "task" },
    { key: "产品:p1", kind: "产品", name: "DDR5 · 产品一", origin: "case" },
  ]);
  assert.deepEqual(plain(rows.find(item => item.id === "project-only-case").business), [
    { key: "TF:t1", kind: "TF", name: "专项一", origin: "task" },
    { key: "Project:name:同名项目", kind: "Project", name: "同名项目", origin: "case", nameOnly: true },
  ]);
  for (const item of rows) assert.equal(item.record, item.source === "case" ? item.caseItem.tasks.find(task => task.id === item.id) : tasks.find(task => task.id === item.id));
  for (const [id, key, kind, name] of [["tf", "TF:t1", "TF", "专项一"], ["project", "Project:id:1", "Project", "同名项目"]]) {
    assert.deepEqual(plain(rows.find(item => item.id === id).business), [{ key, kind, name, origin: "task" }]);
  }
  assert.deepEqual(plain(rows.find(item => item.id === "none").business), []);
  const allCases = ["inherited", "direct-product", "direct-tf", "direct-project", "project-only-case"];
  const productCases = ["inherited", "direct-product", "direct-tf", "direct-project"];
  const allTasks = ["product", "tf", "project", "none"];
  const scenarios = [
    [{}, allCases, allTasks],
    [{ productKey: "产品:p1" }, productCases, ["product"]],
    [{ productKey: "产品:p2" }, ["direct-product"], []],
    [{ tfKey: "TF:t1" }, allCases, allTasks],
    [{ projectKey: "Project:name:同名项目" }, allCases, allTasks],
    [{ projectKey: "Project:id:1" }, allCases, allTasks],
    [{ tfKey: "TF:missing", projectKey: "Project:missing" }, allCases, allTasks],
    [{ productKey: "产品:p1", tfKey: "TF:t1" }, productCases, ["product"]],
    [{ productKey: "产品:p1", projectKey: "Project:name:同名项目" }, productCases, ["product"]],
    [{ tfKey: "TF:t1", projectKey: "Project:name:同名项目" }, allCases, allTasks],
    [{ productKey: "产品:p1", tfKey: "TF:t1", projectKey: "Project:name:同名项目" }, productCases, ["product"]],
    [{ productKey: "产品:p1", projectKey: "Project:id:1" }, productCases, ["product"]],
    [{ productKey: "产品:p2", tfKey: "TF:t1", projectKey: "Project:name:同名项目" }, ["direct-product"], []],
    [{ productKey: "产品:missing", tfKey: "TF:t1", projectKey: "Project:id:1" }, [], []],
    [{ productKey: "产品:p1", caseId: "project-only-case", creator: "刘洋" }, [], ["product"]],
  ];
  for (const [patch, left, right] of scenarios) {
    const state = freeze(stateFor("待接受", patch)); const snapshot = JSON.stringify(state);
    const selected = select(rows, state, actor, now);
    assert.deepEqual(ids(selected.caseRows).sort(), [...left].sort());
    assert.deepEqual(ids(selected.standaloneRows).sort(), [...right].sort());
    assert.deepEqual(plain(selected.counts), { 待接受: 9, 进行中: 0, 已完成: 0 });
    assert.deepEqual(plain(selected.scopeCounts), { mine: left.length + right.length, assigned: 0, participating: 0 });
    assert.equal(selected.filters.tfKey, ""); assert.equal(selected.filters.projectKey, "");
    assertReferences(combined(selected), rows);
    const cleared = update(state, { type: "reset" });
    assert.deepEqual(ids(select(rows, cleared, actor, now).caseRows).sort(), [...allCases].sort());
    assert.deepEqual(ids(select(rows, cleared, actor, now).standaloneRows).sort(), [...allTasks].sort());
    assert.equal(JSON.stringify(state), snapshot);
  }
  assert.equal(JSON.stringify(rows), rowSnapshot);
  assert.equal(JSON.stringify([products, cases, tasks]), before);
});

test("product requires its own kind and exact key, never matches names or prefixes, and stale TF/Project cannot restrict results", () => {
  const references = [
    ["product", { key: "产品:p1", kind: "产品", name: "同名", origin: "case" }],
    ["product-prefix", { key: "产品:p10", kind: "产品", name: "同名", origin: "task" }],
    ["tf", { key: "TF:t1", kind: "TF", name: "同名", origin: "task" }],
    ["project-name", { key: "Project:name:同名项目", kind: "Project", name: "同名项目", origin: "case", nameOnly: true }],
    ["project-id", { key: "Project:id:1", kind: "Project", name: "同名项目", origin: "task" }],
    ["wrong-product-kind", { key: "产品:p1", kind: "TF", name: "同名", origin: "task" }],
    ["wrong-tf-kind", { key: "TF:t1", kind: "Project", name: "同名", origin: "task" }],
    ["wrong-project-kind", { key: "Project:id:1", kind: "产品", name: "同名项目", origin: "task" }],
  ];
  const rows = freeze(sources.flatMap(source => references.map(([id, reference]) => row(id, "待接受", source, { title: "产品:p1 TF:t1 同名项目", business: [reference] }))));
  const before = JSON.stringify(rows);
  const allIds = references.map(([id]) => id).sort();
  for (const [patch, expected] of [
    [{ productKey: "产品:p1" }, ["product"]], [{ productKey: "产品:p10" }, ["product-prefix"]],
    [{ tfKey: "TF:t1" }, allIds],
    [{ projectKey: "Project:name:同名项目" }, allIds], [{ projectKey: "Project:id:1" }, allIds],
    [{ productKey: "TF:t1" }, []], [{ tfKey: "产品:p1" }, allIds],
    [{ productKey: "产品:p" }, []], [{ productKey: " 产品:p1 " }, []],
    [{ productKey: "同名" }, []], [{ productKey: "Project:name:同名项目" }, []],
    [{ projectKey: "同名项目" }, allIds], [{ projectKey: "Project:id:10" }, allIds],
    [{ productKey: "产品:p1", tfKey: "TF:t1", projectKey: "Project:id:1" }, ["product"]],
    [{ productKey: "产品:p1", tfKey: "TF:missing", projectKey: "Project:missing" }, ["product"]],
  ]) {
    const selected = select(rows, stateFor("待接受", patch), actor, now);
    assert.deepEqual(ids(selected.caseRows).sort(), expected);
    assert.deepEqual(ids(selected.standaloneRows).sort(), expected);
    assert.deepEqual(plain(selected.counts), { 待接受: 16, 进行中: 0, 已完成: 0 });
    assert.equal(selected.filters.tfKey, ""); assert.equal(selected.filters.projectKey, "");
    assertReferences(combined(selected), rows);
  }
  assert.equal(JSON.stringify(rows), before);
});

test("empty AND results retain product/Case/creator and resetting one populated status leaves the other two snapshots intact without restoring TF/Project", () => {
  let state = create();
  for (const [i, status] of statuses.entries()) {
    state = update(state, { type: "status", status });
    state = update(state, { type: "column-filters", patch: { scope: scopes[i], productKey: `产品:p${i}`, tfKey: `TF:t${i}`, projectKey: `Project:project${i}`, caseId: `case-${i}`, creator: `creator-${i}` } });
    state = update(state, { type: "business" });
    assert.equal(state.views[status].filters.tfKey, ""); assert.equal(state.views[status].filters.projectKey, "");
  }
  freeze(state);
  const before = JSON.stringify(state);
  for (const status of statuses) {
    const active = update(state, { type: "status", status });
    for (const rows of [freeze([]), relationRows()]) {
      const selected = select(rows, active, actor, now);
      assert.deepEqual(plain(combined(selected)), []);
      assert.deepEqual(plain(selected.scopeCounts), { mine: 0, participating: 0, assigned: 0 });
      assert.equal(selected.filters.status, status); assert.equal(taskColumnFilterCount(selected.filters), 3);
      const index = statuses.indexOf(status);
      assert.equal(selected.filters.productKey, `产品:p${index}`);
      assert.equal(selected.filters.caseId, `case-${index}`); assert.equal(selected.filters.creator, `creator-${index}`);
      assert.equal(selected.filters.tfKey, ""); assert.equal(selected.filters.projectKey, "");
      assert.deepEqual(plain(selected.counts), rows.length ? { 待接受: 10, 进行中: 10, 已完成: 10 } : { 待接受: 0, 进行中: 0, 已完成: 0 });
    }
    const reset = update(active, { type: "reset" });
    assert.equal(reset.status, status); assert.equal(reset.views[status].showBusiness, true);
    assert.equal(reset.views[status].filters.scope, active.views[status].filters.scope);
    assert.equal(taskColumnFilterCount(select([], reset, actor, now).filters), 0);
    for (const other of statuses.filter(value => value !== status)) {
      assert.equal(reset.views[other], state.views[other]);
      const restored = select([], update(reset, { type: "status", status: other }), actor, now);
      assert.equal(taskColumnFilterCount(restored.filters), 3);
      assert.equal(restored.filters.tfKey, ""); assert.equal(restored.filters.projectKey, "");
    }
  }
  assert.equal(JSON.stringify(state), before);
});