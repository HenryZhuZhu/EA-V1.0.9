import test from "node:test";
import assert from "node:assert/strict";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";
import vm from "node:vm";
import { build } from "esbuild";
import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { parseGIF, decompressFrames } from "gifuct-js";
import { AGENT_GIF_DELAY, AGENT_GIF_FRAMES, AGENT_GIF_SIZE, renderAgentFrame } from "../gen-agent-gif.mjs";

const { outputFiles } = await build({
  entryPoints: [fileURLToPath(new URL("../src/app/components/AgentMark.tsx", import.meta.url))],
  bundle: true, write: false, platform: "node", format: "cjs", jsx: "automatic",
  external: ["react", "react/jsx-runtime"],
});
const sandbox = { module: { exports: {} }, require: createRequire(import.meta.url) };
vm.runInNewContext(outputFiles[0].text, sandbox);
const { AgentMark } = sandbox.module.exports;

test("Agent entry is an embedded animated GIF without SVG filters or GPU canvas", () => {
  const html = renderToStaticMarkup(createElement(AgentMark, { className: "ea-agent-logo" }));
  assert.match(html, /class="ea-agent-orb ea-agent-logo" aria-hidden="true"/);
  assert.match(html, /<img src="data:image\/gif;base64,/);
  assert.match(html, /width="112" height="112" draggable="false"/);
  assert.match(html, /prefers-reduced-motion: reduce/);
  assert.doesNotMatch(html, /<svg|<canvas|<filter|<button|<script|<foreignObject|tabindex/i);
  assert.doesNotMatch(html, /M31 17v-4|M25 30v3M39 30v3|M28 42h8/);
});

test("all icon positions share the same offline GIF with a valid static reduced-motion image", () => {
  const html = renderToStaticMarkup(createElement("div", null,
    createElement(AgentMark, { className: "ea-agent-logo" }),
    createElement(AgentMark, { className: "ea-agent-nav-logo" }),
    createElement(AgentMark, { className: "ea-agent-header-logo" }),
    createElement(AgentMark, { className: "ea-agent-header-logo" }),
    createElement(AgentMark, { className: "ea-agent-welcome-orb" }),
  ));
  assert.equal((html.match(/class="ea-agent-orb /g) ?? []).length, 5);
  const images = [...html.matchAll(/<img src="data:image\/gif;base64,([^"]+)"/g)];
  assert.equal(images.length, 5); assert.equal(new Set(images.map(match => match[1])).size, 1);
  const bytes = Buffer.from(images[0][1], "base64");
  assert.equal(bytes.subarray(0, 6).toString(), "GIF89a"); assert.equal(bytes.readUInt16LE(6), AGENT_GIF_SIZE); assert.equal(bytes.readUInt16LE(8), AGENT_GIF_SIZE);
  assert.equal(AGENT_GIF_SIZE, 224); assert.equal(AGENT_GIF_FRAMES, 240); assert.equal(AGENT_GIF_DELAY, 40);
  assert.ok(bytes.length < 3200000); assert.ok(bytes.includes(Buffer.from("NETSCAPE2.0")));
  const poster = /srcSet="data:image\/gif;base64,([^"]+)"/.exec(html);
  assert.ok(poster); assert.ok(Buffer.from(poster[1], "base64").length < bytes.length);
});

test("the GIF palette retains both cyan-blue and violet from the previous glass icon", () => {
  const html = renderToStaticMarkup(createElement(AgentMark));
  const encoded = /<img src="data:image\/gif;base64,([^"]+)"/.exec(html)[1];
  const bytes = Buffer.from(encoded, "base64");
  assert.ok(bytes[10] & 128);
  const count = 2 ** ((bytes[10] & 7) + 1);
  const palette = Array.from({ length: count }, (_, index) => [...bytes.subarray(13 + index * 3, 16 + index * 3)]);
  assert.ok(palette.filter(([red, green, blue]) => green > red + 30 && blue > red + 30).length >= 3, "Cyan highlights must remain visible");
  assert.ok(palette.filter(([red, green, blue]) => red > green + 15 && blue > red + 25).length >= 3, "Violet must not collapse into a monochrome blue palette");
});

test("all GIF frames preserve original artwork colors and luminance instead of darkening the icon", () => {
  const html = renderToStaticMarkup(createElement(AgentMark));
  const bytes = Buffer.from(/<img src="data:image\/gif;base64,([^"]+)"/.exec(html)[1], "base64");
  const frames = decompressFrames(parseGIF(bytes), true);
  assert.equal(frames.length, AGENT_GIF_FRAMES);
  assert.ok(frames.every(frame => frame.delay === AGENT_GIF_DELAY));
  assert.equal(new Set(frames.map(frame => Buffer.from(frame.patch).toString("base64"))).size, AGENT_GIF_FRAMES);
  frames.forEach((frame, index) => {
    const original = renderAgentFrame(index);
    let error = 0; let luminance = 0; let count = 0;
    let darkInteriorPixels = 0;
    for (let offset = 0; offset < original.length; offset += 4) {
      if (!original[offset + 3]) { assert.equal(frame.patch[offset + 3], 0); continue; }
      if (original[offset + 3] !== 255) continue;
      assert.equal(frame.patch[offset + 3], 255);
      const column = offset / 4 % AGENT_GIF_SIZE;
      const row = Math.floor(offset / 4 / AGENT_GIF_SIZE);
      const brightness = frame.patch[offset] * .2126 + frame.patch[offset + 1] * .7152 + frame.patch[offset + 2] * .0722;
      if ((column - AGENT_GIF_SIZE / 2) ** 2 + (row - AGENT_GIF_SIZE / 2) ** 2 <= (AGENT_GIF_SIZE * 39 / 112) ** 2 && brightness < 70) darkInteriorPixels++;
      for (const [channel, weight] of [0.2126, 0.7152, 0.0722].entries()) {
        const delta = frame.patch[offset + channel] - original[offset + channel];
        error += Math.abs(delta); luminance += delta * weight;
      }
      count++;
    }
    assert.ok(count > 20000);
    assert.ok(darkInteriorPixels < 60, `Frame ${index}: unexpected dark block (${darkInteriorPixels} pixels)`);
    assert.ok(error / count / 3 < 4, `Frame ${index}: color drift`);
    assert.ok(Math.abs(luminance / count) < 1, `Frame ${index}: brightness drift`);
  });
  const poster = Buffer.from(/srcSet="data:image\/gif;base64,([^"]+)"/.exec(html)[1], "base64");
  const stillFrames = decompressFrames(parseGIF(poster), true);
  assert.equal(stillFrames.length, 1);
  assert.deepEqual(stillFrames[0].patch, frames[0].patch);
});