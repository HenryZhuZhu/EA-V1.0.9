import assert from "node:assert/strict";
import test from "node:test";
import { build } from "esbuild";
import { fileURLToPath } from "node:url";
import vm from "node:vm";

const { outputFiles } = await build({
  entryPoints: [fileURLToPath(new URL("../src/app/components/taskWorkbenchState.ts", import.meta.url))],
  bundle: true, write: false, platform: "node", format: "cjs", external: ["./data"],
});
const sandbox = { module: { exports: {} }, require: name => { if (name === "./data") return {}; throw new Error(name); } };
vm.runInNewContext(outputFiles[0].text, sandbox);
const { createTaskWorkbenchState: create, updateTaskWorkbenchState: update, selectTaskWorkbenchViews: select, paginateTaskWorkbench: paginate, canFilterWorkbenchCases: canFilterCases } = sandbox.module.exports;
const plain = value => JSON.parse(JSON.stringify(value));
const statuses = ["待接受", "进行中", "已完成"];
const row = (id, status, patch = {}) => ({ key: id, id, title: id, source: "standalone", status, owner: "张伟", creator: "李娜", participants: [], business: [], urgency: "一般", updatedAt: "2026-09-01T10:00:00Z", ...patch });

test("Case selector remains present for every relation and status in the Case tab", () => {
  const filters = create().views.待接受.filters;
  for (const source of ["all", "standalone", "case"]) {
    for (const status of statuses) {
      for (const scope of ["mine", "assigned", "participating"]) {
        assert.equal(canFilterCases({ ...filters, source, status, scope }), source === "case");
        assert.equal(canFilterCases({ ...filters, source, status, scope, caseId: "old" }), source === "case");
      }
    }
  }
});

test("legacy Case filters outside Case tab cannot restrict tasks or reappear after tab navigation", () => {
  const rows = [row("independent", "待接受"), row("case", "待接受", { source: "case", caseItem: { id: "c" } })];
  for (const source of ["all", "standalone"]) {
    const initial = create();
    const state = { ...initial, views: { ...initial.views, 待接受: { ...initial.views.待接受, filters: { ...initial.views.待接受.filters, source, caseId: "missing" } } } };
    const before = JSON.stringify(state);
    const selected = select(rows, state, "张伟");
    assert.equal(selected.filters.caseId, "");
    assert.equal(selected.selection.taskCount, source === "all" ? 2 : 1);
    assert.equal(JSON.stringify(state), before);
  }
  let state = update(create(), { type: "source", source: "case" });
  state = update(state, { type: "filters", patch: { caseId: "c", creator: "李娜" } });
  for (const source of ["all", "standalone"]) {
    const switched = update(state, { type: "source", source });
    assert.equal(switched.views.待接受.filters.caseId, "");
    assert.equal(switched.views.待接受.filters.creator, "李娜");
    assert.equal(update(switched, { type: "source", source: "case" }).views.待接受.filters.caseId, "");
  }
});

test("creator filter still finds a named person's assignments within source and personal responsibility", () => {
  for (const status of statuses) {
    const rows = [
      row("own-independent", status),
      row("own-case", status, { source: "case", caseItem: { id: "c" } }),
      row("other-creator", status, { creator: "刘洋" }),
      row("other-owner", status, { owner: "王强", participants: ["张伟"] }),
    ];
    const baseline = JSON.stringify(rows);
    let state = update(create(), { type: "status", status });
    state = update(state, { type: "filters", patch: { creator: "李娜" } });
    assert.deepEqual(plain(select(rows, state, "张伟").selection.rows.map(r => r.id)), ["own-independent", "own-case"]);
    state = update(state, { type: "source", source: "case" });
    assert.deepEqual(plain(select(rows, state, "张伟").selection.rows.map(r => r.id)), ["own-case"]);
    assert.equal(select(rows, state, "张伟").counts[status], 3);
    state = update(state, { type: "reset" });
    assert.equal(state.views[status].filters.source, "case");
    assert.equal(state.views[status].filters.scope, "mine");
    assert.equal(state.views[status].filters.creator, "");
    assert.equal(JSON.stringify(rows), baseline);
  }
});

test("flat list always uses state-default sorting across pages regardless of legacy display preferences", () => {
  const now = new Date("2026-09-10T12:00:00Z");
  for (const status of statuses) {
    const rows = Array.from({ length: 12 }, (_, i) => row(String(i).padStart(2, "0"), status, {
      urgency: ["不紧急", "一般", "紧急", "非常紧急"][i % 4],
      dueDate: `2026-09-${String(12 - i).padStart(2, "0")}`,
      updatedAt: `2026-09-${String((i * 5) % 12 + 1).padStart(2, "0")}T10:00:00Z`,
      source: i % 2 ? "case" : "standalone", caseItem: i % 2 ? { id: `c${i}` } : undefined,
    }));
    const priority = { 非常紧急: 0, 紧急: 1, 一般: 2, 不紧急: 3 };
    const expected = [...rows].sort((a, b) => status === "待接受"
      ? priority[a.urgency] - priority[b.urgency] || a.dueDate.localeCompare(b.dueDate)
      : status === "进行中" ? a.dueDate.localeCompare(b.dueDate) : b.updatedAt.localeCompare(a.updatedAt)).map(r => r.key);
    const before = JSON.stringify(rows);
    for (const sortBy of ["priority", "due", "updated"]) {
      for (const groupBy of ["none", "case", "owner", "business", "due"]) {
        let state = update(create(), { type: "status", status });
        state = update(state, { type: "group", groupBy });
        state = update(state, { type: "sort", sortBy });
        const seen = [];
        for (const page of [1, 2]) {
          state = update(state, { type: "page", page });
          const result = paginate(rows, state, now);
          assert.equal(result.groups.length, 1);
          assert.equal(result.groups[0].key, "all");
          assert.equal(result.total, 12);
          assert.equal(result.pages, 2);
          assert.equal(result.groups[0].rows.length, page === 1 ? 8 : 4);
          for (const r of result.groups[0].rows) { assert.equal(r, rows.find(original => original.key === r.key)); seen.push(r.key); }
        }
        assert.deepEqual(seen, expected);
        assert.equal(new Set(seen).size, 12);
      }
    }
    assert.equal(JSON.stringify(rows), before);
  }
});