import assert from "node:assert/strict";
import { webcrypto } from "node:crypto";
import { fileURLToPath } from "node:url";
import vm from "node:vm";
import test from "node:test";
import { build } from "esbuild";

// Exercise the real task/domain/tree stores without browser storage or React rendering.
const { outputFiles } = await build({
  stdin: {
    contents: `export * from './src/app/components/standaloneTasks.ts';
      export * from './src/app/components/standaloneTaskConfig.ts';
      export { allProjects, caseByStandaloneTask } from './src/app/components/domainStore.ts';
      export { currentUser, departments, departmentSupervisors, ownerToDepartment, PROBLEM_DOMAINS, PROBLEM_TYPES, mockProducts, flattenTasks, mockCases } from './src/app/components/data.ts';
      export { respondToCaseTask, loadCaseTaskTree, saveCaseTaskTree, updateCaseTask, commentOnCaseTask, caseReworkDisabledReason, returnCaseTaskForRework } from './src/app/components/caseTaskTrees.ts';
      export * from './src/app/components/taskRework.ts';
      export * from './src/app/components/taskVisibility.ts';
      export * from './src/app/components/taskActivity.ts';`,
    resolveDir: fileURLToPath(new URL("../", import.meta.url)),
  },
  bundle: true, write: false, platform: "node", format: "cjs",
  plugins: [{ name: "react-hooks", setup(builder) {
    builder.onResolve({ filter: /^react$/ }, () => ({ path: "react", namespace: "test" }));
    builder.onLoad({ filter: /.*/, namespace: "test" }, () => ({ contents: "export const useEffect=()=>{}; export const useState=()=>[0,()=>{}];" }));
  } }],
});
const TASKS_KEY = "ea_standalone_tasks_v1";
const DOMAIN_KEY = "ea_domain_v6";
const plain = (value) => JSON.parse(JSON.stringify(value));
function fixture(id, extra = {}) {
  return {
    id, code: `TASK-TEST-${id}`, title: `测试任务 ${id}`, description: `任务说明 ${id}`,
    owner: "张伟", createdBy: "李娜", createdForOther: true,
    collaborators: [{ name: "周杰", department: "PTE" }], urgency: "紧急", dueDate: "2026-09-20",
    attachments: [{ name: `${id}.txt`, kind: "file", url: "data:text/plain;base64,dGVzdA==" }],
    voiceNote: "data:audio/webm;base64,dGVzdA==", status: "待接受",
    createdAt: "2026-09-07T08:00:00.000Z", updatedAt: "2026-09-07T08:00:00.000Z", ...extra,
  };
}
function environment(tasks = []) {
  const storage = new Map([[TASKS_KEY, JSON.stringify(tasks)]]);
  let failingKey;
  const boot = () => {
    const context = { module: { exports: {} }, crypto: webcrypto, btoa, atob, localStorage: {
      getItem: (key) => storage.get(key) ?? null,
      setItem: (key, value) => { if (key === failingKey) throw new Error("quota"); storage.set(key, value); },
    } };
    vm.runInNewContext(outputFiles[0].text, context);
    const api = context.module.exports;
    api.useStandaloneTasks();
    return api;
  };
  return { boot, storage, fail: (key) => { failingKey = key; } };
}
const actions = (api, c) => api.flattenTasks(c.tasks).map(({ task }) => task).filter((task) => task.code);

const newTaskInput = (extra = {}) => ({ title: "基础信息回归", description: "检查字段与自动分派", creationMode: "advanced", owner: "", handlingDepartment: "PTE", createdForOther: false, collaborators: [], urgency: "一般", dueDate: "2026-09-20", attachments: [], involvement: "无", ...extra });

const addedExampleIds = Array.from({ length: 6 }, (_, index) => `standalone-example-v108-${index + 6}`);

const editInput = (task, patch = {}) => ({
  title: task.title, description: task.description, owner: task.owner,
  creationMode: task.creationMode ?? "simple", assignmentMethod: task.assignmentMethod,
  handlingDepartment: task.handlingDepartment, problemDomain: task.problemDomain, problemType: task.problemType,
  involvement: task.involvement?.kind ?? "无", involvementId: task.involvement?.id,
  visibilityType: task.visibility?.type ?? "all", visiblePeople: task.visibility?.people ?? [],
  createdForOther: task.createdForOther, collaborators: task.collaborators.map(person => person.name),
  urgency: task.urgency, dueDate: task.dueDate, attachments: task.attachments, voiceNote: task.voiceNote, ...patch,
});

test("editing updates the same task with audit history and preserves results, comments, identities and other tasks", () => {
  const original = fixture("edit", { status: "进行中", conclusion: "已有结论", analysisProcess: "过程", resultAttachments: [{ name: "结果.txt", kind: "file" }], comments: [{ id: "comment", user: "李娜", time: "2026-09-10", content: "保留" }], activityLog: [{ id: "old", kind: "create", at: "2026-09-07", by: "李娜", summary: "原记录", changes: [] }] });
  const env = environment([original, fixture("untouched")]); const api = env.boot();
  const before = plain(api.standaloneTaskById("edit")); const total = JSON.parse(env.storage.get(TASKS_KEY)).length;
  const updated = api.editStandaloneTask("edit", editInput(before, { title: "编辑后的任务", description: "新说明", visibilityType: "partial", visiblePeople: ["周杰"] }), before);
  assert.equal(updated.id, original.id); assert.equal(updated.code, original.code); assert.equal(updated.createdBy, original.createdBy);
  for (const key of ["status", "createdAt", "conclusion", "analysisProcess", "resultAttachments", "comments", "attachments", "voiceNote"]) assert.deepEqual(plain(updated[key]), original[key], key);
  assert.equal(updated.activityLog.length, 2); assert.equal(updated.activityLog[0].id, "old");
  assert.equal(updated.activityLog[1].summary, "编辑自由任务"); assert.ok(updated.activityLog[1].changes.some(change => change.field === "可见范围"));
  assert.equal(JSON.parse(env.storage.get(TASKS_KEY)).length, total);
  assert.deepEqual(plain(api.standaloneTaskById("untouched")), fixture("untouched"));
  assert.equal(env.boot().standaloneTaskById("edit").title, "编辑后的任务");
});

test("unchanged editing and unchanged historical product or TF references do not manufacture updates", () => {
  for (const extra of [{}, { creationMode: "advanced", assignmentMethod: "department", handlingDepartment: "旧部门", involvement: { kind: "TF", id: "old-tf", name: "原专项" } }, { involvement: { kind: "产品", id: "removed-product", name: "旧产品" } }]) {
    const env = environment([fixture("noop", extra)]); const api = env.boot(); const before = api.standaloneTaskById("noop");
    const storage = env.storage.get(TASKS_KEY);
    assert.equal(api.editStandaloneTask("noop", editInput(before), plain(before)), before);
    assert.equal(env.storage.get(TASKS_KEY), storage);
  }
});

test("editing enforces owner or creator, live status, source conversion and unchanged snapshot", () => {
  for (const patch of [{ owner: "别人", createdBy: "别人" }, { status: "已完成" }, { status: "已拒绝" }, { status: "已中止" }, { convertedCaseId: "case" }]) {
    const env = environment([fixture("blocked", patch)]); const api = env.boot(); const task = api.standaloneTaskById("blocked"); const storage = env.storage.get(TASKS_KEY);
    assert.ok(api.standaloneTaskEditDisabledReason(task));
    assert.throws(() => api.editStandaloneTask(task.id, editInput(task, { title: "不应保存" }), task));
    assert.equal(env.storage.get(TASKS_KEY), storage);
  }
  const env = environment([fixture("stale")]); const api = env.boot(); const old = plain(api.standaloneTaskById("stale"));
  api.commentOnStandaloneTask("stale", "并发评论"); const storage = env.storage.get(TASKS_KEY);
  assert.throws(() => api.editStandaloneTask("stale", editInput(old), old), /任务已更新/);
  assert.equal(env.storage.get(TASKS_KEY), storage);
  assert.throws(() => api.editStandaloneTask("missing", editInput(old), old), /不存在/);
});

test("reassignment returns to pending without discarding results and creator can edit an assigned task", () => {
  const env = environment([fixture("reassign", { status: "进行中", conclusion: "保留" }), fixture("creator", { owner: "周杰", createdBy: "张伟" })]); const api = env.boot();
  const task = api.standaloneTaskById("reassign");
  const updated = api.editStandaloneTask(task.id, editInput(task, { owner: "李娜" }), plain(task));
  assert.equal(updated.status, "待接受"); assert.equal(updated.owner, "李娜"); assert.equal(updated.conclusion, "保留");
  assert.ok(updated.activityLog.at(-1).changes.some(change => change.field === "状态"));
  const created = api.standaloneTaskById("creator");
  assert.equal(api.editStandaloneTask(created.id, editInput(created, { description: "创建人修改" }), plain(created)).description, "创建人修改");
});

test("edit validation and storage failure are atomic and retry creates only one edit event", () => {
  const env = environment([fixture("failure")]); const api = env.boot(); const task = api.standaloneTaskById("failure"); const storage = env.storage.get(TASKS_KEY);
  for (const patch of [{ title: " " }, { description: "" }, { owner: "" }, { urgency: "未知" }, { dueDate: "2026-02-31" }, { visibilityType: "partial", visiblePeople: [] }, { involvement: "产品", involvementId: "invalid" }]) {
    assert.throws(() => api.editStandaloneTask(task.id, editInput(task, patch), plain(task)));
    assert.equal(env.storage.get(TASKS_KEY), storage); assert.equal(api.standaloneTaskById(task.id), task);
  }
  env.fail(TASKS_KEY);
  assert.throws(() => api.editStandaloneTask(task.id, editInput(task, { title: "重试成功" }), plain(task)), /未能保存/);
  assert.equal(env.storage.get(TASKS_KEY), storage); assert.equal(api.standaloneTaskById(task.id), task);
  env.fail(undefined);
  assert.equal(api.editStandaloneTask(task.id, editInput(task, { title: "重试成功" }), plain(task)).activityLog.length, 1);
});

test("free task terminology updates new copy without rewriting historical independent-task user content", () => {
  const original = fixture("terminology", {
    title: "用户命名的独立任务", description: "原始独立任务说明", status: "进行中",
    activityLog: [{ id: "legacy-event", kind: "create", at: "2026-09-07T08:00:00.000Z", by: "张伟", summary: "创建独立任务", changes: [] }],
  });
  const env = environment([original]); const api = env.boot();
  assert.deepEqual(plain(api.standaloneTaskById(original.id)), original);
  assert.throws(() => api.upgradeStandaloneTasksToCase([]), /请至少选择一条自由任务/);
  assert.throws(() => api.saveStandaloneTaskWorkspace("missing", { conclusion: "", analysisProcess: "" }), /自由任务/);
  const c = api.upgradeStandaloneTaskToCase(original.id);
  assert.equal(c.tasks[0].title, "带入的自由任务");
  const imported = actions(api, c)[0];
  assert.equal(imported.title, original.title);
  assert.equal(imported.expectation, original.description);
  assert.equal(imported.sourceStandaloneTaskId, original.id);
  assert.equal(imported.status, original.status);
  assert.equal(imported.activityLog[0].summary, "创建独立任务");
  assert.equal(imported.activityLog.at(-1).summary, "从自由任务带入 Case");
  const saved = env.storage.get(TASKS_KEY); const reloaded = env.boot();
  assert.equal(env.storage.get(TASKS_KEY), saved);
  assert.equal(reloaded.standaloneTaskById(original.id).title, original.title);
  assert.equal(reloaded.standaloneTaskById(original.id).convertedCaseId, c.id);
});

test("additional daily examples seed three pending and three active tasks assigned to the current user", () => {
  const env = environment(); const api = env.boot();
  const added = addedExampleIds.map((id) => api.standaloneTaskById(id));
  assert.equal(added.filter((task) => task.status === "待接受").length, 3);
  assert.equal(added.filter((task) => task.status === "进行中").length, 3);
  for (const task of added) {
    assert.equal(task.owner, api.currentUser.name);
    assert.equal(task.createdForOther, task.status === "待接受");
    assert.equal(task.convertedCaseId, undefined);
    assert.equal(task.activityLog, undefined); // Initial example states are not fabricated user actions.
    assert.ok(task.title && task.description && task.dueDate);
    assert.ok(new Date(`${task.dueDate}T23:59:59`).getTime() > Date.parse(task.createdAt));
    assert.ok(task.collaborators.every((person) => person.name !== task.owner && person.department !== "—"));
  }
  assert.equal(new Set(added.map((task) => task.code)).size, 6);
  assert.equal(api.standaloneTaskById("standalone-example-v108-1").title, "周例会材料整理");
  assert.equal(api.standaloneTaskById("standalone-example-v108-5").title, "本周工作记录归档");
});

test("example backfill preserves existing user records and edited or upgraded examples across reloads", () => {
  const originals = [fixture("user-task", { status: "进行中", analysisProcess: "保留用户记录" }),
    fixture("standalone-example-v108-1", { status: "已完成", convertedCaseId: "existing-case", conclusion: "已处理" }),
    fixture(addedExampleIds[0], { status: "已拒绝", rejectReason: "保留已拒绝状态", comments: [{ id: "old-comment", user: "张伟", content: "保留评论", time: "2026-09-08T00:00:00Z" }] }),
  ];
  const env = environment(originals); const api = env.boot();
  for (const task of originals) assert.deepEqual(plain(api.standaloneTaskById(task.id)), task);
  const saved = env.storage.get(TASKS_KEY);
  const reload = env.boot();
  assert.equal(env.storage.get(TASKS_KEY), saved);
  for (const id of addedExampleIds) assert.equal(JSON.parse(saved).filter((task) => task.id === id).length, 1);
  for (const task of originals) assert.deepEqual(plain(reload.standaloneTaskById(task.id)), task);
});

test("new examples support real task actions without reseeding their processed states", () => {
  const env = environment(); const api = env.boot();
  api.updateStandaloneTaskStatus(addedExampleIds[0], "进行中");
  api.updateStandaloneTaskStatus(addedExampleIds[1], "已拒绝", "排期需调整");
  api.saveStandaloneTaskWorkspace(addedExampleIds[3], { conclusion: "目录已整理", analysisProcess: "已核对目录索引" });
  api.completeStandaloneTask(addedExampleIds[3], { conclusion: "目录已整理" });
  api.terminateStandaloneTask(addedExampleIds[4], "说明已合并至其他文档");
  const c = api.upgradeStandaloneTaskToCase(addedExampleIds[5]);
  const saved = env.storage.get(TASKS_KEY); const reload = env.boot();
  assert.equal(env.storage.get(TASKS_KEY), saved);
  assert.equal(reload.standaloneTaskById(addedExampleIds[0]).status, "进行中");
  assert.equal(reload.standaloneTaskById(addedExampleIds[1]).rejectReason, "排期需调整");
  assert.equal(reload.standaloneTaskById(addedExampleIds[2]).status, "待接受");
  assert.equal(reload.standaloneTaskById(addedExampleIds[3]).status, "已完成");
  assert.equal(reload.standaloneTaskById(addedExampleIds[3]).conclusion, "目录已整理");
  assert.equal(reload.standaloneTaskById(addedExampleIds[4]).status, "已中止");
  assert.equal(reload.standaloneTaskById(addedExampleIds[5]).convertedCaseId, c.id);
  assert.equal(reload.standaloneTaskById(addedExampleIds[5]).status, "进行中");
});

test("redo permission uses initiator OR owner's actual supervisor, not task department or owner alone", () => {
  const api=environment().boot();
  const task={owner:"张伟",initiator:"李娜",status:"已完成"};
  assert.equal(api.taskReworkDisabledReason(task,"李娜"),undefined);
  assert.equal(api.taskReworkDisabledReason(task,"周主管"),undefined);
  for(const actor of ["张伟","李主管","刘洋","林副总","无关人员"]) assert.match(api.taskReworkDisabledReason(task,actor),/发起人或负责人主管/);
  assert.equal(api.taskReworkDisabledReason({...task,initiator:"张伟"},"张伟"),undefined);
  assert.equal(api.taskReworkDisabledReason({owner:"周主管",initiator:"李娜",status:"已完成"},"高总监"),undefined);
  assert.match(api.taskReworkDisabledReason({owner:"周主管",initiator:"李娜",status:"已完成"},"周主管"),/发起人/);
  assert.match(api.taskReworkDisabledReason({owner:"未知负责人",status:"已完成"},"林副总"),/发起人/);
  for(const status of ["待接受","进行中","已拒绝","已中止"]) assert.match(api.taskReworkDisabledReason({...task,status},"李娜"),/已完成/);
});

test("cancelled rework preserves completed task results, comments and historical reasons", () => {
  const source=fixture("redo",{status:"已完成",conclusion:"原结论",analysisProcess:"原过程",resultAttachments:[{name:"原结果.txt",kind:"file",url:"data:text/plain;base64,b2s="}],comments:[{id:"comment-old",user:"张伟",time:"2026-09-08T00:00:00Z",content:"原评论"}]});
  const env=environment([source,fixture("sibling")]);const api=env.boot();api.currentUser.name="李娜";
  const before = env.storage.get(TASKS_KEY);
  assert.match(api.standaloneReworkDisabledReason(source), /已取消/);
  for (const name of ["张伟", "李娜", "周主管"]) {
    api.currentUser.name = name;
    assert.throws(() => api.returnStandaloneTaskForRework("redo", "补充验证"), /已取消/);
  }
  assert.equal(env.storage.get(TASKS_KEY), before);
  assert.deepEqual(plain(env.boot().standaloneTaskById("redo")), source);
});

test("upgrade preparation is read only and allows only tasks owned by the actor, not merely created by them", () => {
  const env = environment([fixture("own"), fixture("assigned", { owner: "李娜", createdBy: "张伟" })]); const api = env.boot();
  const before = [...env.storage.entries()];
  const draft = api.prepareStandaloneTaskUpgrade(["own", "own"]);
  assert.deepEqual(plain(draft.sourceStandaloneTaskIds), ["own"]); assert.equal(draft.name, "测试任务 own");
  assert.match(draft.background, /任务说明 own/);
  assert.deepEqual([...env.storage.entries()], before);
  assert.equal(api.canUpgradeStandaloneTask(api.standaloneTaskById("assigned")), false);
  assert.throws(() => api.prepareStandaloneTaskUpgrade(["own", "assigned"]), /自己负责/);
  assert.throws(() => api.upgradeStandaloneTasksToCase(["own", "assigned"]), /自己负责/);
  assert.deepEqual([...env.storage.entries()], before);
});

test("new Case submission uses edited Case metadata and retains source documents plus newly added tasks", () => {
  const env = environment([fixture("own", { status: "已完成", conclusion: "保留结论" })]); const api = env.boot();
  const draft = api.prepareStandaloneTaskUpgrade(["own"]);
  const details = { name: "填写后的 Case", owner: "张伟", level: "L2", urgency: "紧急", dueDate: "2026-10-01", reason: "填写事由", background: "填写背景", impact: "填写影响", source: "手动", product: api.mockProducts[0].id, tasks: [{ id: "new-thought", title: "补充思路", owner: "待指派", department: "PTE", urgency: "一般", progress: 0, status: "待接受" }], caseAttachments: [{ name: "新增资料", kind: "file" }] };
  const created = api.upgradeStandaloneTasksToCase(draft.sourceStandaloneTaskIds, details);
  for (const key of ["name", "owner", "level", "urgency", "dueDate", "background", "impact"]) assert.equal(created[key], details[key]);
  assert.equal(actions(api, created)[0].conclusion, "保留结论"); assert.equal(actions(api, created)[0].status, "已完成");
  assert.ok(created.tasks.some(task => task.id === "new-thought")); assert.ok(created.caseAttachments.some(item => item.name === "新增资料"));
  assert.equal(api.upgradeStandaloneTasksToCase(draft.sourceStandaloneTaskIds, details).id, created.id);
});

test("upgraded and partially linked standalone sources cannot be returned", () => {
  const env=environment([fixture("linked",{status:"已完成"}),fixture("partial",{status:"已完成"})]);const api=env.boot();api.upgradeStandaloneTaskToCase("linked");env.fail(TASKS_KEY);assert.throws(()=>api.upgradeStandaloneTaskToCase("partial"));env.fail(undefined);api.currentUser.name="李娜";
  for(const id of ["linked","partial"])assert.throws(()=>api.returnStandaloneTaskForRework(id,"来源不得退回"),/已取消/);
});

test("Case redo permissions are enforced separately from ordinary edits and state transitions", () => {
  const env=environment([fixture("redo",{status:"已完成",conclusion:"原结论"})]);const api=env.boot();const c=api.upgradeStandaloneTaskToCase("redo");const task=actions(api,c)[0];
  assert.throws(()=>api.returnCaseTaskForRework(c.id,task.id,"负责人本人"),/已取消/);
  assert.throws(()=>api.updateCaseTask(c.id,task.id,{status:"进行中",reworkReason:"绕过"}),/不支持/);
  const before = [...env.storage.entries()];
  for (const name of ["李娜", "周主管"]) { api.currentUser.name = name; assert.throws(() => api.returnCaseTaskForRework(c.id, task.id, "补充证据"), /已取消/); }
  assert.deepEqual([...env.storage.entries()], before);
  assert.equal(actions(env.boot(), env.boot().caseByStandaloneTask("redo"))[0].conclusion, "原结论");
});

test("current creation contract requires Domain/type product and discards hidden product and collaborator inputs", () => {
  const env = environment(); const api = env.boot(); const before = env.storage.get(TASKS_KEY);
  const input = newTaskInput({ productByAssignment: true, assignmentMethod: "domain-type", problemDomain: "Testing", problemType: "DFT" });
  assert.throws(() => api.createStandaloneTask(input), /必须选择关联产品/); assert.equal(env.storage.get(TASKS_KEY), before);
  assert.throws(() => api.createStandaloneTask({ ...input, involvement: "产品", involvementId: api.mockProducts[0].id, problemType: "Others" }), /暂无 KR 信息/);
  const product = api.mockProducts[0];
  const classified = api.createStandaloneTask({ ...input, involvement: "产品", involvementId: product.id, collaborators: ["李娜"] });
  assert.equal(classified.involvement.id, product.id); assert.deepEqual(plain(classified.collaborators), []);
  for (const creationMode of ["simple", "advanced"]) {
    const task = api.createStandaloneTask({ ...input, creationMode, assignmentMethod: "department", owner: "张伟", handlingDepartment: "PTE", involvement: "产品", involvementId: "invalid", collaborators: ["李娜"] });
    assert.deepEqual(plain(task.involvement), { kind: "无" }); assert.deepEqual(plain(task.collaborators), []);
  }
});

test("creation and real transitions append attributed activity with before/after states", () => {
  const env = environment([fixture("pending"), fixture("reject"), fixture("stop", { status: "进行中" })]); const api = env.boot();
  const created = api.createStandaloneTask(newTaskInput({ owner: "张伟" }));
  assert.equal(created.activityLog.length, 1); assert.equal(created.activityLog[0].kind, "create");
  assert.equal(created.activityLog[0].at, created.createdAt); assert.equal(created.activityLog[0].by, "张伟");
  assert.deepEqual(plain(created.activityLog[0].changes.find(c=>c.field === "状态")), { field: "状态", before: "未创建", after: "进行中" });
  assert.equal(api.standaloneTaskById("pending").activityLog, undefined);
  api.updateStandaloneTaskStatus("pending", "进行中");
  api.updateStandaloneTaskStatus("reject", "已拒绝", "  排期冲突  ");
  api.terminateStandaloneTask("stop", "需求取消");
  const reload = env.boot();
  for (const id of ["pending", "reject", "stop"]) {
    const log = reload.standaloneTaskById(id).activityLog;
    assert.equal(log.length, 1); assert.equal(log[0].by, "张伟"); assert.ok(Number.isFinite(Date.parse(log[0].at)));
  }
  assert.ok(reload.standaloneTaskById("reject").activityLog[0].changes.some(c=>c.field === "拒绝理由" && c.after === "排期冲突"));
  assert.ok(reload.standaloneTaskById("stop").activityLog[0].changes.some(c=>c.field === "中止原因" && c.after === "需求取消"));
});

test("Workspace logs real changes only; repeated save does not change time or duplicate logs", () => {
  const env = environment([fixture("doc", { status: "进行中" })]); const api = env.boot();
  const document = { conclusion: "阶段结论", analysisProcess: "1. 检查\n2. 复核", resultAttachments: [{ name: "结果.txt", kind: "file", url: "data:text/plain;base64,b2s=" }] };
  api.saveStandaloneTaskWorkspace("doc", document);
  const first = plain(api.standaloneTaskById("doc"));
  assert.deepEqual(first.activityLog[0].changes.map(c=>c.field), ["任务结论", "分析过程", "结果附件"]);
  assert.ok(!JSON.stringify(first.activityLog).includes("data:"));
  api.saveStandaloneTaskWorkspace("doc", document);
  assert.deepEqual(plain(api.standaloneTaskById("doc")), first);
  api.completeStandaloneTask("doc", { conclusion: document.conclusion });
  const saved = env.boot().standaloneTaskById("doc");
  assert.equal(saved.activityLog.length, 2); assert.equal(saved.activityLog[1].kind, "status");
  assert.deepEqual(plain(saved.activityLog[1].changes), [{ field: "状态", before: "进行中", after: "已完成" }]);
});

test("same-named replacement attachment logs content update without storing payload", () => {
  const env = environment([fixture("file", { status: "进行中", resultAttachments: [{ name: "结果.txt", kind: "file", url: "data:text/plain;base64,YQ==" }] })]); const api = env.boot();
  api.saveStandaloneTaskWorkspace("file", { conclusion: "", analysisProcess: "", resultAttachments: [{ name: "结果.txt", kind: "file", url: "data:text/plain;base64,Yg==" }] });
  const event = api.standaloneTaskById("file").activityLog[0];
  assert.ok(event.changes.some(c=>c.field === "结果附件" && c.after.includes("内容已更新")));
  assert.ok(!JSON.stringify(event).includes("base64"));
});

test("comments and replies persist, do not change task state, allow readers and completed discussions", () => {
  const env = environment([fixture("comment", { status: "已完成", owner: "李娜", createdBy: "周杰" }), fixture("other")]); const api = env.boot();
  const first = api.commentOnStandaloneTask("comment", "  第一行\n<script>not executed</script>  ");
  const comment = first.comments[0]; assert.equal(comment.user, "张伟");
  api.commentOnStandaloneTask("comment", "回复意见", comment.id);
  const saved = env.boot().standaloneTaskById("comment");
  assert.equal(saved.status, "已完成"); assert.equal(saved.owner, "李娜");
  assert.equal(saved.comments[0].content, "第一行\n<script>not executed</script>");
  assert.equal(saved.comments[0].replies[0].content, "回复意见");
  assert.deepEqual(saved.activityLog.map(e=>e.kind).join(","), "comment,comment");
  assert.equal(api.standaloneTaskById("other").comments, undefined);
});

test("invalid comments, missing replies and all failed writes leave neither phantom activity nor comment", () => {
  const env = environment([fixture("a", { status: "进行中" }), fixture("b")]); const api = env.boot(); const before = env.storage.get(TASKS_KEY);
  for (const content of ["", " \n ", "x".repeat(2001)]) assert.throws(()=>api.commentOnStandaloneTask("a", content));
  assert.throws(()=>api.commentOnStandaloneTask("a", "reply", "missing")); assert.throws(()=>api.commentOnStandaloneTask("missing", "comment"));
  env.fail(TASKS_KEY);
  for (const operation of [()=>api.commentOnStandaloneTask("a", "comment"), ()=>api.saveStandaloneTaskWorkspace("a", { conclusion:"更新", analysisProcess:"新内容" }), ()=>api.terminateStandaloneTask("a", "撤回"), ()=>api.updateStandaloneTaskStatus("b", "进行中")]) assert.throws(operation);
  assert.equal(env.storage.get(TASKS_KEY), before); assert.equal(api.standaloneTaskById("a").activityLog, undefined); assert.equal(api.standaloneTaskById("a").comments, undefined);
  env.fail(undefined); api.commentOnStandaloneTask("a", "重试成功"); assert.equal(env.boot().standaloneTaskById("a").comments.length, 1);
});

test("upgrade carries comments and logs, freezes sources, and retry never duplicates history", () => {
  const env = environment([fixture("a", { status: "进行中" }), fixture("b")]); const api = env.boot();
  api.saveStandaloneTaskWorkspace("a", { conclusion:"原结论", analysisProcess:"原过程" });
  const comment = api.commentOnStandaloneTask("a", "带入前讨论").comments[0]; api.commentOnStandaloneTask("a", "带入前回复", comment.id);
  env.fail(TASKS_KEY); assert.throws(()=>api.upgradeStandaloneTasksToCase(["a", "b"])); env.fail(undefined);
  assert.throws(()=>api.commentOnStandaloneTask("a", "不能在旧来源评论"), /已升级/);
  const c = api.upgradeStandaloneTasksToCase(["a", "b"]); const imported = actions(api,c)[0];
  assert.equal(imported.comments[0].replies[0].content, "带入前回复");
  assert.equal(imported.activityLog.filter(e=>e.kind === "upgrade").length, 1);
  assert.equal(imported.statusHistory.length, 0); // 原始任务未记录状态事件，不以更新时间伪造。
  const sourceLog = api.standaloneTaskById("a").activityLog;
  assert.equal(sourceLog.filter(e=>e.kind === "upgrade").length, 1);
  api.upgradeStandaloneTaskToCase("a"); assert.deepEqual(plain(api.standaloneTaskById("a").activityLog), plain(sourceLog));
  api.commentOnCaseTask(c.id, imported.id, "Case中的后续回复", comment.id);
  const reload = env.boot(); const restoredCase = reload.caseByStandaloneTask("a"); const inCase = actions(reload,{ ...restoredCase, tasks: reload.loadCaseTaskTree(restoredCase.id, restoredCase.tasks) })[0];
  assert.equal(inCase.comments[0].replies.length, 2); assert.equal(reload.standaloneTaskById("a").comments[0].replies.length, 1);
});

test("Case task edit/status/comment each persists an attributed event and preserves siblings", () => {
  const env = environment([fixture("a", { status:"进行中" }), fixture("b")]); const api=env.boot(); const c=api.upgradeStandaloneTasksToCase(["a","b"]); const [a,b]=actions(api,c);
  const edited=api.updateCaseTask(c.id,a.id,{ urgency:"非常紧急", conclusion:"Case结论", analysisProcess:"Case过程" });
  const edit=edited.activityLog.at(-1); assert.equal(edit.kind,"edit"); assert.equal(edit.by,"张伟"); assert.ok(edit.changes.some(c=>c.field==='紧急程度'&&c.before==='紧急'&&c.after==='非常紧急'));
  const snapshot=plain(api.loadCaseTaskTree(c.id,c.tasks));
  const first=api.commentOnCaseTask(c.id,a.id,"Case讨论").comments[0];
  api.commentOnCaseTask(c.id,a.id,"Case回复",first.id);
  // 普通Case编辑持有旧树时不丢弃已保存评论。
  api.saveCaseTaskTree(c.id,snapshot,true);
  let saved=api.loadCaseTaskTree(c.id,c.tasks); assert.equal(api.flattenTasks(saved).find(({task})=>task.id===a.id).task.comments[0].replies.length,1);
  const accepted=api.respondToCaseTask(c.id,b.id,"accept"); assert.equal(accepted.activityLog.at(-1).kind,"status");
  api.updateCaseTask(c.id,a.id,{status:"已完成",progress:100});
  const reload=env.boot(), restoredCase=reload.caseByStandaloneTask("a"), nodes=actions(reload,{ ...restoredCase, tasks: reload.loadCaseTaskTree(restoredCase.id, restoredCase.tasks) });
  assert.equal(nodes[0].status,"已完成"); assert.equal(nodes[1].status,"进行中");
  assert.equal(nodes[0].comments[0].content,"Case讨论"); assert.ok(nodes[0].activityLog.some(e=>e.summary==='发表评论'));
  assert.equal(nodes[0].statusHistory.at(-1).status,"已完成");
});

test("Case tree no-op saves do not invent history and strict failure is atomic", () => {
  const env=environment([fixture("a",{status:"进行中"})]); const api=env.boot(); const c=api.upgradeStandaloneTaskToCase("a"); const [task]=actions(api,c);
  api.saveCaseTaskTree(c.id,c.tasks,true); const before=plain(api.loadCaseTaskTree(c.id,c.tasks));
  api.saveCaseTaskTree(c.id,c.tasks,true); assert.deepEqual(plain(api.loadCaseTaskTree(c.id,c.tasks)),before);
  env.fail("ea_case_task_trees_v1");
  assert.throws(()=>api.commentOnCaseTask(c.id,task.id,"失败评论"));
  assert.throws(()=>api.updateCaseTask(c.id,task.id,{conclusion:"失败修改"}));
  assert.deepEqual(plain(api.loadCaseTaskTree(c.id,c.tasks)),before);
  env.fail(undefined); const commented=api.commentOnCaseTask(c.id,task.id,"重试"); assert.equal(commented.comments.length,1);
  assert.throws(()=>api.updateCaseTask(c.id,task.id,{status:"已完成"}),/结论/);
  assert.throws(()=>api.updateCaseTask(c.id,task.id,{status:"已中止"}),/中止原因/);
});

test("legacy Case status normalization and page opening produce no invented audit event", () => {
  const env=environment(); const api=env.boot(); const c=api.mockCases[0];
  const legacy={id:"legacy-status",code:"LEGACY.001",title:"旧任务",owner:"张伟",department:"PTE",urgency:"一般",progress:0,status:"待开始"};
  c.tasks=[legacy]; env.storage.set("ea_case_task_trees_v1",JSON.stringify({[c.id]:[legacy]}));
  const normalized=api.loadCaseTaskTree(c.id,c.tasks); api.saveCaseTaskTree(c.id,normalized,true);
  const saved=api.loadCaseTaskTree(c.id,c.tasks)[0];
  assert.equal(saved.status,"待接受"); assert.equal(saved.activityLog.length,0); assert.equal(saved.statusHistory.length,0);
});

test("ordinary Case edits retain existing status history and enforce edit permissions", () => {
  const env=environment([fixture("a")]); const api=env.boot(); const c=api.upgradeStandaloneTaskToCase("a"); const [task]=actions(api,c);
  api.respondToCaseTask(c.id,task.id,"accept");
  const snapshot=plain(api.loadCaseTaskTree(c.id,c.tasks));
  const target=api.flattenTasks(snapshot).find(({task:t})=>t.id===task.id).task;
  target.statusHistory=[]; target.title="普通字段修改";
  api.saveCaseTaskTree(c.id,snapshot,true);
  const updated=api.flattenTasks(api.loadCaseTaskTree(c.id,c.tasks)).find(({task:t})=>t.id===task.id).task;
  assert.equal(updated.statusHistory.length,1); assert.equal(updated.statusHistory[0].status,"进行中");
  assert.ok(updated.activityLog.some(e=>e.changes.some(c=>c.field==='任务名称')));
  api.currentUser.name="不相关用户";
  assert.throws(()=>api.updateCaseTask(c.id,task.id,{title:"未授权"}),/负责人或分派人/);
  // 可查看任务的读者可讨论，评论不赋予编辑或流转权限。
  assert.equal(api.commentOnCaseTask(c.id,task.id,"讨论意见").status,"进行中");
});

test("Case detail stale snapshot cannot overwrite a newer comment or task tree", () => {
  const env=environment([fixture("a")]); const api=env.boot(); const c=api.upgradeStandaloneTaskToCase("a"); const [task]=actions(api,c);
  const baseline=api.loadCaseTaskTree(c.id,c.tasks), draft=plain(baseline);
  api.commentOnCaseTask(c.id,task.id,"另一视图的新评论");
  const before=env.storage.get("ea_case_task_trees_v1");
  assert.throws(()=>api.saveCaseTaskTree(c.id,draft,true,baseline),/其他操作更新/);
  assert.equal(env.storage.get("ea_case_task_trees_v1"),before);
});

test("simple creation needs no department or classification and keeps self ownership", () => {
  const env = environment(); const api = env.boot();
  const input = newTaskInput({ creationMode: "simple", owner: "张伟" });
  delete input.handlingDepartment; delete input.involvement;
  const task = api.createStandaloneTask(input);
  assert.equal(task.creationMode, "simple"); assert.equal(task.owner, "张伟");
  assert.equal(task.status, "进行中"); assert.equal(task.createdForOther, false);
  assert.equal(task.handlingDepartment, "PTE"); assert.deepEqual(plain(task.involvement), { kind: "无" });
  assert.equal(task.problemDomain, undefined); assert.equal(task.problemType, undefined);
  assert.equal(api.hasAdvancedTaskInformation(task), false);
  assert.deepEqual(plain(env.boot().standaloneTaskById(task.id)), plain(task));
});

test("simple creation for others is unrestricted by hidden department and never assigns its leader", () => {
  const env = environment(); const api = env.boot();
  for (const owner of ["李娜", "李四", "刘洋"]) {
    const task = api.createStandaloneTask(newTaskInput({ creationMode: "simple", owner, handlingDepartment: "FT", collaborators: [owner, "周杰"] }));
    assert.equal(task.owner, owner); assert.equal(task.handlingDepartment, api.ownerToDepartment[owner]);
    assert.equal(task.status, "待接受"); assert.equal(task.createdForOther, true);
    assert.deepEqual(plain(task.collaborators), [{ name: "周杰", department: "PTE" }]);
  }
});

test("simple mode ignores only hidden assignment conditions, not shared involvement", () => {
  const env = environment(); const api = env.boot();
  for (const fields of [
    { problemDomain: "Design", problemType: "Layout", handlingDepartment: "RD" },
    { problemDomain: "Bad", problemType: "Bad", handlingDepartment: "Bad" },
    { problemDomain: "Testing", problemType: "", handlingDepartment: "" },
  ]) {
    const task = api.createStandaloneTask(newTaskInput({ ...fields, creationMode: "simple", assignmentMethod: "domain-type", owner: "张伟", involvement: "TF", involvementId: api.DEMO_TASK_FORCES[0].id }));
    const saved = env.boot().standaloneTaskById(task.id);
    assert.equal(saved.owner, "张伟"); assert.equal(saved.handlingDepartment, "PTE");
    for (const field of ["assignmentMethod", "problemDomain", "problemType"]) assert.equal(saved[field], undefined);
    assert.equal(saved.involvement.kind, "TF"); assert.equal(saved.involvement.id, api.DEMO_TASK_FORCES[0].id);
    assert.equal(api.hasAdvancedTaskInformation(saved), false);
  }
});

test("simple mode still requires an explicit owner and valid basic fields; advanced remains strict", () => {
  const env = environment(); const api = env.boot(); const before = env.storage.get(TASKS_KEY);
  for (const fields of [{ owner: " " }, { title: " " }, { description: " " }, { dueDate: "bad date" }]) {
    assert.throws(() => api.createStandaloneTask(newTaskInput({ creationMode: "simple", owner: "张伟", ...fields })));
  }
  for (const fields of [{ handlingDepartment: undefined }, { handlingDepartment: "" }, { involvement: "TF", involvementId: "" }]) {
    assert.throws(() => api.createStandaloneTask(newTaskInput({ owner: "张伟", ...fields })));
  }
  assert.throws(() => api.createStandaloneTask(newTaskInput({ creationMode: "invalid", owner: "张伟" })), /创建模式/);
  assert.equal(env.storage.get(TASKS_KEY), before);
});

test("simple persistence failure preserves attachments and is safe to retry", () => {
  const env = environment(); const api = env.boot();
  const attachments = [{ name: "任务说明.txt", kind: "file", url: "data:text/plain;base64,b2s=" }];
  const input = newTaskInput({ creationMode: "simple", owner: "张伟", attachments, voiceNote: "data:audio/webm;base64,b2s=" });
  const before = env.storage.get(TASKS_KEY); env.fail(TASKS_KEY);
  assert.throws(() => api.createStandaloneTask(input), /未能保存任务/);
  assert.equal(env.storage.get(TASKS_KEY), before);
  env.fail(undefined); const task = api.createStandaloneTask(input); attachments[0].name = "changed";
  const saved = env.boot().standaloneTaskById(task.id);
  assert.equal(saved.attachments[0].name, "任务说明.txt"); assert.equal(saved.voiceNote, input.voiceNote);
});

test("both creation modes upgrade without losing metadata or promoting simple drafts", () => {
  const env = environment(); const api = env.boot();
  const simple = api.createStandaloneTask(newTaskInput({ creationMode: "simple", owner: "张伟", problemDomain: "Design", problemType: "Layout", involvement: "产品", involvementId: api.mockProducts[0].id }));
  const advanced = api.createStandaloneTask(newTaskInput({ owner: "张伟", involvement: "TF", involvementId: api.DEMO_TASK_FORCES[0].id, problemDomain: "Testing", problemType: "DFT" }));
  const c = api.upgradeStandaloneTasksToCase([simple.id, advanced.id]);
  const imported = actions(env.boot(), env.boot().caseByStandaloneTask(simple.id));
  assert.equal(imported[0].owner, "张伟"); assert.equal(imported[0].standaloneTaskContext.problemDomain, undefined);
  assert.equal(imported[0].standaloneTaskContext.involvement.id, api.mockProducts[0].id); assert.equal(c.problemDomain, undefined);
  assert.equal(imported[1].owner, "张伟"); assert.equal(imported[1].standaloneTaskContext.problemDomain, "Testing");
  assert.equal(imported[1].standaloneTaskContext.involvement.kind, "TF");
});

test("legacy advanced records remain visible without reassigning or rewriting history", () => {
  const basic = fixture("old-basic");
  const advanced = fixture("old-advanced", { handlingDepartment: "FT", problemDomain: "Testing", problemType: "DFT" });
  const env = environment([basic, advanced]); const api = env.boot();
  assert.equal(api.hasAdvancedTaskInformation(api.standaloneTaskById(basic.id)), false);
  assert.equal(api.hasAdvancedTaskInformation(api.standaloneTaskById(advanced.id)), true);
  assert.deepEqual(plain(api.standaloneTaskById(advanced.id)), advanced);
  const legacyInput = newTaskInput({ owner: "李娜" }); delete legacyInput.creationMode; delete legacyInput.handlingDepartment;
  assert.equal(api.createStandaloneTask(legacyInput).creationMode, "simple");
});

test("department leader resolves for empty and partially selected Domain/type", () => {
  const api = environment().boot();
  for (const department of api.departments) {
    for (const [domain, type] of [["", ""], ["Design", ""], ["", "DFT"]]) {
      const assignment = api.resolveStandaloneAssignment(domain, type, department);
      assert.equal(assignment.owner, api.departmentSupervisors[department]);
      assert.equal(assignment.department, department); assert.equal(assignment.source, "department-leader");
    }
  }
  assert.equal(api.resolveStandaloneAssignment("", "", ""), null);
  assert.equal(api.resolveStandaloneAssignment("", "", "invalid"), null);
});

test("explicit department assignment needs no known owner and ignores inactive classification drafts", () => {
  const env = environment(); const api = env.boot();
  const task = api.createStandaloneTask(newTaskInput({ assignmentMethod: "department", handlingDepartment: "FT", owner: "李娜", problemDomain: "Bad", problemType: "Bad" }));
  assert.equal(task.owner, api.departmentSupervisors.FT); assert.equal(task.handlingDepartment, "FT");
  assert.equal(task.assignmentMethod, "department"); assert.equal(task.problemDomain, undefined); assert.equal(task.problemType, undefined);
  assert.equal(task.status, "待接受"); assert.deepEqual(plain(env.boot().standaloneTaskById(task.id)), plain(task));
});

test("explicit classification assignment derives department and owner without department input", () => {
  const env = environment(); const api = env.boot();
  for (const handlingDepartment of [undefined, "", "Bad", "FT"]) {
    const task = api.createStandaloneTask(newTaskInput({ assignmentMethod: "domain-type", handlingDepartment, owner: "李娜", problemDomain: "Testing", problemType: "DFT" }));
    assert.equal(task.owner, "周杰"); assert.equal(task.handlingDepartment, "PTE"); assert.equal(task.problemDomain, "Testing");
    assert.equal(task.problemType, "DFT"); assert.equal(task.assignmentMethod, "domain-type");
  }
  const before = env.storage.get(TASKS_KEY);
  for (const extra of [{ problemType: "" }, { problemDomain: "" }, { assignmentMethod: "invalid" }, { assignmentMethod: "" }]) {
    assert.throws(() => api.createStandaloneTask(newTaskInput({ assignmentMethod: "domain-type", problemDomain: "Testing", problemType: "DFT", ...extra })));
    assert.equal(env.storage.get(TASKS_KEY), before);
  }
});

test("simple tasks validate and persist Product Project TF and None independently of routing", () => {
  const env = environment(); const api = env.boot();
  for (const [kind, reference] of [["产品", api.mockProducts[0]], ["Project", api.allProjects()[0]], ["TF", api.DEMO_TASK_FORCES[0]]]) {
    const task = api.createStandaloneTask(newTaskInput({ creationMode: "simple", owner: "张伟", involvement: kind, involvementId: reference.id }));
    assert.equal(task.owner, "张伟"); assert.equal(task.involvement.id, reference.id); assert.equal(task.involvement.kind, kind);
    assert.equal(env.boot().standaloneTaskById(task.id).involvement.id, reference.id);
  }
  const before = env.storage.get(TASKS_KEY);
  for (const involvement of ["产品", "Project", "TF", "Bad"]) {
    assert.throws(() => api.createStandaloneTask(newTaskInput({ creationMode: "simple", owner: "张伟", involvement, involvementId: "missing" })));
  }
  assert.equal(env.storage.get(TASKS_KEY), before);
  assert.deepEqual(plain(api.createStandaloneTask(newTaskInput({ creationMode: "simple", owner: "张伟", involvement: "无", involvementId: "stale" })).involvement), { kind: "无" });
});

test("visibility settings persist in both modes, deduplicate people and discard hidden all-scope people", () => {
  const env = environment([fixture("legacy")]); const api = env.boot();
  for (const creationMode of ["simple", "advanced"]) {
    const people = [" 李娜 ", "周杰", "李娜", ""];
    const task = api.createStandaloneTask(newTaskInput({ creationMode, owner: "张伟", visibilityType: "partial", visiblePeople: people }));
    people.push("刘洋");
    assert.deepEqual(plain(task.visibility), { type: "partial", people: ["李娜", "周杰"] });
    assert.deepEqual(plain(env.boot().standaloneTaskById(task.id).visibility), plain(task.visibility));
    const all = api.createStandaloneTask(newTaskInput({ creationMode, owner: "张伟", visibilityType: "all", visiblePeople: ["李娜"] }));
    assert.deepEqual(plain(all.visibility), { type: "all", people: [] });
  }
  assert.equal(api.standaloneTaskById("legacy").visibility, undefined);
  // 经用户确认只保存设置，不因可见人员选择改变操作或查看权限。
  api.currentUser.name = "其他读者";
  assert.ok(api.standaloneTaskById("legacy"));
});

test("invalid visibility or failed save never partially writes task settings", () => {
  const env = environment(); const api = env.boot(); const before = env.storage.get(TASKS_KEY);
  for (const extra of [{ visibilityType: "bad" }, { visibilityType: "partial", visiblePeople: [] }, { visibilityType: "partial", visiblePeople: [" "] }, { visibilityType: "partial", visiblePeople: [null] }]) {
    assert.throws(() => api.createStandaloneTask(newTaskInput({ creationMode: "simple", owner: "张伟", ...extra })));
    assert.equal(env.storage.get(TASKS_KEY), before);
  }
  const input = newTaskInput({ creationMode: "simple", owner: "张伟", visibilityType: "partial", visiblePeople: ["李娜"], involvement: "TF", involvementId: api.DEMO_TASK_FORCES[0].id });
  env.fail(TASKS_KEY); assert.throws(() => api.createStandaloneTask(input), /未能保存/); assert.equal(env.storage.get(TASKS_KEY), before);
  env.fail(undefined); const saved = api.createStandaloneTask(input); assert.equal(saved.visibility.type, "partial");
});

test("visibility settings carry per task through batch upgrade without changing Case access rules", () => {
  const env = environment(); const api = env.boot();
  const a = api.createStandaloneTask(newTaskInput({ creationMode: "simple", owner: "张伟", visibilityType: "partial", visiblePeople: ["李娜"] }));
  const b = api.createStandaloneTask(newTaskInput({ creationMode: "simple", owner: "张伟", visibilityType: "all" }));
  const c = api.upgradeStandaloneTasksToCase([a.id, b.id]);
  const imported = actions(api, c);
  assert.deepEqual(plain(imported[0].standaloneTaskContext.visibility), plain(a.visibility));
  assert.deepEqual(plain(imported[1].standaloneTaskContext.visibility), plain(b.visibility));
  assert.notEqual(imported[0].standaloneTaskContext.visibility.people, a.visibility.people);
  assert.equal(c.visibility, undefined);
  const reload = env.boot(); const restored = reload.caseByStandaloneTask(a.id);
  assert.deepEqual(plain(actions(reload, restored)[0].standaloneTaskContext.visibility), plain(a.visibility));
});

test("task visibility presets reuse the Case form format and tolerate malformed storage", () => {
  const env = environment(); const api = env.boot();
  assert.deepEqual(plain(api.loadTaskVisibilityPreset()), { type: "all", people: [] });
  env.storage.set("ea_perm_preset_v1", JSON.stringify({ type: "partial", list: [{ id: "perm-李娜", name: "李娜", type: "user" }] }));
  assert.deepEqual(plain(api.loadTaskVisibilityPreset()), { type: "partial", people: ["李娜"] });
  api.saveTaskVisibilityPreset({ type: "partial", people: ["周杰"] });
  assert.deepEqual(JSON.parse(env.storage.get("ea_perm_preset_v1")), { type: "partial", list: [{ id: "perm-周杰", name: "周杰", type: "user" }] });
  for (const value of ["bad json", '{"type":"invalid"}', '{"type":"partial","list":[]}']) {
    env.storage.set("ea_perm_preset_v1", value); assert.deepEqual(plain(api.loadTaskVisibilityPreset()), { type: "all", people: [] });
  }
  env.fail("ea_perm_preset_v1"); assert.doesNotThrow(() => api.saveTaskVisibilityPreset({ type: "all", people: [] }));
});

test("every Case Domain/type pair has a deterministic demo owner and consistent department", () => {
  const api = environment().boot();
  assert.equal(api.DEMO_TASK_OWNER_RULES.length, api.PROBLEM_DOMAINS.length * api.PROBLEM_TYPES.length);
  for (const domain of api.PROBLEM_DOMAINS) for (const type of api.PROBLEM_TYPES) {
    const assignment = api.resolveStandaloneAssignment(domain, type, "QA");
    assert.equal(assignment.source, "domain-type");
    assert.equal(assignment.department, api.ownerToDepartment[assignment.owner]);
    assert.ok(api.departments.includes(assignment.department));
    assert.deepEqual(plain(assignment), plain(api.resolveStandaloneAssignment(domain, type, "CP")));
  }
  assert.equal(api.resolveStandaloneAssignment("Design", "DFT", "QA").owner, "张伟");
  assert.equal(api.resolveStandaloneAssignment("Design", "Layout", "QA").owner, "孙主管");
});

test("new metadata persists with creator department, leader and pending status", () => {
  const env = environment(); const api = env.boot();
  const task = api.createStandaloneTask(newTaskInput({ handlingDepartment: "FT", initiatingDepartment: "not trusted", collaborators: ["黄主管", "李娜", " 李娜 "] }));
  assert.equal(task.owner, "黄主管"); assert.equal(task.handlingDepartment, "FT");
  assert.equal(task.initiatingDepartment, api.currentUser.department);
  assert.equal(task.createdBy, api.currentUser.name); assert.equal(task.createdForOther, true); assert.equal(task.status, "待接受");
  assert.deepEqual(plain(task.collaborators), [{ name: "李娜", department: "DA" }]);
  assert.deepEqual(plain(env.boot().standaloneTaskById(task.id)), plain(task));
});

test("complete Domain/type takes precedence, partial fields use leader and manual same-department owner works", () => {
  const env = environment(); const api = env.boot();
  const mapped = api.createStandaloneTask(newTaskInput({ problemDomain: "Design", problemType: "DFT", handlingDepartment: "QA" }));
  assert.equal(mapped.owner, "张伟"); assert.equal(mapped.handlingDepartment, "PTE"); assert.equal(mapped.status, "进行中");
  assert.equal(mapped.problemDomain, "Design"); assert.equal(mapped.problemType, "DFT");
  const partial = api.createStandaloneTask(newTaskInput({ problemDomain: "Testing", handlingDepartment: "FT" }));
  assert.equal(partial.owner, "黄主管"); assert.equal(partial.problemDomain, "Testing"); assert.equal(partial.problemType, undefined);
  const manual = api.createStandaloneTask(newTaskInput({ owner: "刘洋" })); assert.equal(manual.owner, "刘洋");
  assert.throws(() => api.createStandaloneTask(newTaskInput({ owner: "李娜" })), /处理部门内/);
});

test("new required department, enums and dependent selections validate before task writes", () => {
  const env = environment(); const api = env.boot(); const before = env.storage.get(TASKS_KEY);
  for (const extra of [{ handlingDepartment: undefined }, { handlingDepartment: "" }, { handlingDepartment: "Bad" }, { problemDomain: "Bad" }, { problemType: "Bad" }, { involvement: "Bad" }, { involvement: "产品" }, { involvement: "Project", involvementId: "missing" }, { involvement: "TF", involvementId: "missing" }]) {
    assert.throws(() => api.createStandaloneTask(newTaskInput(extra)));
    assert.equal(env.storage.get(TASKS_KEY), before);
  }
});

test("Product, Project and TF references persist separately; none discards stale selection", () => {
  const env = environment(); const api = env.boot();
  const cases = [["产品", api.mockProducts[0]], ["Project", api.allProjects()[0]], ["TF", api.DEMO_TASK_FORCES[0]]];
  for (const [kind, reference] of cases) {
    assert.ok(reference); const task = api.createStandaloneTask(newTaskInput({ involvement: kind, involvementId: reference.id }));
    const saved = env.boot().standaloneTaskById(task.id);
    assert.equal(saved.involvement.kind, kind); assert.equal(saved.involvement.id, reference.id);
    assert.ok(saved.involvement.name.includes(reference.name));
  }
  const none = api.createStandaloneTask(newTaskInput({ involvement: "无", involvementId: api.mockProducts[0].id }));
  assert.deepEqual(plain(none.involvement), { kind: "无" });
  assert.throws(() => api.createStandaloneTask(newTaskInput({ involvement: "TF", involvementId: api.mockProducts[0].id })));
});

test("new-field persistence failure is atomic and legacy tasks are never reassigned", () => {
  const original = fixture("legacy", { owner: "张伟", status: "进行中" });
  const env = environment([original]); const api = env.boot(); const before = env.storage.get(TASKS_KEY);
  assert.deepEqual(plain(api.standaloneTaskById("legacy")), original);
  env.fail(TASKS_KEY); assert.throws(() => api.createStandaloneTask(newTaskInput()), /未能保存任务/);
  assert.equal(env.storage.get(TASKS_KEY), before); assert.deepEqual(plain(api.standaloneTaskById("legacy")), original);
  env.fail(undefined); const task = api.createStandaloneTask(newTaskInput());
  assert.equal(env.boot().standaloneTaskById(task.id).handlingDepartment, "PTE");
  assert.deepEqual(plain(env.boot().standaloneTaskById("legacy")), original);
});

test("batch upgrade retains each task department, involvement and optional classifications", () => {
  const env = environment([fixture("historic-a", { handlingDepartment: "PTE", involvement: { kind: "产品", id: "p-test", name: "历史产品" }, problemDomain: "Design", problemType: "DFT" }), fixture("historic-b", { handlingDepartment: "FT", involvement: { kind: "TF", id: "tf-old", name: "历史专项" } })]); const api = env.boot();
  const product = api.mockProducts[0];
  const a = api.standaloneTaskById("historic-a");
  const b = api.standaloneTaskById("historic-b");
  const c = api.upgradeStandaloneTasksToCase([a.id, b.id]);
  const imported = actions(env.boot(), env.boot().caseByStandaloneTask(a.id));
  assert.equal(c.productId, "p-test"); assert.equal(c.problemDomain, "Design"); assert.equal(c.problemType, "DFT");
  assert.deepEqual(plain(imported.map((task) => task.department)), ["PTE", "FT"]);
  for (const [index, source] of [a, b].entries()) {
    assert.equal(imported[index].standaloneTaskContext.initiatingDepartment, source.initiatingDepartment ?? api.ownerToDepartment[source.createdBy]);
    assert.deepEqual(plain(imported[index].standaloneTaskContext.involvement), plain(source.involvement));
    assert.equal(imported[index].standaloneTaskContext.problemDomain, source.problemDomain);
    assert.equal(imported[index].standaloneTaskContext.problemType, source.problemType);
  }
});

test("termination requires a reason but not a conclusion and supports pending/active tasks", () => {
  const env = environment([fixture("pending"), fixture("active", { status: "进行中" })]); const api = env.boot();
  for (const reason of ["", " \n\t "]) assert.throws(() => api.terminateStandaloneTask("active", reason), /请填写中止原因/);
  assert.equal(api.standaloneTaskById("active").status, "进行中");
  api.terminateStandaloneTask("pending", "  需求撤回  ");
  api.terminateStandaloneTask("active", "验证条件已变更");
  const reload = env.boot();
  for (const id of ["pending", "active"]) {
    assert.equal(reload.standaloneTaskById(id).status, "已中止");
    assert.equal(reload.standaloneTaskById(id).conclusion, undefined);
    assert.equal(reload.canUpgradeStandaloneTask(reload.standaloneTaskById(id)), false);
    assert.throws(() => reload.completeStandaloneTask(id, { conclusion: "不能完成" }));
    assert.throws(() => reload.updateStandaloneTaskStatus(id, "进行中"));
    assert.throws(() => reload.terminateStandaloneTask(id, "不能重复中止"));
  }
  assert.equal(reload.standaloneTaskById("pending").terminateReason, "需求撤回");
});

test("termination preserves saved Workspace, original attachments and draft result files", () => {
  const original = fixture("active", { status: "进行中", conclusion: "阶段结论", analysisProcess: "已执行步骤" });
  const env = environment([original, fixture("sibling")]); const api = env.boot();
  const result = [{ name: "阶段记录.txt", kind: "file", url: "data:text/plain;base64,b2s=" }];
  api.terminateStandaloneTask("active", "需求取消", result);
  const saved = env.boot().standaloneTaskById("active");
  assert.equal(saved.conclusion, original.conclusion); assert.equal(saved.analysisProcess, original.analysisProcess);
  assert.deepEqual(plain(saved.attachments), original.attachments); assert.deepEqual(plain(saved.resultAttachments), result);
  assert.equal(api.standaloneTaskById("sibling").status, "待接受");
  assert.throws(() => api.saveStandaloneTaskWorkspace("active", { conclusion: "不可修改", analysisProcess: "" }));
});

test("termination enforces ownership, terminal states and upgrade exclusivity", () => {
  const env = environment([fixture("foreign", { owner: "李娜", createdBy: "张伟", status: "进行中" }),
    fixture("done", { status: "已完成" }), fixture("reject", { status: "已拒绝" }),
    fixture("converted", { convertedCaseId: "old-case" }), fixture("partial", { status: "进行中" })]); const api = env.boot();
  for (const id of ["foreign", "done", "reject", "converted", "missing"]) assert.throws(() => api.terminateStandaloneTask(id, "不允许"));
  assert.throws(() => api.updateStandaloneTaskStatus("partial", "已中止"));
  env.fail(TASKS_KEY); assert.throws(() => api.upgradeStandaloneTaskToCase("partial")); env.fail(undefined);
  assert.throws(() => api.terminateStandaloneTask("partial", "已经带入Case"), /已带入 Case/);
  assert.equal(api.standaloneTaskById("partial").status, "进行中");
});

test("failed termination is atomic and can be retried without losing saved content", () => {
  const task = fixture("active", { status: "进行中", analysisProcess: "原文档" });
  const env = environment([task]); const api = env.boot(); env.fail(TASKS_KEY);
  assert.throws(() => api.terminateStandaloneTask("active", "需求撤回"), /未能保存任务/);
  assert.equal(api.standaloneTaskById("active").status, "进行中");
  assert.equal(api.standaloneTaskById("active").terminateReason, undefined);
  assert.equal(api.standaloneTaskById("active").analysisProcess, "原文档");
  env.fail(undefined); api.terminateStandaloneTask("active", "需求撤回");
  assert.equal(env.boot().standaloneTaskById("active").terminateReason, "需求撤回");
});

test("Workspace saves process and conclusion without completing the task and survives reload", () => {
  const source = fixture("workspace", { status: "进行中", resultAttachments: [{ name: "结果.csv", kind: "sheet", url: "data:text/csv;base64,YQpi" }] });
  const env = environment([source]); const api = env.boot();
  api.saveStandaloneTaskWorkspace(source.id, { conclusion: "  核对通过  ", analysisProcess: "## 核对步骤\n1. 比对清单\n2. 记录差异\n  保留缩进" });
  const saved = env.boot().standaloneTaskById(source.id);
  assert.equal(saved.status, "进行中"); assert.equal(saved.conclusion, "核对通过");
  assert.equal(saved.analysisProcess, "## 核对步骤\n1. 比对清单\n2. 记录差异\n  保留缩进");
  assert.deepEqual(plain(saved.attachments), source.attachments);
  assert.deepEqual(plain(saved.resultAttachments), source.resultAttachments);
});

test("Workspace permits a process-only draft but completion still requires a conclusion", () => {
  const env = environment([fixture("workspace", { status: "进行中" })]); const api = env.boot();
  api.saveStandaloneTaskWorkspace("workspace", { conclusion: "", analysisProcess: "正在检查，结论待确认" });
  assert.throws(() => api.completeStandaloneTask("workspace", { conclusion: "  " }), /请填写任务结论/);
  const result = { name: "记录.txt", kind: "file", url: "data:text/plain;base64,b2s=" };
  api.saveStandaloneTaskWorkspace("workspace", { conclusion: "核对通过", analysisProcess: "所有检查项通过", resultAttachments: [result] });
  api.completeStandaloneTask("workspace", { conclusion: "核对通过" });
  const saved = env.boot().standaloneTaskById("workspace");
  assert.equal(saved.status, "已完成"); assert.equal(saved.analysisProcess, "所有检查项通过");
  assert.deepEqual(plain(saved.resultAttachments), [result]);
});

test("Workspace saves enforce owner, active state and upgrade exclusivity", () => {
  const env = environment([
    fixture("pending"), fixture("done", { status: "已完成" }), fixture("reject", { status: "已拒绝" }),
    fixture("stop", { status: "已中止" }), fixture("other", { owner: "李娜", status: "进行中", createdBy: "张伟" }),
    fixture("converted", { status: "进行中", convertedCaseId: "case-old" }),
    fixture("partial", { status: "进行中" }),
  ]); const api = env.boot();
  const document = { conclusion: "核对结果", analysisProcess: "处理过程" };
  for (const id of ["pending", "done", "reject", "stop", "other", "converted", "missing"]) assert.throws(() => api.saveStandaloneTaskWorkspace(id, document));
  env.fail(TASKS_KEY);
  assert.throws(() => api.upgradeStandaloneTaskToCase("partial"));
  env.fail(undefined);
  assert.throws(() => api.saveStandaloneTaskWorkspace("partial", document), /已带入 Case/);
  assert.equal(api.standaloneTaskById("partial").analysisProcess, undefined);
});

test("Workspace failed persistence preserves previous content and retry writes one consistent snapshot", () => {
  const source = fixture("workspace", { status: "进行中", conclusion: "原结论", analysisProcess: "原过程" });
  const env = environment([source]); const api = env.boot(); env.fail(TASKS_KEY);
  const updated = { conclusion: "新结论", analysisProcess: "新过程", resultAttachments: [{ name: "记录.txt", kind: "file", url: "data:text/plain;base64,b2s=" }] };
  assert.throws(() => api.saveStandaloneTaskWorkspace("workspace", updated), /未能保存任务/);
  assert.equal(api.standaloneTaskById("workspace").conclusion, "原结论");
  assert.equal(api.standaloneTaskById("workspace").analysisProcess, "原过程");
  env.fail(undefined); api.saveStandaloneTaskWorkspace("workspace", updated);
  const saved = env.boot().standaloneTaskById("workspace");
  assert.equal(saved.status, "进行中"); assert.equal(saved.analysisProcess, updated.analysisProcess);
  assert.deepEqual(plain(saved.resultAttachments), updated.resultAttachments);
});

test("batch upgrade carries each saved Workspace into the corresponding Case task", () => {
  const env = environment([fixture("a", { status: "进行中" }), fixture("b", { status: "进行中" })]); const api = env.boot();
  for (const id of ["a", "b"]) api.saveStandaloneTaskWorkspace(id, { conclusion: `${id} 结论`, analysisProcess: `${id} 分析过程\n检查结果` });
  api.completeStandaloneTask("a", { conclusion: "a 最终结论" });
  api.upgradeStandaloneTasksToCase(["a", "b"]);
  const reloaded = env.boot(); const c = reloaded.caseByStandaloneTask("a");
  const imported = actions(reloaded, c);
  assert.deepEqual(plain(imported.map((t) => t.analysisProcess)), ["a 分析过程\n检查结果", "b 分析过程\n检查结果"]);
  assert.deepEqual(plain(imported.map((t) => t.conclusion)), ["a 最终结论", "b 结论"]);
  assert.deepEqual(plain(imported.map((t) => t.status)), ["已完成", "进行中"]);
  assert.equal(reloaded.standaloneTaskById("a").analysisProcess, "a 分析过程\n检查结果");
  assert.throws(() => reloaded.saveStandaloneTaskWorkspace("b", { conclusion: "不得重复改", analysisProcess: "" }));
});

test("new task attachments retain file content after reload and remain separate from result files", () => {
  const env = environment(); const api = env.boot();
  const attachments = [
    { name: "新建说明.txt", kind: "file", url: "data:text/plain;base64,dGVzdA==" },
    { name: "检查清单.csv", kind: "sheet", url: "data:text/csv;base64,YQpi" },
  ];
  const original = plain(attachments);
  const task = api.createStandaloneTask({ title: "新建附件回归", description: "检查新建附件", owner: "张伟", handlingDepartment: "PTE", createdForOther: false, collaborators: [], urgency: "一般", dueDate: "2026-09-20", attachments });
  attachments[0].name = "外部变更不得覆盖原附件";
  const reloaded = env.boot();
  assert.deepEqual(plain(reloaded.standaloneTaskById(task.id).attachments), original);
  reloaded.completeStandaloneTask(task.id, { conclusion: "附件已核对", resultAttachments: [{ name: "结果.txt", kind: "file", url: "data:text/plain;base64,b2s=" }] });
  const final = env.boot().standaloneTaskById(task.id);
  assert.deepEqual(plain(final.attachments), original);
  assert.equal(final.resultAttachments.length, 1);
  assert.equal(final.resultAttachments[0].name, "结果.txt");
});

test("single upgrade carries a real execution task, all content and source linkage", () => {
  const source = fixture("one");
  const env = environment([source]); const api = env.boot();
  const c = api.upgradeStandaloneTaskToCase(source.id);
  const [task] = actions(api, c);
  assert.equal(c.tasks.length, 1); assert.equal(c.tasks[0].code, undefined);
  assert.equal(task.code, `${c.code}.001`); assert.notEqual(task.id, source.id);
  for (const field of ["title", "owner", "urgency", "status", "dueDate", "voiceNote"]) assert.equal(task[field], source[field]);
  assert.equal(task.expectation, source.description);
  assert.deepEqual(plain(task.attachments), source.attachments);
  assert.deepEqual(plain(task.collaborators), source.collaborators);
  assert.equal(task.sourceStandaloneTaskId, source.id);
  assert.deepEqual(plain(c.sourceStandaloneTaskIds), [source.id]);
  assert.equal(c.sourceStandaloneTaskId, source.id);
  assert.equal(api.standaloneTaskById(source.id).status, source.status);
  assert.equal(api.standaloneTaskById(source.id).convertedCaseId, c.id);
  const reloaded = env.boot();
  assert.equal(actions(reloaded, reloaded.caseByStandaloneTask(source.id)).length, 1);
});

test("batch upgrade preserves mixed states of owned tasks and is idempotent", () => {
  const sources = [fixture("a"), fixture("b", { status: "进行中", owner: "张伟", createdBy: "张伟" }),
    fixture("c", { status: "已完成" }), fixture("d", { status: "已拒绝", rejectReason: "排期冲突" })];
  const env = environment([...sources, fixture("unselected")]); const api = env.boot();
  const c = api.upgradeStandaloneTasksToCase(["a", "b", "c", "d", "a"]);
  const imported = actions(api, c);
  assert.equal(imported.length, 4); assert.equal(new Set(imported.map((t) => t.id)).size, 4);
  assert.equal(new Set(imported.map((t) => t.code)).size, 4);
  assert.deepEqual(plain(imported.map((t) => t.status)), sources.map((t) => t.status));
  assert.equal(imported[1].owner, "张伟"); assert.equal(imported[2].progress, 100); assert.equal(imported[3].rejectReason, "排期冲突");
  assert.ok(c.participants.some((p) => p.name === "周杰")); assert.equal(new Set(c.participants.map((p) => p.name)).size, c.participants.length);
  sources.forEach((source) => assert.equal(api.standaloneTaskById(source.id).convertedCaseId, c.id));
  sources.forEach((source) => assert.equal(api.standaloneTaskById(source.id).status, source.status));
  assert.equal(api.standaloneTaskById("unselected").status, "待接受");
  assert.equal(api.upgradeStandaloneTasksToCase(["b", "a", "c", "d"]).id, c.id);
  assert.equal(api.upgradeStandaloneTaskToCase("a").id, c.id);
  assert.throws(() => api.upgradeStandaloneTasksToCase(["a", "unselected"]), /已关联其他 Case/);
  assert.equal(JSON.parse(env.storage.get(DOMAIN_KEY)).spawnedCases.length, 1);
});

test("empty, missing, unauthorized and terminated selections are rejected before creating a Case", () => {
  const env = environment([fixture("allowed"), fixture("foreign", { owner: "刘洋", createdBy: "周杰" }), fixture("closed", { status: "已中止" })]);
  const api = env.boot();
  for (const ids of [[], ["missing"], ["allowed", "foreign"], ["allowed", "closed"]]) assert.throws(() => api.upgradeStandaloneTasksToCase(ids));
  assert.equal(api.standaloneTaskById("allowed").status, "待接受");
  assert.equal(JSON.parse(env.storage.get(DOMAIN_KEY) ?? '{"spawnedCases":[]}').spawnedCases.length, 0);
});

test("Case storage failure leaves all sources open and no phantom Case", () => {
  const env = environment([fixture("a"), fixture("b")]); const api = env.boot(); env.fail(DOMAIN_KEY);
  assert.throws(() => api.upgradeStandaloneTasksToCase(["a", "b"]), /未能保存新 Case/);
  assert.equal(api.caseByStandaloneTask("a"), undefined);
  for (const id of ["a", "b"]) assert.equal(api.standaloneTaskById(id).status, "待接受");
  env.fail(undefined); assert.equal(actions(api, api.upgradeStandaloneTasksToCase(["a", "b"])).length, 2);
});

test("source storage failure can resume the entire batch after reload without a duplicate Case", () => {
  const env = environment([fixture("a"), fixture("b")]); const api = env.boot(); env.fail(TASKS_KEY);
  assert.throws(() => api.upgradeStandaloneTasksToCase(["a", "b"]), /未能保存任务/);
  const original = api.caseByStandaloneTask("a"); assert.ok(original);
  assert.equal(api.standaloneTaskById("a").status, "待接受");
  env.fail(undefined); const reloaded = env.boot();
  const c = reloaded.upgradeStandaloneTaskToCase("a"); assert.equal(c.id, original.id);
  for (const id of ["a", "b"]) assert.equal(reloaded.standaloneTaskById(id).convertedCaseId, c.id);
  assert.equal(JSON.parse(env.storage.get(DOMAIN_KEY)).spawnedCases.length, 1);
  assert.equal(actions(reloaded, c).length, 2);
});

test("old single-source Case records still resolve without being recreated", () => {
  const env = environment([fixture("legacy")]); const api = env.boot(); const c = api.upgradeStandaloneTaskToCase("legacy");
  const domain = JSON.parse(env.storage.get(DOMAIN_KEY));
  delete domain.spawnedCases[0].sourceStandaloneTaskIds; domain.spawnedCases[0].tasks = [];
  env.storage.set(DOMAIN_KEY, JSON.stringify(domain));
  const reloaded = env.boot(); assert.equal(reloaded.upgradeStandaloneTaskToCase("legacy").id, c.id);
  assert.equal(JSON.parse(env.storage.get(DOMAIN_KEY)).spawnedCases.length, 1);
});

test("imported tasks retain working accept/reject actions and sibling state", () => {
  const env = environment([fixture("a"), fixture("b"), fixture("done", { status: "已完成" })]); const api = env.boot();
  const c = api.upgradeStandaloneTasksToCase(["a", "b", "done"]); const imported = actions(api, c);
  api.respondToCaseTask(c.id, imported[0].id, "accept");
  api.respondToCaseTask(c.id, imported[1].id, "reject", "等待补充资料");
  const reloaded = env.boot(); const saved = reloaded.caseByStandaloneTask("a");
  saved.tasks = reloaded.loadCaseTaskTree(saved.id, saved.tasks);
  const tasks = actions(reloaded, saved);
  assert.deepEqual(plain(tasks.map((t) => t.status)), ["进行中", "已拒绝", "已完成"]);
  assert.equal(tasks[1].rejectReason, "等待补充资料");
  assert.equal(tasks[0].sourceStandaloneTaskId, "a");
  for (const id of ["a", "b", "done"]) {
    assert.equal(reloaded.standaloneTaskById(id).status, id === "done" ? "已完成" : "待接受");
    assert.equal(reloaded.standaloneTaskDisplayStatus(reloaded.standaloneTaskById(id)), "已升级为 Case");
    assert.throws(() => reloaded.updateStandaloneTaskStatus(id, "进行中"), /已升级/);
  }
});

test("completion requires a non-blank conclusion and cannot bypass result submission", () => {
  const env = environment([fixture("result", { status: "进行中" })]); const api = env.boot();
  for (const conclusion of ["", " \n\t "]) assert.throws(() => api.completeStandaloneTask("result", { conclusion }), /请填写任务结论/);
  assert.throws(() => api.updateStandaloneTaskStatus("result", "已完成"), /任务结论/);
  assert.equal(api.standaloneTaskById("result").status, "进行中");
  api.completeStandaloneTask("result", { conclusion: "  已完成核对，无遗漏。  " });
  const saved = env.boot().standaloneTaskById("result");
  assert.equal(saved.status, "已完成"); assert.equal(saved.conclusion, "已完成核对，无遗漏。");
  assert.deepEqual(plain(saved.resultAttachments), []);
  assert.equal(saved.attachments.length, 1);
});

test("result attachments persist separately and completion does not mutate source attachments", () => {
  const source = fixture("result", { status: "进行中" }); const env = environment([source]); const api = env.boot();
  const attachments = [{ name: "核对结果.csv", kind: "sheet", url: "data:text/csv;base64,YQpi" }];
  api.completeStandaloneTask("result", { conclusion: "全部核对通过。", resultAttachments: attachments });
  const saved = env.boot().standaloneTaskById("result");
  assert.deepEqual(plain(saved.resultAttachments), attachments); assert.deepEqual(plain(saved.attachments), source.attachments);
  assert.throws(() => api.completeStandaloneTask("result", { conclusion: "重复提交" }), /仅进行中/);
});

test("only the owner of an active unconverted task may submit results", () => {
  const ids = ["pending", "rejected", "closed", "complete", "foreign", "converted"];
  const env = environment([
    fixture("pending"), fixture("rejected", { status: "已拒绝" }), fixture("closed", { status: "已中止" }),
    fixture("complete", { status: "已完成" }), fixture("foreign", { status: "进行中", owner: "李娜", createdBy: "张伟" }),
    fixture("converted", { status: "进行中", convertedCaseId: "another-case" }),
  ]);
  const api = env.boot();
  for (const id of [...ids, "missing"]) assert.throws(() => api.completeStandaloneTask(id, { conclusion: "完成" }));
  for (const id of ids) assert.equal(api.standaloneTaskById(id).conclusion, undefined);
});

test("failed result storage leaves task active without a partial conclusion, retry succeeds", () => {
  const env = environment([fixture("result", { status: "进行中" })]); const api = env.boot(); env.fail(TASKS_KEY);
  assert.throws(() => api.completeStandaloneTask("result", { conclusion: "核对完成" }), /未能保存任务/);
  assert.equal(api.standaloneTaskById("result").status, "进行中"); assert.equal(api.standaloneTaskById("result").conclusion, undefined);
  env.fail(undefined); api.completeStandaloneTask("result", { conclusion: "核对完成" });
  assert.equal(env.boot().standaloneTaskById("result").conclusion, "核对完成");
});

test("completed results carry into a multi-task Case and survive reload", () => {
  const env = environment([fixture("result", { status: "进行中" }), fixture("pending")]); const api = env.boot();
  const resultAttachment = { name: "结果.pdf", kind: "pdf", url: "data:application/pdf;base64,dGVzdA==" };
  api.completeStandaloneTask("result", { conclusion: "核对通过，已归档。", resultAttachments: [resultAttachment] });
  api.upgradeStandaloneTasksToCase(["result", "pending"]);
  const reloaded = env.boot(); const c = reloaded.caseByStandaloneTask("result"); const imported = actions(reloaded, c);
  assert.equal(imported.length, 2); assert.equal(imported[0].conclusion, "核对通过，已归档。");
  assert.equal(imported[0].status, "已完成"); assert.equal(imported[1].status, "待接受");
  assert.ok(imported[0].attachments.some((a) => a.url === resultAttachment.url));
  assert.ok(c.caseAttachments.some((a) => a.name === resultAttachment.name));
  assert.equal(reloaded.standaloneTaskById("result").conclusion, "核对通过，已归档。");
  assert.deepEqual(plain(reloaded.standaloneTaskById("result").resultAttachments), [resultAttachment]);
});

test("legacy closed upgrade records migrate to valid execution states without losing results or links", () => {
  const original = [fixture("pending"), fixture("active", { status: "进行中" }), fixture("done", { status: "已完成", conclusion: "验证完成" })];
  const env = environment(original); const api = env.boot();
  const c = api.upgradeStandaloneTasksToCase(original.map((t) => t.id));
  const legacy = JSON.parse(env.storage.get(TASKS_KEY)).map((task) => task.convertedCaseId === c.id ? { ...task, status: "已关闭" } : task);
  env.storage.set(TASKS_KEY, JSON.stringify(legacy));
  const reloaded = env.boot();
  original.forEach((before) => {
    const after = reloaded.standaloneTaskById(before.id);
    assert.equal(after.status, before.status); assert.equal(after.convertedCaseId, c.id);
    assert.equal(after.conclusion, before.conclusion); assert.deepEqual(plain(after.attachments), before.attachments);
    assert.equal(reloaded.standaloneTaskDisplayStatus(after), "已升级为 Case");
    assert.equal(reloaded.canUpgradeStandaloneTask(after), false);
  });
  assert.equal(JSON.parse(env.storage.get(TASKS_KEY)).some((task) => task.status === "已关闭"), false);
  assert.equal(reloaded.upgradeStandaloneTaskToCase("active").id, c.id);
  assert.throws(() => reloaded.completeStandaloneTask("active", { conclusion: "不可重复执行" }));
  assert.equal(env.boot().standaloneTaskById("pending").status, "待接受");
});

test("legacy unknown closure is safely normalized without inventing a completion or reopening it", () => {
  const env = environment([fixture("old", { status: "已关闭", convertedCaseId: "old-case" }), fixture("unlinked", { status: "已关闭" }), fixture("waiting", { status: "待处理" })]);
  const api = env.boot();
  assert.equal(api.standaloneTaskById("old").status, "已中止");
  assert.equal(api.standaloneTaskDisplayStatus(api.standaloneTaskById("old")), "已升级为 Case");
  assert.equal(api.standaloneTaskById("unlinked").status, "已中止");
  assert.equal(api.standaloneTaskById("waiting").status, "待接受");
  assert.throws(() => api.updateStandaloneTaskStatus("unlinked", "进行中"));
  const legal = new Set(["待接受", "进行中", "已拒绝", "已完成", "已中止"]);
  assert.ok(api.useStandaloneTasks().every((t) => legal.has(t.status)));
});