import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";
import { webcrypto } from "node:crypto";
import vm from "node:vm";
import { build } from "esbuild";
import { renderToStaticMarkup } from "react-dom/server";

const require = createRequire(import.meta.url);
const React = require("react");
const directory = new URL("../src/app/components/", import.meta.url);
const { outputFiles } = await build({
  stdin: { contents: `export { CreateCase } from './CreateCase'; export { CreateCaseLab } from './CreateCaseLab'; export { CaseList } from './CaseList'; export { TopBar } from './TopBar'; export { StandaloneTaskDetail } from './StandaloneTaskDetail'; export { mockCases } from './data'; export { createManualCase, linksOfCase, allProjects } from './domainStore'; export { useStandaloneTasks } from './standaloneTasks';`, resolveDir: fileURLToPath(directory), loader: "tsx" },
  bundle: true, write: false, platform: "node", format: "cjs", keepNames: true, jsx: "automatic", packages: "external",
  external: ["./CreateCaseMindMapFlow", "./CreateCaseWbsTable"], loader: { ".css": "empty" },
  plugins: [{ name: "capture-only-page-state", setup(builder) {
    builder.onLoad({ filter: /\/(CreateCase|CreateCaseLab|CaseList|TopBar)\.tsx$/ }, args => ({ contents: readFileSync(args.path, "utf8").replace(/\buseState\b/g, "useControlledState"), loader: "tsx" }));
  } }],
});
const plain = value => JSON.parse(JSON.stringify(value));
function elements(tree) {
  if (Array.isArray(tree)) return Array.from(tree).flatMap(elements);
  return React.isValidElement(tree) ? [tree, ...elements(tree.props.children)] : [];
}
function text(tree) {
  if (Array.isArray(tree)) return Array.from(tree).map(text).join("");
  return React.isValidElement(tree) ? text(tree.props.children) : typeof tree === "string" || typeof tree === "number" ? String(tree) : "";
}
function harness(name, props = {}, entries = []) {
  const source = readFileSync(new URL(`${name}.tsx`, directory), "utf8");
  const body = source.slice(source.indexOf(`export function ${name}(`));
  const slots = [...body.matchAll(/const\s+\[\s*(\w+)[^\]\n]*\]\s*=\s*useState\b/g)].map(match => match[1]);
  const state = new Map(); const storage = new Map(entries); let capturing = false; let cursor = 0; let tree;
  const sandbox = { module: { exports: {} }, crypto: webcrypto, btoa, atob, console,
    localStorage: { getItem: key => storage.get(key) ?? null, setItem: (key, value) => storage.set(key, value), removeItem: key => storage.delete(key) },
    require(dependency) {
      if (dependency === "react") return { ...React, useControlledState(initial) {
        if (!capturing) return React.useState(initial);
        const slot = slots[cursor++]; assert.ok(slot, `Missing state slot ${name}`);
        if (!state.has(slot)) state.set(slot, typeof initial === "function" ? initial() : initial);
        return [state.get(slot), next => state.set(slot, typeof next === "function" ? next(state.get(slot)) : next)];
      } };
      if (dependency === "./CreateCaseMindMapFlow") return { CreateCaseMindMapFlow: () => null };
      if (dependency === "./CreateCaseWbsTable") return { CreateCaseWbsTable: () => null };
      return require(dependency);
    },
  };
  vm.runInNewContext(outputFiles[0].text, sandbox); const api = sandbox.module.exports;
  function Root() { cursor = 0; capturing = true; try { tree = api[name](props); } finally { capturing = false; } return tree; }
  const render = () => renderToStaticMarkup(React.createElement(Root));
  const one = predicate => { const found = elements(tree).filter(predicate); assert.equal(found.length, 1); return found[0]; };
  const button = label => one(node => node.type === "button" && text(node).trim() === label);
  const act = (callback, ...args) => { callback(...args); return render(); };
  render();
  return { api, state, storage, render, one, button, act, get tree() { return tree; } };
}

test("standalone details show only four metadata fields for all assignment modes, preserving data and the upper-right deadline", () => {
  for (const route of [{ creationMode: "simple" }, { creationMode: "advanced", assignmentMethod: "department" }, { creationMode: "advanced", assignmentMethod: "domain-type" }]) {
    const task = { id: "four-field-detail", code: "TASK-FOUR", title: "详情四项回归", description: "保留任务说明", owner: "张伟", createdBy: "李娜", createdForOther: true, ...route,
      initiatingDepartment: "DA", handlingDepartment: "PTE", problemDomain: "Testing", problemType: "DFT",
      involvement: { kind: "产品", id: "p1", name: "关联产品" }, visibility: { type: "partial", people: ["刘洋"] }, collaborators: [{ name: "周杰", department: "PTE" }],
      status: "进行中", urgency: "一般", dueDate: "2026-09-30", attachments: [], createdAt: "2026-09-10T08:00:00Z", updatedAt: "2026-09-11T09:30:00Z" };
    const h = harness("StandaloneTaskDetail", { taskId: task.id, onBack() {}, onOpenCase() {}, onEdit() {} }, [["ea_standalone_tasks_v1", JSON.stringify([task])]]);
    const info = h.one(node => node.props["aria-label"] === "任务信息");
    const fields = elements(info).filter(node => node.type === "dt").map(text);
    assert.deepEqual(fields, ["创建人", "负责人", "创建时间", "最近更新"]);
    const values = elements(info).filter(node => node.type === "dd").map(text);
    assert.deepEqual(values.slice(0, 2), [task.createdBy, task.owner]);
    for (const [index, date] of [task.createdAt, task.updatedAt].entries()) assert.equal(values[index + 2], new Date(date).toLocaleString("zh-CN", { hour12: false, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" }));
    const deadline = h.one(node => node.type === "span" && text(node) === `截止 ${task.dueDate}`);
    assert.match(deadline.props.className, /ml-auto/);
    const markup = renderToStaticMarkup(info);
    assert.ok(markup.indexOf(`截止 ${task.dueDate}`) < markup.indexOf("<h1"));
    assert.match(markup, /保留任务说明/);
    const before = h.storage.get("ea_standalone_tasks_v1"); h.render();
    assert.equal(h.storage.get("ea_standalone_tasks_v1"), before);
    assert.deepEqual(JSON.parse(before).find(item => item.id === task.id), task);
  }
});

for (const name of ["CreateCase", "CreateCaseLab"]) test(`${name} inheritance excludes old tasks, shows source relation and saves reciprocal Case links`, () => {
  const created = []; const h = harness(name, { onDone() {}, onCreated: id => created.push(id) });
  const source = h.api.mockCases.find(item => item.tasks.length);
  const original = JSON.stringify(source.tasks);
  h.state.set("inheritCaseId", source.id); h.state.set("inheritOpen", true); h.render();
  h.act(h.button("确认承接").props.onClick);
  assert.deepEqual(plain(h.state.get("thoughtGroups")), []); assert.deepEqual(plain(h.state.get("tasks")), []);
  assert.ok(h.state.get("relatedCaseIds").includes(source.id)); assert.equal(JSON.stringify(source.tasks), original);
  const values = { name: "承接回归", caseOwner: "张伟", dueDate: "2026-09-30", background: "承接背景", impact: "影响", caseAttribute: "VOC", customer: "客户A", failRatio: "2", failRatioUnit: "%", projectName: "独立项目名称", failPlatform: "Intel SPR", productPartNumber: "DEMO-DDR5-6400", productIds: ["p1"], productForm: "IC", density: "16", productSpeed: "6400", ioType: "x8", failPackage: "BGA", productGeneration: "G4", failStage: "PVT", material: "不适用", returnedSamples: [], sampleCount: "0", level: "L2", urgency: "一般" };
  for (const [key, value] of Object.entries(values)) if (h.state.has(key)) h.state.set(key, value);
  if (name === "CreateCaseLab") { h.state.set("returnedSamples", [{ id: "sample", markCode: "AB12" }]); h.state.set("sampleCount", "1"); h.state.set("sampleReceivedAt", "2026-09-11"); }
  h.render(); const submit = h.one(node => node.type === "button" && node.props.onClick?.name === "finalSubmit");
  assert.equal(submit.props.disabled, false, JSON.stringify(h.state.get("productIds")));
  h.act(submit.props.onClick); assert.equal(created.length, 1);
  const result = h.api.mockCases.find(item => item.id === created[0]);
  assert.equal(result.tasks.length, 0); assert.ok(result.relatedCaseIds.includes(source.id)); assert.ok(source.relatedCaseIds.includes(result.id));
  assert.ok(h.api.linksOfCase(result.id).some(link => link.from === source.id || link.to === source.id));
  if (name === "CreateCaseLab") { assert.equal(result.projectName, "独立项目名称"); assert.equal(result.failPlatform, "Intel SPR"); }
  h.act(h.button("重置").props.onClick); assert.equal(h.state.get("inheritedCase"), null);
});

test("lab customer/project controls are single selects with a mandatory project independent from the CPU platform", () => {
  const h = harness("CreateCaseLab", { onDone() {} });
  for (const label of ["项目名称", "客户名称", "客户应用", "CPU·SoC 平台名称", "产品PN"]) {
    const field = h.one(node => node.props.label === label && typeof node.props.onChange === "function");
    const markup = renderToStaticMarkup(field);
    assert.match(markup, new RegExp(`<select[^>]*aria-label="${label}"`)); assert.doesNotMatch(markup, /multiple=""|<input/);
    if (label === "项目名称") assert.match(markup, /required=""/);
  }
  h.act(h.one(node => node.props.label === "项目名称" && node.props.onChange).props.onChange, "新项目");
  h.act(h.one(node => node.props.label === "CPU·SoC 平台名称" && node.props.onChange).props.onChange, "AMD Genoa");
  assert.equal(h.state.get("projectName"), "新项目"); assert.equal(h.state.get("failPlatform"), "AMD Genoa");
  const source = readFileSync(new URL("CreateCaseLab.tsx", directory), "utf8");
  assert.match(source, /!projectName\.trim\(\) && "项目名称"/);
  assert.ok(source.indexOf('<CaseSingleChoice label="项目名称"') < source.indexOf('<CaseSingleChoice label="客户名称"'));
});

test("global search has five sibling tabs with separate Case-task and independent-task counts and exact navigation", () => {
  const tasks = Array.from({ length: 12 }, (_, index) => ({ id: `search-${index}`, code: `SEARCH-${index}`, title: `检索自由任务 ${index}`, description: "搜索说明", owner: "张伟", createdBy: "李娜", collaborators: [], status: "进行中", urgency: "一般", dueDate: "2026-09-20", attachments: [], createdAt: "2026-09-11", updatedAt: "2026-09-11" }));
  const opened = [];
  const h = harness("TopBar", { breadcrumb: [], onFeedback() {}, onCreateCase() {}, onCreateTask() {}, onOpenCase: id => opened.push(["case", id]), onOpenTask: (...ids) => opened.push(["case-task", ...ids]), onOpenStandaloneTask: id => opened.push(["standalone", id]) }, [["ea_standalone_tasks_v1", JSON.stringify(tasks)]]);
  h.state.set("searchOpen", true); h.state.set("tab", "task"); h.state.set("q", "检索自由任务"); h.render();
  const root = h.one(node => typeof node.props.onValueChange === "function" && node.props.value === "task");
  const tabs = h.one(node => node.props["aria-label"] === "全局搜索分类");
  const tabValues = ["all", "user", "case", "task", "standalone"];
  assert.deepEqual(elements(tabs).filter(node => tabValues.includes(node.props.value)).map(node => [node.props.value, text(node)]), [["all", "全部12"], ["user", "用户0"], ["case", "Case0"], ["task", "Case任务0"], ["standalone", "自由任务12"]]);
  assert.equal(elements(h.tree).some(node => node.props["aria-label"] === "搜索任务来源"), false);
  assert.match(h.render(), /未找到匹配结果/);
  const html = h.act(root.props.onValueChange, "standalone");
  assert.match(html, /Case任务/); assert.match(html, /自由任务/);
  const results = elements(h.tree).filter(node => node.type === "button" && text(node).includes("SEARCH-"));
  assert.equal(results.length, 12);
  h.act(results.at(-1).props.onClick); assert.deepEqual(opened, [["standalone", "search-11"]]);
  h.state.set("searchOpen", true); h.state.set("q", ""); h.render();
  h.act(h.one(node => typeof node.props.onValueChange === "function").props.onValueChange, "task");
  assert.equal(elements(h.tree).filter(node => node.type === "button" && text(node).includes("SEARCH-")).length, 0);
  const caseResult = elements(h.tree).find(node => node.type === "button" && text(node).startsWith("Case任务"));
  assert.ok(caseResult); h.act(caseResult.props.onClick); assert.equal(opened.at(-1)[0], "case-task");
});

test("complaint scope uses the explicit Q-FAQA source, combines filters, counts once and resets without writes", () => {
  const h = harness("CaseList", { initialView: "list", onOpenCase() {} });
  const base = h.api.mockCases[0];
  const records = [
    { id: "complaint-a", name: "筛选回归-客诉A", source: "Q·FAQA", level: "L1" },
    { id: "complaint-b", name: "筛选回归-客诉B", source: "Q·FAQA", level: "L2" },
    { id: "manual", name: "筛选回归-客诉标题但手动来源", source: "手动", caseAttribute: "VOC", level: "L1" },
    { id: "fanout", name: "筛选回归-Fanout", source: "fanout验证", level: "L1" },
  ].map(item => ({ ...base, tasks: [], participants: [], departments: [], status: "进行中", customer: "客户名称", fanoutSourceCaseId: undefined, ...item }));
  h.api.mockCases.splice(0, h.api.mockCases.length, ...records); h.state.set("filterOpen", true); h.render();
  const before = JSON.stringify(records); const storage = [...h.storage.entries()];
  const panel = () => h.one(node => node.props.scopeContent?.props["aria-label"] === "Case 筛选范围");
  const scopeButton = label => elements(panel().props.scopeContent).find(node => node.type === "button" && text(node).trim() === label);
  const names = () => elements(h.tree).filter(node => node.type === "button" && typeof node.props.children === "string" && node.props.children.startsWith("筛选回归-")).map(text);
  assert.equal(scopeButton("客诉Case").props["aria-pressed"], false);
  h.act(scopeButton("客诉Case").props.onClick);
  assert.equal(h.state.get("scope"), "complaint"); assert.equal(scopeButton("客诉Case").props["aria-pressed"], true);
  assert.deepEqual(names().sort(), ["筛选回归-客诉A", "筛选回归-客诉B"]);
  assert.ok(elements(h.tree).some(node => node.props["aria-label"] === "筛选 1"));
  h.act(panel().props.onChange, "level", "L1"); assert.deepEqual(names(), ["筛选回归-客诉A"]);
  assert.ok(elements(h.tree).some(node => node.props["aria-label"] === "筛选 2"));
  h.act(panel().props.onChange, "product", "不存在产品"); assert.deepEqual(names(), []);
  h.act(panel().props.onReset); assert.equal(h.state.get("scope"), "all"); assert.equal(names().length, 3);
  assert.ok(elements(h.tree).some(node => node.props["aria-label"] === "筛选"));
  assert.equal(JSON.stringify(records), before); assert.deepEqual([...h.storage.entries()], storage);
});