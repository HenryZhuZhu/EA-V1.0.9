import test from "node:test";
import assert from "node:assert/strict";
import { build } from "esbuild";
import vm from "node:vm";
import { webcrypto } from "node:crypto";
import { fileURLToPath } from "node:url";
const { outputFiles } = await build({stdin:{contents:`export * from './recordRecovery'; export {currentUser,mockCases,flattenTasks} from './data'; export * from './closures'; export * from './caseTaskTrees'; export * from './standaloneTasks';`,resolveDir:fileURLToPath(new URL('../src/app/components/',import.meta.url))},bundle:true,write:false,format:'cjs',platform:'node',plugins:[{name:'hooks',setup(builder){builder.onResolve({filter:/^react$/},()=>({path:'react',namespace:'stub'}));builder.onLoad({filter:/.*/,namespace:'stub'},()=>({contents:'export const useEffect=()=>{};export const useState=()=>[0,()=>{}];'}));}}]});
const environment = (storage=new Map(),fail=false) => { const box={module:{exports:{}},crypto:webcrypto,btoa,atob,localStorage:{getItem:key=>storage.get(key)??null,setItem:(key,value)=>{if(fail)throw Error('quota');storage.set(key,value);}}};vm.runInNewContext(outputFiles[0].text,box);return box.module.exports; };
test('recovery keeps original results and completes without a separate outcome',()=>{
  const api=environment();const original={id:'task',status:'已完成',conclusion:'原结论',attachments:[{name:'证据'}]};
  const next=api.startRecovery(original,'return','请补齐对照',['张伟','李娜']);
  assert.equal(next.id,original.id);assert.equal(next.conclusion,'原结论');assert.equal(api.needsCorrection(next),true);
  assert.equal(next.recovery[0].before.conclusion,'原结论');assert.equal(api.finishRecovery(next).recovery[0].outcome,undefined);
  assert.throws(()=>api.startRecovery(next,'return','重复',[]),/已有/);
  const done=api.finishRecovery(next);assert.equal(api.needsCorrection(done),false);
  assert.ok(done.recovery[0].completedAt);assert.equal(original.recovery,undefined);
  const supplemented=api.supplementRecord(done,'补充附件说明');assert.equal(supplemented.status,'已完成');assert.equal(supplemented.conclusion,'原结论');
});
test('only the actual direct supervisor may reopen, not the owner, dispatcher or another manager',()=>{
  const api=environment();
  for(const actor of ['张伟','李娜','高总监','马总监','林副总']) assert.equal(api.canReopenRecord('张伟',actor),false,actor);
  assert.equal(api.canReopenRecord('张伟','周主管'),true);
  assert.equal(api.canReopenRecord('周主管','高总监'),true);
  assert.equal(api.canReopenRecord('高总监','林副总'),true);
  assert.equal(api.canReopenRecord('不存在','周主管'),false);
  assert.throws(()=>api.validateRecoveryAction('张伟','reopen'),/直属主管/);
  assert.throws(()=>api.validateRecoveryAction('张伟','outcome'),/原文档/);
});
test('department managers can correct scoped owners but visibility and ownership alone are insufficient',()=>{
  const api=environment();assert.equal(api.canReturnRecord('张伟','高总监'),true);assert.equal(api.canReturnRecord('张伟','周主管'),true);
  assert.equal(api.canReturnRecord('张伟','马总监'),false);assert.equal(api.canReturnRecord('张伟','张伟'),false);assert.equal(api.canReturnRecord('不存在','林副总'),false);
  assert.throws(()=>api.startRecovery({},'reopen',' ',[]),/原因/);assert.throws(()=>api.supplementRecord({},'x'.repeat(2001)),/2000/);
});

const caseFixture = api => {
  const item={...api.mockCases[0],id:'recovery-case',owner:'张伟',createdBy:'李娜',status:'已关闭',tasks:[{id:'execution',code:'TEST.001',title:'验证',owner:'张伟',supervisor:'李娜',department:'PTE',urgency:'一般',status:'已完成',progress:100,conclusion:'原结论',attachments:[{name:'原证据',kind:'file'}]}]};
  api.mockCases.push(item);return item;
};
test('supervisor reopens Case and task, owners revise original documents and complete without outcome fields',()=>{
  const storage=new Map();const api=environment(storage);const item=caseFixture(api);
  assert.throws(()=>api.recoverCaseTask(item.id,'execution','reopen','补验证'),/先重新开启/);
  api.recoverCase(item.id,'supplement','补充旧资料');assert.equal(api.isCaseClosed(item.id),true);
  assert.throws(()=>api.recoverCase(item.id,'reopen','需要新对照'),/直属主管/);
  api.currentUser.name='周主管';api.recoverCase(item.id,'reopen','已线下沟通，需要新对照');assert.equal(api.isCaseClosed(item.id),false);assert.equal(item.status,'进行中');
  assert.equal(api.getClosure(item.id).recovery.at(-1).before.caseInfo.status,'已关闭');
  api.recoverCaseTask(item.id,'execution','reopen','补验证');
  assert.equal(api.loadCaseTaskTree(item.id,item.tasks)[0].status,'进行中');
  assert.equal(api.loadCaseTaskTree(item.id,item.tasks)[0].recovery.at(-1).by,'周主管');
  api.currentUser.name='张伟';
  api.updateCaseTask(item.id,'execution',{conclusion:'原文档修订结论',analysisProcess:'原文档补充验证过程'});
  api.saveCaseWorkspace(item.id,{conclusion:'Case文档修订结论',process:'根因已复核',attachments:[]});
  assert.throws(()=>api.submitClosure({caseId:item.id,conclusion:'新结论',submittedBy:'张伟'}),/正在重新处理/);
  api.updateCaseTask(item.id,'execution',{status:'已完成'});
  api.submitClosure({caseId:item.id,conclusion:'Case文档修订结论',submittedBy:'张伟'});
  assert.equal(api.isCaseClosed(item.id),true);assert.ok(api.getClosure(item.id).recovery.at(-1).completedAt);
  const reloaded=environment(storage);const again=caseFixture(reloaded);assert.equal(reloaded.isCaseClosed(again.id),true);
  assert.equal(reloaded.loadCaseTaskTree(again.id,again.tasks)[0].recovery[0].before.conclusion,'原结论');
  assert.equal(reloaded.loadCaseTaskTree(again.id,again.tasks)[0].conclusion,'原文档修订结论');
  assert.equal(reloaded.getClosure(again.id).workspace.conclusion,'Case文档修订结论');
  assert.equal(reloaded.getClosure(again.id).recovery.at(-1).outcome,undefined);
});
test('reviewed Case is reopened by direct supervisor, not owner or reviewer; reclosure still needs original reviewer',()=>{
  const storage=new Map([['ea_case_closures_v4',JSON.stringify({'recovery-case':{caseId:'recovery-case',state:'closed',conclusion:'已审核结论',approvedBy:'高总监',closedAt:'2026-09-01'}})]]);
  const api=environment(storage);const item=caseFixture(api);
  assert.throws(()=>api.recoverCase(item.id,'reopen','修正依据'),/直属主管/);
  api.currentUser.name='高总监';assert.throws(()=>api.recoverCase(item.id,'reopen','修正依据'),/直属主管/);
  assert.equal(api.isCaseClosed(item.id),true);
  api.currentUser.name='周主管';api.recoverCase(item.id,'reopen','已沟通，补充复现记录');
  assert.equal(api.isCaseClosed(item.id),false);assert.equal(api.getClosure(item.id).recovery.at(-1).by,'周主管');assert.equal(api.getClosure(item.id).approval,undefined);
  api.currentUser.name='张伟';api.saveCaseWorkspace(item.id,{conclusion:'修正结论',process:'新证据',attachments:[]});api.submitClosure({caseId:item.id,conclusion:'修正结论',submittedBy:'张伟'});
  assert.equal(api.isCaseClosed(item.id),false);const close=api.getClosure(item.id).approval;assert.equal(close.kind,'closure');
  assert.throws(()=>api.decideCaseRecovery(item.id,close.id,true,''),/审核人/);
  api.currentUser.name='高总监';api.decideCaseRecovery(item.id,close.id,true,'复核通过');assert.equal(api.isCaseClosed(item.id),true);assert.equal(api.getClosure(item.id).conclusion,'修正结论');
});
test('manager scope, immutable supplements and storage failures are enforced by services',()=>{
  const storage=new Map();const api=environment(storage);const item=caseFixture(api);item.status='进行中';
  api.currentUser.name='马总监';assert.throws(()=>api.recoverCase(item.id,'return','整改'),/权限/);assert.throws(()=>api.recoverCaseTask(item.id,'execution','return','整改'),/权限/);
  api.currentUser.name='高总监';api.recoverCaseTask(item.id,'execution','return','请复测');assert.equal(api.needsCorrection(api.loadCaseTaskTree(item.id,item.tasks)[0]),true);assert.equal(api.getClosure(item.id),undefined);
  api.currentUser.name='张伟';assert.throws(()=>api.recoverCaseTask(item.id,'execution','reopen','重复'),/直属主管/);
  const failed=environment(new Map(),true);const unchanged=caseFixture(failed);failed.currentUser.name='周主管';assert.throws(()=>failed.recoverCase(unchanged.id,'reopen','重开'),/保存失败/);assert.equal(unchanged.status,'已关闭');assert.equal(failed.getClosure(unchanged.id),undefined);
});
test('free tasks reopen on the same ID, keep attachments and notify the creator on completion',()=>{
  const task={id:'free',code:'TASK-FREE',title:'已完成事项',description:'说明',owner:'张伟',createdBy:'李娜',createdForOther:true,collaborators:[],urgency:'一般',dueDate:'2026-10-01',attachments:[],status:'已完成',conclusion:'旧结果',createdAt:'2026-09-01',updatedAt:'2026-09-02'};
  const storage=new Map([['ea_standalone_tasks_v1',JSON.stringify([task])]]);const api=environment(storage);
  api.recoverStandaloneTask(task.id,'supplement','补充记录',[{name:'追加.txt',kind:'file',url:'data:text/plain,ok'}]);assert.equal(api.standaloneTaskById(task.id).status,'已完成');
  for(const actor of ['张伟','李娜','高总监','马总监']) {api.currentUser.name=actor;assert.throws(()=>api.recoverStandaloneTask(task.id,'reopen','补做'),/直属主管/);}
  api.currentUser.name='周主管';api.recoverStandaloneTask(task.id,'reopen','线下沟通后补做');
  assert.throws(()=>api.recoverStandaloneTask(task.id,'reopen','再次补做'),/已完成/);
  api.currentUser.name='张伟';api.saveStandaloneTaskWorkspace(task.id,{conclusion:'新结果',analysisProcess:'原文档新增验证',resultAttachments:[{name:'新结果.txt',kind:'file'}]});
  assert.throws(()=>api.completeStandaloneTask(task.id,{conclusion:' '}),/结论/);
  api.completeStandaloneTask(task.id,{conclusion:'新结果'});
  const saved=api.standaloneTaskById(task.id);assert.equal(saved.id,task.id);assert.equal(saved.recovery.at(-1).before.conclusion,'旧结果');assert.ok(saved.recovery.at(-1).completedAt);assert.ok(saved.recovery.at(-1).recipients.includes('李娜'));
  assert.equal(environment(storage).standaloneTaskById(task.id).recovery[0].files[0].name,'追加.txt');
  assert.equal(saved.recovery.at(-1).by,'周主管');assert.equal(saved.recovery.at(-1).outcome,undefined);assert.equal(saved.analysisProcess,'原文档新增验证');assert.equal(saved.resultAttachments[0].name,'新结果.txt');
});

test('Case editing and Workspace persist after reopening but cannot bypass closure, approval or ownership',()=>{
  const storage=new Map();const api=environment(storage);const item=caseFixture(api);
  assert.throws(()=>api.saveCaseEdit(item.id,{name:'偷改'}),/已结案/);
  assert.throws(()=>api.saveCaseWorkspace(item.id,{conclusion:'偷改',process:'',attachments:[]}),/已结案/);
  api.currentUser.name='周主管';api.recoverCase(item.id,'reopen','更新内容');api.currentUser.name='张伟';api.saveCaseEdit(item.id,{id:'不能覆盖',owner:'李娜',status:'已关闭',name:'已修改标题',background:'补充背景'});
  assert.equal(item.id,'recovery-case');assert.equal(item.owner,'张伟');assert.equal(item.status,'进行中');assert.equal(item.name,'已修改标题');
  api.saveCaseWorkspace(item.id,{conclusion:'修订结论',process:'复测过程',attachments:[{name:'新证据.txt',kind:'file'}]});
  const reloaded=environment(storage);const restored=caseFixture(reloaded);const record=reloaded.getClosure(restored.id);
  assert.equal(restored.name,'已修改标题');assert.equal(record.workspace.conclusion,'修订结论');assert.equal(record.workspace.attachments[0].name,'新证据.txt');
  assert.equal(record.recovery[0].before.caseInfo.name,api.mockCases[0].name);
  reloaded.currentUser.name='李娜';assert.throws(()=>reloaded.saveCaseWorkspace(restored.id,{conclusion:'越权',process:'',attachments:[]}),/Owner/);
});

test('legacy reopen approvals cannot bypass the supervisor and are archived without fabricating a decision',()=>{
  const request={id:'legacy-request',kind:'reopen',requestedBy:'张伟',requestedAt:'2026-09-19',reason:'原申请',reviewer:'高总监'};
  const storage=new Map([['ea_case_closures_v4',JSON.stringify({'recovery-case':{caseId:'recovery-case',state:'closed',approvedBy:'高总监',approval:request}})]]);
  const api=environment(storage);const item=caseFixture(api);
  assert.equal(api.pendingCaseRecoveries().length,0);
  api.currentUser.name='高总监';assert.throws(()=>api.decideCaseRecovery(item.id,request.id,true,'批准'),/线下沟通/);
  assert.throws(()=>api.decideCaseRecovery(item.id,request.id,false,'驳回'),/线下沟通/);
  assert.equal(api.isCaseClosed(item.id),true);
  api.currentUser.name='周主管';api.recoverCase(item.id,'reopen','已与负责人线下确认');
  const saved=api.getClosure(item.id);assert.equal(saved.approval,undefined);
  assert.deepEqual(JSON.parse(JSON.stringify(saved.approvalHistory)),[request]);assert.equal(saved.recovery.at(-1).by,'周主管');
  assert.equal(saved.recovery.at(-1).before.approval.id,request.id);
  api.currentUser.name='张伟';api.submitClosure({caseId:item.id,conclusion:'修正结论',submittedBy:'张伟'});
  api.currentUser.name='周主管';assert.throws(()=>api.recoverCase(item.id,'return','再退回'),/待处理的审批/);
});

test('legacy outcomes remain immutable and unsupported outcome writes cannot change any record',()=>{
  const old={id:'old',kind:'return',by:'周主管',at:'2026-09-19',reason:'原要求',recipients:['张伟'],outcome:'历史处理说明',outcomeBy:'张伟',outcomeAt:'2026-09-19'};
  const task={id:'legacy-task',code:'LEGACY',owner:'张伟',status:'进行中',conclusion:'已保存结论',recovery:[old]};
  const storage=new Map([['ea_standalone_tasks_v1',JSON.stringify([task])]]);const api=environment(storage);const item=caseFixture(api);item.status='进行中';
  assert.throws(()=>api.recoverStandaloneTask(task.id,'outcome','另写'),/原文档/);
  assert.throws(()=>api.recoverCaseTask(item.id,'execution','outcome','另写'),/原文档/);
  assert.throws(()=>api.recoverCase(item.id,'outcome','另写'),/原文档/);
  api.completeStandaloneTask(task.id,{conclusion:'文档里的结果'});
  const history=api.standaloneTaskById(task.id).recovery[0];assert.equal(history.outcome,old.outcome);assert.equal(history.outcomeAt,old.outcomeAt);assert.ok(history.completedAt);
});

test('feedback dates, genuine edit timestamps and immutable submitted differences do not require manager confirmation',()=>{
  const api=environment();
  assert.throws(()=>api.startRecovery({},'return','补证据',['张伟'],'2026-02-30'),/日期/);
  const start=api.startRecovery({conclusion:'原结论'},'return','补证据',['张伟'],'2026-10-01');
  assert.equal(start.recovery[0].dueDate,'2026-10-01');
  assert.equal(api.trackRecoveryEdit(start,{...start,status:'进行中'}).recovery[0].startedAt,undefined);
  const edited=api.trackRecoveryEdit(start,{...start,conclusion:'修订结论'});assert.ok(edited.recovery[0].startedAt);
  const submitted=api.submitRecovery(edited);assert.ok(submitted.recovery[0].submittedAt);assert.equal(submitted.recovery[0].completedAt,undefined);
  assert.deepEqual(JSON.parse(JSON.stringify(api.recoveryDifferences(submitted.recovery[0]))),[{field:'结论',before:'原结论',after:'修订结论'}]);
  const done=api.finishRecovery(submitted);assert.ok(done.recovery[0].completedAt);assert.equal(done.recovery[0].submittedAt,submitted.recovery[0].submittedAt);
  assert.equal(done.recovery[0].confirmedAt,undefined);assert.equal(start.conclusion,'原结论');
});

test('reopened persisted Cases remain editable when notifications initialize before the Case catalog',()=>{
  const storage=new Map([['ea_case_closures_v4',JSON.stringify({'recovery-case':{caseId:'recovery-case',state:'reopened',recovery:[{id:'run',kind:'reopen',by:'周主管',at:'2026-09-20',reason:'已线下确认',recipients:['张伟']}]}})]]);
  const api=environment(storage);api.allClosureRecords();const item=caseFixture(api);
  item.tasks[0].status='进行中';assert.equal(api.caseTaskReadOnlyReason(item.id),undefined);
  api.updateCaseTask(item.id,'execution',{conclusion:'刷新后可修改'});assert.equal(api.loadCaseTaskTree(item.id,item.tasks)[0].conclusion,'刷新后可修改');
});

test('free tasks reject manager returns without writes while preserving prior records and supervisor reopening',()=>{
  const original={id:'no-return-free',code:'FREE-ONLY',title:'无需整改',owner:'张伟',createdBy:'李娜',status:'已完成',conclusion:'原结论',attachments:[],createdAt:'2026-09-01',updatedAt:'2026-09-20',recovery:[{id:'old-return',kind:'return',by:'高总监',at:'2026-09-01',completedAt:'2026-09-02',reason:'历史要求',recipients:['张伟']}]};
  const storage=new Map([['ea_standalone_tasks_v1',JSON.stringify([original])]]);const api=environment(storage);const before=storage.get('ea_standalone_tasks_v1');
  for(const actor of ['周主管','高总监','林副总']){api.currentUser.name=actor;assert.throws(()=>api.recoverStandaloneTask(original.id,'return','不再支持'),/自由任务不支持退回整改/);assert.equal(storage.get('ea_standalone_tasks_v1'),before);}
  api.currentUser.name='张伟';api.recoverStandaloneTask(original.id,'supplement','追加资料');api.currentUser.name='周主管';api.recoverStandaloneTask(original.id,'reopen','线下沟通后重开');
  assert.equal(api.standaloneTaskById(original.id).status,'进行中');assert.equal(api.standaloneTaskById(original.id).recovery[0].reason,'历史要求');
});

test('VP examples cover pending, editing, overdue and submitted feedback without overwriting saved edits',()=>{
  const storage=new Map();const api=environment(storage);const cases=api.mockCases.filter(item=>item.id.startsWith('vp-recovery-example-'));
  assert.equal(cases.length,6);assert.equal(new Set(cases.map(item=>item.code)).size,6);
  const records=cases.map(item=>api.getClosure(item.id));assert.ok(records.every(record=>record.recovery[0].by==='林副总'));
  assert.equal(records.filter(record=>record.recovery[0].completedAt).length,2);
  assert.equal(records.filter(record=>!record.recovery[0].startedAt).length,2);
  assert.equal(records.filter(record=>record.recovery[0].startedAt&&!record.recovery[0].submittedAt).length,2);
  assert.equal(records.filter(record=>!record.recovery[0].submittedAt&&record.recovery[0].dueDate<'2026-09-21').length,2);
  for(const record of records.filter(item=>item.recovery[0].submittedAt))assert.ok(api.recoveryDifferences(record.recovery[0]).length>0);
  api.currentUser.name=cases[0].owner;api.saveCaseWorkspace(cases[0].id,{conclusion:'用户已修改的示例结论',process:'补充了实际验证过程',attachments:[]});
  const reloaded=environment(storage);assert.equal(reloaded.getClosure(cases[0].id).workspace.conclusion,'用户已修改的示例结论');assert.equal(reloaded.mockCases.filter(item=>item.id.startsWith('vp-recovery-example-')).length,6);
  assert.equal(environment().getClosure(cases[0].id).workspace.conclusion,records[0].workspace.conclusion);
});