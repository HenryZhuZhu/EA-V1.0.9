import assert from "node:assert/strict";
import test from "node:test";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";
import vm from "node:vm";
import { build } from "esbuild";
import { createElement, Fragment, isValidElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";

const require = createRequire(import.meta.url);
const React = require("react");
const { outputFiles } = await build({
  stdin: {
    contents: `
      export { TaskSourceColumn, TASK_COLUMN_SORT_OPTIONS } from "./TaskSourceColumn";
      export { WorkbenchSort } from "./WorkbenchSort";
      export { TaskStatusSummary } from "./TaskStatusSummary";
      export { WorkbenchTaskCard } from "./WorkbenchTaskCard";
      export { TaskWorkbenchFilters } from "./TaskWorkbenchFilters";
      export { TaskReferenceFilter } from "./TaskReferenceFilter";
      export { MyTaskWorkbench } from "./MyTaskWorkbench";
      export { buildWorkbenchTasks } from "./taskWorkbenchModel";
      export { createTaskWorkbenchState, updateTaskWorkbenchState } from "./taskWorkbenchState";
    `,
    resolveDir: fileURLToPath(new URL("../src/app/components/", import.meta.url)),
    sourcefile: "task-workbench-columns-presentation-test-entry.ts", loader: "ts",
  },
  bundle: true, write: false, platform: "node", format: "cjs", jsx: "automatic",
  packages: "external", external: ["./data", "./standaloneTasks", "./caseTaskTrees", "./closures"],
});
const actor = { name: "张伟", department: "PTE" };
const products = [{ id: "p1", code: "DDR5", name: "产品一" }, { id: "p2", code: "LPDDR", name: "产品二" }];
const statuses = ["待接受", "进行中", "已完成"];
const sources = ["case", "standalone"];
const plain = value => JSON.parse(JSON.stringify(value));
function flattenTasks(nodes) { return nodes.flatMap(task => [{ task }, ...flattenTasks(task.children ?? [])]); }
function freeze(value) {
  if (value && typeof value === "object" && !Object.isFrozen(value)) {
    Object.values(value).forEach(freeze); Object.freeze(value);
  }
  return value;
}
// Store reads/data lookups are adapted. Callback tests may externalize only the
// workbench state slot; child hooks, models, cards, ReactDOM and Radix remain real.
function harness({ trees = {}, closed = [], initialState, controlledWorkbench = false } = {}) {
  const treeReads = []; const writes = [];
  const noWrite = (...args) => { writes.push(args); throw new Error("SSR must not write task data"); };
  const loadTree = (id, fallback) => {
    treeReads.push({ id, fallback });
    return Object.hasOwn(trees, id) ? trees[id] : fallback;
  };
  let api; let state = initialState; let tree;
  const stateUpdates = [];
  const stubs = {
    "./data": {
      flattenTasks, currentUser: actor, mockProducts: products,
      ownerToDepartment: { 张伟: "PTE", 刘洋: "PTE", 李娜: "DA", 王强: "FT" },
      reportsTo: name => name === actor.name ? "刘洋" : null,
      levelColors: { L1: "level-l1" }, urgencyBar: { 紧急: "bg-orange-400", 一般: "bg-blue-400" },
    },
    "./standaloneTasks": { updateStandaloneTaskStatus: noWrite },
    "./caseTaskTrees": { loadCaseTaskTree: loadTree, useCaseTaskRevision: () => 0, respondToCaseTask: noWrite },
    "./closures": { useClosures: () => ({ isClosed: id => closed.includes(id) }) },
  };
  // Seed a saved workbench snapshot for SSR without replacing hooks or selectors.
  // The initializer identity ensures no other component's useState is intercepted.
  if (initialState || controlledWorkbench) stubs.react = { ...React, useState(initial) {
    if (initial === api.createTaskWorkbenchState && controlledWorkbench) {
      if (state === undefined) state = initial();
      return [state, next => {
        const previous = state;
        state = typeof next === "function" ? next(previous) : next;
        stateUpdates.push({ previous, next: state });
      }];
    }
    return React.useState(initial === api.createTaskWorkbenchState && initialState ? () => initialState : initial);
  } };
  const sandbox = { module: { exports: {} }, require: name => Object.hasOwn(stubs, name) ? stubs[name] : require(name) };
  for (const name of ["localStorage", "sessionStorage"]) Object.defineProperty(sandbox, name, {
    get() { throw new Error(`${name} must not be accessed by column tests`); },
  });
  vm.runInNewContext(outputFiles[0].text, sandbox);
  api = sandbox.module.exports;
  return { ...api, treeReads, writes, stateUpdates,
    get state() { return state; }, get tree() { return tree; },
    renderWorkbench(props) {
      function Probe() { tree = api.MyTaskWorkbench(props); return tree; }
      return renderToStaticMarkup(createElement(Probe));
    },
  };
}
const render = (Component, props) => renderToStaticMarkup(createElement(Component, props));
const buttons = html => html.match(/<button\b[^>]*>[\s\S]*?<\/button>/g) ?? [];
const articles = html => html.match(/<article\b[^>]*>[\s\S]*?<\/article>/g) ?? [];
const stripTags = html => html.replace(/<[^>]*>/g, "");
function elements(tree) {
  if (Array.isArray(tree)) return tree.flatMap(elements);
  if (!isValidElement(tree)) return [];
  return [tree, ...elements(tree.props.children)];
}
function childElements(tree) {
  const visit = child => Array.isArray(child) ? child.flatMap(visit)
    : !isValidElement(child) ? [] : child.type === Fragment ? childElements(child) : [child];
  return visit(tree.props.children);
}
function classTokens(tag) {
  return (typeof tag === "string" ? /class="([^"]*)"/.exec(tag)?.[1] : tag.props.className)?.split(/\s+/) ?? [];
}
function assertClasses(tag, expected) {
  const tokens = classTokens(tag);
  for (const token of expected) assert.ok(tokens.includes(token), `Missing class ${token}: ${tag}`);
}
function assertNoNestedButtons(html) {
  let depth = 0;
  for (const tag of html.match(/<\/?button\b[^>]*>/g) ?? []) {
    if (tag.startsWith("</")) { assert.equal(depth, 1); depth--; }
    else { assert.equal(depth, 0, `Nested button: ${tag}`); depth++; }
  }
  assert.equal(depth, 0);
}
function assertNoTaskActions(html) {
  for (const button of buttons(html)) assert.doesNotMatch(stripTags(button), /^(接受并开始|拒绝|处理任务|完成任务|完成|中止|退回重做)$/);
}
function columnMarkup(html, source) {
  const title = source === "case" ? "Case 任务" : "自由任务";
  const start = html.indexOf(`<section aria-label="${title}"`);
  assert.notEqual(start, -1, `Missing ${title} column`);
  const end = html.indexOf("</section>", start);
  assert.notEqual(end, -1);
  return html.slice(start, end + "</section>".length);
}
function assertColumnSorters(html) {
  assert.equal((html.match(/<select\b/g) ?? []).length, 0, "My Tasks has no sort or filter selects");
  for (const source of sources) {
    const column = columnMarkup(html, source);
    const header = /<header\b[^>]*>[\s\S]*?<\/header>/.exec(column)?.[0];
    assert.ok(header);
    const title = source === "case" ? "Case 任务" : "自由任务";
    assert.equal((header.match(/<select\b/g) ?? []).length, 0);
    assert.ok(!header.includes(`aria-label="${title}排序"`));
  }
  const beforeColumns = html.slice(0, html.indexOf('<section aria-label="任务列表"'));
  assert.doesNotMatch(beforeColumns, /<select\b|>排序<|排序方式|aria-label="[^"]*排序"/);
}
const noops = { onShowTask() {}, onOpenCase() {}, onTakeAction() {}, onReject() {} };
const columnProps = (source, rows) => ({ source, rows, resetKey: "snapshot", businessKey: "", sortBy: "due", onSortChange() {}, ...noops });
const workbenchProps = (cases = [], tasks = []) => ({ cases, tasks, onOpenTask() {}, onOpenCase() {}, onOpenStandaloneTask() {} });
const row = (id, source = "standalone", patch = {}) => ({
  key: `${source}:${id}`, id, source, code: `TASK-${id}`, title: `任务 ${id}`, description: "完整任务说明",
  owner: actor.name, creator: "刘洋", participants: [], participantsFromCase: false, status: "进行中", urgency: "紧急",
  dueDate: "2026-09-12", updatedAt: "2026-09-09T08:00:00Z", caseClosed: false,
  caseItem: source === "case" ? { id: "c1", name: "关联问题", code: "CASE-1", level: "L1", owner: "刘洋" } : undefined,
  business: [], attachmentCount: 2, hasVoice: true, record: {}, ...patch,
});
const action = (id, patch = {}) => ({ id, code: `EA-${id}`, title: `执行 ${id}`, owner: actor.name, supervisor: "刘洋", collaborators: [], status: "待接受", urgency: "一般", dueDate: "2026-09-12", ...patch });
const task = (id, patch = {}) => ({ id, code: `TASK-${id}`, title: `独立 ${id}`, description: "说明", owner: actor.name, createdBy: "刘洋", collaborators: [], status: "待接受", urgency: "一般", attachments: [], updatedAt: "2026-09-09T08:00:00Z", ...patch });
const caseItem = (id, tasks, patch = {}) => ({ id, code: `CASE-${id}`, name: `问题 ${id}`, owner: "刘洋", participants: [], status: "进行中", level: "L1", updatedAt: "2026-09-09T08:00:00Z", tasks, ...patch });

for (const source of sources) test(`${source} source column SSR retains its name, full count and all cards in a keyboard-focusable scroller without pagination`, () => {
  const { TaskSourceColumn } = harness();
  const rows = freeze(Array.from({ length: 12 }, (_, i) => row(String(i).padStart(2, "0"), source)));
  const before = JSON.stringify(rows);
  const html = render(TaskSourceColumn, columnProps(source, rows));
  const title = source === "case" ? "Case 任务" : "自由任务";
  assert.ok(html.startsWith(`<section aria-label="${title}"`));
  assert.match(html, new RegExp(`<h2[^>]*>${title}</h2>`));
  assert.match(html, /<header\b[^>]*>[\s\S]*?<span[^>]*>12<\/span>[\s\S]*?<\/header>/);
  const root = /^<section\b[^>]*>/.exec(html)?.[0];
  assert.ok(root);
  assertClasses(root, ["flex", "min-h-0", "min-w-0", "flex-col", "overflow-hidden"]);
  const scroller = /<div\b[^>]*role="region"[^>]*>/.exec(html)?.[0];
  assert.ok(scroller);
  assert.ok(scroller.includes(`aria-label="${title}滚动列表"`));
  assert.match(scroller, /tabindex="0"/);
  assertClasses(scroller, ["min-h-0", "flex-1", "overflow-y-auto", "overscroll-contain", "[scrollbar-gutter:stable]", "focus-visible:ring-2"]);
  assert.equal(articles(html).length, 12);
  assert.deepEqual(articles(html).map(article => /aria-label="任务 ([^"]+)"/.exec(article)?.[1]), rows.map(item => item.id));
  assert.doesNotMatch(html, /col-span-2|上一页|下一页|分页|暂无符合条件/);
  assertNoTaskActions(html); assertNoNestedButtons(html);
  assert.equal(JSON.stringify(rows), before);
});

test("both source columns render distinct empty states and zero counts without losing their scroll regions", () => {
  const { TaskSourceColumn } = harness();
  const html = renderToStaticMarkup(createElement(Fragment, null,
    ...sources.map(source => createElement(TaskSourceColumn, { key: source, ...columnProps(source, []) })),
  ));
  assert.equal(articles(html).length, 0);
  assert.equal((html.match(/role="region"/g) ?? []).length, 2);
  assert.equal((html.match(/tabindex="0"/g) ?? []).length, 2);
  assert.equal((html.match(/暂无符合条件的/g) ?? []).length, 2);
  for (const source of sources) {
    const column = columnMarkup(html, source);
    const title = source === "case" ? "Case 任务" : "自由任务";
    assert.ok(column.includes(`暂无符合条件的${title}`));
    assert.match(column, /<header\b[^>]*>[\s\S]*?<span[^>]*>0<\/span>[\s\S]*?<\/header>/);
    assert.match(column, /overflow-y-auto/);
  }
  assert.doesNotMatch(html, /上一页|下一页|第 1/);
});

test("active column cards keep wrapped long titles, owner, selected business/Case context, date and materials without horizontal spans or action buttons", () => {
  const { WorkbenchTaskCard } = harness();
  const title = "完整超长任务标题用于验证双栏内容不会按横向任务行截断".repeat(5) + " <样品>&记录";
  const business = [
    { key: "产品:p1", kind: "产品", name: "DDR5 · 产品一", origin: "case" },
    { key: "产品:p2", kind: "产品", name: "LPDDR · 产品二", origin: "task" },
  ];
  for (const source of sources) {
    const record = freeze(row("long", source, { title, business })); const before = JSON.stringify(record);
    const props = { row: record, columnLayout: true, businessKey: "产品:p2", ...noops };
    const html = render(WorkbenchTaskCard, props);
    const titleButton = buttons(html).find(button => button.includes('aria-label="查看任务 '));
    assert.ok(titleButton);
    const opening = /^<button\b[^>]*>/.exec(titleButton)?.[0];
    assertClasses(opening, ["min-w-0", "flex-1", "break-words", "text-left", "text-[13px]", "font-medium", "leading-snug"]);
    assert.equal(classTokens(opening).includes("truncate"), false);
    assert.ok(stripTags(titleButton).includes(title.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;")));
    assert.doesNotMatch(html, /col-span-2|w-\[74px\]|w-\[96px\]|w-\[100px\]|<样品>/);
    assert.match(html, /title="状态：进行中"/);
    assert.match(html, /title="紧急程度：紧急"/);
    assert.match(html, /title="张伟 · 刘洋 分派"/);
    assert.match(html, /title="2026-09-12"/);
    assert.match(stripTags(html), /已逾期 \d+ 天|今日到期|\d+ 天到期/);
    assert.match(html, /title="2 个附件"/); assert.match(html, /aria-label="有语音备注"/);
    assert.match(titleButton, /TASK-long/); assert.match(titleButton, /完整任务说明/);
    assert.match(titleButton, /DDR5 · 产品一/); assert.match(titleButton, /LPDDR · 产品二/);
    assert.match(stripTags(html), /LPDDR · 产品二/);
    if (source === "case") {
      assert.match(html, /aria-label="查看关联 Case 关联问题"/);
      assert.match(html, /level-l1/); assert.equal(buttons(html).length, 2);
    } else assert.equal(buttons(html).length, 1);
    assertNoTaskActions(html); assertNoNestedButtons(html);
    const titleElement = elements(WorkbenchTaskCard(props)).find(element => element.props["aria-label"] === `查看任务 ${title}`);
    assert.equal(titleElement.props.children, title);
    assert.equal(JSON.stringify(record), before);
  }
});

test("completed column cards retain conclusion, update date, owner/context and materials without active rails or lifecycle actions", () => {
  const { WorkbenchTaskCard } = harness();
  for (const source of sources) {
    const record = row("done", source, { status: "已完成", conclusion: "真实验证结论", business: [{ key: "TF:t1", kind: "TF", name: "专项一", origin: "task" }] });
    const html = render(WorkbenchTaskCard, { row: record, columnLayout: true, businessKey: "", ...noops });
    assert.match(html, /title="状态：已完成"/);
    assert.match(html, /更新 2026-09-09/);
    assert.match(html, /title="2026-09-09T08:00:00Z"/);
    assert.match(html, /真实验证结论/); assert.match(html, /title="张伟 · 刘洋 分派"/);
    assert.match(html, /专项一/); assert.match(html, /title="2 个附件"/); assert.match(html, /aria-label="有语音备注"/);
    assert.doesNotMatch(html, /col-span-2|紧急程度：|今日到期|天到期|已逾期|完成 2026-09-09/);
    assertNoTaskActions(html); assertNoNestedButtons(html);
  }
});

test("nonpending compact cards have exactly two content groups with inline dates and shared context/owner/materials navigation", () => {
  const { WorkbenchTaskCard } = harness();
  for (const source of sources) for (const status of ["进行中", "已完成"]) for (const caseClosed of [false, true]) {
    const events = [];
    const record = freeze(row("compact", source, { status, caseClosed, owner: "李娜完整姓名", creator: "刘洋完整姓名",
      conclusion: "完整验证结论", business: [
        { key: "产品:p1", kind: "产品", name: "DDR5 · 产品一", origin: "case" },
        { key: "产品:p2", kind: "产品", name: "LPDDR · 产品二", origin: "task" },
      ],
    }));
    const before = JSON.stringify(record);
    const props = { row: record, columnLayout: true, businessKey: "产品:p2", ...noops,
      onShowTask: () => events.push("detail"), onOpenCase: id => events.push(["case", id]),
    };
    const tree = WorkbenchTaskCard(props); const html = render(WorkbenchTaskCard, props);
    assert.equal(tree.type, "article"); assert.equal(tree.props["data-layout"], "compact-task");
    assertClasses(tree, ["relative", "min-w-0", "rounded-lg", "px-3", "py-2"]);
    for (const token of ["rounded-xl", "p-4", "pl-5", "px-4", "py-3", "col-span-2"]) assert.equal(classTokens(tree).includes(token), false);
    const children = childElements(tree);
    const rails = children.filter(child => child.props.title === "紧急程度：紧急");
    assert.equal(rails.length, Number(status === "进行中" && !caseClosed));
    const groups = children.filter(child => !rails.includes(child));
    assert.equal(groups.length, 2, "Context must not introduce a third content group");
    const [top, bottom] = groups;
    assert.equal(top.type, "div"); assert.equal(bottom.type, "div");
    assertClasses(top, ["flex", "items-start", "gap-2"]);
    assertClasses(bottom, ["mt-1.5", "flex", "min-w-0", "items-start", "gap-2", "pl-[22px]"]);
    assert.equal(classTokens(bottom).includes("flex-wrap"), false);
    const topItems = childElements(top);
    assert.equal(topItems.length, 3);
    const [badge, title, date] = topItems;
    assert.equal(badge.props.title, status);
    assert.equal(title.type, "button"); assert.equal(title.props.children, record.title);
    assertClasses(title, ["min-w-0", "flex-1", "break-words", "leading-snug"]);
    assert.equal(classTokens(title).includes("truncate"), false);
    assert.equal(date.type, "span"); assertClasses(date, ["inline-flex", "shrink-0"]);
    const active = status === "进行中" && !caseClosed;
    assert.equal(date.props.title, active ? record.dueDate : record.updatedAt);
    const dateHtml = renderToStaticMarkup(date);
    assert.match(stripTags(dateHtml), active ? /已逾期 \d+ 天|今日到期|\d+ 天到期/ : /更新 2026-09-09/);
    for (const value of [record.title, record.code, status === "已完成" ? record.conclusion : record.description,
      `${record.creator} 分派`, ...record.business.map(ref => ref.name)]) assert.ok(title.props.title.includes(value));
    const metadata = childElements(bottom);
    assert.equal(metadata.length, 4 + Number(caseClosed), "Context and materials precede the right-anchored owner in the same flex row");
    const [context, attachments, voice] = metadata;
    const owner = metadata.at(-1);
    const closed = caseClosed ? metadata.at(-2) : undefined;
    assert.ok(context.props.title.includes("DDR5 · 产品一"));
    assert.ok(context.props.title.includes("LPDDR · 产品二"));
    assert.match(stripTags(renderToStaticMarkup(context)), /LPDDR · 产品二/);
    assert.equal(owner.props["data-slot"], "task-owner");
    assertClasses(owner, ["ml-auto", "inline-flex", "w-[72px]", "shrink-0", "items-center", "gap-1"]);
    assert.equal(owner.props.title, `${record.owner} · ${record.creator} 分派`);
    assert.ok(stripTags(renderToStaticMarkup(owner)).endsWith(record.owner));
    assert.equal(classTokens(owner).includes("truncate"), false);
    const [avatar, ownerName] = childElements(owner);
    assertClasses(avatar, ["h-4", "w-4", "shrink-0", "rounded-full"]);
    assertClasses(ownerName, ["min-w-0", "truncate"]); assert.equal(ownerName.props.children, record.owner);
    assert.equal(attachments.props.title, "2 个附件"); assert.equal(voice.props["aria-label"], "有语音备注");
    if (caseClosed) assert.equal(closed.props.children, "Case 已结案");
    assert.deepEqual(events, []); title.props.onClick(); assert.deepEqual(events, ["detail"]);
    if (source === "case") {
      assert.equal(context.type, "button");
      assert.equal(context.props["aria-label"], "查看关联 Case 关联问题");
      context.props.onClick(); assert.deepEqual(events, ["detail", ["case", "c1"]]);
    } else assert.equal(context.type, "span");
    assertNoTaskActions(html); assertNoNestedButtons(html);
    assert.equal(JSON.stringify(record), before);
  }
});

test("compact standalone cards without context or materials keep only the owner row with no empty context gap", () => {
  const { WorkbenchTaskCard } = harness();
  for (const status of ["进行中", "已完成"]) for (const creator of ["刘洋完整姓名", ""]) {
    const record = freeze(row("no-context", "standalone", { status, creator, business: [], attachmentCount: 0, hasVoice: false }));
    const props = { row: record, columnLayout: true, businessKey: "", ...noops };
    const tree = WorkbenchTaskCard(props); const html = render(WorkbenchTaskCard, props);
    const groups = childElements(tree).filter(child => !classTokens(child).includes("absolute"));
    assert.equal(groups.length, 2);
    const bottom = groups[1]; const metadata = childElements(bottom);
    assertClasses(bottom, ["mt-1.5", "flex", "min-w-0", "items-start", "gap-2", "pl-[22px]"]);
    assert.equal(classTokens(bottom).includes("flex-wrap"), false);
    assert.equal(metadata.length, 1, "Missing context/materials must not leave an empty wrapper or spacer");
    assert.equal(metadata[0].type, "span");
    assert.equal(metadata[0].props["data-slot"], "task-owner");
    assertClasses(metadata[0], ["ml-auto", "w-[72px]", "shrink-0"]);
    assert.equal(metadata[0].props.title, creator ? `${record.owner} · ${creator} 分派` : record.owner);
    const [avatar, ownerName] = childElements(metadata[0]);
    assertClasses(avatar, ["h-4", "w-4", "shrink-0"]);
    assertClasses(ownerName, ["min-w-0", "truncate"]); assert.equal(ownerName.props.children, record.owner);
    assert.ok(stripTags(renderToStaticMarkup(bottom)).endsWith(record.owner));
    assert.equal(elements(bottom).some(child => child.type === "div" && child !== bottom), false);
    assert.equal(buttons(html).length, 1);
    assert.doesNotMatch(html, /查看关联 Case|有语音备注|个附件|Case 已结案|space-y-|mt-2|mt-3/);
  }
});

test("nonpending Case column context gives the full wrapped name flexible space after a 76px product without expanding compact metadata", () => {
  const { WorkbenchTaskCard } = harness();
  const name = "完整关联 Case 名称需要多行展示".repeat(8) + "UnbrokenCaseName".repeat(16) + " <样品>&记录";
  const business = [
    { key: "产品:p1", kind: "产品", name: "DDR5 · 完整产品名称一", origin: "case" },
    { key: "产品:p2", kind: "产品", name: "LPDDR · 完整产品名称二", origin: "task" },
  ];
  for (const status of ["进行中", "已完成"]) for (const caseClosed of [false, true]) for (const businessKey of ["产品:p2", "missing", "none"]) {
    const events = [];
    const record = freeze(row("full-case", "case", { status, caseClosed,
      caseItem: { id: "long-case", name, code: "CASE-LONG", level: "L1", owner: "刘洋" },
      business: businessKey === "none" ? [] : business,
    }));
    const before = JSON.stringify(record);
    const props = { row: record, columnLayout: true, businessKey, ...noops,
      onOpenCase: id => events.push(["case", id]), onShowTask: () => events.push(["task", record.id]),
    };
    const tree = WorkbenchTaskCard(props); const html = render(WorkbenchTaskCard, props);
    const groups = childElements(tree).filter(node => !classTokens(node).includes("absolute"));
    assert.equal(groups.length, 2);
    const [top, bottom] = groups;
    const [badge, title, date] = childElements(top);
    assert.equal(badge.props.title, status);
    assertClasses(date, ["inline-flex", "shrink-0", "items-center", "gap-1", "text-[11px]"]);
    assert.equal(date.props.title, status === "进行中" && !caseClosed ? record.dueDate : record.updatedAt);
    assertClasses(bottom, ["mt-1.5", "flex", "min-w-0", "items-start", "gap-2", "pl-[22px]"]);
    assert.equal(classTokens(bottom).includes("flex-wrap"), false);
    const metadata = childElements(bottom);
    assert.equal(metadata.length, 4 + Number(caseClosed));
    const [context, attachments, voice] = metadata;
    const owner = metadata.at(-1);
    assert.equal(context.type, "button"); assert.equal(context.props.type, "button");
    assert.equal(context.props["aria-label"], `查看关联 Case ${name}`);
    assert.ok(context.props.title.startsWith(name));
    assertClasses(context, ["inline-flex", "min-w-0", "flex-1", "items-start", "text-left"]);
    const parts = childElements(context);
    assert.equal(parts.length, record.business.length ? 3 : 2);
    const level = parts[0]; const caseName = parts.at(-1);
    const product = record.business.length ? parts[1] : undefined;
    assert.equal(level.props.children, "L1"); assertClasses(level, ["shrink-0", "level-l1"]);
    assert.equal(caseName.type, "span"); assert.equal(caseName.props["data-slot"], "task-case-name");
    assert.equal(caseName.props.children, name);
    assertClasses(caseName, ["min-w-0", "flex-1", "whitespace-normal", "break-words", "leading-4"]);
    for (const element of [context, caseName]) for (const token of classTokens(element)) {
      assert.doesNotMatch(token, /^(?:max-w-|line-clamp-|truncate$|whitespace-nowrap$|overflow-hidden$|text-ellipsis$)/, "Full Case names must not retain a cap or truncation");
    }
    assert.equal((html.match(/data-slot="task-case-name"/g) ?? []).length, 1);
    const nameHtml = renderToStaticMarkup(caseName);
    assert.ok(nameHtml.includes(name.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;")));
    assert.doesNotMatch(html, /<样品>/);
    if (product) {
      const selected = businessKey === "产品:p2" ? business[1] : business[0];
      assertClasses(product, ["max-w-[76px]", "inline-flex", "shrink-0", "whitespace-nowrap", "text-[9px]"]);
      assert.equal(classTokens(product).includes("max-w-[110px]"), false);
      assert.equal(childElements(product).at(-1).props.children, selected.name);
      for (const ref of business) assert.ok(product.props.title.includes(ref.name));
      assert.ok(html.indexOf(renderToStaticMarkup(product)) < html.indexOf(nameHtml), "Product chip must precede the full Case name");
    }
    assert.equal(owner.props["data-slot"], "task-owner");
    assertClasses(owner, ["ml-auto", "inline-flex", "w-[72px]", "shrink-0", "items-center", "gap-1", "text-[11px]"]);
    assert.equal(owner.props.title, `${record.owner} · ${record.creator} 分派`);
    const [avatar, ownerName] = childElements(owner);
    assertClasses(avatar, ["h-4", "w-4", "shrink-0", "rounded-full"]);
    assertClasses(ownerName, ["min-w-0", "truncate"]); assert.equal(ownerName.props.children, record.owner);
    assertClasses(attachments, ["inline-flex", "gap-0.5", "text-[10px]"]);
    assert.equal(attachments.props.title, "2 个附件"); assert.equal(voice.props["aria-label"], "有语音备注");
    assert.equal(voice.props.size, 11);
    assert.deepEqual(events, []); context.props.onClick(); title.props.onClick();
    assert.deepEqual(events, [["case", "long-case"], ["task", "full-case"]]);
    assertNoNestedButtons(html); assertNoTaskActions(html);
    assert.equal(JSON.stringify(record), before);
  }
});

test("Case source columns render the selected product pill before the uncapped full name in active and done cards", () => {
  const api = harness();
  const name = "完整关联 Case 名称需要换行".repeat(6) + "UnbrokenCaseName".repeat(12);
  const business = [
    { key: "产品:p1", kind: "产品", name: "DDR5 · 完整产品名称一", origin: "case" },
    { key: "产品:p2", kind: "产品", name: "LPDDR · 完整产品名称二", origin: "task" },
  ];
  for (const status of ["进行中", "已完成"]) for (const caseClosed of [false, true]) for (const businessKey of ["产品:p1", "产品:p2", "missing"]) {
    const rows = freeze([true, false].map(hasProduct => row(`product-order-${hasProduct}`, "case", {
      status, caseClosed, business: hasProduct ? business : [],
      caseItem: { id: "product-order-case", name, level: "L1", owner: "刘洋" },
    })));
    const before = JSON.stringify(rows); const calls = [];
    const html = render(api.TaskSourceColumn, { ...columnProps("case", rows), businessKey,
      onShowTask: value => calls.push(["detail", value]), onOpenCase: id => calls.push(["case", id]),
      onTakeAction: value => calls.push(["accept", value]), onReject: value => calls.push(["reject", value]),
    });
    const cards = articles(html); assert.equal(cards.length, rows.length);
    for (const [index, card] of cards.entries()) {
      assert.match(card, /data-layout="compact-task"/);
      const context = buttons(card).find(button => button.includes(`aria-label="查看关联 Case ${name}"`));
      assert.ok(context);
      assertClasses(/^<button\b[^>]*>/.exec(context)?.[0], ["min-w-0", "flex-1", "items-start", "text-left"]);
      const caseName = /<span\b[^>]*data-slot="task-case-name"[^>]*>[\s\S]*?<\/span>/.exec(context)?.[0];
      assert.ok(caseName); assert.equal(stripTags(caseName), name);
      assertClasses(caseName, ["min-w-0", "flex-1", "whitespace-normal", "break-words", "leading-4"]);
      assert.doesNotMatch(caseName, /max-w-|truncate|line-clamp-|overflow-hidden|text-ellipsis|whitespace-nowrap/);
      assert.doesNotMatch(context, /max-w-\[210px\]/);
      const selected = rows[index].business.find(ref => ref.key === businessKey) ?? rows[index].business[0];
      assert.equal(stripTags(context), `L1${selected?.name ?? ""}${name}`);
      const productIndex = context.indexOf("max-w-[76px]");
      if (selected) {
        assert.ok(productIndex >= 0 && productIndex < context.indexOf('data-slot="task-case-name"'), "The product pill must render before the Case name");
      } else assert.equal(productIndex, -1, "A missing product must not leave a placeholder pill");
      assertNoTaskActions(card); assertNoNestedButtons(card);
    }
    assert.deepEqual(calls, []); assert.deepEqual(api.writes, []);
    assert.equal(JSON.stringify(rows), before);
  }
});

test("both source/state cards keep the same rightmost 72px owner slot as context, attachment counts and voice vary without changing actions", () => {
  const api = harness(); let baselineLayout;
  const business = [{ key: "产品:p1", kind: "产品", name: "DDR5 · 完整产品名称", origin: "task" }];
  for (const source of sources) for (const status of ["进行中", "已完成"]) for (const caseClosed of [false, true])
    for (const hasBusiness of [false, true]) for (const attachmentCount of [0, 1, 128]) for (const hasVoice of [false, true]) {
    const calls = [];
    const record = freeze(row("owner-layout", source, { status, caseClosed, attachmentCount, hasVoice,
      business: hasBusiness ? business : [],
      owner: status === "进行中" ? actor.name : "李娜完整负责人姓名用于验证截断",
      creator: hasVoice ? "" : "刘洋完整分派人姓名",
    }));
    const before = JSON.stringify(record);
    const props = { row: record, columnLayout: true, businessKey: "产品:p1",
      onShowTask: () => calls.push("detail"), onOpenCase: id => calls.push(["case", id]),
      onTakeAction: () => calls.push("accept"), onReject: () => calls.push("reject"),
    };
    const tree = api.WorkbenchTaskCard(props); const html = render(api.WorkbenchTaskCard, props);
    const groups = childElements(tree).filter(node => !classTokens(node).includes("absolute"));
    assert.equal(groups.length, 2);
    const [top, bottom] = groups; const metadata = childElements(bottom); const owner = metadata.at(-1);
    assertClasses(bottom, ["mt-1.5", "flex", "min-w-0", "items-start", "gap-2", "pl-[22px]"]);
    for (const token of ["flex-wrap", "items-center", "gap-x-2", "gap-y-1"]) assert.equal(classTokens(bottom).includes(token), false);
    assert.equal(owner.type, "span"); assert.equal(owner.props["data-slot"], "task-owner");
    assertClasses(owner, ["ml-auto", "inline-flex", "w-[72px]", "shrink-0", "items-center", "gap-1", "text-[11px]"]);
    assert.equal(classTokens(owner).includes("truncate"), false);
    assert.equal(owner.props.title, record.creator ? `${record.owner} · ${record.creator} 分派` : record.owner);
    const ownerParts = childElements(owner); assert.equal(ownerParts.length, 2);
    const [avatar, ownerName] = ownerParts;
    assert.equal(avatar.type, "span"); assert.equal(avatar.props.children, record.owner[0]);
    assertClasses(avatar, ["h-4", "w-4", "shrink-0", "rounded-full"]);
    assert.equal(ownerName.type, "span"); assert.equal(ownerName.props.children, record.owner);
    assertClasses(ownerName, ["min-w-0", "truncate"]);
    const layout = [bottom, owner, avatar, ownerName].map(classTokens);
    baselineLayout ??= layout; assert.deepEqual(layout, baselineLayout, "Both sources/states must use identical owner sizing and anchoring regardless of metadata");
    assert.equal((html.match(/data-slot="task-owner"/g) ?? []).length, 1);
    assert.equal(elements(top).some(node => node.props["data-slot"] === "task-owner"), false);
    assert.ok(renderToStaticMarkup(bottom).endsWith(`${renderToStaticMarkup(owner)}</div>`), "Owner must remain the last item in the second row");
    let index = 0;
    if (source === "case" || hasBusiness) {
      const context = metadata[index++];
      assert.equal(context.type, source === "case" ? "button" : "span");
      if (source === "case") assert.equal(context.props["aria-label"], "查看关联 Case 关联问题");
      else assert.ok(context.props.title.includes(business[0].name));
    }
    if (attachmentCount) assert.equal(metadata[index++].props.title, `${attachmentCount} 个附件`);
    if (hasVoice) assert.equal(metadata[index++].props["aria-label"], "有语音备注");
    if (caseClosed) assert.equal(metadata[index++].props.children, "Case 已结案");
    assert.equal(metadata[index++], owner, "All material and closure indicators must precede the fixed owner slot");
    assert.equal(metadata.length, index, "No empty context/material wrappers or spacers may be introduced");
    assert.equal((html.match(/title="\d+ 个附件"/g) ?? []).length, Number(attachmentCount > 0));
    assert.equal((html.match(/aria-label="有语音备注"/g) ?? []).length, Number(hasVoice));
    assert.equal(buttons(html).length, source === "case" ? 2 : 1);
    assertNoTaskActions(html); assertNoNestedButtons(html); assert.deepEqual(calls, []);
    const controls = elements(tree).filter(node => node.type === "button");
    controls.find(node => node.props["aria-label"] === `查看任务 ${record.title}`).props.onClick();
    assert.deepEqual(calls, ["detail"]);
    if (source === "case") {
      controls.find(node => node.props["aria-label"] === "查看关联 Case 关联问题").props.onClick();
      assert.deepEqual(calls, ["detail", ["case", "c1"]]);
    }
    assert.deepEqual(api.writes, []); assert.equal(JSON.stringify(record), before);
  }
});

test("pending and legacy Case contexts retain the 210px cap, 110px product-first chip and truncated name", () => {
  const { WorkbenchTaskCard } = harness();
  const business = [{ key: "产品:p1", kind: "产品", name: "DDR5 · 完整产品名称", origin: "case" }];
  for (const status of statuses) for (const caseClosed of [false, true]) {
    const record = freeze(row("legacy-context", "case", { status, caseClosed, business,
      caseItem: { id: "legacy-case", name: "保留原样的完整 Case 名称".repeat(12), level: "L1", owner: "刘洋" },
    }));
    const before = JSON.stringify(record); let baseline;
    for (const columnLayout of status === "待接受" ? [undefined, false, true] : [undefined, false]) {
      const events = [];
      const props = { row: record, columnLayout, businessKey: "产品:p1", ...noops, onOpenCase: id => events.push(id) };
      const tree = WorkbenchTaskCard(props); const html = render(WorkbenchTaskCard, props);
      baseline ??= html;
      assert.equal(html, baseline, "Pending column opt-in and the default legacy layout must remain unchanged");
      const context = elements(tree).find(node => node.props["aria-label"] === `查看关联 Case ${record.caseItem.name}`);
      assert.ok(context); assert.equal(context.type, "button");
      assertClasses(context, ["max-w-[210px]", "min-w-0", "inline-flex", "items-center"]);
      for (const token of ["flex-1", "items-start", "text-left"]) assert.equal(classTokens(context).includes(token), false);
      const parts = childElements(context);
      assert.equal(parts.length, 3);
      const [level, product, caseName] = parts;
      assert.equal(level.props.children, "L1");
      assertClasses(product, ["max-w-[110px]", "shrink-0", "whitespace-nowrap"]);
      assert.equal(classTokens(product).includes("max-w-[76px]"), false);
      assert.equal(childElements(product).at(-1).props.children, business[0].name);
      assertClasses(caseName, ["truncate"]); assert.equal(caseName.props.children, record.caseItem.name);
      assert.equal(caseName.props["data-slot"], undefined);
      assert.doesNotMatch(html, /data-slot="task-case-name"|data-layout="compact-task"/);
      if (status === "待接受") assertClasses(context, ["rounded-md", "border", "bg-slate-100", "px-2", "py-0.5", "text-[10.5px]"]);
      else assertClasses(context, ["text-[11px]"]);
      context.props.onClick(); assert.deepEqual(events, ["legacy-case"]);
      assertNoNestedButtons(html);
    }
    assert.equal(JSON.stringify(record), before);
  }
});

test("source columns use spacing two for nonpending lists and spacing three for pending lists without changing pending card styles", () => {
  const { TaskSourceColumn, WorkbenchTaskCard } = harness();
  for (const source of sources) for (const rowStatuses of [["进行中", "已完成"], ["待接受", "待接受"], ["进行中", "待接受"]]) {
    const rows = freeze(rowStatuses.map((status, index) => row(`spacing-${index}`, source, { status })));
    const html = render(TaskSourceColumn, columnProps(source, rows));
    const spacing = rowStatuses.includes("待接受") ? "space-y-3" : "space-y-2";
    assert.deepEqual((html.match(/<div\b[^>]*>/g) ?? []).filter(tag => classTokens(tag).some(token => token.startsWith("space-y-"))).map(classTokens), [[spacing]]);
    assert.equal(articles(html).length, rows.length);
    for (const record of rows.filter(item => item.status === "待接受")) for (const owner of [actor.name, "李娜"]) for (const caseClosed of [false, true]) {
      const props = { row: { ...record, owner, caseClosed }, businessKey: "", ...noops };
      const pending = render(WorkbenchTaskCard, { ...props, columnLayout: true });
      assert.equal(pending, render(WorkbenchTaskCard, { ...props, columnLayout: false }), "Column mode must leave the full pending markup unchanged");
      assertClasses(/^<article\b[^>]*>/.exec(pending)?.[0], ["rounded-xl", "p-4", "pl-5"]);
      assert.match(pending, /rounded-tl-\[3px\]/); assert.match(pending, /bg-\[#f7f9fc\]/);
      assert.doesNotMatch(pending, /data-layout="compact-task"/);
      const actions = buttons(pending).map(stripTags); const permitted = owner === actor.name && !caseClosed;
      for (const label of ["接受并开始", "拒绝"]) assert.equal(actions.filter(text => text === label).length, Number(permitted));
    }
  }
});

test("column cards use honest missing-date fallbacks and omit nonexistent materials", () => {
  const { WorkbenchTaskCard } = harness();
  for (const dueDate of [undefined, "", "2026-02-31", "invalid"]) {
    const html = render(WorkbenchTaskCard, { row: row("missing", "standalone", { dueDate, attachmentCount: 0, hasVoice: false }), columnLayout: true, businessKey: "", ...noops });
    assert.match(html, /未设置截止日期/);
    assert.doesNotMatch(html, /有语音备注|个附件|今日到期|已逾期|NaN/);
  }
  const html = render(WorkbenchTaskCard, { row: row("missing-update", "case", { status: "已完成", updatedAt: undefined }), columnLayout: true, businessKey: "", ...noops });
  assert.match(html, /更新时间未记录/); assert.doesNotMatch(html, /更新 \d{4}-|完成 \d{4}-/);
});

test("pending column cards retain the dispatch bubble and accept/reject only for the actionable owner in both sources", () => {
  const { WorkbenchTaskCard } = harness();
  for (const source of sources) for (const [patch, permitted] of [
    [{}, true],
    [{ creator: actor.name, participants: [actor.name] }, true],
    [{ owner: "李娜", creator: actor.name }, false],
    [{ owner: "李娜", participants: [actor.name] }, false],
    [{ owner: "李娜", creator: actor.name, participants: [actor.name] }, false],
    [{ caseClosed: true }, false],
    [{ convertedCaseId: "upgraded", convertedCaseName: "升级后的问题" }, false],
  ]) {
    const record = freeze(row("pending", source, { status: "待接受", ...patch }));
    const html = render(WorkbenchTaskCard, { row: record, columnLayout: true, businessKey: "", ...noops });
    const actions = buttons(html).map(stripTags);
    assert.equal(actions.filter(text => text === "接受并开始").length, Number(permitted));
    assert.equal(actions.filter(text => text === "拒绝").length, Number(permitted));
    assert.doesNotMatch(html, /col-span-2/);
    if (!record.convertedCaseId) {
      assert.match(html, /rounded-tl-\[3px\]/); assert.match(html, /bg-\[#f7f9fc\]/);
      assert.ok(html.includes(record.owner === actor.name ? "@你" : "@李娜"));
      assert.match(html, /title="2 个附件"/); assert.match(html, /aria-label="有语音备注"/);
    }
    if (record.caseClosed) assert.match(html, /Case 已结案/);
    if (record.caseClosed || record.convertedCaseId) assert.doesNotMatch(html, /title="紧急程度：/);
    if (record.owner !== actor.name) assert.doesNotMatch(html, /@你|请处理这个任务/);
    assertNoNestedButtons(html);
  }
});

test("column-card navigation stays separate from Case navigation and pending owner action callbacks", () => {
  const { WorkbenchTaskCard } = harness();
  for (const source of sources) for (const status of ["待接受", "进行中"]) {
    const events = [];
    const props = { row: row("navigation", source, { status }), columnLayout: true, businessKey: "",
      onShowTask: () => events.push("detail"), onOpenCase: id => events.push(["case", id]),
      onTakeAction: () => events.push("accept"), onReject: () => events.push("reject"),
    };
    const html = render(WorkbenchTaskCard, props);
    assert.deepEqual(events, []);
    const controls = elements(WorkbenchTaskCard(props)).filter(element => element.type === "button");
    controls.find(button => button.props["aria-label"] === "查看任务 任务 navigation").props.onClick();
    assert.deepEqual(events, ["detail"]);
    if (source === "case") {
      controls.find(button => button.props["aria-label"] === "查看关联 Case 关联问题").props.onClick();
      assert.deepEqual(events.at(-1), ["case", "c1"]);
    }
    if (status === "待接受") {
      controls.find(button => button.props.children === "接受并开始").props.onClick();
      controls.find(button => button.props.children === "拒绝").props.onClick();
      assert.deepEqual(events.slice(-2), ["accept", "reject"]);
    } else assertNoTaskActions(html);
    assertNoNestedButtons(html);
  }
});

test("MyTaskWorkbench SSR wires full Case-left and standalone-right columns, fixed summaries and summed roles using saved trees without writes", () => {
  const own = Array.from({ length: 12 }, (_, i) => action(String(i).padStart(2, "0")));
  const trees = freeze({ c1: [{ id: "thought", title: "方向", children: [
    ...own, action("assigned", { owner: "李娜", supervisor: actor.name, collaborators: [{ name: actor.name }] }),
    action("joined", { owner: "王强", collaborators: [{ name: actor.name }] }),
    action("active", { status: "进行中" }),
  ] }] });
  const cases = freeze([caseItem("c1", [action("stale")], { sourceStandaloneTaskIds: ["partial"] })]);
  const tasks = freeze([
    ...Array.from({ length: 12 }, (_, i) => task(String(i).padStart(2, "0"))),
    task("converted", { convertedCaseId: "c1" }), task("partial"),
    task("assigned", { owner: "李娜", createdBy: actor.name, collaborators: [{ name: actor.name }] }),
    task("joined", { owner: "王强", collaborators: [{ name: actor.name }] }), task("done", { status: "已完成" }),
  ]);
  const before = JSON.stringify([cases, tasks, trees]);
  const api = harness({ trees });
  const html = render(api.MyTaskWorkbench, workbenchProps(cases, tasks));
  const left = columnMarkup(html, "case"); const right = columnMarkup(html, "standalone");
  assert.ok(html.indexOf(left) < html.indexOf(right));
  assert.equal(articles(left).length, 12); assert.equal(articles(right).length, 12);
  assert.equal(articles(html).length, 24);
  assert.match(left, /<span[^>]*>12<\/span>[\s\S]*?<\/header>/); assert.match(right, /<span[^>]*>12<\/span>[\s\S]*?<\/header>/);
  assertColumnSorters(html);
  assert.deepEqual(articles(left).map(article => /aria-label="执行 ([^"]+)"/.exec(article)?.[1]), own.map(item => item.id));
  assert.deepEqual(articles(right).map(article => /aria-label="独立 ([^"]+)"/.exec(article)?.[1]), own.map(item => item.id));
  for (const [status, count] of [["待接受", 24], ["进行中", 1], ["已完成", 1]]) assert.ok(html.includes(`aria-label="${status} ${count} 件"`));
  for (const [label, count] of [["我负责", 26], ["我分派", 2]]) {
    assert.ok(buttons(html).some(button => stripTags(button) === `${label}${count}`));
  }
  assert.match(html, /aria-label="任务列表" class="grid min-h-0 flex-1 grid-cols-2 gap-4"/);
  assert.match(html, /aria-label="待接受任务内容"/);
  assert.equal((html.match(/role="tab"/g) ?? []).length, 2);
  assert.doesNotMatch(html, /待我协作|我参与|上一页|下一页|分页|归类显示|第 1|col-span-2/);
  assert.doesNotMatch(html, /aria-label="执行 stale"|aria-label="独立 converted"|aria-label="独立 partial"/);
  assert.equal(api.treeReads.length, 1); assert.equal(api.treeReads[0].fallback, cases[0].tasks);
  assert.deepEqual(api.writes, []); assert.equal(JSON.stringify([cases, tasks, trees]), before);
  assertNoNestedButtons(html);
});

test("MyTaskWorkbench SSR ignores all legacy filters and sorting and exposes neither control", () => {
  const setup = harness();
  for (const status of statuses) for (const source of ["all", "case", "standalone"]) {
    const initialState = setup.createTaskWorkbenchState();
    initialState.status = status;
    Object.assign(initialState.views[status], { page: 999, groupBy: "owner", sortBy: status === "已完成" ? "priority" : "updated" });
    Object.assign(initialState.views[status].filters, { source, query: "hidden no-match", showUpgraded: true, businessKind: "none", businessKey: "hidden-unavailable", tfKey: "TF:stale", projectKey: "Project:stale" });
    freeze(initialState);
    const api = harness({ initialState });
    const cases = freeze([caseItem("c1", Array.from({ length: 10 }, (_, i) => action(String(i), { status, dueDate: `2026-09-${String(20 - i).padStart(2, "0")}` }))) ]);
    const tasks = freeze(Array.from({ length: 11 }, (_, i) => task(String(i), { status })));
    const before = JSON.stringify([initialState, cases, tasks]);
    const html = render(api.MyTaskWorkbench, workbenchProps(cases, tasks));
    assert.equal(articles(columnMarkup(html, "case")).length, 10);
    assert.equal(articles(columnMarkup(html, "standalone")).length, 11);
    assertColumnSorters(html);
    assert.ok(html.includes(`aria-label="${status} 21 件"`));
    assert.ok(html.includes(`aria-label="${status}任务内容"`));
    assert.doesNotMatch(html, /col-span-2|上一页|下一页|归类显示|排序方式|aria-label="筛选"/);
    assert.doesNotMatch(html, /aria-label="筛选 \d|清除.*筛选|任务涉及|hidden-unavailable|TF筛选|Project筛选|TF:stale|Project:stale/);
    for (const primary of statuses) assert.ok(html.includes(`aria-label="${primary} ${primary === status ? 21 : 0} 件"`));
    if (status !== "待接受") assertNoTaskActions(html);
    assert.equal(JSON.stringify([initialState, cases, tasks]), before);
    assert.deepEqual(api.writes, []);
  }
});

test("MyTaskWorkbench ignores previously selected product, Case and creator in both columns", () => {
  const setup = harness();
  let initialState = setup.createTaskWorkbenchState();
  initialState = setup.updateTaskWorkbenchState(initialState, { type: "column-filters", patch: {
    caseId: "c1", productKey: "产品:p1", creator: "刘洋",
  } });
  freeze(initialState);
  const cases = freeze([caseItem("c1", [action("left")], { productId: "p1" }), caseItem("c2", [action("excluded")], { productId: "p1" })]);
  const tasks = freeze([task("right", { involvement: { kind: "产品", id: "p1", name: "产品一" } }), task("other-product", { involvement: { kind: "产品", id: "p2", name: "产品二" } })]);
  const api = harness({ initialState });
  const html = render(api.MyTaskWorkbench, workbenchProps(cases, tasks));
  assert.equal(articles(columnMarkup(html, "case")).length, 2);
  assert.equal(articles(columnMarkup(html, "standalone")).length, 2);
  assert.match(html, /aria-label="执行 left"/); assert.match(html, /aria-label="独立 right"/);
  assert.match(html, /aria-label="执行 excluded"/); assert.match(html, /aria-label="独立 other-product"/);
  assert.match(html, /aria-label="待接受 4 件"/);
  assert.doesNotMatch(html, /筛选|排序/);
  assert.equal(initialState.views.待接受.filters.caseId, "c1");
  assert.equal(initialState.views.待接受.filters.source, "all");
  assert.deepEqual(api.writes, []);
});

test("empty workbench SSR still renders both named columns and all three zero responsibility summaries", () => {
  const api = harness();
  const html = render(api.MyTaskWorkbench, workbenchProps());
  assert.equal(articles(html).length, 0);
  for (const status of statuses) assert.ok(html.includes(`aria-label="${status} 0 件"`));
  assert.match(html, /暂无符合条件的Case 任务/); assert.match(html, /暂无符合条件的自由任务/);
  assert.equal((html.match(/role="region"/g) ?? []).length, 2);
  assertColumnSorters(html);
  assert.doesNotMatch(html, /上一页|下一页|清除筛选|col-span-2/);
  assert.deepEqual(api.writes, []);
});

test("filter trigger SSR retains analysis-center classes and a maximum-three product/Case/creator badge ignoring TF/Project and old business fields", () => {
  const api = harness();
  const base = plain(api.createTaskWorkbenchState().views.待接受.filters);
  const props = { businessOptions: [], caseOptions: [], creators: [], open: false, onOpenChange() {}, onChange() {}, onReset() {} };
  for (const [patch, count] of [
    [{ source: "case" }, 0],
    [{ businessKind: "产品" }, 0],
    [{ businessKind: "产品", businessKey: "产品:p1" }, 0],
    [{ businessKind: "none" }, 0],
    [{ businessKind: "TF", businessKey: "TF:missing", scope: "assigned", query: "hidden", showUpgraded: true }, 0],
    [{ productKey: "产品:p1" }, 1],
    [{ tfKey: "TF:t1" }, 0],
    [{ projectKey: "Project:name:同名项目" }, 0],
    [{ productKey: "产品:p1", tfKey: "TF:t1" }, 1],
    [{ productKey: "产品:p1", tfKey: "TF:t1", projectKey: "Project:id:1" }, 1],
    [{ businessKind: "产品", businessKey: "产品:p1", caseId: "missing", creator: "刘洋" }, 2],
    [{ businessKind: "none", businessKey: "legacy", productKey: "产品:missing", tfKey: "TF:missing", projectKey: "Project:missing", caseId: "missing", creator: "刘洋" }, 3],
    ...Array.from({ length: 8 }, (_, mask) => [{
      productKey: mask & 1 ? "产品:p1" : "", caseId: mask & 2 ? "c1" : "", creator: mask & 4 ? "刘洋" : "",
      tfKey: "TF:stale", projectKey: "Project:stale", businessKind: "none", businessKey: "hidden",
    }, Number(Boolean(mask & 1)) + Number(Boolean(mask & 2)) + Number(Boolean(mask & 4))]),
  ]) {
    const html = render(api.TaskWorkbenchFilters, { ...props, filters: { ...base, ...patch } });
    const trigger = buttons(html).find(button => button.includes(`aria-label="筛选${count ? ` ${count}` : ""}"`));
    assert.ok(trigger);
    const opening = /^<button\b[^>]*>/.exec(trigger)?.[0];
    assertClasses(opening, ["inline-flex", "h-9", "items-center", "gap-1.5", "rounded-lg", "border", "px-3", "text-sm", "transition-colors"]);
    assertClasses(opening, count ? ["border-[#0052D9]/40", "bg-[#0052D9]/5", "text-[#0052D9]"] : ["border-slate-200", "bg-white", "text-slate-600", "hover:border-slate-300"]);
    assert.equal((trigger.match(/min-w-\[16px\]/g) ?? []).length, Number(count > 0));
    if (count) assert.ok(trigger.includes(`>${count}</span>`));
    assert.doesNotMatch(html, /aria-label="筛选 [4-9]|TF筛选|Project筛选/);
  }
});

test("filter content SSR retains field labels, left-only Case guidance and reset callbacks even with stale selections", () => {
  const api = harness(); const calls = [];
  const filters = freeze({ ...plain(api.createTaskWorkbenchState().views.待接受.filters), productKey: "产品:missing", tfKey: "TF:missing", projectKey: "Project:missing", caseId: "missing", creator: "旧分派人" });
  const before = JSON.stringify(filters);
  const props = { filters, businessOptions: [], caseOptions: [], creators: [], open: true,
    onOpenChange: value => calls.push(["open", value]), onChange: patch => calls.push(["change", plain(patch)]), onReset: () => calls.push(["reset"]),
  };
  const tree = api.TaskWorkbenchFilters(props);
  const content = elements(tree).find(element => element.props["aria-label"] === "任务筛选条件");
  assert.ok(content);
  // Radix portals are absent during SSR; render their real content subtree in isolation.
  const html = renderToStaticMarkup(createElement(Fragment, null, content.props.children));
  for (const label of ["产品筛选", "所属 Case（仅左栏）", "创建或分派人"]) assert.ok(html.includes(`aria-label="${label}"`));
  assert.equal((html.match(/<select\b/g) ?? []).length, 2);
  assert.equal(buttons(html).filter(button => button.includes('aria-label="产品筛选"')).length, 1);
  assert.match(html, /title="已选对象（当前范围无任务）"/);
  assert.match(html, /所属 Case 仅筛选左栏，其他条件同时作用于两栏。/);
  assert.match(html, /value="missing" selected=""/); assert.match(html, /value="旧分派人" selected=""/);
  assert.equal((html.match(/已选值（当前范围无任务）/g) ?? []).length, 2);
  assert.match(html, /重置全部/); assert.match(html, />完成<\/button>/);
  assert.doesNotMatch(html, /归类显示|排序方式|任务来源|任务涉及|任务涉及类型|具体涉及对象|task-business-filter|TF筛选|Project筛选|TF:missing|Project:missing/);
  const controls = elements(content.props.children).filter(element => element.type === "button");
  const reset = controls.find(element => elements(element).some(child => child.type !== "button") && element.props.onClick === props.onReset);
  assert.ok(reset); reset.props.onClick();
  controls.find(element => element.props.children === "完成").props.onClick();
  assert.deepEqual(calls, [["reset"], ["open", false]]);
  assert.equal(filters.caseId, "missing"); assert.equal(filters.creator, "旧分派人");
  assert.equal(JSON.stringify(filters), before);
});

test("filter content mounts only the product picker plus Case/creator and exposes no TF/Project callbacks even with a mixed compatibility catalog", () => {
  const api = harness(); const calls = [];
  const filters = freeze({ ...plain(api.createTaskWorkbenchState().views.待接受.filters),
    productKey: "产品:p1", tfKey: "TF:t1", projectKey: "Project:name:同名项目", caseId: "c1", creator: "刘洋", businessKind: "none", businessKey: "legacy-hidden",
  });
  const businessOptions = freeze([
    { key: "产品:p1", kind: "产品", name: "DDR5 · 产品一", origin: "case" },
    { key: "TF:t1", kind: "TF", name: "专项一", origin: "task" },
    { key: "Project:name:同名项目", kind: "Project", name: "同名项目", origin: "case", nameOnly: true },
  ]);
  const caseOptions = freeze([caseItem("c1", [])]); const creators = freeze(["刘洋"]);
  const before = JSON.stringify([filters, businessOptions, caseOptions, creators]);
  const tree = api.TaskWorkbenchFilters({ filters, businessOptions, caseOptions, creators, open: true, onOpenChange() {}, onReset() {}, onChange: patch => calls.push(plain(patch)) });
  const content = elements(tree).find(element => element.props["aria-label"] === "任务筛选条件");
  const references = elements(content).filter(element => element.type === api.TaskReferenceFilter);
  assert.equal(references.length, 1);
  assert.deepEqual(plain(references.map(element => [element.key, element.props.kind, element.props.value])), [
    ["productKey", "产品", "产品:p1"],
  ]);
  const html = renderToStaticMarkup(createElement(Fragment, null, content.props.children));
  assert.equal((html.match(/<select\b/g) ?? []).length, 2);
  assert.doesNotMatch(html, /任务涉及|具体涉及对象|task-business-filter|legacy-hidden|TF筛选|Project筛选|同名项目|专项一/);
  assert.match(html, /title="DDR5 · 产品一"/);
  assert.deepEqual(calls, []);
  const field = references[0];
  // The reusable helper still accepts a broad catalog; My Tasks mounts only 产品.
  assert.equal(field.props.options, businessOptions);
  field.props.onChange("产品:p1"); field.props.onChange("");
  assert.deepEqual(calls, [{ productKey: "产品:p1" }, { productKey: "" }]);
  for (const [ariaLabel, key, value] of [["所属 Case（仅左栏）", "caseId", "c1"], ["创建或分派人", "creator", "刘洋"]]) {
    const field = elements(content).find(element => element.props.ariaLabel === ariaLabel);
    assert.ok(field);
    const select = elements(field.type(field.props)).find(element => element.type === "select");
    select.props.onChange({ target: { value } }); select.props.onChange({ target: { value: "" } });
    assert.deepEqual(calls.slice(-2), [{ [key]: value }, { [key]: "" }]);
  }
  assert.deepEqual(calls, [{ productKey: "产品:p1" }, { productKey: "" }, { caseId: "c1" }, { caseId: "" }, { creator: "刘洋" }, { creator: "" }]);
  assert.equal(elements(content).some(element => ["TF", "Project"].includes(element.props.kind) || ["tfKey", "projectKey"].includes(element.key)), false);
  assert.equal(JSON.stringify([filters, businessOptions, caseOptions, creators]), before);
  assert.deepEqual(api.writes, []);
});

test("MyTaskWorkbench ignores every saved filter across statuses while keeping historical context and fixed totals", () => {
  const setup = harness();
  const cases = freeze([caseItem("c1", statuses.flatMap(status => [
    action(`match-${status}`, { status, standaloneTaskContext: { involvement: { kind: "TF", id: "t1", name: "专项一" } } }),
    action(`other-creator-${status}`, { status, supervisor: "李娜" }),
  ]), { productId: "p1", projectName: "同名项目" }),
    caseItem("c2", statuses.map(status => action(`other-${status}`, { status, standaloneTaskContext: { involvement: { kind: "TF", id: "t2", name: "专项二" } } })), { productId: "p1", projectName: "同名项目" }),
  ]);
  const tasks = freeze(statuses.flatMap(status => [
    task(`product-${status}`, { status, involvement: { kind: "产品", id: "p1", name: "产品一" } }),
    task(`other-creator-${status}`, { status, createdBy: "李娜", involvement: { kind: "产品", id: "p1", name: "产品一" } }),
    task(`other-product-${status}`, { status, involvement: { kind: "产品", id: "p2", name: "产品二" } }),
    task(`tf-${status}`, { status, involvement: { kind: "TF", id: "t1", name: "专项一" } }),
    task(`project-${status}`, { status, involvement: { kind: "Project", id: "id:1", name: "同名项目" } }),
  ]));
  const before = JSON.stringify([cases, tasks]);
  for (const status of statuses) for (const [patch, leftIds, rightIds, labels] of [
    [{}, ["match", "other-creator", "other"], ["product", "other-creator", "other-product", "tf", "project"], []],
    [{ productKey: "产品:p1" }, ["match", "other-creator", "other"], ["product", "other-creator"], ["清除产品筛选"]],
    [{ productKey: "产品:p1", caseId: "c1" }, ["match", "other-creator"], ["product", "other-creator"], ["清除产品筛选", "清除所属 Case 筛选"]],
    [{ productKey: "产品:p1", caseId: "c1", creator: "刘洋" }, ["match"], ["product"], ["清除产品筛选", "清除所属 Case 筛选", "清除创建或分派人筛选"]],
  ]) {
    const initialState = setup.updateTaskWorkbenchState(setup.createTaskWorkbenchState(), { type: "status", status });
    // Seed raw saved values, bypassing the reducer so rendering must ignore them too.
    Object.assign(initialState.views[status].filters, { ...patch, tfKey: "TF:t1", projectKey: "Project:name:同名项目", businessKind: "none", businessKey: "legacy-hidden" });
    freeze(initialState); const stateSnapshot = JSON.stringify(initialState);
    const api = harness({ initialState });
    const html = render(api.MyTaskWorkbench, workbenchProps(cases, tasks));
    const left = articles(columnMarkup(html, "case")); const right = articles(columnMarkup(html, "standalone"));
    assert.deepEqual(left.map(article => /aria-label="执行 ([^"]+)"/.exec(article)?.[1]).sort(), ["match", "other-creator", "other"].map(id => `${id}-${status}`).sort());
    assert.deepEqual(right.map(article => /aria-label="独立 ([^"]+)"/.exec(article)?.[1]).sort(), ["product", "other-creator", "other-product", "tf", "project"].map(id => `${id}-${status}`).sort());
    for (const primary of statuses) assert.ok(html.includes(`aria-label="${primary} 8 件"`));
    assert.doesNotMatch(html, /筛选|排序/);
    // Removing filter controls must not strip legitimate historical card context.
    assert.match(left.find(article => article.includes(`aria-label="执行 match-${status}"`)), /专项一|同名项目/);
    assert.ok(buttons(html).some(button => stripTags(button) === "我负责24"));
    assert.ok(buttons(html).some(button => stripTags(button) === "我分派0"));
    assert.doesNotMatch(html, /待我协作|我参与/);
    assert.doesNotMatch(html, /任务涉及|具体涉及对象|task-business-filter|清除TF筛选|清除Project筛选|aria-label="(?:TF|Project)筛选"|aria-label="筛选 [4-9]|legacy-hidden/);
    if (status !== "待接受") assertNoTaskActions(html);
    assertNoNestedButtons(html); assert.deepEqual(api.writes, []);
    assert.equal(JSON.stringify(initialState), stateSnapshot);
  }
  assert.equal(JSON.stringify([cases, tasks]), before);
});

test("MyTaskWorkbench ignores stale unavailable filters and removed participation scope without needing reset", () => {
  const setup = harness();
  for (const status of statuses) {
    const initialState = setup.updateTaskWorkbenchState(setup.createTaskWorkbenchState(), { type: "status", status });
    Object.assign(initialState.views[status].filters, { scope: "participating", productKey: "产品:missing", tfKey: "TF:missing", projectKey: "Project:name:旧项目", caseId: "missing", creator: "旧分派人" });
    freeze(initialState);
    const before = JSON.stringify(initialState);
    const api = harness({ initialState });
    const html = render(api.MyTaskWorkbench, workbenchProps());
    assert.ok(html.includes(`aria-label="${status}任务内容"`));
    assert.doesNotMatch(html, /筛选|排序|已选 Case|旧分派人|旧项目|TF:missing|Project:name:/);
    assert.equal(articles(html).length, 0);
    assert.match(html, /暂无符合条件的Case 任务/); assert.match(html, /暂无符合条件的自由任务/);
    for (const primary of statuses) assert.ok(html.includes(`aria-label="${primary} 0 件"`));
    const resetState = freeze(setup.updateTaskWorkbenchState(initialState, { type: "reset" }));
    const resetApi = harness({ initialState: resetState });
    const resetHtml = render(resetApi.MyTaskWorkbench, workbenchProps());
    assert.doesNotMatch(resetHtml, /筛选|排序|已选对象|旧分派人/);
    assert.ok(resetHtml.includes(`aria-label="${status}任务内容"`));
    assert.ok(buttons(resetHtml).some(button => button.includes('aria-selected="true"') && stripTags(button) === "我负责0"));
    assert.equal(JSON.stringify(initialState), before);
    assert.deepEqual(api.writes, []); assert.deepEqual(resetApi.writes, []);
  }
});

test("MyTaskWorkbench scroll reset keys ignore removed filters and sorts and change with status", () => {
  const setup = harness();
  const initial = setup.updateTaskWorkbenchState(setup.createTaskWorkbenchState(), { type: "column-filters", patch: { productKey: "产品:p1", caseId: "c1", creator: "刘洋" } });
  Object.assign(initial.views.待接受.filters, { tfKey: "TF:t1", projectKey: "Project:id:1" });
  freeze(initial); const before = JSON.stringify(initial);
  function rawPatch(patch) {
    const state = plain(initial);
    Object.assign(state.views.待接受.filters, patch);
    return freeze(state);
  }
  function columnSnapshots(initialState) {
    const api = harness({ initialState }); let tree;
    function Probe() { tree = api.MyTaskWorkbench(workbenchProps()); return tree; }
    renderToStaticMarkup(createElement(Probe));
    const columns = elements(tree).filter(element => element.type === api.TaskSourceColumn);
    assert.deepEqual(columns.map(column => column.props.source), ["case", "standalone"]);
    assert.deepEqual(api.writes, []);
    for (const column of columns) assert.equal(column.props.onSortChange, undefined);
    return columns.map(column => ({ resetKey: column.props.resetKey, businessKey: column.props.businessKey, sortBy: column.props.sortBy }));
  }
  const baseline = columnSnapshots(initial);
  assert.deepEqual(baseline.map(column => column.businessKey), ["", ""]);
  assert.deepEqual(baseline.map(column => column.sortBy), [undefined, undefined]);
  const commonKey = JSON.stringify(["待接受", "mine"]);
  assert.deepEqual(baseline.map(column => column.resetKey), [commonKey, commonKey]);
  for (const [index, source] of sources.entries()) for (const sortBy of ["due", "updated"]) {
    const changed = columnSnapshots(freeze(setup.updateTaskWorkbenchState(initial, { type: "column-sort", source, sortBy })));
    assert.deepEqual(changed, baseline);
  }
  for (const patch of [{ productKey: "产品:p2" }, { creator: "李娜" }, { scope: "assigned" }]) {
    const changed = columnSnapshots(freeze(setup.updateTaskWorkbenchState(initial, { type: "column-filters", patch })));
    assert.deepEqual(changed, baseline);
  }
  for (const patch of [{ tfKey: "TF:t2" }, { projectKey: "Project:id:2" }, { tfKey: "", projectKey: "" }, { tfKey: "TF:missing", projectKey: "Project:missing", businessKind: "none", businessKey: "legacy-hidden" }]) {
    assert.deepEqual(columnSnapshots(rawPatch(patch)), baseline);
    assert.deepEqual(columnSnapshots(freeze(setup.updateTaskWorkbenchState(initial, { type: "column-filters", patch }))), baseline);
  }
  for (const status of ["进行中", "已完成"]) {
    const changed = columnSnapshots(freeze(setup.updateTaskWorkbenchState(initial, { type: "status", status })));
    for (const i of [0, 1]) assert.notEqual(changed[i].resetKey, baseline[i].resetKey);
  }
  const changedCase = columnSnapshots(freeze(setup.updateTaskWorkbenchState(initial, { type: "column-filters", patch: { caseId: "c2" } })));
  assert.deepEqual(changedCase, baseline);
  const expanded = columnSnapshots(freeze(setup.updateTaskWorkbenchState(initial, { type: "business" })));
  assert.deepEqual(expanded, baseline);
  const clearProduct = setup.updateTaskWorkbenchState(initial, { type: "column-filters", patch: { productKey: "" } });
  const cleared = columnSnapshots(freeze(clearProduct));
  assert.deepEqual(cleared.map(column => column.businessKey), ["", ""]);
  assert.deepEqual(cleared, baseline);
  assert.deepEqual(columnSnapshots(rawPatch({ productKey: "" })), cleared);
  assert.deepEqual(columnSnapshots(rawPatch({ productKey: "", tfKey: "" })), cleared);
  assert.equal(JSON.stringify(initial), before);
});

test("TaskSourceColumn renders the real controlled sorter only with both optional props and forwards display/navigation callbacks without touching rows", () => {
  const api = harness();
  const options = [{ value: "priority", label: "紧急程度" }, { value: "due", label: "截止日期" }, { value: "updated", label: "最近更新" }];
  assert.deepEqual(plain(api.TASK_COLUMN_SORT_OPTIONS), options);
  function capture(props) {
    let tree;
    function Probe() { tree = api.TaskSourceColumn(props); return tree; }
    const html = renderToStaticMarkup(createElement(Probe));
    return { tree, html };
  }
  for (const source of sources) {
    const rows = freeze(Array.from({ length: 12 }, (_, i) => row(String(11 - i).padStart(2, "0"), source)));
    const before = JSON.stringify(rows); const calls = [];
    const base = { ...columnProps(source, rows), onSortChange: value => calls.push(["sort", source, value]),
      onShowTask: value => calls.push(["detail", value]), onOpenCase: id => calls.push(["case", id]),
      onTakeAction: value => calls.push(["accept", value]), onReject: value => calls.push(["reject", value]),
    };
    for (const patch of [{ sortBy: undefined, onSortChange: undefined }, { sortBy: undefined }, { onSortChange: undefined }]) {
      const { tree, html } = capture({ ...base, ...patch });
      assert.equal(elements(tree).filter(node => node.type === api.WorkbenchSort).length, 0);
      assert.doesNotMatch(html, /<select\b|>排序</);
      assert.equal(articles(html).length, 12);
    }
    for (const sortBy of ["priority", "due", "updated"]) {
      const props = { ...base, sortBy }; const { tree, html } = capture(props);
      const header = elements(tree).find(node => node.type === "header");
      const sorter = elements(header).filter(node => node.type === api.WorkbenchSort);
      assert.equal(sorter.length, 1);
      assert.equal(sorter[0].props.ariaLabel, `${source === "case" ? "Case 任务" : "自由任务"}排序`);
      assert.equal(sorter[0].props.value, sortBy);
      assert.equal(sorter[0].props.options, api.TASK_COLUMN_SORT_OPTIONS);
      const native = elements(api.WorkbenchSort(sorter[0].props)).find(node => node.type === "select");
      const count = calls.length;
      for (const value of ["urgency", "level", "progress", "unknown", "", " due "]) native.props.onChange({ target: { value } });
      assert.equal(calls.length, count, "Unknown native values never reach the column callback");
      for (const option of options) {
        native.props.onChange({ target: { value: option.value } });
        assert.deepEqual(calls.at(-1), ["sort", source, option.value]);
        assert.equal(native.props.value, sortBy, "Selection remains controlled until the parent updates");
      }
      assert.equal(calls.length, count + 3);
      assert.deepEqual(articles(html).map(article => /aria-label="任务 ([^"]+)"/.exec(article)?.[1]), rows.map(item => item.id), "Columns display all rows in the supplied order, never re-sort or truncate");
      const cards = elements(tree).filter(node => node.type === api.WorkbenchTaskCard);
      assert.equal(cards.length, 12);
      cards.forEach((card, index) => {
        assert.equal(card.props.row, rows[index]); assert.equal(card.props.columnLayout, true);
        assert.equal(card.props.onOpenCase, base.onOpenCase);
      });
      cards[9].props.onShowTask(); assert.equal(calls.at(-1)[1], rows[9]); assert.equal(calls.at(-1)[0], "detail");
      cards[9].props.onTakeAction(); assert.equal(calls.at(-1)[1], rows[9]); assert.equal(calls.at(-1)[0], "accept");
      cards[9].props.onReject(); assert.equal(calls.at(-1)[1], rows[9]); assert.equal(calls.at(-1)[0], "reject");
      cards[9].props.onOpenCase("c1"); assert.deepEqual(calls.at(-1), ["case", "c1"]);
    }
    assert.equal(JSON.stringify(rows), before); assert.deepEqual(api.writes, []);
  }
});

test("MyTaskWorkbench uses fixed default orders across status navigation and retains full rows and detail callbacks", () => {
  const sortNames = ["priority", "due", "updated"];
  const defaults = { 待接受: "priority", 进行中: "due", 已完成: "updated" };
  // Independent explicit oracle: each comparator gives a different twelve-item order.
  const order = { priority: [11, 7, 3, 10, 6, 2, 9, 5, 1, 8, 4, 0], due: [11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0], updated: [7, 2, 9, 4, 11, 6, 1, 8, 3, 10, 5, 0] };
  const pad = i => String(i).padStart(2, "0");
  const fields = (status, i) => ({ status, urgency: ["不紧急", "一般", "紧急", "非常紧急"][i % 4],
    dueDate: `2026-09-${pad(12 - i)}`, updatedAt: `2026-09-${pad((i * 5) % 12 + 1)}T10:00:00Z`,
  });
  const cases = freeze([caseItem("c1", statuses.flatMap(status => Array.from({ length: 12 }, (_, i) => {
    const patch = fields(status, i);
    return action(`${status}-${pad(i)}`, { ...patch, statusHistory: [{ at: patch.updatedAt, from: "待接受", to: status }] });
  })).reverse(), { productId: "p1" })]);
  const tasks = freeze(statuses.flatMap(status => Array.from({ length: 12 }, (_, i) => task(`${status}-${pad(i)}`, {
    ...fields(status, i), involvement: { kind: "产品", id: "p1", name: "产品一" },
  }))));
  const before = JSON.stringify([cases, tasks]); const navigation = [];
  const api = harness({ controlledWorkbench: true });
  const props = { ...workbenchProps(cases, tasks), onOpenTask: (...args) => navigation.push(["case-task", ...args]),
    onOpenStandaloneTask: id => navigation.push(["standalone-task", id]), onOpenCase: id => navigation.push(["case", id]),
  };
  const columns = () => elements(api.tree).filter(node => node.type === api.TaskSourceColumn);
  const summary = () => elements(api.tree).find(node => node.type === api.TaskStatusSummary);
  function renderAndCheck(expected) {
    const html = api.renderWorkbench(props); const status = api.state.status;
    assertColumnSorters(html);
    for (const primary of statuses) assert.ok(html.includes(`aria-label="${primary} 24 件"`));
    assert.doesNotMatch(html, /筛选|排序/);
    for (const column of columns()) {
      const source = column.props.source; const sortBy = expected[source];
      assert.equal(column.props.sortBy, undefined); assert.equal(column.props.onSortChange, undefined);
      const expectedIds = order[sortBy].map(i => `${status}-${pad(i)}`);
      assert.deepEqual(plain(column.props.rows.map(item => item.id)), expectedIds);
      const markup = columnMarkup(html, source);
      assert.deepEqual(articles(markup).map(article => /aria-label="(?:执行|独立) ([^"]+)"/.exec(article)?.[1]), expectedIds);
      assert.equal(articles(markup).length, 12);
      assert.doesNotMatch(markup, /<select/);
    }
    assert.ok(buttons(html).some(button => stripTags(button) === "我负责72"));
    assert.ok(buttons(html).some(button => stripTags(button) === "我分派0"));
    if (status !== "待接受") assertNoTaskActions(html);
    assertNoNestedButtons(html); assert.deepEqual(api.writes, []);
    return html;
  }
  renderAndCheck({ case: "priority", standalone: "priority" });
  const saved = {};
  for (const [statusIndex, status] of statuses.entries()) {
    summary().props.onChange(status);
    renderAndCheck({ case: defaults[status], standalone: defaults[status] });
    const pair = { case: defaults[status], standalone: defaults[status] };
    renderAndCheck(pair);
    saved[status] = { view: api.state.views[status], pair, keys: columns().map(column => column.props.resetKey) };
  }
  for (const status of ["待接受", "已完成", "进行中", "待接受"]) {
    summary().props.onChange(status); renderAndCheck(saved[status].pair);
    assert.equal(api.state.views[status], saved[status].view);
    assert.deepEqual(columns().map(column => column.props.resetKey), saved[status].keys);
  }
  for (const column of columns()) {
    const first = column.props.rows[0]; column.props.onShowTask(first);
    assert.deepEqual(navigation.at(-1), column.props.source === "case" ? ["case-task", "c1", first.id] : ["standalone-task", first.id]);
    column.props.onOpenCase("c1"); assert.deepEqual(navigation.at(-1), ["case", "c1"]);
  }
  assert.equal(JSON.stringify([cases, tasks]), before); assert.deepEqual(api.writes, []);
});