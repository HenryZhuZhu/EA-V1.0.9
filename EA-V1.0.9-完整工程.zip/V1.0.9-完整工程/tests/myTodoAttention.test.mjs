import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";
import { fileURLToPath } from "node:url";

const source = readFileSync(fileURLToPath(new URL("../src/app/components/MyTodo.tsx", import.meta.url)), "utf8");

test("My Attention opens Recently Viewed and places it first", () => {
  assert.match(source, /useState<"subscribed" \| "recent">\("recent"\)/);
  assert.match(source, /aria-label="关注内容"[\s\S]*?<Tabs\.Trigger value="recent"[\s\S]*?>最近浏览<\/Tabs\.Trigger><Tabs\.Trigger value="subscribed"[\s\S]*?>我的订阅<\/Tabs\.Trigger>/);
});