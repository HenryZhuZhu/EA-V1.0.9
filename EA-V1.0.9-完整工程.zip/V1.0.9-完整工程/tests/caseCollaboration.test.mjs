import test from 'node:test';import assert from 'node:assert/strict';import vm from 'node:vm';import {build} from 'esbuild';import {webcrypto} from 'node:crypto';import {fileURLToPath} from 'node:url';
const {outputFiles}=await build({stdin:{contents:"export * from './caseParticipants';export * from './caseFeishuGroups';export {currentUser,mockCases} from './data';",resolveDir:fileURLToPath(new URL('../src/app/components/',import.meta.url))},bundle:true,write:false,platform:'node',format:'cjs',plugins:[{name:'hooks',setup(builder){builder.onResolve({filter:/^react$/},()=>({path:'react',namespace:'stub'}));builder.onLoad({filter:/.*/,namespace:'stub'},()=>({contents:'export const useEffect=()=>{};export const useState=()=>[0,()=>{}];'}));}}]});
function setup(fail=false,groups={},trees={}){const storage=new Map([['ea_v109_case_group_demo',JSON.stringify(groups)],['ea_case_task_trees_v1',JSON.stringify(trees)]]);const box={module:{exports:{}},btoa,atob,crypto:webcrypto,localStorage:{getItem:key=>storage.get(key)??null,setItem:(key,value)=>{if(fail)throw Error('quota');storage.set(key,value);}}};vm.runInNewContext(outputFiles[0].text,box);return box.module.exports;}
const action=(id,owner,extra={})=>({id,code:id,owner,department:'PTE',status:'进行中',title:id,...extra});
test('core participants prioritize real current tasks, cross-department representation and exclude owner/thought/skill placeholders',()=>{const api=setup();const record={owner:'张伟',participants:[{name:'张伟'},{name:'周杰',department:'PTE'},{name:'李娜',department:'DA'},{name:'陈磊',department:'CP'}],tasks:[action('a','周杰'),action('b','周杰'),action('c','李娜',{conclusion:'证据'}),action('thought','伪参与',{code:undefined}),action('skill','机器人',{assigneeType:'skill'}),action('empty','待指派'),action('rejected','王芳',{status:'已拒绝'})]};const original=JSON.stringify(record);const result=api.coreCaseParticipants(record);assert.deepEqual(JSON.parse(JSON.stringify(result.selected.map(person=>person.name))),['周杰','李娜']);assert.equal(result.total,3);assert.deepEqual(JSON.parse(JSON.stringify(api.caseParticipants(record).map(person=>person.name))),['张伟','周杰','李娜','陈磊']);assert.equal(JSON.stringify(record),original);});
test('empty and explicit-only participants use stable fallback and never fabricate two people',()=>{const api=setup();assert.equal(api.coreCaseParticipants({owner:'张伟',tasks:[]}).total,0);const result=api.coreCaseParticipants({owner:'张伟',participants:[{name:'李娜'},{name:'李娜'}],tasks:[]});assert.equal(result.selected.length,1);assert.equal(result.total,1);});
test('supervisors, directors and VP can create groups without being the Case Owner',()=>{
	for(const actor of ['周主管','高总监','林副总']){
		const api=setup();const record={...api.mockCases[0],id:'manager-group',owner:'张伟',participants:[],tasks:[]};api.mockCases.push(record);
		api.currentUser.name=actor;assert.equal(api.canManageCaseGroup(),true);
		const group=api.updateDemoCaseGroup(record.id,'create');assert.equal(group.createdBy,actor);assert.ok(group.members.includes(actor));assert.ok(group.members.includes(record.owner));
	}
});
test('engineers including the Owner, participants and unknown names cannot mutate group records',()=>{
	const api=setup();const record={...api.mockCases[0],id:'denied-group',owner:'张伟',participants:[{name:'李娜'}],tasks:[]};api.mockCases.push(record);
	for(const actor of ['张伟','李娜','不存在的主管']){
		api.currentUser.name=actor;assert.equal(api.canManageCaseGroup(),false);assert.throws(()=>api.updateDemoCaseGroup(record.id,'create'),/主管及以上/);assert.equal(api.getCaseGroup(record.id),undefined);
	}
	api.currentUser.name='周主管';const original=JSON.stringify(api.updateDemoCaseGroup(record.id,'create'));
	for(const actor of ['张伟','李娜','不存在的主管'])for(const operation of ['create','join','sync']){
		api.currentUser.name=actor;assert.throws(()=>api.updateDemoCaseGroup(record.id,operation),/主管及以上/);assert.equal(JSON.stringify(api.getCaseGroup(record.id)),original);
	}
});
test('one group per Case only supports initial creation and additive participant supplementation',()=>{
	const api=setup();const record={...api.mockCases[0],id:'group-case',owner:'张伟',participants:[{name:'李娜'}],tasks:[action('task','周杰')]};api.mockCases.push(record);
	api.currentUser.name='周主管';let group=api.updateDemoCaseGroup(record.id,'create',['李娜']);assert.ok(group.members.includes('周杰'));assert.deepEqual(JSON.parse(JSON.stringify(group.failed)),['李娜']);
	api.currentUser.name='高总监';assert.equal(api.updateDemoCaseGroup(record.id,'create').id,group.id);group=api.updateDemoCaseGroup(record.id,'sync');assert.ok(group.members.includes('李娜'));assert.equal(group.failed.length,0);assert.ok(!group.members.includes('高总监'));
	const before=JSON.stringify(group);assert.throws(()=>api.updateDemoCaseGroup(record.id,'join'),/补充参与人/);assert.equal(JSON.stringify(api.getCaseGroup(record.id)),before);
	record.participants.push({name:'高总监'});group=api.updateDemoCaseGroup(record.id,'sync');assert.ok(group.members.includes('高总监'));assert.equal(new Set(group.members).size,group.members.length);
	record.participants=[];record.tasks=[];api.currentUser.name='林副总';group=api.updateDemoCaseGroup(record.id,'sync');assert.ok(group.members.includes('李娜'));assert.ok(group.members.includes('周杰'));
});
test('creation preview and actual members include the clicker, Owner and all Case/task collaborators from the current tree',()=>{
	const trees={'full-group':[{id:'thought',owner:'待指派',children:[action('nested','陈磊',{collaborators:[{name:'王芳',department:'CP'},{name:'李娜',department:'DA'}]})]},action('finished','周杰',{status:'已完成',collaborators:[{name:'孙楠',department:'QA'}]}),action('stopped','赵敏',{status:'已中止'}),action('skill','系统',{assigneeType:'skill'}),action('empty','待指派')]};
	const api=setup(false,{},trees);api.mockCases.push({...api.mockCases[0],id:'full-group',owner:'张伟',participants:[{name:'李娜',department:'DA'},{name:'张伟',department:'PTE'},{name:'李娜',department:'DA'}],tasks:[action('stale','张三')]});api.currentUser.name='周主管';
	const expected=['张伟','李娜','陈磊','王芳','周杰','孙楠','赵敏','周主管'].sort();
	const preview=api.caseGroupCandidates('full-group','周主管').map(person=>person.name);assert.deepEqual(Array.from(preview).sort(),expected);
	const group=api.updateDemoCaseGroup('full-group','create');assert.deepEqual(Array.from(group.members).sort(),expected);assert.equal(group.failed.length,0);
	const repeated=api.updateDemoCaseGroup('full-group','sync');assert.equal(repeated.id,group.id);assert.deepEqual(Array.from(repeated.members),Array.from(group.members));
});
test('legacy Owner-created groups retain identity, creator and membership under new manager permissions',()=>{
	const old={id:'legacy-group',caseId:'legacy-case',name:'历史群组',createdBy:'张伟',createdAt:'2026-09-20',members:['张伟','李娜'],failed:[]};const api=setup(false,{'legacy-case':old});
	api.mockCases.push({...api.mockCases[0],id:'legacy-case',owner:'张伟',participants:[{name:'周杰'}],tasks:[]});assert.deepEqual(JSON.parse(JSON.stringify(api.getCaseGroup('legacy-case'))),old);
	assert.throws(()=>api.updateDemoCaseGroup('legacy-case','sync'),/主管及以上/);api.currentUser.name='高总监';const group=api.updateDemoCaseGroup('legacy-case','sync');assert.equal(group.id,old.id);assert.equal(group.createdBy,'张伟');assert.ok(group.members.includes('李娜'));assert.ok(group.members.includes('周杰'));
});
test('failed storage never leaves a phantom group and unknown accounts stay visibly failed',()=>{const api=setup(true);const record={...api.mockCases[0],id:'fail-case',owner:'张伟',participants:[],tasks:[]};api.mockCases.push(record);api.currentUser.name='周主管';assert.throws(()=>api.updateDemoCaseGroup(record.id,'create'),/保存失败/);assert.equal(api.getCaseGroup(record.id),undefined);const real=setup();real.currentUser.name='高总监';real.mockCases.push({...record,participants:[{name:'未映射用户'},{name:'林副总'}]});const group=real.updateDemoCaseGroup(record.id,'create');assert.ok(group.failed.includes('未映射用户'));assert.ok(group.members.includes('林副总'));});