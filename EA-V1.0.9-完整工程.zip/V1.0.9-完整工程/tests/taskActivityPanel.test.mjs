import test from "node:test";
import assert from "node:assert/strict";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";
import vm from "node:vm";
import { build } from "esbuild";
import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";

const require = createRequire(import.meta.url);
const { outputFiles } = await build({
  entryPoints: [fileURLToPath(new URL("../src/app/components/TaskActivityPanel.tsx", import.meta.url))],
  bundle: true, write: false, platform: "node", format: "cjs", jsx: "automatic",
  external: ["react", "react/jsx-runtime", "lucide-react", "./data"],
});
const sandbox = {
  module: { exports: {} },
  require: (name) => name === "./data" ? { currentUser: { name: "张伟" } } : require(name),
};
vm.runInNewContext(outputFiles[0].text, sandbox);
const { TaskActivityPanel } = sandbox.module.exports;
const render = (props = {}) => renderToStaticMarkup(createElement(TaskActivityPanel, { onComment() {}, ...props }));

test("all activity kinds share one newest-first timeline without type filters", () => {
  const activities = ["create", "status", "edit", "upgrade", "comment"].map((kind, index) => ({
    id: kind, kind, at: `2026-09-08T10:0${index}:00Z`, by: "张伟", summary: `event-${kind}`,
    changes: kind === "status" ? [{ field: "状态", before: "待接受", after: "进行中" }]
      : kind === "edit" ? [{ field: "任务说明", before: "之前的说明\n第二行", after: "新的说明\n补充要求" }] : [],
  }));
  const html = render({ activities, statusHistory: [
    { status: "进行中", at: activities[1].at, by: "张伟" },
    { status: "待接受", at: "2026-09-08T09:00:00Z", by: "李娜" },
  ] });
  assert.match(html, />全部<\/span>/);
  assert.doesNotMatch(html, /流转记录|修改记录|日志类型/);
  assert.match(html, /操作日志 <span[^>]*>6<\/span>/);
  const positions = ["event-comment", "event-upgrade", "event-edit", "event-status", "event-create", "状态记录：待接受"].map((text) => html.indexOf(text));
  assert.ok(positions.every((position, index) => position >= 0 && (index === 0 || position > positions[index - 1])));
  assert.doesNotMatch(html, /状态记录：进行中/); // Existing status activity is not duplicated.
  assert.match(html, /<details/);
  assert.match(html, /之前的说明\n第二行/);
  assert.match(html, /新的说明\n补充要求/);
  assert.match(html, /评论 <span/);
});

test("empty unified log keeps its honest empty state and comment entry", () => {
  const html = render();
  assert.match(html, /暂无操作日志/);
  assert.doesNotMatch(html, /暂无此类记录|流转记录|修改记录|<ol/);
  assert.match(html, /发表评论/);
  assert.match(html, /操作日志 <span[^>]*>0<\/span>/);
});

test("standalone log-only view has no comment entry and drawer-only view shows real comments without logs", () => {
  const comments = [{ id: "comment", user: "李娜", time: "2026-09-10T10:00:00Z", content: "已有评论", replies: [{ id: "reply", user: "张伟", time: "2026-09-10T11:00:00Z", content: "已有回复" }] }];
  const log = render({ view: "log", comments });
  assert.match(log, /暂无操作日志/); assert.doesNotMatch(log, /发表评论|已有评论|动态内容/);
  const drawer = render({ view: "comments", compact: true, comments });
  assert.match(drawer, /已有评论/); assert.match(drawer, /已有回复/); assert.match(drawer, /发表评论/);
  assert.doesNotMatch(drawer, /任务流转日志|暂无操作日志|动态内容|hidden=""/);
  const frozen = render({ view: "comments", comments, readOnlyReason: "任务已升级为 Case" });
  assert.match(frozen, /已有评论|任务已升级为 Case/); assert.doesNotMatch(frozen, /发表评论|<textarea/);
});