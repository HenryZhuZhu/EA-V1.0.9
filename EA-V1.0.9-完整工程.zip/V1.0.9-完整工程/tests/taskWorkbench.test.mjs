import assert from "node:assert/strict";
import test from "node:test";
import { build } from "esbuild";
import { fileURLToPath } from "node:url";
import vm from "node:vm";

const { outputFiles } = await build({ entryPoints: [fileURLToPath(new URL("../src/app/components/taskWorkbenchModel.ts", import.meta.url))], bundle: true, write: false, platform: "node", format: "cjs", external: ["./data"] });
function flattenTasks(nodes) { return nodes.flatMap(task => [{ task }, ...flattenTasks(task.children ?? [])]); }
const sandbox = { module: { exports: {} }, require: name => { if (name === "./data") return { flattenTasks }; throw new Error(name); } };
vm.runInNewContext(outputFiles[0].text, sandbox);
const { buildWorkbenchTasks: buildRows, selectWorkbenchTasks: select, taskBelongsTo: belongs, taskCanAct: canAct, taskRemainingDays: days, groupWorkbenchTasks: group, paginateTaskGroups: paginate, updateWorkbenchFilters: updateFilters, DEFAULT_TASK_FILTERS } = sandbox.module.exports;
const { availableTaskGroups: availableGroups, defaultTaskSort } = sandbox.module.exports;
const plain = value => JSON.parse(JSON.stringify(value));
const actor = "张伟";
const products = [{ id: "p1", code: "DDR5", name: "产品一" }, { id: "p2", code: "LPDDR", name: "产品二" }];
const filter = patch => ({ ...DEFAULT_TASK_FILTERS, ...patch });
const daily = (id, patch = {}) => ({ id, code: `TASK-${id}`, title: `日常${id}`, description: "任务说明", owner: actor, createdBy: actor, createdForOther: false, collaborators: [], urgency: "一般", dueDate: "2026-09-12", status: "进行中", attachments: [], updatedAt: "2026-09-09T10:00:00Z", createdAt: "2026-09-09T09:00:00Z", ...patch });
const action = (id, patch = {}) => ({ id, code: `EA-${id}`, title: `执行${id}`, owner: actor, supervisor: "刘洋", department: "PTE", urgency: "一般", progress: 0, status: "待接受", dueDate: "2026-09-12", ...patch });
const c = (id, tasks, patch = {}) => ({ id, code: `CASE-${id}`, name: `问题${id}`, owner: actor, status: "进行中", productId: "p1", participants: [], updatedAt: "2026-09-10T00:00:00Z", tasks, ...patch });
const rows = (cases = [], tasks = [], extra = {}) => buildRows(cases, tasks, { products, ...extra });

test("relations distinguish responsible, assigned-to-others and participating without guessing dispatcher", () => {
  const list = rows([c("a", [action("owner-fallback", { owner: "李娜", supervisor: undefined }), action("assigned", { owner: "李娜", supervisor: actor }), action("participant", { owner: "刘洋", collaborators: [{ name: actor }] })])], [daily("self"), daily("outgoing", { owner: "李娜" }), daily("participant", { owner: "李娜", createdBy: "刘洋", collaborators: [{ name: actor }] })]);
  assert.deepEqual(plain(list.filter(r => belongs(r, "assigned", actor)).map(r => r.id).sort()), ["assigned", "outgoing"]);
  assert.equal(list.filter(r => belongs(r, "participating", actor)).length, 2);
  assert.equal(list.filter(r => belongs(r, "mine", actor)).length, 1);
  assert.equal(list.find(r => r.id === "owner-fallback").creator, "");
});

test("participation respects explicit task membership and legacy Case fallback without granting operations", () => {
  const list = rows([c("a", [action("inherit", { owner: "李娜" }), action("empty", { owner: "李娜", collaborators: [] }), action("self", { collaborators: [{ name: actor }] })], { participants: [{ name: actor }] })]);
  assert.equal(belongs(list[0], "participating", actor), true);
  assert.equal(list[0].participantsFromCase, true);
  assert.equal(belongs(list[1], "participating", actor), false);
  assert.equal(belongs(list[2], "participating", actor), false);
  assert.equal(canAct(list[0], actor), false);
});

test("status summaries share role source business search filters but ignore the selected status", () => {
  const tasks = [daily("pending", { status: "待接受" }), daily("doing"), daily("done", { status: "已完成" }), daily("other", { owner: "李娜", status: "已完成" })];
  const list = rows([c("a", [action("case-doing", { status: "进行中" })])], tasks);
  const all = select(list, filter(), actor);
  assert.deepEqual(plain(all.counts), { 待接受: 1, 进行中: 2, 已完成: 1 });
  for (const status of ["待接受", "进行中", "已完成"]) {
    const selected = select(list, filter({ status }), actor);
    assert.deepEqual(plain(selected.counts), plain(all.counts));
    assert.ok(selected.rows.every(r => r.status === status));
  }
  assert.deepEqual(plain(select(list, filter({ source: "standalone" }), actor).counts), { 待接受: 1, 进行中: 1, 已完成: 1 });
  assert.deepEqual(plain(select(list, filter({ query: "case-doing" }), actor).counts), { 待接受: 0, 进行中: 1, 已完成: 0 });
});

test("closed Case tasks stay searchable with true states and no execution actions", () => {
  const list = rows([c("raw", [action("raw")], { status: "已关闭" }), c("store", [action("store", { status: "已完成" })]), c("archive", [action("archive", { status: "进行中" })], { status: "已归档" }), c("open", [action("open")])], [], { isClosed: id => id === "store" });
  assert.deepEqual(plain(list.map(r => r.caseClosed)), [true, true, true, false]);
  assert.deepEqual(plain(list.map(r => canAct(r, actor))), [false, false, false, true]);
  assert.deepEqual(plain(select(list, filter(), actor).counts), { 待接受: 2, 进行中: 1, 已完成: 1 });
  assert.equal(select(list, filter({ caseId: "raw", status: "待接受" }), actor).rows.length, 1);
});

test("upgraded and partially linked sources are excluded by default and never double-counted", () => {
  const list = rows([c("up", [action("import", { status: "进行中" })], { sourceStandaloneTaskIds: ["partial"] })], [daily("source", { convertedCaseId: "other-case", status: "已完成" }), daily("partial"), daily("regular")]);
  assert.equal(select(list, filter(), actor).rows.length, 2);
  const history = select(list, filter({ showUpgraded: true }), actor);
  assert.equal(history.rows.length, 4);
  assert.deepEqual(plain(history.counts), { 待接受: 0, 进行中: 2, 已完成: 0 });
  assert.equal(history.taskCount, 2); assert.equal(history.upgradedCount, 2);
  const completed = select(list, filter({ showUpgraded: true, status: "已完成" }), actor);
  assert.equal(completed.taskCount, 0); assert.equal(completed.upgradedCount, 1);
  assert.equal(completed.rows[0].id, "source");
  assert.ok(list.filter(r => r.convertedCaseId).every(r => !canAct(r, actor)));
});

test("upgraded toggle preserves status and Case filters remain usable in all and Case scopes", () => {
  const initial = filter({ source: "case", caseId: "a", status: "进行中", businessKind: "产品", businessKey: "产品:p1", creator: "刘洋" });
  const before = JSON.stringify(initial);
  const enabled = updateFilters(initial, { showUpgraded: true });
  assert.deepEqual(plain(enabled), { ...initial, showUpgraded: true });
  assert.equal(updateFilters(enabled, { showUpgraded: false }).status, "进行中");
  const all = updateFilters(enabled, { source: "all" });
  assert.equal(all.caseId, "a");
  assert.equal(updateFilters(all, { source: "case" }).caseId, "a");
  const dailyOnly = updateFilters(all, { source: "standalone" });
  assert.deepEqual(plain(dailyOnly), { ...enabled, source: "standalone", caseId: "" });
  assert.equal(updateFilters(dailyOnly, { source: "all" }).caseId, "");
  assert.equal(JSON.stringify(initial), before);
});

test("upgraded originals respect each saved status and common filters without inflating summaries", () => {
  const statuses = ["待接受", "进行中", "已完成"];
  const tasks = statuses.flatMap((status, i) => [daily(`normal-${i}`, { status }), daily(`old-${i}`, { status, convertedCaseId: "up" })]);
  const list = rows([c("up", [action("import")])], tasks);
  for (const status of [...statuses, null]) {
    const hidden = select(list, filter({ status }), actor);
    const shown = select(list, filter({ status, showUpgraded: true }), actor);
    assert.deepEqual(plain(shown.counts), plain(hidden.counts));
    assert.deepEqual(plain(shown.scopeCounts), plain(hidden.scopeCounts));
    assert.equal(shown.taskCount, hidden.taskCount);
    assert.equal(hidden.upgradedCount, 0);
    assert.equal(shown.upgradedCount, status === null ? 3 : 1);
    assert.equal(shown.rows.length, shown.taskCount + shown.upgradedCount);
    assert.ok(shown.rows.every(r => status === null || r.status === status));
  }
  for (const patch of [{ source: "case" }, { caseId: "up" }, { businessKind: "产品" }, { creator: "other" }, { scope: "assigned" }, { scope: "participating" }]) {
    assert.equal(select(list, filter({ ...patch, showUpgraded: true }), actor).upgradedCount, 0);
  }
  const empty = select([], filter({ showUpgraded: true }), actor);
  assert.equal(empty.taskCount, 0); assert.equal(empty.upgradedCount, 0);
});

test("mixed and history-only pagination retain separate whole-group totals across pages", () => {
  const list = rows([], [...Array.from({ length: 9 }, (_, i) => daily(`normal-${i}`)), ...Array.from({ length: 3 }, (_, i) => daily(`old-${i}`, { convertedCaseId: "up" }))]);
  for (const by of ["none", "case", "business", "owner", "due"]) {
    const groups = group(list, by, new Date(2026, 8, 9));
    const keys = [];
    for (const p of [1, 2]) {
      const page = paginate(groups, p);
      assert.equal(page.total, 12); assert.equal(page.pages, 2);
      for (const g of page.groups) {
        const original = groups.find(item => item.key === g.key);
        assert.equal(g.upgradedCount, original.rows.filter(r => r.convertedCaseId).length);
        assert.equal(g.taskCount + g.upgradedCount, original.total);
        keys.push(...g.rows.map(r => r.key));
      }
    }
    assert.equal(keys.length, 12); assert.equal(new Set(keys).size, 12);
  }
  const history = paginate(group(list.filter(r => r.convertedCaseId), "due"), 1).groups[0];
  assert.equal(history.label, "已升级的原任务");
  assert.equal(history.taskCount, 0); assert.equal(history.upgradedCount, 3);
});

test("business references retain direct versus Case origin, multiple products and exact keys", () => {
  const task = action("import", { standaloneTaskContext: { involvement: { kind: "产品", id: "p1", name: "DDR5 · 产品一" } } });
  const list = rows([c("a", [task], { productIds: ["p1", "p2", "p2"] })], [daily("tf", { involvement: { kind: "TF", id: "tf1", name: "专项一" } }), daily("none")]);
  assert.equal(list[0].business.length, 2); assert.equal(list[0].business[0].origin, "task"); assert.equal(list[0].business[1].origin, "case");
  assert.equal(select(list, filter({ businessKind: "产品", businessKey: "产品:p2" }), actor).rows[0].id, "import");
  assert.equal(select(list, filter({ businessKind: "TF" }), actor).rows[0].id, "tf");
  assert.equal(select(list, filter({ businessKind: "none" }), actor).rows[0].id, "none");
  assert.equal(select(list, filter({ businessKind: "产品", businessKey: "TF:tf1" }), actor).rows.length, 0);
});

test("Project names are not fabricated IDs; title text alone never creates a product association", () => {
  const list = rows([c("text", [action("a", { title: "DDR5 验证" })], { productId: undefined, product: "不存在", projectName: "同名项目" })], [daily("direct", { involvement: { kind: "Project", id: "p-project", name: "同名项目" } })]);
  assert.equal(list[0].business.length, 1); assert.equal(list[0].business[0].nameOnly, true);
  assert.notEqual(list[0].business[0].key, list[1].business[0].key);
  assert.equal(select(list, filter({ businessKind: "产品" }), actor).rows.length, 0);
  const exact = rows([c("legacy", [action("b")], { productId: undefined, product: "DDR5" })]);
  assert.equal(exact[0].business[0].key, "产品:p1");
});

test("recursive saved task trees are used instead of stale snapshots and thoughts are excluded", () => {
  const source = c("a", [action("stale")]);
  const list = rows([source], [], { loadTree: () => [{ id: "thought", title: "方向", children: [action("actual", { status: "已完成", activityLog: [{ at: "2026-09-09T11:00:00Z" }], children: [action("deep")] })] }] });
  assert.deepEqual(plain(list.map(r => r.id)), ["actual", "deep"]);
  assert.equal(list[0].status, "已完成"); assert.equal(list[0].updatedAt, "2026-09-09T11:00:00Z");
});

test("search combines words across task name code Case business people and saved results", () => {
  const list = rows([c("c1", [action("a", { conclusion: "高温已验证", owner: "李娜", supervisor: actor })])]);
  assert.equal(select(list, filter({ scope: "assigned", query: "CASE-C1 高温 李娜 DDR5" }), actor).rows.length, 1);
  assert.equal(select(list, filter({ scope: "assigned", query: "[.*]" }), actor).rows.length, 0);
  assert.equal(select(list, filter({ scope: "assigned", creator: "其他人" }), actor).rows.length, 0);
});

test("due groups use calendar dates, not stale dueIn or milliseconds across daylight saving", () => {
  const now = new Date(2026, 8, 9, 23, 50);
  assert.equal(days({ dueDate: "2026-09-09", dueIn: 20 }, now), 0);
  assert.equal(days({ dueDate: "2026-09-08" }, now), -1);
  assert.equal(days({ dueDate: "2026-09-10" }, now), 1);
  assert.equal(days({ dueDate: "2026-02-31" }, now), undefined);
  assert.equal(days({}, now), undefined);
  const list = rows([], [daily("old", { dueDate: "2026-09-08" }), daily("today", { dueDate: "2026-09-09" }), daily("none", { dueDate: "" }), daily("end", { status: "已拒绝", dueDate: "2026-09-08" })]);
  assert.deepEqual(plain(group(list, "due", now).map(g => g.label)), ["已逾期", "今天到期", "无截止日期", "已结束"]);
});

test("grouped pagination orders globally, preserves totals and shows each task once", () => {
  const list = rows([c("a", Array.from({ length: 13 }, (_, i) => action(String(i))), { productIds: ["p1", "p2"] })], Array.from({ length: 4 }, (_, i) => daily(`d${i}`)));
  for (const by of ["none", "case", "business", "owner", "due"]) {
    const groups = group(list, by, new Date(2026, 8, 9));
    const keys = [];
    for (let p = 1; p <= 3; p++) { const page = paginate(groups, p); assert.equal(page.total, 17); assert.equal(page.pages, 3); const pageRows = page.groups.flatMap(g => g.rows); assert.ok(pageRows.length <= 8); keys.push(...pageRows.map(r => r.key)); }
    assert.equal(new Set(keys).size, 17); assert.equal(keys.length, 17);
  }
  assert.equal(paginate(group(list, "none"), 999).page, 3);
  assert.equal(paginate([], 5).page, 1);
  assert.equal(group(list, "business", new Date(), "产品:p2").find(g => g.rows.some(r => r.source === "case")).key, "产品:p2");
});

test("reading filtering grouping and pagination never mutate source records or authorize by visibility", () => {
  const originalCases = [c("a", [action("a", { owner: "李娜", supervisor: actor })])], originalTasks = [daily("d", { visibility: { type: "partial", people: ["李娜"] } })];
  const before = JSON.stringify([originalCases, originalTasks]);
  const list = rows(originalCases, originalTasks);
  const listBefore = JSON.stringify(list);
  select(list, filter({ query: "a" }), actor); paginate(group(list, "owner"), 1);
  assert.equal(canAct(list[0], actor), false); assert.equal(canAct(list[1], actor), true);
  assert.equal(JSON.stringify([originalCases, originalTasks]), before); assert.equal(JSON.stringify(list), listBefore);
});

test("explicit sorts handle valid, missing and invalid dates with deterministic key ties and priority fallback", () => {
  const now = new Date(2026, 8, 10, 12);
  assert.deepEqual(["待接受", "进行中", "已完成"].map(defaultTaskSort), ["priority", "due", "updated"]);
  const tasks = [
    daily("tie-z", { updatedAt: "2026-09-08T10:00:00Z" }),
    daily("invalid-due", { urgency: "非常紧急", dueDate: "2026-02-31", updatedAt: "2026-09-11T10:00:00Z" }),
    daily("missing-updated", { dueDate: "2026-09-10", updatedAt: undefined }),
    daily("late", { urgency: "非常紧急", dueDate: "2026-09-13", updatedAt: "2026-09-07T10:00:00Z" }),
    daily("missing-due", { urgency: "紧急", dueDate: undefined, updatedAt: "2026-09-12T10:00:00Z" }),
    daily("invalid-updated", { dueDate: "2026-09-10", updatedAt: "not-a-date" }),
    daily("early", { urgency: "不紧急", dueDate: "2026-09-09", updatedAt: "2026-09-10T10:00:00Z" }),
    daily("tie-a", { updatedAt: "2026-09-08T10:00:00Z" }),
    daily("newer"),
    daily("missing-both", { urgency: "紧急", dueDate: "", updatedAt: "" }),
    daily("invalid-both", { urgency: "紧急", dueDate: "not-a-date", updatedAt: "not-a-date" }),
  ];
  const list = Object.freeze(rows([], tasks).map(Object.freeze));
  const before = JSON.stringify([tasks, list]);
  const expected = {
    priority: ["late", "invalid-due", "missing-due", "invalid-both", "missing-both", "invalid-updated", "missing-updated", "newer", "tie-a", "tie-z", "early"],
    due: ["early", "invalid-updated", "missing-updated", "newer", "tie-a", "tie-z", "late", "invalid-due", "missing-due", "invalid-both", "missing-both"],
    updated: ["missing-due", "invalid-due", "early", "newer", "tie-a", "tie-z", "late", "invalid-both", "missing-both", "invalid-updated", "missing-updated"],
  };
  for (const input of [list, Object.freeze([...list].reverse()), Object.freeze([...list.slice(4), ...list.slice(0, 4)])]) {
    for (const [sortBy, ids] of Object.entries(expected)) {
      const sorted = group(input, "none", now, "", sortBy)[0].rows;
      assert.deepEqual(plain(sorted.map(r => r.id)), ids, sortBy);
      for (const r of sorted) {
        assert.equal(r, list.find(original => original.key === r.key));
        assert.equal(r.record, tasks.find(task => task.id === r.id));
      }
    }
    assert.deepEqual(plain(group(input, "none", now)[0].rows.map(r => r.id)), expected.priority);
  }
  assert.equal(JSON.stringify([tasks, list]), before);
});

test("every explicit sort survives cross-group pagination without losing rows, references or full-group totals", () => {
  const now = new Date(2026, 8, 9, 12);
  const cases = [10, 5, 6].map((count, index) => c(String(index), Array.from({ length: count }, (_, i) => action(`${index}-${i}`, {
    owner: ["A", "B", "C"][index], status: "进行中", urgency: ["一般", "紧急", "非常紧急", "不紧急"][i % 4],
    dueDate: ["2026-09-08", "2026-09-09", "2026-09-12"][index],
    activityLog: [{ at: `2026-09-${String(i % 9 + 1).padStart(2, "0")}T10:00:00Z` }],
  })), { productId: `p${index + 1}`, productIds: [`p${index + 1}`, "shared"] }));
  const list = Object.freeze(rows(cases).map(Object.freeze));
  const before = JSON.stringify([cases, list]);
  for (const sortBy of ["priority", "due", "updated"]) {
    const sorted = group(list, "none", now, "", sortBy)[0].rows;
    for (const by of ["none", "owner", "case", "business", "due"]) {
      const groups = group(list, by, now, "", sortBy);
      const groupsBefore = JSON.stringify(groups);
      for (const g of groups) {
        assert.deepEqual(plain(g.rows.map(r => r.key)), plain(sorted.filter(r => g.rows.includes(r)).map(r => r.key)));
        assert.equal(g.total, g.rows.length);
      }
      const seen = []; const pages = [];
      for (const p of [1, 2, 3]) {
        const page = paginate(groups, p); pages.push(page);
        assert.equal(page.page, p); assert.equal(page.pages, 3); assert.equal(page.total, 21);
        assert.equal(page.groups.flatMap(g => g.rows).length, p === 3 ? 5 : 8);
        for (const g of page.groups) {
          const original = groups.find(item => item.key === g.key);
          assert.equal(g.total, original.total); assert.equal(g.taskCount, original.total); assert.equal(g.upgradedCount, 0);
          assert.equal(g.continued, original.rows.indexOf(g.rows[0]) > 0);
          for (const r of g.rows) assert.equal(r, list.find(item => item.key === r.key));
          seen.push(...g.rows.map(r => r.key));
        }
      }
      assert.deepEqual(seen, plain(groups.flatMap(g => g.rows.map(r => r.key))));
      assert.deepEqual([...seen].sort(), plain(list.map(r => r.key).sort()));
      assert.equal(new Set(seen).size, 21);
      assert.ok(pages.some(page => page.groups.some(g => g.continued)));
      if (by !== "none") assert.ok(pages.some(page => page.groups.length > 1));
      assert.equal(JSON.stringify(groups), groupsBefore);
    }
  }
  assert.equal(JSON.stringify([cases, list]), before);
});

test("meaningful group options respect relation, source, Case, business and completed contexts", () => {
  const now = new Date(2026, 8, 9, 12);
  const cases = ["a", "b"].map((id, i) => c(id, [actor, "李娜", "王强"].map((owner, j) => action(`${id}-${j}`, {
    owner, supervisor: actor, collaborators: [{ name: actor }], status: "进行中", dueDate: j === 1 ? "2026-09-08" : "2026-09-09",
  })), { productId: `p${i + 1}`, productIds: i ? ["p2", "p1"] : ["p1", "p2"] }));
  const tasks = [actor, "李娜", "王强"].flatMap((owner, i) => [
    daily(`tf-${i}`, { owner, collaborators: [{ name: actor }], involvement: { kind: "TF", id: `tf${i}`, name: `专项${i}` } }),
    daily(`none-${i}`, { owner, collaborators: [{ name: actor }], dueDate: i === 1 ? "2026-09-08" : "2026-09-12" }),
  ]);
  const list = rows(cases, tasks); const before = JSON.stringify([cases, tasks, list]);
  const all = ["none", "due", "owner", "case", "business"];
  for (const [patch, expected] of [
    [{}, all],
    [{ scope: "participating" }, all],
    [{ scope: "mine" }, ["none", "due", "case", "business"]],
    [{ source: "standalone" }, ["none", "due", "owner", "business"]],
    [{ source: "case" }, all],
    [{ caseId: "a" }, ["none", "due", "owner"]],
    [{ businessKind: "产品" }, all],
    [{ businessKey: "产品:p1" }, ["none", "due", "owner", "case"]],
    [{ businessKind: "none" }, ["none", "due", "owner"]],
    [{ status: "已完成" }, ["none", "owner", "case", "business"]],
  ]) {
    const filters = filter({ scope: "assigned", status: "进行中", ...patch });
    const candidates = filters.status === "已完成" ? list.map(r => ({ ...r, status: "已完成" })) : list;
    const selection = select(candidates, filters, actor);
    const selectionBefore = JSON.stringify([filters, selection]);
    const options = availableGroups(selection.rows, filters, now);
    assert.deepEqual(plain(options.map(option => option.value)), expected, JSON.stringify(patch));
    for (const { value } of options.filter(option => option.value !== "none")) {
      assert.ok(group(selection.rows, value, now, filters.businessKey).length > 1);
    }
    for (const r of selection.rows) assert.equal(r, candidates.find(item => item.key === r.key));
    assert.equal(JSON.stringify([filters, selection]), selectionBefore);
  }
  assert.equal(JSON.stringify([cases, tasks, list]), before);
});

test("group availability uses the full selection and offers only none for empty or single-group results", () => {
  const now = new Date(2026, 8, 9, 12);
  const list = rows([
    c("a", Array.from({ length: 8 }, (_, i) => action(`same-${i}`, { owner: "李娜", supervisor: actor, urgency: "非常紧急" }))),
    c("b", [action("different", { owner: "王强", supervisor: actor, urgency: "不紧急", dueDate: "2026-09-08" })], { productId: "p2" }),
  ]);
  const filters = filter({ scope: "assigned", status: "待接受" });
  const selection = select(list, filters, actor);
  const firstPage = paginate(group(selection.rows, "none", now), 1).groups.flatMap(g => g.rows);
  assert.equal(firstPage.length, 8); assert.equal(selection.rows.length, 9);
  assert.deepEqual(plain(availableGroups(selection.rows, filters, now).map(option => option.value)), ["none", "due", "owner", "case", "business"]);
  for (const subset of [[], selection.rows.slice(0, 1), firstPage, select(list, { ...filters, caseId: "a" }, actor).rows]) {
    assert.deepEqual(plain(availableGroups(subset, filters, now).map(option => option.value)), ["none"]);
  }
});