import assert from 'node:assert/strict';
import { build } from 'esbuild';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';
const { chromium, expect } = await import(process.env.EA_BROWSER_TOOLS || '@playwright/test');
const {outputFiles}=await build({entryPoints:[fileURLToPath(new URL('../src/app/components/data.ts',import.meta.url))],bundle:true,write:false,platform:'node',format:'cjs'});
const sandbox={module:{exports:{}},btoa,atob};vm.runInNewContext(outputFiles[0].text,sandbox);
const base=JSON.parse(JSON.stringify(sandbox.module.exports.mockCases[0]));
const task={id:'qa-task',code:'QA-TASK.001',title:'V109验收任务',owner:'张伟',supervisor:'李娜',department:'PTE',urgency:'一般',status:'已完成',progress:100,conclusion:'原始任务结论',createdAt:'2026-09-10T08:30:00+08:00'};
const fixture={...base,owner:'张伟',createdBy:'李娜',level:'L3',status:'已关闭',fanoutSourceCaseId:undefined,childCaseIds:[],sourceStandaloneTaskIds:[],tasks:[task]};
const browser=await chromium.launch({headless:true});
try {
  const page=await browser.newPage({viewport:{width:1440,height:1000}});
  const errors=[];page.on('pageerror',error=>errors.push(error.message));
  await page.addInitScript(()=>{localStorage.setItem('ea_onboarding_v0_2','seen');localStorage.setItem('ea_whatsnew_v1_0_2_f','seen');localStorage.setItem('ea_agent_position_v1',JSON.stringify({x:24,y:680}));});
  await page.goto(process.env.EA_PREVIEW_URL||'http://127.0.0.1:5195/');
  await expect(page.getByRole('heading',{name:'我的任务',exact:true})).toBeVisible();
  await page.evaluate(fixture=>{
    const domain=JSON.parse(localStorage.getItem('ea_domain_v6'));
    domain.spawnedCases.push({...fixture,id:'qa-case',code:'QA-CASE',name:'V109验收Case'},{...fixture,id:'qa-reviewed',code:'QA-REVIEWED',name:'V109审批Case',source:'fanout验证',fanoutSourceCaseId:'qa-case',tasks:[]});
    const crossTasks=['已完成','已拒绝','已中止','已完成'].map((status,index)=>({...fixture.tasks[0],id:`qa-cross-${index}`,code:`QA-CROSS.${index}`,title:`跨Case任务${index}`,owner:'李娜',department:'DA',status,createdAt:index===1||index===2?undefined:'2026-09-12T09:00:00+08:00',activityLog:index===1?[{id:'creation-evidence',kind:'create',at:'2026-09-11T11:45:00+08:00',by:'李娜',summary:'创建执行任务',changes:[]}]:[]}));
    domain.spawnedCases.push({...fixture,id:'qa-cross-case',code:'QA-CROSS-CASE',name:'跨Case重开验收',owner:'李娜',status:'进行中',tasks:[{id:'cross-thought',title:'验证方向',owner:'待指派',department:'DA',status:'待接受',urgency:'一般',progress:0,children:crossTasks}]},{...fixture,id:'qa-closed-target',code:'QA-LOCKED-CASE',name:'已结案保护验收',tasks:[{...crossTasks[0],id:'locked-task',code:'QA-LOCKED.001',title:'已结案不可重开任务'}]});
    const ganttTask={...fixture.tasks[0],createdAt:'2026-09-18T08:00:00+08:00',dueDate:'2026-09-20',progress:37,statusHistory:[{status:'进行中',at:'2026-09-19T10:00:00+08:00'},{status:'已完成',at:'2026-09-22T17:00:00+08:00'}]};
    domain.spawnedCases.push({...fixture,id:'qa-gantt-case',code:'QA-GANTT',name:'甘特生命周期验收',status:'进行中',tasks:[{id:'gantt-thought',title:'生命周期验证方向',owner:'待指派',department:'PTE',status:'待接受',urgency:'一般',progress:0,children:[
      {...ganttTask,id:'gantt-done',code:'QA-GANTT.1',title:'完成时间条'},
      {...ganttTask,id:'gantt-late',code:'QA-GANTT.2',title:'超期时间条',status:'进行中'},
      {...ganttTask,id:'gantt-active',code:'QA-GANTT.3',title:'进行中时间条',status:'进行中',dueDate:'2026-09-23T12:00:30+08:00'},
      {...ganttTask,id:'gantt-pending',code:'QA-GANTT.4',title:'待接受时间条',status:'待接受',dueDate:'2026-09-30',statusHistory:[]},
      {...ganttTask,id:'gantt-unknown',code:'QA-GANTT.5',title:'缺失时间',createdAt:undefined,statusHistory:[]},
      {...ganttTask,id:'gantt-stop',code:'QA-GANTT.6',title:'中止时间条',status:'已中止',statusHistory:[...ganttTask.statusHistory,{status:'已中止',at:'2026-09-23T09:00:00+08:00'}]},
    ]}]},{...fixture,id:'qa-gantt-empty',code:'QA-GANTT-EMPTY',name:'甘特仅思路验收',status:'进行中',tasks:[{id:'empty-thought',title:'仅思路',status:'待接受',owner:'待指派',department:'PTE',urgency:'一般',progress:0}]});
    localStorage.setItem('ea_domain_v6',JSON.stringify(domain));
    const examples=Object.fromEntries(Array.from({length:6},(_,index)=>{const id=`vp-recovery-example-${index+1}`;return [id,{caseId:id,state:'closed'}];}));
    localStorage.setItem('ea_case_closures_v4',JSON.stringify({...examples,'qa-case':{caseId:'qa-case',state:'closed',conclusion:'原结案',rootCauseAt:'2026-08-29T10:00:00+08:00',closedAt:'2026-09-01T17:00:00+08:00'},'qa-reviewed':{caseId:'qa-reviewed',state:'closed',conclusion:'原审核结论',closedAt:'2026-09-01',approvedBy:'高总监'},'qa-cross-case':{caseId:'qa-cross-case',state:'rootcause',rootCauseAt:'2026-09-18T10:30:00+08:00'}}));
    localStorage.setItem('ea_standalone_tasks_v1',JSON.stringify([{id:'qa-free',code:'QA-FREE',title:'V109验收自由任务',description:'验收说明',owner:'张伟',createdBy:'李娜',createdForOther:true,collaborators:[],urgency:'一般',dueDate:'2026-10-01',attachments:[],status:'已完成',conclusion:'原自由任务结论',createdAt:'2026-09-01',updatedAt:'2026-09-20'}]));
  },fixture);
  await page.reload();
  const open=async(name,code)=>{await page.getByRole('button',{name:/搜索 Case、任务/}).click();await page.getByRole('checkbox',{name:'查看 Fanout',exact:true}).check();await page.getByPlaceholder('搜索 Case、任务、用户…（多个关键词用空格分隔）').fill(name);await page.getByRole('button').filter({hasText:name}).filter({hasText:code}).click();};
  const action=async(name,label,value)=>{await page.getByRole('button',{name,exact:true}).click();await page.getByRole('textbox',{name:label,exact:true}).fill(value);await page.getByRole('button',{name:'确认提交',exact:true}).click();};
  const actor=async(name)=>{await page.getByRole('button',{name:'演示身份',exact:true}).click();await page.getByRole('dialog',{name:'演示身份',exact:true}).getByRole('combobox',{name:'演示身份',exact:true}).selectOption(name);await page.getByRole('button',{name:'切换并刷新',exact:true}).click();await expect(page.getByRole('heading',{name:'我的任务',exact:true})).toBeVisible();};
  const noOutcome=async()=>{await expect(page.getByRole('button',{name:'填写处理说明',exact:true})).toHaveCount(0);await expect(page.getByRole('textbox',{name:'处理说明',exact:true})).toHaveCount(0);};
  const editTaskDocument=async(conclusion)=>{
    if (!await page.getByText('进入 Workspace 编辑',{exact:true}).count()) {
      console.log(await page.locator('main').innerText());
      console.log(await page.evaluate(()=>({actor:localStorage.getItem('ea_v109_demo_actor'),trees:JSON.parse(localStorage.getItem('ea_case_task_trees_v1')),closures:JSON.parse(localStorage.getItem('ea_case_closures_v4'))})));
      await page.screenshot({path:'/tmp/ea-full-recovery-failure.png'});
    }
    await page.getByText('进入 Workspace 编辑',{exact:true}).click();
    await page.getByPlaceholder('如：Pattern P_ICC2_07 在低压下过激，叠加 wafer 边缘工艺偏移。').fill(conclusion);
    await page.getByPlaceholder('详细记录分析步骤、对照数据、决策依据...').fill('在原任务文档补充对照验证过程');
    await noOutcome();await page.getByRole('button',{name:'保存并回写',exact:true}).click();
  };
  await open('V109验收任务','QA-TASK.001');await expect(page.getByRole('button',{name:'重新处理',exact:true})).toHaveCount(0);
  await action('补充记录','补充说明','不改变原任务结论');await noOutcome();
  await open('V109验收Case','QA-CASE');await expect(page.getByRole('button',{name:'编辑',exact:true})).toBeDisabled();
  const verification=page.getByRole('region',{name:'验证时间',exact:true});await expect(verification).toContainText('2026/08/29');await expect(verification).toContainText('2026/09/01');
  await expect(page.getByRole('button',{name:'重新处理',exact:true})).toHaveCount(0);
  await page.getByRole('button',{name:'补充记录',exact:true}).click();
  await page.getByRole('textbox',{name:'补充说明',exact:true}).fill('Case补充原始复测附件');
  await page.getByRole('dialog',{name:'补充记录',exact:true}).locator('input[type="file"]').first().setInputFiles({name:'case-supplement.txt',mimeType:'text/plain',buffer:Buffer.from('Original Case evidence')});
  await page.getByRole('button',{name:'确认提交',exact:true}).click();
  const caseLog=page.getByRole('region',{name:'Case 流转日志',exact:true});
  const noSeparateCaseHistory=async()=>{await expect(page.getByRole('region',{name:'重新处理与补充记录',exact:true})).toHaveCount(0);await expect(page.getByText(/^重新处理与补充记录 ·/)).toHaveCount(0);};
  await noSeparateCaseHistory();await expect(caseLog).toContainText('Case补充原始复测附件');await expect(caseLog).toContainText('case-supplement.txt');
  await expect(page.getByText('Case补充原始复测附件',{exact:true})).toHaveCount(1);
  await actor('高总监');await open('V109验收Case','QA-CASE');await expect(page.getByRole('button',{name:'重新处理',exact:true})).toHaveCount(0);
  const beforeDraft=await page.evaluate(()=>localStorage.getItem('ea_case_closures_v4'));
  await page.getByRole('button',{name:'退回整改',exact:true}).click();const returnDialog=page.getByRole('dialog',{name:'退回整改',exact:true});
  await expect(returnDialog.getByRole('textbox',{name:'整改要求',exact:true})).toHaveValue(/原结案/);await expect(returnDialog).toContainText('AI 摘要 · 本地模拟');await expect(returnDialog).toContainText('提交退回后 24 小时内');await expect(returnDialog.getByLabel('期望反馈日期',{exact:true})).toHaveCount(0);
  for(const width of [1280,1440]){await page.setViewportSize({width,height:900});const bounds=await returnDialog.boundingBox();assert.ok(bounds.x>=0&&bounds.y>=0&&bounds.x+bounds.width<=width&&bounds.y+bounds.height<=900);await returnDialog.screenshot({path:`/tmp/ea-case-return-draft-${width}.png`});}
  await returnDialog.getByRole('button',{name:'取消',exact:true}).click();assert.equal(await page.evaluate(()=>localStorage.getItem('ea_case_closures_v4')),beforeDraft);
  await actor('周主管');await open('V109验收任务','QA-TASK.001');await expect(page.getByRole('button',{name:'重新处理',exact:true})).toBeDisabled();
  await open('V109验收Case','QA-CASE');await action('重新处理','重新处理原因','已与 Owner 线下沟通，重新核验根因');
  await expect(verification).toContainText('尚未开始');await expect(verification).toContainText('尚未结束');await expect(verification).not.toContainText('2026/08/29');
  await noSeparateCaseHistory();await expect(caseLog).toContainText('已与 Owner 线下沟通，重新核验根因');await expect(caseLog).toContainText('待处理');await noOutcome();
  const caseRows=caseLog.locator('.space-y-4 > div.relative');
  await expect(caseRows.nth(0)).toContainText('已与 Owner 线下沟通，重新核验根因');await expect(caseRows.nth(1)).toContainText('Case补充原始复测附件');
  const beforeViewing=await page.evaluate(()=>localStorage.getItem('ea_case_closures_v4'));
  await caseLog.getByText('查看处理前记录',{exact:true}).click();await expect(caseLog).toContainText('原结论：原结案');await expect(caseLog.getByRole('link',{name:'下载完整原始记录',exact:true})).toHaveAttribute('href',/^data:application\/json/);
  assert.equal(await page.evaluate(()=>localStorage.getItem('ea_case_closures_v4')),beforeViewing);
  await page.reload();await open('V109验收Case','QA-CASE');await noSeparateCaseHistory();await expect(caseLog).toContainText('Case补充原始复测附件');await expect(caseRows.nth(0)).toContainText('已与 Owner 线下沟通，重新核验根因');
  await caseLog.screenshot({path:'/tmp/ea109-case-flow-log-1440.png'});
  await open('V109验收任务','QA-TASK.001');await action('重新处理','重新处理原因','已与工程师线下沟通，补充任务验证');
  await expect(page.getByRole('region',{name:'任务信息'}).getByText('待整改',{exact:true})).toHaveCount(0);
  await actor('张伟');await open('V109验收任务','QA-TASK.001');await noOutcome();await editTaskDocument('主管重开后的原任务文档结论');
  await page.getByRole('button',{name:'完成',exact:true}).click();
  await expect(page.getByRole('region',{name:'任务信息'}).getByText('已完成',{exact:true})).toBeVisible();
  await actor('高总监');await open('V109验收任务','QA-TASK.001');await action('退回整改','整改要求','补齐第二组对照实验');
  await expect(page.getByRole('region',{name:'任务信息'}).getByText('待整改',{exact:true})).toBeVisible();await page.screenshot({path:'/tmp/ea109-task-returned.png'});
  await actor('张伟');await open('V109验收任务','QA-TASK.001');await noOutcome();await editTaskDocument('整改后在原文档中的最终结论');await page.getByRole('button',{name:'完成',exact:true}).click();await expect(page.getByRole('region',{name:'任务信息'}).getByText('待整改',{exact:true})).toHaveCount(0);
  await open('V109审批Case','QA-REVIEWED');await expect(page.getByRole('button',{name:'申请重新处理',exact:true})).toHaveCount(0);await expect(page.getByRole('button',{name:'重新处理',exact:true})).toHaveCount(0);await expect(page.getByRole('button',{name:'编辑',exact:true})).toBeDisabled();
  await actor('周主管');await open('V109审批Case','QA-REVIEWED');await action('重新处理','重新处理原因','已线下沟通，主管同意修订审核依据');
  await expect(page.getByRole('region',{name:'Case 重新处理审批'})).toHaveCount(0);
  await actor('张伟');await open('V109审批Case','QA-REVIEWED');await expect(page.getByRole('button',{name:'编辑',exact:true})).toBeEnabled();await noOutcome();
  await page.getByText('进入 Workspace 编辑',{exact:true}).click();
  await page.getByPlaceholder('如：Pattern P_ICC2_07 在低压下过激，叠加 wafer 边缘工艺偏移。').fill('已重新验证并修正结论');
  await page.getByPlaceholder('点「按结构生成」自动汇总各 sub case 的分析过程，或手动编辑...').fill('在原 Case 文档补充验证依据');
  await page.getByRole('button',{name:'保存并回写',exact:true}).click();
  await page.screenshot({path:'/tmp/ea109-case-reopened.png'});
  await page.getByRole('button',{name:'结案',exact:true}).click();
  await expect(page.getByPlaceholder('简要填写验证结果与结案结论')).toHaveValue('已重新验证并修正结论');
  await page.getByRole('button',{name:'结案',exact:true}).last().click();
  await expect(page.getByRole('region',{name:'Case 重新处理审批'})).toContainText('再次结案申请 · 待确认');
  await expect(page.getByRole('button',{name:'编辑',exact:true})).toBeDisabled();
  await actor('高总监');await open('V109审批Case','QA-REVIEWED');await page.getByRole('button',{name:'通过',exact:true}).click();
  await expect(page.getByRole('button',{name:'已结案',exact:true})).toBeVisible();
  await expect(page.getByRole('region',{name:'当前整改要求',exact:true})).toHaveCount(0);
  await noSeparateCaseHistory();await caseLog.locator('summary').filter({hasText:'已提交整改结果'}).click();
  await expect(caseLog).toContainText('原审核结论');await expect(caseLog).toContainText('已重新验证并修正结论');await expect(caseLog).toContainText('再次完成于');
  await page.setViewportSize({width:1280,height:800});await caseLog.scrollIntoViewIfNeeded();
  assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);
  await caseLog.screenshot({path:'/tmp/ea109-case-flow-log-1280.png'});await page.setViewportSize({width:1440,height:1000});
  await actor('张伟');await open('V109验收自由任务','QA-FREE');await expect(page.getByRole('button',{name:'重新处理',exact:true})).toHaveCount(0);
  await actor('周主管');await open('V109验收自由任务','QA-FREE');await action('重新处理','重新处理原因','已沟通，同意补充自由任务');
  await actor('张伟');await open('V109验收自由任务','QA-FREE');await noOutcome();
  await page.getByRole('button',{name:'进入 Workspace 编辑',exact:true}).click();
  await page.getByLabel('Workspace 任务结论',{exact:true}).fill('原自由任务文档的新结论');
  await page.getByLabel('Workspace 分析过程',{exact:true}).fill('补充固定流程执行记录');
  await page.getByRole('button',{name:'保存并回写',exact:true}).click();await page.getByRole('button',{name:'完成',exact:true}).click();
  await page.reload();await open('V109验收自由任务','QA-FREE');await page.getByRole('button',{name:'查看 Workspace 文档',exact:true}).click();
  await expect(page.getByLabel('Workspace 任务结论',{exact:true})).toHaveValue('原自由任务文档的新结论');
  await expect(page.getByLabel('Workspace 任务结论',{exact:true})).toHaveAttribute('readonly','');
  await page.getByRole('dialog',{name:'Workspace 文档',exact:true}).getByRole('button',{name:'关闭',exact:true}).click();
  await page.setViewportSize({width:1280,height:800});
  assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);
  const saved=await page.evaluate(()=>({closures:JSON.parse(localStorage.getItem('ea_case_closures_v4')),tasks:JSON.parse(localStorage.getItem('ea_case_task_trees_v1')),free:JSON.parse(localStorage.getItem('ea_standalone_tasks_v1')).find(item=>item.id==='qa-free')}));
  assert.equal(saved.closures['qa-reviewed'].state,'closed');assert.equal(saved.closures['qa-reviewed'].workspace.conclusion,'已重新验证并修正结论');assert.equal(saved.closures['qa-reviewed'].conclusion,'已重新验证并修正结论');
  assert.equal(saved.tasks['qa-case'][0].status,'已完成');assert.equal(saved.tasks['qa-case'][0].conclusion,'整改后在原文档中的最终结论');assert.equal(saved.tasks['qa-case'][0].recovery.at(-1).kind,'return');assert.ok(saved.tasks['qa-case'][0].recovery.at(-1).completedAt);
  for(const record of [saved.closures['qa-reviewed'],saved.tasks['qa-case'][0],saved.free])for(const entry of record.recovery.filter(item=>item.kind!=='supplement')){assert.equal(entry.outcome,undefined);assert.ok(entry.completedAt);}
  assert.equal(saved.free.conclusion,'原自由任务文档的新结论');assert.equal(saved.free.recovery[0].by,'周主管');assert.equal(saved.free.recovery[0].before.conclusion,'原自由任务结论');
  await open('跨Case任务0','QA-CROSS.0');await expect(page.getByRole('button',{name:'重新处理',exact:true})).toHaveCount(0);
  await open('跨Case重开验收','QA-CROSS-CASE');await expect(verification).toContainText('2026/09/18');await expect(verification).toContainText('尚未结束');
  for(const width of [1280,1440]){
    await page.setViewportSize({width,height:900});
    const timeGroup=page.getByRole('region',{name:'Case 时间信息',exact:true});await expect(timeGroup.getByRole('region',{name:'验证时间',exact:true})).toBeVisible();
    const updated=await timeGroup.locator('[data-case-updated-at]').boundingBox();const verify=await verification.boundingBox();
    assert.ok(verify.y>=updated.y+updated.height);assert.ok(verify.y-updated.y-updated.height<=9);assert.ok(Math.abs(verify.x-updated.x)<1);assert.ok(Math.abs(verify.width-updated.width)<1);
    await expect(verification).toHaveCSS('border-top-width','0px');await timeGroup.screenshot({path:`/tmp/ea-case-time-group-${width}.png`});
  }
  await page.getByRole('button',{name:'任务视图',exact:true}).click();
  for(const width of [1280,1440]){
    await page.setViewportSize({width,height:900});
    const dateCell=page.locator('[data-task-row="qa-cross-0"] [data-task-created-at]');await expect(dateCell).toContainText('2026/09/12');await expect(page.locator('[data-task-row="qa-cross-1"] [data-task-created-at]')).toContainText('2026/09/11');await expect(page.locator('[data-task-row="qa-cross-2"] [data-task-created-at]')).toHaveText('未记录');
    const columns=await page.locator('[data-task-row="qa-cross-0"]').evaluate(element=>Array.from(element.children).map(child=>child.getBoundingClientRect().toJSON()));assert.equal(columns.length,7);assert.ok(columns[3].x>=columns[2].right);assert.equal(columns[3].y+columns[3].height/2,columns[2].y+columns[2].height/2);assert.ok(columns.every(column=>column.right<=width));
    assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);await page.locator('[data-task-row="qa-cross-0"]').screenshot({path:`/tmp/ea-task-creation-${width}.png`});
  }
  const returnReason='Case流转日志中的再次整改要求\n'+('请补齐根因验证、批次对照及结果依据。'.repeat(12))+'\n<img src=x onerror=alert(1)>';
  await actor('高总监');await open('跨Case重开验收','QA-CROSS-CASE');await expect(page.getByRole('button',{name:'退回整改',exact:true})).toHaveCount(0);
  await open('V109验收Case','QA-CASE');await expect(page.getByRole('button',{name:'退回整改',exact:true})).toHaveCount(0);
  await open('V109审批Case','QA-REVIEWED');await page.getByRole('button',{name:'退回整改',exact:true}).click();await expect(page.getByRole('textbox',{name:'整改要求',exact:true})).toHaveValue(/已重新验证并修正结论/);await page.getByRole('textbox',{name:'整改要求',exact:true}).fill(returnReason);await expect(page.getByLabel('期望反馈日期',{exact:true})).toHaveCount(0);await page.getByRole('button',{name:'确认提交',exact:true}).click();
  const submittedReturn=await page.evaluate(()=>JSON.parse(localStorage.getItem('ea_case_closures_v4'))['qa-reviewed'].recovery.at(-1));assert.equal(Date.parse(submittedReturn.dueDate)-Date.parse(submittedReturn.at),86400000);assert.equal(submittedReturn.reason,returnReason);
  await noSeparateCaseHistory();await expect(caseRows.nth(0)).toContainText('退回整改');await expect(caseRows.nth(0)).toContainText('Case流转日志中的再次整改要求');
  const requirement=page.getByRole('region',{name:'当前整改要求',exact:true});await expect(requirement).toContainText(returnReason);await expect(requirement).toContainText('高总监');await expect(requirement).toContainText('整改截止：');await expect(requirement).not.toContainText(submittedReturn.dueDate);await expect(requirement.locator('img')).toHaveCount(0);await expect(page.getByRole('button',{name:'退回整改',exact:true})).toHaveCount(0);
  for(const width of [1280,1440]){
    await page.setViewportSize({width,height:900});await page.locator('main').evaluate(element=>element.scrollTop=0);
    const title=await page.getByRole('heading',{name:'V109审批Case',exact:true,level:1}).boundingBox();const reasonBounds=await requirement.boundingBox();
    assert.ok(reasonBounds.y>=title.y+title.height);assert.ok(reasonBounds.y-title.y-title.height<28);assert.ok(reasonBounds.x+reasonBounds.width<=width);
    assert.equal(await requirement.evaluate(element=>element.scrollWidth>element.clientWidth),false);await page.screenshot({path:`/tmp/ea-case-return-title-${width}.png`});
  }
  await actor('张伟');await open('V109审批Case','QA-REVIEWED');await expect(requirement).toContainText(returnReason);
  for(const index of [0,1,2]){
    await open('跨Case重开验收','QA-CROSS-CASE');await page.getByRole('button',{name:'任务视图',exact:true}).click();await page.locator(`[data-task-row="qa-cross-${index}"]`).getByRole('button',{name:new RegExp(`跨Case任务${index}$`)}).click();
    await expect(page.getByRole('region',{name:'任务信息',exact:true}).getByRole('button',{name:'重新处理',exact:true})).toBeEnabled();await action('重新处理','重新处理原因','跨Case补充验证');await expect(page.getByRole('region',{name:'任务信息',exact:true})).toContainText('进行中');await expect(page.getByText('进入 Workspace 编辑',{exact:true})).toHaveCount(0);
  }
  await page.reload();await open('跨Case任务0','QA-CROSS.0');await expect(page.getByRole('region',{name:'任务信息',exact:true})).toContainText('进行中');
  const reopenedTasks=await page.evaluate(()=>JSON.parse(localStorage.getItem('ea_case_task_trees_v1'))['qa-cross-case'][0].children);
  for(const index of [0,1,2]){assert.equal(reopenedTasks[index].owner,'李娜');assert.equal(reopenedTasks[index].conclusion,'原始任务结论');assert.equal(reopenedTasks[index].recovery.at(-1).authorizedByCaseReturn.caseId,'qa-reviewed');}assert.equal(reopenedTasks[3].status,'已完成');assert.equal(reopenedTasks[0].createdAt,'2026-09-12T09:00:00+08:00');
  await open('已结案不可重开任务','QA-LOCKED.001');await expect(page.getByRole('button',{name:'重新处理',exact:true})).toHaveCount(0);
  await open('V109审批Case','QA-REVIEWED');
  await page.getByRole('button',{name:'结案',exact:true}).click();await page.getByRole('button',{name:'结案',exact:true}).last().click();await expect(requirement).toBeVisible();
  await expect(verification).toContainText('尚未结束');await open('跨Case任务3','QA-CROSS.3');await expect(page.getByRole('button',{name:'重新处理',exact:true})).toHaveCount(0);
  await actor('高总监');await open('V109审批Case','QA-REVIEWED');await page.getByRole('button',{name:'通过',exact:true}).click();await expect(requirement).toHaveCount(0);await expect(caseLog).toContainText('Case流转日志中的再次整改要求');
  await expect(verification).not.toContainText('尚未结束');await actor('张伟');await open('跨Case任务3','QA-CROSS.3');await expect(page.getByRole('button',{name:'重新处理',exact:true})).toHaveCount(0);
  await actor('李娜');await open('跨Case重开验收','QA-CROSS-CASE');await page.getByRole('button',{name:'任务视图',exact:true}).click();await page.getByRole('button',{name:'新增任务',exact:true}).click();await page.getByLabel(/任务名称/).fill('新任务创建时间即时验收');await page.getByRole('button',{name:'保存任务',exact:true}).click();
  const createdRow=page.locator('[data-task-row]').filter({hasText:'新任务创建时间即时验收'});await expect(createdRow.locator('[data-task-created-at]')).not.toHaveText('未记录');const createdAt=await createdRow.locator('[data-task-created-at]').getAttribute('title');assert.ok(Number.isFinite(Date.parse(createdAt)));
  await createdRow.scrollIntoViewIfNeeded();await page.screenshot({path:'/tmp/ea-case-task-view-created.png'});
  await page.reload();await open('跨Case重开验收','QA-CROSS-CASE');await page.getByRole('button',{name:'任务视图',exact:true}).click();await expect(createdRow.locator('[data-task-created-at]')).toHaveAttribute('title',createdAt);await page.locator('main').evaluate(element=>element.scrollTop=0);await page.screenshot({path:'/tmp/ea-case-verification-sidebar.png'});
  await page.clock.install({time:new Date('2026-09-23T12:00:00+08:00')});
  await open('甘特生命周期验收','QA-GANTT');await page.getByRole('button',{name:'甘特图',exact:true}).click();
  const gantt=page.getByRole('region',{name:'甘特生命周期验收任务甘特图',exact:true});
  const bar=id=>gantt.locator(`[data-gantt-bar="gantt-${id}"]`);
  await expect(bar('done')).toHaveAttribute('data-gantt-state','completed');await expect(bar('done')).toHaveClass(/bg-emerald-500/);await expect(bar('done')).toHaveAttribute('data-start','2026-09-18T08:00:00+08:00');await expect(bar('done')).toHaveAttribute('data-end','2026-09-22T17:00:00+08:00');
  await expect(bar('late')).toHaveAttribute('data-gantt-state','overdue');await expect(bar('late')).toHaveClass(/bg-red-500/);await expect(bar('late').locator('[data-gantt-milestone="completed"]')).toHaveCount(0);
  await expect(bar('active')).toHaveAttribute('data-gantt-state','active');await expect(bar('active')).toHaveClass(/bg-blue-500/);const elapsed=await page.evaluate(()=>Date.now())-Date.parse(await bar('active').getAttribute('data-end'));assert.ok(elapsed>=0&&elapsed<60000);
  await expect(bar('pending')).toHaveAttribute('data-gantt-state','inactive');await expect(bar('pending').locator('[data-gantt-milestone="accepted"]')).toHaveCount(0);await expect(bar('unknown')).toHaveCount(0);await expect(gantt.locator('[data-gantt-row="gantt-unknown"]')).toContainText('时间未记录');await expect(bar('stop')).toHaveAttribute('data-gantt-state','inactive');
  await expect(bar('done').locator('[data-gantt-milestone]')).toHaveCount(3);await expect(bar('done').locator('[data-gantt-milestone="accepted"]')).toHaveAttribute('data-at','2026-09-19T10:00:00+08:00');
  await expect(gantt).not.toContainText(/\d+%|含估算|NaN|Invalid Date/);assert.ok((await gantt.locator('[data-gantt-bar]').evaluateAll(elements=>elements.map(element=>element.title))).every(title=>!title.includes('%')));
  const beforeGantt=await page.evaluate(()=>localStorage.getItem('ea_case_task_trees_v1'));
  for(const width of [1280,1440]){
    await page.setViewportSize({width,height:900});await gantt.scrollIntoViewIfNeeded();await expect(gantt.getByRole('button',{name:'日',exact:true})).toHaveAttribute('aria-pressed','true');const dayBar=await bar('done').boundingBox();const milestone=await bar('done').locator('[data-gantt-milestone="accepted"]').boundingBox();assert.ok(milestone.x>dayBar.x&&milestone.x<dayBar.x+dayBar.width);
    assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);await gantt.screenshot({path:`/tmp/ea-gantt-lifecycle-${width}.png`});
    await gantt.getByRole('button',{name:'周',exact:true}).click();await expect(gantt.getByRole('button',{name:'周',exact:true})).toHaveAttribute('aria-pressed','true');assert.ok((await bar('done').boundingBox()).width<dayBar.width);await gantt.getByRole('button',{name:'日',exact:true}).click();
  }
  await page.clock.fastForward(61000);await expect(bar('active')).toHaveAttribute('data-gantt-state','overdue');await expect(bar('done')).toHaveAttribute('data-gantt-state','completed');assert.equal(await page.evaluate(()=>localStorage.getItem('ea_case_task_trees_v1')),beforeGantt);
  await bar('done').click();await expect(page.getByRole('region',{name:'任务信息',exact:true})).toContainText('完成时间条');
  await open('甘特仅思路验收','QA-GANTT-EMPTY');await page.getByRole('button',{name:'甘特图',exact:true}).click();const thoughtGantt=page.getByRole('region',{name:'甘特仅思路验收任务甘特图',exact:true});await expect(thoughtGantt).toContainText('仅思路');await expect(thoughtGantt).not.toContainText(/NaN|Invalid Date/);await expect(thoughtGantt.locator('[data-gantt-bar]')).toHaveCount(0);
  assert.deepEqual(errors,[]);
  console.log('PASS: Gantt lifecycle endpoints/acceptance markers, green/red/blue states, no percentages, live overdue refresh, day/week navigation and missing-date handling at 1280/1440; Case return, timing and recovery workflows preserved.');
} finally {await browser.close();}