import test from "node:test";
import assert from "node:assert/strict";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";
import vm from "node:vm";
import { build } from "esbuild";
import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";

const require = createRequire(import.meta.url);
const { outputFiles } = await build({
  entryPoints: [fileURLToPath(new URL("../src/app/components/CreationCollaboratorInput.tsx", import.meta.url))],
  bundle: true, write: false, platform: "node", format: "cjs", jsx: "automatic",
  external: ["react", "react/jsx-runtime", "lucide-react", "./data"],
});
const sandbox = {
  module: { exports: {} },
  require: (name) => name === "./data" ? { ownerToDepartment: { 李娜: "PTE", 王磊: "QA" } } : require(name),
};
vm.runInNewContext(outputFiles[0].text, sandbox);
const { CreationCollaboratorInput } = sandbox.module.exports;
const render = (value) => renderToStaticMarkup(createElement(CreationCollaboratorInput, { value, onChange() {} }));

test("creation collaborator selector uses the Case input style without empty selection decoration", () => {
  const html = render([]);
  assert.match(html, /aria-label="协作者选择"/);
  assert.match(html, /placeholder="添加协作者（可选）"/);
  assert.match(html, /h-9/);
  assert.doesNotMatch(html, /参与人|已选|移除|h-10/);
});

test("Case and task collaborator models render identical counts, avatar stacks and department tooltips", () => {
  const names = [{ name: "李娜" }, { name: "王磊" }];
  const copy = JSON.stringify(names);
  const html = render(names);
  assert.equal(html, render([{ name: "李娜", department: "PTE" }, { name: "王磊", department: "QA" }]));
  assert.match(html, /已选 2 人/);
  assert.match(html, /-space-x-1\.5/);
  assert.match(html, /title="李娜 · PTE"/);
  assert.match(html, /title="王磊 · QA"/);
  assert.equal((html.match(/w-6 h-6 rounded-full/g) ?? []).length, 2);
  assert.match(render([{ name: "外部协作者", department: "保留的部门" }]), /title="外部协作者 · 保留的部门"/);
  assert.equal(JSON.stringify(names), copy);
});

test("task opt-in keeps committed names inside the input without external avatars or counts", () => {
  const value = [{ name: "李娜" }, { name: "王磊" }];
  const html = renderToStaticMarkup(createElement(CreationCollaboratorInput, { value, selectedInside: true, onChange() {} }));
  assert.match(html, /value="李娜、王磊"/);
  assert.match(html, /title="李娜、王磊"/);
  assert.doesNotMatch(html, /已选|w-6 h-6 rounded-full|-space-x-1\.5/);
  assert.equal((html.match(/<input /g) ?? []).length, 1);
  assert.match(render(value), /已选 2 人/);
});

test("inline selection excludes the owner without changing the stored collaborator draft", () => {
  const value = [{ name: "李娜" }, { name: "王磊" }];
  const before = JSON.stringify(value);
  const html = renderToStaticMarkup(createElement(CreationCollaboratorInput, { value, exclude: ["李娜"], selectedInside: true, onChange() {} }));
  assert.match(html, /value="王磊"/);
  assert.doesNotMatch(html, /李娜/);
  assert.equal(JSON.stringify(value), before);
});