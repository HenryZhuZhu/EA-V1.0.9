import test from "node:test";
import assert from "node:assert/strict";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";
import vm from "node:vm";
import { build } from "esbuild";
import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";

const require = createRequire(import.meta.url);
const { outputFiles } = await build({
  entryPoints: [fileURLToPath(new URL("../src/app/components/WorkbenchTaskCard.tsx", import.meta.url))],
  bundle: true, write: false, platform: "node", format: "cjs", jsx: "automatic",
  external: ["react", "react/jsx-runtime", "lucide-react", "./data"],
});
const sandbox = {
  module: { exports: {} },
  require: name => name === "./data" ? {
    currentUser: { name: "张伟" }, ownerToDepartment: { 张伟: "PTE", 刘洋: "PTE", 李娜: "DA" },
    reportsTo: name => name === "张伟" ? "刘洋" : null,
    levelColors: { L1: "level-l1" }, urgencyBar: { 紧急: "bg-orange-400" },
  } : require(name),
};
vm.runInNewContext(outputFiles[0].text, sandbox);
const { WorkbenchTaskCard } = sandbox.module.exports;
const row = {
  key: "standalone:t", id: "t", source: "standalone", code: "TASK-001", title: "任务名称",
  description: "完整任务说明", owner: "张伟", creator: "刘洋", participants: [], status: "待接受",
  urgency: "紧急", dueDate: "2026-09-12", updatedAt: "2026-09-09T08:00:00Z", caseClosed: false,
  business: [], attachmentCount: 2, hasVoice: true, record: {},
};
const render = (patch = {}) => renderToStaticMarkup(createElement(WorkbenchTaskCard, {
  row: { ...row, ...patch }, businessKey: "", onShowTask() {}, onOpenCase() {}, onTakeAction() {}, onReject() {},
}));

test("pending cards restore V1.0.7 dispatch bubble and real owner actions", () => {
  const html = render();
  assert.match(html, /rounded-tl-\[3px\]/);
  assert.match(html, /bg-\[#f7f9fc\]/);
  assert.match(html, /@你/);
  assert.match(html, /你的主管/);
  assert.match(html, />接受并开始<|>接受并开始<\/button>/);
  assert.match(html, />拒绝<\/button>/);
  assert.match(html, /title="2 个附件"/);
  assert.match(html, /aria-label="有语音备注"/);
  assert.match(html, /TASK-001/);
  assert.match(html, /完整任务说明/);
});

test("active and finished rows open task details without trailing task action buttons", () => {
  const active = render({ status: "进行中" });
  assert.match(active, /col-span-2/);
  assert.doesNotMatch(active, /rounded-tl/);
  assert.doesNotMatch(active, /完成任务|处理任务/);
  assert.match(active, /aria-label="查看任务 任务名称"/);
  assert.match(active, /title="紧急程度：紧急"/);
  assert.doesNotMatch(render({ status: "进行中", source: "case" }), /处理任务|完成任务/);
  for (const patch of [{ status: "已完成" }, { status: "已拒绝" }, { status: "进行中", caseClosed: true }, { status: "进行中", owner: "李娜" }, { convertedCaseId: "up" }]) {
    const html = render(patch);
    assert.doesNotMatch(html, />接受并开始<|>拒绝<\/button>|>完成任务<|>处理任务</);
    if (patch.owner !== "李娜") assert.doesNotMatch(html, /title="紧急程度：紧急"/);
  }
});

test("dispatch copy does not address me or invent a sender in other scopes", () => {
  const assigned = render({ owner: "李娜", creator: "张伟" });
  assert.match(assigned, /@李娜/);
  assert.doesNotMatch(assigned, /@你|请处理这个任务|>接受并开始</);
  const unknown = render({ creator: "", caseItem: { id: "c", name: "关联问题", owner: "刘洋", level: "L1" } });
  assert.doesNotMatch(unknown, /Case Owner|你的主管/);
  assert.match(unknown, /aria-label="查看关联 Case 关联问题"/);
  assert.match(unknown, /aria-label="查看任务 任务名称"/);
});