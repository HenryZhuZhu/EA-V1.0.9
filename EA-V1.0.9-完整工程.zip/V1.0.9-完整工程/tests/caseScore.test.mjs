import test from 'node:test';
import assert from 'node:assert/strict';
import { build } from 'esbuild';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const { outputFiles } = await build({ entryPoints: [fileURLToPath(new URL('../src/app/components/caseScoreModel.ts', import.meta.url))], bundle: true, write: false, format: 'cjs', platform: 'node' });
const sandbox = { module: { exports: {} }, btoa, atob };
vm.runInNewContext(outputFiles[0].text, sandbox);
const { calculateCaseScore } = sandbox.module.exports;
const record = { id: 'score-case', reason: '事由', background: '背景', impact: '影响', caseAttachments: [{ name: 'Case证据' }], aiSummary: { conclusion: '结论' }, tasks: [] };
const task = { id: 'task', code: 'TASK.001', owner: '张伟', status: '已完成', analysisProcess: '过程', conclusion: '结论', attachments: [{ name: '任务证据' }] };

test('six dimensions have explicit weights, deterministic scores and no source writes', () => {
  const source = structuredClone(record);
  const snapshot = JSON.stringify(source);
  const result = calculateCaseScore(source, [task], { workspace: { process: 'Case过程', conclusion: '已验证', attachments: [] } });
  assert.equal(result.dimensions.length, 6);
  assert.equal(result.dimensions.reduce((sum, dimension) => sum + dimension.weight, 0), 100);
  assert.equal(result.total, 100);
  assert.equal(JSON.stringify(source), snapshot);
  assert.equal(JSON.stringify(result), JSON.stringify(calculateCaseScore(source, [task], { workspace: { process: 'Case过程', conclusion: '已验证' } })));
});

test('missing data and placeholder fields earn no fabricated credit', () => {
  const result = calculateCaseScore({ tasks: [], reason: '—', background: ' ', impact: '待补充' });
  assert.equal(result.total, 0);
  assert.ok(result.dimensions.every(dimension => dimension.value === 0));
  assert.match(result.dimensions[4].basis, /暂无有效执行任务/);
});

test('current nested tasks override stale originals and excluded tasks do not inflate denominators', () => {
  const source = { ...record, tasks: [task] };
  const nested = [{ id: 'thought', children: [{ ...task, status: '进行中', owner: '待指派', conclusion: '' }, { ...task, id: 'rejected', status: '已拒绝' }, { ...task, id: 'stopped', status: '已中止' }] }];
  const result = calculateCaseScore(source, nested, { workspace: { conclusion: '', process: '', attachments: [] } });
  assert.equal(result.dimensions[3].value, 0);
  assert.equal(result.dimensions[4].value, 0);
  assert.equal(result.dimensions[5].value, 0);
  assert.match(result.dimensions[1].basis, /1\/2/);
  assert.notEqual(result.total, calculateCaseScore(source).total);
});

test('weighting remains bounded and Skill or EFA evidence uses explicit records', () => {
  const result = calculateCaseScore(record, [{ ...task, attachments: [], efaTicket: { attachments: [{ name: 'EFA证据' }] }, assigneeType: 'skill', skillId: 'skill-1', owner: '系统' }]);
  assert.equal(result.dimensions[2].value, 100);
  assert.equal(result.dimensions[5].value, 100);
  assert.equal(result.total, Math.round(result.dimensions.reduce((sum, dimension) => sum + dimension.value * dimension.weight / 100, 0)));
  assert.ok(result.total >= 0 && result.total <= 100);
});