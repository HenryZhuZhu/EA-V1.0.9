import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";
import vm from "node:vm";
import { build } from "esbuild";
import { renderToStaticMarkup } from "react-dom/server";

const require = createRequire(import.meta.url);
const React = require("react");
const jsxRuntime = require("react/jsx-runtime");
const Dialog = require("@radix-ui/react-dialog");
const Popover = require("@radix-ui/react-popover");
const { Settings2 } = require("lucide-react");
const directory = new URL("../src/app/components/", import.meta.url);
const source = name => readFileSync(new URL(name, directory), "utf8");
const appSource = source("../App.tsx");
const pageSource = source("EaAgentPage.tsx");
const hookSource = source("useAgentConversation.ts");
const floatingSource = source("EaAgent.tsx");
const dailySource = source("DailyReportSkill.tsx");
const css = source("eaAgent.css");
const capturedSources = {
  App: appSource,
  useAgentConversation: hookSource, EaAgentPage: pageSource, EaAgent: floatingSource,
  AiAssistant: source("AiAssistant.tsx"), SkillCenter: source("SkillCenter.tsx"),
  AgentSessionControls: source("AgentSessionControls.tsx"),
  SkillWorkspace: source("SkillCenter.tsx"), AgentSkillPicker: source("AgentSkillPicker.tsx"),
};
function functionSource(body, name) {
  const start = new RegExp(`^(?:export (?:default )?)?function ${name}\\(`, "m").exec(body);
  assert.ok(start, `Missing function ${name}`);
  const rest = body.slice(start.index + start[0].length);
  const end = /^(?:export (?:default )?)?function \w+\(/m.exec(rest);
  return start[0] + (end ? rest.slice(0, end.index) : rest);
}
const slots = Object.fromEntries(Object.entries(capturedSources).map(([name, body]) => {
  const part = functionSource(body, name);
  return [name, {
    states: [...part.matchAll(/^\s*const\s+\[\s*(\w+)[^\]\n]*\]\s*=\s*useState\b/gm)].map(match => match[1]),
    refs: [...part.matchAll(/^\s*const\s+(\w+)\s*=\s*useRef\b/gm)].map(match => match[1]),
  }];
}));
const { outputFiles } = await build({
  stdin: {
    contents: `export { default as App } from '../App'; export { EaAgentPage } from './EaAgentPage';
      export { EaAgent } from './EaAgent'; export { AiAssistant } from './AiAssistant';
      export { SkillCenter } from './SkillCenter'; export { DailyReportSkill } from './DailyReportSkill';
      export { AgentSkillPicker } from './AgentSkillPicker';
      export { agentSessionTimeGroup } from './AgentSessionControls';
      export { useAgentConversation } from './useAgentConversation'; export * from './eaAgentModel';`,
    resolveDir: fileURLToPath(directory), loader: "ts",
  },
  bundle: true, write: false, platform: "node", format: "cjs", jsx: "automatic",
  keepNames: true, packages: "external", external: ["./skills", "./data"], loader: { ".css": "empty" },
  plugins: [{ name: "app-shell-boundaries", setup(bundler) {
    bundler.onResolve({ filter: /^\.\/components\// }, args => {
      if (!args.importer.endsWith("/App.tsx")) return;
      const name = args.path.slice("./components/".length);
      if (["EaAgentPage", "EaAgent", "SkillCenter"].includes(name)) return;
      return { path: `app-boundary:${name}`, external: true };
    });
  } }],
});
const plain = value => JSON.parse(JSON.stringify(value));
const skill = (id, name, category, installs, rating, extra = {}) => Object.freeze({
  id, name, category, installs, rating, author: "测试作者", description: "原始技能说明",
  status: "已发布", updatedAt: "2026-09-10", ...extra, tags: Object.freeze(extra.tags ?? []),
});
// Intentionally unsorted, including an unpublished highest-ranked record.
const skills = Object.freeze([
  skill("analysis-low", "低频分析", "失效分析", 10, 5, { tags: ["NeedleTag"] }),
  skill("draft", "未发布草稿", "失效分析", 999, 5, { status: "草稿" }),
  skill("analysis-tie", "同量低评分", "失效分析", 20, 3),
  skill("sk-003", "日报管理", "报告生成", 30, 5),
  skill("analysis-top", "Bitmap 高评分", "失效分析", 20, 5, { author: "ALICE", description: "Corner 风险核对" }),
]);
const categories = JSON.parse(/export const SKILL_CATEGORIES = (\[[^\]]+\])/.exec(source("skills.ts"))[1]);
function elements(tree) {
  if (Array.isArray(tree)) return Array.from(tree).flatMap(elements);
  return React.isValidElement(tree) ? [tree, ...elements(tree.props.children), ...elements(tree.props.composerTools)] : [];
}
function text(tree) {
  if (Array.isArray(tree)) return Array.from(tree).map(text).join("");
  if (React.isValidElement(tree)) return text(tree.props.children);
  return typeof tree === "string" || typeof tree === "number" ? String(tree) : "";
}
function one(tree, predicate, label) {
  const matches = elements(tree).filter(predicate);
  assert.equal(matches.length, 1, `Expected exactly one ${label}`);
  return matches[0];
}
const byAria = (tree, label) => one(tree, node => node.props["aria-label"] === label, label);
const button = (tree, label) => one(tree, node => node.type === "button" && text(node) === label, label);
const original = node => node.type?.original ?? node.type;
const cards = tree => elements(tree).filter(node => node.type === "article" && node.props.role === "button");
const cardIds = tree => cards(tree).map(node => node.key);

function harness({ mode = "page", embedded, storage = new Map(), failStorage = false, deferReplies = false } = {}) {
  let activeFrame; let api; let conversation; let snapshots; let seen; let html; let popupHtml;
  let pendingEffects = [];
  const timers = new Map();
  let timerId = 0;
  const cleanups = [];
  const runTimers = () => { for (const [id, callback] of [...timers]) { timers.delete(id); callback(); } };
  const routed = mode === "page" || mode === "floating";
  const frames = new Map(); const wrappers = new WeakMap();
  const updates = []; const forbiddenCalls = []; const storageReads = [];
  const forbidden = name => (...args) => { forbiddenCalls.push([name, ...args]); throw new Error(`Forbidden: ${name}`); };
  function capture(name, run) {
    if (!frames.has(name)) frames.set(name, { name, states: new Map(), refs: new Map(), effects: [] });
    const frame = frames.get(name); frame.stateCursor = 0; frame.refCursor = 0; frame.effectCursor = 0;
    const previous = activeFrame; activeFrame = frame;
    let result;
    try { result = run(); } finally { activeFrame = previous; }
    assert.equal(frame.stateCursor, slots[name].states.length, `${name}: update bounded state slots`);
    assert.equal(frame.refCursor, slots[name].refs.length, `${name}: update bounded ref slots`);
    seen.add(name);
    return result;
  }
  function wrap(Type) {
    // Preserve the real specialized element/props, but do not execute its
    // generation, timers, HEMS or persistence. Keep its parent/header in SSR.
    if (Type === api?.DailyReportSkill) {
      if (!wrappers.has(Type)) {
        function DailyBoundary() { return null; }
        DailyBoundary.original = Type;
        wrappers.set(Type, DailyBoundary);
      }
      return wrappers.get(Type);
    }
    if (!Object.hasOwn(capturedSources, Type?.name)) return Type;
    if (!wrappers.has(Type)) {
      function CaptureBoundary(props) {
        const tree = capture(Type.name, () => Type(props));
        assert.ok(!snapshots.has(Type.name), `Harness supports one mounted ${Type.name}`);
        snapshots.set(Type.name, { tree, props });
        return tree;
      }
      CaptureBoundary.original = Type;
      wrappers.set(Type, CaptureBoundary);
    }
    return wrappers.get(Type);
  }
  const controlledReact = {
    ...React,
    useEffect(callback, dependencies) {
      React.useEffect(callback, dependencies);
      assert.ok(activeFrame);
      const frame = activeFrame; const index = frame.effectCursor++;
      const previous = frame.effects[index];
      if (!previous || !dependencies || dependencies.some((value, i) => !Object.is(value, previous[i])) || dependencies.length !== previous.length) {
        pendingEffects.push({ owner: frame.name, callback });
      }
      frame.effects[index] = dependencies;
    },
    useState(initial) {
      assert.ok(activeFrame, "Application state must be captured inside React SSR");
      const frame = activeFrame; const name = slots[frame.name].states[frame.stateCursor++];
      assert.ok(name, `Unexpected state in ${frame.name}`);
      if (!frame.states.has(name)) frame.states.set(name, typeof initial === "function" ? initial() : initial);
      return [frame.states.get(name), next => {
        const before = frame.states.get(name);
        const value = typeof next === "function" ? next(before) : next;
        frame.states.set(name, value);
        updates.push({ owner: frame.name, name, before, value, functional: typeof next === "function" });
      }];
    },
    useRef(initial) {
      // SSR roots remount between explicit callback steps; retain each real ref
      // so message IDs, composition and focus refs model a still-mounted owner.
      const ref = React.useRef(initial);
      assert.ok(activeFrame);
      const name = slots[activeFrame.name].refs[activeFrame.refCursor++];
      assert.ok(name, `Unexpected ref in ${activeFrame.name}`);
      if (!activeFrame.refs.has(name)) activeFrame.refs.set(name, ref);
      return activeFrame.refs.get(name);
    },
  };
  const stubs = {
    react: controlledReact,
    "react/jsx-runtime": {
      ...jsxRuntime,
      jsx: (Type, props, key) => jsxRuntime.jsx(wrap(Type), props, key),
      jsxs: (Type, props, key) => jsxRuntime.jsxs(wrap(Type), props, key),
    },
    "./skills": { SKILL_CATEGORIES: categories, useSkills: () => ({ skills, upsert: forbidden("upsertSkill"), remove: forbidden("removeSkill") }) },
    "./data": { currentUser: { name: "张伟", department: "PTE" }, departments: ["PTE", "EFA"] },
  };
  // Execute App unchanged; isolate only unrelated application leaves/stores.
  // All navigation handlers, route conditions and breadcrumb props come from App.
  for (const [, imports, name] of appSource.matchAll(/import \{([^}]+)\} from "\.\/components\/([^"]+)"/g)) {
    stubs[`app-boundary:${name}`] = Object.fromEntries(imports.split(",").map(value => {
      const symbol = value.trim();
      return [symbol, props => { snapshots.set(symbol, { props }); return null; }];
    }));
  }
  stubs["app-boundary:data"] = { ...stubs["./data"], currentUser: { ...stubs["./data"].currentUser, accountId: "test" }, mockCases: [] };
  stubs["app-boundary:standaloneTasks"] = { standaloneTaskById: forbidden("standaloneTaskById") };
  stubs["app-boundary:Onboarding"].ONBOARDING_KEY = "test-onboarding";
  stubs["app-boundary:WhatsNew"].WHATSNEW_KEY = "test-whats-new";
  stubs["app-boundary:useAgentConversation"] = { useAgentConversation() {
    conversation = capture("useAgentConversation", () => api.useAgentConversation());
    return conversation;
  } };
  const sandbox = {
    module: { exports: {} },
    Blob,
    setTimeout(callback, delay) { assert.equal(delay, 1600); const id = ++timerId; timers.set(id, callback); return id; },
    clearTimeout(id) { timers.delete(id); },
    require(name) {
      if (Object.hasOwn(stubs, name)) return stubs[name];
      assert.ok(["react/jsx-runtime", "lucide-react", "@radix-ui/react-dialog", "@radix-ui/react-popover"].includes(name), `Unexpected dependency ${name}`);
      return require(name);
    },
    window: { innerWidth: 1440, innerHeight: 1000 },
    localStorage: {
      getItem(key) { storageReads.push(key); return ["test-onboarding", "test-whats-new"].includes(key) ? "seen" : storage.get(key) ?? null; },
      setItem(key, value) { assert.equal(key, "ea_agent_sessions_v1"); if (failStorage) throw new Error("quota"); storage.set(key, value); }, removeItem: forbidden("localStorage.removeItem"), clear: forbidden("localStorage.clear"),
    },
    fetch: forbidden("fetch"), XMLHttpRequest: forbidden("XMLHttpRequest"), WebSocket: forbidden("WebSocket"),
  };
  Object.defineProperty(sandbox, "sessionStorage", { get: forbidden("sessionStorage") });
  vm.runInNewContext(outputFiles[0].text, sandbox);
  api = sandbox.module.exports;
  function Owner() {
    if (routed) return React.createElement(wrap(api.App));
    // Invoke the actual hook only while React is rendering this real component.
    conversation = capture("useAgentConversation", () => api.useAgentConversation());
    if (mode === "hook") return null;
    if (mode === "skills") return React.createElement(wrap(api.SkillCenter), embedded === undefined ? {} : { embedded });
    if (mode === "assistant") return React.createElement(wrap(api.AiAssistant), {
      messages: conversation.messages, draft: conversation.draft, onDraftChange: conversation.setDraft,
      onSend: conversation.send, isRunning: conversation.isRunning, inputRef: { current: null }, expanded: false,
    });
    throw new Error(`Unknown harness mode: ${mode}`);
  }
  const snapshot = name => { assert.ok(snapshots.has(name), `${name} must be mounted`); return snapshots.get(name); };
  const dialog = name => {
    const tree = snapshot(name).tree;
    return one(tree, node => node.type === Dialog.Root, `${name} Dialog.Root`);
  };
  function render() {
    if (!deferReplies) runTimers();
    snapshots = new Map(); seen = new Set(); popupHtml = ""; pendingEffects = [];
    html = renderToStaticMarkup(React.createElement(Owner));
    const owner = snapshots.has("EaAgent") ? "EaAgent" : null;
    if (owner && dialog(owner).props.open) {
      const content = one(snapshot(owner).tree, node => node.type === Dialog.Content, "real Dialog.Content");
      // Radix portals are absent in SSR. Only expose the open content's actual
      // children under real Radix context, not a fake dialog or SkillCenter.
      popupHtml = renderToStaticMarkup(React.createElement(Dialog.Root, { open: true }, content.props.children));
    }
    for (const name of frames.keys()) if (!seen.has(name)) frames.delete(name);
    assert.deepEqual(forbiddenCalls, [], "Chat/library callbacks must not write or contact a backend");
    assert.ok(storageReads.every(key => ["ea_agent_sessions_v1", api.AGENT_POSITION_KEY, "test-onboarding", "test-whats-new"].includes(key)), "Only chat and launcher/onboarding preference reads are allowed");
    return html;
  }
  const act = (callback, ...args) => { assert.equal(typeof callback, "function"); callback(...args); render(); };
  render();
  if (routed && mode === "page") act(snapshot("Sidebar").props.onChange, "skills");
  return {
    api, act, render, snapshot, dialog, updates, forbiddenCalls, storage,
    finishReplies() { runTimers(); render(); },
    get pendingTimers() { return timers.size; },
    unmount() { for (const cleanup of cleanups) cleanup(); },
    tree: name => snapshot(name).tree,
    get conversation() { return conversation; }, get html() { return html; }, get popupHtml() { return popupHtml; },
    get mounted() { return [...snapshots.keys()]; },
    frame(name) { assert.ok(frames.has(name), `${name} frame must exist`); return frames.get(name); },
    flushEffects(name) {
      const selected = pendingEffects.filter(effect => effect.owner === name);
      pendingEffects = pendingEffects.filter(effect => effect.owner !== name);
      for (const effect of selected) { const cleanup = effect.callback(); if (typeof cleanup === "function") cleanups.push(cleanup); }
      return selected.length;
    },
    navigate(next) {
      assert.ok(routed);
      act(snapshot("Sidebar").props.onChange, next === "page" ? "skills" : next === "floating" ? "todo" : next);
    },
    library(open) {
      if (!open) return act(button(snapshot("SkillCenter").tree, "返回 EA Agent").props.onClick);
      const frame = frames.get("App");
      const value = { kind: "skill-management" };
      updates.push({ owner: "App", name: "view", before: frame.states.get("view"), value, functional: false });
      frame.states.set("view", value);
      render();
    },
  };
}

function floatingHarness() {
  const h = harness({ mode: "floating" });
  h.act(byAria(h.tree("EaAgent"), "打开 EA Agent 对话").props.onClick, { preventDefault() {} });
  return h;
}

test("sessions persist independent messages drafts and Skills, reload, rename and delete without touching business data", () => {
  const storage = new Map([["business-record", "unchanged"]]);
    const h = harness({ mode: "hook", storage });
    const initialCount = h.conversation.sessions.length;
    const firstId = h.conversation.activeSessionId;
  h.act(h.conversation.selectSkill, skills[0]); h.act(h.conversation.send, "第一轮问题"); h.act(h.conversation.setDraft, "第一对话草稿");
  h.act(h.conversation.newSession); const secondId = h.conversation.activeSessionId;
  assert.notEqual(firstId, secondId); assert.equal(h.conversation.messages.length, 0); assert.equal(h.conversation.activeSkill, null);
  h.act(h.conversation.send, "第二轮问题"); h.act(h.conversation.renameSession, firstId, "重新命名");
  h.act(h.conversation.openSession, firstId);
  assert.equal(h.conversation.draft, "第一对话草稿"); assert.equal(h.conversation.messages[0].text, "第一轮问题"); assert.equal(h.conversation.activeSkill.id, skills[0].id);
  const reloaded = harness({ mode: "hook", storage });
  assert.equal(reloaded.conversation.activeSessionId, firstId); assert.equal(reloaded.conversation.draft, "第一对话草稿"); assert.equal(reloaded.conversation.sessions.find(item => item.id === firstId).title, "重新命名");
  reloaded.act(reloaded.conversation.deleteSession, firstId);
  assert.equal(reloaded.conversation.activeSessionId, secondId); assert.equal(reloaded.conversation.messages[0].text, "第二轮问题");
  reloaded.act(reloaded.conversation.deleteSession, secondId); assert.equal(reloaded.conversation.sessions.length, initialCount - 1); assert.ok(reloaded.conversation.sessions.every(item => item.id !== firstId && item.id !== secondId));
  assert.equal(storage.get("business-record"), "unchanged");
});

test("generated files render only on AI replies with local downloads in both chat surfaces", () => {
  for (const makeHarness of [harness, floatingHarness]) {
    const current = makeHarness();
    current.act(current.snapshot("AiAssistant").props.onSend, "生成一份可下载的 Case 分析报告和验证计划");
    const messages = current.conversation.messages;
    assert.equal(messages[0].generatedFileIds, undefined);
    assert.deepEqual(plain(messages[1].generatedFileIds), ["analysis-report", "verification-data"]);
    assert.match(messages[1].text, /示例内容，未读取业务数据/);
    const fileList = byAria(current.tree("AiAssistant"), "生成的文件");
    assert.equal(elements(fileList).filter(node => node.type === "li").length, 2);
    const userMessage = byAria(current.tree("AiAssistant"), "我的消息");
    assert.equal(elements(userMessage).some(node => node.props.download), false);
    for (const file of current.api.AGENT_DEMO_FILES) {
      const link = byAria(fileList, `下载 ${file.name}`);
      assert.equal(link.type, "a");
      assert.equal(link.props.download, file.name);
      const [header, payload] = link.props.href.split(",");
      assert.equal(header, `data:${file.mime};charset=utf-8`);
      assert.equal(decodeURIComponent(payload), `\uFEFF${file.content}`);
      assert.match(text(fileList), new RegExp(`${(new Blob([`\uFEFF${file.content}`]).size / 1024).toFixed(1)} KB`));
      const stored = current.storage.get("ea_agent_sessions_v1");
      current.act(link.props.onClick);
      assert.match(text(byAria(current.tree("AiAssistant"), "生成的文件")), /已发起下载/);
      assert.equal(current.storage.get("ea_agent_sessions_v1"), stored);
    }
    assert.equal(elements(current.tree("AiAssistant")).filter(node => node.props["aria-label"] === "回复操作").length, 1);
    const reloaded = harness({ storage: current.storage });
    assert.deepEqual(plain(reloaded.conversation.messages), plain(messages));
    assert.equal(elements(byAria(reloaded.tree("AiAssistant"), "生成的文件")).filter(node => node.props.download).length, 2);
    assert.doesNotMatch(text(byAria(reloaded.tree("AiAssistant"), "生成的文件")), /已发起下载/);
    reloaded.act(reloaded.conversation.newSession);
    reloaded.act(reloaded.conversation.send, "Case 分析从哪里开始？");
    assert.equal(reloaded.conversation.messages.at(-1).generatedFileIds, undefined);
    assert.equal(elements(reloaded.tree("AiAssistant")).some(node => node.props.download), false);
  }
});

test("legacy and malformed file references cannot inject downloads or break a conversation", () => {
  for (const generatedFileIds of [undefined, "analysis-report", {}, ["unknown", "analysis-report", "analysis-report", 42]]) {
    const current = harness({ mode: "hook" });
    current.act(current.conversation.send, "保留这条消息");
    const data = JSON.parse(current.storage.get("ea_agent_sessions_v1"));
    const session = data.sessions.find(item => item.id === data.activeId);
    for (const message of session.messages) message.generatedFileIds = generatedFileIds;
    current.storage.set("ea_agent_sessions_v1", JSON.stringify(data));
    const reloaded = harness({ storage: current.storage });
    assert.equal(reloaded.conversation.messages.length, 2);
    assert.equal(reloaded.conversation.messages[0].generatedFileIds, undefined);
    assert.equal(elements(reloaded.tree("AiAssistant")).filter(node => node.props.download).length, Array.isArray(generatedFileIds) ? 1 : 0);
  }
});

test("custom conversation groups persist, rename, move sessions and release sessions when deleted", () => {
  const storage = new Map(); const h = harness({ mode: "hook", storage }); const sessionId = h.conversation.activeSessionId;
  const defaults = plain(h.conversation.groups);
  h.act(h.conversation.createGroup, "专项复盘"); h.act(h.conversation.moveSessionToGroup, sessionId, "专项复盘");
  assert.deepEqual(plain(h.conversation.groups), [...defaults, "专项复盘"]); assert.equal(h.conversation.sessions[0].group, "专项复盘");
  const reloaded = harness({ mode: "hook", storage });
  assert.deepEqual(plain(reloaded.conversation.groups), [...defaults, "专项复盘"]); assert.equal(reloaded.conversation.sessions[0].group, "专项复盘");
  reloaded.act(reloaded.conversation.renameGroup, "专项复盘", "专项跟踪");
  assert.deepEqual(plain(reloaded.conversation.groups), [...defaults, "专项跟踪"]); assert.equal(reloaded.conversation.sessions[0].group, "专项跟踪");
  reloaded.act(reloaded.conversation.deleteGroup, "专项跟踪");
  assert.deepEqual(plain(reloaded.conversation.groups), defaults); assert.equal(reloaded.conversation.sessions[0].group, undefined);
});

test("top-level new sessions stay recent while group-created sessions join that group", () => {
  const h = harness({ mode: "hook" });
  h.act(h.conversation.createGroup, "G5 专项");
  h.act(h.conversation.newSession, "G5 专项");
  assert.equal(h.conversation.sessions.find(item => item.id === h.conversation.activeSessionId).group, "G5 专项");
  h.act(h.conversation.newSession);
  assert.equal(h.conversation.sessions.find(item => item.id === h.conversation.activeSessionId).group, undefined);
});

test("time archive distinguishes today, yesterday, recent weeks, months and older years", () => {
  const h = harness(); const now = new Date("2026-09-12T12:00:00");
  assert.equal(h.api.agentSessionTimeGroup("2026-09-12T08:00:00", now), "今天");
  assert.equal(h.api.agentSessionTimeGroup("2026-09-11T08:00:00", now), "昨天");
  assert.equal(h.api.agentSessionTimeGroup("2026-09-07T08:00:00", now), "过去 7 天");
  assert.equal(h.api.agentSessionTimeGroup("2026-08-25T08:00:00", now), "过去 30 天");
  assert.equal(h.api.agentSessionTimeGroup("2026-07-15T08:00:00", now), "7 月");
  assert.equal(h.api.agentSessionTimeGroup("2025-12-01T08:00:00", now), "2025 年");
  assert.equal(h.api.agentSessionTimeGroup("invalid", now), "更早");
});

test("failed chat storage keeps the in-memory conversation and exposes a retry action", () => {
  const h = harness({ mode: "hook", failStorage: true });
  const initialCount = h.conversation.sessions.length;
  h.act(h.conversation.send, "不能丢失的问题");
  assert.equal(h.conversation.messages.length, 2); assert.match(h.conversation.storageError, /存储失败/); assert.equal(typeof h.conversation.retrySave, "function");
  h.act(h.conversation.newSession); assert.equal(h.conversation.sessions.length, initialCount + 1);
  h.act(h.conversation.openSession, h.conversation.sessions[1].id); assert.equal(h.conversation.messages[0].text, "不能丢失的问题");
});

test("skill center has a public sidebar route and keeps the floating Agent available", () => {
  const h = harness(); h.navigate("skill-center");
  assert.ok(h.mounted.includes("SkillCenter")); assert.equal(h.snapshot("EaAgent").props.suspended, false);
  assert.match(source("Sidebar.tsx"), /label="技能中心"/);
});

test("common questions appear only in genuinely empty sessions and never overlay an existing conversation", () => {
  const h = harness();
  const firstId = h.conversation.activeSessionId;
  assert.match(h.html, /Hi，EA有什么可以帮您？|ea-agent-prompts/);
  assert.doesNotMatch(h.html, /返回首页|继续对话/);
  h.act(h.conversation.selectSkill, skills[0]);
  h.act(h.conversation.send, "Case 分析");
  h.act(h.conversation.setDraft, "尚未发送的草稿");
  const history = h.conversation.messages, selected = h.conversation.activeSkill;
  assert.doesNotMatch(h.html, /Hi，EA有什么可以帮您？|ea-agent-prompts|返回首页|继续对话/);
  assert.equal(h.snapshot("AiAssistant").props.messages, history);
  assert.equal(h.conversation.messages, history); assert.equal(h.conversation.activeSkill, selected);
  assert.equal(h.conversation.draft, "尚未发送的草稿");
  h.act(h.conversation.newSession);
  assert.match(h.html, /Hi，EA有什么可以帮您？|ea-agent-prompts/);
  h.act(h.conversation.openSession, firstId);
  assert.doesNotMatch(h.html, /Hi，EA有什么可以帮您？|ea-agent-prompts|返回首页|继续对话/);
  assert.equal(h.snapshot("AiAssistant").props.messages, history);
  assert.equal(h.conversation.draft, "尚未发送的草稿");
});

test("rejected sends keep a new-session homepage while the first valid send permanently enters conversation mode", () => {
  const h = harness();
  for (const value of ["   ", "x".repeat(h.api.AGENT_MAX_MESSAGE + 1)]) {
    h.act(h.snapshot("AiAssistant").props.onSend, value);
    assert.match(h.html, /Hi，EA有什么可以帮您？|ea-agent-prompts/);
    assert.deepEqual(plain(h.conversation.messages), []);
  }
  h.act(h.snapshot("AiAssistant").props.onSend, "开始分析");
  assert.doesNotMatch(h.html, /Hi，EA有什么可以帮您？|ea-agent-prompts|返回首页|继续对话/);
  assert.equal(h.conversation.messages.length, 2);
  assert.equal(h.conversation.draft, "");
  assert.doesNotMatch(pageSource + css, /HOME_MESSAGES|setHome|ea-agent-page-navigation/);
});

test("App routes skills and the ai alias to one page with one shared hook and suspends floating chat", () => {
  assert.equal((appSource.match(/\buseAgentConversation\s*\(/g) ?? []).length, 1);
  assert.match(appSource, /function App\(\)\s*\{\s*const agentConversation = useAgentConversation\(\)/);
  assert.match(appSource, /view\.kind === "page" && \(view\.page === "skills" \|\| view\.page === "ai"\) && \(\s*<EaAgentPage conversation=\{agentConversation\} onOpenWindow=\{returnAgentToWindow\} \/>/);
  assert.equal((appSource.match(/<EaAgentPage\b/g) ?? []).length, 1);
  assert.equal((appSource.match(/<EaAgent\b/g) ?? []).length, 1);
  assert.match(appSource, /<EaAgent conversation=\{agentConversation\} onOpenPage=\{goAgent\} openRequest=\{agentWindowRequest\} suspended=\{guideOpen \|\| whatsNew \|\| feedback \|\| view\.kind === "skill-management" \|\| \(view\.kind === "page" && \(view\.page === "skills" \|\| view\.page === "ai"\)\)\}/);
  for (const route of ["skills", "ai"]) assert.match(appSource, new RegExp(`${route}: "EA Agent"`));
  assert.match(appSource, /\| \{ kind: "skill-management" \}/);
  assert.match(appSource, /const goAgent = \(\) => \{[\s\S]*agentReturnView\.current = view;[\s\S]*setView\(\{ kind: "page", page: "skills" \}\)/);
  assert.match(appSource, /const returnAgentToWindow = \(\) => \{\s*setView\(agentReturnView\.current\);\s*setAgentWindowRequest\(value => value \+ 1\)/);
  assert.match(appSource, /view\.page === "skill-center"/);
  assert.match(appSource, /<SkillCenter onBackToAgent=\{goAgent\}/);
  assert.equal((appSource.match(/<SkillCenter\b/g) ?? []).length, 1);
  assert.doesNotMatch(appSource, /<AiAssistant\b|agentConversation\.(?:send|setDraft)\(/);
  assert.doesNotMatch(pageSource + floatingSource, /\buseAgentConversation\s*\(/);
  assert.doesNotMatch(source("Sidebar.tsx"), /label="EA Agent"[^\n]*onChange\("skills"\)/);
  assert.match(floatingSource, /hidden=\{suspended \|\| open\}/);
  assert.match(floatingSource, /<Dialog.Root open=\{open && !suspended\}/);
  assert.doesNotMatch(hookSource, /\b(?:sessionStorage|fetch|XMLHttpRequest|WebSocket)\b/);
});

test("the real conversation hook rejects invalid sends and appends trimmed, uniquely identified messages in order", () => {
  const h = harness({ mode: "hook" }); const max = h.api.AGENT_MAX_MESSAGE;
  assert.deepEqual(plain(h.conversation.messages), []);
  assert.equal(h.conversation.draft, "");
  h.act(h.conversation.setDraft, "保留草稿");
  const before = h.conversation.messages; const count = h.updates.length;
  for (const value of ["", " \n\t ", "x".repeat(max + 1), `  ${"x".repeat(max + 1)}  `]) h.act(h.conversation.send, value);
  assert.equal(h.conversation.messages, before);
  assert.equal(h.conversation.draft, "保留草稿");
  assert.equal(h.updates.length, count, "Rejected input must not even schedule state updates");
  // Reuse one callback before rerender to expose stale-array/nonfunctional updates.
  const send = h.conversation.send;
  send(" \nCase 分析\t "); h.render(); send("自由任务如何处理？"); h.render();
  h.act(h.conversation.send, `  ${"x".repeat(max)} \n`);
  const messages = plain(h.conversation.messages);
  assert.deepEqual(messages.map(message => message.role), ["user", "ai", "user", "ai", "user", "ai"]);
  assert.deepEqual(messages.map(message => message.id), [1, 2, 3, 4, 5, 6]);
  assert.equal(new Set(messages.map(message => message.id)).size, messages.length);
  assert.deepEqual(messages.filter(message => message.role === "user").map(message => message.text), ["Case 分析", "自由任务如何处理？", "x".repeat(max)]);
  assert.equal(h.conversation.draft, "");
  for (let i = 0; i < messages.length; i += 2) assert.equal(messages[i + 1].text, h.api.agentDemoReply(messages[i].text));
  const commits = h.updates.filter(update => update.owner === "useAgentConversation" && update.name === "messages" && update.value.length > update.before.length);
  assert.equal(commits.length, 6);
  for (const commit of commits) {
    assert.equal(commit.value.length, commit.before.length + 1);
    assert.deepEqual(plain(commit.value.slice(0, -1)), plain(commit.before));
    assert.equal(commit.value.at(-1).role, commit.before.length % 2 ? "ai" : "user");
  }
  assert.deepEqual(plain(before), [], "Appending must not mutate previous snapshots");
});

test("running feedback waits for a reply, blocks duplicate sends and preserves the next draft across chat surfaces", () => {
  const h = harness({ deferReplies: true });
  const composer = () => one(h.tree("AiAssistant"), node => node.props.className?.split(" ").includes("ea-agent-composer"), "composer");
  for (const value of [" ", "x".repeat(h.api.AGENT_MAX_MESSAGE + 1)]) h.act(h.conversation.send, value);
  assert.equal(h.pendingTimers, 0); assert.equal(h.conversation.isRunning, false);
  const send = h.conversation.send;
  h.act(send, "生成一份可下载的分析报告");
  assert.equal(h.pendingTimers, 1);
  assert.equal(h.conversation.isRunning, true);
  assert.equal(h.conversation.messages.length, 1);
  assert.equal(composer().props["aria-busy"], true);
  assert.match(composer().props.className, /is-running/);
  assert.equal(byAria(h.tree("AiAssistant"), "发送消息").props.disabled, true);
  h.act(send, "重复发送");
  assert.equal(h.conversation.messages.length, 1); assert.equal(h.pendingTimers, 1);
  h.act(h.conversation.setDraft, "下一条草稿");
  const input = byAria(h.tree("AiAssistant"), "发送给 EA Agent 的消息");
  h.act(input.props.onKeyDown, { key: "Enter", shiftKey: false, nativeEvent: { isComposing: false }, keyCode: 13, preventDefault() {} });
  h.act(one(h.tree("AiAssistant"), node => node.type === "form", "compose form").props.onSubmit, { preventDefault() {} });
  assert.equal(h.conversation.draft, "下一条草稿"); assert.equal(h.conversation.messages.length, 1);
  h.act(byAria(h.tree("EaAgentPage"), "返回 EA Agent 小窗").props.onClick);
  h.flushEffects("EaAgent"); h.render();
  assert.equal(h.snapshot("AiAssistant").props.isRunning, true);
  h.finishReplies();
  assert.equal(h.conversation.isRunning, false); assert.equal(h.pendingTimers, 0);
  assert.equal(h.conversation.messages.length, 2); assert.equal(h.conversation.draft, "下一条草稿");
  assert.equal(composer().props["aria-busy"], false); assert.doesNotMatch(composer().props.className, /is-running/);
  assert.equal(byAria(h.tree("AiAssistant"), "发送消息").props.disabled, false);
  assert.equal(elements(h.tree("AiAssistant")).filter(node => node.props.download).length, 2);
  assert.equal(harness({ storage: h.storage }).conversation.isRunning, false);
});

test("pending replies stay with their original sessions and deleted or unmounted runs are cancelled", () => {
  const h = harness({ mode: "hook", deferReplies: true });
  h.flushEffects("useAgentConversation");
  const first = h.conversation.activeSessionId;
  h.act(h.conversation.send, "第一条会话");
  h.act(h.conversation.newSession);
  const second = h.conversation.activeSessionId;
  assert.equal(h.conversation.isRunning, false);
  h.act(h.conversation.send, "第二条会话");
  h.act(h.conversation.setDraft, "保留另一条草稿");
  h.act(h.conversation.renameSession, first, "已重命名");
  h.finishReplies();
  assert.equal(h.conversation.activeSessionId, second);
  assert.equal(h.conversation.draft, "保留另一条草稿");
  assert.equal(h.conversation.messages[0].text, "第二条会话");
  assert.equal(h.conversation.messages.length, 2);
  assert.equal(h.conversation.sessions.find(item => item.id === first).messages.length, 2);
  assert.equal(h.conversation.sessions.find(item => item.id === first).title, "已重命名");
  h.act(h.conversation.send, "将删除的运行");
  h.act(h.conversation.deleteSession, second);
  assert.equal(h.pendingTimers, 0); h.finishReplies();
  assert.equal(h.conversation.sessions.some(item => item.id === second), false);
  h.act(h.conversation.send, "卸载前的运行");
  h.unmount();
  assert.equal(h.pendingTimers, 0);
});

test("composer running border is restrained, non-interactive and supports reduced motion", () => {
  assert.match(css, /\.ea-agent-composer\.is-running::after \{[^}]*pointer-events:none;[^}]*animation:ea-agent-running-border 3s linear infinite/);
  assert.match(css, /@media \(prefers-reduced-motion:reduce\)[\s\S]*\.ea-agent-composer\.is-running::after \{ animation:none;/);
  assert.match(css, /@media \(forced-colors:active\)[\s\S]*\.ea-agent-composer\.is-running::after \{ display:none;/);
});

test("EA Agent page keeps conversation controls and direct-send common questions without a Skill picker", () => {
  const h = harness(); const tree = h.tree("EaAgentPage");
    assert.equal(elements(tree).filter(node => node.type === "h1" || node.type === "header").length, 0); 
  assert.doesNotMatch(h.html, /<h1|管理 Skill/);
  assert.doesNotMatch(pageSource, /onManageSkills|Dialog|SkillCenter|skillsOpen|onCloseAutoFocus/);
  assert.doesNotMatch(css, /ea-agent-skills-(?:dialog|overlay|body|header|close)/);
  const composer = one(h.tree("AiAssistant"), node => node.props.className === "ea-agent-composer", "text input container");
  assert.equal(elements(composer).filter(node => node.type === "textarea").length, 1);
  assert.equal(elements(composer).some(node => original(node) === h.api.AgentSkillPicker), false);
  assert.equal(elements(composer).some(node => node.type === Dialog.Root || node.type === Dialog.Trigger || node.props.className === "ea-agent-skill-manage"), false);
  assert.doesNotMatch(h.html, /选择 Skill|ea-agent-composer-skills/);
  const questions = ["帮我统计我的部门当前的Case状态与风险情况", "G5平台当前有什么问题？", "DDJOC产品有多少case，什么进展？", "Fail stage在FT阶段的问题有哪些？"];
  assert.deepEqual(elements(h.tree("AiAssistant")).filter(node => node.type === "button" && questions.includes(text(node))).map(text), questions);
  assert.match(h.html, /新建对话/); assert.match(h.html, /历史对话/);
  assert.equal(h.snapshot("AiAssistant").props.showPrompts, true);
  assert.doesNotMatch(h.html, /已上线技能|打开使用|搜索技能名称|技能市场|未发布草稿|<article/);
  h.act(byAria(h.tree("AiAssistant"), `发送常用问题：${questions[0]}`).props.onClick);
  assert.equal(h.conversation.messages[0].text, questions[0]); assert.equal(h.conversation.messages[1].role, "ai");
  assert.doesNotMatch(h.html, /ea-agent-prompts/);
  assert.equal(h.mounted.includes("SkillCenter"), false);
  assert.equal(elements(tree).some(node => [Dialog.Root, Dialog.Portal, Dialog.Content, Dialog.Overlay].includes(node.type)), false);
  h.library(true);
  assert.equal(h.snapshot("SkillCenter").props.embedded, undefined, "Management uses default full-page layout, not embedded modal layout");
  assert.equal(typeof h.snapshot("SkillCenter").props.onSelectSkill, "function");
  assert.equal(typeof h.snapshot("SkillCenter").props.onBackToAgent, "function");
  assert.match(h.html, /搜索 Skill|搜索技能名称/);
  assert.match(h.html, /日报管理|Bitmap 高评分/);
  assert.match(h.html, /<h1[^>]*>管理 Skill<\/h1>/);
  assert.doesNotMatch(h.html, /ea-agent-header-logo|未发布草稿|role="dialog"|aria-modal|ea-agent-skills-overlay/);
  assert.equal(h.mounted.includes("EaAgentPage"), false);
  assert.equal(h.mounted.includes("AiAssistant"), false);
  assert.equal(h.popupHtml, "");
  assert.equal(h.dialog("EaAgent").props.open, false);
  h.library(false);
  assert.equal(h.popupHtml, "");
  assert.equal(h.mounted.includes("SkillCenter"), false);
  assert.doesNotMatch(h.html, /<h1|管理 Skill/);
});

test("page title exposes hover rename and saves inline without opening a dialog", () => {
  const h = harness(); const title = h.conversation.sessions.find(item => item.id === h.conversation.activeSessionId).title;
  assert.equal(text(byAria(h.tree("EaAgentPage"), `重命名 ${title}`)), "");
  assert.match(css, /\.ea-agent-page-title-rename[^}]*opacity:0/);
  h.act(byAria(h.tree("EaAgentPage"), `重命名 ${title}`).props.onClick);
  const name = byAria(h.tree("EaAgentPage"), "对话名称");
  h.act(name.props.onChange, { target: { value: " 顶部重命名 " } });
  const form = one(h.tree("EaAgentPage"), node => node.type === "form" && node.props.className === "ea-agent-page-title-form", "title rename form");
  h.act(form.props.onSubmit, { preventDefault() {} });
  assert.equal(h.conversation.sessions.find(item => item.id === h.conversation.activeSessionId).title, "顶部重命名");
  assert.equal(elements(h.tree("EaAgentPage")).some(node => node.type === Dialog.Root), false);
});

test("new and historical conversations live in a left sidebar with an expandable history list", () => {
  const h = harness();
  assert.match(capturedSources.AgentSessionControls, /PanelLeftClose, PanelLeftOpen/);
  assert.match(capturedSources.AgentSessionControls, /open \? <PanelLeftClose size=\{15\} \/> : <PanelLeftOpen size=\{15\} \/>/);
  assert.match(capturedSources.AgentSessionControls, /collapsed \? <Folder size=\{12\} \/> : <FolderOpen size=\{12\} \/>/);
  assert.match(capturedSources.AgentSessionControls, /aria-label=\{`重命名 \$\{item\.title\}`\}[\s\S]*ea-agent-sidebar-rename/);
  assert.match(capturedSources.AgentSessionControls, /ea-agent-sidebar-menu is-wide">\s*<div className="ea-agent-sidebar-menu-label">移动到分组/);
  assert.doesNotMatch(capturedSources.AgentSessionControls, /最近对话<\/span><small>/);
  assert.match(css, /\.ea-agent-sidebar-rename \{ opacity:0; transition:opacity \.15s ease; \}/);
  assert.match(css, /\.ea-agent-sidebar-session:hover \.ea-agent-sidebar-rename, \.ea-agent-sidebar-rename:focus-visible \{ opacity:1; \}/);
  assert.match(css, /\.ea-agent-sidebar-group-add \{ opacity:0; transition:opacity \.15s ease; \}/);
  assert.match(css, /\.ea-agent-sidebar-section-heading:hover \.ea-agent-sidebar-group-add, \.ea-agent-sidebar-group-add:focus-visible \{ opacity:1; \}/);
  assert.equal(declarations(".ea-agent-sidebar-section-heading").padding, "0 0 0 5px");
  assert.doesNotMatch(capturedSources.AgentSessionControls, /\bFolderPlus\b/);
  assert.match(capturedSources.AgentSessionControls, /conversation\.newSession\(label\)/);
  assert.match(capturedSources.AgentSessionControls, /draggable=\{!item\.group\}[\s\S]*moveSessionToGroup\(id, label\)/);
  assert.doesNotMatch(capturedSources.AgentSessionControls, /<small>\{items\.length\}<\/small>/);
  assert.doesNotMatch(capturedSources.AgentSessionControls, />未分组</);
  assert.match(capturedSources.AgentSessionControls, /item\.group &&[\s\S]*移至最近对话/);
  assert.match(capturedSources.AgentSessionControls, /elapsedDays === 1[\s\S]*过去 7 天[\s\S]*过去 30 天[\s\S]*getFullYear/);
  const sidebar = byAria(h.tree("EaAgentPage"), "EA Agent 对话侧栏");
  assert.equal(sidebar.type, "aside"); assert.equal(sidebar.props.className, "ea-agent-session-sidebar");
  assert.equal(h.snapshot("AgentSessionControls").props.sidebar, true);
  assert.equal(declarations(".ea-agent-page")["flex-direction"], "row");
  assert.equal(declarations(".ea-agent-session-sidebar").width, "53px");
  assert.equal(declarations(".ea-agent-session-sidebar.is-expanded").width, "244px");
  assert.equal(declarations(".ea-agent-sidebar-group")["margin-bottom"], "10px");
  assert.deepEqual(declarations(".ea-agent-sidebar-group-items"), { display: "flex", "flex-direction": "column", gap: "1px" });
  assert.equal(declarations(".ea-agent-sidebar-group.is-dialog-group .ea-agent-sidebar-group-items")["margin-left"], "29px");
  assert.equal(declarations(".ea-agent-sidebar-group.is-time-group .ea-agent-sidebar-group-items")["margin-left"], "17px");
  const controls = () => h.tree("AgentSessionControls");
  const history = () => byAria(controls(), "历史对话列表");
  assert.equal(byAria(controls(), "展开").props["aria-expanded"], false);
  assert.equal(history().props.hidden, true);
  assert.equal(text(byAria(controls(), "新建对话")), ""); assert.equal(text(byAria(controls(), "展开")), "");
  h.act(byAria(controls(), "展开").props.onClick);
  assert.equal(history().props.hidden, false);
  assert.match(byAria(h.tree("EaAgentPage"), "EA Agent 对话侧栏").props.className, /is-expanded/);
  assert.equal(text(byAria(controls(), "新建对话")), "新建对话"); assert.equal(text(byAria(controls(), "收起")), "");
  assert.doesNotMatch(text(controls()), /EA Agent|张伟|PTE Engineer/);
  assert.doesNotMatch(capturedSources.AgentSessionControls, /搜索历史对话|搜索对话|ea-agent-sidebar-search|常用问题/);
  assert.match(capturedSources.AgentSessionControls, /ea-agent-sidebar-actions/);
  assert.match(text(controls()), /对话组.*最近对话/);
  assert.ok(byAria(controls(), "新建分组"));
  assert.doesNotMatch(capturedSources.AgentSessionControls, /对话归纳方式|role="tab"|>Projects</);
  assert.ok(byAria(controls(), "今天"));
  const todayToggle = byAria(controls(), "收起分组 今天");
  assert.equal(todayToggle.props["aria-expanded"], true);
  h.act(todayToggle.props.onClick);
  assert.equal(byAria(controls(), "展开分组 今天").props["aria-expanded"], false);
  h.act(byAria(controls(), "展开分组 今天").props.onClick);
  assert.equal(byAria(controls(), "收起分组 今天").props["aria-expanded"], true);
  assert.ok(byAria(controls(), "更多操作 新对话"));
  const stored = [...h.storage.entries()];
  h.act(byAria(controls(), "收起").props.onClick);
  assert.equal(history().props.hidden, true);
  assert.equal(byAria(controls(), "展开").props["aria-expanded"], false);
  assert.equal(text(byAria(controls(), "新建对话")), ""); assert.equal(text(byAria(controls(), "展开")), "");
  assert.deepEqual([...h.storage.entries()], stored, "Collapsing history never mutates sessions");
  const sessionCount = h.conversation.sessions.length;
  h.act(byAria(controls(), "新建对话").props.onClick);
  assert.equal(h.conversation.sessions.length, sessionCount + 1);
  h.act(byAria(controls(), "展开").props.onClick);
  const other = one(controls(), node => node.type === "button" && node.props["aria-current"] === undefined && elements(node).some(child => child.type === "span" && child.props.title === "新对话"), "other session");
  h.act(other.props.onClick);
  assert.equal(history().props.hidden, false, "Opening a conversation keeps the history expanded");
});

test("floating maximize opens the sidebar Agent page with the same conversation instead of a full-screen dialog", () => {
  const h = harness(); h.act(h.conversation.send, "保留的悬浮对话"); h.act(h.conversation.setDraft, "保留的草稿");
  const messages = h.conversation.messages; h.navigate("floating");
  h.act(byAria(h.tree("EaAgent"), "打开 EA Agent 对话").props.onClick, { preventDefault() {} });
  assert.equal(h.dialog("EaAgent").props.modal, false); assert.doesNotMatch(h.popupHtml, /is-expanded|ea-agent-overlay/);
  h.act(byAria(h.tree("EaAgent"), "打开 EA Agent 页面").props.onClick);
  assert.ok(h.mounted.includes("EaAgentPage")); assert.equal(h.dialog("EaAgent").props.open, false);
  assert.equal(h.snapshot("AiAssistant").props.messages, messages); assert.equal(h.conversation.draft, "保留的草稿");
});

test("full-page Agent returns to the previous page and opens an immersive floating window with the same conversation", () => {
  const h = harness(); h.act(h.conversation.send, "全屏返回小窗"); h.act(h.conversation.setDraft, "继续输入");
  const messages = h.conversation.messages;
  assert.doesNotMatch(floatingSource, /<header|ea-agent-header-logo|ea-agent-heading|AI 助手|工程分析与任务协作/);
  assert.match(floatingSource, /<Dialog\.Title className="sr-only">EA Agent<\/Dialog\.Title>/);
  assert.match(floatingSource, /ea-agent-window-actions ea-agent-window-actions-overlay/);
  h.act(h.snapshot("EaAgentPage").props.onOpenWindow);
  assert.equal(h.mounted.includes("EaAgentPage"), false);
  assert.equal(h.snapshot("EaAgent").props.suspended, false);
  assert.equal(h.snapshot("EaAgent").props.openRequest, 1);
  h.flushEffects("EaAgent"); h.render();
  assert.equal(h.dialog("EaAgent").props.open, true);
  assert.equal(h.snapshot("AiAssistant").props.messages, messages);
  assert.equal(h.conversation.draft, "继续输入");
  assert.doesNotMatch(h.popupHtml, /AI 助手|工程分析与任务协作|ea-agent-header-logo/);
});

test("one conversation survives page/floating remounts and library visits without leaking Skill chat", () => {
  const h = harness();
  const chat = () => h.snapshot("AiAssistant");
  h.act(chat().props.onDraftChange, "未发送草稿");
  h.library(true); h.library(false);
  assert.equal(chat().props.draft, "未发送草稿");
  h.act(chat().props.onSend, "Case 分析");
  const history = h.conversation.messages;
  h.act(chat().props.onDraftChange, "跨视图草稿");
  h.navigate("floating");
  h.act(byAria(h.tree("EaAgent"), "打开 EA Agent 对话").props.onClick, { preventDefault() {} });
  assert.equal(chat().props.messages, history);
  assert.equal(chat().props.draft, "跨视图草稿");
  h.act(chat().props.onSend, "Workspace 结论");
  h.act(chat().props.onDraftChange, "继续保留");
  h.navigate("page");
  assert.equal(h.dialog("EaAgent").props.open, false);
  assert.equal(byAria(h.tree("EaAgent"), "打开 EA Agent 对话").props.hidden, true);
  const shared = h.conversation.messages;
  h.library(true);
  h.act(button(cards(h.tree("SkillCenter")).find(node => node.key === "analysis-top"), "打开工作区").props.onClick, { stopPropagation() {} });
  const workspace = h.tree("SkillWorkspace");
  const prompt = elements(workspace).find(node => node.type === "button" && text(node) === "给出下一步验证路径");
  h.act(prompt.props.onClick);
  assert.equal(h.conversation.messages, shared, "SkillWorkspace retains its own existing conversation");
  h.library(false);
  assert.equal(chat().props.messages, shared);
  assert.equal(chat().props.draft, "继续保留");
  h.navigate("floating");
  assert.equal(h.dialog("EaAgent").props.open, true, "Suspension must not erase the floating open state");
  assert.equal(chat().props.messages, shared);
  h.act(byAria(h.tree("EaAgent"), "收起 EA Agent").props.onClick);
  h.act(byAria(h.tree("EaAgent"), "打开 EA Agent 对话").props.onClick, { preventDefault() {} });
  assert.equal(chat().props.draft, "继续保留");
  assert.deepEqual(plain(shared.map(message => message.id)), [1, 2, 3, 4]);
  assert.deepEqual(plain(harness({ mode: "hook" }).conversation.messages), [], "A fresh owner has no persisted chat");
});

test("default and embedded SkillCenter preserve raw published filtering, ranking, search and categories", () => {
  const expected = ["sk-003", "analysis-top", "analysis-tie", "analysis-low"];
  for (const embedded of [undefined, true]) {
    const h = harness({ mode: "skills", embedded });
    assert.deepEqual(cardIds(h.tree("SkillCenter")), expected);
    if (embedded) assert.doesNotMatch(h.html, /<h1|ea-agent-header-logo/);
    else { assert.match(h.html, /<h1[^>]*>EA Agent<\/h1>/); assert.match(h.html, /ea-agent-header-logo/); }
    assert.match(h.html, /已上线技能/);
    assert.doesNotMatch(h.html, /未发布草稿/);
    assert.doesNotMatch(h.html, /返回 EA Agent|>管理 Skill<|调用<|打开工作区/);
    const search = value => h.act(byAria(h.tree("SkillCenter"), "搜索 Skill").props.onChange, { target: { value } });
    for (const query of ["  bitmap  ", " alice ", " CORNER "]) {
      search(query); assert.deepEqual(cardIds(h.tree("SkillCenter")), ["analysis-top"]);
    }
    search("needletag"); assert.deepEqual(cardIds(h.tree("SkillCenter")), ["analysis-low"]);
    h.act(button(h.tree("SkillCenter"), "报告生成").props.onClick);
    assert.match(h.html, /没有匹配的已上线技能/);
    assert.equal(button(h.tree("SkillCenter"), "报告生成").props["aria-pressed"], true);
    search(""); assert.deepEqual(cardIds(h.tree("SkillCenter")), ["sk-003"]);
    h.act(button(h.tree("SkillCenter"), "全部").props.onClick);
    assert.deepEqual(cardIds(h.tree("SkillCenter")), expected);
  }
  assert.deepEqual(skills.map(item => item.id), ["analysis-low", "draft", "analysis-tie", "sk-003", "analysis-top"], "Sorting never mutates the raw store array");
  assert.match(capturedSources.SkillCenter, /onBackToAgent\?:\s*\(\) => void/);
});

test("Skill cards keep click/keyboard guards and restore search/category after returning from the workspace", () => {
  for (const action of ["click", "Enter", " ", "button"]) {
    const h = harness({ mode: "skills", embedded: true });
    h.act(byAria(h.tree("SkillCenter"), "搜索 Skill").props.onChange, { target: { value: "bitmap" } });
    h.act(button(h.tree("SkillCenter"), "失效分析").props.onClick);
    const card = cards(h.tree("SkillCenter"))[0]; const target = {}; let prevented = 0; let stopped = 0;
    assert.equal(card.props.tabIndex, 0);
    const event = key => ({ key, target, currentTarget: target, preventDefault() { prevented++; } });
    h.act(card.props.onKeyDown, { ...event("Enter"), target: {} });
    h.act(card.props.onKeyDown, event("Escape"));
    assert.equal(h.mounted.includes("SkillWorkspace"), false);
    assert.equal(prevented, 0);
    if (action === "click") h.act(card.props.onClick);
    else if (action === "button") h.act(button(card, "打开使用").props.onClick, { stopPropagation() { stopped++; } });
    else h.act(card.props.onKeyDown, event(action));
    assert.equal(prevented, action === "Enter" || action === " " ? 1 : 0);
    assert.equal(stopped, action === "button" ? 1 : 0);
    assert.equal(h.snapshot("SkillWorkspace").props.skill, skills[4]);
    assert.equal(h.snapshot("SkillWorkspace").props.embedded, true);
    assert.match(h.html, /h-\[min\(620px,70vh\)\]/);
    h.act(button(h.tree("SkillWorkspace"), "返回 Skill 列表").props.onClick);
    assert.equal(byAria(h.tree("SkillCenter"), "搜索 Skill").props.value, "bitmap");
    assert.equal(button(h.tree("SkillCenter"), "失效分析").props["aria-pressed"], true);
    assert.deepEqual(cardIds(h.tree("SkillCenter")), ["analysis-top"]);
  }
});

test("DailyReport selection preserves the actual specialized component, skill, key, embedded and back props", () => {
  for (const embedded of [undefined, true]) {
    const h = harness({ mode: "skills", embedded });
    h.act(button(h.tree("SkillCenter"), "报告生成").props.onClick);
    h.act(cards(h.tree("SkillCenter"))[0].props.onClick);
    const daily = one(h.tree("SkillCenter"), node => original(node) === h.api.DailyReportSkill, "actual DailyReportSkill");
    assert.equal(daily.props.skill, skills[3]);
    assert.equal(daily.key, "sk-003");
    assert.equal(daily.props.embedded, embedded === true);
    assert.equal(h.mounted.includes("SkillWorkspace"), false);
    h.act(daily.props.onBack);
    assert.equal(button(h.tree("SkillCenter"), "报告生成").props["aria-pressed"], true);
    assert.deepEqual(cardIds(h.tree("SkillCenter")), ["sk-003"]);
  }
  assert.match(dailySource, /embedded = false/);
  assert.match(dailySource, /embedded \? "h-\[min\(660px,70vh\)\] min-h-\[360px\] w-full"/);
  assert.match(dailySource, /onClick=\{onBack\}/);
  assert.match(dailySource, /embedded \? "返回 Skill 列表" : "返回技能市场"/);
});

test("AiAssistant welcome uses the decorative animated orb, while existing messages suppress welcome and prompts", () => {
  const h = harness({ mode: "assistant" });
  assert.match(h.html, /Hi，EA有什么可以帮您？/);
  assert.match(h.html, /class="ea-agent-orb ea-agent-welcome-orb" aria-hidden="true"/);
  assert.doesNotMatch(h.html, /ea-agent-header-logo/);
  assert.match(h.html, /<img src="data:image\/gif;base64,/);
  assert.doesNotMatch(h.html, /演示模式 · 示例回复，尚未连接真实 AI 服务|仅本地演示 · 对话保存在当前浏览器，不提交服务器|Enter 发送 · Shift \+ Enter 换行|ea-agent-demo|ea-agent-footnote/);
  assert.equal(elements(h.tree("AiAssistant")).filter(node => node.type === "button" && text(node) !== "").length, 4);
  assert.equal(byAria(h.tree("AiAssistant"), "发送给 EA Agent 的消息").props.placeholder, "请输入...");
  assert.equal(byAria(h.tree("AiAssistant"), "发送消息").props.disabled, true);
  h.act(h.conversation.send, "<img src=x onerror=alert(1)>\nCase 分析");
  assert.doesNotMatch(h.html, /ea-agent-welcome|Hi，EA有什么可以帮您？|ea-agent-prompts|<img src=x/);
  assert.match(h.html, /&lt;img src=x onerror=alert\(1\)&gt;/);
  const log = byAria(h.tree("AiAssistant"), "EA Agent 对话记录");
  assert.equal(log.props.role, "log"); assert.equal(log.props["aria-live"], "polite");
  assert.equal(log.props["aria-relevant"], "additions");
  assert.deepEqual(elements(log).filter(node => node.type === "article").map(node => node.props["aria-label"]), ["我的消息", "EA Agent 回复"]);
  assert.match(h.html, /ea-agent-orb ea-agent-message-orb/);
  assert.equal(byAria(log, "回复操作").type, "div");
  assert.equal(byAria(log, "复制回复").props.title, "复制");
  assert.equal(byAria(log, "赞同此回复").props["aria-pressed"], false);
  assert.equal(byAria(log, "不赞同此回复").props["aria-pressed"], false);
  assert.match(h.html, /<time dateTime="[^"]+">\d{2}:\d{2}<\/time>/);
  assert.equal(elements(log).filter(node => node.props["aria-label"] === "回复操作").length, 1, "Only AI replies expose hover actions");
  h.act(byAria(log, "赞同此回复").props.onClick);
  assert.equal(byAria(byAria(h.tree("AiAssistant"), "EA Agent 对话记录"), "赞同此回复").props["aria-pressed"], true);
  h.act(byAria(byAria(h.tree("AiAssistant"), "EA Agent 对话记录"), "不赞同此回复").props.onClick);
  assert.equal(byAria(byAria(h.tree("AiAssistant"), "EA Agent 对话记录"), "赞同此回复").props["aria-pressed"], false);
  assert.equal(byAria(byAria(h.tree("AiAssistant"), "EA Agent 对话记录"), "不赞同此回复").props["aria-pressed"], true);
  assert.doesNotMatch(h.html, /<span>示例<\/span>|lucide-sparkles/);
});

test("composer callbacks preserve drafts, maxlength, Enter/newline and both IME guards without preset prompts", () => {
  const h = floatingHarness(); const tree = () => h.tree("AiAssistant");
  const input = () => byAria(tree(), "发送给 EA Agent 的消息");
  const form = () => one(tree(), node => node.type === "form", "composer form");
  let focused = 0; let prevented = 0;
  h.snapshot("AiAssistant").props.inputRef.current = { focus() { focused++; } };
  assert.equal(input().props.maxLength, h.api.AGENT_MAX_MESSAGE);
  assert.equal(elements(tree()).filter(node => node.type === "button" && ["梳理分析思路", "整理文档结构", "了解任务流程"].includes(text(node))).length, 0);
  assert.equal(h.conversation.messages.length, 0); assert.equal(focused, 0);
  h.act(input().props.onChange, { target: { value: " 中文输入\n第二行 " } });
  const event = extra => ({ key: "Enter", shiftKey: false, keyCode: 13, nativeEvent: { isComposing: false }, preventDefault() { prevented++; }, ...extra });
  for (const extra of [{ shiftKey: true }, { keyCode: 229 }, { nativeEvent: { isComposing: true } }, { key: "a" }]) h.act(input().props.onKeyDown, event(extra));
  h.act(input().props.onCompositionStart);
  h.act(input().props.onKeyDown, event());
  h.act(form().props.onSubmit, event());
  assert.equal(h.conversation.messages.length, 0);
  assert.equal(h.conversation.draft, " 中文输入\n第二行 ");
  assert.equal(prevented, 1, "Only form submission prevents default while composing");
  h.act(input().props.onCompositionEnd);
  h.act(input().props.onKeyDown, event());
  assert.equal(h.conversation.messages.length, 2);
  assert.equal(h.conversation.messages[0].text, "中文输入\n第二行");
  assert.equal(h.conversation.draft, ""); assert.equal(focused, 1);
  h.act(input().props.onChange, { target: { value: "   " } });
  assert.equal(byAria(tree(), "发送消息").props.disabled, true);
  h.act(form().props.onSubmit, event());
  assert.equal(h.conversation.messages.length, 2, "The actual hook also guards direct empty submissions");
  h.act(input().props.onChange, { target: { value: "正常提交" } });
  h.act(form().props.onSubmit, event());
  assert.equal(h.conversation.messages.length, 4);
  assert.equal(h.conversation.messages[2].text, "正常提交");
});

test("page and floating chat expose direct-send common questions only for empty sessions", () => {
  const page = harness(); const floating = floatingHarness();
  assert.doesNotMatch(floatingSource, /AgentSessionControls|新建对话|历史对话/);
  for (const h of [page, floating]) {
    assert.equal(h.mounted.includes("AgentSkillPicker"), false);
    assert.equal(h.snapshot("AiAssistant").props.composerTools, undefined);
  }
  assert.equal(page.snapshot("AiAssistant").props.showPrompts, true);
  assert.match(page.html, /aria-label="常用问题"|ea-agent-prompts/);
  assert.equal(elements(page.tree("AiAssistant")).filter(node => node.type === "h3" && text(node) === "常用问题").length, 0);
  assert.equal(elements(page.tree("AiAssistant")).filter(node => node.type === "button" && /^发送常用问题：/.test(node.props["aria-label"] ?? "")).length, 4);
  assert.equal(floating.snapshot("AiAssistant").props.showPrompts, true);
  assert.match(floating.popupHtml, /ea-agent-prompts|发送常用问题/);
  assert.equal(elements(floating.tree("AiAssistant")).filter(node => node.type === "button" && /^发送常用问题：/.test(node.props["aria-label"] ?? "")).length, 4);
  const question = "G5平台当前有什么问题？";
  floating.act(byAria(floating.tree("AiAssistant"), `发送常用问题：${question}`).props.onClick);
  assert.equal(floating.conversation.messages[0].text, question);
  assert.doesNotMatch(floating.popupHtml, /ea-agent-prompts|发送常用问题/);
});

test("historical Skill snapshots remain readable but page and floating sends ignore hidden selections", () => {
  const h = harness();
  const selected = { ...skills[4] };
  const send = h.conversation.send;
  h.act(h.conversation.selectSkill, selected);
  selected.name = "后续修改名称"; selected.category = "数据处理";
  h.act(send, "  自由任务如何处理？  ");
  const first = h.conversation.messages;
  assert.equal(first[0].skillName, "Bitmap 高评分");
  assert.equal(first[1].text, h.api.agentDemoReply("自由任务如何处理？", skills[4]));
  assert.match(first[1].text, /可验证的分析路径/);
  assert.match(h.html, /使用 Skill · Bitmap 高评分/);
  h.act(h.conversation.setDraft, "跨页面保留");
  h.navigate("floating");
  h.act(byAria(h.tree("EaAgent"), "打开 EA Agent 对话").props.onClick, { preventDefault() {} });
  assert.equal(h.mounted.includes("AgentSkillPicker"), false);
  assert.equal(h.conversation.draft, "跨页面保留");
  assert.doesNotMatch(h.popupHtml, /选择 Skill|ea-agent-skill-selection/);
  assert.doesNotMatch(h.popupHtml, /演示模式 · 示例回复，尚未连接真实 AI 服务/);
  h.act(h.conversation.selectSkill, skills[3]);
  h.act(h.snapshot("AiAssistant").props.onSend, "需要什么输入？");
  assert.equal(h.conversation.messages[2].skillName, undefined);
  h.navigate("page");
  assert.equal(h.conversation.activeSkill.name, "日报管理");
  assert.equal(h.mounted.includes("AgentSkillPicker"), false);
  h.act(h.snapshot("AiAssistant").props.onSend, "自由任务如何处理？");
  const messages = h.conversation.messages;
  assert.equal(messages[4].skillName, undefined);
  assert.equal(messages[5].text, h.api.agentDemoReply("自由任务如何处理？"));
  assert.deepEqual(plain(messages.slice(0, 2)), plain(first), "Selection/clear must not rewrite old messages");
  assert.deepEqual(plain(messages.map(message => message.id)), [1, 2, 3, 4, 5, 6]);
  assert.match(h.html, /使用 Skill · Bitmap 高评分/);
  assert.doesNotMatch(h.html, /使用 Skill · 日报管理/);
  assert.equal(harness({ mode: "hook" }).conversation.activeSkill, null);
});

test("management cards select through App and return to EA Agent without autosending or changing drafts/history", () => {
  for (const action of ["调用", "click", "Enter", " "]) {
    const h = harness(); let focused = 0; let stopped = 0;
    h.act(h.conversation.send, "调用之前的消息");
    const history = h.conversation.messages;
    h.act(h.conversation.setDraft, "调用后继续编辑");
    h.library(true);
    const before = h.updates.length;
    const card = cards(h.tree("SkillCenter")).find(node => node.key === "sk-003");
    const target = {};
    h.act(card.props.onKeyDown, { key: "Enter", target: {}, currentTarget: target, preventDefault() { throw new Error("Child key must not invoke card"); } });
    assert.equal(h.conversation.activeSkill, null);
    if (action === "调用") h.act(button(card, "调用").props.onClick, { stopPropagation() { stopped++; } });
    else if (action === "click") h.act(card.props.onClick);
    else h.act(card.props.onKeyDown, { key: action, target, currentTarget: target, preventDefault() {} });
    assert.equal(stopped, action === "调用" ? 1 : 0);
    assert.equal(h.mounted.includes("EaAgentPage"), true);
    assert.equal(h.mounted.includes("SkillCenter"), false);
    assert.equal(h.conversation.activeSkill.name, "日报管理");
    assert.equal(h.conversation.draft, "调用后继续编辑");
    assert.equal(h.conversation.messages, history, "Calling selects context, never autosends or executes a workflow");
    assert.ok(h.updates.slice(before).some(({ owner, name }) => owner === "useAgentConversation" && name === "activeSkill"));
    assert.ok(h.updates.slice(before).some(({ owner, name }) => owner === "App" && name === "view"));
    assert.deepEqual(plain(h.updates.at(-1).value), { kind: "page", page: "skills" });
    h.snapshot("AiAssistant").props.inputRef.current = { focus() { focused++; } };
    assert.equal(h.flushEffects("EaAgentPage"), 2, "Returning remounts the page focus and title synchronization effects");
    assert.equal(focused, 1);
  }
});

test("invoked library retains dedicated generic and DailyReport workspaces without changing active chat Skill", () => {
  const h = harness();
  h.act(h.conversation.selectSkill, skills[0]);
  const selected = h.conversation.activeSkill;
  h.library(true);
  const open = id => h.act(button(cards(h.tree("SkillCenter")).find(node => node.key === id), "打开工作区").props.onClick, { stopPropagation() {} });
  open("analysis-top");
  assert.equal(h.snapshot("SkillWorkspace").props.skill, skills[4]);
  assert.equal(h.snapshot("SkillWorkspace").props.embedded, false);
  assert.match(h.html, /<h1[^>]*>管理 Skill<\/h1>/);
  assert.equal(button(h.tree("SkillCenter"), "返回 EA Agent").props.onClick, h.snapshot("SkillCenter").props.onBackToAgent);
  assert.equal(h.conversation.activeSkill, selected);
  h.act(h.snapshot("SkillWorkspace").props.onBack);
  open("sk-003");
  const daily = one(h.tree("SkillCenter"), node => original(node) === h.api.DailyReportSkill, "DailyReport workspace");
  assert.equal(daily.props.skill, skills[3]); assert.equal(daily.props.embedded, false);
  assert.equal(h.conversation.activeSkill, selected);
  assert.match(h.html, /<h1[^>]*>管理 Skill<\/h1>/);
  assert.equal(h.mounted.includes("EaAgentPage"), false);
  assert.equal(h.popupHtml, "");
  h.act(daily.props.onBack);
  assert.equal(cardIds(h.tree("SkillCenter")).length, 4);
  assert.equal(h.conversation.messages.length, 0);
});

test("App management route keeps Sidebar skills active and clickable EA Agent breadcrumbs without remounting its conversation owner", () => {
  const h = harness();
  h.act(h.conversation.send, "路由之前的对话");
  h.act(h.conversation.setDraft, "页面返回后继续写");
  h.act(h.conversation.selectSkill, skills[0]);
  const history = h.conversation.messages; const selected = h.conversation.activeSkill;
  const owner = h.frame("App"); const hook = h.frame("useAgentConversation");
  for (const route of ["skills", "ai"]) {
    h.navigate(route);
    const page = h.frame("EaAgentPage");
    assert.equal(h.snapshot("EaAgentPage").props.conversation, h.conversation);
    const before = h.updates.length;
    h.library(true);
    h.flushEffects("App");
    assert.deepEqual(plain(owner.states.get("view")), { kind: "skill-management" });
    assert.equal(h.snapshot("Sidebar").props.active, "skills");
    const crumbs = h.snapshot("TopBar").props.breadcrumb;
    assert.deepEqual(plain(crumbs.map(item => item.label)), ["EA 平台", "EA Agent", "管理 Skill"]);
    assert.equal(crumbs[1].onClick, h.snapshot("SkillCenter").props.onBackToAgent);
    assert.equal(crumbs[2].onClick, undefined);
    const main = one(h.tree("App"), node => node.type === "main", "App main route outlet");
    assert.equal(elements(main).filter(node => original(node) === h.api.SkillCenter).length, 1);
    assert.equal(elements(main).some(node => original(node) === h.api.EaAgentPage || node.type === Dialog.Root), false);
    assert.equal(h.mounted.includes("EaAgentPage"), false);
    assert.equal(h.mounted.includes("AiAssistant"), false);
    assert.equal(h.snapshot("EaAgent").props.suspended, true);
    if (route === "skills") h.library(false);
    else h.act(crumbs[1].onClick);
    h.flushEffects("App");
    assert.deepEqual(plain(owner.states.get("view")), { kind: "page", page: "skills" });
    assert.equal(h.frame("App"), owner);
    assert.equal(h.frame("useAgentConversation"), hook);
    assert.notEqual(h.frame("EaAgentPage"), page, "The page really unmounts; only the App-owned hook persists");
    for (const name of ["App", "useAgentConversation", "EaAgentPage"]) {
      assert.deepEqual([...h.frame(name).states.keys()], slots[name].states);
      assert.deepEqual([...h.frame(name).refs.keys()], slots[name].refs);
    }
    assert.deepEqual(h.updates.slice(before).map(({ owner: name, name: state }) => [name, state]), [["App", "view"], ["App", "view"]]);
    assert.equal(h.conversation.messages, history);
    assert.equal(h.conversation.activeSkill, selected);
    assert.equal(h.conversation.draft, "页面返回后继续写");
  }
  assert.doesNotMatch(hookSource, /setMessages\(\[\]\)|setDraft\(""\)[^]*view/);
});

test("full-page list filters and workspace returns retain search/category; list and both workspaces expose the real return-to-Agent header", () => {
  for (const id of [null, "analysis-top", "sk-003"]) {
    const h = harness();
    h.act(h.conversation.send, "保留已有消息");
    h.act(h.conversation.setDraft, "不因管理跳转清空");
    const history = h.conversation.messages;
    h.library(true);
    const item = skills.find(item => item.id === (id ?? "analysis-top"));
    const search = value => h.act(byAria(h.tree("SkillCenter"), "搜索 Skill").props.onChange, { target: { value } });
    search("不存在的 Skill");
    h.act(button(h.tree("SkillCenter"), item.category).props.onClick);
    assert.match(h.html, /没有匹配的已上线技能/);
    search(item.name);
    assert.deepEqual(cardIds(h.tree("SkillCenter")), [item.id]);
    assert.equal(button(h.tree("SkillCenter"), item.category).props["aria-pressed"], true);
    const checkHeader = () => {
      assert.match(h.html, /<h1[^>]*>管理 Skill<\/h1>/);
      const heading = one(h.tree("SkillCenter"), node => node.type === "h1", "management heading");
      assert.equal(heading.props.tabIndex, -1);
      assert.equal(text(heading), "管理 Skill");
      assert.equal(button(h.tree("SkillCenter"), "返回 EA Agent").props.onClick, h.snapshot("SkillCenter").props.onBackToAgent);
      assert.doesNotMatch(h.html, /role="dialog"|aria-modal|ea-agent-skills-overlay|ea-agent-header-logo/);
      assert.equal(h.popupHtml, "");
    };
    checkHeader();
    if (id) {
      const open = () => h.act(button(cards(h.tree("SkillCenter"))[0], "打开工作区").props.onClick, { stopPropagation() {} });
      open(); checkHeader();
      const workspace = id === "sk-003"
        ? one(h.tree("SkillCenter"), node => original(node) === h.api.DailyReportSkill, "DailyReport workspace").props
        : h.snapshot("SkillWorkspace").props;
      assert.equal(workspace.skill, item);
      assert.equal(workspace.embedded, false);
      h.act(workspace.onBack);
      checkHeader();
      assert.equal(byAria(h.tree("SkillCenter"), "搜索 Skill").props.value, item.name);
      assert.equal(button(h.tree("SkillCenter"), item.category).props["aria-pressed"], true);
      assert.deepEqual(cardIds(h.tree("SkillCenter")), [item.id]);
      open(); checkHeader();
    }
    const before = h.updates.length;
    h.library(false);
    assert.deepEqual(h.updates.slice(before).map(({ owner, name }) => [owner, name]), [["App", "view"]]);
    assert.doesNotMatch(h.html, /<h1>EA Agent<\/h1>|ea-agent-skill-manage/);
    assert.equal(h.conversation.messages, history);
    assert.equal(h.conversation.draft, "不因管理跳转清空");
    assert.equal(h.conversation.activeSkill, null);
  }
});

test("management title focus effect depends only on management mode and active Skill, never search/category or callback identity", () => {
  const body = functionSource(capturedSources.SkillCenter, "SkillCenter");
  assert.match(body, /useEffect\(\(\) => \{ if \(managementPage\) managementTitle\.current\?\.focus\(\{ preventScroll: true \}\); \}, \[managementPage, activeSkill\?\.id\]\)/);
  assert.match(body, /ref=\{managementTitle\}/);
  assert.doesNotMatch(body, /ref=\{\s*(?:\([^)]*\)|\w+)\s*=>/);
  const h = harness();
  h.library(true);
  const calls = [];
  h.frame("SkillCenter").refs.get("managementTitle").current = { focus(options) { calls.push(plain(options)); } };
  // SSR has no DOM focus: explicitly run the source effect on a ref spy. This
  // verifies scheduling/callback behavior, not browser-computed activeElement.
  assert.equal(h.flushEffects("SkillCenter"), 1);
  assert.deepEqual(calls, [{ preventScroll: true }]);
  const originalBack = h.snapshot("SkillCenter").props.onBackToAgent;
  for (const value of ["b", "bi", "bitmap"]) {
    h.act(byAria(h.tree("SkillCenter"), "搜索 Skill").props.onChange, { target: { value } });
    assert.equal(byAria(h.tree("SkillCenter"), "搜索 Skill").props.value, value);
    assert.equal(h.flushEffects("SkillCenter"), 0);
  }
  assert.notEqual(h.snapshot("SkillCenter").props.onBackToAgent, originalBack, "App recreates callbacks without refocusing the title");
  h.act(button(h.tree("SkillCenter"), "失效分析").props.onClick);
  assert.equal(h.flushEffects("SkillCenter"), 0);
  h.act(button(cards(h.tree("SkillCenter"))[0], "打开工作区").props.onClick, { stopPropagation() {} });
  assert.equal(h.flushEffects("SkillCenter"), 1);
  h.act(h.snapshot("SkillWorkspace").props.onBack);
  assert.equal(h.flushEffects("SkillCenter"), 1);
  assert.equal(byAria(h.tree("SkillCenter"), "搜索 Skill").props.value, "bitmap");
  assert.deepEqual(calls, Array.from({ length: 3 }, () => ({ preventScroll: true })));
  for (const embedded of [undefined, true]) {
    const legacy = harness({ mode: "skills", embedded }); let focused = 0;
    legacy.frame("SkillCenter").refs.get("managementTitle").current = { focus() { focused++; } };
    legacy.flushEffects("SkillCenter");
    assert.equal(focused, 0, "Legacy non-management mounts must not steal focus");
  }
});

test("Skill dispatch uses category/name before generic keywords and preserves published/max/id guards", () => {
  const h = harness({ mode: "hook" });
  const cases = [
    [skills[4], /可验证的分析路径/],
    [skill("timing", "测试程式 timing 体检", "测试自动化", 0, 0), /setup\/hold/],
    [skill("yield", "良率异常波动预警", "数据处理", 0, 0), /统计口径/],
    [skills[3], /按日期提供工作笔记/],
    [skill("report", "报告结构", "报告生成", 0, 0), /Workspace 文档/],
    [skill("knowledge", "EA 知识库智能问答", "知识问答", 0, 0), /资料版本和证据来源/],
    [skill("other", "自定义 Skill", "其他", 0, 0), /可以按这条路径处理任务/],
  ];
  for (const [item, expected] of cases) {
    h.act(h.conversation.selectSkill, item);
    const before = h.conversation.messages;
    h.act(h.conversation.selectSkill, skills[1]);
    assert.equal(h.conversation.activeSkill.name, item.name, "Unpublished Skill cannot replace context");
    h.act(h.conversation.setDraft, "保留");
    h.act(h.conversation.send, "  ");
    h.act(h.conversation.send, "x".repeat(h.api.AGENT_MAX_MESSAGE + 1));
    assert.equal(h.conversation.messages, before); assert.equal(h.conversation.draft, "保留");
    h.act(h.conversation.send, "  自由任务如何处理？  ");
    const reply = h.conversation.messages.at(-1);
    assert.match(reply.text, expected);
    assert.match(reply.text, /仅本地 Skill 指引，未调用真实 AI 服务/);
    assert.doesNotMatch(reply.text, /已处理你的需求|已生成结构化初稿|检测到 3 个|异常主要集中在 FT2|已从历史 Case 与 SOP 中整理/);
    assert.equal(reply.skillName, item.name);
  }
  assert.deepEqual(plain(h.conversation.messages.map(message => message.id)), Array.from({ length: cases.length * 2 }, (_, index) => index + 1));
  assert.deepEqual(h.forbiddenCalls, []);
});

// Inspect actual declaration blocks rather than pretending SSR computes CSS.
function block(body, selector) {
  const start = body.indexOf(`${selector} {`);
  assert.ok(start >= 0, `Missing block ${selector}`);
  const open = body.indexOf("{", start); let depth = 1; let end = open + 1;
  for (; end < body.length && depth; end++) { if (body[end] === "{") depth++; if (body[end] === "}") depth--; }
  assert.equal(depth, 0, `Unclosed block ${selector}`);
  return body.slice(open + 1, end - 1);
}
const baseCss = css.slice(0, css.indexOf("@media (prefers-reduced-motion"));
function declarations(selector, body = baseCss) {
  const rules = [...body.matchAll(/([^{}]+)\{([^{}]*)\}/g)].filter(match => match[1].split(",").map(value => value.trim()).includes(selector));
  assert.equal(rules.length, 1, `Expected one declaration block for ${selector}`);
  return Object.fromEntries(rules[0][2].split(";").filter(value => value.trim()).map(value => {
    const colon = value.indexOf(":"); return [value.slice(0, colon).trim(), value.slice(colon + 1).trim()];
  }));
}

test("legacy picker styling remains available to SkillCenter but neither chat surface mounts the picker", () => {
  const selection = declarations(".ea-agent-skill-selection");
  assert.equal(selection.display, "inline-flex"); assert.equal(selection.flex, "none");
  assert.equal(selection.width, "232px"); assert.equal(selection["max-width"], "100%");
  assert.equal(selection.height, "28px");
  const selected = declarations(".ea-agent-skill-selection.is-selected");
  assert.equal(selected.color, "#0052d9");
  assert.notEqual(selected.background, selection.background);
  assert.notEqual(selected["border-color"], undefined);
  for (const property of ["width", "height", "flex", "padding", "margin"]) assert.equal(selected[property], undefined);
  const triggerRule = declarations(".ea-agent-skill-selection .ea-agent-skill-trigger");
  assert.equal(triggerRule.flex, "1"); assert.equal(triggerRule["min-width"], "0");
  assert.equal(triggerRule.height, "26px"); assert.equal(triggerRule.border, "0");
  const nameRule = declarations(".ea-agent-skill-selection-name");
  for (const [property, value] of Object.entries({ flex: "1", "min-width": "0", overflow: "hidden", "white-space": "nowrap", "text-overflow": "ellipsis" })) assert.equal(nameRule[property], value);
  assert.equal(declarations(".ea-agent-skill-selection .ea-agent-skill-trigger svg").flex, "none");
  const clearRule = declarations(".ea-agent-skill-clear");
  assert.equal(clearRule.width, "22px"); assert.equal(clearRule.height, "22px");
  assert.equal(clearRule.flex, "none"); assert.equal(clearRule.display, "grid");
  assert.equal(clearRule["margin-right"], "3px");
  assert.deepEqual(declarations(".ea-agent-skill-clear:disabled"), { visibility: "hidden" }, "Hide without removing the reserved clear slot");
  assert.doesNotMatch(css + capturedSources.AgentSkillPicker, /ea-agent-selected-skill/);

  const page = harness(); const floating = floatingHarness();
  for (const h of [page, floating]) {
    assert.equal(h.mounted.includes("AgentSkillPicker"), false);
    assert.equal(h.snapshot("AiAssistant").props.composerTools, undefined);
  }
  assert.equal(page.snapshot("AiAssistant").props.showPrompts, true);
  assert.equal(floating.snapshot("AiAssistant").props.showPrompts, true);
});

test("conversation and composer use the same bounded width, responses use an orb and no management header returns on selection", () => {
  assert.doesNotMatch(css, /\.ea-agent-page-header|\.ea-agent-skill-manage/);
  assert.equal(declarations(".ea-agent-page").background, "radial-gradient(ellipse at top left,#f7faff,#fff 60%)");
  assert.equal(declarations(".ea-agent-session-sidebar").background, "#f8fafc");
  assert.equal(declarations(".ea-agent-page-main").background, "transparent");
  assert.equal(declarations(".ea-agent-page .ea-agent-composer").background, "#fcfdff");
  assert.equal(declarations(".ea-agent-page .ea-agent-composer textarea").height, "44px");
  assert.equal(declarations(".ea-agent-compose").padding, "12px 15px 18px");
  assert.equal(declarations(".ea-agent-panel.is-expanded .ea-agent-compose").padding, "17px 28px 26px");
  assert.equal(declarations(".ea-agent-page .ea-agent-compose").padding, "14px 32px 20px");
  assert.equal(declarations(".ea-agent-compose")["border-top"], undefined);
  assert.equal(declarations(".ea-agent-page .ea-agent-compose")["border-top"], undefined);
  assert.doesNotMatch(capturedSources.AgentSessionControls, /currentUser|ea-agent-sidebar-user|>EA Agent<|PTE Engineer/);
  assert.equal(declarations(".ea-agent-conversation")["max-width"], "760px");
  assert.equal(declarations(".ea-agent-composer")["max-width"], "760px");
  assert.equal(declarations(".ea-agent-message.is-ai").width, "100%");
  assert.equal(declarations(".ea-agent-message-orb").width, "28px");
  assert.equal(declarations(".ea-agent-message-label")["font-size"], "12px");
  assert.equal(declarations(".ea-agent-message-label")["font-weight"], "600");
  assert.equal(declarations(".ea-agent-page .ea-agent-message-label")["font-size"], "13px");
  assert.equal(declarations(".ea-agent-page .has-messages .ea-agent-conversation").margin, "0 auto");
  const toolsRule = declarations(".ea-agent-composer-skills");
  assert.equal(toolsRule.display, "flex"); assert.equal(toolsRule["justify-content"], "flex-start");
  assert.doesNotMatch(css, /\.ea-agent-skills-(?:dialog|overlay|header|body|close)\b/);
  assert.equal(declarations(".ea-agent-page").height, "100%");

  const h = harness();
  for (const item of [null, skills[4], null]) {
    h.act(h.conversation.selectSkill, item);
    assert.equal(elements(h.tree("EaAgentPage")).some(node => node.type === "header" || node.type === "h1"), false);
    const tools = h.snapshot("AiAssistant").props.composerTools;
    assert.equal(tools, undefined, "Historical selection does not restore a picker on the page");
    const composer = one(h.tree("AiAssistant"), node => node.props.className === "ea-agent-composer", "composer");
    assert.equal(elements(composer).some(node => [Dialog.Root, Dialog.Trigger, Dialog.Content, h.api.SkillCenter].includes(original(node)) || node.props.className === "ea-agent-skill-manage"), false);
    assert.equal(elements(composer).some(node => node.props.className === "ea-agent-composer-skills"), false);
    assert.equal((h.html.match(/class="ea-agent-skill-manage"/g) ?? []).length, 0);
    h.library(true);
    assert.equal(h.mounted.includes("EaAgentPage"), false);
    assert.equal(h.snapshot("SkillCenter").props.embedded, undefined);
    assert.equal(h.popupHtml, "");
    assert.equal(typeof h.snapshot("SkillCenter").props.onSelectSkill, "function");
    h.library(false);
    assert.equal(h.conversation.messages.length, 0);
    assert.equal(h.conversation.activeSkill?.name ?? null, item?.name ?? null);
  }
});

test("welcome CSS keeps 88px/96px sizing and continuous aura, flow, color and sweep without hover", () => {
  for (const [selector, size] of [[".ea-agent-welcome-orb", "88px"], [".ea-agent-page .ea-agent-welcome-orb", "96px"]]) {
    const rule = declarations(selector); assert.equal(rule.width, size); assert.equal(rule.height, size);
  }
  assert.match(declarations(".ea-agent-orb-aura").animation, /^ea-orb-breathe .*infinite$/);
  assert.match(declarations(".ea-agent-orb-flow").animation, /^ea-orb-flow .*infinite alternate$/);
  assert.equal(declarations(".ea-agent-welcome-orb .ea-agent-orb-interaction").opacity, "1");
  for (const layer of ["colors", "sweep"]) assert.equal(declarations(`.ea-agent-welcome-orb .ea-agent-orb-${layer}`)["animation-play-state"], "running");
  assert.match(block(baseCss, "@keyframes ea-orb-breathe"), /scale\(\.95\)[\s\S]*scale\(1\.16\)/);
  assert.match(block(baseCss, "@keyframes ea-orb-flow"), /rotate\(-9deg\)[\s\S]*rotate\(15deg\)/);
  assert.match(block(baseCss, "@keyframes ea-orb-colors"), /rotate\(0deg\)[\s\S]*rotate\(360deg\)/);
  assert.match(block(baseCss, "@keyframes ea-orb-sweep"), /translateX\(-75px\)[\s\S]*translateX\(75px\)/);
  assert.doesNotMatch(baseCss, /[^{}]*ea-agent-welcome-orb[^{}]*:(?:hover|focus)[^{}]*\{/);
  assert.equal(declarations(".ea-agent-header-logo .ea-agent-orb-aura").animation, "none");
  assert.equal(declarations(".ea-agent-nav-logo .ea-agent-orb-flow").animation, "none");
});

test("reduced motion and forced colors remain global while floating hover, drag and hidden guards stay intact", () => {
  const reduced = block(css, "@media (prefers-reduced-motion:reduce)");
  for (const selector of [".ea-agent-orb", ".ea-agent-orb *"]) {
    assert.equal(declarations(selector, reduced).animation, "none !important");
    assert.equal(declarations(selector, reduced).transition, "none !important");
  }
  assert.equal(declarations(".ea-agent-orb-sweep", reduced).display, "none");
  const forced = block(css, "@media (forced-colors:active)");
  for (const layer of ["aura", "ground", "interaction"]) assert.equal(declarations(`.ea-agent-orb-${layer}`, forced).display, "none");
  assert.deepEqual(declarations(".ea-agent-orb-shell", forced), { fill: "Canvas", stroke: "CanvasText", "stroke-width": "2" });
  assert.equal(declarations(".ea-agent-orb-rim", forced).stroke, "CanvasText");
  const guard = ".ea-agent-launcher:not(.is-dragging):not([hidden]):is(:hover,:focus-visible)";
  // :is() contains a comma, so use the intact block for these guarded selectors.
  assert.match(block(baseCss, `${guard} .ea-agent-orb-interaction`), /opacity:1/);
  const run = block(baseCss, `${guard} .ea-agent-orb-sweep`);
  assert.match(run, /animation-play-state:running/);
  assert.ok(baseCss.includes(`${guard} .ea-agent-orb-colors,\n${guard} .ea-agent-orb-sweep`));
  for (const layer of ["colors", "sweep"]) assert.match(declarations(`.ea-agent-orb-${layer}`).animation, /infinite paused$/);
  for (const selector of [".ea-agent-launcher.is-dragging .ea-agent-orb *", ".ea-agent-launcher[hidden] .ea-agent-orb *"]) assert.equal(declarations(selector)["animation-play-state"], "paused");
  assert.equal(declarations(".ea-agent-logo").transform, "none");
  assert.equal(declarations(".ea-agent-logo").width, "64px");
  assert.equal(declarations(".ea-agent-launcher").width, "64px");
  assert.doesNotMatch(baseCss, /[^{}]*:hover[^{}]*\.ea-agent-logo\s*\{[^}]*transform:/);
});