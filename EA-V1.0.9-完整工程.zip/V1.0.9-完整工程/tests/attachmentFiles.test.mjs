import assert from "node:assert/strict";
import { fileURLToPath } from "node:url";
import vm from "node:vm";
import test from "node:test";
import { build } from "esbuild";

const { outputFiles } = await build({ entryPoints: [fileURLToPath(new URL("../src/app/components/attachmentFiles.ts", import.meta.url))], bundle: true, write: false, platform: "node", format: "cjs" });
const context = { module: { exports: {} }, FileReader: class {
  readAsDataURL(file) {
    queueMicrotask(() => {
      if (file.fail) { this.onerror(); return; }
      if (file.abort) { this.onabort(); return; }
      this.result = file.invalid ? null : `data:${file.type || "application/octet-stream"};base64,${Buffer.from(file.content || "").toString("base64")}`;
      this.onload();
    });
  }
} };
vm.runInNewContext(outputFiles[0].text, context);
const { attachmentKind, readAttachmentFiles } = context.module.exports;

test("dropped and selected file batches retain names, types, contents and order", async () => {
  const files = [{ name: "说明.txt", type: "text/plain", content: "说明" }, { name: "报告.PDF", type: "", content: "pdf" }, { name: "数据.CSV", type: "", content: "a,b" }, { name: "图.PNG", type: "", content: "png" }];
  const result = JSON.parse(JSON.stringify(await readAttachmentFiles(files)));
  assert.deepEqual(result.map(file => file.name), files.map(file => file.name));
  assert.deepEqual(result.map(file => file.kind), ["file", "pdf", "sheet", "image"]);
  result.forEach((file, index) => assert.equal(Buffer.from(file.url.split(",")[1], "base64").toString(), files[index].content));
  assert.equal(attachmentKind({ name: "blob", type: "image/jpeg" }), "image");
  assert.equal(attachmentKind({ name: "sheet", type: "application/vnd.ms-excel" }), "sheet");
});

test("failed, aborted or invalid reads reject the batch without submitting partial attachments and can retry", async () => {
  for (const mode of ["fail", "abort", "invalid"]) {
    let commits = 0;
    await assert.rejects(async () => { await readAttachmentFiles([{ name: "ok.txt", type: "text/plain" }, { name: "坏文件.txt", type: "text/plain", [mode]: true }]); commits += 1; }, /无法读取附件「坏文件.txt」/);
    assert.equal(commits, 0);
  }
  assert.equal((await readAttachmentFiles([{ name: "retry.txt", type: "text/plain" }])).length, 1);
  assert.equal((await readAttachmentFiles([])).length, 0);
});