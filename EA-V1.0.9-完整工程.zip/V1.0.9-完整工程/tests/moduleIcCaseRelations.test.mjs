import assert from "node:assert/strict";
import { webcrypto } from "node:crypto";
import { fileURLToPath } from "node:url";
import vm from "node:vm";
import test from "node:test";
import { build } from "esbuild";

const { outputFiles } = await build({
  stdin: { contents: `export * from './src/app/components/domainStore.ts'; export {mockCases} from './src/app/components/data.ts';`, resolveDir: fileURLToPath(new URL("../", import.meta.url)) },
  bundle: true, write: false, platform: "node", format: "cjs",
  plugins: [{ name: "react-hooks", setup(builder) {
    builder.onResolve({ filter: /^react$/ }, () => ({ path: "react", namespace: "test" }));
    builder.onLoad({ filter: /.*/, namespace: "test" }, () => ({ contents: "export const useEffect=()=>{}; export const useState=()=>[0,()=>{}];" }));
  } }],
});
const KEY = "ea_domain_v6";
const input = (name, material, extra = {}) => ({ name, material, owner: "张伟", createdBy: "张伟", level: "L3", urgency: "一般", reason: "测试", background: "模组拆解IC关联测试", source: "手动", tasks: [], ...extra });
function environment() {
  const storage = new Map(); let fail = false;
  const boot = () => {
    const context = { module: { exports: {} }, crypto: webcrypto, btoa, atob, localStorage: {
      getItem: (key) => storage.get(key) ?? null,
      setItem: (key, value) => { if (fail) throw new Error("quota"); storage.set(key, value); },
    } };
    vm.runInNewContext(outputFiles[0].text, context);
    const api = context.module.exports; api.allCaseLinks(); return api;
  };
  return { storage, boot, fail: (value) => { fail = value; } };
}
function pair(api, from, to) { return api.linksOfCase(from).filter((l) => (l.from === from && l.to === to) || (l.from === to && l.to === from)); }
function assertMutual(api, sourceId, childId) {
  assert.equal(pair(api, sourceId, childId).length, 1);
  assert.equal(pair(api, childId, sourceId).length, 1);
  assert.ok(api.mockCases.find((c) => c.id === sourceId).relatedCaseIds.includes(childId));
  assert.ok(api.mockCases.find((c) => c.id === childId).relatedCaseIds.includes(sourceId));
}

for (const material of ["DIMM", "CAMM"]) test(`${material}: every split IC links both ways before navigation and after reload`, () => {
  const env = environment(); const api = env.boot();
  const parent = api.createManualCase(input("来源模组", material));
  const children = ["Die/IC", "IC", "Chip"].map((mat, index) => api.createManualCase(input(`拆出IC-${index}`, mat, { sourceModuleCaseId: parent.id })));
  for (const child of children) assertMutual(api, parent.id, child.id);
  assert.equal(pair(api, children[0].id, children[1].id).length, 0, "do not create unrelated sibling links");
  const stored = JSON.parse(env.storage.get(KEY));
  assert.equal(stored.spawnedCases.find((c) => c.id === parent.id).relatedCaseIds.length, 3);
  const reload = env.boot();
  for (const child of children) assertMutual(reload, parent.id, child.id);
  // Existing form-level linking must not duplicate an automatically created reverse edge.
  reload.bindRelatedCases([children[0].id, parent.id]); reload.linkCases(children[0].id, parent.id, "关联");
  assert.equal(pair(reload, parent.id, children[0].id).length, 1);
});

test("legacy one-sided related/parent/child fields restore module-IC links once, without name guessing", () => {
  const env = environment(); const api = env.boot();
  const parent = api.createManualCase(input("旧模组", "CAMM"));
  const children = [0, 1, 2, 3].map((n) => api.createManualCase(input(`旧IC-${n}`, "Die/IC")));
  const unrelated = api.createManualCase(input("旧模组 · 名称相同并不关联", "IC"));
  const legacy = JSON.parse(env.storage.get(KEY)); delete legacy.moduleIcRelationsVersion;
  const p = legacy.spawnedCases.find((c) => c.id === parent.id);
  legacy.spawnedCases.find((c) => c.id === children[0].id).parentCaseId = parent.id;
  legacy.spawnedCases.find((c) => c.id === children[1].id).relatedCaseIds = [parent.id];
  p.childCaseIds = [children[2].id]; p.relatedCaseIds = [children[3].id];
  env.storage.set(KEY, JSON.stringify(legacy));
  const reloaded = env.boot();
  for (const child of children) assertMutual(reloaded, parent.id, child.id);
  assert.equal(pair(reloaded, parent.id, unrelated.id).length, 0);
  assert.equal(JSON.parse(env.storage.get(KEY)).moduleIcRelationsVersion, 1);
  const edgeCount = reloaded.allCaseLinks().length;
  assert.equal(env.boot().allCaseLinks().length, edgeCount);
});

test("existing reverse/duplicate relation is not duplicated or relabeled", () => {
  const env = environment(); const api = env.boot();
  const parent = api.createManualCase(input("来源", "DIMM"));
  const child = api.createManualCase(input("IC", "IC"));
  const legacy = JSON.parse(env.storage.get(KEY)); delete legacy.moduleIcRelationsVersion;
  legacy.spawnedCases.find((c) => c.id === child.id).sourceModuleCaseId = parent.id;
  legacy.caseLinks.push({ from: child.id, to: parent.id, type: "重复", note: "保留原标注" });
  env.storage.set(KEY, JSON.stringify(legacy));
  const reload = env.boot(); assertMutual(reload, parent.id, child.id);
  assert.equal(pair(reload, parent.id, child.id)[0].type, "重复");
});

test("unrelated material and Fanout paths are unchanged", () => {
  const env = environment(); const api = env.boot();
  const parent = api.createManualCase(input("模组", "DIMM"));
  const module = api.createManualCase(input("模块子Case", "DIMM", { sourceModuleCaseId: parent.id }));
  const fanout = api.createManualCase(input("Fanout", "IC", { sourceModuleCaseId: parent.id, source: "fanout验证" }));
  assert.equal(pair(api, parent.id, module.id).length, 0); assert.equal(pair(api, parent.id, fanout.id).length, 0);
});

test("failed IC creation leaves no phantom Case or half-saved association", () => {
  const env = environment(); const api = env.boot();
  const parent = api.createManualCase(input("来源", "DIMM"));
  const before = env.storage.get(KEY); const count = api.mockCases.length; const links = api.allCaseLinks().length;
  env.fail(true);
  assert.throws(() => api.createManualCase(input("失败IC", "IC", { sourceModuleCaseId: parent.id })), /未能保存新 Case 及来源关联/);
  assert.equal(env.storage.get(KEY), before); assert.equal(api.mockCases.length, count); assert.equal(api.allCaseLinks().length, links);
  assert.equal(parent.relatedCaseIds, undefined);
  env.fail(false); const child = api.createManualCase(input("重试IC", "IC", { sourceModuleCaseId: parent.id }));
  assertMutual(env.boot(), parent.id, child.id);
});

test("explicit unlink removes both sides and is not resurrected after reload", () => {
  const env = environment(); const api = env.boot(); const parent = api.createManualCase(input("来源", "CAMM"));
  const child = api.createManualCase(input("IC", "IC", { sourceModuleCaseId: parent.id }));
  api.unlinkCases(child.id, parent.id);
  const reload = env.boot(); assert.equal(pair(reload, parent.id, child.id).length, 0);
  assert.ok(!reload.mockCases.find((c) => c.id === parent.id).relatedCaseIds.includes(child.id));
  assert.ok(!reload.mockCases.find((c) => c.id === child.id).relatedCaseIds.includes(parent.id));
});