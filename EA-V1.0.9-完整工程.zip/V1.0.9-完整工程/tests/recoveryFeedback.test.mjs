import test from 'node:test';import assert from 'node:assert/strict';import {build} from 'esbuild';import vm from 'node:vm';import {fileURLToPath} from 'node:url';import {webcrypto} from 'node:crypto';
const {outputFiles}=await build({stdin:{contents:"export * from './recoveryFeedback';export {currentUser} from './data';export {vpRecoveryExamples} from './vpRecoveryExamples';",resolveDir:fileURLToPath(new URL('../src/app/components/',import.meta.url))},bundle:true,write:false,platform:'node',format:'cjs',plugins:[{name:'hooks',setup(builder){builder.onResolve({filter:/^react$/},()=>({path:'react',namespace:'mock'}));builder.onLoad({filter:/.*/,namespace:'mock'},()=>({contents:'export const useEffect=()=>{};export const useState=()=>[0,()=>{}];'}));}}]});
function setup(){const storage=new Map();const box={module:{exports:{}},crypto:webcrypto,btoa,atob,localStorage:{getItem:key=>storage.get(key)??null,setItem:(key,value)=>storage.set(key,value)}};vm.runInNewContext(outputFiles[0].text,box);return box.module.exports;}
const row=(extra={})=>({key:'case:a:r',target:{kind:'case',caseId:'a'},owner:'张伟',returns:1,status:'进行中',entry:{id:'r',kind:'return',by:'高总监',recipients:['张伟'],reason:'补充对照',at:'2026-09-10T08:00:00',...extra}});
test('alerts respect actual dates, no-deadline records, submission and configurable inactivity',()=>{const api=setup(),now=new Date('2026-09-20T12:00:00');assert.equal(api.recoveryAlerts(row(),undefined,now).some(item=>item.label.startsWith('超期')),false);assert.equal(api.recoveryAlerts(row({dueDate:'2026-09-19'}),undefined,now)[0].label,'超期 1 天');assert.equal(api.recoveryAlerts(row({dueDate:'2026-09-20'}),undefined,now)[0].label,'今日到期');assert.equal(api.recoveryAlerts(row({submittedAt:'2026-09-18'}),undefined,now).length,0);assert.equal(api.recoveryAlerts(row({lastEditedAt:'2026-09-19'}),undefined,now).length,0);assert.equal(api.recoveryProgress(row()),'待处理');assert.equal(api.recoveryProgress(row({startedAt:'2026-09-19'})),'处理中');});
test('feedback read status is per-user and per-submission, never confirmation',()=>{const api=setup(),value=row({submittedAt:'2026-09-20',after:{conclusion:'新结果'},before:{conclusion:'旧结果'}});api.currentUser.name='高总监';assert.equal(api.feedbackUnread(value),true);api.markFeedbackRead(value);assert.equal(api.feedbackUnread(value),false);assert.equal(value.entry.confirmedAt,undefined);assert.equal(api.feedbackUnread({...value,entry:{...value.entry,submittedAt:'2026-09-21'}}),true);api.currentUser.name='张伟';assert.equal(api.feedbackUnread(value),true);api.currentUser.name='马总监';assert.throws(()=>api.markFeedbackRead(value),/无权/);});
test('manager-only policy saves are bounded and modifying reminders does not mutate business records',()=>{const api=setup();assert.throws(()=>api.setReminderPolicy({dueSoonDays:1,inactiveDays:7,repeatCount:2}),/管理者/);api.currentUser.name='高总监';api.setReminderPolicy({dueSoonDays:2,inactiveDays:5,repeatCount:3});assert.equal(api.reminderPolicy().inactiveDays,5);assert.throws(()=>api.setReminderPolicy({dueSoonDays:-1,inactiveDays:5,repeatCount:3}),/范围/);});
test('Case-only return selection excludes legacy free feedback and notifications without deleting history',()=>{
	const api=setup();api.currentUser.name='高总监';const caseRow=row();const taskRow={...row(),key:'task:a:r',target:{kind:'task',caseId:'a',taskId:'task'}};
	const legacy={...row({submittedAt:'2026-09-20'}),key:'free:a:r',target:{kind:'standalone',taskId:'free'}};const original=JSON.stringify(legacy);
	const rows=[caseRow,taskRow,legacy,row({kind:'reopen'}),row({by:'周主管'})];
	assert.deepEqual(Array.from(api.selectMyReturns(rows),item=>item.key),['case:a:r','task:a:r']);assert.equal(api.selectMyReturns(rows).filter(item=>api.feedbackUnread(item)).length,0);
	assert.equal(api.recoveryNotification(legacy,api.DEFAULT_REMINDERS),null);assert.equal(JSON.stringify(legacy),original);
	assert.ok(api.recoveryNotification({...legacy,entry:{...legacy.entry,kind:'reopen'}},api.DEFAULT_REMINDERS));
});

test('VP overview partitions six examples into matching exclusive groups and reading feedback changes only unread state',()=>{
	const api=setup();api.currentUser.name='林副总';const now=new Date('2026-09-21T12:00:00');
	const examples=api.vpRecoveryExamples.map(({caseItem,closure})=>({key:caseItem.id,title:caseItem.name,code:caseItem.code,owner:caseItem.owner,target:{kind:'case',caseId:caseItem.id},record:closure,status:caseItem.status,returns:1,entry:closure.recovery[0]}));
	const before=JSON.stringify(examples);const overview=api.recoveryOverview(examples,api.DEFAULT_REMINDERS,'',now);
	assert.deepEqual(JSON.parse(JSON.stringify(overview.counts)),{following:2,feedback:2,overdue:2});
	const keys=Object.values(overview.groups).flat().map(item=>item.key);assert.equal(new Set(keys).size,6);assert.equal(keys.length,overview.rows.length);
	const submitted=overview.groups.feedback[0];api.markFeedbackRead(submitted);assert.equal(api.feedbackUnread(submitted),false);
	assert.deepEqual(JSON.parse(JSON.stringify(api.recoveryOverview(examples,api.DEFAULT_REMINDERS,'',now).counts)),{following:2,feedback:2,overdue:2});
	const search=api.recoveryOverview(examples,api.DEFAULT_REMINDERS,'CP 漏检',now);assert.equal(search.rows.length,1);assert.equal(search.counts.feedback,1);assert.equal(search.counts.following+search.counts.overdue,0);assert.equal(JSON.stringify(examples),before);
});

test('due dates and rejected reclosure determine exactly one follow-up group',()=>{
	const api=setup();const now=new Date('2026-09-21T12:00:00');
	assert.equal(api.recoveryCategory(row({dueDate:'2026-09-21'}),undefined,now),'following');
	assert.equal(api.recoveryCategory(row({dueDate:'2026-09-20'}),undefined,now),'overdue');
	assert.equal(api.recoveryCategory(row(),undefined,now),'following');
	const submitted=row({dueDate:'2026-09-20',submittedAt:'2026-09-19'});assert.equal(api.recoveryCategory(submitted,undefined,now),'feedback');
	assert.equal(api.recoveryCategory({...submitted,approvalRejected:true},undefined,now),'overdue');
	assert.equal(api.recoveryCategory({...submitted,approvalRejected:true,entry:{...submitted.entry,dueDate:'2026-09-23'}},undefined,now),'following');
	assert.equal(api.recoveryCategory({...submitted,approvalRejected:true,entry:{...submitted.entry,completedAt:'2026-09-20'}},undefined,now),'feedback');
});