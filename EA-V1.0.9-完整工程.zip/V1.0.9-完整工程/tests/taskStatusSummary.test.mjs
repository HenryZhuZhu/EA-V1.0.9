import test from "node:test";
import assert from "node:assert/strict";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";
import vm from "node:vm";
import { build } from "esbuild";
import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";

const { outputFiles } = await build({
  entryPoints: [fileURLToPath(new URL("../src/app/components/TaskStatusSummary.tsx", import.meta.url))],
  bundle: true, write: false, platform: "node", format: "cjs", jsx: "automatic",
  external: ["react", "react/jsx-runtime"],
});
const sandbox = { module: { exports: {} }, require: createRequire(import.meta.url) };
vm.runInNewContext(outputFiles[0].text, sandbox);
const { TaskStatusSummary } = sandbox.module.exports;
const counts = { 待接受: 12, 进行中: 8, 已完成: 3 };
const render = (status, scope = "mine") => renderToStaticMarkup(createElement(TaskStatusSummary, { counts, status, scope, onChange() {} }));

test("status summaries retain the V1.0.7 vertical layout and selected/unselected visual contract", () => {
  for (const status of ["待接受", "进行中", "已完成"]) {
    const html = render(status);
    assert.equal((html.match(/<button /g) ?? []).length, 3);
    assert.ok(html.includes("grid-cols-[minmax(0,2fr)_minmax(0,2fr)_minmax(0,1fr)]"));
    assert.equal((html.match(/px-\[18px\] pt-\[15px\] pb-\[14px\]/g) ?? []).length, 3);
    assert.equal((html.match(/text-\[32px\] leading-none font-bold tabular-nums mt-2\.5/g) ?? []).length, 3);
    assert.equal((html.match(/top-0 h-\[3px\] origin-left/g) ?? []).length, 3);
    assert.equal((html.match(/w-\[5px\] h-\[5px\] rounded-full/g) ?? []).length, 3);
    assert.equal((html.match(/aria-pressed="true"/g) ?? []).length, 1);
    assert.equal((html.match(/scaleX\(0\)/g) ?? []).length, 2);
    assert.match(html, /box-shadow:0 8px 20px -14px/);
    assert.doesNotMatch(html, /<svg|min-h-\[92px\]|text-\[30px\]|inset-y-3/);
    for (const [name, count] of Object.entries(counts)) assert.ok(html.includes(`aria-label="${name} ${count} 件"`));
  }
});

test("summary clicks always keep one primary status without modifying counts", () => {
  for (const selected of ["待接受", "进行中", "已完成"]) {
    const changes = [];
    const tree = TaskStatusSummary({ counts, status: selected, onChange: value => changes.push(value) });
    for (const button of tree.props.children) button.props.onClick();
    assert.deepEqual(changes, ["待接受", "进行中", "已完成"]);
    assert.doesNotMatch(render(selected), /再次点击查看全部状态/);
  }
  assert.deepEqual(counts, { 待接受: 12, 进行中: 8, 已完成: 3 });
  assert.match(render("待接受"), /需要我确认/);
  assert.match(render("进行中"), /继续推进/);
  assert.match(render("已完成"), /成果与记录/);
  assert.doesNotMatch(render("待接受").replace(/<[^>]*>/g, ""), /我负责/);
  assert.match(render("待接受"), /title="待我接受的任务数"/);
  assert.match(render("进行中"), /title="我负责的进行中任务数"/);
  assert.match(render("待接受", "assigned"), /title="我分派的待接受任务数"/);
  assert.match(render("待接受", "assigned"), /等待对方接受/);
  assert.doesNotMatch(render("待接受", "assigned"), /需要我确认|不受人员视角影响/);
});