import assert from "node:assert/strict";
import test from "node:test";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import vm from "node:vm";
import { build } from "esbuild";

const directory = new URL("../src/app/components/", import.meta.url);
// Compile the actual exported pure tree selector. Unused rendering imports are
// side-effect-free here so no canvas, styles, stores or browser APIs are loaded.
const { outputFiles } = await build({
  stdin: { contents: 'export { filterMindMapTasks } from "./MindMapFlow";', resolveDir: fileURLToPath(directory), loader: "ts" },
  bundle: true, write: false, platform: "node", format: "cjs", jsx: "transform",
  plugins: [{ name: "isolate-pure-tree-selector", setup(build) {
    build.onResolve({ filter: /./ }, args => args.importer.endsWith("/MindMapFlow.tsx")
      ? { path: args.path, external: true, sideEffects: false } : undefined);
  } }],
});
const sandbox = { module: { exports: {} }, require(name) {
  // The module's top-level thought-category spread is retained by esbuild;
  // provide only that unrelated static catalog, never task/filter results.
  if (name === "./data") return { PROBLEM_DOMAINS: [] };
  throw new Error(`Pure selector must not load ${name}`);
} };
vm.runInNewContext(outputFiles[0].text, sandbox);
const { filterMindMapTasks: filter } = sandbox.module.exports;
const plain = value => JSON.parse(JSON.stringify(value));
const task = (id, patch = {}) => ({ id, code: `TASK-${id}`, supervisor: "王强", owner: "李娜", department: "PTE", status: "进行中", ...patch });
const ids = nodes => nodes.flatMap(node => [node.id, ...ids(node.children ?? [])]);
function freeze(value) {
  if (value && typeof value === "object" && !Object.isFrozen(value)) { Object.values(value).forEach(freeze); Object.freeze(value); }
  return value;
}

test("tree creator filter matches explicit exact supervisor on coded descendants and preserves only required ancestor paths", () => {
  const tree = freeze([{ id: "root", supervisor: "思路人员", children: [
    task("parent", { supervisor: "另一人", children: [{ id: "nested", children: [task("match"), task("wrong", { supervisor: "王强甲" })] }] }),
    task("owner-only", { owner: "王强", supervisor: undefined }), task("blank", { supervisor: " " }),
    { id: "empty-code", code: "", supervisor: "王强" },
  ] }]);
  const before = JSON.stringify(tree);
  assert.deepEqual(plain(ids(filter(tree, "全部", "全部", "王强"))), ["root", "parent", "nested", "match"]);
  for (const creator of ["王", "强", " 王强 ", "思路人员", "李娜"]) assert.deepEqual(plain(filter(tree, "全部", "全部", creator)), []);
  assert.deepEqual(plain(ids(filter(tree, "全部", "全部", "王强甲"))), ["root", "parent", "nested", "wrong"]);
  assert.equal(JSON.stringify(tree), before);
});

test("tree status department and dispatcher must match the same task, retaining legacy unrestricted behavior without mutation", () => {
  const tree = freeze([{ id: "thought", children: [task("match"), task("wrong-status", { status: "已完成" }),
    task("wrong-dept", { department: "DA" }), task("wrong-person", { supervisor: "李娜" })] }]);
  const before = JSON.stringify(tree);
  assert.deepEqual(plain(ids(filter(tree, "进行中", "PTE", "王强"))), ["thought", "match"]);
  assert.deepEqual(plain(filter(tree, "已完成", "DA", "王强")), [], "Different tasks cannot satisfy different conditions");
  assert.deepEqual(plain(ids(filter(tree, "已完成", "全部", "全部"))), ["thought", "wrong-status"]);
  assert.deepEqual(plain(ids(filter(tree, "全部", "DA"))), ["thought", "wrong-dept"]);
  for (const creator of [undefined, "", "全部"]) assert.equal(filter(tree, "全部", "全部", creator), tree);
  assert.equal(JSON.stringify(tree), before);
});

test("tree filtering uses the supplied current snapshot, never a previously assigned dispatcher after replacement or removal", () => {
  const original = freeze([task("one")]);
  const replaced = freeze([task("one", { supervisor: "刘洋" })]);
  assert.equal(filter(original, "全部", "全部", "王强").length, 1);
  assert.equal(filter(replaced, "全部", "全部", "王强").length, 0);
  assert.equal(filter(replaced, "全部", "全部", "刘洋").length, 1);
  assert.deepEqual(plain(filter(freeze([]), "全部", "全部", "王强")), []);
});

test("production toolbar wires one dispatcher control to current roots and preserves reset/stale-selection choices", () => {
  const source = readFileSync(new URL("MindMapFlow.tsx", directory), "utf8");
  assert.match(source, /const rootTasks = tasks \?\? caseItem.tasks/);
  assert.match(source, /\[creatorFilter, setCreatorFilter\] = useState<string>\("全部"\)/);
  assert.match(source, /filterMindMapTasks\(rootTasks, statusFilter, deptFilter, creatorFilter\)/);
  assert.match(source, /const creatorOpts = useMemo\(\(\) => \["全部", \.\.\.caseCreators\(\{ tasks: rootTasks \}\)\], \[rootTasks\]\)/);
  const controls = source.match(/<select\b[\s\S]*?<\/select>/g) ?? [];
  const matches = controls.filter(control => control.includes('aria-label="任务树 创建 / 分派人"'));
  assert.equal(matches.length, 1);
  assert.match(matches[0], /value=\{creatorFilter\}/);
  assert.match(matches[0], /onChange=\{\(event\) => setCreatorFilter\(event.target.value\)\}/);
  assert.match(matches[0], /!creatorOpts.includes\(creatorFilter\)/);
  assert.match(matches[0], /当前无可选项/);
  assert.match(matches[0], /创建 \/ 分派人：全部/);
  assert.doesNotMatch(matches[0], /owner|createdBy/);
});