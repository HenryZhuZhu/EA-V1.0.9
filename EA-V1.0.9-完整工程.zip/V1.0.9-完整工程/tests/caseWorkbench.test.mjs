import assert from "node:assert/strict";
import test from "node:test";
import { build } from "esbuild";
import { fileURLToPath } from "node:url";
import vm from "node:vm";

const { outputFiles } = await build({
  stdin: { contents: `export * from "./caseWorkbenchModel"; export { buildCustomFilterRecords, customFieldCatalog, customFilterOptions } from "./caseCustomFilters";`,
    resolveDir: fileURLToPath(new URL("../src/app/components/", import.meta.url)), loader: "ts" },
  bundle: true, write: false, platform: "node", format: "cjs", external: ["./data"],
});
// Only the external data traversal is replaced; preserve the supplied nodes and tree structure.
function flattenTasks(nodes, depth = 0, parentPath = []) {
  return nodes.flatMap(task => [
    { task, depth, path: parentPath },
    ...flattenTasks(task.children ?? [], depth + 1, [...parentPath, task.title]),
  ]);
}
const sandbox = { module: { exports: {} }, require: name => {
  if (name === "./data") return { flattenTasks };
  throw new Error(`Unexpected model dependency: ${name}`);
} };
vm.runInNewContext(outputFiles[0].text, sandbox);
const {
  CASE_WORKBENCH_STATUSES, CASE_SCOPE_LABELS, DEFAULT_CASE_FILTERS, CASE_DIMENSION_FILTERS,
  CASE_WORKBENCH_SORT_OPTIONS, caseWorkbenchSortBy: sortBy, caseCreators,
  normalizeCaseWorkbenchFilters: normalizeFilters, caseWorkbenchFilterCount: filterCount,
  caseWorkbenchStatus: normalizeStatus, buildCaseWorkbenchRows: buildRows,
  caseBelongsTo: belongs, createCaseWorkbenchState: create,
  updateCaseWorkbenchState: update, selectCaseWorkbench: select,
  currentCaseWorkbenchView: currentView, buildCustomFilterRecords, customFieldCatalog, customFilterOptions,
} = sandbox.module.exports;
const plain = value => JSON.parse(JSON.stringify(value));
const statuses = ["进行中", "验证中", "已结案"];
const scopes = ["mine", "participating", "created", "department", "subscribed"];
const defaultFilters = { level: "全部", urgency: "全部", product: "全部", department: "全部", businessKind: "all", businessKey: "", creator: "全部" };
const dimensionFilters = { level: "L1", urgency: "一般", product: "DDR5", department: "PTE" };
const actor = { name: "张伟", department: "PTE" };
const departments = { 张伟: "PTE", 刘洋: "PTE", 李娜: "DA", 王强: "FT" };
const products = [{ id: "p1", code: "DDR5", name: "产品一" }, { id: "p2", code: "LPDDR", name: "产品二" }];
const now = new Date(2026, 8, 10, 23, 50);
const action = (id, patch = {}) => ({ id, code: `TASK-${id}`, title: `执行 ${id}`, owner: "李娜", status: "进行中", children: [], ...patch });
const c = (id, patch = {}) => ({
  id, code: `CASE-${id}`, name: `问题 ${id}`, owner: actor.name, createdBy: "李娜",
  status: "进行中", level: "L1", urgency: "一般", dueDate: "2026-09-12", dueIn: -999,
  updatedAt: "2026-09-01T10:00:00Z", participants: [], departments: [], tasks: [], ...patch,
});
function rows(cases, { closures = {}, subscribed = [], trees = {}, ...overrides } = {}) {
  return buildRows(cases, {
    products, closure: id => closures[id], isSubscribed: id => subscribed.includes(id),
    loadTree: record => Object.hasOwn(trees, record.id) ? trees[record.id] : record.tasks,
    ...overrides,
  });
}
function stateFor({ status = "进行中", source = "all", scope = "mine", filters = {}, page = 1, sortBy } = {}) {
  let state = update(create(scope), { type: "status", status });
  state = update(state, { type: "source", source });
  state = update(state, { type: "filters", patch: filters });
  if (sortBy !== undefined) state = update(state, { type: "sort", sortBy });
  return update(state, { type: "page", page });
}
const selected = (list, options = {}) => select(list, stateFor(options), actor, departments, now);
const ids = list => plain(list.map(row => row.id));
function freeze(value) {
  if (value && typeof value === "object" && !Object.isFrozen(value)) {
    Object.values(value).forEach(freeze);
    Object.freeze(value);
  }
  return value;
}

test("caseCreators deduplicates only actual creator and recursive coded-task dispatchers with exact raw names", () => {
  const record = freeze(c("people", { createdBy: "李娜", owner: "仅负责人", participants: [{ name: "仅参与人" }], tasks: [
    { id: "thought", supervisor: "思路分派人", children: [action("one", { supervisor: "王强", children: [
      { id: "nested", children: [action("deep", { supervisor: "李娜" }), action("exact", { supervisor: " 王强 " })] },
    ] })] }, action("duplicate", { supervisor: "王强" }), action("blank", { supervisor: "  " }),
    action("missing"), { code: "", supervisor: "空编码" },
  ] }));
  const before = JSON.stringify(record);
  assert.deepEqual(plain(caseCreators(record)), ["李娜", "王强", " 王强 "]);
  assert.deepEqual(plain(caseCreators({})), []);
  assert.deepEqual(plain(caseCreators({ createdBy: " ", tasks: [] })), []);
  assert.equal(JSON.stringify(record), before);
});

test("creator filtering uses one current persisted-tree read, exact membership and never removed tasks or owner inference", () => {
  const cases = freeze([c("created", { createdBy: "王强" }), c("dispatch", { createdBy: undefined, tasks: [action("stale", { supervisor: "旧人" })] }),
    c("removed", { createdBy: undefined, tasks: [action("removed", { supervisor: "王强" })] }),
    c("owner-only", { createdBy: undefined }), c("substring", { createdBy: "王强甲" })]);
  const trees = freeze({ dispatch: [{ id: "thought", children: [action("actual", { supervisor: "王强" })] }], removed: [] });
  const calls = [];
  const list = freeze(rows(cases, { loadTree: record => { calls.push(record.id); return trees[record.id] ?? record.tasks; } }));
  const before = JSON.stringify([cases, trees, list]);
  assert.deepEqual(calls, cases.map(record => record.id));
  assert.deepEqual(plain(list.map(row => row.creators)), [["王强"], ["王强"], [], [], ["王强甲"]]);
  assert.deepEqual(ids(selected(list, { filters: { creator: "王强" } }).rows), ["created", "dispatch"]);
  for (const creator of ["王", "强", "旧人", actor.name, " 王强 "]) assert.equal(selected(list, { filters: { creator } }).total, 0, creator);
  for (const creator of [undefined, null, "", "全部"]) {
    const result = selected(list, { filters: { creator } });
    assert.equal(result.total, 5); assert.equal(result.filters.creator, "全部"); assert.equal(filterCount(result.filters), 0);
  }
  assert.equal(selected(list, { filters: { creator: "王强", level: "L2" } }).total, 0);
  assert.equal(selected(list, { filters: { creator: "王强" } }).candidates.length, 5);
  assert.equal(calls.length, cases.length, "Selections never reload persisted trees");
  const legacyRow = { ...list[0] }; delete legacyRow.creators;
  assert.equal(selected([legacyRow], { filters: { creator: "王强" } }).total, 1, "Optional row metadata remains compatible");
  assert.equal(JSON.stringify([cases, trees, list]), before);
});

test("creator composes with custom createdBy/supervisor and Fanout status, with independent memory and filter-only reset", () => {
  const cases = freeze([c("fan", { source: "fanout验证", status: "验证中", createdBy: "李娜", tasks: [action("t", { supervisor: "王强" })] }),
    c("other", { source: "fanout验证", status: "已结案", createdBy: "李娜", tasks: [action("t2", { supervisor: "王强" })] }), c("normal")]);
  const list = freeze(rows(cases));
  const records = buildCustomFilterRecords(cases, { loadTree: c => c.tasks, status: normalizeStatus, closure: () => undefined });
  const fields = customFieldCatalog(records);
  let state = update(create(), { type: "filters", patch: { creator: "李娜" } });
  const normal = state.views.进行中;
  for (const action of [{ type: "fanout" }, { type: "filters", patch: { creator: "王强" } }, { type: "fanout-status", status: "验证中" },
    { type: "custom-rules", rules: [{ id: "c", fieldId: "case:createdBy", operator: "in", values: ["李娜"] }, { id: "t", fieldId: "task:supervisor", operator: "in", values: ["王强"] }] },
    { type: "sort", sortBy: "level" }, { type: "expanded" }, { type: "page", page: 9 }]) state = update(state, action);
  const result = select(list, state, actor, departments, now, { records, fields });
  assert.deepEqual(ids(result.rows), ["fan"]); assert.equal(result.appliedCustomRules.length, 2);
  assert.equal(filterCount(result.filters) + result.appliedCustomRules.length + Number(currentView(state).statusFilter !== "全部"), 4);
  assert.equal(result.counts.进行中, 1); assert.equal(result.fanoutCount, 2);
  const saved = currentView(state); freeze(state);
  assert.equal(currentView(update(state, { type: "status", status: "进行中" })), normal);
  assert.equal(currentView(update(update(state, { type: "status", status: "进行中" }), { type: "fanout" })), saved);
  const reset = update(state, { type: "reset" });
  assert.deepEqual(plain(currentView(reset).filters), defaultFilters); assert.equal(currentView(reset).statusFilter, "全部");
  assert.deepEqual(plain(currentView(reset).customRules), []); assert.equal(currentView(reset).page, 1);
  assert.equal(currentView(reset).sortBy, "level"); assert.equal(currentView(reset).expanded, true); assert.equal(reset.views, state.views);
  assert.equal(currentView(state).filters.creator, "王强");
});

test("primary states are exactly three and closed records take precedence over root-cause verification", () => {
  assert.deepEqual(plain(CASE_WORKBENCH_STATUSES), statuses);
  for (const raw of ["进行中", "验证中", "Pending", "已关闭", "已结案", "已归档"]) {
    assert.equal(normalizeStatus({ status: raw }, { state: "closed" }), "已结案");
  }
  for (const raw of ["已关闭", "已结案", "已归档"]) {
    for (const closure of [undefined, { state: "rootcause" }, { state: "closed" }]) {
      assert.equal(normalizeStatus({ status: raw }, closure), "已结案");
    }
  }
  assert.ok(!CASE_WORKBENCH_STATUSES.includes("Pending"));
  assert.ok(!CASE_WORKBENCH_STATUSES.includes("暂存"));
  assert.ok(!CASE_WORKBENCH_STATUSES.includes("待处理"));
  assert.equal(normalizeStatus({ status: "待处理" }), "进行中");
});

test("stored root cause and raw verification normalize to verification while legacy Pending stays active", () => {
  const cases = freeze([c("stored"), c("raw", { status: "验证中" }), c("legacy", { status: "Pending" }), c("legacy-root", { status: "Pending" })]);
  const closures = freeze({ stored: { caseId: "stored", state: "rootcause" }, "legacy-root": { caseId: "legacy-root", state: "rootcause" } });
  const before = JSON.stringify([cases, closures]);
  const list = rows(cases, { closures });
  assert.deepEqual(plain(list.map(row => row.status)), ["验证中", "验证中", "进行中", "验证中"]);
  assert.deepEqual(plain(selected(list).counts), { 进行中: 1, 验证中: 3, 已结案: 0 });
  assert.equal(list[2].record, cases[2]);
  assert.equal(list[2].record.status, "Pending");
  assert.equal(JSON.stringify([cases, closures]), before);
});

test("build loads each actual Case's persisted recursive tree and counts actions rather than thoughts", () => {
  const cases = freeze([c("saved", { tasks: [action("stale")] }), c("empty", { tasks: [action("removed")] }), c("fallback", { tasks: [action("original")] })]);
  const trees = freeze({
    saved: [{ id: "thought", title: "方向", children: [action("nested", { children: [
      { id: "thought-deep", title: "子方向", children: [action("deep", { status: "已完成" })] },
    ] })] }, action("root", { status: "待接受" }), { id: "empty-code", code: "", title: "不是执行任务" }],
    empty: [],
  });
  const before = JSON.stringify([cases, trees]);
  const calls = [];
  const list = rows(cases, { loadTree: record => {
    calls.push(record);
    return Object.hasOwn(trees, record.id) ? trees[record.id] : record.tasks;
  } });
  assert.deepEqual(plain(list.map(row => row.taskCount)), [3, 0, 1]);
  assert.equal(calls.length, cases.length);
  calls.forEach((record, i) => { assert.equal(record, cases[i]); assert.equal(list[i].record, cases[i]); });
  assert.equal(JSON.stringify([cases, trees]), before);
});

test("building filtering sorting and pagination never mutate Cases, loaded trees, closure data or rows", () => {
  const cases = freeze([c("source", { owner: "刘洋", fanoutTargets: ["p2"] }), c("child", {
    fanoutSourceCaseId: "source", productIds: ["p2", "p1", "p2"], participants: [{ name: "张伟" }],
    product: "DDR5", departments: ["PTE"], tasks: [action("old")], projectName: " 同名项目 ",
  })]);
  const closures = freeze({ child: { caseId: "child", state: "rootcause", rootCauseAt: "2026-09-08T10:00:00Z" } });
  const trees = freeze({ child: [action("persisted", { collaborators: [{ name: "张伟" }] })] });
  const subscribed = freeze(["source", "child"]);
  const catalog = freeze(plain(products));
  const before = JSON.stringify([cases, closures, trees, subscribed, catalog]);
  const list = freeze(rows(cases, { closures, trees, subscribed, products: catalog }));
  const rowBefore = JSON.stringify(list);
  let state = update(stateFor({ status: "验证中" }), { type: "fanout" });
  state = update(state, { type: "fanout-status", status: "验证中" });
  state = update(state, { type: "filters", patch: dimensionFilters });
  state = freeze(update(state, { type: "page", page: 999 }));
  const stateBefore = JSON.stringify(state);
  const result = select(list, state, actor, departments, now);
  assert.deepEqual(ids(result.rows), ["child"]);
  assert.deepEqual(plain(result.filters), { ...defaultFilters, ...dimensionFilters });
  assert.equal(result.rows[0], list[1]);
  assert.equal(result.rows[0].sourceCase, cases[0]);
  assert.equal(result.page, 1);
  assert.equal(state.fanoutView.page, 999);
  assert.equal(JSON.stringify(state), stateBefore);
  assert.equal(JSON.stringify(list), rowBefore);
  assert.equal(JSON.stringify([cases, closures, trees, subscribed, catalog]), before);
});

test("Fanout scope requires an explicit incoming marker and never infers it from outgoing targets or normal relations", () => {
  const list = rows([
    c("outgoing", { fanoutTargets: ["p1"], childCaseIds: ["parent-child"] }),
    c("closure-outgoing"), c("incoming", { fanoutSourceCaseId: "outgoing" }),
    c("marker", { source: "fanout验证" }),
    c("parent-child", { parentCaseId: "outgoing", sourceModuleCaseId: "outgoing", relatedCaseIds: ["outgoing"] }),
    c("issue-only", { fanoutOfIssueId: "issue" }), c("text", { name: "Fanout 验证", source: "手动" }),
  ], { closures: { "closure-outgoing": { caseId: "closure-outgoing", state: "rootcause", fanoutTargets: ["p2"] } } });
  assert.deepEqual(ids(list.filter(row => row.fanout)), ["incoming", "marker"]);
  const fanoutState = update(create(), { type: "fanout" });
  assert.deepEqual(ids(select(list, fanoutState, actor, departments, now).rows).sort(), ["incoming", "marker"]);
  assert.equal(selected(list, { source: "fanout", status: "验证中" }).total, 1, "Legacy source no longer hides ordinary verification records");
  assert.equal(selected(list, { source: "fanout" }).total, 4);
  assert.equal(selected(list).total, 4);
});

test("source Case resolves from raw Cases independently of source/role/status filters and missing links are graceful", () => {
  const cases = [c("normal-source", { owner: "王强", status: "已归档", fanoutTargets: ["p2"] }),
    c("linked", { fanoutSourceCaseId: "normal-source" }), c("absent", { source: "fanout验证" }),
    c("missing", { fanoutSourceCaseId: "not-loaded" }), c("self", { fanoutSourceCaseId: "self" }),
    c("parent-only", { parentCaseId: "normal-source" })];
  const list = rows(cases);
  const linked = select(list, update(create(), { type: "fanout" }), actor, departments, now).rows.find(row => row.id === "linked");
  assert.equal(linked.sourceCase, cases[0]);
  assert.equal(linked.sourceCase.status, "已归档");
  assert.equal(list[0].fanout, false);
  for (const id of ["absent", "missing", "self", "parent-only"]) assert.equal(list.find(row => row.id === id).sourceCase, undefined);
  assert.equal(list.find(row => row.id === "missing").record.fanoutSourceCaseId, "not-loaded");
  assert.equal(list.find(row => row.id === "parent-only").fanout, false);
});

test("own joined created and subscribed relations use explicit Case metadata, with intentional overlap but no task inference", () => {
  const list = rows([
    c("self", { createdBy: actor.name, participants: [{ name: actor.name }] }),
    c("overlap", { owner: "李娜", createdBy: actor.name, participants: [{ name: actor.name }] }),
    c("joined", { owner: "李娜", participants: [{ name: actor.name }] }),
    c("created", { owner: "王强", createdBy: actor.name }),
    c("task-only", { owner: "李娜", tasks: [action("mine-task", { owner: actor.name }), action("collab", { supervisor: actor.name, collaborators: [{ name: actor.name }] })] }),
    c("unknown-creator", { owner: "李娜", createdBy: undefined }),
    c("subscription-only", { owner: "王强" }),
  ], { subscribed: ["self", "overlap", "subscription-only"] });
  assert.deepEqual(plain(CASE_SCOPE_LABELS), { mine: "我负责", participating: "我参与", created: "我分派", department: "我部门", subscribed: "我订阅" });
  for (const [scope, expected] of Object.entries({ mine: ["self"], participating: ["overlap", "joined"], created: ["overlap", "created"], subscribed: ["self", "overlap", "subscription-only"] })) {
    assert.deepEqual(ids(list.filter(row => belongs(row, scope, actor, departments))), expected, scope);
  }
  assert.equal(belongs(list[0], "participating", actor, departments), false);
  assert.equal(belongs(list[0], "created", actor, departments), false);
  assert.equal(belongs(list[4], "participating", actor, departments), false);
  assert.equal(belongs(list[4], "created", actor, departments), false);
});

test("department relation accepts explicit Case departments or owner mapping, not task departments or unknown-owner guesses", () => {
  const list = rows([c("owner-map", { owner: "刘洋", departments: [] }), c("explicit", { owner: "李娜", departments: ["PTE", "DA"] }),
    c("task-department", { owner: "李娜", tasks: [action("t", { department: "PTE" })] }),
    c("unknown", { owner: "未登记人员", departments: undefined }), c("unknown-explicit", { owner: "未登记人员", departments: ["PTE"] })]);
  assert.deepEqual(ids(list.filter(row => belongs(row, "department", actor, departments))), ["owner-map", "explicit", "unknown-explicit"]);
  assert.ok(list.every(row => !belongs(row, "department", { ...actor, department: "" }, departments)));
  assert.equal(belongs(list[0], "department", actor, {}), false);
});

test("closed historical Cases remain accessible through all five relations in both ordinary and Fanout scopes", () => {
  const patches = {
    mine: {}, participating: { owner: "李娜", participants: [{ name: actor.name }] },
    created: { owner: "李娜", createdBy: actor.name }, department: { owner: "刘洋" }, subscribed: { owner: "王强" },
  };
  for (const [scope, patch] of Object.entries(patches)) {
    const cases = [c("raw", { ...patch, status: "已归档", source: "手动" }), c("stored", { ...patch, source: "fanout验证" })];
    const list = rows(cases, { closures: { stored: { caseId: "stored", state: "closed", closedAt: "2026-09-09T10:00:00Z" } }, subscribed: ["raw", "stored"] });
    for (const source of ["all", "fanout"]) {
      assert.deepEqual(ids(selected(list, { status: "已结案", scope, source }).rows), ["raw"], `${scope}/${source}: normal history excludes Fanout`);
      assert.equal(selected(list, { status: "进行中", scope, source }).total, 0);
      assert.equal(selected(list, { status: "验证中", scope, source }).total, 0);
    }
    const fanout = update(update(create(), { type: "fanout" }), { type: "scope", scope });
    assert.deepEqual(ids(select(list, fanout, actor, departments, now).rows), ["stored"], `${scope}: Fanout history remains accessible`);
  }
});

test("fixed owner summaries ignore primary selection, source, every role, all five filters, expansion and pages", () => {
  const cases = statuses.flatMap((status, i) => [c(`own-${i}`, { status, productId: "p1", product: "DDR5", departments: ["PTE"] }), c(`fanout-${i}`, { status, source: "fanout验证", createdBy: actor.name }),
    c(`other-${i}`, { status, owner: "刘洋", createdBy: actor.name, participants: [{ name: actor.name }], source: "fanout验证" })]);
  const list = freeze(rows(cases, { subscribed: cases.map(record => record.id) }));
  const before = JSON.stringify(list);
  const expected = { 进行中: 1, 验证中: 1, 已结案: 1 };
  for (const status of statuses) for (const source of ["all", "fanout"]) for (const scope of scopes) {
    for (const filters of [{}, ...Object.entries(dimensionFilters).map(([key, value]) => ({ [key]: value })), dimensionFilters,
      { creator: "李娜" }, { creator: "不存在" }, { level: "旧层级", urgency: "旧紧急", product: "旧产品", department: "旧部门", creator: "旧人" }]) {
      let state = stateFor({ status, source, scope, filters, page: 7 });
      state = update(state, { type: "expanded" });
      assert.deepEqual(plain(select(list, state, actor, departments, now).counts), expected);
      assert.deepEqual(plain(select(list, update(state, { type: "reset" }), actor, departments, now).counts), expected);
    }
  }
  assert.equal(JSON.stringify(list), before);
});

test("business references preserve multiple exact products plus name-only Project without inventing IDs", () => {
  const list = rows([c("multi", { productId: "p1", productIds: ["p2", "p1", "p2"], projectName: " 同名项目 " }),
    c("legacy-code", { product: "DDR5" }), c("legacy-id", { product: "p2" }),
    c("unknown-id", { productId: "saved-product" }), c("text-only", { name: "DDR5 产品一", product: "产品一" }),
    c("project-only", { projectName: "同名项目" }), c("blank", { projectName: "   " })]);
  assert.deepEqual(plain(list[0].business), [
    { key: "产品:p2", kind: "产品", name: "LPDDR · 产品二", origin: "case" },
    { key: "产品:p1", kind: "产品", name: "DDR5 · 产品一", origin: "case" },
    { key: "Project:name:同名项目", kind: "Project", name: "同名项目", origin: "case", nameOnly: true },
  ]);
  assert.equal(list[1].business[0].key, "产品:p1");
  assert.equal(list[2].business[0].key, "产品:p2");
  assert.equal(list[3].business[0].key, "产品:saved-product");
  assert.equal(list[3].business[0].name, "saved-product");
  assert.deepEqual(plain(list[4].business), []);
  assert.equal(list[5].business[0].key, "Project:name:同名项目");
  assert.deepEqual(plain(list[6].business), []);
});

test("level urgency exact product and explicit department combine with AND semantics independently of Project and creator", () => {
  const list = rows([
    c("match", { product: "DDR5", departments: ["PTE", "DA"], projectName: "项目一", productIds: ["p1", "p2"] }),
    c("other-creator-project", { product: "DDR5", departments: ["PTE"], createdBy: "刘洋", projectName: "项目二" }),
    c("missing-creator-project", { product: "DDR5", departments: ["PTE"], createdBy: undefined }),
    c("wrong-level", { level: "L2", product: "DDR5", departments: ["PTE"] }),
    c("wrong-urgency", { urgency: "紧急", product: "DDR5", departments: ["PTE"] }),
    c("wrong-product", { product: "LPDDR", departments: ["PTE"] }),
    c("wrong-department", { product: "DDR5", departments: ["DA"] }),
  ]);
  const matches = ["match", "other-creator-project", "missing-creator-project"];
  const checks = [
    [dimensionFilters, matches],
    [{ ...dimensionFilters, level: "全部" }, [...matches, "wrong-level"]],
    [{ ...dimensionFilters, urgency: "全部" }, [...matches, "wrong-urgency"]],
    [{ ...dimensionFilters, product: "全部" }, [...matches, "wrong-product"]],
    [{ ...dimensionFilters, department: "全部" }, [...matches, "wrong-department"]],
    [{ ...dimensionFilters, businessKind: "Project", businessKey: "Project:name:旧项目" }, matches],
    [{ ...dimensionFilters, creator: "李娜" }, ["match"]],
    [{ ...dimensionFilters, creator: "不存在" }, []],
    ...Object.keys(dimensionFilters).map(key => [{ ...dimensionFilters, [key]: "不存在" }, []]),
  ];
  for (const [filters, expected] of checks) assert.deepEqual(ids(selected(list, { filters }).rows).sort(), [...expected].sort(), JSON.stringify(filters));
});

test("dimension metadata and normalization activate creator while ignoring unrelated legacy fields without mutation", () => {
  assert.deepEqual(plain(CASE_DIMENSION_FILTERS), [
    { key: "level", label: "层级" }, { key: "urgency", label: "紧急程度" },
    { key: "product", label: "产品" }, { key: "department", label: "部门" }, { key: "creator", label: "创建 / 分派人" },
  ]);
  const legacy = { businessKind: "Project", businessKey: "Project:name:旧项目", creator: "旧创建人", project: "旧项目", status: "已结案", extra: "忽略" };
  const inputs = [{}, legacy, ...[undefined, null, ""].map(value => ({
    ...legacy, ...Object.fromEntries(Object.keys(dimensionFilters).map(key => [key, value])),
  }))];
  for (const input of inputs) {
    freeze(input);
    const before = JSON.stringify(input);
    const normalized = normalizeFilters(input);
    assert.deepEqual(plain(normalized), { ...defaultFilters, creator: input.creator || "全部" });
    assert.deepEqual(Object.keys(normalized).sort(), Object.keys(defaultFilters).sort());
    assert.notEqual(normalized, input);
    assert.notEqual(normalized, DEFAULT_CASE_FILTERS);
    assert.notEqual(normalizeFilters(input), normalized);
    assert.equal(JSON.stringify(input), before);
  }
  const exact = freeze({ ...legacy, level: "旧层级", urgency: "旧紧急", product: " DDR5 ", department: "旧部门" });
  const normalized = normalizeFilters(exact);
  assert.deepEqual(plain(normalized), { ...defaultFilters, level: "旧层级", urgency: "旧紧急", product: " DDR5 ", department: "旧部门", creator: "旧创建人" });
  assert.deepEqual(plain(normalizeFilters(normalized)), plain(normalized));
});

test("filter count covers all 32 five-field combinations and stale creators but never status or obsolete business conditions", () => {
  const keys = ["level", "urgency", "product", "department", "creator"];
  const legacy = { businessKind: "Project", businessKey: "Project:name:旧项目", creator: "旧人", project: "旧项目", status: "已结案" };
  for (let mask = 0; mask < 32; mask++) {
    const filters = freeze({ ...defaultFilters, ...legacy, ...Object.fromEntries(keys.map((key, i) => [key, mask & (1 << i) ? `旧-${key}` : "全部"])) });
    const expected = mask.toString(2).replaceAll("0", "").length;
    assert.equal(filterCount(filters), expected, `combination ${mask}`);
    assert.equal(filterCount(normalizeFilters(filters)), expected);
  }
  for (const empty of [undefined, null, "", "全部"]) {
    assert.equal(filterCount({ ...legacy, ...Object.fromEntries(keys.map(key => [key, empty])) }), 0);
  }
  assert.equal(filterCount({ ...legacy, ...dimensionFilters }), 5);
  assert.equal(filterCount({ ...legacy, product: " 全部 " }), 2, "nonempty strings are not trimmed into the sentinel");
  assert.equal(filterCount({}), 0);
  assert.equal(filterCount(DEFAULT_CASE_FILTERS), 0);
});

test("selector and filter actions activate saved creator but ignore legacy Project product-ref without rewriting inputs", () => {
  const list = freeze(rows([
    c("matching", { product: "DDR5", departments: ["PTE"] }),
    c("different", { product: "LPDDR", departments: ["DA"], createdBy: "刘洋", projectName: "项目二" }),
    c("no-business", { createdBy: undefined }),
  ]));
  const rowBefore = JSON.stringify(list);
  for (const legacy of [
    { businessKind: "Project", businessKey: "Project:name:不存在", creator: "不存在" },
    { businessKind: "产品", businessKey: "产品:missing", creator: "不存在" },
    { businessKind: "none", businessKey: "stale-key", creator: "不存在" },
  ]) for (const dimensions of [{}, dimensionFilters]) {
    // Inject a real pre-normalization snapshot; stateFor would sanitize it via the filters action.
    const state = create();
    state.views.进行中 = { ...state.views.进行中, filters: { ...legacy, ...dimensions, project: "不存在", status: "已结案" }, expanded: true, page: 9 };
    freeze(state);
    const before = JSON.stringify(state);
    const expected = selected(list, { filters: { ...dimensions, creator: legacy.creator } });
    const result = select(list, state, actor, departments, now);
    assert.deepEqual(ids(result.rows), ids(expected.rows));
    assert.deepEqual(ids(result.rows), []);
    assert.deepEqual(ids(result.candidates), ids(list));
    assert.deepEqual(plain(result.scopeCounts), plain(expected.scopeCounts));
    assert.deepEqual(plain(result.counts), { 进行中: 3, 验证中: 0, 已结案: 0 });
    assert.deepEqual(plain(result.filters), { ...defaultFilters, ...dimensions, creator: legacy.creator });
    assert.notEqual(result.filters, state.views.进行中.filters);
    assert.equal(result.total, expected.total);
    assert.equal(result.page, 1);
    const patch = freeze({ ...legacy, project: "另一个旧项目", status: "验证中" });
    const patchBefore = JSON.stringify(patch);
    const next = update(state, { type: "filters", patch });
    assert.equal(next.status, "进行中", "filter patches cannot introduce a second primary-status condition");
    assert.deepEqual(plain(next.views.进行中), { source: "all", scope: "mine", filters: { ...defaultFilters, ...dimensions, creator: legacy.creator }, expanded: true, page: 1 });
    assert.equal(next.views.验证中, state.views.验证中);
    assert.equal(next.views.已结案, state.views.已结案);
    assert.deepEqual(ids(select(list, next, actor, departments, now).rows), ids(expected.rows));
    assert.equal(JSON.stringify(patch), patchBefore);
    assert.equal(JSON.stringify(state), before);
  }
  assert.equal(JSON.stringify(list), rowBefore);
});

test("product dimension matches the exact stored string, not inferred IDs, catalog names, or multi-product references", () => {
  const list = freeze(rows([
    c("exact", { product: "DDR5" }),
    c("conflicting-id", { product: "DDR5", productId: "p2" }),
    c("id-string", { product: "p1" }),
    c("refs-only", { productId: "p1", productIds: ["p1", "p2", "p1"] }),
    c("multi-other", { product: "LPDDR", productIds: ["p1", "p2"] }),
    c("display-name", { product: "产品一" }),
    c("padded", { product: " DDR5 " }),
    c("case-sensitive", { product: "ddr5" }),
  ]));
  const before = JSON.stringify(list);
  const checks = [
    ["DDR5", ["conflicting-id", "exact"]], ["p1", ["id-string"]], ["LPDDR", ["multi-other"]],
    ["产品一", ["display-name"]], [" DDR5 ", ["padded"]], ["ddr5", ["case-sensitive"]],
    ["产品:p1", []], ["p2", []], ["DDR5 · 产品一", []], ["DDR5,LPDDR", []],
  ];
  for (const [product, expected] of checks) {
    const result = selected(list, { filters: { product } });
    assert.deepEqual(ids(result.rows).sort(), expected, product);
    assert.equal(result.total, expected.length);
    assert.equal(filterCount(result.filters), 1);
  }
  assert.equal(selected(list).total, 8);
  assert.deepEqual(plain(list[3].business.map(ref => ref.key)), ["产品:p1", "产品:p2"]);
  assert.equal(list[1].business[0].key, "产品:p2", "historical references remain independent of the string filter");
  assert.equal(JSON.stringify(list), before);
});

test("department dimension uses only explicit departments even though the department role also allows owner mapping", () => {
  const list = freeze(rows([
    c("owner-map", { owner: "刘洋", departments: [] }),
    c("explicit", { owner: "李娜", departments: ["PTE", "DA", "PTE"] }),
    c("mapped-other-explicit", { owner: "刘洋", departments: ["DA"] }),
    c("missing", { owner: "刘洋", departments: undefined }),
    c("task-only", { owner: "刘洋", tasks: [action("t", { department: "PTE" })] }),
    c("unknown-explicit", { owner: "未登记人员", departments: ["PTE"] }),
  ], { subscribed: ["explicit"] }));
  assert.equal(selected(list, { scope: "department" }).total, 6);
  const result = selected(list, { scope: "department", filters: { department: "PTE" } });
  assert.deepEqual(ids(result.rows), ["explicit", "unknown-explicit"]);
  assert.equal(result.total, 2, "duplicate explicit departments do not duplicate rows");
  assert.equal(result.candidates.length, 6);
  assert.deepEqual(plain(result.scopeCounts), { mine: 0, participating: 0, created: 0, department: 2, subscribed: 1 });
  assert.deepEqual(ids(selected(list, { scope: "department", filters: { department: "DA" } }).rows), ["explicit", "mapped-other-explicit"]);
  assert.equal(selected(list, { scope: "department", filters: { department: "pte" } }).total, 0);
  assert.equal(selected(list, { scope: "department", filters: { department: " PTE " } }).total, 0);
  assert.deepEqual(ids(select(list, stateFor({ scope: "department", filters: { department: "PTE" } }), actor, {}, now).rows), ["explicit", "unknown-explicit"]);
});

test("empty or missing Case dimensions match only unrestricted fields and blank filter edits restore those defaults", () => {
  const keys = ["level", "urgency", "product", "department"];
  const fields = { level: "level", urgency: "urgency", product: "product", department: "departments" };
  for (const key of keys) {
    const complete = { product: "DDR5", departments: ["PTE"] };
    const missing = c("missing", complete);
    delete missing[fields[key]];
    const list = freeze(rows([
      c("complete", complete), missing,
      c("undefined", { ...complete, [fields[key]]: undefined }),
      c("null", { ...complete, [fields[key]]: null }),
      c("empty", { ...complete, [fields[key]]: key === "department" ? [] : "" }),
    ]));
    const before = JSON.stringify(list);
    assert.deepEqual(ids(selected(list, { filters: dimensionFilters }).rows), ["complete"], key);
    const state = freeze(stateFor({ filters: dimensionFilters, page: 5 }));
    for (const value of [undefined, null, "", "全部"]) {
      const next = update(state, { type: "filters", patch: { [key]: value } });
      const result = select(list, next, actor, departments, now);
      assert.deepEqual(ids(result.rows).sort(), ["complete", "empty", "missing", "null", "undefined"], key);
      assert.deepEqual(plain(result.filters), { ...defaultFilters, ...dimensionFilters, [key]: "全部" });
      assert.equal(filterCount(result.filters), 3);
      assert.equal(next.views.进行中.page, 1);
      assert.equal(result.total, 5);
    }
    assert.equal(state.views.进行中.filters[key], dimensionFilters[key]);
    assert.equal(state.views.进行中.page, 5);
    assert.equal(JSON.stringify(list), before);
  }
});

test("filter candidates ignore dimensions page and legacy source but always exclude Fanout from normal status and relation results", () => {
  const list = rows([c("a", { product: "DDR5", departments: ["PTE"] }),
    c("b", { createdBy: "刘洋", level: "L2", urgency: "紧急", product: "LPDDR", departments: ["DA"] }),
    c("outside-source", { source: "fanout验证" }), c("outside-status", { status: "验证中" }),
    c("outside-role", { owner: "李娜", createdBy: actor.name, participants: [{ name: actor.name }] })]);
  const result = selected(list, { source: "fanout", filters: dimensionFilters, page: 6 });
  assert.deepEqual(ids(result.rows), ["a"]);
  assert.deepEqual(plain(result.filters), { ...defaultFilters, ...dimensionFilters });
  assert.deepEqual(ids(result.candidates), ["a", "b"]);
  assert.equal(result.candidates[0], list[0]);
  assert.deepEqual(plain(result.scopeCounts), { mine: 1, participating: 0, created: 0, department: 1, subscribed: 0 });
  const unfiltered = selected(list, { source: "fanout" });
  assert.deepEqual(plain(unfiltered.scopeCounts), { mine: 2, participating: 1, created: 1, department: 2, subscribed: 0 });
});

test("empty and stale saved views retain their filters and selected status rather than falling back to all", () => {
  const list = rows([c("available", { status: "已结案", productId: "p1" })]);
  const stale = { level: "旧层级", urgency: "旧紧急", product: "旧产品", department: "旧部门" };
  const state = freeze(stateFor({ status: "已结案", source: "fanout", scope: "created", filters: stale, page: 10 }));
  const before = JSON.stringify(state);
  for (const input of [list, []]) {
    const result = select(input, state, actor, departments, now);
    assert.equal(result.total, 0); assert.equal(result.page, 1); assert.equal(result.pages, 1);
    assert.deepEqual(ids(result.rows), []); assert.deepEqual(ids(result.candidates), []);
    assert.deepEqual(Object.keys(plain(result.counts)), statuses);
    assert.deepEqual(plain(result.filters), { ...defaultFilters, ...stale });
    assert.equal(filterCount(result.filters), 4);
  }
  assert.equal(JSON.stringify(state), before);
  assert.equal(state.status, "已结案");
  assert.deepEqual(plain(state.views.已结案.filters), { ...defaultFilters, ...stale });
});

test("each primary state and each new workbench get independent default view and filter objects", () => {
  const defaults = { source: "all", scope: "mine", filters: defaultFilters, expanded: false, page: 1 };
  const state = create(); const separate = create();
  assert.deepEqual(plain(DEFAULT_CASE_FILTERS), defaultFilters);
  assert.equal(state.status, "进行中");
  assert.deepEqual(Object.keys(plain(state.views)), statuses);
  for (const status of statuses) {
    assert.deepEqual(plain(state.views[status]), defaults);
    assert.notEqual(state.views[status], separate.views[status]);
    assert.notEqual(state.views[status].filters, DEFAULT_CASE_FILTERS);
    assert.notEqual(state.views[status].filters, separate.views[status].filters);
    for (const other of statuses.filter(value => value !== status)) {
      assert.notEqual(state.views[status], state.views[other]);
      assert.notEqual(state.views[status].filters, state.views[other].filters);
    }
  }
  for (const scope of scopes) assert.ok(statuses.every(status => create(scope).views[status].scope === scope));
});

test("repeat source scope and status actions are identity no-ops; real source/scope changes reset only the current page", () => {
  for (const status of statuses) {
    let state = stateFor({ status, filters: dimensionFilters, page: 4 });
    state = update(state, { type: "expanded" });
    for (const action of [{ type: "status", status }, { type: "source", source: "all" }, { type: "scope", scope: "mine" }]) assert.equal(update(state, action), state);
    for (const [action, patch] of [[{ type: "source", source: "fanout" }, { source: "fanout" }], [{ type: "scope", scope: "participating" }, { scope: "participating" }]]) {
      const before = JSON.stringify(state); const next = update(state, action);
      assert.deepEqual(plain(next.views[status]), { ...plain(state.views[status]), ...patch, page: 1 });
      assert.equal(next.views[status].filters, state.views[status].filters);
      assert.equal(next.status, status);
      for (const other of statuses.filter(value => value !== status)) assert.equal(next.views[other], state.views[other]);
      assert.equal(JSON.stringify(state), before);
      const paged = update(next, { type: "page", page: 3 });
      assert.equal(update(paged, action), paged);
    }
  }
});

test("the shared status action restores its source scope four filters expansion and page snapshot without a second status filter", () => {
  let state = create(); const saved = {};
  for (const [i, status] of statuses.entries()) {
    const previousViews = state.views;
    state = update(state, { type: "status", status });
    assert.equal(state.views, previousViews);
    state = update(state, { type: "source", source: i === 1 ? "all" : "fanout" });
    state = update(state, { type: "scope", scope: ["created", "department", "subscribed"][i] });
    const filters = { level: `L${i + 1}`, urgency: ["一般", "紧急", "非常紧急"][i], product: `产品-${i}`, department: `部门-${i}` };
    state = update(state, { type: "filters", patch: filters });
    assert.deepEqual(plain(state.views[status].filters), { ...defaultFilters, ...filters });
    if (i !== 1) state = update(state, { type: "expanded" });
    state = update(state, { type: "page", page: i + 2 });
    saved[status] = state.views[status];
  }
  const before = JSON.stringify(state);
  for (const status of ["进行中", "已结案", "验证中", "进行中"]) {
    state = update(state, { type: "status", status });
    assert.equal(state.status, status);
    assert.equal(Object.hasOwn(state.views[status].filters, "status"), false);
    for (const other of statuses) assert.equal(state.views[other], saved[other]);
    assert.equal(update(state, { type: "status", status }), state);
  }
  assert.deepEqual(plain(state.views), JSON.parse(before).views);
});

test("reset clears only current filters/page, preserving selected status source relationship and expanded panel", () => {
  for (const status of statuses) for (const source of ["all", "fanout"]) for (const scope of scopes) {
    let state = stateFor({ status, source, scope, filters: dimensionFilters, page: 4 });
    state = update(state, { type: "expanded" });
    const before = JSON.stringify(state); const reset = update(state, { type: "reset" });
    assert.equal(reset.status, status);
    assert.deepEqual(plain(reset.views[status]), { source, scope, filters: plain(DEFAULT_CASE_FILTERS), expanded: true, page: 1 });
    assert.equal(filterCount(reset.views[status].filters), 0);
    for (const other of statuses.filter(value => value !== status)) assert.equal(reset.views[other], state.views[other]);
    assert.equal(JSON.stringify(state), before);
  }
});

test("filter edits reset only current page and expansion toggles preserve page while page inputs are sanitized", () => {
  const state = stateFor({ status: "验证中", page: 5, filters: { level: "L2", department: "PTE" } });
  const expanded = update(state, { type: "expanded" });
  assert.equal(expanded.views.验证中.page, 5);
  assert.equal(expanded.views.验证中.expanded, true);
  assert.equal(update(expanded, { type: "expanded" }).views.验证中.expanded, false);
  const filtered = update(expanded, { type: "filters", patch: { urgency: "紧急", product: "DDR5" } });
  assert.equal(filtered.views.验证中.page, 1);
  assert.deepEqual(plain(filtered.views.验证中.filters), { ...defaultFilters, level: "L2", urgency: "紧急", product: "DDR5", department: "PTE" });
  assert.equal(filtered.views.验证中.expanded, true);
  assert.equal(filtered.views.进行中, state.views.进行中);
  assert.equal(filtered.views.已结案, state.views.已结案);
  for (const [page, expected] of [[2.9, 2], [0, 1], [-5, 1], [NaN, 1], [Infinity, 1], [-Infinity, 1]]) {
    assert.equal(update(state, { type: "page", page }).views.验证中.page, expected);
  }
});

test("active and verifying lists sort priority then valid calendar due dates, ignoring stale dueIn and stabilizing missing dates", () => {
  const fixtures = [
    c("tie-z", { dueDate: undefined, updatedAt: "" }),
    c("urgent-invalid", { urgency: "非常紧急", dueDate: "2026-02-31" }),
    c("normal-earlier", { dueDate: "2026-02-28", dueIn: 999 }),
    c("urgent-late", { urgency: "非常紧急", dueDate: "2026-09-12", dueIn: -999 }),
    c("unknown-priority", { urgency: "未知", dueDate: "2020-01-01" }),
    c("tie-a", { dueDate: "2026-02-29", updatedAt: "not-a-date" }),
    c("normal-leap", { dueDate: "2024-02-29" }),
    c("urgent-early", { urgency: "非常紧急", dueDate: "2026-09-09", dueIn: 999 }),
  ];
  const expected = ["urgent-early", "urgent-late", "urgent-invalid", "normal-leap", "normal-earlier", "tie-a", "tie-z", "unknown-priority"];
  for (const status of ["进行中", "验证中"]) {
    const ranked = rows(["不紧急", "一般", "紧急", "非常紧急", undefined, "未知"].map((urgency, i) => c(`rank-${i}`, { status, urgency })));
    assert.deepEqual(ids(selected(ranked, { status }).rows), ["rank-3", "rank-2", "rank-1", "rank-0", "rank-4", "rank-5"]);
    const list = freeze(rows(fixtures.map(record => ({ ...record, status }))));
    const before = JSON.stringify(list);
    for (const input of [list, [...list].reverse(), [...list.slice(3), ...list.slice(0, 3)]]) {
      const result = selected(input, { status });
      assert.deepEqual(ids(result.rows), expected);
      result.rows.forEach(row => assert.equal(row, list.find(original => original.id === row.id)));
    }
    assert.equal(JSON.stringify(list), before);
  }
});

test("equal priority/due dates use latest real activity and then stable IDs, with missing activity after valid dates", () => {
  const list = rows([c("tie-z"), c("invalid", { updatedAt: "invalid" }), c("newer", { updatedAt: "2026-09-08T10:00:00Z" }), c("tie-a"),
    c("rootcause", { updatedAt: "2026-09-02T10:00:00Z" }), c("missing", { updatedAt: undefined })],
  { closures: { rootcause: { caseId: "rootcause", state: "rootcause", rootCauseAt: "2026-09-09T10:00:00Z" } } });
  assert.deepEqual(ids(selected(list).rows), ["newer", "tie-a", "tie-z", "invalid", "missing"]);
  assert.equal(list.find(row => row.id === "rootcause").updatedAt, "2026-09-09T10:00:00Z");
  assert.deepEqual(ids(selected(list, { status: "验证中" }).rows), ["rootcause"]);
});

test("closed sorting prefers actual closure time over later record updates and uses updated fallback only without valid closure time", () => {
  const cases = [c("actual-old", { status: "已结案", updatedAt: "2026-12-01T10:00:00Z" }),
    c("fallback", { status: "已归档", updatedAt: "2026-09-06T10:00:00Z" }), c("actual-new", { urgency: "不紧急" }),
    c("invalid-closure", { status: "已关闭", updatedAt: "2026-09-07T10:00:00Z" }),
    c("missing-z", { status: "已结案", updatedAt: "bad" }), c("missing-a", { status: "已结案", updatedAt: undefined })];
  const closures = {
    "actual-old": { caseId: "actual-old", state: "closed", closedAt: "2026-09-01T10:00:00Z" },
    "actual-new": { caseId: "actual-new", state: "closed", closedAt: "2026-09-08T10:00:00Z" },
    "invalid-closure": { caseId: "invalid-closure", state: "closed", closedAt: "bad-date" },
  };
  const list = freeze(rows(cases, { closures }));
  for (const input of [list, [...list].reverse()]) assert.deepEqual(ids(selected(input, { status: "已结案" }).rows), ["actual-new", "invalid-closure", "fallback", "actual-old", "missing-a", "missing-z"]);
  assert.equal(list[0].closedAt, closures["actual-old"].closedAt);
  assert.equal(list[0].updatedAt, cases[0].updatedAt);
  assert.equal(list[2].updatedAt, closures["actual-new"].closedAt);
  assert.equal(list[3].closedAt, undefined);
  assert.equal(list[4].updatedAt, "");
});

test("latest activity selection ignores invalid timestamps and keeps closure date separate from later root-cause or Case updates", () => {
  const list = rows([c("root"), c("closed", { updatedAt: "bad" }), c("invalid", { updatedAt: "" })], { closures: {
    root: { caseId: "root", state: "rootcause", rootCauseAt: "2026-09-09T12:00:00Z" },
    closed: { caseId: "closed", state: "closed", closedAt: "2026-09-04T12:00:00Z", rootCauseAt: "2026-09-05T12:00:00Z" },
    invalid: { caseId: "invalid", state: "rootcause", rootCauseAt: "invalid" },
  } });
  assert.deepEqual(plain(list.map(row => row.updatedAt)), ["2026-09-09T12:00:00Z", "2026-09-05T12:00:00Z", ""]);
  assert.equal(list[1].closedAt, "2026-09-04T12:00:00Z");
  assert.equal(list[2].closedAt, undefined);
});

test("global eight-row pagination sorts before slicing and never loses or duplicates multi-product Cases across pages", () => {
  for (const status of statuses) {
    const cases = Array.from({ length: 21 }, (_, i) => c(`c${String(i).padStart(2, "0")}`, {
      status, source: i % 2 ? "fanout验证" : "手动", dueDate: `2026-07-${String(i + 1).padStart(2, "0")}`,
      product: i % 3 ? "DDR5" : "LPDDR", departments: ["PTE"], productIds: ["p1", "p2", "p1"], projectName: "同名项目",
    }));
    const closures = status === "已结案" ? Object.fromEntries(cases.map((record, i) => [record.id, { caseId: record.id, state: "closed", closedAt: `2026-08-${String(i + 1).padStart(2, "0")}T10:00:00Z` }])) : {};
    const list = freeze(rows([...cases].reverse(), { closures, subscribed: cases.map(record => record.id) }));
    const before = JSON.stringify(list);
    for (const source of ["all", "fanout"]) for (const scope of ["mine", "department", "subscribed"]) for (const filters of [{}, dimensionFilters]) {
      const expected = cases.filter((record, i) => i % 2 === 0 && (!filters.product || i % 3 !== 0)).map(record => record.id);
      if (status === "已结案") expected.reverse();
      const seen = []; const pages = Math.ceil(expected.length / 8);
      for (let page = 1; page <= pages; page++) {
        const result = selected(list, { status, source, scope, filters, page });
        assert.equal(result.total, expected.length); assert.equal(result.pages, pages); assert.equal(result.page, page);
        assert.deepEqual(plain(result.counts), Object.fromEntries(statuses.map(value => [value, value === status ? 11 : 0])));
        assert.equal(result.candidates.length, 11, "Candidates exclude Fanout, regardless of legacy source snapshots");
        assert.deepEqual(plain(result.filters), { ...defaultFilters, ...filters });
        assert.deepEqual(ids(result.rows), expected.slice((page - 1) * 8, page * 8));
        assert.equal(result.rows.length, Math.min(8, expected.length - (page - 1) * 8));
        for (const row of result.rows) assert.equal(row, list.find(original => original.id === row.id));
        seen.push(...ids(result.rows));
      }
      assert.deepEqual(seen, expected);
      assert.equal(new Set(seen).size, expected.length);
      const clamped = selected(list, { status, source, scope, filters, page: 999 });
      assert.equal(clamped.page, pages);
      assert.deepEqual(ids(clamped.rows), expected.slice((pages - 1) * 8));
    }
    assert.equal(JSON.stringify(list), before);
  }
});

test("Fanout is a separate view with mine/all-status defaults, not a fourth lifecycle status, including legacy snapshots", () => {
  for (const scope of scopes) {
    const state = create(scope);
    const next = update(state, { type: "fanout" });
    assert.equal(next.status, "进行中");
    assert.equal(next.fanout, true);
    assert.deepEqual(Object.keys(next.views), statuses);
    assert.equal(currentView(next).scope, "mine");
    assert.equal(currentView(next).statusFilter, "全部");
    assert.equal(currentView(next).page, 1);
    assert.equal(next.views, state.views);
    assert.equal(update(next, { type: "fanout" }), next);
    assert.notEqual(next.fanoutView, create(scope).fanoutView);
  }
  const legacy = create("department"); delete legacy.fanout; delete legacy.fanoutView;
  assert.equal(currentView(update(legacy, { type: "fanout" })).scope, "mine");
  assert.equal(update(legacy, { type: "fanout-status", status: "已结案" }), legacy);
});

test("Fanout uses only explicit incoming records across all three states and owner totals ignore every auxiliary condition", () => {
  const cases = statuses.flatMap((status, i) => [c(`normal-${i}`, { status }), c(`own-${i}`, { status, source: "fanout验证" }),
    c(`other-${i}`, { status, fanoutSourceCaseId: `normal-${i}`, owner: "李娜", createdBy: actor.name, participants: [{ name: actor.name }], departments: ["PTE"] })]);
  cases.push(c("outgoing", { fanoutTargets: ["p1"] }));
  const list = freeze(rows(cases, { subscribed: cases.map(record => record.id) }));
  const expected = { 进行中: 2, 验证中: 1, 已结案: 1 };
  let state = update(create(), { type: "fanout" });
  assert.deepEqual(ids(select(list, state, actor, departments, now).rows), ["own-0", "own-1", "own-2"]);
  for (const scope of scopes) for (const status of ["全部", ...statuses]) {
    state = update(state, { type: "scope", scope });
    state = update(state, { type: "fanout-status", status });
    const result = select(list, state, actor, departments, now);
    assert.ok(result.rows.every(row => row.fanout && (status === "全部" || row.status === status)));
    assert.equal(result.fanoutCount, 3);
    assert.deepEqual(plain(result.counts), expected);
    const empty = select(list, update(state, { type: "filters", patch: { product: "missing" } }), actor, departments, now);
    assert.equal(empty.total, 0); assert.equal(empty.fanoutCount, 3); assert.deepEqual(plain(empty.counts), expected);
  }
  for (const status of statuses) {
    const normal = stateFor({ status, source: "fanout" });
    assert.equal(select(list, normal, actor, departments, now).total, expected[status]);
  }
});

test("Fanout and lifecycle views independently restore relationship filters rules expansion and pages, including same-status exit", () => {
  let state = stateFor({ status: "已结案", scope: "subscribed", filters: dimensionFilters, page: 3 });
  state = update(state, { type: "expanded" });
  const normal = state.views.已结案;
  state = update(state, { type: "fanout" });
  for (const action of [{ type: "scope", scope: "created" }, { type: "filters", patch: { level: "L2" } },
    { type: "fanout-status", status: "验证中" }, { type: "custom-rules", rules: [{ id: "r", fieldId: "case:owner", operator: "in", values: ["李娜"] }] },
    { type: "expanded" }, { type: "page", page: 4 }]) state = update(state, action);
  const fanout = currentView(state); freeze(state);
  for (const status of ["已结案", "进行中", "验证中"]) {
    const restored = update(state, { type: "status", status });
    assert.equal(restored.fanout, false); assert.equal(restored.status, status);
    assert.equal(restored.views.已结案, normal); assert.equal(restored.fanoutView, fanout);
    assert.equal(currentView(update(restored, { type: "fanout" })), fanout);
  }
});

test("Fanout reset preserves top view role popup and all lifecycle snapshots while clearing dimensions custom drafts status and page", () => {
  let state = update(create("department"), { type: "fanout" });
  for (const action of [{ type: "scope", scope: "subscribed" }, { type: "filters", patch: dimensionFilters }, { type: "fanout-status", status: "已结案" },
    { type: "custom-rules", rules: [{ id: "draft", fieldId: "case:name", operator: "in", values: [] }] }, { type: "expanded" }, { type: "page", page: 9 }]) state = update(state, action);
  freeze(state); const before = JSON.stringify(state);
  const reset = update(state, { type: "reset" });
  assert.equal(reset.fanout, true); assert.equal(reset.status, state.status); assert.equal(reset.views, state.views);
  assert.deepEqual(plain(currentView(reset)), { ...plain(currentView(state)), filters: defaultFilters, customRules: [], statusFilter: "全部", page: 1 });
  assert.equal(JSON.stringify(state), before);
});

test("real custom rules match the same persisted recursive execution task before eight-row pagination and never alter summary counts", () => {
  const cases = freeze(Array.from({ length: 21 }, (_, i) => c(`custom-${String(i).padStart(2, "0")}`, { tasks: [action("stale", { owner: "wrong" })] })));
  const trees = freeze(Object.fromEntries(cases.map((record, i) => [record.id, [{ id: `thought-${i}`, title: "方向", children: i % 2 === 0
    ? [action(`match-${i}`, { owner: "王强", status: "已完成" })]
    : [action(`owner-${i}`, { owner: "王强" }), action(`done-${i}`, { owner: "李娜", status: "已完成" })] }]])));
  const before = JSON.stringify([cases, trees]);
  const list = freeze(rows(cases, { trees }));
  const records = buildCustomFilterRecords(cases, { loadTree: c => trees[c.id], status: normalizeStatus, closure: () => undefined });
  const fields = customFieldCatalog(records);
  const rules = [{ id: "owner", fieldId: "task:owner", operator: "in", values: ["王强"] }, { id: "done", fieldId: "task:status", operator: "in", values: ["已完成"] },
    { id: "draft", fieldId: "case:name", operator: "in", values: [] }];
  let state = update(create(), { type: "custom-rules", rules });
  const seen = [];
  for (const page of [1, 2]) {
    state = update(state, { type: "page", page });
    const result = select(list, state, actor, departments, now, { records, fields });
    assert.equal(result.total, 11); assert.equal(result.pages, 2); assert.equal(result.appliedCustomRules.length, 2);
    assert.equal(result.counts.进行中, 21); assert.equal(result.candidates.length, 21);
    seen.push(...ids(result.rows));
  }
  assert.deepEqual(seen, cases.filter((_, i) => i % 2 === 0).map(c => c.id));
  assert.deepEqual(plain(customFilterOptions(records, fields.find(f => f.id === "task:owner"))).sort(), ["李娜", "王强"].sort());
  assert.equal(JSON.stringify([cases, trees]), before);
});

test("cross-status Fanout sorting is deterministic priority/due/updated before pagination even when entered from closed", () => {
  const cases = Array.from({ length: 18 }, (_, i) => c(`fan-${String(i).padStart(2, "0")}`, { status: statuses[i % 3], source: "fanout验证", dueDate: `2026-09-${String(i + 1).padStart(2, "0")}` }));
  cases.push(c("urgent", { status: "已结案", source: "fanout验证", urgency: "非常紧急", dueDate: "2026-12-30" }));
  const list = freeze(rows(cases));
  const expected = ["urgent", ...cases.slice(0, 18).map(c => c.id)];
  for (const status of statuses) {
    let state = update(stateFor({ status }), { type: "fanout" });
    const seen = [];
    for (const page of [1, 2, 3]) {
      state = update(state, { type: "page", page });
      const result = select([...list].reverse(), state, actor, departments, now);
      assert.equal(result.total, 19); assert.equal(result.fanoutCount, 19); seen.push(...ids(result.rows));
    }
    assert.deepEqual(seen, expected); assert.equal(new Set(seen).size, 19);
  }
});

const topViews = [...statuses, "Fanout"];
const enterView = (state, view) => update(state, view === "Fanout" ? { type: "fanout" } : { type: "status", status: view });

test("all three normal statuses exclude Fanout in every people view, candidates and scope counts even under custom rules", () => {
  const cases = freeze(statuses.flatMap((status, i) => [
    c(`normal-own-${i}`, { status, product: "match", fanoutTargets: ["p1"] }),
    c(`normal-other-${i}`, { status, product: "match", owner: "李娜", createdBy: actor.name, participants: [{ name: actor.name }], departments: ["PTE"], parentCaseId: `normal-own-${i}` }),
    c(`fan-own-${i}`, { status, product: "match", source: "fanout验证" }),
    c(`fan-other-${i}`, { status, product: "match", fanoutSourceCaseId: `normal-own-${i}`, owner: "李娜", createdBy: actor.name, participants: [{ name: actor.name }], departments: ["PTE"] }),
  ]));
  const list = freeze(rows(cases, { subscribed: cases.map(record => record.id) }));
  const records = buildCustomFilterRecords(cases, { loadTree: c => c.tasks, status: normalizeStatus, closure: () => undefined });
  const fields = customFieldCatalog(records);
  const before = JSON.stringify([cases, list]);
  const expectedScopes = { mine: 1, participating: 1, created: 1, department: 2, subscribed: 2 };
  for (const [i, status] of statuses.entries()) for (const scope of scopes) for (const source of ["all", "fanout"]) {
    let state = stateFor({ status, scope, source, page: 99 });
    state = update(state, { type: "custom-rules", rules: [{ id: "match", fieldId: "case:product", operator: "in", values: ["match"] }] });
    const result = select(list, state, actor, departments, now, { records, fields });
    assert.equal(result.total, expectedScopes[scope]);
    assert.equal(result.candidates.length, expectedScopes[scope]);
    assert.ok([...result.rows, ...result.candidates].every(row => !row.fanout && row.status === status));
    assert.deepEqual(plain(result.scopeCounts), expectedScopes);
    assert.deepEqual(plain(result.counts), { 进行中: 1, 验证中: 1, 已结案: 1 });
    assert.equal(result.fanoutCount, 3);
    const fanout = select(list, update(enterView(state, "Fanout"), { type: "scope", scope }), actor, departments, now);
    assert.equal(fanout.total, expectedScopes[scope] * 3);
    assert.ok(fanout.rows.every(row => row.fanout));
    assert.equal(list.find(row => row.id === `normal-other-${i}`).fanout, false);
  }
  assert.equal(JSON.stringify([cases, list]), before);
});

test("Case sort options match analysis and optional or invalid saved sort values fall back per top view without rewriting snapshots", () => {
  assert.deepEqual(plain(CASE_WORKBENCH_SORT_OPTIONS), [
    { value: "urgency", label: "紧迫度" }, { value: "level", label: "层级" },
    { value: "progress", label: "进度(低→高)" }, { value: "updated", label: "最近更新" },
  ]);
  for (const view of topViews) for (const stale of [undefined, null, "", "due", "constructor", "UPDATED", 1]) {
    const state = enterView(create(), view);
    if (stale !== undefined) currentView(state).sortBy = stale;
    freeze(state); const before = JSON.stringify(state);
    const expected = view === "已结案" ? "updated" : "urgency";
    assert.equal(sortBy(state), expected);
    assert.equal(select([], state, actor, departments, now).sortBy, expected);
    assert.equal(Object.hasOwn(currentView(state), "sortBy"), stale !== undefined);
    assert.equal(JSON.stringify(state), before);
  }
});

test("sort changes preserve filters role custom rules and open state, reset only the current page, and remember all four views", () => {
  let state = create(); const saved = new Map();
  for (const [i, view] of topViews.entries()) {
    state = enterView(state, view);
    for (const action of [{ type: "scope", scope: scopes[i + 1] }, { type: "filters", patch: dimensionFilters },
      { type: "custom-rules", rules: [{ id: view, fieldId: "case:name", operator: "in", values: [view] }] },
      { type: "expanded" }, { type: "page", page: i + 2 }]) state = update(state, action);
    if (view === "Fanout") state = update(state, { type: "fanout-status", status: "验证中" });
    state = update(state, { type: "page", page: i + 2 });
    const previous = freeze(state); const current = currentView(previous);
    const value = ["level", "progress", "urgency", "updated"][i];
    state = update(previous, { type: "sort", sortBy: value });
    assert.deepEqual(plain(currentView(state)), { ...plain(current), sortBy: value, page: 1 });
    assert.equal(currentView(state).filters, current.filters);
    assert.equal(currentView(state).customRules, current.customRules);
    for (const other of topViews.filter(other => other !== view)) assert.equal(currentView(enterView(state, other)), currentView(enterView(previous, other)));
    state = update(state, { type: "page", page: i + 3 });
    saved.set(view, currentView(state));
  }
  for (const view of [...topViews].reverse()) {
    state = enterView(state, view);
    assert.equal(currentView(state), saved.get(view));
    assert.equal(sortBy(state), saved.get(view).sortBy);
    assert.equal(update(state, { type: "sort", sortBy: sortBy(state) }), state);
  }
});

test("reset is filter-only for all four top views and retains explicit sorting plus untouched other view snapshots", () => {
  let state = create();
  for (const [i, view] of topViews.entries()) {
    state = enterView(state, view);
    for (const action of [{ type: "sort", sortBy: ["level", "progress", "urgency", "updated"][i] },
      { type: "scope", scope: "subscribed" }, { type: "filters", patch: dimensionFilters },
      { type: "custom-rules", rules: [{ id: "draft", fieldId: "case:name", operator: "in", values: [] }] }, { type: "expanded" },
      ...(view === "Fanout" ? [{ type: "fanout-status", status: "已结案" }] : []), { type: "page", page: 8 }]) state = update(state, action);
  }
  freeze(state); const before = JSON.stringify(state);
  for (const view of topViews) {
    const selectedState = enterView(state, view); const current = currentView(selectedState);
    const reset = update(selectedState, { type: "reset" });
    assert.deepEqual(plain(currentView(reset)), { ...plain(current), filters: defaultFilters, customRules: [], page: 1, ...(view === "Fanout" ? { statusFilter: "全部" } : {}) });
    assert.equal(sortBy(reset), current.sortBy);
    for (const other of topViews.filter(other => other !== view)) assert.equal(currentView(enterView(reset, other)), currentView(enterView(state, other)));
  }
  assert.equal(JSON.stringify(state), before);
});

test("invalid and repeated sort actions are identity no-ops; first explicit closed updated opts out of legacy closure ordering", () => {
  for (const view of topViews) {
    let state = update(enterView(create(), view), { type: "page", page: 4 });
    for (const value of [undefined, null, "", "due", "LEVEL", "constructor", 12, {}, []]) assert.equal(update(state, { type: "sort", sortBy: value }), state);
    if (view !== "已结案") assert.equal(update(state, { type: "sort", sortBy: "urgency" }), state);
    else {
      const explicit = update(state, { type: "sort", sortBy: "updated" });
      assert.notEqual(explicit, state); assert.equal(explicit.views.已结案.sortBy, "updated"); assert.equal(explicit.views.已结案.page, 1);
      assert.equal(update(explicit, { type: "sort", sortBy: "updated" }), explicit);
    }
    state = update(state, { type: "sort", sortBy: "level" });
    state = freeze(update(state, { type: "page", page: 4 }));
    assert.equal(update(state, { type: "sort", sortBy: "level" }), state);
    assert.equal(currentView(state).page, 4);
  }
});

test("each sort orders the full filtered selection before eight-row pages in every top view without changing any counts or candidates", () => {
  for (const view of topViews) {
    const cases = freeze(Array.from({ length: 19 }, (_, i) => c(`sorted-${String(i).padStart(2, "0")}`, {
      status: view === "Fanout" ? statuses[i % 3] : view, source: view === "Fanout" ? "fanout验证" : "手动",
      level: `L${(18 - i) % 4}`, urgency: ["非常紧急", "紧急", "一般", "不紧急"][(i * 3) % 4],
      dueDate: `2026-09-${String(i + 1).padStart(2, "0")}`, dueIn: -i,
      updatedAt: `2026-08-${String(i + 1).padStart(2, "0")}T10:00:00Z`,
      tasks: [action(`task-${i}`, { progress: ((i * 7) % 19) * 5 })], product: i % 3 === 0 ? "LPDDR" : "DDR5",
    })));
    const list = freeze(rows([...cases].reverse(), { subscribed: cases.map(c => c.id) }));
    const before = JSON.stringify([cases, list]);
    for (const filters of [{}, { product: "DDR5" }]) {
      let state = update(enterView(create(), view), { type: "filters", patch: filters });
      const baseline = select(list, state, actor, departments, now);
      for (const option of CASE_WORKBENCH_SORT_OPTIONS) {
        const indexes = cases.map((_, i) => i).filter(i => !filters.product || i % 3 !== 0);
        const primary = { urgency: (a, b) => (a * 3) % 4 - (b * 3) % 4 || a - b,
          level: (a, b) => (18 - a) % 4 - (18 - b) % 4,
          progress: (a, b) => (a * 7) % 19 - (b * 7) % 19, updated: (a, b) => b - a }[option.value];
        const expected = indexes.sort((a, b) => primary(a, b) || a - b).map(i => cases[i].id);
        assert.ok(expected.length > 8);
        state = update(state, { type: "sort", sortBy: option.value });
        const seen = [];
        for (let page = 1; page <= Math.ceil(expected.length / 8); page++) {
          state = update(state, { type: "page", page });
          const result = select(list, state, actor, departments, now);
          assert.equal(result.sortBy, option.value);
          assert.deepEqual(ids(result.rows), expected.slice((page - 1) * 8, page * 8), `${view}/${option.value}/${page}`);
          assert.deepEqual(plain(result.counts), plain(baseline.counts)); assert.equal(result.fanoutCount, baseline.fanoutCount);
          assert.deepEqual(plain(result.scopeCounts), plain(baseline.scopeCounts)); assert.deepEqual(ids(result.candidates), ids(baseline.candidates));
          assert.equal(result.total, expected.length); assert.equal(result.pages, Math.ceil(expected.length / 8));
          seen.push(...ids(result.rows));
        }
        assert.deepEqual(seen, expected); assert.equal(new Set(seen).size, expected.length);
      }
    }
    assert.equal(JSON.stringify([cases, list]), before);
  }
});

test("progress uses one actual persisted recursive coded-task read, finite numeric values clamped before averaging, and omits missing progress", () => {
  const cases = freeze([c("persisted", { tasks: [action("stale", { progress: 1 })] }), c("empty"), c("invalid")]);
  const trees = freeze({ persisted: [{ id: "thought", title: "方向", progress: 99, children: [
    action("negative", { progress: -20, children: [action("over", { progress: 160 })] }),
    action("twenty", { progress: 20 }), action("complete", { progress: 100, status: "已完成", activityLog: [{ id: "saved-history" }] }),
    ...[NaN, Infinity, -Infinity, "35", undefined, null].map((progress, i) => action(`invalid-${i}`, { progress })),
    { id: "uncoded", code: "", progress: 50 },
  ] }], empty: [], invalid: [action("nan", { progress: NaN }), action("string", { progress: "70" })] });
  const calls = []; const before = JSON.stringify([cases, trees]);
  const list = freeze(rows(cases, { loadTree: c => { calls.push(c.id); return trees[c.id]; } }));
  assert.deepEqual(calls, cases.map(c => c.id));
  assert.equal(list[0].taskCount, 10); assert.equal(list[0].progress, 55);
  assert.ok(list.slice(1).every(row => !Object.hasOwn(row, "progress")));
  for (const sortBy of ["progress", "level", "updated", "urgency"]) selected(list, { sortBy });
  assert.equal(calls.length, cases.length);
  assert.equal(JSON.stringify([cases, trees]), before);
  assert.equal(list[0].record, cases[0]); assert.equal(cases[0].tasks[0].progress, 1);
});

test("level is L0-first, equal levels use stable IDs not urgency, and malformed or missing levels sort last", () => {
  const list = freeze(rows([
    c("bad-c", { level: "constructor" }), c("l3", { level: "L3" }), c("tie-z", { level: "L1", urgency: "非常紧急" }),
    c("bad-a", { level: undefined }), c("l0", { level: "L0" }), c("l2", { level: "L2" }),
    c("tie-a", { level: "L1", urgency: "不紧急" }), c("bad-b", { level: "L9" }),
  ]));
  for (const input of [list, [...list].reverse()]) assert.deepEqual(ids(selected(input, { sortBy: "level" }).rows), ["l0", "tie-a", "tie-z", "l2", "l3", "bad-a", "bad-b", "bad-c"]);
});

test("progress sorts low to high including zero, stabilizes equal progress by ID and places absent or invalid progress last", () => {
  const list = freeze(rows([
    c("invalid-z", { tasks: [action("inf", { progress: Infinity })] }), c("mid-z", { urgency: "非常紧急", tasks: [action("z", { progress: 20 })] }),
    c("empty"), c("high", { tasks: [action("high", { progress: 120 })] }), c("low", { tasks: [action("low", { progress: -1 })] }),
    c("invalid-a", { tasks: [action("nan", { progress: NaN })] }), c("string", { tasks: [action("string", { progress: "30" })] }),
    c("mid-a", { urgency: "不紧急", tasks: [action("a", { progress: 20 })] }),
  ]));
  for (const input of [list, [...list].reverse()]) assert.deepEqual(ids(selected(input, { sortBy: "progress" }).rows), ["low", "mid-a", "mid-z", "high", "empty", "invalid-a", "invalid-z", "string"]);
});

test("explicit updated uses latest genuine Case or closure activity, rejects impossible calendar dates, and keeps old closed default separate", () => {
  const cases = freeze([c("old-close", { status: "已结案", updatedAt: "2026-12-01T10:00:00Z" }), c("new-close"),
    c("root-later", { updatedAt: "bad" }), c("leap", { status: "已结案", updatedAt: "2024-02-29T12:00:00Z" }),
    c("invalid-a", { status: "已结案", updatedAt: "2026-02-29T12:00:00Z", createdAt: "2099-01-01" }),
    c("invalid-z", { status: "已结案", updatedAt: undefined })]);
  const closures = freeze({
    "old-close": { state: "closed", closedAt: "2026-09-01T10:00:00Z" }, "new-close": { state: "closed", closedAt: "2026-09-08T10:00:00Z" },
    "root-later": { state: "closed", closedAt: "2026-09-02T10:00:00Z", rootCauseAt: "2026-09-12T10:00:00Z" },
    "invalid-a": { state: "closed", closedAt: "2026-02-30T10:00:00Z", rootCauseAt: "2026-09-31T12:00:00Z" },
  });
  const list = freeze(rows(cases, { closures })); const state = stateFor({ status: "已结案", page: 3 });
  const before = JSON.stringify([cases, closures, list, state]);
  assert.deepEqual(ids(select(list, state, actor, departments, now).rows), ["new-close", "root-later", "old-close", "leap", "invalid-a", "invalid-z"]);
  const explicit = update(state, { type: "sort", sortBy: "updated" });
  for (const input of [list, [...list].reverse()]) assert.deepEqual(ids(select(input, explicit, actor, departments, now).rows), ["old-close", "root-later", "new-close", "leap", "invalid-a", "invalid-z"]);
  assert.equal(list[4].updatedAt, ""); assert.equal(list[4].closedAt, undefined);
  assert.equal(explicit.views.已结案.page, 1);
  assert.equal(sortBy(state), "updated"); assert.equal(sortBy(explicit), "updated");
  assert.equal(JSON.stringify([cases, closures, list, state]), before);
});

test("explicit urgency in all four views retains priority then real deadline then latest activity, never dueIn or closure-first", () => {
  for (const view of topViews) {
    const cases = [c("normal", { dueDate: "2020-01-01" }), c("invalid", { urgency: "非常紧急", dueDate: "2026-02-31" }),
      c("tie-z", { urgency: "非常紧急", dueDate: "2026-09-09", dueIn: -999, updatedAt: "2026-09-01T10:00:00Z" }),
      c("tie-a", { urgency: "非常紧急", dueDate: "2026-09-09", dueIn: 999, updatedAt: "2026-09-10T10:00:00Z" }),
      c("later", { urgency: "非常紧急", dueDate: "2026-09-12", updatedAt: "2026-09-30T10:00:00Z" }),
      c("unknown", { urgency: "constructor", dueDate: "2010-01-01" })].map(c => ({ ...c, status: view === "Fanout" ? "已结案" : view, source: view === "Fanout" ? "fanout验证" : "手动" }));
    const list = freeze(rows(cases));
    let state = enterView(create(), view);
    state = update(state, { type: "sort", sortBy: "level" });
    state = update(state, { type: "sort", sortBy: "urgency" });
    assert.deepEqual(ids(select(list, state, actor, departments, now).rows), ["tie-a", "tie-z", "later", "invalid", "normal", "unknown"], view);
  }
});

test("all sort ties use stable keys with missing keys last and never reorder the supplied frozen array", () => {
  const list = freeze(rows([c("", { tasks: [action("missing", { progress: 50 })] }), c("z", { tasks: [action("z", { progress: 50 })] }), c("a", { tasks: [action("a", { progress: 50 })] })]));
  const before = JSON.stringify(list);
  for (const sortBy of ["urgency", "level", "progress", "updated"]) for (const input of [list, [...list].reverse()]) assert.deepEqual(ids(selected(input, { sortBy }).rows), ["a", "z", ""]);
  assert.equal(JSON.stringify(list), before);
});

test("custom-rules actions and selector reads normalize legacy operators independently in all four views without hidden predicates", () => {
  for (const view of topViews) {
    const cases = freeze([c("keep", { product: "keep" }), c("other", { product: "other" })].map(record => ({
      ...record, status: view === "Fanout" ? "验证中" : view, ...(view === "Fanout" ? { source: "fanout验证" } : {}),
    })));
    const list = freeze(rows(cases));
    const records = freeze(buildCustomFilterRecords(cases, { loadTree: c => c.tasks, status: normalizeStatus, closure: () => undefined }));
    const fields = freeze(customFieldCatalog(records));
    const legacy = freeze([
      { id: "text", fieldId: "case:name", operator: "contains", values: ["nonexistent"] },
      { id: "number", fieldId: "case:dueIn", operator: "gte", values: ["0"] },
      { id: "date", fieldId: "case:dueDate", operator: "between", values: ["2026-09-01", "2026-09-30"] },
      { id: "boolean", fieldId: "task:likedByMe", operator: "notIn", values: ["true"] },
    ]);
    const keep = freeze({ id: "keep", fieldId: "case:product", operator: "in", values: ["keep"] });
    const dataBefore = JSON.stringify([cases, list, records, fields, legacy, keep]);
    for (const valid of [[], [keep]]) {
      const rules = freeze([...legacy, ...valid]);
      let state = enterView(create(), view);
      state = update(update(state, { type: "expanded" }), { type: "page", page: 9 });
      // Inject old state directly: the selector must be safe even before any action.
      currentView(state).customRules = rules;
      freeze(state); const before = JSON.stringify(state);
      const baseline = select(list, enterView(create(), view), actor, departments, now, { records, fields });
      const expected = valid.length ? ["keep"] : ["keep", "other"];
      const selected = select(list, state, actor, departments, now, { records, fields });
      assert.deepEqual(ids(selected.rows), expected);
      assert.deepEqual(plain(selected.appliedCustomRules), plain(valid));
      assert.deepEqual(plain(selected.counts), plain(baseline.counts)); assert.equal(selected.fanoutCount, baseline.fanoutCount);
      assert.deepEqual(ids(selected.candidates), ids(baseline.candidates));
      assert.equal(selected.scopeCounts.mine, expected.length);
      const next = update(state, { type: "custom-rules", rules });
      const normalized = currentView(next).customRules;
      assert.deepEqual(plain(normalized), [...legacy.map(rule => ({ ...rule, operator: "in", values: [] })), ...valid]);
      assert.notEqual(normalized, rules);
      legacy.forEach((rule, i) => assert.notEqual(normalized[i], rule));
      if (valid.length) { assert.equal(normalized.at(-1), keep); assert.equal(normalized.at(-1).values, keep.values); }
      assert.equal(currentView(next).page, 1); assert.equal(currentView(next).expanded, true);
      assert.equal(currentView(next).filters, currentView(state).filters);
      for (const other of topViews.filter(other => other !== view)) assert.equal(currentView(enterView(next, other)), currentView(enterView(state, other)));
      assert.deepEqual(ids(select(list, next, actor, departments, now, { records, fields }).rows), expected);
      assert.equal(JSON.stringify(state), before);
    }
    assert.equal(JSON.stringify([cases, list, records, fields, legacy, keep]), dataBefore);
  }
});