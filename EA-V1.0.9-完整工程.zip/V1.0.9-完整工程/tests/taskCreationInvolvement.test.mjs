import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { webcrypto } from "node:crypto";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";
import vm from "node:vm";
import { build } from "esbuild";
import { renderToStaticMarkup } from "react-dom/server";

const require = createRequire(import.meta.url);
const React = require("react");
const directory = new URL("../src/app/components/", import.meta.url);
const source = readFileSync(new URL("CreateStandaloneTask.tsx", directory), "utf8");
// Name the component's state slots from its declarations, rather than hard-coding
// hook indices. Every render checks the count; an unsupported hook layout fails.
const stateNames = Array.from(source.matchAll(/^\s*const\s+\[\s*(\w+)[^\]\n]*\]\s*=\s*useState\b/gm), match => match[1]);
const { outputFiles } = await build({
  stdin: {
    contents: `export { CreateStandaloneTask } from './CreateStandaloneTask';
      export { CreateEntryDialog } from './CreateEntryDialog';
      export { TASK_INVOLVEMENT_KINDS } from './standaloneTaskConfig';`,
    resolveDir: fileURLToPath(directory), loader: "ts",
  },
  bundle: true, write: false, platform: "node", format: "cjs", jsx: "automatic",
  packages: "external",
  external: ["./data", "./AttachmentInput", "./PersonInput", "./CreationCollaboratorInput", "./ProductPicker", "./standaloneTasks", "./VoiceNote", "./ui/segmented-control", "./taskVisibility"],
});
const plain = value => JSON.parse(JSON.stringify(value));
const actor = Object.freeze({ name: "张伟", department: "PTE" });
const product = Object.freeze({ id: "product-exact-id", code: "DDR5-TEST", name: "测试产品" });
const fields = { title: "产品核对任务", description: "核对产品资料与完成标准", dueDate: "2026-09-20" };
const modes = ["simple", "advanced"];

const caseForms = await build({
  stdin: { contents: `export { CreateCase } from './CreateCase'; export { CreateCaseLab } from './CreateCaseLab'; export { useStandaloneTasks } from './standaloneTasks';`, resolveDir: fileURLToPath(directory), loader: "tsx" },
  bundle: true, write: false, platform: "node", format: "cjs", jsx: "automatic", packages: "external",
  external: ["./CreateCaseMindMapFlow", "./CreateCaseWbsTable"], loader: { ".css": "empty" },
});

for (const name of ["CreateCase", "CreateCaseLab"]) test(`${name} really mounts with standalone upgrade sources without creating a Case`, () => {
  const task = { id: "form-source", code: "TASK-FORM", title: "原任务", description: "原说明", owner: "张伟", createdBy: "李娜", createdForOther: true, status: "待接受", collaborators: [], attachments: [], urgency: "一般", dueDate: "2026-09-20", createdAt: "2026-09-10", updatedAt: "2026-09-10" };
  const storage = new Map([["ea_standalone_tasks_v1", JSON.stringify([task])]]);
  const sandbox = { module: { exports: {} }, crypto: webcrypto, console, btoa, atob,
    localStorage: { getItem: key => storage.get(key) ?? null, setItem: (key, value) => storage.set(key, value) },
    require: dependency => dependency === "./CreateCaseMindMapFlow" ? { CreateCaseMindMapFlow: () => null } : dependency === "./CreateCaseWbsTable" ? { CreateCaseWbsTable: () => null } : require(dependency),
  };
  vm.runInNewContext(caseForms.outputFiles[0].text, sandbox);
  const api = sandbox.module.exports;
  function Prime() { api.useStandaloneTasks(); return null; }
  renderToStaticMarkup(React.createElement(Prime));
  const before = storage.get("ea_standalone_tasks_v1");
  const html = renderToStaticMarkup(React.createElement(api[name], { onDone() { throw new Error("Render must not navigate"); }, prefill: { name: task.title, sourceStandaloneTaskIds: [task.id] } }));
  assert.match(html, />新建 Case<\/h1>/); assert.match(html, /带入的自由任务/); assert.match(html, /TASK-FORM/); assert.match(html, /原任务/);
  assert.match(html, />为分派<\/button>/); assert.doesNotMatch(html, /为别人创建/);
  assert.equal(storage.get("ea_standalone_tasks_v1"), before);
  assert.equal(JSON.parse(storage.get("ea_domain_v6") ?? '{"spawnedCases":[]}').spawnedCases.length, 0);
});

function elements(tree) {
  if (Array.isArray(tree)) return Array.from(tree).flatMap(elements);
  return React.isValidElement(tree) ? [tree, ...elements(tree.props.children)] : [];
}
function text(tree) {
  if (Array.isArray(tree)) return Array.from(tree).map(text).join("");
  if (React.isValidElement(tree)) return text(tree.props.children);
  return typeof tree === "string" || typeof tree === "number" ? String(tree) : "";
}

function harness(initialTask, control = {}) {
  const state = new Map();
  const edits = []; const cancelled = [];
  const payloads = []; const created = []; const presets = []; const events = [];
  // Deliberately a sentinel, not a fake implementation of task normalization.
  const result = Object.freeze({ id: "captured-task", visibility: Object.freeze({ type: "all", people: Object.freeze([]) }) });
  const leaves = Object.fromEntries(["AttachmentInput", "PersonInput", "MultiPersonInput", "CreationCollaboratorInput", "ProductPicker", "VoiceRecorder", "SegmentedControl"].map(name => [name,
    props => React.createElement("span", { "data-test-leaf": name, "data-value": typeof props.value === "string" ? props.value : undefined }, props.placeholder),
  ]));
  let cursor = 0; let tree; let html;
  const stubs = {
    // Only useState is virtualized for explicit callback-driven rerenders.
    // React elements, SSR, useRef/useEffect, icons and assignment resolution are
    // real. Leaf widgets are boundaries: their internal interaction is not tested.
    react: { ...React, useState(initial) {
      const name = stateNames[cursor++];
      assert.ok(name, "Unexpected useState call: update the bounded state harness");
      if (!state.has(name)) state.set(name, typeof initial === "function" ? initial() : initial);
      return [state.get(name), next => state.set(name, typeof next === "function" ? next(state.get(name)) : next)];
    } },
    "./data": {
      currentUser: actor, departments: ["PTE", "FT"],
      PROBLEM_DOMAINS: ["Testing", "Design"], PROBLEM_TYPES: ["DFT", "IO", "Others"],
      departmentSupervisors: { PTE: "周主管", FT: "王主管" },
      ownerToDepartment: { 张伟: "PTE", 李娜: "DA", 周主管: "PTE", 王主管: "FT", 周杰: "PTE", 王芳: "FT", 刘洋: "PTE" },
      productById: id => id === product.id ? product : undefined,
      domainProductKR: (domain, productId) => domain === "Testing" && productId === product.id ? "张伟" : "李娜",
    },
    "./AttachmentInput": { AttachmentInput: leaves.AttachmentInput },
    "./PersonInput": { PersonInput: leaves.PersonInput, MultiPersonInput: leaves.MultiPersonInput },
    "./CreationCollaboratorInput": { CreationCollaboratorInput: leaves.CreationCollaboratorInput },
    "./ProductPicker": { ProductPicker: leaves.ProductPicker },
    "./VoiceNote": { VoiceRecorder: leaves.VoiceRecorder },
    "./ui/segmented-control": { SegmentedControl: leaves.SegmentedControl },
    "./standaloneTasks": {
      createStandaloneTask(input) { payloads.push(input); events.push("create"); return result; },
      editStandaloneTask(id, input, expected) {
        if (control.fail) throw new Error("保存失败，请重试");
        edits.push({ id, input, expected }); events.push("edit"); return { ...result, id };
      },
    },
    "./taskVisibility": {
      loadTaskVisibilityPreset: () => ({ type: "all", people: [] }),
      saveTaskVisibilityPreset(value) { presets.push(value); events.push("preset"); },
    },
  };
  const sandbox = { module: { exports: {} }, require(name) {
    if (Object.hasOwn(stubs, name)) return stubs[name];
    if (["react/jsx-runtime", "lucide-react", "@radix-ui/react-dialog"].includes(name)) return require(name);
    throw new Error(`Unexpected dependency in creation test: ${name}`);
  } };
  for (const name of ["localStorage", "sessionStorage"]) Object.defineProperty(sandbox, name, {
    get() { throw new Error(`${name} must not be accessed by this test`); },
  });
  vm.runInNewContext(outputFiles[0].text, sandbox);
  const api = sandbox.module.exports;
  function Capture() {
    cursor = 0;
    tree = api.CreateStandaloneTask({ initialTask, onCancel() { cancelled.push(true); }, onCreated(task) { created.push(task); events.push("created"); } });
    assert.equal(cursor, stateNames.length, "State declarations and runtime hook count disagree");
    return tree;
  }
  function render() { html = renderToStaticMarkup(React.createElement(Capture)); return html; }
  function find(predicate, description) {
    const matches = elements(tree).filter(predicate);
    assert.equal(matches.length, 1, `Expected exactly one ${description}`);
    return matches[0];
  }
  const byId = id => find(node => node.props.id === id, id);
  const leaf = name => find(node => node.type === leaves[name], name);
  function act(callback, ...args) {
    assert.equal(typeof callback, "function", "Expected a real rendered callback");
    callback(...args);
    render();
  }
  const change = (id, value) => act(byId(id).props.onChange, { target: { value } });
  const toggle = () => act(find(node => node.props.role === "switch", "advanced switch").props.onClick);
  const method = value => act(find(node => node.type === "input" && node.props.name === "task-assignment-method" && node.props.value === value, `assignment method ${value}`).props.onChange);
  const button = label => find(node => node.type === "button" && text(node) === label, label);
  render();
  return {
    render, act, change, toggle, method, byId, leaf, button, payloads, created, presets, events, result, edits, cancelled,
    get tree() { return tree; },
    legacyKinds: api.TASK_INVOLVEMENT_KINDS,
    get html() { return html; },
    hasLeaf: name => elements(tree).some(node => node.type === leaves[name]),
    // Only for impossible/stale drafts (e.g. HMR), never to implement validation.
    stale(patch) {
      for (const [name, value] of Object.entries(patch)) {
        assert.ok(state.has(name), `Unknown state slot ${name}`);
        state.set(name, value);
      }
      render();
    },
  };
}

function ready(mode = "simple") {
  const h = harness();
  h.change("task-title", fields.title);
  h.change("task-description", fields.description);
  h.change("task-due-date", fields.dueDate);
  if (mode === "advanced") { h.toggle(); h.change("task-handling-department", "FT"); }
  return h;
}
function pickProduct(h, id = product.id) {
  h.act(h.leaf("ProductPicker").props.onChange, id);
}
function assertNoWrites(h) {
  assert.deepEqual(h.payloads, []);
  assert.deepEqual(h.created, []);
  assert.deepEqual(h.presets, []);
  assert.deepEqual(h.events, []);
}
function assertSubmit(h, allowed, context) {
  const button = h.button("创建自由任务");
  assert.equal(button.props.disabled, !allowed, context);
  // Invoke even disabled buttons: the handler must guard the store boundary too.
  button.props.onClick();
  if (!allowed) { assertNoWrites(h); return; }
  assert.equal(h.payloads.length, 1, context);
  assert.equal(h.created[0], h.result);
  assert.deepEqual(h.presets, []);
  assert.deepEqual(h.events, ["create", "created"]);
  assert.equal(h.payloads[0].visibilityType, "all"); assert.deepEqual(plain(h.payloads[0].visiblePeople), []);
  button.props.onClick();
  assert.equal(h.payloads.length, 1, "Same captured callback must not submit twice");
  assert.equal(h.created.length, 1);
}

test("direct and department creation hide product and collaborators without narrowing legacy metadata", () => {
  assert.doesNotMatch(source, /\b(?:useProjects|allProjects|projectById|DEMO_TASK_FORCES)\b|task-(?:project|tf)\b/);
  for (const mode of modes) {
    const h = harness();
    if (mode === "advanced") h.toggle();
    assert.doesNotMatch(h.html, /关联产品|协作者|Project|\bTF\b|task-involvement/);
    assert.equal(h.hasLeaf("ProductPicker"), false);
    assert.equal(h.hasLeaf("CreationCollaboratorInput"), false);
    assert.deepEqual(plain(h.legacyKinds), ["产品", "Project", "TF", "无"]);
    assertSubmit(h, false, `${mode}: required fields still empty`);
  }
});

test("Domain/type requires a real product in the left basic section and keeps a draft when switching modes", () => {
  const h = ready("advanced");
  h.method("domain-type");
  assert.match(source, /<div className="grid grid-cols-3 items-end gap-2">\s*<Field label="关联产品"/);
  assert.equal(h.leaf("ProductPicker").props.placeholder, "请选择产品");
  assert.equal(h.byId("task-domain").props.disabled, true);
  assert.equal(h.byId("task-problem-type").props.disabled, true);
  assertSubmit(h, false, "Product is mandatory");
  const sections = elements(h.tree).filter(node => node.type === "section");
  assert.ok(elements(sections[0]).includes(h.leaf("ProductPicker")));
  assert.ok(!elements(sections[1]).includes(h.leaf("ProductPicker")));
  pickProduct(h); assert.equal(h.byId("task-domain").props.disabled, false);
  h.change("task-domain", "Testing"); assert.equal(h.byId("task-problem-type").props.disabled, false);
  const typeOptions = elements(h.byId("task-problem-type")).filter(node => node.type === "option");
  assert.deepEqual(typeOptions.map(text), ["请选择类型", "DFT", "IO", "Others（暂无 KR）"]);
  assert.equal(typeOptions.at(-1).props.disabled, true);
  h.change("task-problem-type", "DFT"); assert.equal(h.button("创建自由任务").props.disabled, false);
  h.method("department"); assert.equal(h.hasLeaf("ProductPicker"), false);
  h.method("domain-type"); assert.equal(h.leaf("ProductPicker").props.value, product.id);
  h.toggle(); assert.equal(h.hasLeaf("ProductPicker"), false);
  h.toggle(); assert.equal(h.leaf("ProductPicker").props.value, product.id);
  assertNoWrites(h);
});

test("reference validation and existing field, routing and busy gates all guard submit", () => {
  for (const id of ["", "missing-product", product.code, product.id]) {
    const h = ready("advanced"); h.method("domain-type"); pickProduct(h, id); h.change("task-domain", "Testing"); h.change("task-problem-type", "DFT");
    assertSubmit(h, id === product.id, `Domain/type product ${id}`);
  }
  for (const mode of modes) {
    const gates = [
      ["empty title", h => h.change("task-title", "")],
      ["whitespace title", h => h.change("task-title", "   ")],
      ["empty description", h => h.change("task-description", "")],
      ["whitespace description", h => h.change("task-description", " \n ")],
      ["empty date", h => h.change("task-due-date", "")],
      ["invalid date", h => h.change("task-due-date", "invalid-date")],
      ["uploading", h => h.act(h.leaf("AttachmentInput").props.onUploadingChange, true)],
      ["voice busy", h => h.act(h.leaf("VoiceRecorder").props.onBusyChange, true)],
      ["missing owner/routing", h => mode === "simple" ? h.act(h.button("为他人创建").props.onClick) : h.change("task-handling-department", "")],
    ];
    for (const [label, invalidate] of gates) {
      const h = ready(mode);
      assert.equal(h.button("创建自由任务").props.disabled, false);
      invalidate(h);
      assertSubmit(h, false, `${mode}: ${label} despite a valid product`);
    }
  }
  const h = ready();
  h.toggle();
  assertSubmit(h, false, "Enabling advanced mode requires assignment conditions");
  h.method("domain-type"); pickProduct(h); h.change("task-domain", "Testing");
  assertSubmit(h, false, "Domain without type cannot resolve an owner");
  h.change("task-problem-type", "DFT"); h.change("task-domain", "");
  assertSubmit(h, false, "Type without Domain cannot resolve an owner");
  h.toggle();
  assertSubmit(h, true, "Returning to simple mode ignores incomplete advanced routing and product");
  assert.equal(h.payloads[0].creationMode, "simple");
  assert.equal(h.payloads[0].involvementId, "");
});

test("hidden product and collaborator drafts never constrain or leak into direct and department submissions", () => {
  for (const mode of modes) for (const id of [product.id, "TF-old", "missing-product"]) {
    const h = ready(mode); h.stale({ involvementId: id, collaborators: ["周杰"] });
    assertSubmit(h, true, `${mode}: hidden values ignored`);
    assert.equal(h.payloads[0].involvement, "无"); assert.equal(h.payloads[0].involvementId, "");
    assert.deepEqual(plain(h.payloads[0].collaborators), []);
  }
});

test("simple callbacks submit without hidden product, collaborators or advanced conditions", () => {
  for (const other of [false, true]) {
    const h = ready("advanced");
    h.method("domain-type"); pickProduct(h); h.change("task-domain", "Testing"); h.change("task-problem-type", "DFT"); h.toggle();
    const owner = other ? "李娜" : actor.name;
    if (other) { h.act(h.button("为他人创建").props.onClick); h.act(h.leaf("PersonInput").props.onChange, "  李娜  "); }
    const collaborators = [owner, "周杰"];
    const attachments = [{ name: "产品资料.txt", kind: "file", url: "data:text/plain;base64,b2s=" }];
    const voiceNote = "data:audio/webm;base64,b2s=";
    h.stale({ collaborators });
    h.act(h.leaf("AttachmentInput").props.onChange, attachments);
    h.act(h.leaf("VoiceRecorder").props.onChange, voiceNote);
    h.act(h.button("紧急").props.onClick);
    assertNoWrites(h);
    assertSubmit(h, true, `simple product, other=${other}`);
    assert.deepEqual(plain(h.payloads[0]), {
      ...fields, owner, createdForOther: other, creationMode: "simple",
      involvement: "无", involvementId: "", productByAssignment: true, visibilityType: "all", visiblePeople: [],
      collaborators: [], urgency: "紧急", attachments, voiceNote,
    });
    for (const field of ["assignmentMethod", "handlingDepartment", "problemDomain", "problemType"]) assert.equal(Object.hasOwn(h.payloads[0], field), false, field);
    assert.deepEqual(collaborators, [owner, "周杰"], "Owner exclusion must not mutate the collaborator draft");
  }
});

test("advanced callbacks submit product only with the Domain/type route", () => {
  for (const method of ["department", "domain-type"]) {
    const h = ready("advanced");
    // Populate both routing drafts so accidental leakage of inactive fields fails.
    h.method("domain-type"); pickProduct(h); h.change("task-domain", "Testing"); h.change("task-problem-type", "DFT");
    if (method === "department") h.method("department");
    const owner = method === "department" ? "王主管" : "张伟";
    h.stale({ collaborators: [owner, actor.name] });
    assertNoWrites(h);
    assertSubmit(h, true, `advanced ${method}`);
    assert.deepEqual(plain(h.payloads[0]), {
      ...fields, owner, createdForOther: owner !== actor.name, creationMode: "advanced", assignmentMethod: method,
      ...(method === "department" ? { handlingDepartment: "FT" } : { problemDomain: "Testing", problemType: "DFT" }),
      involvement: method === "domain-type" ? "产品" : "无", involvementId: method === "domain-type" ? product.id : "", productByAssignment: true, visibilityType: "all", visiblePeople: [],
      collaborators: [], urgency: "一般", attachments: [],
    });
    assert.equal(h.payloads[0].voiceNote, undefined);
    for (const field of method === "department" ? ["problemDomain", "problemType"] : ["handlingDepartment"]) assert.equal(Object.hasOwn(h.payloads[0], field), false, field);
  }
});

test("basic and background sections own the requested controls in both modes with renamed condition selection", () => {
  const h = ready();
  for (const advanced of [false, true]) {
    if (advanced) h.toggle();
    const sections = elements(h.tree).filter(node => node.type === "section");
    assert.equal(sections.length, 2);
    const basic = renderToStaticMarkup(React.createElement(React.Fragment, null, sections[0].props.children));
    const background = renderToStaticMarkup(React.createElement(React.Fragment, null, sections[1].props.children));
    assert.match(basic, />基础<\/h2>/); assert.match(background, />背景<\/h2>/);
    for (const id of ["task-title", "task-due-date", "task-owner-settings"]) assert.ok(elements(sections[0]).some(node => node.props.id === id));
    assert.match(h.byId("task-description").props.className, /h-\[101px\]/); assert.match(h.byId("task-description").props.className, /min-h-\[80px\]/);
    assert.doesNotMatch(basic, /可见范围|全员可见|部分人可见|任务可见范围/);
    assert.equal(h.hasLeaf("SegmentedControl"), false); assert.equal(h.hasLeaf("MultiPersonInput"), false);
    for (const name of ["VoiceRecorder", "AttachmentInput"]) assert.ok(elements(sections[1]).some(node => node.type === h.leaf(name).type));
    assert.ok(elements(sections[1]).some(node => node.props.id === "task-description"));
    assert.match(basic, /aria-label="条件选人"/); assert.doesNotMatch(h.html, /高级查找|查找方式|>任务内容<|>任务分派</);
    const toggle = elements(sections[0]).find(node => node.props.role === "switch");
    assert.match(toggle.props.className, /h-6/); assert.match(toggle.props.className, /text-\[11px\]/);
    const track = elements(toggle).find(node => node.props["aria-hidden"] === "true");
    assert.match(track.props.className, /h-4 w-7/);
    assert.match(track.props.children.props.className, /h-3 w-3/);
    assert.ok(track.props.children.props.className.includes(advanced ? "translate-x-3" : "translate-x-0"));
    assert.doesNotMatch(background, /关联产品/); assert.doesNotMatch(basic, /task-description|附件上传|协作者/);
  }
});

test("edit form preloads original fields, retains association/routing and saves through update without creation or preset writes", () => {
  const initial = { id: "edit-form", ...fields, owner: "李娜", collaborators: [{ name: "周杰", department: "PTE" }], urgency: "紧急", creationMode: "advanced", assignmentMethod: "department", handlingDepartment: "旧部门", involvement: { kind: "TF", id: "legacy", name: "原关联" }, visibility: { type: "partial", people: ["王芳"] }, attachments: [{ name: "原文件", kind: "file", url: "data:text/plain,test" }], voiceNote: "data:audio/webm,test" };
  const before = JSON.stringify(initial); const h = harness(initial);
  assert.match(h.html, /编辑自由任务|保存修改|保留原关联/);
  assert.equal(h.byId("task-title").props.value, fields.title);
  assert.equal(h.byId("task-owner").props.value, "李娜 · 旧部门");
  assert.doesNotMatch(h.html, /可见范围|全员可见|部分人可见|任务可见范围/);
  assert.equal(h.hasLeaf("SegmentedControl"), false); assert.equal(h.hasLeaf("MultiPersonInput"), false);
  assert.equal(h.leaf("VoiceRecorder").props.value, initial.voiceNote);
  h.change("task-title", "编辑标题"); h.button("保存修改").props.onClick();
  assert.equal(h.edits.length, 1); assert.equal(h.edits[0].id, initial.id); assert.equal(h.edits[0].expected, initial);
  for (const key of ["owner", "handlingDepartment", "assignmentMethod", "voiceNote"]) assert.equal(h.edits[0].input[key], initial[key]);
  assert.equal(h.edits[0].input.involvement, "TF"); assert.equal(h.edits[0].input.involvementId, "legacy");
  assert.equal(h.edits[0].input.visibilityType, "partial"); assert.deepEqual(h.edits[0].input.visiblePeople, ["王芳"]);
  assert.deepEqual(h.payloads, []); assert.deepEqual(h.presets, []); assert.equal(h.created[0].id, initial.id);
  assert.equal(JSON.stringify(initial), before);
});

test("edit failure preserves the draft and permits retry; cancel never calls either save service", () => {
  const initial = { id: "retry", ...fields, owner: actor.name, collaborators: [], urgency: "一般", attachments: [] };
  const control = { fail: true }; const h = harness(initial, control);
  h.change("task-description", "修改草稿"); h.button("保存修改").props.onClick(); h.render();
  assert.match(h.html, /role="alert"/); assert.equal(h.byId("task-description").props.value, "修改草稿");
  assert.deepEqual(h.edits, []); assert.deepEqual(h.created, []);
  control.fail = false; h.button("保存修改").props.onClick(); assert.equal(h.edits.length, 1);
  const cancel = harness(initial); cancel.change("task-title", "不应保存"); cancel.button("取消").props.onClick();
  assert.equal(cancel.cancelled.length, 1); assertNoWrites(cancel); assert.deepEqual(cancel.edits, []);
});

test("creation choice retains its title and two guidance sentences without a question subtitle", async () => {
  const entry = await build({ entryPoints: [fileURLToPath(new URL("CreateEntryDialog.tsx", directory))], bundle: true, write: false, platform: "node", format: "cjs", jsx: "automatic", packages: "external" });
  const sandbox = { module: { exports: {} }, require };
  vm.runInNewContext(entry.outputFiles[0].text, sandbox);
  const Dialog = require("@radix-ui/react-dialog");
  for (const label of ["Case", "自由任务"]) {
    let tree; const calls = [];
    function Probe() { tree = sandbox.module.exports.CreateEntryDialog({ onCreateCase: () => calls.push("Case"), onCreateTask: () => calls.push("自由任务") }); return tree; }
    renderToStaticMarkup(React.createElement(Probe));
    const content = elements(tree).find(node => node.type === Dialog.Content);
    const html = renderToStaticMarkup(React.createElement(Dialog.Root, { open: true }, content.props.children));
    assert.doesNotMatch(html, /选择要创建的内容|新建 Case|新建自由任务|创建 Case|创建自由任务|aria-label="任务"|lucide-arrow/);
    const choices = elements(content).filter(node => node.type === "button" && ["Case", "自由任务"].includes(node.props["aria-label"]));
    assert.equal(choices.length, 2);
    assert.equal(text(elements(content).find(node => node.type === Dialog.Title)), "新建");
    assert.equal(elements(content).some(node => node.type === Dialog.Description), false);
    assert.equal(content.props["aria-describedby"], undefined);
    assert.doesNotMatch(html, /你这次要做的是|「分析原因」还是「完成事项」/);
    const guidance = {
      Case: ["不只看结果，还要和团队一起拆分方向、逐一验证，弄清为什么。", "沉淀根因和改善方案，并 Fanout 到其他产品。"],
      自由任务: ["要做什么、怎么做都比较明确", "可以独立处理日常维护、更新或具体待办。"],
    };
    for (const choice of choices) {
      const list = elements(choice).find(node => node.props["aria-label"] === `${choice.props["aria-label"]}适用情况`);
      assert.deepEqual(elements(list).filter(node => node.props.role === "listitem").map(text), guidance[choice.props["aria-label"]]);
    }
    for (const copy of ["排查某产品测试良率下降原因", "分析客户反馈的功能失效问题", "定位兼容性问题并验证改善方案", "快速简单的日常任务", "有清晰流程的固定任务", "会议后的待办 Todo"]) assert.ok(html.includes(copy), copy);
    assert.doesNotMatch(html, /围绕问题开展分析|记录和分派具体工作|准备评审会议资料|完成设备点检并记录结果/);
    choices.forEach(node => {
      const heading = React.Children.toArray(node.props.children)[0];
      assert.match(heading.props.className, /flex items-center/);
      assert.ok(elements(heading).some(child => child.props.className?.includes("text-2xl")));
    });
    const selected = choices.find(node => node.props["aria-label"] === label);
    selected.props.onClick(); selected.props.onClick();
    assert.deepEqual(calls, [label]);
  }
});