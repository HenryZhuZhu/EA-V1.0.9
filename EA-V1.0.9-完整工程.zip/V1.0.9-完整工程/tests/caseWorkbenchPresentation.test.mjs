import assert from "node:assert/strict";
import test from "node:test";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";
import vm from "node:vm";
import { build } from "esbuild";
import { createElement, Fragment, isValidElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";

const require = createRequire(import.meta.url);
const React = require("react");
const { outputFiles } = await build({
  stdin: {
    contents: `
      export { CaseStatusSummary } from "./CaseStatusSummary";
      export { WorkbenchCaseCard } from "./WorkbenchCaseCard";
      export { MyCaseWorkbench } from "./MyCaseWorkbench";
      export { WorkbenchSort } from "./WorkbenchSort";
      export { CaseWorkbenchFilters } from "./CaseWorkbenchFilters";
      export { CaseFilterPanel } from "./CaseFilterPanel";
      export { CaseCustomFilterEditor } from "./CaseCustomFilterEditor";
      export { CaseFilterFields, caseFilterOptions } from "./CaseFilterFields";
      export { TaskBusinessFilter } from "./TaskBusinessFilter";
      export { buildCaseWorkbenchRows, createCaseWorkbenchState, updateCaseWorkbenchState, DEFAULT_CASE_FILTERS } from "./caseWorkbenchModel";
    `,
    resolveDir: fileURLToPath(new URL("../src/app/components/", import.meta.url)),
    sourcefile: "case-workbench-presentation-test-entry.ts", loader: "ts",
  },
  bundle: true, write: false, platform: "node", format: "cjs", jsx: "automatic",
  packages: "external", external: ["./data", "./closures", "./subscriptions", "./caseTaskTrees"],
});
const plain = value => JSON.parse(JSON.stringify(value));
const statuses = ["进行中", "验证中", "已结案"];
const counts = Object.freeze({ 进行中: 12, 验证中: 8, 已结案: 3 });
const actor = { name: "张伟", department: "PTE" };
const products = [{ id: "p1", code: "DDR5", name: "产品一" }, { id: "p2", code: "LPDDR", name: "产品二" }];
const departments = { 张伟: "PTE", 刘洋: "PTE", 李娜: "DA", 王强: "FT" };
const c = (id, patch = {}) => ({
  id, code: `CASE-${id}`, name: `问题 ${id}`, owner: actor.name, createdBy: "李娜",
  status: "进行中", level: "L1", urgency: "一般", updatedAt: "2026-09-01T10:00:00Z",
  reason: "实际问题说明", background: "背景", participants: [], departments: [], tasks: [], ...patch,
});
const action = (id, patch = {}) => ({ id, code: `TASK-${id}`, title: `执行 ${id}`, owner: "李娜", status: "进行中", ...patch });
function flattenTasks(nodes, depth = 0, parentPath = []) {
  return nodes.flatMap(task => [{ task, depth, path: parentPath }, ...flattenTasks(task.children ?? [], depth + 1, [...parentPath, task.title])]);
}
// Isolated read-only store adapters return the supplied records, never prebuilt model rows/results.
// React, ReactDOM, Radix, lucide and other packages stay real external dependencies.
function harness({ closures = {}, subscribed = [], trees = {}, initialState } = {}) {
  const treeReads = [];
  let capturing = false; let state = initialState; let tree; let stateCalls = 0;
  const stateUpdates = [];
  const getClosure = id => closures[id];
  const isSubscribed = id => subscribed.includes(id);
  const loadTree = (id, fallback) => {
    treeReads.push({ id, fallback });
    return Object.hasOwn(trees, id) ? trees[id] : fallback;
  };
  const stubs = {
    // Only MyCaseWorkbench's single state slot is controlled for callback-driven
    // rerenders. Child hooks, JSX, SSR, Radix and every selector/reducer stay real.
    react: { ...React, useState(initial) {
      if (!capturing) return React.useState(initial);
      stateCalls++;
      if (state === undefined) state = typeof initial === "function" ? initial() : initial;
      return [state, next => {
        const previous = state;
        state = typeof next === "function" ? next(previous) : next;
        stateUpdates.push({ previous, next: state });
      }];
    } },
    "./data": {
      flattenTasks, currentUser: actor, mockProducts: products, ownerToDepartment: departments,
      levelColors: { L1: "level-l1" },
      caseProductOf: record => products.find(product => product.id === record.productId || product.id === record.product || product.code === record.product),
      caseMarkCode: record => record.markCode || null,
    },
    "./closures": { useClosures: () => ({ get: getClosure }) },
    "./subscriptions": { useSubscriptions: () => ({ isSubscribed }) },
    "./caseTaskTrees": { loadCaseTaskTree: loadTree, useCaseTaskRevision: () => 0 },
  };
  const sandbox = { module: { exports: {} }, require: name => Object.hasOwn(stubs, name) ? stubs[name] : require(name) };
  for (const name of ["localStorage", "sessionStorage"]) Object.defineProperty(sandbox, name, {
    get() { throw new Error(`${name} must not be accessed by presentation tests`); },
  });
  vm.runInNewContext(outputFiles[0].text, sandbox);
  const api = sandbox.module.exports;
  function renderWorkbench(props) {
    function Capture() {
      capturing = true; stateCalls = 0;
      try { tree = api.MyCaseWorkbench(props); }
      finally { capturing = false; }
      assert.equal(stateCalls, 1, "Update the bounded harness if MyCaseWorkbench adds state slots");
      return tree;
    }
    return renderToStaticMarkup(createElement(Capture));
  }
  return {
    ...api, treeReads, stateUpdates, renderWorkbench,
    get tree() { return tree; },
    get state() { return state; },
    rows: cases => api.buildCaseWorkbenchRows(cases, {
      products, closure: getClosure, isSubscribed, loadTree: record => loadTree(record.id, record.tasks),
    }),
  };
}
const render = (Component, props) => renderToStaticMarkup(createElement(Component, props));
const buttons = html => html.match(/<button\b[^>]*>[\s\S]*?<\/button>/g) ?? [];
const articles = html => html.match(/<article\b[^>]*>[\s\S]*?<\/article>/g) ?? [];
function elements(tree) {
  if (Array.isArray(tree)) return Array.from(tree).flatMap(elements);
  if (!isValidElement(tree)) return [];
  return [tree, ...elements(tree.props.children)];
}
function freeze(value) {
  if (value && typeof value === "object" && !Object.isFrozen(value)) {
    Object.values(value).forEach(freeze); Object.freeze(value);
  }
  return value;
}
function text(tree) {
  if (Array.isArray(tree)) return Array.from(tree).map(text).join("");
  if (isValidElement(tree)) return text(tree.props.children);
  return typeof tree === "string" || typeof tree === "number" ? String(tree) : "";
}
function one(tree, predicate, description) {
  const matches = elements(tree).filter(predicate);
  assert.equal(matches.length, 1, `Expected exactly one ${description}`);
  return matches[0];
}
const button = (tree, label) => {
  const control = one(tree, node => (node.type === "button" || ["mine", "participating", "created"].includes(node.props.value)) && text(node) === label, label);
  return control.type === "button" ? control : { ...control, props: { ...control.props, onClick: () => tree.props.onValueChange(control.props.value) } };
};
const byAria = (tree, label) => one(tree, node => node.props["aria-label"] === label, label);
function assertClasses(className, expected) {
  const tokens = className.split(/\s+/);
  for (const token of expected) assert.ok(tokens.includes(token), `Missing class ${token}: ${className}`);
}
const dimensionEntries = [["level", "层级", "L2"], ["urgency", "紧急程度", "紧急"], ["product", "产品", "DDR5"], ["department", "部门", "DA"], ["creator", "创建 / 分派人", "李娜"]];
function filterProps(api, overrides = {}) {
  return { cases: [], filters: { ...api.DEFAULT_CASE_FILTERS }, status: "进行中", open: false,
    onOpenChange() {}, onChange() {}, onStatusChange() {}, onReset() {}, ...overrides };
}
function popup(api, props) {
  const tree = api.CaseWorkbenchFilters(props);
  const outer = byAria(tree, "Case 筛选条件");
  const panel = one(outer, node => node.type === api.CaseFilterPanel, "shared CaseFilterPanel");
  const panelBody = api.CaseFilterPanel(panel.props);
  const content = React.cloneElement(outer, undefined, panelBody);
  const fields = one(content, node => node.type === api.CaseFilterFields, "shared CaseFilterFields");
  // Real Radix portals are absent in SSR. Render the actual children, not a mock
  // popup implementation; this does not claim browser portal/focus geometry.
  const html = renderToStaticMarkup(createElement(Fragment, null, content.props.children));
  return { tree, content, panel, panelBody, fields, html, controls: elements(api.CaseFilterFields(fields.props)).filter(node => node.type === "select") };
}
const workbenchFilter = api => one(api.tree, node => node.type === api.CaseWorkbenchFilters, "workbench filter");
function selectField(api, field, value) {
  const controls = popup(api, workbenchFilter(api).props).controls;
  const label = field === "status" ? "状态" : dimensionEntries.find(entry => entry[0] === field)[1];
  one(controls, node => node.type === "select" && node.props["aria-label"] === `Case ${label}`, `Case ${label}`).props.onChange({ target: { value } });
}
function assertNoNestedButtons(html) {
  let depth = 0;
  for (const tag of html.match(/<\/?button\b[^>]*>/g) ?? []) {
    if (tag.startsWith("</")) { assert.equal(depth, 1); depth--; }
    else { assert.equal(depth, 0, `Nested button: ${tag}`); depth++; }
  }
  assert.equal(depth, 0);
}

test("MyCase candidates and selection share the live persisted tree, including dispatcher replacement and empty-tree removal", () => {
  const cases = freeze([c("saved", { createdBy: undefined, tasks: [action("old", { supervisor: "旧分派人" })] }), c("created")]);
  const trees = { saved: freeze([{ id: "thought", supervisor: "思路人员", children: [action("actual", { supervisor: "王强" })] }]) };
  const before = JSON.stringify(cases); const api = harness({ trees }); const props = { cases, onOpenCase() {} };
  api.renderWorkbench(props);
  const candidates = () => plain(popup(api, workbenchFilter(api).props).fields.props.creators);
  assert.deepEqual(candidates(), ["全部", "王强", "李娜"]);
  assert.equal(api.treeReads.length, 2);
  selectField(api, "creator", "王强"); let html = api.renderWorkbench(props);
  assert.equal(api.treeReads.length, 4); assert.equal(articles(html).length, 1); assert.match(html, /aria-label="问题 saved"/);
  assert.match(html, /aria-label="筛选 1"/); assert.match(html, /aria-label="进行中 1 个 Case"/);
  trees.saved = freeze([action("actual", { supervisor: "刘洋" })]);
  html = api.renderWorkbench(props);
  assert.deepEqual(candidates(), ["全部", "刘洋", "李娜"]); assert.equal(articles(html).length, 0);
  assert.match(popup(api, workbenchFilter(api).props).html, /王强（当前无可选项）/);
  selectField(api, "creator", "刘洋"); html = api.renderWorkbench(props); assert.equal(articles(html).length, 1);
  trees.saved = freeze([]); html = api.renderWorkbench(props);
  assert.deepEqual(candidates(), ["全部", "李娜"]); assert.equal(articles(html).length, 0);
  button(popup(api, workbenchFilter(api).props).content, "重置全部").props.onClick(); html = api.renderWorkbench(props);
  assert.equal(articles(html).length, 2); assert.equal(api.state.views.进行中.filters.creator, "全部");
  assert.match(html, /aria-label="筛选"/); assert.equal(api.treeReads.length, 12);
  assert.equal(JSON.stringify(cases), before);
});

test("Case summary SSR renders four vertical 2:2:1:1 cards with 32px counts and retained spacing", () => {
  const { CaseStatusSummary } = harness();
  for (const status of statuses) {
    const html = render(CaseStatusSummary, { counts, status, onChange() {} });
    assert.equal(buttons(html).length, 4);
    assert.ok(html.includes("grid-cols-[minmax(0,2fr)_minmax(0,2fr)_minmax(0,1fr)_minmax(0,1fr)]"));
    for (const token of ["text-[32px]", "font-bold", "leading-none", "tabular-nums", "px-[18px]", "pt-[15px]", "pb-[14px]", "rounded-xl"]) {
      assert.equal(buttons(html).filter(button => button.includes(token)).length, 4, token);
    }
    assert.equal((html.match(/h-\[3px\]/g) ?? []).length, 4);
    assert.equal((html.match(/h-\[5px\] w-\[5px\]/g) ?? []).length, 4);
    assert.doesNotMatch(html, /text-\[30px\]|min-h-\[92px\]|<svg/);
    assertNoNestedButtons(html);
  }
});

test("summary captions describe analysis verification and results, with owner-only totals and no Pending or temporary fourth title", () => {
  const { CaseStatusSummary } = harness();
  const captions = ["分析与推进", "验证与闭环", "成果与记录"];
  const accents = { 进行中: "#0052D9", 验证中: "#0891b2", 已结案: "#64748b" };
  for (const status of statuses) {
    const html = render(CaseStatusSummary, { counts, status, onChange() {} });
    const cards = buttons(html);
    assert.equal((html.match(/aria-pressed="true"/g) ?? []).length, 1);
    assert.equal((html.match(/aria-pressed="false"/g) ?? []).length, 3);
    assert.equal((html.match(/scaleX\(1\)/g) ?? []).length, 1);
    assert.equal((html.match(/scaleX\(0\)/g) ?? []).length, 3);
    assert.ok(html.includes(`box-shadow:0 8px 20px -14px ${accents[status]}`));
    statuses.forEach((value, i) => {
      assert.ok(cards[i].includes(`aria-label="${value} ${counts[value]} 个 Case"`));
      assert.ok(cards[i].includes(`title="${value} · 当前人员视角与筛选条件下共 ${counts[value]} 个 Case"`));
      assert.ok(cards[i].includes(captions[i]));
      assert.match(cards[i], /aria-controls="case-status-content"/);
    });
    assert.doesNotMatch(html, /Pending|暂存|待接受|已完成/);
    assert.doesNotMatch(html.replace(/<[^>]*>/g, ""), /我负责/);
  }
});

test("summary click handlers select only primary states, including repeat clicks, without modifying counts", () => {
  const { CaseStatusSummary } = harness();
  for (const status of statuses) {
    const changes = [];
    const tree = CaseStatusSummary({ counts, status, onChange: value => changes.push(value) });
    const controls = elements(tree).filter(element => element.type === "button").slice(0, 3);
    controls.forEach(button => button.props.onClick());
    controls.find(button => button.props["aria-pressed"]).props.onClick();
    assert.deepEqual(changes, [...statuses, status]);
    assert.ok(changes.every(value => value !== null && value !== "Pending"));
  }
  assert.deepEqual(counts, { 进行中: 12, 验证中: 8, 已结案: 3 });
});

test("Case title and raw normal-source provenance use independent non-nested buttons and navigate to different IDs", () => {
  const api = harness();
  const cases = [c("source", { owner: "王强", status: "已归档", fanoutTargets: ["p2"] }), c("child", { fanoutSourceCaseId: "source", productId: "p1" })];
  const list = api.rows(cases); const row = list[1]; const opened = [];
  assert.equal(list[0].fanout, false);
  assert.equal(row.sourceCase, cases[0]);
  const props = { row, onOpenCase: id => opened.push(id) };
  const html = render(api.WorkbenchCaseCard, props);
  assertNoNestedButtons(html);
  assert.equal(buttons(html).length, 2);
  assert.match(html, /aria-label="查看 Case 问题 child"/);
  assert.match(html, /aria-label="查看 Fanout 来源 Case 问题 source"/);
  assert.match(html, /title="CASE-source · 问题 source"/);
  assert.match(html, /title="问题 child"/);
  assert.match(html, /来源 Case/);
  const treeButtons = elements(api.WorkbenchCaseCard(props)).filter(element => element.type === "button");
  treeButtons.find(button => button.props["aria-label"] === "查看 Case 问题 child").props.onClick();
  assert.deepEqual(opened, ["child"]);
  treeButtons.find(button => button.props["aria-label"] === "查看 Fanout 来源 Case 问题 source").props.onClick();
  assert.deepEqual(opened, ["child", "source"]);
});

test("missing absent and self-referencing Fanout sources render honest fallback text without an invented navigation button", () => {
  const api = harness();
  const list = api.rows([c("missing", { fanoutSourceCaseId: "not-loaded" }), c("absent", { source: "fanout验证" }), c("self", { fanoutSourceCaseId: "self" })]);
  for (const row of list) {
    const opened = [];
    const props = { row, onOpenCase: id => opened.push(id) };
    const html = render(api.WorkbenchCaseCard, props);
    assert.equal(row.sourceCase, undefined);
    assert.equal(buttons(html).length, 1);
    assert.match(html, row.id === "absent" ? /未记录来源 Case/ : /来源 Case 暂不可用/);
    assert.doesNotMatch(html, /aria-label="查看 Fanout 来源 Case|undefined|null/);
    assertNoNestedButtons(html);
    elements(api.WorkbenchCaseCard(props)).find(element => element.type === "button").props.onClick();
    assert.deepEqual(opened, [row.id]);
  }
});

test("outgoing Fanout targets and ordinary parent links do not display an incoming Fanout badge or source footer", () => {
  const api = harness();
  const list = api.rows([c("parent", { fanoutTargets: ["p2"] }), c("ordinary-child", { parentCaseId: "parent" }), c("marked", { source: "fanout验证" })]);
  for (const row of list.slice(0, 2)) {
    const html = render(api.WorkbenchCaseCard, { row, onOpenCase() {} });
    assert.equal(buttons(html).length, 1);
    assert.doesNotMatch(html, /Fanout|来源 Case/);
  }
  const marked = render(api.WorkbenchCaseCard, { row: list[2], onOpenCase() {} });
  assert.match(marked, /Fanout<\/span>/);
  assert.match(marked, /未记录来源 Case/);
});

test("closed card dates distinguish actual closure from updated fallback and missing time instead of fabricating closure", () => {
  const closedAt = "2026-09-03T10:20:00Z";
  const api = harness({ closures: {
    actual: { caseId: "actual", state: "closed", closedAt },
    invalid: { caseId: "invalid", state: "closed", closedAt: "bad-date" },
  } });
  const list = api.rows([c("actual", { updatedAt: "2026-09-09T12:00:00Z" }), c("fallback", { status: "已归档", updatedAt: "2026-09-07T11:00:00Z" }),
    c("missing", { status: "已关闭", updatedAt: undefined }), c("invalid", { updatedAt: "2026-09-06T10:00:00Z" })]);
  const markup = list.map(row => render(api.WorkbenchCaseCard, { row, onOpenCase() {} }));
  assert.match(markup[0], /结案 2026-09-03/);
  assert.ok(markup[0].includes(`title="${closedAt}"`));
  assert.doesNotMatch(markup[0], /更新 2026-09-09|结案 2026-09-09/);
  assert.match(markup[1], /更新 2026-09-07/);
  assert.doesNotMatch(markup[1], /结案 2026-09-07/);
  assert.match(markup[2], /未记录结案时间/);
  assert.doesNotMatch(markup[2], /(?:更新|结案) \d{4}-/);
  assert.match(markup[3], /更新 2026-09-06/);
  assert.doesNotMatch(markup[3], /bad-date|结案 2026-09-06/);
});

test("cards render only normalized Case status even when raw records are legacy Pending or conflict with closure state", () => {
  const api = harness({ closures: {
    root: { caseId: "root", state: "rootcause" }, closed: { caseId: "closed", state: "closed" },
    precedence: { caseId: "precedence", state: "rootcause" },
  } });
  const cases = [c("legacy", { status: "Pending" }), c("root", { status: "Pending" }), c("closed", { status: "Pending" }),
    c("precedence", { status: "已归档" }), c("raw-verify", { status: "验证中" })];
  const before = JSON.stringify(cases);
  const list = api.rows(cases);
  const expected = ["进行中", "验证中", "已结案", "已结案", "验证中"];
  list.forEach((row, i) => {
    const html = render(api.WorkbenchCaseCard, { row, onOpenCase() {} });
    assert.equal(row.status, expected[i]);
    assert.ok(html.includes(`${expected[i]}</span>`));
    assert.doesNotMatch(html, /Pending|暂存|已归档|已关闭/);
    for (const other of statuses.filter(status => status !== expected[i])) assert.ok(!html.includes(`${other}</span>`));
  });
  assert.equal(JSON.stringify(cases), before);
});

test("legacy normalization preserves a legitimate title containing 暂存 rather than rewriting user content", () => {
  const api = harness();
  const record = c("title", { name: "暂存样品复验", status: "Pending" });
  const [row] = api.rows([record]);
  const html = render(api.WorkbenchCaseCard, { row, onOpenCase() {} });
  assert.match(html, /aria-label="查看 Case 暂存样品复验"/);
  assert.match(html, /title="暂存样品复验"/);
  assert.match(html, /进行中<\/span>/);
  assert.doesNotMatch(html, /Pending|暂存<\/span>/);
  assert.equal(record.name, "暂存样品复验");
  assert.equal(record.status, "Pending");
});

test("invalid and absent calendar deadlines display unset rather than a stale dueIn countdown", () => {
  const api = harness();
  const list = api.rows([c("invalid", { dueDate: "2026-02-31", dueIn: 2 }), c("missing", { dueIn: -4 })]);
  for (const row of list) {
    const html = render(api.WorkbenchCaseCard, { row, onOpenCase() {} });
    assert.match(html, /未设置截止日期/);
    assert.doesNotMatch(html, /2 天到期|已逾期 4 天/);
  }
});

test("MyCaseWorkbench SSR wires real model rows, one persisted-tree read per Case, four summaries and global eight-card pagination without source tabs", () => {
  const cases = Array.from({ length: 9 }, (_, i) => c(`own-${String(i).padStart(2, "0")}`, { status: i === 8 ? "Pending" : "进行中", tasks: [action(`stale-${i}`)] }));
  cases.push(c("root"), c("closed", { status: "Pending" }), c("other", { owner: "李娜" }));
  const trees = { "own-00": [{ id: "thought", title: "方向", children: [action("actual-a"), action("actual-b", { children: [action("actual-c")] })] }] };
  const closures = { root: { caseId: "root", state: "rootcause" }, closed: { caseId: "closed", state: "closed", closedAt: "2026-09-09T10:00:00Z" } };
  const before = JSON.stringify([cases, trees, closures]);
  const api = harness({ trees, closures });
  const html = render(api.MyCaseWorkbench, { cases, onOpenCase() {} });
  assert.equal(articles(html).length, 8);
  assert.match(html, /aria-label="进行中 9 个 Case"/);
  assert.match(html, /aria-label="验证中 1 个 Case"/);
  assert.match(html, /aria-label="已结案 1 个 Case"/);
  assert.match(html, /id="case-status-content"/);
  assert.match(html, /aria-label="进行中 Case 内容"/);
  assert.equal((html.match(/role="tab"/g) ?? []).length, 3);
  assert.doesNotMatch(html, /全部 Case|更多视角/); assert.match(html, /aria-label="Fanout 0 个 Case"/);
  assert.match(html, /第 1–8 个 · 9 个 Case/);
  const previous = buttons(html).find(button => button.includes('aria-label="上一页 Case"'));
  const next = buttons(html).find(button => button.includes('aria-label="下一页 Case"'));
  assert.ok(previous); assert.ok(next);
  assert.match(previous, /disabled=""/); assert.doesNotMatch(next, /disabled=""/);
  const first = articles(html).find(article => article.includes('aria-label="问题 own-00"'));
  assert.ok(first); assert.match(first, /3 任务/);
  assert.doesNotMatch(html, /aria-label="问题 own-08"|aria-label="问题 other"|Pending|暂存/);
  assert.doesNotMatch(html, /id="case-filter-settings"|清除筛选/);
  assert.equal(api.treeReads.length, cases.length);
  api.treeReads.forEach((read, i) => { assert.equal(read.id, cases[i].id); assert.equal(read.fallback, cases[i].tasks); });
  assert.equal(JSON.stringify([cases, trees, closures]), before);
  assertNoNestedButtons(html);
});

test("MyCaseWorkbench initial relationship views use explicit metadata and keep the owner summary fixed", () => {
  const cases = [c("self"), c("joined", { owner: "李娜", participants: [{ name: actor.name }] }),
    c("created", { owner: "王强", createdBy: actor.name }), c("department", { owner: "刘洋" }),
    c("subscribed", { owner: "王强" }), c("task-only", { owner: "李娜", tasks: [action("t", { owner: actor.name, collaborators: [{ name: actor.name }] })] }),
    c("verify", { status: "验证中" }), c("closed", { status: "已归档" })];
  const expected = { mine: ["self"], participating: ["joined"], created: ["created"], department: ["self"], subscribed: ["self"] };
  const before = JSON.stringify(cases);
  for (const [initialScope, ids] of Object.entries(expected)) {
    const api = harness({ subscribed: ["subscribed"] });
    const html = render(api.MyCaseWorkbench, { cases, initialScope, onOpenCase() {} });
    const renderedIds = articles(html).map(article => /aria-label="问题 ([^"]+)"/.exec(article)?.[1]);
    assert.deepEqual(renderedIds.sort(), [...ids].sort(), initialScope);
    const expectedCounts = initialScope === "participating" || initialScope === "created" ? { 进行中: 1, 验证中: 0, 已结案: 0 } : { 进行中: 1, 验证中: 1, 已结案: 1 };
    for (const status of statuses) assert.ok(html.includes(`aria-label="${status} ${expectedCounts[status]} 个 Case"`));
    assert.doesNotMatch(html, /aria-label="问题 task-only"/);
    if (["department", "subscribed"].includes(initialScope)) {
      assert.ok(buttons(html).some(button => button.includes('aria-selected="true"') && button.includes("我负责")));
      assert.doesNotMatch(html, /更多视角|我部门|我订阅/);
    }
  }
  assert.equal(JSON.stringify(cases), before);
});

test("legacy TaskBusinessFilter kinds opt-in remains compatible, not a MyCaseWorkbench UI contract", () => {
  const { TaskBusinessFilter } = harness();
  const options = [
    { key: "产品:p1", kind: "产品", name: "DDR5 · 产品一", origin: "case" },
    { key: "Project:name:项目", kind: "Project", name: "项目", nameOnly: true, origin: "case" },
    { key: "TF:tf1", kind: "TF", name: "专项", origin: "task" },
  ];
  const props = { options, filters: { businessKind: "all", businessKey: "" }, className: "h-8", onChange() {} };
  const before = JSON.stringify(props);
  const caseHtml = render(TaskBusinessFilter, { ...props, kinds: ["产品", "Project"] });
  const taskHtml = render(TaskBusinessFilter, props);
  const optionValues = html => [...html.matchAll(/<option value="([^"]*)"/g)].map(match => match[1]);
  assert.deepEqual(optionValues(caseHtml), ["all", "none", "产品", "Project"]);
  assert.deepEqual(optionValues(taskHtml), ["all", "none", "产品", "Project", "TF"]);
  assert.doesNotMatch(caseHtml, /<option value="TF"/);
  assert.match(taskHtml, /<option value="TF"/);
  assert.match(caseHtml, /data-slot="task-business-filter"/);
  assert.match(caseHtml, /<span class="truncate">—<\/span>/);
  const stale = render(TaskBusinessFilter, { ...props, kinds: ["产品", "Project"], options: [], filters: { businessKind: "Project", businessKey: "Project:name:旧项目" } });
  assert.match(stale, /value="Project" selected=""/);
  assert.match(stale, /已选对象/);
  const named = render(TaskBusinessFilter, { ...props, kinds: ["产品", "Project"], filters: { businessKind: "Project", businessKey: "Project:name:项目" } });
  assert.match(named, /项目（名称记录）/);
  assert.equal(JSON.stringify(props), before);
  assert.deepEqual(plain(options).map(option => option.key), ["产品:p1", "Project:name:项目", "TF:tf1"]);
});

test("Case filter trigger SSR counts five auxiliary conditions for all 32 masks/status/open states with a compact 32px bordered button", () => {
  const api = harness();
  for (const status of statuses) for (const open of [false, true]) for (let mask = 0; mask < 32; mask++) {
    const filters = freeze({ ...api.DEFAULT_CASE_FILTERS,
      ...Object.fromEntries(dimensionEntries.map(([key, , value], i) => [key, mask & (1 << i) ? value : "全部"])),
      status, source: "fanout", scope: "created", businessKind: "Project", businessKey: "Project:legacy",
    });
    const before = JSON.stringify(filters);
    const count = dimensionEntries.filter((_, i) => mask & (1 << i)).length;
    const props = filterProps(api, { filters, status, open });
    const html = render(api.CaseWorkbenchFilters, props);
    const trigger = buttons(html).find(value => value.includes(`aria-label="筛选${count ? ` ${count}` : ""}"`));
    assert.ok(trigger, `${status}/${open}/${mask}`);
    assertClasses(/class="([^"]*)"/.exec(trigger)[1], ["h-8", "px-2.5", "rounded-lg", "border", "text-xs", "inline-flex", "shrink-0", "items-center", "gap-1",
      ...(open || count ? ["border-[#0052D9]/40", "bg-[#0052D9]/5", "text-[#0052D9]"] : ["border-slate-200", "bg-white", "text-slate-600"])]);
    assert.equal((trigger.match(/min-w-\[16px\]/g) ?? []).length, Number(count > 0));
    if (count) assert.ok(trigger.includes(`>${count}</span>`));
    assert.equal(trigger.includes("rotate-180"), open);
    assert.doesNotMatch(html, /aria-label="筛选 [6-9]|清除.*筛选|task-business-filter|旧创建人|Project:legacy/);
    const tree = api.CaseWorkbenchFilters(props);
    assert.equal(tree.props.open, open);
    assert.equal(tree.props.onOpenChange, props.onOpenChange);
    assert.equal(JSON.stringify(filters), before);
  }
});

test("controlled Case popup renders six shared fields inside the 480px content with only three primary statuses", () => {
  const api = harness();
  const cases = freeze([c("one", { product: "DDR5", departments: ["DA", "PTE"] }), c("two", { product: "LPDDR", departments: ["DA"] })]);
  for (const status of statuses) {
    const props = filterProps(api, { cases, status, open: true });
    const { tree, content, fields, controls, html } = popup(api, props);
    assert.equal(tree.props.open, true);
    assert.equal(content.props.align, "end"); assert.equal(content.props.sideOffset, 8);
    assertClasses(content.props.className, ["w-[480px]", "max-w-[88vw]", "bg-white", "border", "border-slate-200", "rounded-xl", "p-0", "overflow-hidden", "max-h-[min(80vh,var(--radix-popover-content-available-height))]", "shadow-[0_16px_40px_-12px_rgba(15,23,42,0.25)]"]);
    assert.deepEqual(plain(fields.props.values), { level: "全部", urgency: "全部", product: "全部", department: "全部", creator: "全部", status });
    assert.deepEqual(plain(fields.props.products), ["全部", "DDR5", "LPDDR"]);
    assert.deepEqual(plain(fields.props.departments), ["全部", "DA", "PTE"]);
    assert.deepEqual(plain(fields.props.creators), ["全部", "李娜"]);
    assert.deepEqual(plain(fields.props.statusOptions), statuses);
    assert.deepEqual(controls.map(node => node.props["aria-label"]), ["Case 层级", "Case 紧急程度", "Case 状态", "Case 产品", "Case 部门", "Case 创建 / 分派人"]);
    assert.equal((html.match(/<select\b/g) ?? []).length, 6);
    assert.equal((html.match(/<label\b/g) ?? []).length, 6);
    const statusSelect = byAria(controls, "Case 状态");
    assert.deepEqual(elements(statusSelect).filter(node => node.type === "option").map(node => [node.props.value, text(node)]), statuses.map(value => [value, value]));
    const statusHtml = /<select\b[^>]*aria-label="Case 状态"[^>]*>[\s\S]*?<\/select>/.exec(html)[0];
    const selectedOptions = statusHtml.match(/<option\b(?=[^>]*\bselected="")[^>]*>/g) ?? [];
    assert.equal(selectedOptions.length, 1);
    assert.ok(selectedOptions[0].includes(`value="${status}"`));
    assert.doesNotMatch(statusHtml, /全部|暂存|Pending/);
    assert.match(html, /筛选维度/); assert.match(html, /重置全部/); assert.match(html, />完成<\/button>/);
    assert.doesNotMatch(html, /任务涉及|task-business-filter|Project|\bTF\b|归类显示|排序方式|清除 Case 状态筛选/);
    assertNoNestedButtons(html);
  }
});

test("real field callbacks dispatch one auxiliary patch or a guarded primary status without closing or mutating controlled props", () => {
  const api = harness(); const calls = [];
  const filters = freeze({ ...api.DEFAULT_CASE_FILTERS });
  const cases = freeze([c("raw", { status: "Pending", product: "DDR5", departments: ["DA"] })]);
  const props = filterProps(api, { cases, filters, open: true,
    onChange: patch => calls.push(["filters", plain(patch)]), onStatusChange: value => calls.push(["status", value]),
    onOpenChange: value => calls.push(["open", value]), onReset: () => calls.push(["reset"]),
  });
  const before = JSON.stringify([cases, filters]);
  const { controls, fields } = popup(api, props);
  assert.deepEqual(calls, []);
  for (const [key, label, value] of dimensionEntries) {
    const select = byAria(controls, `Case ${label}`);
    select.props.onChange({ target: { value } });
    select.props.onChange({ target: { value: "全部" } });
    assert.deepEqual(calls.slice(-2), [["filters", { [key]: value }], ["filters", { [key]: "全部" }]]);
  }
  const statusSelect = byAria(controls, "Case 状态");
  for (const status of statuses) statusSelect.props.onChange({ target: { value: status } });
  assert.deepEqual(calls.slice(-3), statuses.map(status => ["status", status]));
  const validCalls = [...calls];
  for (const value of ["全部", "暂存", "Pending", "待处理", "已完成", "", "unknown"]) {
    statusSelect.props.onChange({ target: { value } });
    fields.props.onChange("status", value);
    assert.deepEqual(calls, validCalls, `Invalid status ${value} must not dispatch`);
  }
  assert.equal(calls.length, 13);
  assert.equal(props.open, true); assert.equal(props.status, "进行中");
  assert.ok(calls.every(([kind]) => kind !== "open" && kind !== "reset"));
  assert.deepEqual(plain(popup(api, props).fields.props.values), { level: "全部", urgency: "全部", product: "全部", department: "全部", creator: "全部", status: "进行中" });
  assert.equal(JSON.stringify([cases, filters]), before);
});

test("popup reset and done call only their supplied controlled callbacks, including empty and missing selections", () => {
  const api = harness();
  for (const patch of [{}, { level: "L9", urgency: "旧紧急值", product: "已移除产品", department: "已移除部门" }]) {
    const filters = freeze({ ...api.DEFAULT_CASE_FILTERS, ...patch }); const calls = [];
    const props = filterProps(api, { filters, status: "已结案", open: true,
      onReset: () => calls.push(["reset"]), onOpenChange: value => calls.push(["open", value]),
      onChange: value => calls.push(["filters", plain(value)]), onStatusChange: value => calls.push(["status", value]),
    });
    const before = JSON.stringify(filters);
    const { content, tree, html } = popup(api, props);
    if (Object.keys(patch).length) assert.equal((html.match(/（当前无可选项）/g) ?? []).length, 4);
    const reset = button(content, "重置全部"); const done = button(content, "完成");
    assert.equal(reset.props.onClick, props.onReset);
    reset.props.onClick(); assert.deepEqual(calls, [["reset"]]);
    done.props.onClick(); assert.deepEqual(calls, [["reset"], ["open", false]]);
    tree.props.onOpenChange(true);
    assert.deepEqual(calls, [["reset"], ["open", false], ["open", true]]);
    assert.equal(tree.props.open, true, "Controlled open prop is not internally rewritten");
    assert.equal(JSON.stringify(filters), before);
  }
});

test("MyCase passes the full current Case collection to shared options across status/source/role filters even when results are empty", () => {
  const setup = harness();
  const cases = freeze([c("active", { product: "DDR5", departments: ["DA"] }),
    c("verified", { status: "验证中", product: "LPDDR", departments: ["FT"] }),
    c("closed", { status: "已结案", product: "历史产品", departments: ["研发"] }),
    c("other-owner", { owner: "王强", product: "外部产品", departments: ["QA"], source: "fanout验证" }),
    c("ids-only", { productId: "p1", productIds: ["p2"], projectName: "旧项目", departments: undefined })]);
  const before = JSON.stringify(cases);
  for (const status of statuses) for (const scope of ["mine", "participating", "created", "department", "subscribed"]) for (const source of ["all", "fanout"]) {
    let initialState = setup.createCaseWorkbenchState(scope);
    for (const action of [{ type: "status", status }, { type: "source", source }, { type: "filters", patch: { product: "不存在产品" } }, { type: "expanded" }, { type: "page", page: 99 }]) initialState = setup.updateCaseWorkbenchState(initialState, action);
    freeze(initialState);
    const api = harness({ initialState });
    const html = api.renderWorkbench({ cases, onOpenCase() {} });
    const filter = workbenchFilter(api);
    assert.notEqual(filter.props.cases, cases, "Pass current snapshots rather than stale originals");
    assert.deepEqual(plain(filter.props.cases), plain(cases), "Keep every Case, not only results/candidates");
    assert.equal(filter.props.status, status); assert.equal(filter.props.open, true);
    const { fields, html: content } = popup(api, filter.props);
    assert.deepEqual(plain(fields.props.products), ["全部", "DDR5", "LPDDR", "历史产品", "外部产品"]);
    assert.deepEqual(plain(fields.props.departments), ["全部", "DA", "FT", "研发", "QA"]);
    assert.match(content, /value="不存在产品" selected=""/);
    assert.doesNotMatch(content, /产品:p1|产品:p2|旧项目|产品一|产品二/);
    assert.equal(articles(html).length, 0);
    for (const primary of statuses) assert.match(html, new RegExp(`aria-label="${primary} 0 个 Case"`));
    assert.match(html, /aria-label="筛选 1"/);
  }
  assert.equal(JSON.stringify(cases), before);
});

test("MyCase SSR applies five raw-field conditions with removable chips while keeping owner summaries fixed", () => {
  const setup = harness();
  const selected = { level: "L2", urgency: "紧急", product: "DDR5", department: "PTE", creator: "李娜" };
  const cases = freeze(statuses.flatMap(status => [
    c(`match-${status}`, { status, level: "L2", urgency: "紧急", product: "DDR5", departments: ["PTE", "DA"] }),
    ...[{ level: "L1" }, { urgency: "一般" }, { product: "LPDDR" }, { departments: ["FT"] },
      { product: undefined, productId: "p1" }, { departments: [] }, { product: "ddr5" }].map((patch, i) =>
      c(`miss-${i}-${status}`, { status, level: "L2", urgency: "紧急", product: "DDR5", departments: ["PTE"], ...patch })),
  ]));
  const before = JSON.stringify(cases);
  for (const status of statuses) {
    const initialState = setup.updateCaseWorkbenchState(setup.createCaseWorkbenchState(), { type: "status", status });
    // Obsolete business fields remain ignored; saved creator now actively restricts.
    initialState.views[status].filters = { ...initialState.views[status].filters, creator: "不匹配创建人", businessKind: "none", businessKey: "Project:legacy" };
    freeze(initialState);
    const api = harness({ initialState }); const props = { cases, onOpenCase() {} };
    let html = api.renderWorkbench(props);
    assert.equal(articles(html).length, 0, "Saved creator must actively filter, not silently broaden");
    workbenchFilter(api).props.onOpenChange(true); api.renderWorkbench(props);
    for (const [field, value] of Object.entries(selected)) {
      const previous = api.state;
      selectField(api, field, value);
      html = api.renderWorkbench(props);
      assert.equal(api.state.views[status].filters[field], value);
      assert.equal(api.state.views[status].page, 1);
      assert.equal(workbenchFilter(api).props.open, true);
      for (const other of statuses.filter(primary => primary !== status)) assert.equal(api.state.views[other], previous.views[other]);
    }
    assert.equal(articles(html).length, 1); assert.ok(html.includes(`aria-label="问题 match-${status}"`));
    for (const primary of statuses) assert.ok(html.includes(`aria-label="${primary} 1 个 Case"`));
    assert.match(html, /aria-label="筛选 5"/);
    assert.equal((html.match(/aria-label="清除 Case [^"]+筛选"/g) ?? []).length, 5);
    for (const [, label] of dimensionEntries) assert.ok(html.includes(`aria-label="清除 Case ${label}筛选"`));
    assert.doesNotMatch(html, /清除 Case 状态筛选|task-business-filter|不匹配创建人|Project:legacy|清除创建人筛选/);
    byAria(api.tree, "清除 Case 产品筛选").props.onClick();
    html = api.renderWorkbench(props);
    assert.deepEqual(plain(workbenchFilter(api).props.filters), { ...plain(setup.DEFAULT_CASE_FILTERS), ...selected, product: "全部" });
    assert.equal(articles(html).length, 4, "Clearing product restores raw variants without relaxing the other four fields");
    assert.match(html, /aria-label="筛选 4"/); assert.doesNotMatch(html, /清除 Case 产品筛选/);
    for (const primary of statuses) assert.ok(html.includes(`aria-label="${primary} 4 个 Case"`));
  }
  assert.equal(JSON.stringify(cases), before);
});

test("people tabs and primary status cards share filters, keep aligned counts, and omit status from the popup", () => {
  const cases = freeze(statuses.flatMap((status, index) => [
    c(`mine-${index}`, { status, product: "keep" }),
    c(`join-${index}`, { status, owner: "李娜", participants: [{ name: actor.name }], product: "keep" }),
    c(`created-${index}`, { status, owner: "王强", createdBy: actor.name, product: "keep" }),
    c(`created-miss-${index}`, { status, owner: "王强", createdBy: actor.name, product: "miss" }),
  ]));
  const api = harness(); const props = { cases, onOpenCase() {} }; let html = api.renderWorkbench(props);
  button(api.tree, "我分派").props.onClick(); html = api.renderWorkbench(props);
  workbenchFilter(api).props.onChange({ product: "keep" }); api.renderWorkbench(props);
  workbenchFilter(api).props.onOpenChange(true); html = api.renderWorkbench(props);
  assert.deepEqual(popup(api, workbenchFilter(api).props).controls.map(node => node.props["aria-label"]), ["Case 层级", "Case 紧急程度", "Case 产品", "Case 部门", "Case 创建 / 分派人"]);
  assert.doesNotMatch(popup(api, workbenchFilter(api).props).html, /aria-label="Case 状态"/);
  for (const status of statuses) assert.match(html, new RegExp(`aria-label="${status} 1 个 Case"`));
  const summary = () => one(api.tree, node => node.type === api.CaseStatusSummary, "summary");
  for (const status of ["验证中", "已结案", "进行中"]) {
    summary().props.onChange(status); html = api.renderWorkbench(props);
    assert.equal(api.state.views[status].scope, "created"); assert.equal(api.state.views[status].filters.product, "keep");
    assert.equal(articles(html).length, 1); assert.match(html, new RegExp(`aria-label="问题 created-${statuses.indexOf(status)}"`));
    assert.match(html, new RegExp(`aria-label="${status} 1 个 Case"`));
    assert.match(html, /第 1–1 个 · 1 个 Case/);
  }
});

test("actual popup reset clears current five conditions and page while preserving status/source/role/open and other snapshots", () => {
  const setup = harness();
  for (const [i, status] of statuses.entries()) {
    let initialState = setup.createCaseWorkbenchState();
    for (const primary of statuses) {
      initialState = setup.updateCaseWorkbenchState(initialState, { type: "status", status: primary });
      initialState = setup.updateCaseWorkbenchState(initialState, { type: "filters", patch: { product: `保存-${primary}` } });
    }
    for (const action of [{ type: "status", status }, { type: "source", source: i === 1 ? "all" : "fanout" },
      { type: "scope", scope: ["created", "department", "subscribed"][i] },
      { type: "filters", patch: Object.fromEntries(dimensionEntries.map(([key, , value]) => [key, value])) },
      { type: "expanded" }, { type: "page", page: 9 }]) initialState = setup.updateCaseWorkbenchState(initialState, action);
    freeze(initialState); const before = JSON.stringify(initialState);
    const api = harness({ initialState }); const props = { cases: [], onOpenCase() {} };
    api.renderWorkbench(props);
    button(popup(api, workbenchFilter(api).props).content, "重置全部").props.onClick();
    const html = api.renderWorkbench(props);
    assert.equal(api.state.status, status);
    assert.deepEqual(plain(api.state.views[status]), { ...plain(initialState.views[status]), filters: plain(setup.DEFAULT_CASE_FILTERS), page: 1 });
    for (const other of statuses.filter(value => value !== status)) assert.equal(api.state.views[other], initialState.views[other]);
    assert.equal(workbenchFilter(api).props.open, true);
    assert.equal(popup(api, workbenchFilter(api).props).fields.props.values.status, status);
    assert.match(html, /aria-label="筛选"/); assert.doesNotMatch(html, /aria-label="筛选 \d|清除 Case .*筛选|>清除筛选<\/button>/);
    assert.equal(JSON.stringify(initialState), before);
  }
});

test("three header-right people tabs preserve eight-card pagination and role callbacks without department or subscription", () => {
  const cases = freeze(Array.from({ length: 9 }, (_, i) => c(`ordinary-${i}`)));
  const api = harness({ subscribed: cases.map(record => record.id) }); const props = { cases, onOpenCase() {} };
  let html = api.renderWorkbench(props);
  assert.equal((html.match(/role="tab"/g) ?? []).length, 3);
  assert.doesNotMatch(html, /全部 Case|更多视角/);
  const roles = byAria(api.tree, "Case 人员视角");
  assert.deepEqual(elements(roles).filter(node => ["mine", "participating", "created"].includes(node.props.value)).map(text), ["我负责", "我参与", "我分派"]);
  const toolbar = one(api.tree, node => node.type === "header", "page header");
  assert.equal(toolbar.props.children[1], roles);
  assertClasses(toolbar.props.className, ["flex", "justify-between"]);
  assertClasses(roles.props.className, ["inline-flex", "gap-1"]);
  byAria(api.tree, "下一页 Case").props.onClick(); html = api.renderWorkbench(props);
  assert.equal(articles(html).length, 1); assert.match(html, /第 9–9 个 · 9 个 Case/);
  workbenchFilter(api).props.onOpenChange(true); api.renderWorkbench(props);
  assert.equal(api.state.views.进行中.page, 2, "Opening filters preserves pagination");
  const paged = api.state;
  button(api.tree, "我负责").props.onClick(); assert.equal(api.state, paged);
  button(api.tree, "我参与").props.onClick(); html = api.renderWorkbench(props);
  assert.equal(api.state.views.进行中.scope, "participating"); assert.equal(api.state.views.进行中.page, 1);
  assert.equal(articles(html).length, 0);
  button(api.tree, "我分派").props.onClick(); html = api.renderWorkbench(props);
  assert.equal(api.state.views.进行中.scope, "created"); assert.equal(articles(html).length, 0);
  assert.doesNotMatch(html, /我部门|我订阅/);
  assert.equal(workbenchFilter(api).props.open, true);
  for (const primary of statuses) assert.match(html, new RegExp(`aria-label="${primary} 0 个 Case"`));
  assert.match(html, /aria-label="筛选"/); assert.doesNotMatch(html, /清除 Case .*筛选|aria-label="筛选 \d/);
  assertNoNestedButtons(html);
});

test("saved creator stays selected, badged and resettable while obsolete business snapshots remain ignored", () => {
  const setup = harness();
  const cases = freeze(statuses.map(status => c(status, { status, product: "DDR5", departments: ["PTE"] })));
  for (const status of statuses) {
    const initialState = setup.updateCaseWorkbenchState(setup.createCaseWorkbenchState(), { type: "status", status });
    initialState.views[status].filters = { businessKind: "Project", businessKey: "Project:unavailable", creator: "不匹配创建人" };
    freeze(initialState); const before = JSON.stringify(initialState);
    const api = harness({ initialState });
    const props = { cases, onOpenCase() {} };
    const html = api.renderWorkbench(props);
    assert.equal(articles(html).length, 0);
    const { fields, html: content } = popup(api, workbenchFilter(api).props);
    assert.deepEqual(plain(fields.props.values), { level: "全部", urgency: "全部", product: "全部", department: "全部", creator: "不匹配创建人", status });
    assert.match(html, /aria-label="筛选 1"/);
    assert.match(html, /aria-label="清除 Case 创建 \/ 分派人筛选"/);
    assert.match(content, /不匹配创建人（当前无可选项）/);
    assert.doesNotMatch(html + content, /task-business-filter|Case 涉及|Project:unavailable/);
    for (const primary of statuses) assert.ok(html.includes(`aria-label="${primary} 0 个 Case"`));
    byAria(api.tree, "清除 Case 创建 / 分派人筛选").props.onClick();
    const cleared = api.renderWorkbench(props);
    assert.equal(articles(cleared).length, 1); assert.ok(cleared.includes(`aria-label="问题 ${status}"`));
    assert.match(cleared, /aria-label="筛选"/);
    assert.equal(JSON.stringify(initialState), before);
  }
});

test("fourth summary is exclusively selected after closed, has its own callback and retains the original vertical card styling", () => {
  const api = harness(); const calls = [];
  const props = { counts, status: "已结案", fanout: true, fanoutCount: 7, onChange: status => calls.push(status), onFanout: () => calls.push("fanout-view") };
  const html = render(api.CaseStatusSummary, props); const cards = buttons(html);
  assert.equal(cards.length, 4);
  assert.ok(cards[2].includes('aria-label="已结案 3 个 Case"'));
  assert.ok(cards[3].includes('aria-label="Fanout 7 个 Case"'));
  assert.ok(cards[3].includes('aria-pressed="true"'));
  assert.ok(cards.slice(0, 3).every(card => card.includes('aria-pressed="false"')));
  assert.equal((html.match(/scaleX\(1\)/g) ?? []).length, 1);
  assert.ok(html.includes("grid-cols-[minmax(0,2fr)_minmax(0,2fr)_minmax(0,1fr)_minmax(0,1fr)]"));
  for (const card of cards) for (const token of ["px-[18px]", "pt-[15px]", "pb-[14px]", "text-[32px]", "mt-2.5", "leading-none", "rounded-xl"]) assert.ok(card.includes(token));
  const controls = elements(api.CaseStatusSummary(props)).filter(node => node.type === "button");
  controls[3].props.onClick(); controls[2].props.onClick();
  assert.deepEqual(calls, ["fanout-view", "已结案"]);
  assert.doesNotMatch(html, /Pending|暂存/);
});

test("actual MyCase Fanout defaults mine across all statuses, optional status never changes lifecycle, reset and summary clicks restore independent views", () => {
  const setup = harness();
  let initialState = setup.createCaseWorkbenchState("department");
  initialState = setup.updateCaseWorkbenchState(initialState, { type: "status", status: "已结案" });
  initialState = setup.updateCaseWorkbenchState(initialState, { type: "filters", patch: { level: "L2" } });
  initialState = setup.updateCaseWorkbenchState(initialState, { type: "page", page: 2 });
  const closedSnapshot = initialState.views.已结案;
  const cases = freeze(statuses.flatMap((status, i) => [c(`ordinary-${i}`, { status }), c(`fanout-${i}`, { status, source: "fanout验证" }),
    c(`created-${i}`, { status, source: "fanout验证", owner: "李娜", createdBy: actor.name })]));
  const api = harness({ initialState }); const props = { cases, onOpenCase() {} };
  const summary = () => one(api.tree, node => node.type === api.CaseStatusSummary, "summary");
  api.renderWorkbench(props); summary().props.onFanout(); let html = api.renderWorkbench(props);
  assert.equal(api.state.status, "已结案"); assert.equal(api.state.fanout, true); assert.equal(api.state.fanoutView.scope, "mine");
  assert.equal(articles(html).length, 3); assert.ok(statuses.every(status => html.includes(`aria-label="${status} 1 个 Case"`)));
  assert.match(html, /aria-label="Fanout 3 个 Case"/); assert.match(html, /aria-label="Fanout Case 内容"/);
  assert.doesNotMatch(html, /全部 Case|更多视角|我部门|我订阅/);
  workbenchFilter(api).props.onOpenChange(true); api.renderWorkbench(props);
  let panel = popup(api, workbenchFilter(api).props);
  assert.equal(panel.fields.props.values.status, "全部");
  assert.deepEqual(plain(panel.fields.props.statusOptions), ["全部", ...statuses]);
  assert.match(panel.html, /自定义筛选条件/); assert.doesNotMatch(panel.html, /Case 筛选范围|Case 显示设置|查看 Fanout|Fanout我/);
  selectField(api, "status", "验证中"); html = api.renderWorkbench(props);
  assert.equal(api.state.status, "已结案"); assert.equal(api.state.fanoutView.statusFilter, "验证中");
  assert.equal(articles(html).length, 1); assert.match(html, /aria-label="问题 fanout-1"/);
  assert.match(html, /aria-label="筛选 1"/); assert.equal(workbenchFilter(api).props.open, true);
  button(api.tree, "我分派").props.onClick(); api.renderWorkbench(props);
  selectField(api, "product", "不存在"); html = api.renderWorkbench(props);
  assert.equal(articles(html).length, 0); assert.match(html, /aria-label="Fanout 3 个 Case"/);
  button(popup(api, workbenchFilter(api).props).content, "重置全部").props.onClick(); html = api.renderWorkbench(props);
  assert.equal(api.state.fanout, true); assert.equal(api.state.fanoutView.scope, "created");
  assert.equal(api.state.fanoutView.statusFilter, "全部"); assert.equal(api.state.fanoutView.expanded, true);
  assert.equal(articles(html).length, 3); assert.equal(api.state.views.已结案, closedSnapshot);
  const savedFanout = api.state.fanoutView;
  summary().props.onChange("已结案"); api.renderWorkbench(props);
  assert.equal(api.state.fanout, false); assert.equal(api.state.views.已结案, closedSnapshot);
  assert.equal(workbenchFilter(api).props.status, "已结案"); assert.equal(workbenchFilter(api).props.open, false);
  summary().props.onFanout(); api.renderWorkbench(props);
  assert.equal(api.state.fanoutView, savedFanout); assert.equal(workbenchFilter(api).props.open, true);
});

test("MyCase shared custom editor uses full persisted-tree/closure candidates and the real same-task engine with invariant counts", () => {
  const cases = freeze([c("match", { tasks: [action("stale", { owner: "stale-owner" })] }), c("split"),
    c("outside", { owner: "李娜", status: "Pending" }), c("closed", { status: "Pending", source: "fanout验证" })]);
  const trees = {
    match: [{ id: "thought", title: "方向", owner: "thought-only", children: [action("real", { owner: "王强", status: "已完成" })] }],
    split: [action("owner", { owner: "王强" }), action("done", { owner: "李娜", status: "已完成" })],
    outside: [action("outside-task", { owner: "outside-owner" })],
  };
  const closures = freeze({ outside: { caseId: "outside", state: "rootcause" }, closed: { caseId: "closed", state: "closed", closedAt: "2026-09-09T00:00:00Z" } });
  const before = JSON.stringify([cases, trees, closures]);
  const api = harness({ trees, closures }); const props = { cases, onOpenCase() {} };
  api.renderWorkbench(props); workbenchFilter(api).props.onOpenChange(true); api.renderWorkbench(props);
  const editor = () => {
    const panel = popup(api, workbenchFilter(api).props);
    assert.equal(panel.panel.props.customEditor, workbenchFilter(api).props.customEditor);
    return one(panel.panelBody, node => node.type === api.CaseCustomFilterEditor, "real shared custom editor").props;
  };
  const taskOwner = editor().fields.find(field => field.id === "task:owner");
  const caseStatus = editor().fields.find(field => field.id === "case:status");
  assert.deepEqual(plain(editor().optionsFor(taskOwner)).sort(), ["outside-owner", "李娜", "王强"].sort());
  assert.deepEqual(plain(editor().optionsFor(caseStatus)).sort(), [...statuses].sort());
  const rules = freeze([{ id: "owner", fieldId: "task:owner", operator: "in", values: ["王强"] },
    { id: "status", fieldId: "task:status", operator: "in", values: ["已完成"] }, { id: "draft", fieldId: "case:name", operator: "in", values: [] }]);
  editor().onChange(rules); let html = api.renderWorkbench(props);
  assert.equal(articles(html).length, 1); assert.match(html, /aria-label="问题 match"/); assert.match(html, /1 任务/);
  assert.match(html, /aria-label="筛选 2"/); assert.match(html, /aria-label="进行中 1 个 Case"/); assert.match(html, /aria-label="Fanout 1 个 Case"/);
  assert.notEqual(api.state.views.进行中.customRules, rules);
  assert.deepEqual(plain(api.state.views.进行中.customRules), plain(rules));
  rules.forEach((rule, i) => assert.equal(api.state.views.进行中.customRules[i], rule));
  assert.equal(api.state.views.进行中.page, 1);
  assert.equal(workbenchFilter(api).props.open, true);
  assert.deepEqual(plain(editor().optionsFor(taskOwner)).sort(), ["outside-owner", "李娜", "王强"].sort(), "Candidates are not restricted by results, role, status or custom rules");
  assert.equal(JSON.stringify([cases, trees, closures]), before);
  // Read-through rerender uses the newest tree without mutating Case snapshots or filter state.
  trees.match = [action("changed", { owner: "王强", status: "进行中" })];
  const readsBefore = api.treeReads.length; html = api.renderWorkbench(props);
  assert.equal(api.treeReads.length - readsBefore, cases.length);
  assert.equal(articles(html).length, 0); assert.match(html, /aria-label="进行中 0 个 Case"/);
  button(popup(api, workbenchFilter(api).props).content, "重置全部").props.onClick(); html = api.renderWorkbench(props);
  assert.deepEqual(plain(api.state.views.进行中.customRules), []); assert.equal(articles(html).length, 2);
  assert.equal(workbenchFilter(api).props.open, true); assert.match(html, /aria-label="筛选"/);
  assert.equal(cases[0].tasks[0].owner, "stale-owner");
});

test("custom rules and page are saved per top view while legacy source cannot hide ordinary rows and Fanout custom results paginate globally", () => {
  const setup = harness(); const initialState = setup.createCaseWorkbenchState();
  initialState.views.进行中.source = "fanout";
  const cases = freeze([c("ordinary", { product: "normal" }), ...Array.from({ length: 19 }, (_, i) => c(`fan-${String(i).padStart(2, "0")}`, {
    status: statuses[i % 3], source: "fanout验证", product: i % 2 === 0 ? "match" : "miss", dueDate: `2026-09-${String(i + 1).padStart(2, "0")}`,
  }))]);
  const api = harness({ initialState }); const props = { cases, onOpenCase() {} };
  const summary = () => one(api.tree, node => node.type === api.CaseStatusSummary, "summary");
  let html = api.renderWorkbench(props); assert.match(html, /aria-label="问题 ordinary"/);
  const rules = [{ id: "product", fieldId: "case:product", operator: "in", values: ["match"] }];
  workbenchFilter(api).props.customEditor.onChange(rules); api.renderWorkbench(props);
  const normalSnapshot = api.state.views.进行中;
  summary().props.onFanout(); html = api.renderWorkbench(props);
  assert.deepEqual(plain(workbenchFilter(api).props.customEditor.rules), []);
  workbenchFilter(api).props.customEditor.onChange(rules); html = api.renderWorkbench(props);
  assert.match(html, /第 1–8 个 · 10 个 Case/); assert.match(html, /aria-label="Fanout 19 个 Case"/);
  const first = articles(html).map(article => /aria-label="问题 ([^"]+)"/.exec(article)[1]);
  byAria(api.tree, "下一页 Case").props.onClick(); html = api.renderWorkbench(props);
  const second = articles(html).map(article => /aria-label="问题 ([^"]+)"/.exec(article)[1]);
  assert.deepEqual([...first, ...second], cases.slice(1).filter((_, i) => i % 2 === 0).map(c => c.id));
  const fanoutSnapshot = api.state.fanoutView;
  summary().props.onChange("进行中"); api.renderWorkbench(props); assert.equal(api.state.views.进行中, normalSnapshot);
  summary().props.onFanout(); html = api.renderWorkbench(props); assert.equal(api.state.fanoutView, fanoutSnapshot);
  assert.match(html, /第 9–10 个 · 10 个 Case/);
  assert.ok(["进行中 0", "验证中 0", "已结案 0", "Fanout 19"].every(value => html.includes(`aria-label="${value} 个 Case"`)));
});

const workbenchSort = api => one(api.tree, node => node.type === api.WorkbenchSort, "shared workbench sort");
function changeSort(api, value) {
  byAria(api.WorkbenchSort(workbenchSort(api).props), "我的 Case 排序").props.onChange({ target: { value } });
}
const topViews = [...statuses, "Fanout"];
const currentView = state => state.fanout ? state.fanoutView : state.views[state.status];

test("shared analysis-style filter and sort remain together below the three header-right role tabs", () => {
  const setup = harness();
  for (const view of topViews) {
    const initialState = setup.updateCaseWorkbenchState(setup.createCaseWorkbenchState(), view === "Fanout" ? { type: "fanout" } : { type: "status", status: view });
    const api = harness({ initialState }); const html = api.renderWorkbench({ cases: [], onOpenCase() {} });
    const filter = workbenchFilter(api); const sort = workbenchSort(api); const roles = byAria(api.tree, "Case 人员视角");
    const right = one(api.tree, node => node.type === "div" && Array.isArray(node.props.children) && node.props.children[0] === filter && node.props.children[1] === sort, "filter then sort siblings");
    assert.equal(right.props.children.length, 2);
    assertClasses(right.props.className, ["ml-auto", "flex", "items-center", "gap-2"]);
    const toolbar = one(api.tree, node => node.type === "div" && node.props.className?.includes("h-10"), "one-row toolbar");
    assert.ok(elements(toolbar).includes(right)); assert.ok(!elements(toolbar).includes(roles));
    assert.equal(elements(roles).filter(node => ["mine", "participating", "created"].includes(node.props.value)).length, 3);
    assert.equal(sort.props.ariaLabel, "我的 Case 排序");
    assert.match(render(api.WorkbenchSort, sort.props), /inline-flex h-8[^>]*text-xs/);
    assert.equal(sort.props.value, view === "已结案" ? "updated" : "urgency");
    assert.deepEqual(plain(sort.props.options), [
      { value: "urgency", label: "紧迫度" }, { value: "level", label: "层级" },
      { value: "progress", label: "进度(低→高)" }, { value: "updated", label: "最近更新" },
    ]);
    assert.ok(html.indexOf('aria-label="筛选"') < html.indexOf('aria-label="我的 Case 排序"'));
    assert.ok(html.includes(render(api.WorkbenchSort, sort.props)), "Use the shared component without a local lookalike");
    const control = /<select\b[^>]*aria-label="我的 Case 排序"[^>]*>[\s\S]*?<\/select>/.exec(html)?.[0];
    assert.ok(control); assert.equal((control.match(/<option\b/g) ?? []).length, 4);
    assert.equal((html.match(/aria-label="我的 Case 排序"/g) ?? []).length, 1);
    assert.doesNotMatch(html, /aria-label="筛选 \d|清除.*排序|>清除筛选<|更多视角|我部门|我订阅/);
    assert.equal(popup(api, filter.props).controls.length, view === "Fanout" ? 6 : 5, "Primary statuses omit the redundant status field; Fanout keeps it");
    assertNoNestedButtons(html);
  }
});

test("SSR normal status lists exclude Fanout for all three people tabs, while the Fanout view shows every status", () => {
  const setup = harness(); const scopes = ["mine", "participating", "created"];
  const labels = ["我负责", "我参与", "我分派"];
  const sizes = [1, 1, 1];
  const cases = freeze(statuses.flatMap((status, i) => [
    c(`ordinary-own-${i}`, { status, fanoutTargets: ["p1"] }),
    c(`ordinary-other-${i}`, { status, owner: "李娜", createdBy: actor.name, participants: [{ name: actor.name }], departments: ["PTE"], parentCaseId: `ordinary-own-${i}` }),
    c(`fan-own-${i}`, { status, source: "fanout验证" }),
    c(`fan-other-${i}`, { status, fanoutSourceCaseId: `ordinary-own-${i}`, owner: "李娜", createdBy: actor.name, participants: [{ name: actor.name }], departments: ["PTE"] }),
  ]));
  const before = JSON.stringify(cases);
  for (const status of statuses) for (const [i, scope] of scopes.entries()) {
    let initialState = setup.updateCaseWorkbenchState(setup.createCaseWorkbenchState(scope), { type: "status", status });
    initialState = setup.updateCaseWorkbenchState(initialState, { type: "source", source: "fanout" });
    const api = harness({ initialState, subscribed: cases.map(c => c.id) }); const props = { cases, onOpenCase() {} };
    let html = api.renderWorkbench(props);
    assert.equal(articles(html).length, sizes[i]);
    assert.ok(articles(html).every(article => article.includes('aria-label="问题 ordinary-')));
    assert.doesNotMatch(articles(html).join(""), /Fanout|来源 Case|问题 fan-/);
    for (const primary of statuses) assert.ok(html.includes(`aria-label="${primary} 1 个 Case"`));
    assert.match(html, /aria-label="Fanout 3 个 Case"/);
    assert.deepEqual(elements(byAria(api.tree, "Case 人员视角")).filter(node => scopes.includes(node.props.value)).map(text), labels);
    one(api.tree, node => node.type === api.CaseStatusSummary, "summary").props.onFanout(); html = api.renderWorkbench(props);
    assert.equal(articles(html).length, 3);
    button(api.tree, labels[i]).props.onClick(); html = api.renderWorkbench(props);
    assert.equal(articles(html).length, sizes[i] * 3);
    assert.ok(articles(html).every(article => article.includes("Fanout</span>")));
    for (const primary of statuses) {
      assert.ok(articles(html).some(article => article.includes(`${primary}</span>`)));
      assert.ok(html.includes(`aria-label="${primary} 1 个 Case"`));
    }
    assert.match(html, /aria-label="Fanout 3 个 Case"/);
  }
  assert.equal(JSON.stringify(cases), before);
});

test("real sort callbacks order persisted progress across pages, preserve filters custom rules and popup, reject invalid input and reset filters without resetting sort", () => {
  const setup = harness();
  for (const view of topViews) {
    const cases = freeze(Array.from({ length: 19 }, (_, i) => c(`sort-${String(i).padStart(2, "0")}`, {
      status: view === "Fanout" ? statuses[i % 3] : view, source: view === "Fanout" ? "fanout验证" : "手动",
      product: "DDR5", dueDate: `2026-09-${String(i + 1).padStart(2, "0")}`, tasks: [action(`stale-${i}`, { progress: i })],
    })));
    const trees = freeze(Object.fromEntries(cases.map((record, i) => [record.id, [{ id: `thought-${i}`, progress: 100, children: [action(`actual-${i}`, { progress: 18 - i })] }]])));
    const rules = freeze([{ id: "product", fieldId: "case:product", operator: "in", values: ["DDR5"] }]);
    let initialState = setup.updateCaseWorkbenchState(setup.createCaseWorkbenchState(), view === "Fanout" ? { type: "fanout" } : { type: "status", status: view });
    for (const action of [{ type: "scope", scope: "subscribed" }, { type: "filters", patch: { product: "DDR5" } },
      { type: "custom-rules", rules }, { type: "expanded" }, { type: "page", page: 2 }]) initialState = setup.updateCaseWorkbenchState(initialState, action);
    freeze(initialState); const before = JSON.stringify([cases, trees, initialState]);
    const api = harness({ initialState, trees, subscribed: cases.map(c => c.id) }); const props = { cases, onOpenCase() {} };
    let html = api.renderWorkbench(props); const summaries = buttons(html).slice(0, 4);
    assert.match(html, /第 9–16 个 · 19 个 Case/);
    const previous = currentView(api.state); const reads = api.treeReads.length;
    changeSort(api, "progress"); html = api.renderWorkbench(props);
    assert.equal(api.treeReads.length - reads, cases.length);
    assert.deepEqual(plain(currentView(api.state)), { ...plain(previous), sortBy: "progress", page: 1 });
    assert.equal(currentView(api.state).filters, previous.filters); assert.equal(currentView(api.state).customRules, previous.customRules);
    assert.deepEqual(plain(currentView(api.state).customRules), plain(rules));
    assert.equal(workbenchSort(api).props.value, "progress"); assert.equal(workbenchFilter(api).props.open, true);
    assert.match(html, /aria-label="筛选 2"/); assert.deepEqual(buttons(html).slice(0, 4), summaries);
    const seen = [];
    for (const page of [1, 2, 3]) {
      if (page > 1) { byAria(api.tree, "下一页 Case").props.onClick(); html = api.renderWorkbench(props); }
      seen.push(...articles(html).map(article => /aria-label="问题 ([^"]+)"/.exec(article)[1]));
    }
    assert.deepEqual(seen, [...cases].reverse().map(c => c.id)); assert.equal(new Set(seen).size, 19);
    const paged = api.state;
    for (const value of ["progress", "due", "", "constructor"]) { changeSort(api, value); assert.equal(api.state, paged); }
    workbenchSort(api).props.onChange("invalid"); assert.equal(api.state, paged, "The reducer also validates direct callback input");
    button(popup(api, workbenchFilter(api).props).content, "重置全部").props.onClick(); html = api.renderWorkbench(props);
    assert.equal(workbenchSort(api).props.value, "progress"); assert.equal(currentView(api.state).page, 1);
    assert.equal(currentView(api.state).scope, "subscribed"); assert.equal(workbenchFilter(api).props.open, true);
    assert.deepEqual(plain(currentView(api.state).customRules), []);
    assert.match(html, /aria-label="筛选"/); assert.doesNotMatch(html, /aria-label="筛选 \d|清除 Case .*筛选|>清除筛选<|清除.*排序/);
    assert.deepEqual(buttons(html).slice(0, 4), summaries);
    for (const status of statuses) if (view === "Fanout" || status !== view) assert.equal(api.state.views[status], initialState.views[status]);
    if (view !== "Fanout") assert.equal(api.state.fanoutView, initialState.fanoutView);
    assert.equal(JSON.stringify([cases, trees, initialState]), before);
  }
});

test("linked primary summaries carry people and filters while preserving each destination sort; Fanout remains independent", () => {
  const setup = harness(); let initialState = setup.createCaseWorkbenchState();
  initialState.views.验证中.sortBy = "progress"; initialState.views.已结案.sortBy = "updated";
  const api = harness({ initialState }); const props = { cases: [], onOpenCase() {} }; api.renderWorkbench(props);
  button(api.tree, "我参与").props.onClick(); api.renderWorkbench(props);
  workbenchFilter(api).props.onChange({ product: "共享产品" }); workbenchFilter(api).props.onOpenChange(true); api.renderWorkbench(props);
  const summary = () => one(api.tree, node => node.type === api.CaseStatusSummary, "summary");
  summary().props.onChange("验证中"); api.renderWorkbench(props);
  assert.equal(api.state.views.验证中.scope, "participating"); assert.equal(api.state.views.验证中.filters.product, "共享产品");
  assert.equal(workbenchSort(api).props.value, "progress"); assert.equal(workbenchFilter(api).props.open, false);
  workbenchFilter(api).props.onOpenChange(true); api.renderWorkbench(props);
  summary().props.onChange("已结案"); api.renderWorkbench(props);
  assert.equal(api.state.views.已结案.scope, "participating"); assert.equal(api.state.views.已结案.filters.product, "共享产品"); assert.equal(workbenchSort(api).props.value, "updated");
  const closed = api.state.views.已结案; summary().props.onFanout(); api.renderWorkbench(props);
  assert.equal(api.state.fanoutView.scope, "mine"); assert.equal(api.state.fanoutView.filters.product, "全部");
  summary().props.onChange("已结案"); api.renderWorkbench(props); assert.equal(api.state.views.已结案, closed);
});

test("MyCase custom snapshots, shared panel badges and real callbacks normalize removed operators in every top view", () => {
  const setup = harness();
  const cases = freeze(statuses.flatMap((status, i) => [
    c(`keep-${i}`, { status, product: "keep" }), c(`other-${i}`, { status, product: "other" }),
    c(`fan-keep-${i}`, { status, product: "keep", source: "fanout验证" }), c(`fan-other-${i}`, { status, product: "other", source: "fanout验证" }),
  ]));
  const legacy = freeze([
    { id: "owner", fieldId: "case:owner", operator: "contains", values: ["nonexistent"] },
    { id: "date", fieldId: "case:updatedAt", operator: "between", values: ["2026-09-01", "2026-09-30"] },
    { id: "number", fieldId: "case:tasks#count", operator: "gt", values: ["0"] },
  ]);
  const keep = freeze({ id: "product", fieldId: "case:product", operator: "in", values: ["keep"] });
  const before = JSON.stringify([cases, legacy, keep]);
  for (const view of topViews) for (const valid of [[], [keep]]) {
    const rules = freeze([...legacy, ...valid]);
    const initialState = setup.updateCaseWorkbenchState(setup.createCaseWorkbenchState(), view === "Fanout" ? { type: "fanout" } : { type: "status", status: view });
    Object.assign(currentView(initialState), { customRules: rules, expanded: true, page: 9 });
    freeze(initialState); const stateBefore = JSON.stringify(initialState);
    const api = harness({ initialState }); const props = { cases, onOpenCase() {} };
    const html = api.renderWorkbench(props); const filter = workbenchFilter(api);
    const badge = valid.length ? "筛选 1" : "筛选";
    assert.equal(articles(html).length, (view === "Fanout" ? 3 : 1) * (valid.length ? 1 : 2));
    if (valid.length) assert.ok(articles(html).every(article => /问题 (?:fan-)?keep-/.test(article)));
    assert.ok(html.includes(`aria-label="${badge}"`));
    assert.ok(render(api.CaseWorkbenchFilters, filter.props).includes(`aria-label="${badge}"`), "The shared filter trigger independently normalizes raw snapshots");
    assert.equal(filter.props.customEditor.rules, rules, "Exercise the real editor with raw saved drafts, not prefiltered fixtures");
    const panel = popup(api, filter.props);
    assert.equal(panel.panel.props.customEditor, filter.props.customEditor);
    const editor = one(panel.panelBody, node => node.type === api.CaseCustomFilterEditor, "actual shared custom editor");
    const editorHtml = render(api.CaseCustomFilterEditor, editor.props);
    assert.doesNotMatch(editorHtml, /<select|type="number"|type="date"|是其中之一|多条件同时满足；任务条件需命中同一条执行任务。/);
    assert.equal((editorHtml.match(/未生效/g) ?? []).length, legacy.length);
    const messages = editorHtml.match(/<p\b[^>]*aria-live="polite"[^>]*>[\s\S]*?<\/p>/g) ?? [];
    assert.equal(messages.length, rules.length); assert.ok(messages.every(message => message.includes('class="sr-only"')));
    for (const status of statuses) assert.ok(html.includes(`aria-label="${status} ${valid.length ? 1 : 2} 个 Case"`));
    assert.match(html, /aria-label="Fanout 6 个 Case"/);
    editor.props.onChange(rules); const changedHtml = api.renderWorkbench(props);
    const normalized = currentView(api.state).customRules;
    assert.deepEqual(plain(normalized), [...legacy.map(rule => ({ ...rule, operator: "in", values: [] })), ...valid]);
    if (valid.length) assert.equal(normalized.at(-1), keep);
    assert.equal(currentView(api.state).page, 1); assert.equal(workbenchFilter(api).props.open, true);
    assert.equal(articles(changedHtml).length, articles(html).length);
    assert.ok(changedHtml.includes(`aria-label="${badge}"`));
    button(popup(api, workbenchFilter(api).props).content, "重置全部").props.onClick();
    const resetHtml = api.renderWorkbench(props);
    assert.deepEqual(plain(currentView(api.state).customRules), []);
    assert.equal(articles(resetHtml).length, view === "Fanout" ? 6 : 2);
    assert.match(resetHtml, /aria-label="筛选"/); assert.equal(workbenchFilter(api).props.open, true);
    assert.equal(JSON.stringify(initialState), stateBefore);
  }
  assert.equal(JSON.stringify([cases, legacy, keep]), before);
});