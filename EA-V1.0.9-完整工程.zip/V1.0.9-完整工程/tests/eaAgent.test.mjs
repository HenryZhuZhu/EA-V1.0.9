import assert from "node:assert/strict";
import test from "node:test";
import vm from "node:vm";
import { fileURLToPath } from "node:url";
import { build } from "esbuild";

const { outputFiles } = await build({ entryPoints: [fileURLToPath(new URL("../src/app/components/eaAgentModel.ts", import.meta.url))], bundle: true, write: false, format: "cjs", platform: "node" });
const sandbox = { module: { exports: {} } };
vm.runInNewContext(outputFiles[0].text, sandbox);
const { clampAgentPosition, initialAgentPosition, agentPanelBounds, agentDemoReply } = sandbox.module.exports;
const plain = (value) => JSON.parse(JSON.stringify(value));

test("launcher position stays inside desktop viewport and invalid storage falls back safely", () => {
  const viewport = { width: 1280, height: 900 };
  assert.deepEqual(plain(clampAgentPosition({ x: -100, y: 5000 }, viewport)), { x: 16, y: 820 });
  assert.deepEqual(plain(initialAgentPosition('{"x":120,"y":80}', viewport)), { x: 120, y: 80 });
  const fallback = plain(initialAgentPosition(null, viewport));
  for (const raw of ["{broken", "[]", "null", '{"x":"bad","y":5}', '{"x":1e999,"y":5}']) assert.deepEqual(plain(initialAgentPosition(raw, viewport)), fallback);
  assert.deepEqual(plain(initialAgentPosition('{"x":1500,"y":950}', viewport)), { x: 1200, y: 820 });
});

test("chat panel remains visible regardless of dock position or viewport resize", () => {
  for (const viewport of [{ width: 1440, height: 1000 }, { width: 1280, height: 720 }, { width: 1024, height: 600 }]) {
    for (const position of [{ x: 16, y: 16 }, { x: 5000, y: 5000 }, { x: 600, y: 400 }]) {
      const panel = agentPanelBounds(position, viewport);
      assert.ok(panel.left >= 16 && panel.top >= 16);
      assert.ok(panel.left + panel.width <= viewport.width - 16);
      assert.ok(panel.top + panel.height <= viewport.height - 16);
    }
  }
});

test("offline replies never claim a real query or an action was performed", () => {
  assert.match(agentDemoReply("日常任务如何处理？"), /没有更改任何任务/);
  assert.match(agentDemoReply("自由任务如何处理？"), /没有更改任何任务/);
  assert.match(agentDemoReply("其他问题"), /自由任务如何处理/);
  assert.doesNotMatch(agentDemoReply("其他问题"), /日常任务/);
  assert.match(agentDemoReply("Workspace结论怎么写？"), /不会自动保存/);
  assert.match(agentDemoReply("DDR5 Case 分析"), /尚未读取页面数据或检索历史案例/);
  assert.match(agentDemoReply("你好"), /并非真实 AI 推理/);
  assert.match(agentDemoReply("其他问题"), /无法.*真实检索或推理/);
  assert.ok(agentDemoReply("x".repeat(6000)).length < 600);
});