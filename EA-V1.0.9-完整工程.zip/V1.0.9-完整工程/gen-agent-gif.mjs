import { readFileSync, writeFileSync } from "node:fs";
import { pathToFileURL } from "node:url";
import { Resvg } from "@resvg/resvg-js";
import gifenc from "gifenc";

const { GIFEncoder, quantize, applyPalette } = gifenc;
export const AGENT_GIF_SIZE = 224;
export const AGENT_GIF_FRAMES = 240;
export const AGENT_GIF_DELAY = 40;
const original = readFileSync(new URL("./src/app/components/agent-original.svg", import.meta.url), "utf8");

export function renderAgentFrame(frame) {
  const phase = frame / AGENT_GIF_FRAMES * Math.PI * 2;
  const progress = (1 - Math.cos(phase)) / 2;
  const sweepOffset = -75 + 150 * frame / AGENT_GIF_FRAMES;
  const flow = `translate(40 40) rotate(${-9 + 24 * progress}) scale(${1.03 + .07 * progress}) translate(-40 -40)`;
  const svg = original
    .replace('data-animation="flow"', `transform="${flow}"`)
    .replace('data-animation="refraction"', `transform="rotate(${8 - 20 * progress} 40 40)" opacity="${.65 + .35 * progress}"`)
    .replace('data-animation="colors"', `transform="rotate(${frame / AGENT_GIF_FRAMES * 360} 40 40)"`)
    .replace('data-animation="sweep" opacity="0"', `transform="translate(${sweepOffset} 0)" opacity="${Math.sin(frame / AGENT_GIF_FRAMES * Math.PI) * .65}"`);
  return new Resvg(svg, { fitTo: { mode: "width", value: AGENT_GIF_SIZE } }).render().pixels;
}

export function encodeAgentGif() {
  const animation = GIFEncoder();
  const poster = GIFEncoder();
  for (let frame = 0; frame < AGENT_GIF_FRAMES; frame++) {
    const pixels = new Uint8Array(renderAgentFrame(frame));
    for (let offset = 0; offset < pixels.length; offset += 4) {
      const alpha = pixels[offset + 3] / 255;
      if (!alpha) continue;
      for (let channel = 0; channel < 3; channel++) pixels[offset + channel] = Math.round(pixels[offset + channel] * alpha + 255 * (1 - alpha));
      pixels[offset + 3] = 255;
    }
    const palette = quantize(pixels, 255, { format: "rgb565" });
    const indexed = applyPalette(pixels, palette, "rgb565");
    const transparentIndex = palette.length;
    palette.push([0, 0, 0]);
    for (let offset = 0; offset < indexed.length; offset++) if (!pixels[offset * 4 + 3]) indexed[offset] = transparentIndex;
    const options = { palette, delay: AGENT_GIF_DELAY, repeat: 0, transparent: true, transparentIndex, dispose: 2 };
    animation.writeFrame(indexed, AGENT_GIF_SIZE, AGENT_GIF_SIZE, options);
    if (frame === 0) poster.writeFrame(indexed, AGENT_GIF_SIZE, AGENT_GIF_SIZE, options);
  }
  animation.finish(); poster.finish();
  return { animation: animation.bytes(), poster: poster.bytes() };
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const { animation, poster } = encodeAgentGif();
  const uri = bytes => `data:image/gif;base64,${Buffer.from(bytes).toString("base64")}`;
  writeFileSync(new URL("./src/app/components/agentGif.ts", import.meta.url), `export const AGENT_GIF = ${JSON.stringify(uri(animation))};\nexport const AGENT_POSTER = ${JSON.stringify(uri(poster))};\n`);
  console.log(`Generated ${AGENT_GIF_FRAMES}-frame original-artwork GIF: ${animation.length} bytes`);
}