// 生成 管理者视图 verbatim 副本（iframe srcDoc）—— 从参考原型逐行切片，零手工转写。
// 参考：EA系统_打分积分版_原型演示包/index.html （Chart.js v4.4.7）
import { readFileSync, writeFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";

const __dir = dirname(fileURLToPath(import.meta.url));
const REF = resolve(__dir, "../../EA系统_打分积分版_原型演示包/index.html");
const CHART = resolve(__dir, "../../EA系统_打分积分版_原型演示包/lib/chart.min.js");
const OUT = resolve(__dir, "src/app/components/managerProtoSrc.ts");

const lines = readFileSync(REF, "utf8").split("\n");
// 1-indexed 行切片（含端点）
const slice = (a, b) => lines.slice(a - 1, b).join("\n");

// ---- CSS：整段 <style>…</style> 内容（iframe 隔离，整段引入零遗漏）----
const css = slice(9, 872);

// ---- HTML：page-manager 整块（2653-2926）+ 抽屉（2932-2946），仅去掉 display:none ----
let pageManager = slice(2653, 2926).replace(
  '<div class="page-manager" id="page-manager" style="display:none">',
  '<div class="page-manager" id="page-manager">'
);
const drawer = slice(2932, 2946);
const managerHTML = pageManager + "\n" + drawer;

// ---- JS：数据（2956-3057）+ 管理者函数（3333-3832），均为自包含，仅依赖 window.Chart ----
const dataJS = slice(2956, 3057);
const funcJS = slice(3333, 3832);

// 进入管理者页时参考原型执行：initCharts(); updateMatrix();（switchPage('manager') 的行为）
// 另外：把内容高度回传父窗口，外层 iframe 自适应高度，避免内层滚动条。
const initJS = `
// ===== 自动初始化（等同参考原型 switchPage('manager')）=====
(function(){
  function boot(){
    try { initCharts(); updateMatrix(); } catch(e) { console.error('[manager] init', e); }
    postHeight();
  }
  function postHeight(){
    try { parent.postMessage({ __eaManagerHeight: document.documentElement.scrollHeight }, '*'); } catch(e){}
  }
  window.__eaPostHeight = postHeight;
  if (document.readyState === 'complete' || document.readyState === 'interactive') boot();
  else window.addEventListener('DOMContentLoaded', boot);
  window.addEventListener('load', postHeight);
  window.addEventListener('resize', postHeight);
  setTimeout(postHeight, 400);
  setTimeout(postHeight, 1200);
  // tab 切换 / 抽屉开合后也回传高度
  ['switchManagerTab','switchAnomalyTab','openDrawer','closeDrawer'].forEach(function(fn){
    if (typeof window[fn] === 'function') {
      var orig = window[fn];
      window[fn] = function(){ var r = orig.apply(this, arguments); setTimeout(postHeight, 60); return r; };
    }
  });
})();`;

const chartJS = readFileSync(CHART, "utf8");

// 内联进 srcDoc 的 <script> 内，需中和字面量 </script> 以免提前闭合
const neutralize = (s) => s.replace(/<\/script>/gi, "<\\/script>");
const innerJS = neutralize(dataJS + "\n" + funcJS + "\n" + initJS);
const chartInlined = neutralize(chartJS);

const srcDoc =
`<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<style>
html,body{margin:0}
${css}
</style>
</head>
<body>
<div class="content" style="background:#F5F7FA">
${managerHTML}
</div>
<script>${chartInlined}</script>
<script>${innerJS}</script>
</body>
</html>`;

const banner = `// 自动生成 —— 请勿手改。由 gen-manager-proto.mjs 从参考原型逐行切片生成。
// 源：EA系统_打分积分版_原型演示包/index.html（管理者视图 verbatim 副本，Chart.js v4.4.7 内联）
// 重新生成：node gen-manager-proto.mjs
`;
writeFileSync(OUT, banner + "export const MANAGER_SRCDOC = " + JSON.stringify(srcDoc) + ";\n", "utf8");
console.log("✓ wrote", OUT, "(" + (srcDoc.length / 1024).toFixed(0) + " KB srcDoc)");
