
# EA V1.0.9 · 完整工程

本目录是基于既有 V1.0.9 完整 React 原型复制并独立迭代的工程，不是 Vue 第一批迁移包，也不是只有几个新增页面的演示壳。
既有任务、Case、思维导图、创建、分析中心、技能、团队看板、Agent 等源码与本地素材均保留；此次新增内容见 [FEATURES.md](FEATURES.md)。

## 交付文件

- `V1.0.9.html`：可直接双击的单文件离线原型。
- `dist/`：Vite 生成的 HTML / CSS / JS 网页包，可部署到静态服务器。
- `src/`：完整 React + TypeScript 源码、样式和素材。
- `tests/`：模型与组件回归、隔离浏览器流程验收脚本。
- `EA-V1.0.9-完整工程.zip`：可独立安装的源码工程包。为避免重复占体积，不含 `node_modules/`、`dist/`、已生成的单文件 HTML 及测试临时产物；解压后可重新生成。
- `SOURCE-BASELINE.json`：来源版本及冻结文件校验值。

原根目录 V1.0.8、旧 V1.0.9、旧 app、网页包、海报和 Vue 工程均不覆盖。完整工程的新目录名称带“完整工程”，避免在 macOS 上与已有小写 `v1.0.9` 目录冲突。

## 安装与运行

推荐 Node.js 22 LTS / 24 LTS、npm。保留 package-lock.json，勿跨工程复用旧 node_modules。

```sh
npm ci
npm run dev
```

默认预览地址为 `http://127.0.0.1:5195/`，端口占用时以终端显示为准。

```sh
npm run export
```

同时生成当前目录的 `dist/` 和 `V1.0.9.html`，不会写入父目录。网页资源使用相对路径。

```sh
npm run preview
npm run package
```

前者通过 HTTP 预览 `dist/`，后者重新构建并生成带 SHA-256 校验文件的源码 ZIP。单文件 HTML 使用 `inline-build.mjs` 内嵌资源，不依赖开发服务器。

## 验证

```sh
npm test
npx playwright install chromium
npm run test:browser
node tests/recordRecovery.browser.mjs
```

浏览器测试前启动 `npm run dev`；可用 `EA_PREVIEW_URL` 指定其他 HTTP 或 file:// 地址。浏览器用例使用全新的隔离上下文，创建临时验收数据，不修改用户浏览器记录。截图保存到 `test-results/`。

## 功能入口

1. 顶部“演示身份”仅切换原型身份，不是正式登录或业务窗口。高级管理者可选“高总监”，张伟直属主管为“周主管”。切换会刷新，请先保存草稿。
2. 管理者左侧“我的 → 我发起的整改”是正式监管清单。只展示当前身份发起的退回整改，支持跟进、新反馈、超期、历史、查询、修改对比及再次退回，无完成确认按钮。
3. 在 Case / 任务详情“退回整改”中填写要求，可选反馈日期；负责人编辑原 Workspace 后按原流程完成。提交结果自动出现在退回者清单和通知里，不另填处理说明。
4. 工程师主动重开必须先线下沟通，由直属主管“重新处理”；已审核 Case 的再次结案仍保留原审核流程。
5. Case 参与人员旁的“HEMS建群”仅主管、总监、VP 可见，普通工程师（包括 Case Owner）不显示入口。首次建群邀请点击人、Owner 和全部协作者/参与者；建群后只提供“补充参与人”，补充新增或上次失败的人员，无待补充人员时置灰，不提供打开群聊或自行加入。当前仍为明确标注的本地模拟。
6. 分析中心 → 全部 Case 列表的 Owner 后显示最多两位核心参与者，完整群组名单不因此缩减。

## 工程边界

- 无后端、真实HEMS群组 API、邮件、HEMS 推送或真实 AI。通知是本地列表，提醒是访问页面时按当前日期计算，不是后台定时推送。
- 不把工程师提交结果标为管理者已认可，也不增加整改验收审批；原有结案审批与整改反馈独立。
- localStorage 按浏览器 origin 存储；端口不同数据隔离，file:// 在不同浏览器中可能共享存储。体验新旧离线原型前建议使用独立浏览器配置或备份原数据。
- 面向桌面端，验收尺寸为 1280 / 1440。不是移动端改版。
- 继承的外部系统示例与部分历史原型操作不等于生产服务；本交付“完整”指完整前端工程与当前约定功能，不代表已接入企业后端。
- 光球 GIF 仍内嵌，构建有原有大包提示；未为了缩包替换视觉素材。源码 ZIP 排除了构建重复内容。

## 主要新增文件

`RecoveryWorkbench.tsx` 为正式清单；`recoveryFeedback.ts` 提供进展、提醒、个人已读与通知规则；`recordRecovery.ts` 保存原要求及提交快照；`CaseFeishuGroup.tsx` / `caseFeishuGroups.ts` 为群组示例；`caseParticipants.ts` / `CaseCoreParticipants.tsx` 为参与者计算和展示。均位于 `src/app/components/`。

旧 `CLAUDE.md` 和 `EA_Platform_SOP.md` 含早期版本说明，仅作为迁移来源参考；本交付的命令、范围、数据边界以当前 README / FEATURES 为准。
  