import { useEffect, useRef, useState } from "react";
import { Sidebar, PageKey, TodoTab } from "./components/Sidebar";
import { TopBar } from "./components/TopBar";
import { MyTodo } from "./components/MyTodo";
import { CaseList } from "./components/CaseList";
import { CaseDetail } from "./components/CaseDetail";
import { TaskDetail } from "./components/TaskDetail";
import { ManagerView } from "./components/ManagerView";
import { ContestView } from "./components/ContestView";
import { ProfilePage } from "./components/ProfilePage";
import { CreateCase, CreatePrefill } from "./components/CreateCase";
import { IssueCenter } from "./components/IssueCenter";
import { FeedbackPanel } from "./components/FeedbackPanel";
import { ToolRail } from "./components/ToolRail";
import { Onboarding, ONBOARDING_KEY } from "./components/Onboarding";
import { WhatsNew, WHATSNEW_KEY } from "./components/WhatsNew";
import { currentUser, mockCases } from "./components/data";
import { CreateCaseLab } from "./components/CreateCaseLab";
import { EaAgentPage } from "./components/EaAgentPage";
import { SkillCenter } from "./components/SkillCenter";
import { useAgentConversation } from "./components/useAgentConversation";
import { CreateStandaloneTask } from "./components/CreateStandaloneTask";
import { EditStandaloneTask } from "./components/EditStandaloneTask";
import { StandaloneTaskDetail } from "./components/StandaloneTaskDetail";
import { prepareStandaloneTaskUpgrade, standaloneTaskById } from "./components/standaloneTasks";
import { EaAgent } from "./components/EaAgent";
import { RecoveryWorkbench } from "./components/RecoveryWorkbench";

const LAB_CREATE_CASE_ACCOUNTS = new Set(["alan"]);

function usesLabCreateCase(accountId: string) {
  return LAB_CREATE_CASE_ACCOUNTS.has(accountId.trim().toLowerCase());
}

type View =
  | { kind: "page"; page: PageKey; casesView?: "focus" | "issue"; createEntry?: "direct" | "related" }
  | { kind: "skill-management" }
  | { kind: "case"; id: string }
  | { kind: "issue"; id: string }
  | { kind: "task"; caseId: string; taskId: string }
  | { kind: "standalone-task"; taskId: string }
  | { kind: "create-standalone-task" }
  | { kind: "edit-standalone-task"; taskId: string }
  | { kind: "create"; mode: "upgrade" | "approve" | "edit"; caseId?: string };

export default function App() {
  const agentConversation = useAgentConversation();
  const [view, setView] = useState<View>({ kind: "page", page: "todo" });
  const agentReturnView = useRef<View>({ kind: "page", page: "todo" });
  const [agentWindowRequest, setAgentWindowRequest] = useState(0);
  const [createVariant, setCreateVariant] = useState<"lab" | "standard">(() => usesLabCreateCase(currentUser.accountId) ? "lab" : "standard");
  const mainRef = useRef<HTMLElement | null>(null);
  const [todoTab, setTodoTab] = useState<TodoTab>("task"); // 「我的」下的二级导航
  const [feedback, setFeedback] = useState(false);
  // 由详情页 Chip ID 跳转新建时携带的预填数据
  const [createPrefill, setCreatePrefill] = useState<CreatePrefill | undefined>(undefined);
  // 首次进入自动弹出新手引导（localStorage 记忆）
  const [guideOpen, setGuideOpen] = useState(() => {
    try { return !localStorage.getItem(ONBOARDING_KEY); } catch { return true; }
  });
  // V1.0.2 更新说明：打开应用时自动弹出（已看过新手引导才弹，避免与引导叠加；本版本可勾选不再提示）
  const [whatsNew, setWhatsNew] = useState(() => {
    try {
      return !localStorage.getItem(WHATSNEW_KEY) && !!localStorage.getItem(ONBOARDING_KEY);
    } catch { return false; }
  });

  const active: PageKey =
    view.kind === "page"
      ? view.page
      : view.kind === "skill-management"
      ? "skills"
      : view.kind === "case" || view.kind === "create"
      ? "cases"
      : view.kind === "issue"
      ? "cases"
      : "todo";

  const goHome = () => setView({ kind: "page", page: "todo" });
  const goMyTasks = () => { setTodoTab("task"); setView({ kind: "page", page: "todo" }); };
  const goCases = () => setView({ kind: "page", page: "cases" });
  const goAgent = () => {
    if (view.kind !== "skill-management" && !(view.kind === "page" && (view.page === "skills" || view.page === "ai"))) agentReturnView.current = view;
    setView({ kind: "page", page: "skills" });
  };
  const returnAgentToWindow = () => {
    setView(agentReturnView.current);
    setAgentWindowRequest(value => value + 1);
  };
  const openCreateCase = () => {
    setCreatePrefill(undefined);
    setView({ kind: "page", page: "create", createEntry: "direct" });
  };
  const cancelCreateCase = () => {
    const taskId = createPrefill?.sourceStandaloneTaskIds?.[0];
    setCreatePrefill(undefined);
    setView(taskId ? { kind: "standalone-task", taskId } : { kind: "page", page: "cases" });
  };
  useEffect(() => {
    mainRef.current?.scrollTo({ top: 0, left: 0 });
  }, [view]);

  const breadcrumb = (() => {
    if (view.kind === "skill-management") return [
      { label: "EA 平台", onClick: goHome },
      { label: "EA Agent", onClick: goAgent },
      { label: "管理 Skill" },
    ];
    if (view.kind === "page") {
      const labels: Record<PageKey, string> = {
        todo: "我的",
        cases: "分析中心",
        products: "产品监控",
        issues: "Issue 库",
        manager: "团队看板",
        skills: "EA Agent",
        "skill-center": "技能中心",
        contest: "AI 创新大赛",
        create: "新建 Case",
        ai: "EA Agent",
        approvals: "我的审批",
        profile: "个人主页",
      };
      return [
        { label: "EA 平台", onClick: goHome },
        { label: labels[view.page] },
      ];
    }
    if (view.kind === "case") {
      const c = mockCases.find((x) => x.id === view.id);
      return [
        { label: "EA 平台", onClick: goHome },
        { label: "分析中心", onClick: goCases },
        { label: c?.code || "" },
      ];
    }
    if (view.kind === "issue") {
      return [
        { label: "EA 平台", onClick: goHome },
        { label: "分析中心", onClick: goCases },
        { label: "Issue 中心", onClick: () => setView({ kind: "page", page: "cases", casesView: "issue" }) },
        { label: "Issue 详情" },
      ];
    }
    if (view.kind === "create") {
      const c = mockCases.find((x) => x.id === view.caseId);
      if (view.mode === "edit" && view.caseId) {
        return [
          { label: "EA 平台", onClick: goHome },
          { label: "分析中心", onClick: goCases },
          { label: c?.code || "", onClick: () => setView({ kind: "case", id: view.caseId! }) },
          { label: "编辑 Case" },
        ];
      }
      if (view.caseId) {
        return [
          { label: "EA 平台", onClick: goHome },
          { label: "分析中心", onClick: goCases },
          { label: c?.code || "", onClick: () => setView({ kind: "case", id: view.caseId! }) },
          { label: view.mode === "upgrade" ? "Case 升级" : "审批复核" },
        ];
      }
      return [
        { label: "EA 平台", onClick: goHome },
        { label: "新建 Case" },
      ];
    }
    if (view.kind === "create-standalone-task") {
      return [
        { label: "EA 平台", onClick: goHome },
        { label: "我的任务", onClick: goMyTasks },
        { label: "新建自由任务" },
      ];
    }
    if (view.kind === "edit-standalone-task") return [
      { label: "EA 平台", onClick: goHome },
      { label: "我的任务", onClick: goMyTasks },
      { label: standaloneTaskById(view.taskId)?.code || "自由任务", onClick: () => setView({ kind: "standalone-task", taskId: view.taskId }) },
      { label: "编辑自由任务" },
    ];
    if (view.kind === "standalone-task") {
      const task = standaloneTaskById(view.taskId);
      return [
        { label: "EA 平台", onClick: goHome },
        { label: "我的", onClick: goHome },
        { label: task?.code || "自由任务" },
      ];
    }
    const c = mockCases.find((x) => x.id === view.caseId);
    const t = c?.tasks.find((x) => x.id === view.taskId);
    return [
      { label: "EA 平台", onClick: goHome },
      { label: "我的", onClick: goHome },
      { label: c?.code || "", onClick: () => setView({ kind: "case", id: view.caseId }) },
      { label: t?.title || "" },
    ];
  })();

  return (
    <div className="size-full flex bg-gradient-to-br from-slate-50 via-white to-slate-50 text-slate-800">
      <Sidebar
        active={active}
        onChange={(k) => k === "create" ? openCreateCase() : k === "skills" || k === "ai" ? goAgent() : setView({ kind: "page", page: k })}
        todoTab={todoTab}
        onTodoTab={setTodoTab}
      />
      <div className="flex-1 flex flex-col min-w-0">
        <TopBar
          breadcrumb={breadcrumb}
          onFeedback={() => setFeedback(true)}
          onGuide={() => setGuideOpen(true)}
          onWhatsNew={() => setWhatsNew(true)}
          onOpenCase={(id) => setView({ kind: "case", id })}
          onOpenTask={(caseId, taskId) => setView({ kind: "task", caseId, taskId })}
          onOpenStandaloneTask={(taskId) => setView({ kind: "standalone-task", taskId })}
          onOpenIssue={(id) => setView({ kind: "issue", id })}
          onCreateCase={openCreateCase}
          onCreateTask={() => { setTodoTab("task"); setView({ kind: "create-standalone-task" }); }}
        />
        <main ref={mainRef} className="flex-1 overflow-y-auto">
          {view.kind === "edit-standalone-task" && <EditStandaloneTask key={view.taskId} taskId={view.taskId} onCancel={() => setView({ kind: "standalone-task", taskId: view.taskId })} onSaved={task => setView({ kind: "standalone-task", taskId: task.id })} />}
          {view.kind === "create-standalone-task" && (
            <CreateStandaloneTask
              onCancel={goMyTasks}
              onCreated={(task) => { setTodoTab("task"); setView({ kind: "standalone-task", taskId: task.id }); }}
            />
          )}
          {view.kind === "page" && view.page === "todo" && todoTab === "recovery" && <RecoveryWorkbench onOpen={target => setView(target.kind === "case" ? { kind: "case", id: target.caseId } : target.kind === "task" ? { kind: "task", caseId: target.caseId, taskId: target.taskId } : { kind: "standalone-task", taskId: target.taskId })} />}
          {view.kind === "page" && view.page === "todo" && todoTab !== "recovery" && (
            <MyTodo
              tab={todoTab}
              onOpenCase={(id) => setView({ kind: "case", id })}
              onOpenTask={(caseId, taskId) => setView({ kind: "task", caseId, taskId })}
              onOpenStandaloneTask={(taskId) => setView({ kind: "standalone-task", taskId })}
              onOpenIssue={(id) => setView({ kind: "issue", id })}
            />
          )}
          {view.kind === "page" && view.page === "cases" && (
            <CaseList
              initialView={view.casesView}
              onOpenCase={(id) => setView({ kind: "case", id })}
              onOpenTask={(caseId, taskId) => setView({ kind: "task", caseId, taskId })}
              onOpenIssue={(id) => setView({ kind: "issue", id })}
            />
          )}
          {view.kind === "issue" && (
            <IssueCenter
              initialIssueId={view.id}
              onOpenCase={(id) => setView({ kind: "case", id })}
              onExit={() => setView({ kind: "page", page: "cases", casesView: "issue" })}
            />
          )}
          {view.kind === "page" && view.page === "profile" && (
            <ProfilePage
              onOpenCase={(id) => setView({ kind: "case", id })}
              onOpenTask={(caseId, taskId) => setView({ kind: "task", caseId, taskId })}
            />
          )}
          {view.kind === "page" && view.page === "manager" && (
            <ManagerView
              onOpenCase={(id) => setView({ kind: "case", id })}
              onOpenCases={() => setView({ kind: "page", page: "cases" })}
            />
          )}
          {view.kind === "page" && (view.page === "skills" || view.page === "ai") && (
            <EaAgentPage conversation={agentConversation} onOpenWindow={returnAgentToWindow} />
          )}
          {(view.kind === "skill-management" || (view.kind === "page" && view.page === "skill-center")) && (
            <SkillCenter onBackToAgent={goAgent} onSelectSkill={skill => { agentConversation.selectSkill(skill); goAgent(); }} />
          )}
          {view.kind === "page" && view.page === "contest" && (
            <ContestView />
          )}
          {view.kind === "page" && view.page === "create" && view.createEntry === "direct" && (
            <div className="relative min-h-full">
              <div className="sticky top-0 z-[70] flex h-12 items-center justify-end border-b border-slate-200 bg-white/95 px-8 backdrop-blur">
                <span className="mr-3 text-[11px] text-slate-400">新建页面版本</span>
                <div className="inline-flex items-center rounded-lg border border-slate-200 bg-slate-100 p-0.5">
                  <button type="button" onClick={() => setCreateVariant("lab")} className={`h-7 rounded-md px-3 text-xs transition-colors ${createVariant === "lab" ? "bg-white font-medium text-[#0052D9] shadow-sm" : "text-slate-500 hover:text-slate-700"}`}>创新版</button>
                  <button type="button" onClick={() => setCreateVariant("standard")} className={`h-7 rounded-md px-3 text-xs transition-colors ${createVariant === "standard" ? "bg-white font-medium text-[#0052D9] shadow-sm" : "text-slate-500 hover:text-slate-700"}`}>标准版</button>
                </div>
              </div>
              <div className={createVariant === "lab" ? "block" : "hidden"} aria-hidden={createVariant !== "lab"}>
                <CreateCaseLab
                  key={createPrefill?.sourceStandaloneTaskIds?.join(",") ?? "new-lab"}
                  prefill={createPrefill}
                  onDone={cancelCreateCase}
                  onCreated={(id) => { setCreatePrefill(undefined); setView({ kind: "case", id }); }}
                />
              </div>
              <div className={createVariant === "standard" ? "block" : "hidden"} aria-hidden={createVariant !== "standard"}>
                <CreateCase
                  key={createPrefill?.sourceStandaloneTaskIds?.join(",") ?? "new-standard"}
                  prefill={createPrefill}
                  onDone={cancelCreateCase}
                  onCreated={(id) => { setCreatePrefill(undefined); setView({ kind: "case", id }); }}
                />
              </div>
            </div>
          )}
          {view.kind === "page" && view.page === "create" && view.createEntry !== "direct" && (
            <CreateCase
              prefill={createPrefill}
              onDone={() => { setCreatePrefill(undefined); setView({ kind: "page", page: "cases" }); }}
              onCreated={(id) => { setCreatePrefill(undefined); setView({ kind: "case", id }); }}
            />
          )}
          {view.kind === "case" && (
            <CaseDetail
              key={view.id}
              caseId={view.id}
              onBack={() => setView({ kind: "page", page: "cases" })}
              onOpenTask={(caseId, taskId) => setView({ kind: "task", caseId, taskId })}
              onOpenStandaloneTask={(taskId) => setView({ kind: "standalone-task", taskId })}
              onOpenCase={(id) => setView({ kind: "case", id })}
              onUpgrade={(id) => setView({ kind: "create", mode: "upgrade", caseId: id })}
              onEdit={(id) => setView({ kind: "create", mode: "edit", caseId: id })}
              onOpenIssue={(id) => setView({ kind: "issue", id })}
              onCreateRelated={(p) => { setCreatePrefill(p); setView({ kind: "page", page: "create", createEntry: "related" }); }}
            />
          )}
          {view.kind === "create" && (
            <CreateCase
              mode={view.mode}
              initialCase={mockCases.find((x) => x.id === view.caseId)}
              onDone={() =>
                view.caseId
                  ? setView({ kind: "case", id: view.caseId })
                  : setView({ kind: "page", page: "cases" })
              }
            />
          )}
          {view.kind === "task" && (
            <TaskDetail
              caseId={view.caseId}
              taskId={view.taskId}
              onBack={() => setView({ kind: "page", page: "todo" })}
              onOpenCase={(id) => setView({ kind: "case", id })}
            />
          )}
          {view.kind === "standalone-task" && (
            <StandaloneTaskDetail
              key={view.taskId}
              taskId={view.taskId}
              onUpgrade={ids => { setCreatePrefill(prepareStandaloneTaskUpgrade(ids)); setView({ kind: "page", page: "create", createEntry: "direct" }); }}
              onEdit={taskId => setView({ kind: "edit-standalone-task", taskId })}
              onBack={() => { setTodoTab("task"); setView({ kind: "page", page: "todo" }); }}
              onOpenCase={(id) => setView({ kind: "case", id })}
            />
          )}
        </main>
      </div>
      <FeedbackPanel open={feedback} onClose={() => setFeedback(false)} />
      <Onboarding open={guideOpen} onClose={() => setGuideOpen(false)} />
      <WhatsNew open={whatsNew} onClose={() => setWhatsNew(false)} />
      <EaAgent conversation={agentConversation} onOpenPage={goAgent} openRequest={agentWindowRequest} suspended={guideOpen || whatsNew || feedback || view.kind === "skill-management" || (view.kind === "page" && (view.page === "skills" || view.page === "ai"))} />
    </div>
  );
}
