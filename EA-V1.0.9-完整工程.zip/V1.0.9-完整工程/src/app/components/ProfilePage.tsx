import {
  Crown,
  FolderKanban,
  CircleDot,
  CheckCircle2,
  Building2,
  Mail,
  MapPin,
  Trophy,
  Activity,
  Zap,
  CalendarClock,
  ListChecks,
  ChevronRight,
} from "lucide-react";
import { mockCases, currentUser, levelColors, urgencyBar, myTasksInCase } from "./data";
import { CaseProductPill } from "./CaseProductPill";

interface Props {
  onOpenCase: (id: string) => void;
  onOpenTask: (caseId: string, taskId: string) => void;
}

const dueLabel = (dueIn?: number) =>
  dueIn == null ? "—" : dueIn > 0 ? `${dueIn} 天到期` : dueIn === 0 ? "今日到期" : `已逾期 ${-dueIn} 天`;

type Tone = "emerald" | "amber" | "violet" | "blue" | "teal";
const TONE: Record<Tone, string> = {
  emerald: "bg-emerald-50 text-emerald-600",
  amber: "bg-amber-50 text-amber-600",
  violet: "bg-violet-50 text-violet-600",
  blue: "bg-[#0052D9]/8 text-[#0052D9]",
  teal: "bg-teal-50 text-teal-600",
};
const DOT: Record<Tone, string> = { emerald: "#16a34a", amber: "#d97706", violet: "#7c3aed", blue: "#0052D9", teal: "#0D9488" };

export function ProfilePage({ onOpenCase, onOpenTask }: Props) {
  const owned = mockCases.filter((c) => c.owner === currentUser.name);
  const mine = mockCases.flatMap((c) => myTasksInCase(c, currentUser.name).map((x) => ({ c, ...x })));
  const doneT = mine.filter((x) => x.task.status === "已完成");
  const doingT = mine.filter((x) => x.task.status === "进行中");
  const acceptT = mine.filter((x) => x.task.status === "待接受");
  const participating = mockCases.filter(
    (c) => c.owner !== currentUser.name && myTasksInCase(c, currentUser.name).length > 0
  );
  const keyOwned = owned.find((c) => c.level === "L0") || owned.find((c) => c.level === "L1") || owned[0];

  const stats: { label: string; value: string | number; icon: any; tone: Tone }[] = [
    { label: "我牵头的 Case", value: owned.length, icon: Crown, tone: "amber" },
    { label: "我参与的 Case", value: participating.length, icon: FolderKanban, tone: "blue" },
    { label: "进行中任务", value: doingT.length, icon: CircleDot, tone: "violet" },
    { label: "累计闭环率", value: "92%", icon: CheckCircle2, tone: "emerald" },
  ];

  const highlights: { icon: any; tone: Tone; text: string; meta: string }[] = [
    { icon: Trophy, tone: "amber", text: "攻克 DDR4 退货 8D D4 根因", meta: "锁定 PKG 内引线偏移 · 2026-06" },
    { icon: CheckCircle2, tone: "emerald", text: "本年累计完成 128 项任务", meta: "闭环率 92%，位列部门前 15%" },
    ...(keyOwned ? [{ icon: Crown as any, tone: "violet" as Tone, text: `牵头 ${keyOwned.level} Case「${keyOwned.name}」`, meta: "作为 Case Owner 持续跟进" }] : []),
    { icon: Zap, tone: "blue", text: "缩短 L1 平均响应时长 18%", meta: "沉淀退货失效分析 SOP" },
  ];

  const feed: { act: string; tone: Tone; title: string; time: string }[] = [];
  doneT.slice(0, 2).forEach((x, i) => feed.push({ act: "完成", tone: "emerald", title: x.task.title, time: i === 0 ? "今天 11:02" : "今天 09:18" }));
  doingT.slice(0, 1).forEach((x) => feed.push({ act: "推进", tone: "blue", title: x.task.title, time: "今天 14:30" }));
  acceptT.slice(0, 1).forEach((x) => feed.push({ act: "收到派单", tone: "teal", title: x.task.title, time: "今天 15:46" }));
  if (keyOwned) feed.push({ act: "更新", tone: "violet", title: `${keyOwned.name} 进展纪要`, time: "昨天 17:20" });

  return (
    <div className="relative">
      <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(ellipse_80%_50%_at_0%_0%,rgba(0,82,217,0.05),transparent_60%)]" />
      <div className="relative p-8 max-w-[1400px] mx-auto space-y-6">
        {/* 个人封面卡 */}
        <div className="relative overflow-hidden rounded-2xl border border-slate-200/80 bg-white shadow-[0_1px_2px_0_rgba(15,23,42,0.04)]">
          <div className="h-24 bg-gradient-to-r from-[#0052D9] to-[#00A4FF]" />
          <div className="px-7 pb-6">
            <div className="-mt-10 flex items-end gap-4">
              <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-[#00A4FF] to-[#0052D9] text-white grid place-items-center text-3xl font-bold ring-4 ring-white shadow-md shrink-0">
                {currentUser.avatar}
              </div>
              {/* 姓名 + 角色标签：仅占一行并与头像底对齐，确保落在白底而非蓝色头图之上 */}
              <div className="min-w-0 pb-1.5 flex items-center gap-2.5 flex-wrap">
                <h1 className="text-[22px] font-bold text-slate-900 tracking-tight leading-none">{currentUser.name}</h1>
                <span className="inline-flex items-center h-6 px-2.5 rounded-md text-[11px] font-medium leading-none text-[#0052D9] bg-[#0052D9]/[0.08] border border-[#0052D9]/20 whitespace-nowrap">{currentUser.role}</span>
              </div>
            </div>
            <div className="mt-3.5 text-[13px] text-slate-500 flex items-center gap-x-5 gap-y-1 flex-wrap">
              <span className="inline-flex items-center gap-1.5"><Building2 size={13} className="text-slate-400" /> {currentUser.department} 部门</span>
              <span className="inline-flex items-center gap-1.5"><Mail size={13} className="text-slate-400" /> zhangwei@ea-platform.com</span>
              <span className="inline-flex items-center gap-1.5"><MapPin size={13} className="text-slate-400" /> 上海 · 测试工程</span>
            </div>
          </div>
        </div>

        {/* 数据概览 */}
        <div className="grid grid-cols-4 gap-4">
          {stats.map((s) => {
            const Icon = s.icon;
            return (
              <div key={s.label} className="bg-white border border-slate-200/80 rounded-xl shadow-[0_1px_2px_0_rgba(15,23,42,0.04)] p-4 flex items-center gap-3.5">
                <span className={`w-11 h-11 rounded-xl grid place-items-center shrink-0 ${TONE[s.tone]}`}><Icon size={20} /></span>
                <div className="min-w-0">
                  <div className="text-[26px] font-extrabold tabular-nums leading-none text-slate-900">{s.value}</div>
                  <div className="text-[12px] text-slate-500 mt-1">{s.label}</div>
                </div>
              </div>
            );
          })}
        </div>

        {/* 主体：左 我牵头的 Case / 右 高光时刻 + 动态 */}
        <div className="grid grid-cols-[minmax(0,1fr)_340px] gap-5 items-start">
          {/* 左 */}
          <div className="space-y-4 min-w-0">
            <ListPanel title="我牵头的 Case" icon={Crown} count={owned.length} cases={owned} onOpenCase={onOpenCase} empty="暂无牵头的 Case" />
            <ListPanel title="我参与的 Case" icon={FolderKanban} count={participating.length} cases={participating} onOpenCase={onOpenCase} empty="暂无参与的 Case" />
          </div>

          {/* 右 */}
          <div className="space-y-4">
            <div className="bg-white border border-slate-200/80 rounded-xl shadow-[0_1px_2px_0_rgba(15,23,42,0.04)] overflow-hidden">
              <div className="px-4 h-11 flex items-center gap-2 border-b border-slate-100">
                <span className="w-6 h-6 rounded-md bg-amber-50 text-amber-500 grid place-items-center"><Trophy size={13} /></span>
                <span className="text-[13px] font-bold text-slate-800">我的高光时刻</span>
              </div>
              <div className="p-3.5 space-y-3">
                {highlights.map((h, i) => {
                  const Icon = h.icon;
                  return (
                    <div key={i} className="flex items-start gap-2.5">
                      <span className={`w-7 h-7 rounded-lg grid place-items-center shrink-0 ${TONE[h.tone]}`}><Icon size={14} /></span>
                      <div className="min-w-0 pt-0.5">
                        <div className="text-[12.5px] text-slate-700 leading-snug">{h.text}</div>
                        <div className="text-[11px] text-slate-400 mt-0.5">{h.meta}</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="bg-white border border-slate-200/80 rounded-xl shadow-[0_1px_2px_0_rgba(15,23,42,0.04)] overflow-hidden">
              <div className="px-4 h-11 flex items-center gap-2 border-b border-slate-100">
                <span className="w-6 h-6 rounded-md bg-[#0052D9]/8 text-[#0052D9] grid place-items-center"><Activity size={13} /></span>
                <span className="text-[13px] font-bold text-slate-800">近期动态</span>
              </div>
              <div className="p-4">
                <div className="relative pl-4">
                  <div className="absolute left-[5px] top-1.5 bottom-1.5 w-px bg-slate-100" />
                  <div className="space-y-3.5">
                    {feed.map((f, i) => (
                      <div key={i} className="relative">
                        <span className="absolute -left-[14px] top-1 w-2.5 h-2.5 rounded-full ring-2 ring-white" style={{ background: DOT[f.tone] }} />
                        <div className="text-[12.5px] leading-snug">
                          <b className="font-semibold" style={{ color: DOT[f.tone] }}>{f.act}</b>{" "}
                          <span className="text-slate-600">{f.title}</span>
                        </div>
                        <div className="text-[11px] text-slate-400 mt-0.5">{f.time}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function ListPanel({
  title,
  icon: Icon,
  count,
  cases,
  onOpenCase,
  empty,
}: {
  title: string;
  icon: any;
  count: number;
  cases: any[];
  onOpenCase: (id: string) => void;
  empty: string;
}) {
  return (
    <div className="bg-white border border-slate-200/80 rounded-xl shadow-[0_1px_2px_0_rgba(15,23,42,0.04)] overflow-hidden">
      <div className="px-4 h-11 flex items-center gap-2 border-b border-slate-100">
        <span className="w-6 h-6 rounded-md bg-slate-100 text-slate-500 grid place-items-center"><Icon size={13} /></span>
        <span className="text-[13px] font-bold text-slate-800">{title}</span>
        <span className="text-[11px] text-slate-400 tabular-nums">{count}</span>
      </div>
      {cases.length === 0 ? (
        <div className="py-10 text-center text-[12.5px] text-slate-400">{empty}</div>
      ) : (
        <div className="divide-y divide-slate-50">
          {cases.map((c) => (
            <button
              key={c.id}
              onClick={() => onOpenCase(c.id)}
              className="group relative w-full flex items-center gap-3 pl-4 pr-4 py-3 hover:bg-slate-50/60 transition-colors text-left"
            >
              <span className={`absolute left-0 top-2 bottom-2 w-[3px] rounded-r ${urgencyBar[c.urgency] || "bg-slate-300"}`} />
              <span className={`text-[10px] px-1.5 py-0.5 rounded border shrink-0 ${levelColors[c.level]}`}>{c.level}</span>
              <CaseProductPill caseItem={c} compact />
              <span className="flex-1 min-w-0 text-[13px] text-slate-800 truncate group-hover:text-[#0052D9] transition-colors">{c.name}</span>
              <span className="hidden lg:inline-flex items-center gap-1 text-[11px] text-slate-400 shrink-0"><ListChecks size={11} /> {c.tasks?.length ?? 0}</span>
              <span className="inline-flex items-center gap-1 text-[11px] text-slate-500 shrink-0 w-[88px] justify-end"><CalendarClock size={11} className="text-slate-400" /> {dueLabel(c.dueIn)}</span>
              <ChevronRight size={14} className="text-slate-300 group-hover:text-[#0052D9] shrink-0" />
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
