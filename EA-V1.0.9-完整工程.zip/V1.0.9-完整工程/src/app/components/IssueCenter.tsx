import { useMemo, useState } from "react";
import {
  ShieldAlert, ArrowLeft, Package, FileText, GitBranch, Send, CheckCircle2, X,
  Search, Layers, Users2, RefreshCw, Radar, Link2, ChevronRight, AlertTriangle, Plus,
  UserCheck, ClipboardCheck, RotateCcw, Check, Network, ListTree,
  MonitorPlay, Edit2, ShieldCheck, Bookmark, Share2, MessageSquare, FileSpreadsheet, Sparkles, Unlink,
} from "lucide-react";
import {
  Issue, IssueStatus, IssueSource, ObjectType,
  issueStatusColors, issueSourceColors, objectTypeColors, fanoutStatusColors,
  productById, mockCases, mockProducts, casesOfIssue, fanoutCoverage, issueAllCasesSolved,
  stageDefById, flattenTasks, FanoutStatus, OBJECT_TYPES,
  currentUser, TaskNode, CaseItem, EfaAnalysisCard, urgencyBar, levelColors,
} from "./data";
import {
  useIssues, aggregateCase, submitSolution, setFanoutStatus, syncRETs, createIssue,
  reviewIssue, distributeIssue, decideIssueChecklist, resolveIssueRootCause, closeIssue, detachCase,
} from "./domainStore";
import { MindMapFlow } from "./MindMapFlow";
import { CreateCaseWbsTable } from "./CreateCaseWbsTable";
import { AddTaskPayload } from "./AddTaskModal";
import type { ThoughtGroup, ActionCard } from "./CreateCase";
import { ProgressRing } from "./ProgressRing";
import { CaseCloudDocModal } from "./CaseDetail";
import { suggestRelatedCases } from "./caseInsights";
import { useSubscriptions } from "./subscriptions";
import { ProductPicker } from "./ProductPicker";

function Chip({ text, cls }: { text: string; cls: string }) {
  return <span className={`inline-flex items-center px-1.5 py-0.5 rounded text-[11px] border ${cls}`}>{text}</span>;
}

// 某 Fanout 验证 Case 的进度（任务平均完成度）；找不到 Case 或无任务时为 0。
function fanoutCaseProgress(caseId?: string): number {
  const c = caseId ? mockCases.find((x) => x.id === caseId) : undefined;
  if (!c) return 0;
  const actions = flattenTasks(c.tasks || []).map((x) => x.task).filter((t) => t.code);
  const base = actions.length ? actions : (c.tasks || []);
  return Math.round(base.reduce((s, t) => s + (t.progress || 0), 0) / Math.max(base.length, 1));
}

interface Props {
  initialIssueId?: string;
  onOpenCase: (id: string) => void;
  onExit?: () => void;
}

export function IssueCenter({ initialIssueId, onOpenCase, onExit }: Props) {
  const issues = useIssues();
  const [sel, setSel] = useState<string | undefined>(initialIssueId);
  const current = sel ? issues.find((i) => i.id === sel) : undefined;
  if (current) return <IssueDetail issue={current} onBack={onExit ?? (() => setSel(undefined))} onOpenCase={onOpenCase} onOpenIssue={setSel} />;
  return null; // 旧「Issue 库」列表已退休，Issue 列表统一由 IssueHub 承载
}

/* ================================ 详情 ================================ */
function IssueDetail({ issue, onBack, onOpenCase, onOpenIssue }: {
  issue: Issue; onBack: () => void; onOpenCase: (id: string) => void; onOpenIssue: (id: string) => void;
}) {
  const [aggOpen, setAggOpen] = useState(false);
  const [solOpen, setSolOpen] = useState(false);
  const [reviewOpen, setReviewOpen] = useState(false);
  const [checklistOpen, setChecklistOpen] = useState(false);
  const subs = useSubscriptions();
  const subscribed = subs.isSubscribed(issue.id);
  const cases = casesOfIssue(issue);
  const cov = fanoutCoverage(issue);
  // Fanout 进度：基于各 Fanout 验证 Case 的任务平均完成度
  const fanoutProgresses = issue.fanouts.map((f) => fanoutCaseProgress(f.spawnedCaseId));
  const fanoutAvg = fanoutProgresses.length ? Math.round(fanoutProgresses.reduce((a, b) => a + b, 0) / fanoutProgresses.length) : 0;
  const fanoutDone = fanoutProgresses.filter((p) => p >= 100).length;
  const allSolved = issueAllCasesSolved(issue);
  const products = issue.affectedProductIds.map((id) => productById(id)).filter(Boolean);
  const requester = issue.requester ?? issue.registeredBy ?? issue.kr ?? currentUser.name;
  const kr = issue.kr ?? products[0]?.owner ?? requester;
  const canSubmit = currentUser.name === kr || currentUser.name === requester;
  const canReview = currentUser.name === requester;
  const canDistribute = currentUser.name === requester || currentUser.name === kr;
  const canDecideChecklist = canDistribute;

  // Issue 由 Case 归集而来：从归集 Case 派生「共性（各 Case 一致）」与「差异（各 Case 不同）」
  const memberDims = useMemo(() => {
    const distinct = (fn: (c: any) => any) => Array.from(new Set(cases.map(fn).filter((v) => v && v !== "—"))) as string[];
    return [
      { label: "产品", vals: distinct((c) => productById(c.productId ?? c.product)?.code || c.product) },
      { label: "失效模式", vals: distinct((c) => c.failMode) },
      { label: "失效阶段", vals: distinct((c) => c.failStage) },
      { label: "封装", vals: distinct((c) => c.failPackage) },
      { label: "客户", vals: distinct((c) => c.customer) },
    ].filter((d) => d.vals.length > 0);
  }, [cases]);
  const commonDims = memberDims.filter((d) => d.vals.length === 1);
  const diffDims = memberDims.filter((d) => d.vals.length > 1);
  // Issue 进度：已给解题路径的归集 Case 占比
  const solvedCount = cases.filter((c) => c.solutionPath?.length).length;
  const solvedPct = cases.length ? Math.round((solvedCount / cases.length) * 100) : 0;
  // 结案两态：未归因→“找到根因”；已强制 Fanout 但未写结案→“结案”；已写结案→“已结案”
  const issueResolved = !!issue.distributedAt;
  const issueClosed = issue.status === "已结案" || !!issue.issueConclusion;
  // 更新时间：优先用显式 updatedAt，否则取已有时间戳中最晚的，兵底为 createdAt
  const issueUpdatedAt = issue.updatedAt
    ?? [issue.retsSyncedAt, issue.solvedAt, issue.distributedAt, issue.createdAt].filter(Boolean).sort().slice(-1)[0]
    ?? issue.createdAt;

  const solTitles = (caseId: string): string[] => {
    const c = mockCases.find((x) => x.id === caseId);
    if (!c || !c.solutionPath) return [];
    const idx: Record<string, string> = {};
    flattenTasks(c.tasks).forEach(({ task }) => { idx[task.id] = task.title; });
    return c.solutionPath.map((id) => idx[id]).filter(Boolean);
  };

  // —— Issue 思维导图 / 任务视图：用户自维护的任务树（本地状态，示范用；无固定流程） ——
  const [tasks, setTasks] = useState<TaskNode[]>(issue.tasks ?? []);
  const [tab, setTab] = useState<"mindmap" | "data">("mindmap");
  // 整体进度（同 Case：任务平均完成度）+ 距到期（按预期解决日期计算）
  const issueActionTasks = flattenTasks(tasks).map((x) => x.task).filter((t) => t.code);
  const overallBase = issueActionTasks.length ? issueActionTasks : tasks;
  const overallProgress = Math.round(overallBase.reduce((s, t) => s + (t.progress || 0), 0) / Math.max(overallBase.length, 1));
  const dueIn = issue.expectedResolveDate
    ? Math.ceil((new Date(issue.expectedResolveDate + "T00:00:00").getTime() - Date.now()) / 86400000)
    : null;
  const [rootCauseOpen, setRootCauseOpen] = useState(false);
  const [rootCauseText, setRootCauseText] = useState(issue.rootCause ?? "");
  // 强制 Fanout 的目标产品（默认全部其它产品，源/受影响产品自动排除）
  const otherProductIds = mockProducts.filter((p) => !issue.affectedProductIds.includes(p.id)).map((p) => p.id);
  const [fanoutTargetIds, setFanoutTargetIds] = useState<string[]>(otherProductIds);
  const [conclusionDocOpen, setConclusionDocOpen] = useState(false);
  const [aiRelOpen, setAiRelOpen] = useState(false);
  // AI 建议：以首个成员 Case 为锚点，推荐可归集的相似 Case（排除已在本 Issue 的）
  const relSuggestions = useMemo(() => {
    const anchor = cases[0];
    if (!anchor) return [];
    return suggestRelatedCases(anchor, mockCases).filter((s) => !issue.caseIds.includes(s.caseId));
  }, [cases, issue.caseIds]);
  const issueCaseStub = useMemo(
    () => ({
      id: issue.id, code: issue.code, name: issue.name,
      owner: kr, departments: [] as string[],
      product: issue.affectedProductIds[0], productIds: issue.affectedProductIds,
      background: issue.desc, tasks,
    }) as unknown as CaseItem,
    [issue, kr, tasks]
  );
  const insertTask = (parentId: string | null, t: TaskNode) => {
    if (parentId === null) { setTasks((prev) => [...prev, t]); return; }
    const insert = (nodes: TaskNode[]): TaskNode[] =>
      nodes.map((n) => n.id === parentId
        ? { ...n, children: [...(n.children ?? []), t] }
        : { ...n, children: n.children ? insert(n.children) : n.children });
    setTasks((prev) => insert(prev));
  };
  const submitTask = (parentId: string | null, p: AddTaskPayload): string => {
    const dateStr = new Date().toISOString().slice(2, 10).replace(/-/g, "").slice(0, 6);
    const code = p.kind === "执行任务" ? `EA-${dateStr}${String(Date.now()).slice(-6)}.001` : undefined;
    const newId = `t${Date.now()}`;
    insertTask(parentId, {
      id: newId, code, title: p.title, owner: p.assignee.trim() || "待指派",
      department: p.department, urgency: p.urgency, progress: 0, status: "待接受",
      dueDate: p.dueDate || undefined, type: p.type, category: p.category,
      voiceNote: p.voiceNote, attachments: p.attachments, note: p.note,
      supervisor: p.supervisor, site: p.site,
    });
    return newId;
  };
  const editTask = (id: string, p: AddTaskPayload) => {
    const apply = (nodes: TaskNode[]): TaskNode[] =>
      nodes.map((n) => n.id === id
        ? {
            ...n, title: p.title, expectation: p.expectation ?? n.expectation,
            owner: p.assignee.trim() || n.owner, department: p.department || n.department,
            urgency: p.urgency, dueDate: p.dueDate || n.dueDate,
            type: p.kind === "执行任务" ? p.type : n.type,
            coverageTestName: p.type === "Coverage上线" ? p.coverageTestName : undefined,
            coverageTestTime: p.type === "Coverage上线" ? p.coverageTestTime : undefined,
            coverageActionStage: p.type === "Coverage上线" ? p.coverageActionStage : undefined,
            coverageNtc: p.type === "Coverage上线" ? p.coverageNtc : undefined,
            efaAnalysis: p.efaAnalysis === undefined ? n.efaAnalysis : p.efaAnalysis ?? undefined,
            category: p.category ?? n.category, voiceNote: p.voiceNote ?? n.voiceNote,
            attachments: p.attachments ?? n.attachments, note: p.note ?? n.note,
            supervisor: p.supervisor ?? n.supervisor, site: p.site ?? n.site,
          }
        : { ...n, children: n.children ? apply(n.children) : n.children });
    setTasks((prev) => apply(prev));
  };
  const saveEfaAnalysis = (id: string, value: EfaAnalysisCard) => {
    const apply = (nodes: TaskNode[]): TaskNode[] =>
      nodes.map((n) => n.id === id ? { ...n, efaAnalysis: value } : { ...n, children: n.children ? apply(n.children) : n.children });
    setTasks((prev) => apply(prev));
  };
  const deleteTask = (id: string) => {
    const remove = (nodes: TaskNode[]): TaskNode[] =>
      nodes.filter((n) => n.id !== id).map((n) => ({ ...n, children: n.children ? remove(n.children) : n.children }));
    setTasks((prev) => remove(prev));
  };
  const findInList = (nodes: TaskNode[], id: string): TaskNode | undefined => {
    for (const n of nodes) { if (n.id === id) return n; if (n.children) { const r = findInList(n.children, id); if (r) return r; } }
    return undefined;
  };
  const cloneTask = (sourceId: string, targetParentId: string | null) => {
    const src = findInList(tasks, sourceId);
    if (!src) return;
    let counter = 0;
    const stamp = String(Date.now());
    const dateStr = new Date().toISOString().slice(2, 10).replace(/-/g, "").slice(0, 6);
    const clone = (n: TaskNode, isRoot: boolean): TaskNode => {
      counter += 1;
      const isAction = !!n.code;
      return {
        ...n, id: `t${stamp}_${counter}`,
        code: isAction ? `EA-${dateStr}${stamp.slice(-6)}.${String(counter).padStart(3, "0")}` : undefined,
        title: isRoot ? `${n.title}（副本）` : n.title,
        likes: 0, likedByMe: false, comments: [],
        children: n.children ? n.children.map((c) => clone(c, false)) : undefined,
      };
    };
    insertTask(targetParentId === "case" ? null : targetParentId, clone(src, true));
  };
  const taskTreeToThoughtGroups = (nodes: TaskNode[] | undefined): ThoughtGroup[] =>
    (nodes ?? []).map((group) => ({
      id: group.id, thought: group.title, category: group.category,
      actions: (group.children ?? []).map((action): ActionCard => ({
        id: action.id, title: action.title, expectation: action.expectation,
        urgency: action.urgency, department: action.department, supervisor: action.supervisor,
        assignee: action.owner === "待指派" ? "" : action.owner, dueDate: action.dueDate ?? "",
        note: action.note, voiceNote: action.voiceNote, attachments: action.attachments,
        type: action.type, efaAnalysis: action.efaAnalysis,
        childGroups: taskTreeToThoughtGroups(action.children),
      })),
    }));
  const detailThoughtGroups = useMemo(() => taskTreeToThoughtGroups(tasks), [tasks]);
  const groupsToTaskTree = (groups: ThoughtGroup[], existing: TaskNode[]): TaskNode[] => {
    const byId = new Map<string, TaskNode>();
    const index = (nodes: TaskNode[]) => nodes.forEach((n) => { byId.set(n.id, n); if (n.children) index(n.children); });
    index(existing);
    const dateStr = new Date().toISOString().slice(2, 10).replace(/-/g, "").slice(0, 6);
    const convThought = (g: ThoughtGroup): TaskNode => {
      const prev = byId.get(g.id);
      return { ...(prev ?? {}), id: g.id, title: g.thought, category: g.category, code: undefined,
        owner: prev?.owner ?? "待指派", department: prev?.department ?? "PTE", urgency: prev?.urgency ?? "一般",
        progress: prev?.progress ?? 0, status: prev?.status ?? "待接受", children: g.actions.map(convAction) } as TaskNode;
    };
    const convAction = (a: ActionCard): TaskNode => {
      const prev = byId.get(a.id);
      return { ...(prev ?? {}), id: a.id, code: prev?.code ?? `EA-${dateStr}${Math.random().toString().slice(2, 8)}.001`,
        title: a.title, expectation: a.expectation, owner: a.assignee?.trim() || "待指派", department: a.department,
        supervisor: a.supervisor, urgency: a.urgency, progress: prev?.progress ?? 0, status: prev?.status ?? "待接受",
        dueDate: a.dueDate || undefined, note: a.note, voiceNote: a.voiceNote, attachments: a.attachments,
        type: a.type, efaAnalysis: a.efaAnalysis, children: a.childGroups?.length ? a.childGroups.map(convThought) : undefined } as TaskNode;
    };
    return groups.map(convThought);
  };

  return (
    <div className="p-6 max-w-[1280px] mx-auto">
      <button onClick={onBack} className="inline-flex items-center gap-1 text-sm text-slate-500 hover:text-slate-800 mb-3">
        <ArrowLeft size={15} /> 返回 Issue 中心
      </button>

      <div className="grid grid-cols-[1fr_300px] gap-4 items-start">
        {/* 左：主卡 + 描述 / 根因 / 解决方案 / 相关 Case */}
        <div className="space-y-4 min-w-0">
          {/* 主卡：编号 + 操作 + 标题 + 徽章 */}
          <div className="bg-white border border-slate-200 rounded-lg p-5">
            <div className="flex items-center justify-between gap-4">
              <span className="font-mono text-xs text-slate-500">{issue.code}</span>
              <div className="flex flex-nowrap items-center gap-2 shrink-0">
                {/* 演示 */}
                <button title="演示模式（汇报放映）"
                  className="h-8 px-3 text-sm rounded-md border border-slate-200 bg-white text-slate-600 hover:border-[#0052D9]/40 hover:text-[#0052D9] hover:bg-[#0052D9]/5 flex items-center gap-1.5 transition-all">
                  <MonitorPlay size={14} /> 演示
                </button>
                {/* 编辑 */}
                <button title="编辑 Issue"
                  className="h-8 px-3 text-sm rounded-md border border-[#0052D9]/30 bg-white text-[#0052D9] hover:bg-[#0052D9]/5 flex items-center gap-1.5 transition-all">
                  <Edit2 size={14} /> 编辑
                </button>
                {/* 结案（两态：找到根因 → 强制 Fanout；再点结案 → 填写结案内容） */}
                {!issueResolved ? (
                  <button onClick={() => { setRootCauseText(issue.rootCause ?? ""); setFanoutTargetIds(otherProductIds); setRootCauseOpen(true); }} title="填写根因并强制 Fanout"
                    className="h-8 px-3 text-sm rounded-md border bg-white text-[#00B578] border-[#00B578]/40 hover:bg-[#00B578]/5 flex items-center gap-1.5 transition-all">
                    <ShieldCheck size={14} /> 找到根因
                  </button>
                ) : !issueClosed ? (
                  <button onClick={() => setConclusionDocOpen(true)} title="填写结案内容"
                    className="h-8 px-3 text-sm rounded-md border bg-white text-[#00B578] border-[#00B578]/40 hover:bg-[#00B578]/5 flex items-center gap-1.5 transition-all">
                    <ShieldCheck size={14} /> 结案
                  </button>
                ) : (
                  <button disabled title="已结案"
                    className="h-8 px-3 text-sm rounded-md border bg-emerald-50 text-emerald-700 border-emerald-300 cursor-not-allowed flex items-center gap-1.5">
                    <ShieldCheck size={14} /> 已结案
                  </button>
                )}

                {/* 分隔 */}
                <span className="w-px h-5 bg-slate-200 mx-0.5" />

                {/* 订阅 */}
                <button onClick={() => subs.toggle(issue.id)}
                  title={subscribed ? "已订阅 · 点击取消" : "订阅此 Issue"}
                  className={`h-8 w-8 rounded-md border flex items-center justify-center transition-all ${
                    subscribed ? "bg-[#0052D9]/8 text-[#0052D9] border-[#0052D9]/30" : "bg-white text-slate-700 border-slate-200 hover:border-[#0052D9]/40"
                  }`}>
                  {subscribed ? <Bookmark size={15} fill="currentColor" /> : <Bookmark size={15} />}
                </button>
                {/* 分享 */}
                <button title="分享链接"
                  className="h-8 w-8 rounded-md border border-slate-200 text-slate-700 bg-white hover:bg-slate-50 flex items-center justify-center transition-all">
                  <Share2 size={15} />
                </button>
                {/* 评论 */}
                <button title="Issue 评论"
                  className="h-8 w-8 rounded-md border border-slate-200 text-slate-700 bg-white hover:border-[#0052D9]/40 hover:text-[#0052D9] flex items-center justify-center transition-all">
                  <MessageSquare size={15} />
                </button>
              </div>
            </div>

            <div className="mt-2">
              <h1 className="text-slate-900">{issue.name}</h1>
            </div>

            {/* 归集背景 + 影响范围（Issue 由 Case 归集而来，体现共性背景） */}
            <div className="mt-4 grid grid-cols-2 gap-4">
              <div>
                <div className="text-xs font-medium text-slate-500 mb-1">共性背景（What &amp; Why）</div>
                <p className="text-sm text-slate-700 leading-relaxed">{issue.desc || <span className="text-slate-400">—</span>}</p>
              </div>
              <div>
                <div className="text-xs font-medium text-slate-500 mb-1">影响范围</div>
                <div className="text-sm text-slate-700">由 <b>{cases.length}</b> 个 Case 归集 · 影响 <b>{products.length}</b> 个产品</div>
              </div>
            </div>

            {/* 归集 Case 的共性 / 差异 */}
            {cases.length > 0 && (
              <div className="mt-4 rounded-lg border border-slate-100 bg-slate-50/60 p-3">
                <div className="flex items-center gap-1.5 mb-2">
                  <Layers size={13} className="text-slate-400" />
                  <span className="text-xs font-medium text-slate-500">归集 Case 的共性与差异</span>
                  <span className="text-[11px] text-slate-400">来自 {cases.length} 个 Case</span>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-[11px] text-emerald-600 mb-1.5">共性 · 各 Case 一致</div>
                    <div className="flex flex-wrap gap-1">
                      {commonDims.length > 0 ? commonDims.map((d) => (
                        <span key={d.label} className="text-[11px] px-1.5 py-0.5 rounded bg-emerald-50 border border-emerald-200 text-emerald-700">{d.label}：{d.vals[0]}</span>
                      )) : <span className="text-[11px] text-slate-400">暂无一致维度</span>}
                    </div>
                  </div>
                  <div>
                    <div className="text-[11px] text-amber-600 mb-1.5">差异 · 各 Case 不同</div>
                    <div className="flex flex-wrap gap-1">
                      {diffDims.length > 0 ? diffDims.map((d) => (
                        <span key={d.label} className="text-[11px] px-1.5 py-0.5 rounded bg-amber-50 border border-amber-200 text-amber-700">{d.label}：{d.vals.join(" / ")}</span>
                      )) : <span className="text-[11px] text-slate-400">各 Case 无明显差异</span>}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* 分析过程与结论（复用 Case 的结论/过程记录） */}
          <div onClick={() => setConclusionDocOpen(true)}
            className="group cursor-pointer rounded-xl border border-slate-200 bg-white p-4 hover:border-[#0052D9]/40 hover:shadow-sm transition-all">
            <div className="flex items-center gap-2.5">
              <span className="w-8 h-8 rounded-lg bg-[#0052D9]/8 text-[#0052D9] flex items-center justify-center shrink-0"><FileSpreadsheet size={16} /></span>
              <div className="min-w-0">
                <div className="text-sm text-slate-800 font-medium">分析过程与结论</div>
                <div className="text-[11px] text-slate-400">现象 → 假设 → 验证 → 结论 · 支持富文本 / 图表 / 附件</div>
              </div>
              <span className="ml-auto shrink-0 text-[11px] text-slate-400 group-hover:text-[#0052D9] inline-flex items-center gap-0.5">进入 Workspace 编辑 <ChevronRight size={13} /></span>
            </div>
            <div className="mt-2.5 rounded-lg bg-slate-50/70 border border-slate-100 px-3 py-2.5">
              <div className="text-xs text-slate-600 leading-relaxed line-clamp-2">
                {issue.issueConclusion || <span className="text-slate-400">暂无结论，点击撰写分析过程与结论。</span>}
              </div>
            </div>
          </div>

          {/* 相关 Case —— 复用关联 Case 组件的样式/交互（行为=归集成员 Case） */}
          <Section title={`相关 Case（${cases.length}）`} icon={Link2}
            action={
              <div className="flex items-center gap-2.5">
                <button onClick={() => setAiRelOpen((o) => !o)} className="text-[11px] text-[#7A3DFF] hover:underline inline-flex items-center gap-0.5">
                  <Sparkles size={12} /> AI 建议{relSuggestions.length ? `（${relSuggestions.length}）` : ""}
                </button>
                <button onClick={() => setAggOpen(true)} className="text-[11px] text-[#0052D9] hover:underline inline-flex items-center gap-0.5"><Plus size={12} /> 添加</button>
              </div>
            }>
            {/* AI 建议：可归集的相似 Case */}
            {aiRelOpen && (
              <div className="mb-3 grid grid-cols-2 gap-2.5">
                {relSuggestions.length === 0 && <div className="text-xs text-slate-400">暂无更多可归集的相似 Case。</div>}
                {relSuggestions.map((s) => {
                  const sc = mockCases.find((x) => x.id === s.caseId)!;
                  return (
                    <div key={s.caseId} className="relative overflow-hidden rounded-lg border border-slate-200/90 bg-white px-3.5 py-2.5 hover:border-[#0052D9]/35 hover:shadow-[0_5px_16px_-10px_rgba(0,82,217,0.28)] transition-all">
                      <span aria-hidden="true" className={`absolute left-0 top-3 bottom-3 w-0.5 rounded-r ${urgencyBar[sc.urgency]}`} />
                      <div className="flex items-center gap-1.5 pl-0.5">
                        <span className={`px-1 py-0.5 rounded text-[9px] leading-none border shrink-0 ${levelColors[sc.level]}`}>{sc.level}</span>
                        <span className="font-mono text-[9.5px] text-slate-300 truncate">{sc.code}</span>
                        <span className="ml-auto text-[9.5px] text-slate-400 whitespace-nowrap shrink-0">相似度 {Math.round(s.score * 100)}%</span>
                        <button onClick={() => aggregateCase(issue.id, s.caseId)} title="归集到本 Issue"
                          className="shrink-0 h-6 px-2 rounded-md border border-[#0052D9]/25 text-[#0052D9] text-[10px] hover:bg-[#0052D9]/5">归集</button>
                      </div>
                      <button onClick={() => onOpenCase(sc.id)} className="mt-1.5 block w-full text-left text-[12px] leading-snug font-medium text-slate-800 hover:text-[#0052D9] truncate">{sc.name}</button>
                      <div className="mt-1 text-[10px] leading-relaxed text-slate-500 line-clamp-2"><span className="font-medium text-slate-600">判断依据：</span>{s.reason}</div>
                    </div>
                  );
                })}
              </div>
            )}
            {/* 已归集成员 Case（pill 样式） */}
            <div className="flex flex-wrap gap-1.5">
              {cases.map((c) => {
                const prod = productById(c.productId ?? c.product);
                return (
                  <span key={c.id} className="inline-flex items-center gap-1.5 rounded-md border border-slate-200 bg-slate-50 pl-2 pr-1.5 py-1">
                    <button onClick={() => onOpenCase(c.id)} className="inline-flex items-center gap-1.5 min-w-0 hover:opacity-80">
                      <span className="font-mono text-[10px] text-slate-300">{c.code}</span>
                      <span className="text-xs text-slate-800 truncate max-w-[220px]">{c.name}</span>
                      {prod && <span className="text-[10px] px-1 py-0.5 rounded bg-white border border-slate-200 text-slate-500">{prod.code}</span>}
                    </button>
                    <button onClick={() => detachCase(issue.id, c.id)} title="从本 Issue 移除" className="text-slate-300 hover:text-red-500"><Unlink size={11} /></button>
                  </span>
                );
              })}
              {cases.length === 0 && <div className="text-xs text-slate-400">尚未归集 Case。可手动添加，或用 AI 建议发现相似 Case。</div>}
            </div>
          </Section>
        </div>

        {/* 右：概览进度 + 产品 & KR + Fanout + RETs */}
        <div className="space-y-4">
          {/* 概览 / 进度信息（对齐 Case 详情页右栏） */}
          <div className="rounded-xl border border-slate-200 bg-white p-4">
            <div className="flex items-center gap-1.5 flex-wrap">
              <Chip text={issue.source} cls={issueSourceColors[issue.source]} />
              {issue.domain && <Chip text={issue.domain} cls="bg-blue-50 text-blue-600 border-blue-200" />}
              {issue.problemType && <Chip text={issue.problemType} cls="bg-slate-50 text-slate-500 border-slate-200" />}
              <Chip text={issue.status} cls={issueStatusColors[issue.status]} />
              {issue.retsSynced && <Chip text="RETs ✓" cls="bg-[#7A3DFF]/8 text-[#7A3DFF] border-[#7A3DFF]/20" />}
            </div>
            <div className="flex items-center gap-3 mt-4">
              <ProgressRing value={overallProgress} size={48} stroke={5} />
              <div>
                <div className="text-[11px] text-slate-400">整体进度 {overallProgress}%</div>
                <div className="text-xs text-slate-700 font-medium mt-0.5">
                  {dueIn === null
                    ? <span className="text-slate-400">未设预期日期</span>
                    : <>距到期 <span className={dueIn <= 3 ? "text-[#FF3B30]" : "text-slate-700"}>{dueIn} 天</span></>}
                </div>
              </div>
            </div>
            <div className="mt-4 pt-3.5 border-t border-slate-100">
              <div className="text-[11px] text-slate-400 mb-1.5">受影响产品 & KR（{products.length}）</div>
              <div className="space-y-1.5">
                {products.map((p) => (
                  <div key={p!.id} className="flex items-center justify-between gap-2 rounded-md border border-slate-200 bg-slate-50/60 px-2.5 py-1.5">
                    <div className="min-w-0">
                      <div className="text-xs text-slate-700 truncate">{p!.code}</div>
                      <div className="text-[10px] text-slate-400 truncate">{stageDefById(p!.currentStageId).name}</div>
                    </div>
                    <div className="shrink-0 inline-flex items-center gap-1 text-[11px] text-slate-600">
                      <span className="w-5 h-5 rounded-full bg-gradient-to-br from-[#7A3DFF] to-[#00A4FF] text-white flex items-center justify-center text-[9px]">{(p!.owner || "?").slice(0, 1)}</span>
                      {p!.owner || "—"}
                    </div>
                  </div>
                ))}
                {products.length === 0 && <div className="text-xs text-slate-400">暂无受影响产品</div>}
              </div>
            </div>
            <div className="mt-4 pt-3.5 border-t border-slate-100 flex flex-col gap-2.5 text-xs">
              <div className="flex items-center justify-between gap-2">
                <span className="text-slate-400">创建者</span>
                <span className="text-slate-700">{requester}</span>
              </div>
            </div>
            <div className="mt-3.5 pt-3.5 border-t border-slate-100 flex flex-col gap-2 text-[11px] text-slate-400">
              <div className="flex items-center justify-between"><span>创建</span><span className="text-slate-500">{issue.createdAt}</span></div>
              <div className="flex items-center justify-between"><span>更新</span><span className="text-slate-500">{issueUpdatedAt}</span></div>
              {issue.expectedResolveDate && <div className="flex items-center justify-between"><span>预期解决</span><span className="text-slate-500">{issue.expectedResolveDate}</span></div>}
              {issue.solvedAt && <div className="flex items-center justify-between"><span>解决</span><span className="text-slate-500">{issue.solvedAt}</span></div>}
            </div>
          </div>

          <Section title="Fanout 进度" icon={Radar}
            action={issue.fanouts.length ? <span className="text-xs text-slate-500">{fanoutDone}/{issue.fanouts.length} 完成 · 均 {fanoutAvg}%</span> : undefined}>
            {issue.fanouts.length === 0
              ? <p className="text-xs text-slate-400 leading-relaxed">点击顶部「找到根因」填写根因并选择目标产品后，系统<b className="text-slate-500">强制 Fanout</b>：为选中的每个产品各建 1 个「Fanout 验证」Case 并推送对应负责人。</p>
              : <>
                  <div className="h-1.5 rounded-full bg-slate-100 overflow-hidden mb-2">
                    <div className="h-full bg-emerald-400" style={{ width: `${fanoutAvg}%` }} />
                  </div>
                  <div className="space-y-1.5 max-h-[280px] overflow-y-auto pr-1">
                    {issue.fanouts.map((f) => {
                      const p = productById(f.targetProductId);
                      const prog = fanoutCaseProgress(f.spawnedCaseId);
                      return (
                        <div key={f.targetProductId} className="flex items-center gap-2 text-xs">
                          <div className="flex-1 min-w-0">
                            <div className="text-slate-700 truncate">{p?.code} <span className="text-slate-400">· {f.targetOwner}</span></div>
                            {f.spawnedCaseId ? (
                              <button onClick={() => onOpenCase(f.spawnedCaseId!)} className="font-mono text-[10px] text-[#0052D9] hover:underline">{f.spawnedCaseCode}</button>
                            ) : (
                              <div className="font-mono text-[10px] text-slate-400">{f.spawnedCaseCode}</div>
                            )}
                          </div>
                          <span className="shrink-0 inline-flex items-center gap-1" title={`Case 任务平均完成度 ${prog}%`}>
                            <ProgressRing value={prog} size={18} stroke={2.5} />
                            <span className="text-[10px] text-slate-500 tabular-nums w-8 text-right">{prog}%</span>
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </>}
          </Section>
        </div>
      </div>

      {/* 思维导图 / 任务视图 —— 用户自维护的分析任务树 */}
      <div className="mt-4 bg-white border border-slate-200 rounded-lg">
        <div className="border-b border-slate-100 px-2 flex items-center">
          {([{ key: "mindmap", label: "思维导图", icon: Network }, { key: "data", label: "任务视图", icon: ListTree }] as const).map((t) => {
            const Icon = t.icon;
            const active = t.key === tab;
            return (
              <button
                key={t.key}
                onClick={() => setTab(t.key)}
                className={`px-3 py-2.5 text-sm flex items-center gap-1.5 border-b-2 transition-colors ${
                  active ? "border-[#0052D9] text-[#0052D9]" : "border-transparent text-slate-600 hover:text-slate-900"
                }`}
              >
                <Icon size={14} /> {t.label}
              </button>
            );
          })}
        </div>
        <div className="p-4">
          {tab === "mindmap" && (
            <MindMapFlow
              caseItem={issueCaseStub}
              tasks={tasks}
              onAddChild={submitTask}
              onEditTask={editTask}
              onSaveEfa={saveEfaAnalysis}
              onDelete={deleteTask}
              onClone={cloneTask}
            />
          )}
          {tab === "data" && (
            <CreateCaseWbsTable
              caseData={issueCaseStub}
              thoughtGroups={detailThoughtGroups}
              onGroupsChange={(groups) => setTasks(groupsToTaskTree(groups, tasks))}
            />
          )}
        </div>
      </div>

      {aggOpen && <AggregateModal issue={issue} onCancel={() => setAggOpen(false)} onDone={() => setAggOpen(false)} />}
      {solOpen && <SolutionModal issue={issue} onCancel={() => setSolOpen(false)} onDone={() => setSolOpen(false)} />}
      {reviewOpen && <ReviewModal issue={issue} requester={requester} onCancel={() => setReviewOpen(false)} onDone={() => setReviewOpen(false)} />}
      {checklistOpen && <ChecklistDecisionModal issue={issue} onCancel={() => setChecklistOpen(false)} onDone={() => setChecklistOpen(false)} />}

      {/* 结案第一步：找到根因 + 强制 Fanout */}
      {rootCauseOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40" onClick={() => setRootCauseOpen(false)}>
          <div className="w-[540px] bg-white rounded-lg shadow-xl border border-slate-200 p-5" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center gap-2 mb-3">
              <AlertTriangle size={16} className="text-[#7A3DFF]" />
              <h3 className="text-slate-900">找到根因</h3>
              <button onClick={() => setRootCauseOpen(false)} className="ml-auto text-slate-400 hover:text-slate-600"><X size={16} /></button>
            </div>
            <p className="text-xs text-slate-500 mb-2">填写本 Issue 的根因；确定后将<b className="text-[#00B578]">强制 Fanout</b>——为下方选中的每个产品各建 1 个「Fanout 验证」Case 并推送对应负责人。</p>
            <label className="block text-xs text-slate-600">根因
              <textarea value={rootCauseText} onChange={(e) => setRootCauseText(e.target.value)} autoFocus
                placeholder="如：Pattern timing margin 不足 + 边缘 die 工艺漂移"
                className="mt-1 w-full min-h-[90px] p-2.5 text-sm rounded border border-slate-200 outline-none focus:border-[#0052D9] leading-relaxed" />
            </label>
            <div className="mt-3">
              <div className="flex items-center gap-1.5 text-xs text-slate-600">
                <Radar size={13} className="text-[#00B578]" /> Fanout 目标产品
                <span className="text-slate-400">（已默认选中全部其它产品，可增删；本 Issue 受影响产品已自动排除）</span>
                <span className="ml-auto text-slate-400">已选 {fanoutTargetIds.length} 个</span>
              </div>
              <div className="mt-1.5">
                <ProductPicker multiple value={fanoutTargetIds} onChange={setFanoutTargetIds}
                  excludeIds={issue.affectedProductIds} placeholder="选择一个或多个产品" triggerClassName="min-h-[52px]" />
              </div>
            </div>
            <div className="flex items-center justify-end gap-2 pt-3 mt-3 border-t border-slate-100">
              <button onClick={() => setRootCauseOpen(false)} className="h-8 px-3 text-sm rounded-md border border-slate-200 text-slate-600 hover:bg-slate-50">取消</button>
              <button disabled={rootCauseText.trim().length < 2 || fanoutTargetIds.length === 0}
                onClick={() => { resolveIssueRootCause(issue.id, rootCauseText.trim(), currentUser.name, fanoutTargetIds); setRootCauseOpen(false); }}
                className="h-8 px-3.5 text-sm rounded-md bg-[#00B578] text-white hover:bg-[#009d68] disabled:opacity-40 inline-flex items-center gap-1">
                <Radar size={13} /> 确定并强制 Fanout
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 结案第二步：填写结案内容（复用 Case 的结论/过程/附件文档） */}
      {conclusionDocOpen && (
        <CaseCloudDocModal
          caseItem={issueCaseStub}
          initialConclusion={issue.issueConclusion ?? ""}
          initialProcess={issue.issueProcess ?? ""}
          initialAttachments={issue.issueAttachments ?? []}
          onClose={() => setConclusionDocOpen(false)}
          onSave={(payload) => { closeIssue(issue.id, payload, currentUser.name); setConclusionDocOpen(false); }}
        />
      )}
    </div>
  );
}

function IssueRoleChain({ issue, requester, kr }: { issue: Issue; requester: string; kr: string }) {
  const steps = [
    { title: "提出 Issue", owner: requester, done: true, active: !issue.solution },
    { title: "KR 分析解决", owner: kr, done: !!issue.solution, active: !issue.solution },
    { title: "requester Review", owner: requester, done: issue.reviewResult === "通过", active: issue.status === "已准备好解决方案", rejected: issue.reviewResult === "打回" },
    { title: "结案 Fanout", owner: "系统自动", done: !!issue.distributedAt, active: issue.reviewResult === "通过" && !issue.distributedAt },
    { title: "Checklist 决策", owner: "requester / KR", done: !!issue.checklistDecisionBy, active: !!issue.distributedAt && !issue.checklistDecisionBy },
  ];
  return (
    <div className="mt-4 rounded-xl border border-slate-100 bg-slate-50/60 px-4 py-3">
      <div className="flex items-start">
        {steps.map((step, index) => (
          <div key={step.title} className="relative flex-1 min-w-0 text-center">
            {index > 0 && <div className={`absolute top-3 right-1/2 w-full h-0.5 ${steps[index - 1].done ? "bg-emerald-300" : "bg-slate-200"}`} />}
            <div className={`relative z-10 mx-auto w-6 h-6 rounded-full border-2 flex items-center justify-center ${
              step.rejected ? "bg-red-50 border-red-400 text-red-500" :
              step.done ? "bg-emerald-500 border-emerald-500 text-white" :
              step.active ? "bg-white border-[#0052D9] text-[#0052D9] ring-4 ring-blue-100" :
              "bg-white border-slate-300 text-slate-300"
            }`}>
              {step.done ? <Check size={12} strokeWidth={3} /> : step.rejected ? <RotateCcw size={11} /> : <span className="text-[10px] font-semibold">{index + 1}</span>}
            </div>
            <div className={`mt-1.5 text-[11px] font-medium ${step.active ? "text-[#0052D9]" : step.done ? "text-slate-700" : "text-slate-400"}`}>{step.title}</div>
            <div className="mt-0.5 text-[10px] text-slate-400 truncate px-1">{step.owner}</div>
          </div>
        ))}
      </div>
      {issue.reviewResult === "打回" && <div className="mt-2 text-[11px] text-red-600 text-center">requester 已打回，等待 KR 修改解决方案后重新提交。</div>}
      {issue.checklistDecisionBy && <div className="mt-2 text-[11px] text-center text-slate-500">Checklist 决策：<b className={issue.inChecklist ? "text-emerald-600" : "text-slate-600"}>{issue.inChecklist ? `加入 · ${issue.backwriteDefTitle}` : "本次不加入"}</b> · {issue.checklistDecisionBy}</div>}
    </div>
  );
}

function Section({ title, icon: Icon, action, children }: { title: string; icon: any; action?: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4">
      <div className="flex items-center gap-1.5 mb-2.5">
        <Icon size={14} className="text-slate-400" />
        <h3 className="text-sm text-slate-800">{title}</h3>
        {action && <div className="ml-auto">{action}</div>}
      </div>
      {children}
    </div>
  );
}

function SourceChain({ issue }: { issue: Issue }) {
  const step = (t: string) => <span className="px-2 py-1 rounded bg-slate-50 border border-slate-200 text-xs text-slate-600">{t}</span>;
  const arrow = <ChevronRight size={13} className="text-slate-300 shrink-0" />;
  let chain: React.ReactNode = null;
  if (issue.source === "检查项Fail") {
    chain = <>{step("产品 Checklist")}{arrow}{step("检查项 Fail")}{arrow}{step("自动冒泡 Issue")}</>;
  } else if (issue.source === "MC·WBS") {
    chain = <>{step("MC · AVL 填 WBS（ES~CS）")}{arrow}{step("WBS ⇄ EA 接口")}{arrow}{step("生成 Case")}{arrow}{step("人工归集 Issue")}</>;
  } else if (issue.source === "SC·FAE") {
    chain = <>{step("SC · FAE")}{arrow}{step(issue.fieldSystem || "（待命名）现场系统")}{arrow}{step("SAE 部门建 Case")}{arrow}{step("人工归集 Issue")}</>;
  } else if (issue.source === "Q·FAQA") {
    chain = <>{step("Q · FAQA（CS 后 / MP）")}{arrow}{step("直接提报 Issue")}</>;
  } else {
    chain = <>{step("人工新建 Issue")}</>;
  }
  return (
    <div className="space-y-2">
      <div className="flex items-center gap-1.5 flex-wrap">{chain}</div>
      {(issue.customer || issue.registeredBy) && (
        <div className="text-xs text-slate-500">
          {issue.customer && <>客户：<b className="text-slate-700">{issue.customer}</b>　</>}
          {issue.registeredBy && <>登记：<b className="text-slate-700">{issue.registeredBy}</b></>}
        </div>
      )}
      {issue.memberFails.length > 0 && (
        <div className="mt-1 space-y-1">
          <div className="text-[11px] text-slate-400">来源检查项 Fail：</div>
          {issue.memberFails.map((m, k) => (
            <div key={k} className="text-xs text-slate-600 flex items-center gap-1.5">
              <AlertTriangle size={11} className="text-red-500" />
              {productById(m.productId)?.code} · {m.title}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function FanoutControl({ issueId, f }: { issueId: string; f: { targetProductId: string; status: FanoutStatus } }) {
  const next: Record<FanoutStatus, FanoutStatus | null> = { 待验证: "验证中", 验证中: "已验证", 已验证: null, 不适用: null };
  const n = next[f.status];
  return (
    <div className="flex items-center gap-1 shrink-0">
      <Chip text={f.status} cls={fanoutStatusColors[f.status]} />
      {n && (
        <button onClick={() => setFanoutStatus(issueId, f.targetProductId, n)}
          className="text-[10px] px-1.5 py-0.5 rounded border border-slate-200 text-slate-500 hover:border-[#0052D9] hover:text-[#0052D9]">
          → {n}
        </button>
      )}
    </div>
  );
}

/* ============================== 弹窗：归集 Case ============================== */
function AggregateModal({ issue, onCancel, onDone }: { issue: Issue; onCancel: () => void; onDone: () => void }) {
  const [pick, setPick] = useState<string>("");
  const candidates = mockCases.filter((c) => !issue.caseIds.includes(c.id));
  return (
    <Modal title="归集 Case 到 Issue" onCancel={onCancel}>
      <p className="text-xs text-slate-500">把来源②③（MC·WBS / SC·FAE）形成的 Case 人工归集到本 Issue，一处统一调查。</p>
      <div className="max-h-[320px] overflow-y-auto mt-2 space-y-1">
        {candidates.map((c) => {
          const prod = productById(c.productId ?? c.product);
          return (
            <label key={c.id} className={`flex items-center gap-2 p-2 rounded-md border cursor-pointer ${pick === c.id ? "border-[#0052D9] bg-[#0052D9]/5" : "border-slate-200 hover:bg-slate-50"}`}>
              <input type="radio" name="pick" checked={pick === c.id} onChange={() => setPick(c.id)} className="accent-[#0052D9]" />
              <span className="font-mono text-xs text-slate-400">{c.code}</span>
              <span className="text-sm text-slate-800 flex-1 min-w-0 truncate">{c.name}</span>
              {prod && <Chip text={prod.code} cls="bg-slate-50 text-slate-500 border-slate-200" />}
            </label>
          );
        })}
      </div>
      <ModalFooter onCancel={onCancel} okText="归集" okDisabled={!pick}
        onOk={() => { aggregateCase(issue.id, pick); onDone(); }} />
    </Modal>
  );
}

/* ============================ 弹窗：提交解决方案 ============================ */
function SolutionModal({ issue, onCancel, onDone }: { issue: Issue; onCancel: () => void; onDone: () => void }) {
  const [sol, setSol] = useState(issue.solution ?? "");
  const [rootCause, setRootCause] = useState(issue.rootCause ?? "");
  return (
    <Modal title="KR 提交解决方案" onCancel={onCancel}>
      <div className="rounded-md bg-[#0052D9]/5 border border-[#0052D9]/20 p-2.5 text-xs text-slate-700 leading-relaxed">
        提交后进入 <b>requester Review</b>，不会立即分发。Review <b>通过即 Issue 结案</b>，届时系统会强制 Fanout 到其它产品（各建 1 个验证 Case）。
      </div>
      <label className="block text-xs text-slate-600 mt-3">
        根因定位
        <textarea value={rootCause} onChange={(e) => setRootCause(e.target.value)} autoFocus
          placeholder="请描述共性根因及证据"
          className="mt-1 w-full min-h-[76px] p-2.5 text-sm rounded border border-slate-200 outline-none focus:border-[#0052D9] leading-relaxed" />
      </label>
      <label className="block text-xs text-slate-600 mt-3">
        解决方案 <span className="text-slate-400">（根因对策 / 防护措施）</span>
        <textarea value={sol} onChange={(e) => setSol(e.target.value)}
          placeholder="例：更新扩散 recipe 温控补偿参数；在良率基线检查单新增 WAT Vth 漂移监控检查项。"
          className="mt-1 w-full min-h-[110px] p-2.5 text-sm rounded border border-slate-200 outline-none focus:border-[#0052D9] leading-relaxed" />
      </label>
      <ModalFooter onCancel={onCancel} okText="提交 requester Review" okDisabled={sol.trim().length < 5 || rootCause.trim().length < 3}
        onOk={() => { submitSolution(issue.id, sol.trim(), rootCause.trim()); onDone(); }} />
    </Modal>
  );
}

function ReviewModal({ issue, requester, onCancel, onDone }: { issue: Issue; requester: string; onCancel: () => void; onDone: () => void }) {
  const [note, setNote] = useState("");
  return (
    <Modal title="requester Review" onCancel={onCancel}>
      <div className="rounded-lg border border-purple-100 bg-purple-50/70 p-3 text-xs text-slate-700 leading-relaxed">
        <b>{requester}</b> 将确认 KR 提交的根因和解决方案。<b className="text-purple-700">通过即代表 Issue 结案</b>，系统将强制 Fanout：为每个其它产品各建 1 个「Fanout 验证」Case 并推送负责人；打回后回到 KR 调查阶段。
      </div>
      <div className="mt-3 grid grid-cols-2 gap-3">
        <div className="rounded-lg border border-slate-200 p-3"><div className="text-[11px] text-slate-400">根因</div><div className="mt-1 text-xs text-slate-700 leading-relaxed">{issue.rootCause || "—"}</div></div>
        <div className="rounded-lg border border-slate-200 p-3"><div className="text-[11px] text-slate-400">解决方案</div><div className="mt-1 text-xs text-slate-700 leading-relaxed">{issue.solution || "—"}</div></div>
      </div>
      <label className="block text-xs text-slate-600 mt-3">Review 意见（打回时建议填写）
        <textarea value={note} onChange={(e) => setNote(e.target.value)} rows={3} placeholder="补充确认意见或需修改内容" className="mt-1 w-full p-2.5 rounded border border-slate-200 text-sm outline-none focus:border-purple-400 resize-none" />
      </label>
      <div className="flex justify-end gap-2 pt-3 mt-3 border-t border-slate-100">
        <button onClick={onCancel} className="h-8 px-3 text-sm rounded border border-slate-200 text-slate-600">取消</button>
        <button disabled={!note.trim()} onClick={() => { reviewIssue(issue.id, currentUser.name, "打回"); onDone(); }} className="h-8 px-3 text-sm rounded border border-red-300 text-red-600 hover:bg-red-50 disabled:opacity-40 inline-flex items-center gap-1"><RotateCcw size={12} /> 打回 KR</button>
        <button onClick={() => { reviewIssue(issue.id, currentUser.name, "通过"); onDone(); }} className="h-8 px-3 text-sm rounded bg-emerald-600 text-white hover:bg-emerald-700 inline-flex items-center gap-1"><Check size={12} /> 通过并结案 Fanout</button>
      </div>
    </Modal>
  );
}

function ChecklistDecisionModal({ issue, onCancel, onDone }: { issue: Issue; onCancel: () => void; onDone: () => void }) {
  const [decision, setDecision] = useState<"join" | "skip">("join");
  const [title, setTitle] = useState(issue.backwriteDefTitle || issue.name);
  return (
    <Modal title="Checklist 决策" onCancel={onCancel}>
      <p className="text-xs text-slate-500 leading-relaxed">分发完成后，由 requester 或 KR 判断该共性问题是否应加入产品好坏检查的 Checklist，防止同类问题再次发生。</p>
      <div className="mt-3 grid grid-cols-2 gap-3">
        <button onClick={() => setDecision("join")} className={`rounded-lg border p-3 text-left ${decision === "join" ? "border-emerald-400 bg-emerald-50" : "border-slate-200"}`}><div className="text-sm font-medium text-emerald-700">加入 Checklist</div><div className="mt-1 text-[11px] text-slate-500">沉淀为后续产品检查项</div></button>
        <button onClick={() => setDecision("skip")} className={`rounded-lg border p-3 text-left ${decision === "skip" ? "border-slate-500 bg-slate-50" : "border-slate-200"}`}><div className="text-sm font-medium text-slate-700">本次不加入</div><div className="mt-1 text-[11px] text-slate-500">保留 Issue 记录，不新增检查项</div></button>
      </div>
      {decision === "join" && <label className="block mt-3 text-xs text-slate-600">新检查项标题
        <input value={title} onChange={(e) => setTitle(e.target.value)} className="mt-1 w-full h-9 px-2.5 rounded border border-slate-200 text-sm outline-none focus:border-emerald-500" />
      </label>}
      <ModalFooter onCancel={onCancel} okText="确认决策" okDisabled={decision === "join" && !title.trim()}
        onOk={() => { decideIssueChecklist(issue.id, currentUser.name, decision === "join", title.trim()); onDone(); }} />
    </Modal>
  );
}

/* ================================ 通用弹窗 ================================ */
function Modal({ title, onCancel, children }: { title: string; onCancel: () => void; children: React.ReactNode }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40" onClick={onCancel}>
      <div className="w-[540px] bg-white rounded-lg shadow-xl border border-slate-200 p-5 max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center gap-2 mb-3">
          <h3 className="text-slate-900">{title}</h3>
          <button onClick={onCancel} className="ml-auto text-slate-400 hover:text-slate-600"><X size={16} /></button>
        </div>
        {children}
      </div>
    </div>
  );
}
function ModalFooter({ onCancel, onOk, okText, okDisabled }: { onCancel: () => void; onOk: () => void; okText: string; okDisabled?: boolean }) {
  return (
    <div className="flex items-center justify-end gap-2 pt-3 mt-3 border-t border-slate-100">
      <button onClick={onCancel} className="h-8 px-3 text-sm rounded-md border border-slate-200 text-slate-600 hover:bg-slate-50">取消</button>
      <button disabled={okDisabled} onClick={onOk} className="h-8 px-3.5 text-sm rounded-md bg-[#0052D9] text-white hover:bg-[#0047b8] disabled:opacity-40">{okText}</button>
    </div>
  );
}
