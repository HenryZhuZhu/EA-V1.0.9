import { useState } from "react";
import { TaskDialog } from "./TaskDialog";

export function RejectTaskModal({ title, onClose, onConfirm }: {
  title: string;
  onClose: () => void;
  onConfirm: (reason: string) => void;
}) {
  const [reason, setReason] = useState("");
  const [error, setError] = useState("");
  const confirm = () => {
    if (!reason.trim()) return;
    try { onConfirm(reason.trim()); onClose(); }
    catch (cause) { setError(cause instanceof Error ? cause.message : "操作失败，请重试。"); }
  };
  return <TaskDialog title="拒绝任务" description="请说明拒绝原因，便于分派人了解情况并重新安排。" onClose={onClose} footer={<>
    <button type="button" onClick={onClose} className="h-9 rounded-lg border border-slate-200 bg-white px-4 text-xs text-slate-600">取消</button>
    <button type="button" onClick={confirm} disabled={!reason.trim()} className="h-9 rounded-lg bg-[#0052D9] px-4 text-xs font-medium text-white hover:bg-[#003FA8] disabled:cursor-not-allowed disabled:opacity-40">确认拒绝</button>
  </>}>
    <div className="mb-4 rounded-lg border border-slate-200 bg-slate-50 px-3 py-3 text-sm text-slate-700">{title}</div>
    <label className="block text-xs font-medium text-slate-600">拒绝理由 <span className="text-red-400">*</span><textarea autoFocus value={reason} onChange={(event) => { setReason(event.target.value); setError(""); }} placeholder="请填写无法接受此任务的原因" className="mt-2 min-h-[110px] w-full rounded-lg border border-slate-200 px-3 py-2.5 text-sm font-normal leading-relaxed outline-none focus:border-[#0052D9]" /></label>
    {error && <p role="alert" className="mt-3 text-xs text-red-600">{error}</p>}
  </TaskDialog>;
}