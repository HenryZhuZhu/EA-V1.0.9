import { useState } from "react";
import {
  ChevronLeft,
  ChevronRight,
  Wrench,
  Pin,
  Search,
  Sparkles,
  ExternalLink,
} from "lucide-react";

type Tool = {
  key: string;
  name: string;
  desc: string;
  tag: "执行" | "数据" | "分析" | "可视";
  hot?: boolean;
  gradient: string;
  initial: string;
};

const TOOLS: Tool[] = [
  {
    key: "itest",
    name: "iTest",
    desc: "自动化测试执行平台",
    tag: "执行",
    hot: true,
    gradient: "from-[#0052D9] to-[#00A4FF]",
    initial: "iT",
  },
  {
    key: "oneclick",
    name: "Oneclick",
    desc: "一键数据拉取 & 环境准备",
    tag: "数据",
    hot: true,
    gradient: "from-[#7A3DFF] to-[#B07BFF]",
    initial: "1C",
  },
  {
    key: "shmoo",
    name: "Shmoo Viewer",
    desc: "VDDmin / Fmax 可视化",
    tag: "分析",
    gradient: "from-[#00B578] to-[#33D28F]",
    initial: "Sh",
  },
  {
    key: "datalog",
    name: "Datalog Parser",
    desc: "datalog 结构化解析",
    tag: "数据",
    gradient: "from-[#F7A000] to-[#FFC24A]",
    initial: "DP",
  },
  {
    key: "yield",
    name: "Yield Pareto",
    desc: "Bin 分布 / 失效分布",
    tag: "分析",
    gradient: "from-[#E54545] to-[#FF7A7A]",
    initial: "YP",
  },
  {
    key: "wafer",
    name: "Wafer Map",
    desc: "Wafer 空间分布",
    tag: "可视",
    gradient: "from-[#00A4FF] to-[#33C4FF]",
    initial: "Wm",
  },
  {
    key: "jira",
    name: "JIRA",
    desc: "工单 / 缺陷跟踪",
    tag: "执行",
    gradient: "from-[#0747A6] to-[#2684FF]",
    initial: "Ji",
  },
  {
    key: "spc",
    name: "SPC Monitor",
    desc: "统计过程控制",
    tag: "分析",
    gradient: "from-[#475569] to-[#64748B]",
    initial: "Sp",
  },
];

const tagColors: Record<Tool["tag"], string> = {
  执行: "bg-blue-50 text-blue-600 border-blue-100",
  数据: "bg-amber-50 text-amber-600 border-amber-100",
  分析: "bg-emerald-50 text-emerald-600 border-emerald-100",
  可视: "bg-purple-50 text-purple-600 border-purple-100",
};

export function ToolRail() {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const [pinned, setPinned] = useState<string[]>(["itest", "oneclick", "shmoo"]);

  const tools = TOOLS.filter(
    (t) => !q || t.name.toLowerCase().includes(q.toLowerCase()) || t.desc.includes(q)
  );
  const pinnedTools = TOOLS.filter((t) => pinned.includes(t.key));

  const togglePin = (k: string) =>
    setPinned((p) => (p.includes(k) ? p.filter((x) => x !== k) : [...p, k]));

  return (
    <aside
      className={`relative shrink-0 border-l border-slate-200 bg-white/70 backdrop-blur-sm transition-all duration-200 ${
        open ? "w-[280px]" : "w-[56px]"
      }`}
    >
      {/* Toggle */}
      <button
        onClick={() => setOpen(!open)}
        className="absolute -left-3 top-16 w-6 h-6 rounded-full bg-white border border-slate-200 shadow-sm flex items-center justify-center text-slate-500 hover:text-[#0052D9] hover:border-[#0052D9]/40 z-10"
      >
        {open ? <ChevronRight size={12} /> : <ChevronLeft size={12} />}
      </button>

      {/* Collapsed rail */}
      {!open && (
        <div className="h-full py-4 flex flex-col items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-slate-700 to-slate-900 text-white flex items-center justify-center">
            <Wrench size={14} />
          </div>
          <div className="flex-1 flex flex-col gap-2 items-center overflow-y-auto py-1">
            {pinnedTools.map((t) => (
              <button
                key={t.key}
                title={`${t.name} — ${t.desc}`}
                className={`relative w-9 h-9 rounded-lg bg-gradient-to-br ${t.gradient} text-white text-[11px] flex items-center justify-center shadow-sm hover:scale-105 transition-transform`}
              >
                {t.initial}
                {t.hot && (
                  <span className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 rounded-full bg-red-500 ring-2 ring-white" />
                )}
              </button>
            ))}
          </div>
          <div className="text-[9px] text-slate-400 writing-mode-vertical" style={{ writingMode: "vertical-rl" }}>
            工具箱
          </div>
        </div>
      )}

      {/* Expanded panel */}
      {open && (
        <div className="h-full flex flex-col">
          <div className="px-4 pt-4 pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-slate-700 to-slate-900 text-white flex items-center justify-center">
                <Wrench size={13} />
              </div>
              <div>
                <h4 className="text-slate-900">工具箱</h4>
                <p className="text-[11px] text-slate-500 mt-0.5">直连工程师常用系统</p>
              </div>
            </div>
            <div className="relative mt-3">
              <Search size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="搜索工具"
                className="w-full h-8 pl-7 pr-2 text-xs rounded-md bg-slate-50 border border-slate-200 outline-none focus:bg-white focus:border-[#0052D9]"
              />
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-3 space-y-3">
            {/* AI suggestion */}
            <div className="bg-gradient-to-br from-[#0052D9]/5 to-[#7A3DFF]/5 border border-[#7A3DFF]/20 rounded-md p-2.5 flex items-start gap-2">
              <Sparkles size={12} className="text-[#7A3DFF] mt-0.5 shrink-0" />
              <div className="text-[11px] text-slate-700 leading-relaxed">
                基于当前任务推荐：<b className="text-[#0052D9]">iTest</b> → <b className="text-[#0052D9]">Oneclick</b> → Shmoo
              </div>
            </div>

            {/* Pinned */}
            {!q && pinnedTools.length > 0 && (
              <div>
                <div className="text-[10px] text-slate-400 uppercase tracking-wider px-1 mb-1.5">
                  已置顶
                </div>
                <div className="space-y-1">
                  {pinnedTools.map((t) => (
                    <ToolRow
                      key={t.key}
                      tool={t}
                      pinned
                      onTogglePin={() => togglePin(t.key)}
                    />
                  ))}
                </div>
              </div>
            )}

            <div>
              {!q && (
                <div className="text-[10px] text-slate-400 uppercase tracking-wider px-1 mb-1.5">
                  全部工具
                </div>
              )}
              <div className="space-y-1">
                {tools
                  .filter((t) => q || !pinned.includes(t.key))
                  .map((t) => (
                    <ToolRow
                      key={t.key}
                      tool={t}
                      pinned={pinned.includes(t.key)}
                      onTogglePin={() => togglePin(t.key)}
                    />
                  ))}
              </div>
            </div>
          </div>

          <div className="px-3 py-2 border-t border-slate-100 text-[11px] text-slate-500 flex items-center gap-1.5">
            <span>{TOOLS.length} 个工具 · {pinned.length} 已置顶</span>
            <button className="ml-auto text-[#0052D9] hover:underline">管理</button>
          </div>
        </div>
      )}
    </aside>
  );
}

function ToolRow({
  tool,
  pinned,
  onTogglePin,
}: {
  tool: Tool;
  pinned: boolean;
  onTogglePin: () => void;
}) {
  return (
    <button className="group w-full flex items-center gap-2.5 p-2 rounded-md hover:bg-slate-50 text-left transition-colors">
      <div
        className={`w-8 h-8 rounded-md bg-gradient-to-br ${tool.gradient} text-white text-[11px] flex items-center justify-center shrink-0 shadow-sm`}
      >
        {tool.initial}
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1.5">
          <span className="text-sm text-slate-800 truncate group-hover:text-[#0052D9]">
            {tool.name}
          </span>
          {tool.hot && (
            <span className="px-1 py-0.5 rounded text-[9px] bg-red-500/10 text-red-500">HOT</span>
          )}
        </div>
        <div className="text-[11px] text-slate-500 truncate">{tool.desc}</div>
      </div>
      <span
        className={`px-1.5 py-0.5 rounded text-[10px] border shrink-0 ${tagColors[tool.tag]}`}
      >
        {tool.tag}
      </span>
      <div className="flex items-center gap-0.5 shrink-0">
        <span
          onClick={(e) => {
            e.stopPropagation();
            onTogglePin();
          }}
          className={`w-6 h-6 rounded flex items-center justify-center ${
            pinned
              ? "text-[#0052D9]"
              : "text-slate-300 opacity-0 group-hover:opacity-100 hover:text-[#0052D9]"
          }`}
        >
          <Pin size={11} fill={pinned ? "currentColor" : "none"} />
        </span>
        <ExternalLink
          size={11}
          className="text-slate-300 opacity-0 group-hover:opacity-100 group-hover:text-[#0052D9]"
        />
      </div>
    </button>
  );
}
