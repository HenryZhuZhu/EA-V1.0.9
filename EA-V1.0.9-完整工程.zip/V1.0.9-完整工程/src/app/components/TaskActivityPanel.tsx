import { useId, useRef, useState } from "react";
import { Clock3, MessageSquare, Send } from "lucide-react";
import { currentUser, type TaskComment, type TaskNode } from "./data";
import { TASK_COMMENT_LIMIT, type TaskActivity } from "./taskActivity";

function timeLabel(value: string) {
  const time = new Date(value);
  return Number.isNaN(time.getTime()) ? value : time.toLocaleString("zh-CN", { hour12: false, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

export function TaskActivityPanel({ activities = [], comments = [], statusHistory = [], onComment, readOnlyReason, compact = false, view }: {
  activities?: TaskActivity[];
  comments?: TaskComment[];
  statusHistory?: TaskNode["statusHistory"];
  onComment: (content: string, replyTo?: string) => void;
  readOnlyReason?: string;
  compact?: boolean;
  view?: "log" | "comments";
}) {
  const id = useId();
  const [tab, setTab] = useState<"log" | "comments">("log");
  const activeTab = view ?? tab;
  const [draft, setDraft] = useState("");
  const [replyTo, setReplyTo] = useState<string | null>(null);
  const [replyDraft, setReplyDraft] = useState("");
  const [error, setError] = useState("");
  const sending = useRef(false);
  const history: TaskActivity[] = statusHistory.filter((entry) => !activities.some((activity) => activity.at === entry.at && activity.changes.some((change) => change.field === "状态" && change.after === entry.status))).map((entry, index) => ({
    id: `status-${index}-${entry.at}`, kind: "status", at: entry.at, by: entry.by || "未记录", summary: `状态记录：${entry.status}`, changes: [],
  }));
  const all = [...activities, ...history].map((entry, index) => ({ entry, index })).sort((a, b) => (Date.parse(b.entry.at) || 0) - (Date.parse(a.entry.at) || 0) || b.index - a.index).map(({ entry }) => ({ ...entry, changes: entry.changes.map(change => change.field === "协作者" ? { ...change, field: "参与人" } : change) }));
  const commentCount = comments.reduce((sum, comment) => sum + 1 + (comment.replies?.length ?? 0), 0);
  const send = (reply = false) => {
    if (sending.current || readOnlyReason) return;
    const content = reply ? replyDraft : draft;
    if (!content.trim()) return;
    sending.current = true;
    try {
      onComment(content, reply ? replyTo ?? undefined : undefined);
      if (reply) { setReplyDraft(""); setReplyTo(null); } else setDraft("");
      setError("");
    } catch (reason) { setError(reason instanceof Error ? reason.message : "评论保存失败，请重试。"); }
    finally { sending.current = false; }
  };
  const inputClass = "w-full resize-y rounded-lg border border-slate-200 bg-white p-3 text-xs leading-relaxed text-slate-700 outline-none focus:border-[#0052D9]";

  return <section aria-label="任务动态" className={view === "comments" ? "bg-white p-5" : "rounded-xl border border-slate-200 bg-white p-5"}>
    {view !== "comments" && <header className="mb-4 flex items-center gap-2">
      <Clock3 size={15} className="shrink-0 text-[#0052D9]" />
      <h2 className="text-sm font-medium text-slate-800">任务流转日志</h2>
      {!compact && <span className="text-[11px] text-slate-400">负责人 / 时间 / 状态等变更</span>}
      {!view && <div role="group" aria-label="动态内容" className="ml-auto flex gap-1 rounded-lg bg-slate-50 p-1">
        <button type="button" aria-pressed={tab === "log"} aria-controls={`${id}-log`} onClick={() => setTab("log")} className={`inline-flex h-7 items-center gap-1.5 rounded-md px-3 text-xs ${tab === "log" ? "bg-white text-[#0052D9] shadow-sm" : "text-slate-500"}`}><Clock3 size={13} />操作日志 <span className="text-[10px]">{all.length}</span></button>
        <button type="button" aria-pressed={tab === "comments"} aria-controls={`${id}-comments`} onClick={() => setTab("comments")} className={`inline-flex h-7 items-center gap-1.5 rounded-md px-3 text-xs ${tab === "comments" ? "bg-white text-[#0052D9] shadow-sm" : "text-slate-500"}`}><MessageSquare size={13} />评论 <span className="text-[10px]">{commentCount}</span></button>
      </div>}
    </header>}
    {view !== "comments" && <div id={`${id}-log`} hidden={activeTab !== "log"}>
      <div className="mb-4 flex items-center gap-2"><span className="rounded-md bg-blue-50 px-2.5 py-1 text-[11px] text-[#0052D9]">全部</span><span className="ml-auto text-[10px] text-slate-400">最新在前</span></div>
      {!all.length && <p className="py-5 text-center text-xs text-slate-400">暂无操作日志</p>}
      {all.length > 0 && <div className="max-h-[480px] overflow-y-auto pr-2"><div className="relative pl-5">
        <div aria-hidden="true" className="absolute bottom-1 left-[5px] top-1 w-px bg-slate-200" />
        <ol className="space-y-4">{all.map((entry) => {
          const brief = entry.changes.filter((change) => change.before.length + change.after.length <= 100 && !/[\r\n]/.test(change.before + change.after));
          const lengthy = entry.changes.filter((change) => !brief.includes(change));
          const dot = entry.kind === "status" || entry.kind === "upgrade" ? "bg-[#0052D9]" : entry.kind === "edit" ? "bg-amber-500" : "bg-slate-400";
          return <li key={entry.id} className="relative">
            <span aria-hidden="true" className={`absolute -left-[18px] top-1 h-2.5 w-2.5 rounded-full ring-2 ring-white ${dot}`} />
            <div className="break-words text-sm text-slate-800">{entry.summary}
              {brief.map((change, index) => <span key={`${change.field}-${index}`} className="ml-2 inline-block max-w-full align-top text-xs text-slate-500"><span>{change.field}：</span><span className="line-through decoration-slate-300">{change.before}</span><span className="mx-1">→</span><b className="font-semibold text-slate-700">{change.after}</b></span>)}
            </div>
            <div className="mt-0.5 text-[11px] text-slate-400">{entry.by} · <time dateTime={entry.at}>{timeLabel(entry.at)}</time></div>
            {entry.detail && !entry.changes.some((change) => change.after === entry.detail) && <p className="mt-1.5 whitespace-pre-wrap break-words text-xs leading-relaxed text-slate-500">{entry.detail}</p>}
            {lengthy.length > 0 && <details className="mt-2">
              <summary className="cursor-pointer text-[11px] text-slate-500">{lengthy.map((change) => change.field).join("、")} · 查看变更前后</summary>
              <div className="mt-2 space-y-2">{lengthy.map((change, index) => <div key={`${change.field}-${index}`} className="rounded-md bg-slate-50 p-3 text-[11px]"><div className="mb-1 font-medium text-slate-600">{change.field}</div><div className="grid grid-cols-2 gap-3"><div className="min-w-0 rounded bg-white p-2"><span className="text-[10px] text-slate-400">变更前</span><p className="mt-1 max-h-32 overflow-auto whitespace-pre-wrap break-words text-slate-500">{change.before}</p></div><div className="min-w-0 rounded bg-white p-2"><span className="text-[10px] text-slate-400">变更后</span><p className="mt-1 max-h-32 overflow-auto whitespace-pre-wrap break-words text-slate-700">{change.after}</p></div></div></div>)}</div>
            </details>}
          </li>;
        })}</ol>
      </div></div>}
      <p className="mt-4 border-t border-slate-100 pt-3 text-[10px] text-slate-400">仅展示已保存的记录；早期未记录的操作不补造。修改日志在显式保存后生成，相同内容不会重复记录。</p>
    </div>}
    {view !== "log" && <div id={`${id}-comments`} hidden={activeTab !== "comments"} className="space-y-4">
      {readOnlyReason ? <p className="rounded-lg bg-slate-50 p-3 text-xs text-slate-500">{readOnlyReason}</p> : <form onSubmit={(event) => { event.preventDefault(); send(); }} className="space-y-2">
        <label htmlFor={`${id}-draft`} className="block text-xs text-slate-600">发表评论 · {currentUser.name}</label>
        <textarea id={`${id}-draft`} value={draft} onChange={(event) => setDraft(event.target.value)} maxLength={TASK_COMMENT_LIMIT} rows={3} placeholder="补充进展、提出问题或同步处理意见…" className={inputClass} onKeyDown={(event) => { if (!event.nativeEvent.isComposing && event.key === "Enter" && (event.ctrlKey || event.metaKey)) { event.preventDefault(); send(); } }} />
        <div className="flex items-center justify-between"><span className="text-[10px] text-slate-400">Enter 换行 · Ctrl / ⌘ + Enter 发送 · {draft.length}/{TASK_COMMENT_LIMIT}</span><button type="submit" disabled={!draft.trim()} className="inline-flex h-8 items-center gap-1.5 rounded-md bg-[#0052D9] px-3 text-xs text-white hover:bg-[#003FA8] disabled:opacity-40"><Send size={12} />发送评论</button></div>
      </form>}
      {error && <p role="alert" className="rounded-md bg-red-50 p-2 text-xs text-red-600">{error}</p>}
      {!comments.length && <p className="border-t border-slate-100 py-6 text-center text-xs text-slate-400">暂无评论</p>}
      <div className="max-h-[520px] space-y-4 overflow-y-auto pr-1">{[...comments].reverse().map((comment) => <article key={comment.id} aria-label={`${comment.user}的评论`} className="border-t border-slate-100 pt-4">
        <div className="flex items-center gap-2 text-xs"><span className="grid h-6 w-6 place-items-center rounded-full bg-blue-50 text-[10px] text-[#0052D9]">{comment.user.slice(-2)}</span><span className="font-medium text-slate-700">{comment.user}</span><time dateTime={comment.time} className="ml-auto text-[10px] text-slate-400">{timeLabel(comment.time)}</time></div>
        <p className="mt-2 whitespace-pre-wrap break-words text-xs leading-relaxed text-slate-700">{comment.content}</p>
        {comment.replies?.map((reply) => <div key={reply.id} className="ml-6 mt-3 border-l-2 border-slate-100 pl-3"><div className="flex items-center gap-2 text-[11px]"><span className="font-medium text-slate-600">{reply.user}</span><span className="text-slate-400">回复</span><time dateTime={reply.time} className="ml-auto text-[10px] text-slate-400">{timeLabel(reply.time)}</time></div><p className="mt-1 whitespace-pre-wrap break-words text-xs leading-relaxed text-slate-600">{reply.content}</p></div>)}
        {!readOnlyReason && (replyTo === comment.id ? <form className="ml-6 mt-3 space-y-2" onSubmit={(event) => { event.preventDefault(); send(true); }}><textarea aria-label={`回复 ${comment.user}`} value={replyDraft} maxLength={TASK_COMMENT_LIMIT} rows={2} onChange={(event) => setReplyDraft(event.target.value)} className={inputClass} placeholder={`回复 ${comment.user}…`} /><div className="flex justify-end gap-2"><button type="button" onClick={() => setReplyTo(null)} className="text-xs text-slate-400">取消回复</button><button type="submit" disabled={!replyDraft.trim()} className="rounded bg-[#0052D9] px-3 py-1.5 text-xs text-white disabled:opacity-40">发送回复</button></div></form> : <button type="button" aria-label={`回复 ${comment.user}的评论`} onClick={() => { setReplyTo(comment.id); setReplyDraft(""); setError(""); }} className="mt-2 text-[11px] text-[#0052D9] hover:underline">回复</button>)}
      </article>)}</div>
      <p className="text-[10px] text-slate-400">记录与评论保存在当前浏览器。</p>
    </div>}
  </section>;
}