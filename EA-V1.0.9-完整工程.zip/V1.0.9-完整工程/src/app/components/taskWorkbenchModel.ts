import { flattenTasks, type CaseItem, type Product, type TaskNode, type Urgency } from "./data";
import type { StandaloneTask } from "./standaloneTasks";
import type { TaskInvolvement } from "./standaloneTaskConfig";

export type TaskScope = "mine" | "assigned" | "participating";
export type TaskSource = "all" | "standalone" | "case";
export type SummaryStatus = "待接受" | "进行中" | "已完成";
export type BusinessKind = "产品" | "Project" | "TF";
export type TaskGroupBy = "none" | "due" | "owner" | "case" | "business";
export type TaskSortBy = "priority" | "due" | "updated";
export const TASK_SORT_OPTIONS: { value: TaskSortBy; label: string }[] = [
  { value: "priority", label: "紧急程度：高 → 低" },
  { value: "due", label: "截止日期：早 → 晚" },
  { value: "updated", label: "最近更新：新 → 旧" },
];
export const TASK_GROUP_OPTIONS: { value: TaskGroupBy; label: string }[] = [
  { value: "none", label: "不归类" },
  { value: "due", label: "按截止日期" },
  { value: "owner", label: "按负责人" },
  { value: "case", label: "按 Case" },
  { value: "business", label: "按涉及对象" },
];
export function defaultTaskSort(status: SummaryStatus): TaskSortBy {
  return status === "待接受" ? "priority" : status === "进行中" ? "due" : "updated";
}
export type BusinessReference = { key: string; kind: BusinessKind; name: string; origin: "task" | "case"; nameOnly?: boolean };
export interface WorkbenchTask {
  key: string; id: string; source: Exclude<TaskSource, "all">; code: string; title: string; description: string;
  owner: string; creator: string; participants: string[]; participantsFromCase: boolean;
  urgency: Urgency; status: string; dueDate?: string; updatedAt: string;
  conclusion?: string; analysisProcess?: string; rejectReason?: string; terminateReason?: string; reworkReason?: string;
  caseItem?: CaseItem; caseClosed: boolean; convertedCaseId?: string; convertedCaseName?: string;
  business: BusinessReference[]; attachmentCount: number; hasVoice: boolean;
  record: StandaloneTask | TaskNode;
}
export interface TaskFilters {
  scope: TaskScope; source: TaskSource; status: SummaryStatus | null; query: string;
  businessKind: "all" | "none" | BusinessKind; businessKey: string; caseId: string; creator: string;
  showUpgraded: boolean;
}
export const DEFAULT_TASK_FILTERS: TaskFilters = {
  scope: "mine", source: "all", status: null, query: "", businessKind: "all", businessKey: "", caseId: "", creator: "", showUpgraded: false,
};
export function updateWorkbenchFilters(previous: TaskFilters, patch: Partial<TaskFilters>): TaskFilters {
  const next = { ...previous, ...patch };
  // 全部与 Case 任务均可按 Case 筛选，仅自由任务隐藏并清除该条件。
  if (next.source === "standalone") next.caseId = "";
  return next;
}
export function countWorkbenchTasks(rows: WorkbenchTask[]) {
  const upgradedCount = rows.filter(row => Boolean(row.convertedCaseId)).length;
  return { taskCount: rows.length - upgradedCount, upgradedCount };
}
const PRIORITY: Record<Urgency, number> = { 非常紧急: 0, 紧急: 1, 一般: 2, 不紧急: 3 };
export const SUMMARY_STATUSES: SummaryStatus[] = ["待接受", "进行中", "已完成"];

function directBusiness(involvement?: TaskInvolvement): BusinessReference[] {
  return involvement && involvement.kind !== "无" ? [{ key: `${involvement.kind}:${involvement.id}`, kind: involvement.kind, name: involvement.name, origin: "task" }] : [];
}
function caseBusiness(c: CaseItem, products: Pick<Product, "id" | "code" | "name">[]): BusinessReference[] {
  const ids = new Set([...(c.productIds ?? []), ...(c.productId ? [c.productId] : [])]);
  if (!ids.size) {
    // 仅对已有产品字段做准确 ID/编码匹配，不从任务标题或说明猜测关系。
    const product = products.find(p => p.id === c.product || p.code === c.product);
    if (product) ids.add(product.id);
  }
  const refs: BusinessReference[] = [...ids].map(id => {
    const product = products.find(p => p.id === id);
    return { key: `产品:${id}`, kind: "产品", name: product ? `${product.code} · ${product.name}` : id, origin: "case" };
  });
  // projectName 是显式文本记录，不假装它是 Project ID；与精确 ID 引用分开。
  if (c.projectName?.trim()) refs.push({ key: `Project:name:${c.projectName.trim()}`, kind: "Project", name: c.projectName.trim(), origin: "case", nameOnly: true });
  return refs;
}
function latestTime(values: (string | undefined)[], fallback = "") {
  return values.filter((v): v is string => Boolean(v) && Number.isFinite(Date.parse(v!))).sort((a, b) => Date.parse(b) - Date.parse(a))[0] ?? fallback;
}

// 纯读模型：统一查阅，不迁移任务、不改写状态，也不赋予新的操作权限。
export function buildWorkbenchTasks(cases: CaseItem[], tasks: StandaloneTask[], options: {
  products: Pick<Product, "id" | "code" | "name">[];
  loadTree?: (c: CaseItem) => TaskNode[];
  isClosed?: (id: string) => boolean;
}): WorkbenchTask[] {
  const caseRows = cases.flatMap(c => flattenTasks(options.loadTree?.(c) ?? c.tasks).filter(({ task }) => Boolean(task.code)).map(({ task }): WorkbenchTask => {
    const direct = directBusiness(task.standaloneTaskContext?.involvement);
    const inherited = caseBusiness(c, options.products).filter(ref => !direct.some(item => item.key === ref.key || (ref.nameOnly && item.kind === "Project" && item.name === ref.name)));
    const closed = ["已关闭", "已结案", "已归档"].includes(c.status) || Boolean(options.isClosed?.(c.id));
    return {
      key: `case:${c.id}:${task.id}`, id: task.id, source: "case", code: task.code!, title: task.title, description: task.expectation || task.note || "",
      owner: task.owner, creator: task.supervisor?.trim() || "", // 不把 Case Owner 猜成实际分派人。
      participants: [...new Set((task.collaborators ?? c.participants ?? []).map(p => p.name))], participantsFromCase: task.collaborators == null,
      urgency: task.urgency, status: task.status, dueDate: task.dueDate,
      updatedAt: latestTime([...(task.activityLog ?? []).map(a => a.at), ...(task.statusHistory ?? []).map(a => a.at)], c.updatedAt),
      conclusion: task.conclusion, analysisProcess: task.analysisProcess, rejectReason: task.rejectReason, terminateReason: task.terminateReason, reworkReason: task.reworkReason,
      caseItem: c, caseClosed: closed, business: [...direct, ...inherited], attachmentCount: task.attachments?.length ?? 0, hasVoice: Boolean(task.voiceNote), record: task,
    };
  }));
  const dailyRows = tasks.map((task): WorkbenchTask => {
    // 包含来源标记尚未写回的升级批次，避免把同一工作重复统计/操作。
    const linked = cases.find(c => c.id === task.convertedCaseId || c.sourceStandaloneTaskId === task.id || c.sourceStandaloneTaskIds?.includes(task.id));
    return {
      key: `standalone:${task.id}`, id: task.id, source: "standalone", code: task.code, title: task.title, description: task.description,
      owner: task.owner, creator: task.createdBy, participants: [...new Set(task.collaborators.map(p => p.name))], participantsFromCase: false,
      urgency: task.urgency, status: task.status, dueDate: task.dueDate, updatedAt: task.updatedAt,
      conclusion: task.conclusion, analysisProcess: task.analysisProcess, rejectReason: task.rejectReason, terminateReason: task.terminateReason, reworkReason: task.reworkReason,
      caseClosed: false, convertedCaseId: task.convertedCaseId || linked?.id, convertedCaseName: linked?.name,
      business: directBusiness(task.involvement), attachmentCount: task.attachments.length + (task.resultAttachments?.length ?? 0), hasVoice: Boolean(task.voiceNote), record: task,
    };
  });
  return [...caseRows, ...dailyRows];
}

export function taskBelongsTo(row: WorkbenchTask, scope: TaskScope, actor: string) {
  if (scope === "mine") return row.owner === actor;
  if (scope === "assigned") return row.creator === actor && row.owner !== actor;
  return row.owner !== actor && row.participants.includes(actor);
}
export function taskCanAct(row: WorkbenchTask, actor: string) {
  return row.owner === actor && !row.caseClosed && !row.convertedCaseId && ["待接受", "进行中"].includes(row.status);
}
export function taskRemainingDays(row: Pick<WorkbenchTask, "dueDate">, now = new Date()) {
  const match = /^(\d{4})-(\d{2})-(\d{2})/.exec(row.dueDate || "");
  if (!match) return undefined;
  const [year, month, day] = match.slice(1).map(Number);
  const value = new Date(Date.UTC(year, month - 1, day));
  if (value.getUTCFullYear() !== year || value.getUTCMonth() !== month - 1 || value.getUTCDate() !== day) return undefined;
  return (value.getTime() - Date.UTC(now.getFullYear(), now.getMonth(), now.getDate())) / 86400000;
}
export function businessLabel(ref: BusinessReference) {
  return `${ref.kind} · ${ref.name}${ref.origin === "case" ? "（来自 Case）" : ""}${ref.nameOnly ? " · 名称记录" : ""}`;
}
function matchesCommon(row: WorkbenchTask, filters: TaskFilters) {
  if (filters.source !== "all" && row.source !== filters.source) return false;
  if (filters.creator && row.creator !== filters.creator) return false;
  if (filters.caseId && row.caseItem?.id !== filters.caseId) return false;
  if (filters.businessKind === "none" && row.business.length) return false;
  if (filters.businessKind !== "all" && filters.businessKind !== "none" && !row.business.some(ref => ref.kind === filters.businessKind)) return false;
  if (filters.businessKey && !row.business.some(ref => ref.key === filters.businessKey)) return false;
  const terms = filters.query.trim().toLocaleLowerCase().split(/\s+/).filter(Boolean);
  const haystack = [row.title, row.code, row.description, row.owner, row.creator, ...row.participants, row.caseItem?.name, row.caseItem?.code, row.convertedCaseName, ...row.business.map(businessLabel), row.conclusion, row.analysisProcess].filter(Boolean).join(" ").toLocaleLowerCase();
  return terms.every(term => haystack.includes(term));
}
export function selectWorkbenchTasks(rows: WorkbenchTask[], filters: TaskFilters, actor: string) {
  const common = rows.filter(row => matchesCommon(row, filters));
  const related = common.filter(row => taskBelongsTo(row, filters.scope, actor));
  const scopeCounts = Object.fromEntries((["mine", "assigned", "participating"] as const).map(scope => [scope, common.filter(row => !row.convertedCaseId && taskBelongsTo(row, scope, actor)).length])) as Record<TaskScope, number>;
  const counts = Object.fromEntries(SUMMARY_STATUSES.map(status => [status, related.filter(row => !row.convertedCaseId && row.status === status).length])) as Record<SummaryStatus, number>;
  const filtered = related.filter(row => (!row.convertedCaseId || filters.showUpgraded) && (filters.status === null || row.status === filters.status));
  return { rows: filtered, counts, scopeCounts, ...countWorkbenchTasks(filtered) };
}
function compareNumber(a: number, b: number) { return a === b ? 0 : a < b ? -1 : 1; }
function updatedTime(value: string) {
  const time = Date.parse(value);
  return Number.isFinite(time) ? time : -Infinity;
}
function compareTasks(a: WorkbenchTask, b: WorkbenchTask, now: Date, sortBy: TaskSortBy) {
  const priority = compareNumber(PRIORITY[a.urgency] ?? Infinity, PRIORITY[b.urgency] ?? Infinity);
  const due = compareNumber(taskRemainingDays(a, now) ?? Infinity, taskRemainingDays(b, now) ?? Infinity);
  const updated = compareNumber(updatedTime(b.updatedAt), updatedTime(a.updatedAt));
  const order = sortBy === "due" ? due || priority || updated : sortBy === "updated" ? updated || priority || due : priority || due || updated;
  return Number(Boolean(a.convertedCaseId)) - Number(Boolean(b.convertedCaseId)) || order || a.key.localeCompare(b.key);
}
export interface WorkbenchGroup { key: string; label: string; rows: WorkbenchTask[]; total: number; continued?: boolean }
export function groupWorkbenchTasks(rows: WorkbenchTask[], groupBy: TaskGroupBy, now = new Date(), businessKey = "", sortBy: TaskSortBy = "priority"): WorkbenchGroup[] {
  const groups = new Map<string, WorkbenchGroup>();
  for (const row of [...rows].sort((a, b) => compareTasks(a, b, now, sortBy))) {
    let key = "all", label = "全部任务";
    if (groupBy === "owner") { key = `owner:${row.owner}`; label = row.owner || "未记录负责人"; }
    if (groupBy === "case") { key = row.caseItem?.id || "standalone"; label = row.caseItem ? `${row.caseItem.code} · ${row.caseItem.name}${row.caseClosed ? "（已结案）" : ""}` : "未归属 Case"; }
    if (groupBy === "business") {
      const ref = row.business.find(b => b.key === businessKey) ?? row.business[0];
      key = ref?.key || "none"; label = ref ? `${ref.kind} · ${ref.name}${ref.nameOnly ? "（名称记录）" : ""}` : "未关联业务对象";
    }
    if (groupBy === "due") {
      const days = taskRemainingDays(row, now);
      key = row.convertedCaseId ? "6" : !["待接受", "进行中"].includes(row.status) ? "5" : row.caseClosed ? "4" : days === undefined ? "3" : days < 0 ? "0" : days === 0 ? "1" : "2";
      label = ["已逾期", "今天到期", "后续到期", "无截止日期", "所属 Case 已结案", "已结束", "已升级的原任务"][Number(key)];
    }
    const group = groups.get(key) ?? { key, label, rows: [], total: 0 };
    group.rows.push(row); group.total += 1; groups.set(key, group);
  }
  const result = [...groups.values()];
  if (groupBy !== "none") result.sort((a, b) => groupBy === "due" ? a.key.localeCompare(b.key) : a.label.localeCompare(b.label, "zh-CN"));
  return result;
}
// 归类只是一种展示方式；当前范围不能形成多个区块时，不提供无意义的选择。
export function availableTaskGroups(rows: WorkbenchTask[], filters: TaskFilters, now = new Date()) {
  return TASK_GROUP_OPTIONS.filter(({ value }) => {
    if (value === "none") return true;
    if (value === "owner" && filters.scope === "mine") return false;
    if (value === "case" && (filters.source === "standalone" || filters.caseId)) return false;
    if (value === "business" && (filters.businessKey || filters.businessKind === "none")) return false;
    if (value === "due" && filters.status === "已完成") return false;
    return groupWorkbenchTasks(rows, value, now, filters.businessKey).length > 1;
  });
}
export function paginateTaskGroups(groups: WorkbenchGroup[], page: number, size = 8) {
  const total = groups.reduce((sum, group) => sum + group.rows.length, 0);
  const pages = Math.max(1, Math.ceil(total / size)), current = Math.min(Math.max(1, page), pages);
  const start = (current - 1) * size, end = start + size;
  let offset = 0;
  const visible = groups.flatMap(group => {
    const from = Math.max(0, start - offset), to = Math.min(group.rows.length, end - offset);
    offset += group.rows.length;
    return to > from ? [{ ...group, ...countWorkbenchTasks(group.rows), rows: group.rows.slice(from, to), continued: from > 0 }] : [];
  });
  return { groups: visible, page: current, pages, total };
}