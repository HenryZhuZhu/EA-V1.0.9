import { useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { CalendarRange, CheckCircle2, ChevronDown, Search, Users, X } from "lucide-react";
import { Bar, BarChart, CartesianGrid, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { CaseItem, flattenTasks, levelColors, mockCases, Product, TaskNode } from "./data";
import { useClosures } from "./closures";
import { ProductPicker } from "./ProductPicker";
import { CLOSURE_ANALYSIS_PRODUCTS, ensureClosureTimeMockCases } from "./closureTimeMockData";

interface Props {
  onOpenCase: (id: string) => void;
  onOpenTask?: (caseId: string, taskId: string) => void;
  headerActionsTarget?: HTMLDivElement | null;
}

interface ClosedCaseMetric {
  caseItem: CaseItem;
  closedAt: string;
  hours: number;
}

interface ProductMetric {
  product: string;
  cases: ClosedCaseMetric[];
  averageHours: number;
}

const COLORS = ["#0052D9", "#2F7CF6", "#00A4FF", "#00B578", "#67C23A", "#E6A23C", "#F97316", "#E34D59"];
const ANALYSIS_PRODUCTS: Product[] = CLOSURE_ANALYSIS_PRODUCTS.map((product) => ({ ...product, id: product.code }));
const analysisProductByCode = (code?: string) => ANALYSIS_PRODUCTS.find((product) => product.code === code);

function toDate(value?: string) {
  if (!value) return null;
  const normalized = value.length === 10 ? `${value} 00:00` : value;
  const date = new Date(normalized.replace(" ", "T"));
  return Number.isNaN(date.getTime()) ? null : date;
}

function durationHours(createdAt: string, closedAt: string) {
  const start = toDate(createdAt);
  const end = toDate(closedAt);
  if (!start || !end) return 0;
  return Math.max(0, Math.round(((end.getTime() - start.getTime()) / 3600000) * 10) / 10);
}

function taskDurationHours(task: TaskNode) {
  const startedAt = task.statusHistory?.find((entry) => entry.status === "进行中")?.at;
  const completedAt = [...(task.statusHistory ?? [])].reverse().find((entry) => entry.status === "已完成")?.at;
  if (!startedAt || !completedAt) return 0;
  return durationHours(startedAt, completedAt);
}

function formatHours(hours: number) {
  const days = hours / 24;
  return { hours: `${hours.toFixed(hours % 1 ? 1 : 0)}h`, days: `${days.toFixed(1)}天` };
}

function shortDate(value: string) {
  return value.slice(0, 10);
}

function dateText(date: Date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

function shortDateLabel(value: string) {
  const [, month, day] = value.split("-");
  return `${Number(month)}/${Number(day)}`;
}

function weekStart(value: string) {
  const date = new Date(`${shortDate(value)}T00:00:00`);
  const day = date.getDay();
  date.setDate(date.getDate() - (day === 0 ? 6 : day - 1));
  return date;
}

function PeriodDepartmentTooltip({ active, payload, teams }: {
  active?: boolean;
  payload?: any[];
  teams: { name: string; key: string; color: string }[];
}) {
  if (!active || !payload?.length) return null;
  const row = payload[0].payload;
  return (
    <div className="min-w-[230px] rounded-md border border-slate-200 bg-white p-3 text-[10.5px] shadow-[0_8px_24px_rgba(15,23,42,0.14)]">
      <div className="font-semibold text-slate-800">{row.detailLabel}</div>
      <div className="mt-1 text-slate-500">整体平均 <b className="font-medium text-slate-700">{formatHours(row.averageHours).hours}</b> · {row.caseCount} Cases</div>
      <div className="mt-2 border-t border-slate-100 pt-2">
        {teams.map((team) => {
          const detail = row.teamDetails?.[team.name];
          if (!detail) return null;
          return (
            <div key={team.name}>
              <div className="flex items-center gap-2 font-medium text-slate-700">
                <span className="h-2 w-2 shrink-0 rounded-sm" style={{ backgroundColor: team.color }} />{team.name}
              </div>
              <div className="mt-1 whitespace-nowrap text-slate-500">
                贡献 {formatHours(detail.contributionHours).hours} · {detail.caseCount} Cases · 部门均值 {formatHours(detail.averageHours).hours}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export function ClosureTimeAnalysis({ onOpenCase, onOpenTask, headerActionsTarget }: Props) {
  const closures = useClosures();
  const [mockDataReady, setMockDataReady] = useState(false);
  const [selectedProducts, setSelectedProducts] = useState<string[]>([]);
  const [period, setPeriod] = useState<"day" | "week" | "month">("day");
  const [chartFilter, setChartFilter] = useState<
    { kind: "team"; team: string } |
    { kind: "periodTeam"; key: string; label: string; team: string } |
    null
  >(null);
  const [hoveredPeriodTeam, setHoveredPeriodTeam] = useState<string | null>(null);
  const [detailTab, setDetailTab] = useState<"cases" | "members">("cases");
  const [detailQuery, setDetailQuery] = useState("");
  const [visibleCaseCount, setVisibleCaseCount] = useState(8);
  const [expandedCaseId, setExpandedCaseId] = useState("");
  const [expandedEngineerKey, setExpandedEngineerKey] = useState("");
  const [expandedMemberDetail, setExpandedMemberDetail] = useState<{ name: string; kind: "cases" | "tasks" } | null>(null);
  const [hoveredTeam, setHoveredTeam] = useState<string | null>(null);
  const [hoveredTeamPosition, setHoveredTeamPosition] = useState<{ left: number; top: number; cardLeft: number; cardTop: number; cardAbove: boolean } | null>(null);
  const [teamHoverVisible, setTeamHoverVisible] = useState(false);
  const hoverClearTimerRef = useRef<number | null>(null);
  const [customOpen, setCustomOpen] = useState(false);
  const [customStart, setCustomStart] = useState("");
  const [customEnd, setCustomEnd] = useState("");
  const [appliedRange, setAppliedRange] = useState<{ start: string; end: string } | null>(null);

  useEffect(() => {
    ensureClosureTimeMockCases();
    setMockDataReady(true);
  }, []);

  useEffect(() => () => {
    if (hoverClearTimerRef.current !== null) window.clearTimeout(hoverClearTimerRef.current);
  }, []);

  const products = useMemo<ProductMetric[]>(() => {
    const grouped = new Map<string, ClosedCaseMetric[]>();
    mockCases.forEach((caseItem) => {
      const closure = closures.get(caseItem.id);
      const closed = closure?.state === "closed" || caseItem.status === "已关闭" || caseItem.status === "已结案";
      if (!closed) return;
      const closedAt = closure?.closedAt || caseItem.updatedAt;
      const closedDate = shortDate(closedAt);
      if (appliedRange && (closedDate < appliedRange.start || closedDate > appliedRange.end)) return;
      const hours = durationHours(caseItem.createdAt, closedAt);
      const product = caseItem.product && caseItem.product !== "—" ? caseItem.product : "";
      if (!product || !ANALYSIS_PRODUCTS.some((candidate) => candidate.code === product)) return;
      const list = grouped.get(product) ?? [];
      list.push({ caseItem, closedAt, hours });
      grouped.set(product, list);
    });
    return ANALYSIS_PRODUCTS.map((candidate) => {
      const cases = grouped.get(candidate.code) ?? [];
      return {
        product: candidate.code,
        cases: [...cases].sort((a, b) => b.hours - a.hours),
        averageHours: cases.reduce((sum, item) => sum + item.hours, 0) / Math.max(cases.length, 1),
      };
    })
      .sort((a, b) => (b.cases.length > 0 ? 1 : 0) - (a.cases.length > 0 ? 1 : 0) || b.averageHours - a.averageHours || a.product.localeCompare(b.product));
  }, [closures, appliedRange, mockDataReady]);

  const activeProducts = useMemo(
    () => selectedProducts.length ? products.filter((item) => selectedProducts.includes(item.product)) : products,
    [products, selectedProducts],
  );
  const activeCases = useMemo(
    () => activeProducts.flatMap((item) => item.cases).sort((left, right) => right.hours - left.hours),
    [activeProducts],
  );
  const activeAverageHours = activeCases.reduce((sum, metric) => sum + metric.hours, 0) / Math.max(activeCases.length, 1);
  const activeFormat = formatHours(activeAverageHours);
  const teamsOfCase = (metric: ClosedCaseMetric) => {
    const teams = new Set(metric.caseItem.departments ?? []);
    flattenTasks(metric.caseItem.tasks).forEach(({ task }) => { if (task.department) teams.add(task.department); });
    if (!teams.size) teams.add("未标注团队");
    return [...teams];
  };
  const periodKeyOfCase = (metric: ClosedCaseMetric) => {
    const closedDate = shortDate(metric.closedAt);
    if (period === "week") return dateText(weekStart(closedDate));
    if (period === "month") return closedDate.slice(0, 7);
    return closedDate;
  };
  const detailCases = useMemo(() => {
    if (!chartFilter) return activeCases;
    return activeCases.filter((metric) => {
      if (!teamsOfCase(metric).includes(chartFilter.team)) return false;
      return chartFilter.kind === "team" || periodKeyOfCase(metric) === chartFilter.key;
    });
  }, [activeCases, chartFilter, period]);

  useEffect(() => {
    setChartFilter(null);
  }, [period, selectedProducts, appliedRange]);
  const periodTeams = useMemo(() => {
    const counts = new Map<string, number>();
    activeCases.forEach((metric) => teamsOfCase(metric).forEach((team) => counts.set(team, (counts.get(team) ?? 0) + 1)));
    return [...counts.entries()]
      .sort((left, right) => right[1] - left[1] || left[0].localeCompare(right[0]))
      .map(([name], index) => ({ name, key: `team${index}`, color: COLORS[index % COLORS.length] }));
  }, [activeCases]);
  const periodMetrics = useMemo(() => {
    const buckets = new Map<string, {
      label: string;
      detailLabel: string;
      totalHours: number;
      caseCount: number;
      teams: Map<string, { allocatedHours: number; totalHours: number; caseIds: Set<string> }>;
    }>();
    activeCases.forEach((metric) => {
      const closedDate = shortDate(metric.closedAt);
      let key = closedDate;
      let label = shortDateLabel(closedDate);
      let detailLabel = closedDate;
      if (period === "week") {
        const start = weekStart(closedDate);
        const end = new Date(start);
        end.setDate(end.getDate() + 6);
        key = dateText(start);
        label = `${shortDateLabel(key)}-${shortDateLabel(dateText(end))}`;
        detailLabel = `${key} 至 ${dateText(end)}`;
      } else if (period === "month") {
        key = closedDate.slice(0, 7);
        label = key.replace("-", "/");
        detailLabel = key;
      }
      const current = buckets.get(key) ?? { label, detailLabel, totalHours: 0, caseCount: 0, teams: new Map() };
      current.totalHours += metric.hours;
      current.caseCount += 1;
      const caseTeams = teamsOfCase(metric);
      caseTeams.forEach((team) => {
        const teamMetric = current.teams.get(team) ?? { allocatedHours: 0, totalHours: 0, caseIds: new Set<string>() };
        teamMetric.allocatedHours += metric.hours / caseTeams.length;
        teamMetric.totalHours += metric.hours;
        teamMetric.caseIds.add(metric.caseItem.id);
        current.teams.set(team, teamMetric);
      });
      buckets.set(key, current);
    });
    return [...buckets.entries()]
      .sort(([left], [right]) => left.localeCompare(right))
      .map(([key, metric]) => {
        const row: Record<string, any> = {
          key,
          label: metric.label,
          detailLabel: metric.detailLabel,
          averageHours: Math.round((metric.totalHours / Math.max(metric.caseCount, 1)) * 10) / 10,
          caseCount: metric.caseCount,
          teamDetails: {},
        };
        periodTeams.forEach((team) => {
          const teamMetric = metric.teams.get(team.name);
          if (!teamMetric) return;
          const contributionHours = Math.round((teamMetric.allocatedHours / Math.max(metric.caseCount, 1)) * 10) / 10;
          row[team.key] = contributionHours;
          row.teamDetails[team.name] = {
            contributionHours,
            caseCount: teamMetric.caseIds.size,
            averageHours: Math.round((teamMetric.totalHours / Math.max(teamMetric.caseIds.size, 1)) * 10) / 10,
          };
        });
        return row;
      });
  }, [activeCases, period, periodTeams]);
  const periodCopy = period === "day"
    ? { title: "每日平均结案耗时对比", subtitle: "按 Case 实际结案日期统计", unit: "天" }
    : period === "week"
      ? { title: "每周平均结案耗时与部门贡献", subtitle: "按周一至周日统计 · 柱内按部门堆叠", unit: "周" }
      : { title: "月度平均结案耗时与部门贡献", subtitle: "按 Case 实际结案月份统计 · 柱内按部门堆叠", unit: "个月" };
  const activeProductLabel = selectedProducts.length === 0 ? "全部产品" : selectedProducts.length === 1 ? selectedProducts[0] : `${selectedProducts.length} 个产品`;
  const activeProductMeta = selectedProducts.length === 1
    ? `${analysisProductByCode(selectedProducts[0])?.platform ?? "—"} · ${analysisProductByCode(selectedProducts[0])?.family ?? "—"}`
    : `已汇总 ${activeProducts.length} 个产品`;
  const teamParticipation = new Map<string, { caseIds: Set<string>; members: Set<string>; taskCount: number; totalHours: number }>();
  activeCases.forEach((metric) => {
    const teams = new Set<string>(metric.caseItem.departments ?? []);
    const tasks = flattenTasks(metric.caseItem.tasks).map(({ task }) => task);
    tasks.forEach((task) => {
      if (task.department) teams.add(task.department);
    });
    if (!teams.size) teams.add("未标注团队");
    teams.forEach((team) => {
      const current = teamParticipation.get(team) ?? { caseIds: new Set<string>(), members: new Set<string>(), taskCount: 0, totalHours: 0 };
      current.caseIds.add(metric.caseItem.id);
      current.totalHours += metric.hours;
      (metric.caseItem.participants ?? []).filter((participant) => participant.department === team).forEach((participant) => current.members.add(participant.name));
      tasks.filter((task) => task.department === team).forEach((task) => {
        current.taskCount += 1;
        if (task.owner) current.members.add(task.owner);
      });
      teamParticipation.set(team, current);
    });
  });
  const totalTeamParticipation = [...teamParticipation.values()].reduce((sum, metric) => sum + metric.caseIds.size, 0);
  const pieData = [...teamParticipation.entries()]
    .map(([name, metric]) => ({
      name,
      value: metric.caseIds.size,
      percentage: totalTeamParticipation ? (metric.caseIds.size / totalTeamParticipation) * 100 : 0,
      averageHours: metric.totalHours / Math.max(metric.caseIds.size, 1),
      memberCount: metric.members.size,
      taskCount: metric.taskCount,
    }))
    .sort((a, b) => b.value - a.value || a.name.localeCompare(b.name));
  const hoveredTeamMetric = pieData.find((team) => team.name === hoveredTeam);
  const showTeamHover = (sector: any, index: number) => {
    const team = sector?.payload?.name ?? sector?.name ?? pieData[index]?.name ?? null;
    if (!team) return;
    const { cx, cy, midAngle, innerRadius, outerRadius } = sector;
    const radius = innerRadius + (outerRadius - innerRadius) * 0.58;
    const radians = (-midAngle * Math.PI) / 180;
    const left = ((cx + radius * Math.cos(radians)) / Math.max(cx * 2, 1)) * 100;
    const top = ((cy + radius * Math.sin(radians)) / Math.max(cy * 2, 1)) * 100;
    const cardAbove = top >= 50;
    if (hoverClearTimerRef.current !== null) window.clearTimeout(hoverClearTimerRef.current);
    setHoveredTeam(team);
    setHoveredTeamPosition({
      left,
      top,
      cardLeft: Math.min(62, Math.max(38, left)),
      cardTop: cardAbove ? Math.max(18, top - 10) : Math.min(82, top + 10),
      cardAbove,
    });
    window.requestAnimationFrame(() => setTeamHoverVisible(true));
  };
  const hideTeamHover = () => {
    setTeamHoverVisible(false);
    if (hoverClearTimerRef.current !== null) window.clearTimeout(hoverClearTimerRef.current);
    hoverClearTimerRef.current = window.setTimeout(() => {
      setHoveredTeam(null);
      setHoveredTeamPosition(null);
    }, 260);
  };
  const activeExpandedCaseId = detailCases.some((metric) => metric.caseItem.id === expandedCaseId) ? expandedCaseId : detailCases[0]?.caseItem.id || "";
  const memberMetrics = useMemo(() => {
    const members = new Map<string, { cases: Map<string, ClosedCaseMetric>; tasks: { caseItem: CaseItem; task: TaskNode; hours: number }[]; totalHours: number }>();
    detailCases.forEach((metric) => {
      const names = new Set<string>([metric.caseItem.owner, ...(metric.caseItem.participants ?? []).map((participant) => participant.name)]);
      flattenTasks(metric.caseItem.tasks).forEach(({ task }) => {
        if (task.owner) names.add(task.owner);
        if (task.owner) {
          const current = members.get(task.owner) ?? { cases: new Map<string, ClosedCaseMetric>(), tasks: [], totalHours: 0 };
          current.tasks.push({ caseItem: metric.caseItem, task, hours: taskDurationHours(task) });
          members.set(task.owner, current);
        }
      });
      names.forEach((name) => {
        if (!name) return;
        const current = members.get(name) ?? { cases: new Map<string, ClosedCaseMetric>(), tasks: [], totalHours: 0 };
        current.cases.set(metric.caseItem.id, metric);
        current.totalHours += metric.hours;
        members.set(name, current);
      });
    });
    return [...members.entries()].map(([name, metric]) => ({
      name,
      cases: [...metric.cases.values()].sort((a, b) => b.hours - a.hours),
      tasks: [...metric.tasks].sort((a, b) => b.hours - a.hours),
      caseCount: metric.cases.size,
      taskCount: metric.tasks.length,
      averageHours: metric.totalHours / Math.max(metric.cases.size, 1),
    })).sort((a, b) => b.averageHours - a.averageHours);
  }, [detailCases]);
  const normalizedDetailQuery = detailQuery.trim().toLowerCase();
  const filteredActiveCases = detailCases.filter((metric) => {
    if (!normalizedDetailQuery) return true;
    const taskText = flattenTasks(metric.caseItem.tasks).map(({ task }) => `${task.title} ${task.owner}`).join(" ");
    return `${metric.caseItem.code} ${metric.caseItem.name} ${metric.caseItem.owner} ${taskText}`.toLowerCase().includes(normalizedDetailQuery);
  });
  const visibleActiveCases = filteredActiveCases.slice(0, visibleCaseCount);
  const filteredMemberMetrics = memberMetrics.filter((member) => {
    if (!normalizedDetailQuery) return true;
    return `${member.name} ${member.cases.map((metric) => `${metric.caseItem.code} ${metric.caseItem.name}`).join(" ")} ${member.tasks.map(({ task }) => task.title).join(" ")}`.toLowerCase().includes(normalizedDetailQuery);
  });

  useEffect(() => {
    setVisibleCaseCount(8);
  }, [detailQuery, selectedProducts, appliedRange, chartFilter]);

  const trendPoints = (item: ProductMetric) => {
    const values = item.cases.slice(0, 6).map((metric) => metric.hours).reverse();
    if (!values.length) return "0,12 70,12";
    if (values.length === 1) values.push(values[0]);
    const min = Math.min(...values);
    const max = Math.max(...values);
    return values.map((value, index) => {
      const x = values.length === 1 ? 35 : (index / (values.length - 1)) * 70;
      const y = max === min ? 12 : 22 - ((value - min) / (max - min)) * 18;
      return `${x},${y}`;
    }).join(" ");
  };

  const timeControls = (
    <div className="relative flex items-center gap-2">
      <div className="inline-flex items-center rounded-lg border border-slate-200 bg-slate-50 p-0.5">
        {([['day', '天'], ['week', '周'], ['month', '月']] as const).map(([key, label]) => (
          <button key={key} type="button" onClick={() => setPeriod(key)} className={`h-7 px-3 rounded-md text-xs transition-colors ${period === key ? "bg-white text-[#0052D9] shadow-sm" : "text-slate-500 hover:text-slate-700"}`}>{label}</button>
        ))}
      </div>
      <button type="button" onClick={() => setCustomOpen((open) => !open)} className={`inline-flex h-8 items-center gap-1.5 rounded-lg border px-3 text-xs transition-colors ${appliedRange || customOpen ? "border-[#0052D9]/40 bg-[#0052D9]/5 text-[#0052D9]" : "border-slate-200 bg-white text-slate-600 hover:border-slate-300"}`}>
        <CalendarRange size={13} />
        {appliedRange ? `${appliedRange.start} 至 ${appliedRange.end}` : "自定义"}
        <ChevronDown size={12} className={`transition-transform ${customOpen ? "rotate-180" : ""}`} />
      </button>
      {customOpen && (
        <div className="absolute right-0 top-full z-30 mt-2 w-[340px] rounded-xl border border-slate-200 bg-white p-4 shadow-[0_16px_40px_-12px_rgba(15,23,42,0.25)]">
          <div className="grid grid-cols-2 gap-3">
            <label className="text-[11px] text-slate-500">开始日期<input type="date" value={customStart} onChange={(event) => setCustomStart(event.target.value)} className="mt-1 h-9 w-full rounded-md border border-slate-200 px-2 text-xs text-slate-700 outline-none focus:border-[#0052D9]" /></label>
            <label className="text-[11px] text-slate-500">结束日期<input type="date" value={customEnd} onChange={(event) => setCustomEnd(event.target.value)} className="mt-1 h-9 w-full rounded-md border border-slate-200 px-2 text-xs text-slate-700 outline-none focus:border-[#0052D9]" /></label>
          </div>
          {customStart && customEnd && customStart > customEnd && <div className="mt-2 text-[10.5px] text-red-500">开始日期不能晚于结束日期</div>}
          <div className="mt-4 flex justify-end gap-2">
            <button type="button" onClick={() => { setCustomStart(""); setCustomEnd(""); setAppliedRange(null); setCustomOpen(false); }} className="h-8 rounded-md border border-slate-200 px-3 text-xs text-slate-600 hover:bg-slate-50">清除</button>
            <button type="button" disabled={!customStart || !customEnd || customStart > customEnd} onClick={() => { setAppliedRange({ start: customStart, end: customEnd }); setCustomOpen(false); }} className="h-8 rounded-md bg-[#0052D9] px-3 text-xs text-white hover:bg-[#003FA8] disabled:cursor-not-allowed disabled:opacity-40">应用</button>
          </div>
        </div>
      )}
    </div>
  );

  return (
    <div>
      {headerActionsTarget && createPortal(timeControls, headerActionsTarget)}
      <div className="grid min-h-[650px] grid-cols-[300px_minmax(0,1fr)] gap-4">
        <aside className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-[0_1px_2px_rgba(15,23,42,0.04)]">
          <div className="flex min-h-14 items-center gap-2 border-b border-slate-100 px-3 py-2">
            <div className="min-w-0 flex-1">
              <ProductPicker multiple products={ANALYSIS_PRODUCTS} value={selectedProducts} onChange={(productIds) => { setSelectedProducts(productIds); setExpandedCaseId(""); }} placeholder="选择一个或多个产品" triggerClassName="min-h-[36px] max-h-20 overflow-y-auto" />
            </div>
          </div>
          <div className="max-h-[680px] overflow-y-auto p-2">
            {products.map((item) => {
              const selected = selectedProducts.includes(item.product);
              const formatted = formatHours(item.averageHours);
              const product = analysisProductByCode(item.product);
              return (
                <button
                  key={item.product}
                  type="button"
                  aria-pressed={selected}
                  onClick={() => {
                    setSelectedProducts((current) => current.includes(item.product)
                      ? current.filter((productId) => productId !== item.product)
                      : [...current, item.product]);
                    setExpandedCaseId("");
                  }}
                  className={`mb-1 w-full rounded-lg border px-3 py-3 text-left transition-colors ${selected ? "border-[#0052D9]/25 bg-[#0052D9]/[0.07]" : "border-transparent hover:bg-slate-50"}`}
                >
                  <div className="flex items-center gap-2">
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-sm font-semibold text-slate-800">{item.product}</span>
                      {product && <span className="mt-1 block text-[10.5px] text-slate-400">{product.platform ?? '—'} · {product.family ?? '—'}</span>}
                    </span>
                    <svg width="72" height="24" viewBox="0 0 72 24" className="shrink-0" aria-hidden="true">
                      <polyline points={trendPoints(item)} fill="none" stroke={selected ? "#0052D9" : "#94A3B8"} strokeWidth="1.6" strokeLinejoin="round" strokeLinecap="round" />
                      <circle cx={Number(trendPoints(item).split(" ").at(-1)?.split(",")[0] ?? 70)} cy={Number(trendPoints(item).split(" ").at(-1)?.split(",")[1] ?? 12)} r="2" fill={selected ? "#0052D9" : "#94A3B8"} />
                    </svg>
                    <span className="w-[66px] shrink-0 text-right"><span className="block text-sm font-semibold tabular-nums text-slate-800">{formatted.hours}</span><span className="text-[10px] text-slate-400">{formatted.days}</span></span>
                  </div>
                </button>
              );
            })}
          </div>
        </aside>

        <section className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-[0_1px_2px_rgba(15,23,42,0.04)]">
          <div className="flex h-[76px] items-center gap-6 border-b border-slate-100 px-5">
            <div className="min-w-0 flex-1">
              <div className="truncate text-base font-semibold text-slate-900">{activeProductLabel}</div>
              <div className="mt-1 text-[11px] text-slate-400">{activeProductMeta}</div>
            </div>
            <div className="text-right"><div className="text-[10.5px] text-slate-400">{period === "day" ? "平均结案时间" : "区间平均结案时间"}</div><div className="mt-0.5 flex items-baseline justify-end gap-1"><span className="text-xl font-bold tabular-nums text-slate-900">{activeFormat.hours}</span><span className="text-xs text-slate-400">{activeFormat.days}</span></div></div>
            <div className="h-8 w-px bg-slate-100" />
            <div className="text-right"><div className="text-[10.5px] text-slate-400">已结案 Case</div><div className="mt-0.5 text-xl font-bold tabular-nums text-slate-900">{activeCases.length}</div></div>
            <div className="h-8 w-px bg-slate-100" />
            <div className="text-right"><div className="text-[10.5px] text-slate-400">任务数量</div><div className="mt-0.5 text-xl font-bold tabular-nums text-slate-900">{activeCases.reduce((sum, metric) => sum + flattenTasks(metric.caseItem.tasks).length, 0)}</div></div>
          </div>

          <div className="grid min-h-[574px] grid-cols-[46%_54%]">
            <div className="relative flex items-start justify-center border-r border-slate-100">
              {period !== "day" ? (
                <div className="mt-8 h-[500px] w-full min-w-0 px-6">
                  <div className="mb-1 text-sm font-semibold text-slate-800">{periodCopy.title}</div>
                  <div className="text-[10.5px] text-slate-400">{periodCopy.subtitle} · 共 {periodMetrics.length} {periodCopy.unit}</div>
                  <div className="mt-3 flex flex-wrap gap-x-3 gap-y-1.5">
                    {periodTeams.map((team) => <span key={team.name} className="inline-flex items-center gap-1 text-[9.5px] text-slate-500"><span className="h-2 w-2 rounded-sm" style={{ backgroundColor: team.color }} />{team.name}</span>)}
                  </div>
                  <div className="mt-4 h-[350px] w-full">
                    {periodMetrics.length ? (
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={periodMetrics} margin={{ top: 12, right: 8, bottom: 8, left: 0 }}>
                          <CartesianGrid vertical={false} stroke="#E2E8F0" strokeDasharray="3 3" />
                          <XAxis dataKey="label" axisLine={false} tickLine={false} interval="preserveStartEnd" minTickGap={period === "day" ? 24 : 12} tick={{ fill: "#64748B", fontSize: 10 }} />
                          <YAxis axisLine={false} tickLine={false} width={48} tick={{ fill: "#94A3B8", fontSize: 9.5 }} tickFormatter={(value) => `${value}h`} />
                          <Tooltip
                            cursor={{ fill: "rgba(0,82,217,0.04)" }}
                            content={<PeriodDepartmentTooltip teams={hoveredPeriodTeam ? periodTeams.filter((team) => team.name === hoveredPeriodTeam) : []} />}
                          />
                          {periodTeams.map((team, index) => (
                            <Bar
                              key={team.name}
                              dataKey={team.key}
                              name={team.name}
                              stackId="departments"
                              fill={team.color}
                              radius={index === periodTeams.length - 1 ? [4, 4, 0, 0] : [0, 0, 0, 0]}
                              maxBarSize={52}
                              cursor="pointer"
                              onMouseEnter={() => setHoveredPeriodTeam(team.name)}
                              onMouseLeave={() => setHoveredPeriodTeam(null)}
                              onClick={(entry: any) => {
                                const row = entry?.payload;
                                if (!row?.key) return;
                                setExpandedCaseId("");
                                setChartFilter((current) => current?.kind === "periodTeam" && current.key === row.key && current.team === team.name
                                  ? null
                                  : { kind: "periodTeam", key: row.key, label: row.detailLabel, team: team.name });
                              }}
                            >
                              {periodMetrics.map((row) => (
                                <Cell
                                  key={`${team.name}-${row.key}`}
                                  fill={team.color}
                                  fillOpacity={chartFilter?.kind === "periodTeam" && (chartFilter.key !== row.key || chartFilter.team !== team.name) ? 0.3 : 1}
                                />
                              ))}
                            </Bar>
                          ))}
                        </BarChart>
                      </ResponsiveContainer>
                    ) : <div className="grid h-full place-items-center text-sm text-slate-400">当前范围暂无结案数据</div>}
                  </div>
                </div>
              ) : (
              <div className="relative mt-[92px] h-[390px] w-[390px] max-w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={pieData}
                      dataKey="value"
                      nameKey="name"
                      innerRadius="56%"
                      outerRadius="82%"
                      paddingAngle={2}
                      stroke="white"
                      strokeWidth={2}
                      onMouseEnter={showTeamHover}
                      onMouseLeave={hideTeamHover}
                      onClick={(sector: any, index: number) => {
                        const team = sector?.payload?.name ?? sector?.name ?? pieData[index]?.name;
                        if (!team) return;
                        setExpandedCaseId("");
                        setChartFilter((current) => current?.kind === "team" && current.team === team ? null : { kind: "team", team });
                      }}
                    >
                      {pieData.map((item, index) => <Cell key={item.name} cursor="pointer" fill={COLORS[index % COLORS.length]} opacity={(hoveredTeam && hoveredTeam !== item.name) || (chartFilter?.kind === "team" && chartFilter.team !== item.name) ? 0.35 : 1} style={{ transition: "opacity 200ms ease" }} />)}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
                {hoveredTeamMetric && hoveredTeamPosition && (
                  <div
                    className="pointer-events-none absolute z-30 rounded-xl border border-slate-200 bg-white/95 px-4 py-3 shadow-[0_12px_30px_-10px_rgba(15,23,42,0.28)] backdrop-blur"
                    style={{
                      width: 300,
                      left: `${hoveredTeamPosition.cardLeft}%`,
                      top: `${hoveredTeamPosition.cardTop}%`,
                      transform: `translate(-50%, ${hoveredTeamPosition.cardAbove ? "-100%" : "0"}) scale(${teamHoverVisible ? 1 : 0.97})`,
                      opacity: teamHoverVisible ? 1 : 0,
                      transition: "opacity 200ms ease, transform 200ms ease, left 160ms ease, top 160ms ease",
                    }}
                  >
                    <div className="flex items-center justify-between gap-3">
                      <span className="text-sm font-semibold text-slate-800">{hoveredTeamMetric.name}</span>
                      <span className="text-lg font-bold tabular-nums text-slate-900">{hoveredTeamMetric.percentage.toFixed(1)}%</span>
                    </div>
                    <div className="mt-2 border-t border-slate-100 pt-2 text-[10.5px] text-slate-500">
                      团队平均耗时 <span className="font-medium text-slate-700">{formatHours(hoveredTeamMetric.averageHours).hours} {formatHours(hoveredTeamMetric.averageHours).days}</span>
                      <span className="mx-2 text-slate-300">·</span>
                      参与人员 <span className="font-medium text-slate-700">{hoveredTeamMetric.memberCount} 人</span>
                      <span className="mx-2 text-slate-300">·</span>
                      <span className="font-medium text-slate-700">{hoveredTeamMetric.taskCount}</span> 个任务
                    </div>
                  </div>
                )}
                {hoveredTeamMetric && hoveredTeamPosition && (
                  <div
                    className="pointer-events-none absolute z-40 rounded bg-[#0052D9] px-2 py-1 text-[11px] font-semibold text-white shadow-md"
                    style={{
                      left: `${hoveredTeamPosition.left}%`,
                      top: `${hoveredTeamPosition.top}%`,
                      transform: `translate(-50%, -50%) scale(${teamHoverVisible ? 1 : 0.94})`,
                      opacity: teamHoverVisible ? 1 : 0,
                      transition: "opacity 200ms ease, transform 200ms ease, left 160ms ease, top 160ms ease",
                    }}
                  >
                    {hoveredTeamMetric.name} {hoveredTeamMetric.percentage.toFixed(1)}%
                  </div>
                )}
                <div className="pointer-events-none absolute inset-0 grid place-items-center"><div className="text-center"><div className="text-[11px] text-slate-400">产品平均结案耗时</div><div className="mt-1 text-3xl font-bold tabular-nums text-slate-900">{activeFormat.hours}</div><div className="text-xs text-slate-400">{activeFormat.days}</div><div className="mt-1 text-[10px] text-slate-400">{activeProductLabel}</div></div></div>
              </div>
              )}
            </div>

            <div className="flex h-full min-h-0 min-w-0 flex-col px-5 py-4">
              <div className="flex min-w-0 items-center border-b border-slate-100 pb-3">
                <div className="inline-flex shrink-0 whitespace-nowrap rounded-lg bg-slate-100 p-0.5">
                  <button type="button" onClick={() => setDetailTab("cases")} className={`h-7 shrink-0 whitespace-nowrap rounded-md px-3 text-[11px] ${detailTab === "cases" ? "bg-white font-medium text-[#0052D9] shadow-sm" : "text-slate-500"}`}>高耗时 Case</button>
                  <button type="button" onClick={() => setDetailTab("members")} className={`h-7 shrink-0 whitespace-nowrap rounded-md px-3 text-[11px] ${detailTab === "members" ? "bg-white font-medium text-[#0052D9] shadow-sm" : "text-slate-500"}`}>成员平均耗时</button>
                </div>
                {chartFilter && (
                  <button type="button" onClick={() => setChartFilter(null)} title="清除图表筛选" className="ml-2 inline-flex h-7 min-w-0 max-w-[130px] items-center gap-1 rounded-md border border-[#0052D9]/20 bg-[#0052D9]/5 px-2 text-[10px] text-[#0052D9]">
                    <span className="truncate">{chartFilter.kind === "team" ? `部门 · ${chartFilter.team}` : `${chartFilter.label} · ${chartFilter.team}`}</span><X size={10} className="shrink-0" />
                  </button>
                )}
                <div className="relative ml-auto min-w-[80px] flex-1 max-w-[180px]">
                  <Search size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input value={detailQuery} onChange={(event) => setDetailQuery(event.target.value)} placeholder="搜索 Case / 工程师 / 任务" className="h-7 w-full rounded-md border border-slate-200 bg-white pl-7 pr-7 text-[10.5px] text-slate-700 outline-none placeholder:text-slate-400 focus:border-[#0052D9]" />
                  {detailQuery && <button type="button" onClick={() => setDetailQuery("")} title="清空搜索" className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"><X size={11} /></button>}
                </div>
                <span className="ml-3 shrink-0 whitespace-nowrap text-[10.5px] text-slate-400">{detailTab === "cases" ? `${Math.min(visibleCaseCount, filteredActiveCases.length)} / ${filteredActiveCases.length}` : `${filteredMemberMetrics.length} 人`}</span>
              </div>

              <div
                className="min-h-0 flex-1 overflow-y-auto"
                onScroll={(event) => {
                  if (detailTab !== "cases" || visibleCaseCount >= filteredActiveCases.length) return;
                  const element = event.currentTarget;
                  if (element.scrollTop + element.clientHeight >= element.scrollHeight - 48) {
                    setVisibleCaseCount((count) => Math.min(count + 8, filteredActiveCases.length));
                  }
                }}
              >
                {detailTab === "cases" ? visibleActiveCases.map((metric, index) => {
                  const formatted = formatHours(metric.hours);
                  const expanded = metric.caseItem.id === activeExpandedCaseId;
                  const engineerMap = new Map<string, { owner: string; department: string; tasks: { task: TaskNode; hours: number }[]; totalHours: number }>();
                  flattenTasks(metric.caseItem.tasks).map(({ task }) => task).filter((task) => task.status === "已完成").forEach((task) => {
                    const current = engineerMap.get(task.owner) ?? { owner: task.owner, department: task.department, tasks: [], totalHours: 0 };
                    const hours = taskDurationHours(task);
                    current.tasks.push({ task, hours });
                    current.totalHours += hours;
                    engineerMap.set(task.owner, current);
                  });
                  const engineers = [...engineerMap.values()].sort((a, b) => b.totalHours - a.totalHours || a.owner.localeCompare(b.owner));
                  const defaultEngineerKey = engineers[0] ? `${metric.caseItem.id}:${engineers[0].owner}` : "";
                  const activeEngineerKey = expandedEngineerKey || defaultEngineerKey;
                  return (
                    <div key={metric.caseItem.id} className="border-b border-slate-100">
                      <button type="button" onClick={() => { setExpandedCaseId(expanded ? "__none__" : metric.caseItem.id); setExpandedEngineerKey(""); }} className="flex min-h-[64px] w-full items-center gap-3 px-3 py-2.5 text-left transition-colors hover:bg-slate-50/70">
                        <span className={`grid h-5 w-5 shrink-0 place-items-center rounded-md text-[12px] font-bold tabular-nums ${index < 3 ? "bg-[#0052D9]/8 text-[#0052D9]" : "bg-slate-100 text-slate-400"}`}>{index + 1}</span>
                        <span className="min-w-0 flex-1">
                          <span className="flex min-w-0 items-center gap-2">
                          <span className={`shrink-0 rounded border px-1 py-0.5 text-[9px] leading-none ${levelColors[metric.caseItem.level]}`} title={`层级：${metric.caseItem.level}`}>{metric.caseItem.level}</span>
                          <span className="shrink-0 font-mono text-[10.5px] text-slate-400">{metric.caseItem.code}</span>
                            <span className="min-w-0 truncate text-[11px] text-slate-400">{metric.caseItem.owner}</span>
                          </span>
                          <span className="mt-1 block truncate text-[13px] font-medium text-slate-700">{metric.caseItem.name}</span>
                        </span>
                        <span className="w-20 shrink-0 text-right"><span className="block text-sm font-semibold tabular-nums text-slate-900">{formatted.hours}</span><span className="text-[10px] text-slate-400">{formatted.days}</span></span>
                      </button>
                      {expanded && (
                        <div className="mb-3 ml-11 mr-3 rounded-lg border border-slate-100 bg-slate-50/70 p-2.5">
                          {engineers.length ? engineers.map((engineer) => {
                            const engineerKey = `${metric.caseItem.id}:${engineer.owner}`;
                            const engineerExpanded = activeEngineerKey === engineerKey;
                            const engineerDuration = formatHours(engineer.totalHours);
                            return (
                              <div key={engineerKey} className="border-b border-slate-100 last:border-b-0">
                                <div className="flex items-center gap-2 py-2">
                                  <span className="min-w-0 flex-1">
                                    <div className="group relative inline-flex max-w-full items-center gap-1.5" title={`${engineer.owner} · ${engineer.department}`}>
                                      <span className="grid h-6 w-6 shrink-0 cursor-pointer place-items-center rounded-full border-2 border-white bg-gradient-to-br from-[#0052D9] to-[#00A4FF] text-[10px] text-white">{engineer.owner.slice(-2)}</span>
                                      <span className="truncate text-[11px] font-medium text-slate-700">{engineer.owner}</span>
                                      <div className="pointer-events-none absolute bottom-full left-0 z-50 mb-2 whitespace-nowrap rounded bg-slate-800 px-2 py-1 text-[10px] text-white opacity-0 transition-opacity group-hover:opacity-100">{engineer.owner} · {engineer.department}</div>
                                    </div>
                                  </span>
                                  <span className="ml-auto flex shrink-0 items-center gap-2">
                                    <button type="button" onClick={() => setExpandedEngineerKey(engineerExpanded ? "__none__" : engineerKey)} className={`h-7 shrink-0 rounded-md border px-2.5 text-[10.5px] transition-colors ${engineerExpanded ? "border-[#0052D9]/30 bg-[#0052D9]/5 text-[#0052D9]" : "border-slate-200 bg-white text-slate-500 hover:border-[#0052D9]/30 hover:text-[#0052D9]"}`}>{engineer.tasks.length} 任务</button>
                                    <span className="w-16 shrink-0 text-right"><span className="block text-[12px] font-semibold tabular-nums text-slate-800">{engineerDuration.hours}</span><span className="text-[9.5px] text-slate-400">{engineerDuration.days}</span></span>
                                  </span>
                                </div>
                                {engineerExpanded && (
                                  <div className="mb-2 ml-8 border-l-2 border-slate-200 pl-3">
                                    {engineer.tasks.map(({ task, hours }) => {
                                      const duration = formatHours(hours);
                                      return (
                                        <div key={task.id} className="flex items-center gap-3 border-b border-slate-100 py-2 last:border-b-0">
                                          <span className="min-w-0 flex-1"><span className="block truncate font-mono text-[10.5px] text-slate-500">{task.code ?? task.id}</span><span className="mt-0.5 block truncate text-[10px] text-slate-400">{task.title}</span></span>
                                          <span className="w-16 shrink-0 text-right"><span className="block text-[11px] font-medium tabular-nums text-slate-700">{duration.hours}</span><span className="block text-[9.5px] text-slate-400">{duration.days}</span></span>
                                        </div>
                                      );
                                    })}
                                  </div>
                                )}
                              </div>
                            );
                          }) : <div className="py-3 text-center text-[11px] text-slate-400">暂无任务数据</div>}
                        </div>
                      )}
                    </div>
                  );
                }) : filteredMemberMetrics.map((member) => {
                  const caseExpanded = expandedMemberDetail?.name === member.name && expandedMemberDetail.kind === "cases";
                  const taskExpanded = expandedMemberDetail?.name === member.name && expandedMemberDetail.kind === "tasks";
                  return (
                    <div key={member.name} className="border-b border-slate-100">
                      <div className="flex items-center gap-3 px-1 py-3">
                        <span className="grid h-7 w-7 place-items-center rounded-full bg-[#0052D9]/10 text-[10px] font-medium text-[#0052D9]">{member.name.slice(-2)}</span>
                        <span className="min-w-0 flex-1"><span className="block text-[12px] font-medium text-slate-700">{member.name}</span></span>
                        <span className="flex shrink-0 items-center gap-1.5">
                          <button type="button" onClick={() => setExpandedMemberDetail(caseExpanded ? null : { name: member.name, kind: "cases" })} className={`h-7 rounded-md border px-2 text-[10px] ${caseExpanded ? "border-[#0052D9]/30 bg-[#0052D9]/5 text-[#0052D9]" : "border-slate-200 text-slate-500 hover:border-[#0052D9]/30 hover:text-[#0052D9]"}`}>{member.caseCount} Cases</button>
                          <button type="button" onClick={() => setExpandedMemberDetail(taskExpanded ? null : { name: member.name, kind: "tasks" })} className={`h-7 rounded-md border px-2 text-[10px] ${taskExpanded ? "border-[#0052D9]/30 bg-[#0052D9]/5 text-[#0052D9]" : "border-slate-200 text-slate-500 hover:border-[#0052D9]/30 hover:text-[#0052D9]"}`}>{member.taskCount} 任务</button>
                        </span>
                        <span className="w-16 shrink-0 text-right"><span className="block text-sm font-semibold tabular-nums text-slate-900">{formatHours(member.averageHours).hours}</span><span className="text-[10px] text-slate-400">{formatHours(member.averageHours).days}</span></span>
                      </div>
                      {caseExpanded && (
                        <div className="mb-3 ml-10 mr-1 rounded-lg border border-slate-100 bg-slate-50/70 p-2">
                          {member.cases.map((metric) => {
                            const duration = formatHours(metric.hours);
                            return <button key={metric.caseItem.id} type="button" onClick={() => onOpenCase(metric.caseItem.id)} className="flex w-full items-center gap-3 border-b border-slate-100 px-2 py-2 text-left last:border-b-0 hover:bg-white"><span className="min-w-0 flex-1"><span className="block truncate font-mono text-[10.5px] text-slate-500">{metric.caseItem.code}</span><span className="mt-0.5 block truncate text-[10px] text-slate-400">{metric.caseItem.name}</span></span><span className="shrink-0 text-right"><span className="block text-[11px] font-medium text-slate-700">{duration.hours}</span><span className="text-[9.5px] text-slate-400">{duration.days}</span></span></button>;
                          })}
                        </div>
                      )}
                      {taskExpanded && (
                        <div className="mb-3 ml-10 mr-1 rounded-lg border border-slate-100 bg-slate-50/70 p-2">
                          {member.tasks.map(({ caseItem, task, hours }) => {
                            const duration = formatHours(hours);
                            return <button key={`${caseItem.id}:${task.id}`} type="button" onClick={() => onOpenTask?.(caseItem.id, task.id)} className="flex w-full items-center gap-3 border-b border-slate-100 px-2 py-2 text-left last:border-b-0 hover:bg-white"><span className="min-w-0 flex-1"><span className="block truncate font-mono text-[10.5px] text-slate-500">{task.code ?? task.id}</span><span className="mt-0.5 block truncate text-[10px] text-slate-400">{task.title} · {caseItem.code}</span></span><span className="shrink-0 text-right"><span className="block text-[11px] font-medium text-slate-700">{duration.hours}</span><span className="text-[9.5px] text-slate-400">{duration.days}</span></span></button>;
                          })}
                        </div>
                      )}
                    </div>
                  );
                })}
                {detailTab === "cases" && !filteredActiveCases.length && <div className="grid h-56 place-items-center text-sm text-slate-400"><span className="inline-flex items-center gap-2"><CheckCircle2 size={16} />无匹配 Case</span></div>}
                {detailTab === "members" && !filteredMemberMetrics.length && <div className="grid h-56 place-items-center text-sm text-slate-400"><span className="inline-flex items-center gap-2"><Users size={16} />无匹配成员</span></div>}
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
