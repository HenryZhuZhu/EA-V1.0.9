import { Panel, useReactFlow, useViewport } from "@xyflow/react";
import { Minus, Plus, Maximize2, Minimize2 } from "lucide-react";

/* 思维导图缩放控件（− / % / +，可选「全屏」）—— React Flow Panel，放大缩小走 useReactFlow */
export function MindMapZoomPill({
  onFullscreen,
  fullscreen,
  guideAttr,
  position = "bottom-left",
}: {
  onFullscreen?: () => void;
  fullscreen?: boolean;
  guideAttr?: string;
  position?: "bottom-left" | "bottom-right" | "top-left" | "top-right";
}) {
  const { zoomIn, zoomOut, zoomTo } = useReactFlow();
  const { zoom } = useViewport();
  return (
    <Panel position={position}>
      <div
        {...(guideAttr ? { "data-create-guide": guideAttr } : {})}
        className="flex items-center gap-0.5 bg-white/95 backdrop-blur border border-slate-200 rounded-lg shadow-sm p-0.5"
      >
        <button onClick={() => zoomOut({ duration: 200 })} title="缩小" className="w-7 h-7 rounded-md hover:bg-slate-100 flex items-center justify-center text-slate-600"><Minus size={15} /></button>
        <button onClick={() => zoomTo(1, { duration: 200 })} title="实际大小 100%" className="px-1.5 h-7 rounded-md hover:bg-slate-100 text-[11px] tabular-nums text-slate-600 min-w-[44px]">{Math.round(zoom * 100)}%</button>
        <button onClick={() => zoomIn({ duration: 200 })} title="放大" className="w-7 h-7 rounded-md hover:bg-slate-100 flex items-center justify-center text-slate-600"><Plus size={15} /></button>
        {onFullscreen && (
          <>
            <div className="w-px h-4 bg-slate-200 mx-0.5" />
            <button onClick={onFullscreen} title={fullscreen ? "退出全屏" : "全屏"} className="h-7 px-2 rounded-md hover:bg-slate-100 flex items-center gap-1 text-[11px] text-slate-600">
              {fullscreen ? <Minimize2 size={13} /> : <Maximize2 size={13} />} {fullscreen ? "退出全屏" : "全屏"}
            </button>
          </>
        )}
      </div>
    </Panel>
  );
}
