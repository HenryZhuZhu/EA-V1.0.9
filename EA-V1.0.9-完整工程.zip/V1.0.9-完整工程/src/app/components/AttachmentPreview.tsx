import { useEffect, useState } from "react";
import { Download, FileText, LoaderCircle, X } from "lucide-react";
import type { Att } from "./AttachmentInput";

type ZipEntry = { name: string; method: number; size: number; compressedSize: number; offset: number };
type PptSlide = { title: string; lines: string[]; images: string[] };

function bytesFromDataUrl(url: string): Uint8Array {
  const binary = atob(url.split(",")[1] || "");
  return Uint8Array.from(binary, (char) => char.charCodeAt(0));
}

function zipEntries(bytes: Uint8Array): ZipEntry[] {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  let eocd = bytes.length - 22;
  while (eocd >= 0 && view.getUint32(eocd, true) !== 0x06054b50) eocd -= 1;
  if (eocd < 0) throw new Error("无法识别 PPTX 压缩结构");
  const count = view.getUint16(eocd + 10, true);
  let cursor = view.getUint32(eocd + 16, true);
  const decoder = new TextDecoder();
  const entries: ZipEntry[] = [];
  for (let index = 0; index < count; index += 1) {
    if (view.getUint32(cursor, true) !== 0x02014b50) break;
    const nameLength = view.getUint16(cursor + 28, true);
    const extraLength = view.getUint16(cursor + 30, true);
    const commentLength = view.getUint16(cursor + 32, true);
    entries.push({ name: decoder.decode(bytes.slice(cursor + 46, cursor + 46 + nameLength)), method: view.getUint16(cursor + 10, true), compressedSize: view.getUint32(cursor + 20, true), size: view.getUint32(cursor + 24, true), offset: view.getUint32(cursor + 42, true) });
    cursor += 46 + nameLength + extraLength + commentLength;
  }
  return entries;
}

async function unzipEntry(bytes: Uint8Array, entry: ZipEntry): Promise<Uint8Array> {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const nameLength = view.getUint16(entry.offset + 26, true);
  const extraLength = view.getUint16(entry.offset + 28, true);
  const body = bytes.slice(entry.offset + 30 + nameLength + extraLength, entry.offset + 30 + nameLength + extraLength + entry.compressedSize);
  if (entry.method === 0) return body;
  if (entry.method !== 8 || typeof DecompressionStream === "undefined") throw new Error("当前浏览器不支持 PPTX 解压");
  const stream = new Blob([body]).stream().pipeThrough(new DecompressionStream("deflate-raw"));
  return new Uint8Array(await new Response(stream).arrayBuffer());
}

async function parsePptx(url: string): Promise<PptSlide[]> {
  const bytes = bytesFromDataUrl(url);
  const entries = zipEntries(bytes);
  const byName = new Map(entries.map((entry) => [entry.name, entry]));
  const slideNames = entries.map((entry) => entry.name).filter((name) => /^ppt\/slides\/slide\d+\.xml$/.test(name)).sort((a, b) => Number(a.match(/\d+/)?.[0]) - Number(b.match(/\d+/)?.[0]));
  const decoder = new TextDecoder();
  const objectUrls: string[] = [];
  const slides: PptSlide[] = [];
  for (const slideName of slideNames) {
    const slideXml = decoder.decode(await unzipEntry(bytes, byName.get(slideName)!));
    const lines = [...slideXml.matchAll(/<a:t>([\s\S]*?)<\/a:t>/g)].map((match) => new DOMParser().parseFromString(`<x>${match[1]}</x>`, "text/xml").documentElement.textContent || "").filter(Boolean);
    const slideFile = slideName.split("/").pop()!;
    const relName = `ppt/slides/_rels/${slideFile}.rels`;
    const relEntry = byName.get(relName);
    const images: string[] = [];
    if (relEntry) {
      const relXml = decoder.decode(await unzipEntry(bytes, relEntry));
      const relationships = [...relXml.matchAll(/<Relationship[^>]+Id="([^"]+)"[^>]+Target="([^"]+)"/g)];
      for (const [, id, target] of relationships) {
        if (!slideXml.includes(`r:embed="${id}"`) || !target.includes("media/")) continue;
        const mediaName = `ppt/${target.replace(/^\.\.\//, "")}`;
        const mediaEntry = byName.get(mediaName);
        if (!mediaEntry) continue;
        const media = await unzipEntry(bytes, mediaEntry);
        const ext = mediaName.split(".").pop()?.toLowerCase();
        const mime = ext === "png" ? "image/png" : ext === "svg" ? "image/svg+xml" : "image/jpeg";
        const objectUrl = URL.createObjectURL(new Blob([media], { type: mime }));
        objectUrls.push(objectUrl); images.push(objectUrl);
      }
    }
    slides.push({ title: lines[0] || `第 ${slides.length + 1} 页`, lines, images });
  }
  return slides;
}

export function AttachmentPreview({ attachment, onClose }: { attachment: Att; onClose: () => void }) {
  const isImage = attachment.kind === "image" && !!attachment.url;
  const isPpt = /\.(ppt|pptx)$/i.test(attachment.name);
  const [slides, setSlides] = useState<PptSlide[]>([]);
  const [page, setPage] = useState(0);
  const [error, setError] = useState("");
  useEffect(() => { if (isPpt && attachment.url) parsePptx(attachment.url).then(setSlides).catch((reason) => setError(String(reason?.message || reason))); }, [attachment.url, isPpt]);
  const download = () => { if (!attachment.url) return; const link = document.createElement("a"); link.href = attachment.url; link.download = attachment.name; link.click(); };
  return <div className="fixed inset-0 z-[150] bg-slate-950/70 flex items-center justify-center" onClick={onClose}><div className="w-[980px] h-[680px] bg-white rounded-lg shadow-2xl overflow-hidden flex flex-col" onClick={(event) => event.stopPropagation()}><div className="h-12 px-4 border-b border-slate-200 flex items-center gap-2"><FileText size={15} className="text-[#0052D9]"/><span className="text-sm font-medium text-slate-800 truncate">{attachment.name}</span><button onClick={download} className="ml-auto h-8 w-8 grid place-items-center rounded hover:bg-slate-100" title="下载"><Download size={15}/></button><button onClick={onClose} className="h-8 w-8 grid place-items-center rounded hover:bg-slate-100" title="关闭"><X size={16}/></button></div><div className="flex-1 min-h-0 bg-slate-100 flex">{isImage ? <div className="w-full h-full p-6 flex items-center justify-center"><img src={attachment.url} alt={attachment.name} className="max-w-full max-h-full object-contain shadow-lg"/></div> : isPpt ? <>{slides.length > 0 && <div className="w-44 border-r border-slate-200 bg-white p-2 overflow-y-auto">{slides.map((slide, index) => <button key={index} onClick={() => setPage(index)} className={`w-full mb-2 p-2 rounded border text-left text-xs ${page === index ? "border-[#0052D9] bg-blue-50" : "border-slate-200"}`}><span className="text-slate-400">{index + 1}</span><div className="mt-1 truncate text-slate-700">{slide.title}</div></button>)}</div>}<div className="flex-1 p-8 flex items-center justify-center">{error ? <div className="text-sm text-red-600">{error}</div> : !slides.length ? <div className="text-sm text-slate-500 inline-flex items-center gap-2"><LoaderCircle size={16} className="animate-spin"/>正在解析 PPTX...</div> : <div className="w-full aspect-video bg-white shadow-xl p-10 overflow-hidden"><h2 className="text-2xl font-semibold text-slate-900">{slides[page].title}</h2><div className="mt-6 grid grid-cols-2 gap-5"><div className="space-y-2">{slides[page].lines.slice(1).map((line, index) => <p key={index} className="text-sm text-slate-700">{line}</p>)}</div><div className="grid grid-cols-2 gap-2">{slides[page].images.map((src) => <img key={src} src={src} className="max-w-full max-h-40 object-contain"/>)}</div></div></div>}</div></> : <div className="m-auto text-center"><FileText size={38} className="mx-auto text-slate-400"/><div className="mt-3 text-sm text-slate-600">该类型文件请下载后查看</div><button onClick={download} className="mt-3 h-8 px-3 rounded bg-[#0052D9] text-white text-xs">下载文件</button></div>}</div></div></div>;
}