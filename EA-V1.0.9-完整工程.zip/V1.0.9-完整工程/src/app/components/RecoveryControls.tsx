import { useState } from "react";
import { FilePlus2, RotateCcw, Undo2 } from "lucide-react";
import { currentUser } from "./data";
import { activeRecovery, canReopenRecord, canReturnRecord, needsCorrection, recoveryDifferences, type Recoverable, type RecoveryAction, type RecoveryEntry, type RecoveryFile } from "./recordRecovery";
import { AttachmentInput } from "./AttachmentInput";
import { TaskAttachmentList } from "./TaskAttachmentList";
import { TaskDialog } from "./TaskDialog";

export type { RecoveryAction } from "./recordRecovery";
const labels = { reopen: "重新处理", return: "退回整改", supplement: "补充记录" };
const buttonStyle = "inline-flex h-7 shrink-0 items-center gap-1.5 rounded-md border border-slate-200 bg-white px-2 text-[11px] text-slate-600 hover:border-blue-300 hover:text-[#0052D9] disabled:cursor-not-allowed disabled:opacity-40";

export function RecoveryBadge({ record }: { record: Recoverable }) {
  return needsCorrection(record) ? <span className="inline-flex shrink-0 rounded border border-amber-200 bg-amber-50 px-1.5 py-0.5 text-[10px] font-medium text-amber-700">待整改</span> : null;
}

export function RecoveryActions({ record, owner, title, completed, active, blocked, parentClosed, reviewed, isCase = false, allowReturn = true, onAction }: {
  record: Recoverable; owner: string; title: string; completed: boolean; active: boolean;
  blocked?: string; parentClosed?: boolean; reviewed?: string; isCase?: boolean; allowReturn?: boolean;
  onAction: (action: RecoveryAction, text: string, files: RecoveryFile[], dueDate?: string) => void;
}) {
  const [action, setAction] = useState<RecoveryAction | null>(null);
  const [text, setText] = useState("");
  const [files, setFiles] = useState<RecoveryFile[]>([]);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState("");
  const [dueDate, setDueDate] = useState("");
  const ownerAction = owner === currentUser.name;
  const pending = activeRecovery(record);
  const submit = () => {
    if (!action || uploading) return;
    try { onAction(action, text, files, action === "return" ? dueDate : undefined); setAction(null); setError(""); }
    catch (cause) { setError(cause instanceof Error ? cause.message : "保存失败，请重试。"); }
  };
  const options = [
    { action: "supplement" as const, show: ownerAction && completed, Icon: FilePlus2 },
    { action: "reopen" as const, show: canReopenRecord(owner) && completed && !pending, Icon: RotateCcw },
    { action: "return" as const, show: allowReturn && canReturnRecord(owner) && (active || completed) && !pending, Icon: Undo2 },
  ];
  return <>
    {options.filter(option => option.show).map(({ action: value, Icon }) => {
      const disabled = blocked || (parentClosed && value !== "supplement" ? "请先重新开启所属 Case" : undefined);
      return <button key={value} type="button" className={buttonStyle} disabled={Boolean(disabled)} title={disabled || (value === "reopen" ? "与负责人线下沟通后，由直属主管确认重新处理" : labels[value])} onClick={() => { setAction(value); setText(""); setFiles([]); setDueDate(""); setError(""); }}><Icon size={12} />{labels[value]}</button>;
    })}
    {action && <TaskDialog title={labels[action]} description={title} onClose={() => setAction(null)} footer={<><button className={buttonStyle} onClick={() => setAction(null)}>取消</button><button className="h-8 rounded-md bg-[#0052D9] px-4 text-xs text-white disabled:opacity-40" disabled={!text.trim() || uploading} onClick={submit}>确认提交</button></>}>
      {action === "supplement" ? <p className="mb-3 text-xs text-slate-500">追加说明和附件，不覆盖原结论或改变完成状态。</p> : <div className="mb-3 space-y-1 text-xs text-slate-500"><p>负责人：{owner} · 保留原编号、内容与历史记录</p>{action === "reopen" && <p>请确认已与负责人线下沟通；确认后由负责人在原文档中修改。</p>}{isCase && completed && <p className="text-amber-700">提交后将重新开启 Case；不会自动重开其他任务或撤回 Fanout。</p>}{isCase && reviewed && <p>再次结案仍需原审核人 {reviewed} 确认。</p>}{isCase && <p>根因或改善方案变化时，请核对对已分发产品的影响。</p>}</div>}
      <label className="block text-xs text-slate-600">{action === "return" ? "整改要求" : action === "reopen" ? "重新处理原因" : "补充说明"}<textarea autoFocus aria-label={action === "return" ? "整改要求" : action === "reopen" ? "重新处理原因" : "补充说明"} value={text} onChange={event => setText(event.target.value)} maxLength={2000} className="mt-2 h-28 w-full resize-y rounded-md border border-slate-200 p-3 text-sm outline-none focus:border-[#0052D9]" /></label>
      {action === "supplement" && <div className="mt-3"><AttachmentInput value={files} onChange={setFiles} onUploadingChange={setUploading} /></div>}
      {action === "return" && <label className="mt-3 flex items-center gap-3 text-xs text-slate-500">期望反馈日期（选填）<input type="date" aria-label="期望反馈日期" value={dueDate} onChange={event => setDueDate(event.target.value)} className="h-8 rounded-md border border-slate-200 px-2" /></label>}
      {error && <p role="alert" className="mt-2 text-xs text-red-600">{error}</p>}
    </TaskDialog>}
  </>;
}

export function RecoveryHistoryEntry({ entry, showProgress = false }: { entry: RecoveryEntry; showProgress?: boolean }) {
  const differences = showProgress && entry.submittedAt ? recoveryDifferences(entry) : [];
  return <>
    <p className="mt-1 whitespace-pre-wrap break-words text-xs leading-5 text-slate-600">{entry.reason}</p>
    {showProgress && entry.kind !== "supplement" && <div className="mt-1 flex flex-wrap gap-x-3 gap-y-1 text-[11px] text-slate-500">
      {!entry.completedAt && <span>{entry.submittedAt ? "已提交整改结果" : entry.startedAt ? "处理中" : "待处理"}</span>}
      {entry.dueDate && <span>期望反馈：{entry.dueDate}</span>}
      {entry.lastEditedAt && <span>最近修改：{new Date(entry.lastEditedAt).toLocaleString("zh-CN")}</span>}
    </div>}
    {entry.outcome && <p className="mt-1 whitespace-pre-wrap text-xs leading-5">历史处理说明：{entry.outcome}</p>}
    {entry.completedAt && <p className="mt-1 text-xs text-emerald-700">再次完成于 {new Date(entry.completedAt).toLocaleString("zh-CN")}</p>}
    {entry.files?.length ? <TaskAttachmentList attachments={entry.files} /> : null}
    {showProgress && entry.submittedAt && <details className="mt-2 text-xs"><summary className="cursor-pointer text-[#0052D9]">已提交整改结果 · {new Date(entry.submittedAt).toLocaleString("zh-CN")}</summary><div className="mt-2 space-y-2">
      {differences.map((change, index) => <div key={index} className="grid grid-cols-2 gap-4"><div className="min-w-0 whitespace-pre-wrap break-words text-slate-500">{change.field}（处理前）：{change.before}</div><div className="min-w-0 whitespace-pre-wrap break-words text-slate-700">本次提交：{change.after}</div></div>)}
      {!differences.length && <p>未记录可比对的内容变化，请查看原文档。</p>}
    </div></details>}
    {entry.before && <details className="mt-2 text-xs"><summary className="cursor-pointer text-[#0052D9]">查看处理前记录</summary><div className="mt-2 space-y-1 text-slate-500"><p>原状态：{String(entry.before.status ?? entry.before.state ?? "未记录")}</p><p>原完成时间：{String(entry.before.closedAt ?? entry.before.updatedAt ?? "见原流转记录")}</p><p className="whitespace-pre-wrap break-words">原结论：{String(entry.before.conclusion ?? "未记录")}</p><a className="inline-block text-[#0052D9] underline" href={`data:application/json;charset=utf-8,${encodeURIComponent(JSON.stringify(entry.before, null, 2))}`} download={`处理前记录-${entry.id}.json`}>下载完整原始记录</a></div></details>}
  </>;
}

export function RecoveryHistory({ record }: { record: Recoverable }) {
  const active = activeRecovery(record);
  if (!record.recovery?.length) return null;
  return <section aria-label="重新处理与补充记录" className="my-3 space-y-2 text-xs">
    {active && <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-500"><span>{active.submittedAt ? "已提交整改结果" : active.startedAt ? "处理中" : "待处理"}</span>{active.dueDate && <span>期望反馈：{active.dueDate}</span>}{active.lastEditedAt && <span>最近修改：{new Date(active.lastEditedAt).toLocaleString("zh-CN")}</span>}</div>}
    {record.recovery.filter(entry => entry.submittedAt).map(entry => <details key={`feedback-${entry.id}`} className="border-b border-slate-100 pb-2"><summary className="cursor-pointer text-[#0052D9]">已提交整改结果 · {new Date(entry.submittedAt!).toLocaleString("zh-CN")}</summary><div className="mt-2 space-y-2">{recoveryDifferences(entry).map((change, index) => <div key={index} className="grid grid-cols-2 gap-4"><div className="min-w-0 whitespace-pre-wrap break-words text-slate-500">{change.field}（处理前）：{change.before}</div><div className="min-w-0 whitespace-pre-wrap break-words text-slate-700">本次提交：{change.after}</div></div>)}{!recoveryDifferences(entry).length && <p>未记录可比对的内容变化，请查看原文档。</p>}</div></details>)}
    {active && <div className="border-l-2 border-amber-400 bg-amber-50/60 px-3 py-2 text-slate-700"><div className="mb-1 flex flex-wrap items-center gap-2"><b>{active.kind === "return" ? "待整改" : "重新处理中"}</b><span className="text-[11px] text-slate-500">{active.by} · {new Date(active.at).toLocaleString("zh-CN")}</span></div><p className="whitespace-pre-wrap break-words leading-5">{active.reason}</p></div>}
    <details className="border-t border-slate-100 pt-2"><summary className="cursor-pointer text-slate-500">重新处理与补充记录 · {record.recovery.length}</summary><div className="mt-2 space-y-3">{[...record.recovery].reverse().map(entry => <div key={entry.id} className="border-l border-slate-200 pl-3"><div className="text-slate-600">{entry.kind === "return" ? "退回整改" : entry.kind === "reopen" ? "重新处理" : "补充记录"} · {entry.by} · {new Date(entry.at).toLocaleString("zh-CN")}</div><RecoveryHistoryEntry entry={entry} /></div>)}</div></details>
  </section>;
}