import { useRef, useState } from "react";
import { RotateCcw } from "lucide-react";
import { TaskDialog } from "./TaskDialog";
import { REWORK_REASON_LIMIT } from "./taskRework";

export function ReworkTaskModal({ title, onClose, onConfirm }: { title: string; onClose: () => void; onConfirm: (reason: string) => void }) {
  const [reason, setReason] = useState("");
  const [error, setError] = useState("");
  const submitting = useRef(false);
  const confirm = () => {
    if (!reason.trim() || submitting.current) return;
    submitting.current = true;
    try { onConfirm(reason.trim()); onClose(); }
    catch (cause) { setError(cause instanceof Error ? cause.message : "退回失败，请重试。"); }
    finally { submitting.current = false; }
  };
  return <TaskDialog title="退回重做" description="任务将从已完成恢复为进行中，继续由原负责人处理。已有结论、分析过程、附件与评论保留，退回原因写入日志。" onClose={onClose} footer={<>
    <button type="button" onClick={onClose} className="h-9 rounded-md border border-slate-200 px-4 text-xs text-slate-600">取消</button>
    <button type="button" disabled={!reason.trim()} onClick={confirm} className="inline-flex h-9 items-center gap-1.5 rounded-md border border-[#0052D9]/25 bg-blue-50 px-4 text-xs text-[#0052D9] disabled:opacity-40"><RotateCcw size={13} />确认退回重做</button>
  </>}>
    <div className="mb-4 rounded-lg border border-slate-200 bg-slate-50 p-3 text-sm text-slate-700">{title}</div>
    <label className="block text-xs text-slate-600">退回原因 <span className="text-red-400">*</span><textarea autoFocus required aria-label="退回重做原因" maxLength={REWORK_REASON_LIMIT} value={reason} onChange={(event) => { setReason(event.target.value); setError(""); }} placeholder="说明需要补充或重新处理的内容…" className="mt-2 min-h-[110px] w-full rounded-lg border border-slate-200 p-3 text-sm leading-relaxed outline-none focus:border-[#0052D9]" /></label>
    {error && <p role="alert" className="mt-3 text-xs text-red-600">{error}</p>}
  </TaskDialog>;
}