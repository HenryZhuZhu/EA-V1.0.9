import { useEffect, useRef } from "react";
import TEAM_QUALITY_DASHBOARD_SRCDOC from "./teamQualityDashboard.html?raw";

interface Props {
  onOpenCase: (id: string) => void;
  onOpenCases: () => void;
}

interface DashboardMessage {
  source: "ea-team-dashboard";
  type: "open-case" | "open-cases";
  caseId?: string;
}

export function ManagerView({ onOpenCase, onOpenCases }: Props) {
  const iframeRef = useRef<HTMLIFrameElement>(null);

  useEffect(() => {
    const handleMessage = (event: MessageEvent<DashboardMessage>) => {
      if (event.source !== iframeRef.current?.contentWindow || event.data?.source !== "ea-team-dashboard") return;
      if (event.data.type === "open-cases") onOpenCases();
      if (event.data.type === "open-case" && event.data.caseId) onOpenCase(event.data.caseId);
    };

    window.addEventListener("message", handleMessage);
    return () => window.removeEventListener("message", handleMessage);
  }, [onOpenCase, onOpenCases]);

  return (
    <iframe
      ref={iframeRef}
      title="团队看板"
      srcDoc={TEAM_QUALITY_DASHBOARD_SRCDOC}
      style={{ width: "100%", height: "calc(100vh - 56px)", border: "none", display: "block", background: "#F5F7FA" }}
    />
  );
}
