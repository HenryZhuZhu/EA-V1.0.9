// caseInsights.ts —— 本地启发式「AI」：Case 相似度、关联建议、归纳成簇建议（无后端，mock 智能）。
import { CaseItem, CaseLinkType, ObjectType, caseProductOf, OBJECT_TYPES } from "./data";

const STOP = new Set(["的", "在", "与", "和", "了", "批量", "异常", "问题", "case"]);
function tokens(s?: string): Set<string> {
  if (!s) return new Set();
  const parts = s.toLowerCase().split(/[^0-9a-z\u4e00-\u9fa5]+/).filter((t) => t.length >= 2 && !STOP.has(t));
  return new Set(parts);
}
function jaccard(a: Set<string>, b: Set<string>): number {
  if (!a.size && !b.size) return 0;
  let inter = 0;
  a.forEach((t) => { if (b.has(t)) inter += 1; });
  const uni = new Set([...a, ...b]).size;
  return uni ? inter / uni : 0;
}

// 综合相似度 0..1：同 objectType 0.35 + 同产品 0.15 + 失效模式文本 0.3 + 失效阶段/平台 各 0.1
export function caseSimilarity(a: CaseItem, b: CaseItem): number {
  const pa = caseProductOf(a), pb = caseProductOf(b);
  let s = 0;
  if (pa && pb && pa.objectType === pb.objectType) s += 0.35;
  if (a.product && a.product === b.product) s += 0.15;
  s += 0.3 * jaccard(tokens(a.failMode), tokens(b.failMode));
  if (a.failStage && a.failStage === b.failStage && a.failStage !== "—") s += 0.1;
  if (a.failPlatform && a.failPlatform === b.failPlatform) s += 0.1;
  return Math.min(1, s);
}

export interface RelatedSuggestion { caseId: string; score: number; type: CaseLinkType; reason: string }
// 对单个 Case 建议弱链接候选（高分→重复，中分→关联）
export function suggestRelatedCases(target: CaseItem, all: CaseItem[], min = 0.45): RelatedSuggestion[] {
  return all
    .filter((c) => c.id !== target.id)
    .map((c) => ({ c, score: caseSimilarity(target, c) }))
    .filter((x) => x.score >= min)
    .sort((a, b) => b.score - a.score)
    .slice(0, 5)
    .map(({ c, score }) => {
      const same: string[] = [];
      const pa = caseProductOf(target), pb = caseProductOf(c);
      if (pa && pb && pa.objectType === pb.objectType) same.push(`对象类型同为 ${pa.objectType}`);
      if (target.product && target.product === c.product) same.push(`产品同为 ${target.product}`);
      if (target.failMode && target.failMode === c.failMode) same.push(`失效模式同为 ${target.failMode}`);
      else if (jaccard(tokens(target.failMode), tokens(c.failMode)) > 0) same.push("失效模式关键词重合");
      if (target.failStage && target.failStage === c.failStage && target.failStage !== "—") same.push(`失效阶段同为 ${target.failStage}`);
      if (target.failPlatform && target.failPlatform === c.failPlatform) same.push(`失效平台同为 ${target.failPlatform}`);
      return {
        caseId: c.id, score,
        type: (score >= 0.7 ? "重复" : "关联") as CaseLinkType,
        reason: same.length ? same.join("；") : "标题与失效特征相近",
      };
    });
}

export interface DraftCaseSimilarityInput {
  name: string;
  background: string;
  product?: string;
  material?: string;
  problemDomain?: string;
  problemType?: string;
  failMode?: string;
  failStage?: string;
  failPlatform?: string;
}

function semanticTokens(value?: string): Set<string> {
  if (!value) return new Set();
  const normalized = value.toLowerCase();
  const result = new Set<string>();
  normalized.match(/[0-9a-z][0-9a-z._-]+/g)?.forEach((token) => result.add(token));
  normalized.match(/[\u4e00-\u9fa5]+/g)?.forEach((sequence) => {
    if (sequence.length === 1) result.add(sequence);
    for (let index = 0; index < sequence.length - 1; index += 1) {
      result.add(sequence.slice(index, index + 2));
    }
  });
  return result;
}

function normalizedTextSimilarity(left?: string, right?: string): number {
  return jaccard(semanticTokens(left), semanticTokens(right));
}

function materialFamily(value?: string): "IC" | "Wafer" | "Module" | "Other" | undefined {
  if (!value) return undefined;
  if (/dimm|camm|module|模组/i.test(value)) return "Module";
  if (/wafer|晶圆/i.test(value)) return "Wafer";
  if (/die|\bic\b|xdie|颗粒|芯片/i.test(value)) return "IC";
  return "Other";
}

export function suggestRelatedCasesForDraft(
  draft: DraftCaseSimilarityInput,
  all: CaseItem[],
  min = 0.45,
): RelatedSuggestion[] {
  return all
    .map((candidate) => {
      let matchedWeight = 0;
      let availableWeight = 0;
      const reasons: string[] = [];
      const addSignal = (weight: number, matched: boolean, reason: string) => {
        availableWeight += weight;
        if (!matched) return;
        matchedWeight += weight;
        reasons.push(reason);
      };

      const draftText = [draft.name, draft.background].filter(Boolean).join(" ");
      const candidateText = [candidate.name, candidate.reason, candidate.background].filter(Boolean).join(" ");
      const textScore = normalizedTextSimilarity(draftText, candidateText);
      availableWeight += 0.3;
      matchedWeight += 0.3 * textScore;
      if (textScore >= 0.2) reasons.push("名称 / 背景关键词相近");

      if (draft.product) {
        addSignal(0.15, draft.product === candidate.product, `产品同为 ${draft.product}`);
        const draftProduct = caseProductOf({ product: draft.product });
        const candidateProduct = caseProductOf(candidate);
        if (draftProduct) addSignal(0.1, !!candidateProduct && draftProduct.objectType === candidateProduct.objectType, `对象类型同为 ${draftProduct.objectType}`);
      }
      if (draft.material) addSignal(0.1, materialFamily(draft.material) === materialFamily(candidate.material), `物料类型同为 ${materialFamily(draft.material)}`);
      if (draft.problemDomain) addSignal(0.1, draft.problemDomain === candidate.problemDomain, `Domain 同为 ${draft.problemDomain}`);
      if (draft.problemType) addSignal(0.1, draft.problemType === candidate.problemType, `问题类型同为 ${draft.problemType}`);
      if (draft.failMode) {
        availableWeight += 0.15;
        const failModeScore = normalizedTextSimilarity(draft.failMode, candidate.failMode);
        matchedWeight += 0.15 * failModeScore;
        if (failModeScore >= 0.25) reasons.push("Fail Mode 关键词重合");
      }
      if (draft.failStage) addSignal(0.05, draft.failStage === candidate.failStage, `Fail Stage 同为 ${draft.failStage}`);
      if (draft.failPlatform) addSignal(0.05, draft.failPlatform === candidate.failPlatform, `失效平台同为 ${draft.failPlatform}`);

      return {
        candidate,
        score: availableWeight > 0 ? matchedWeight / availableWeight : 0,
        reason: reasons.length ? reasons.join("；") : "名称与问题描述相近",
      };
    })
    .filter(({ score }) => score >= min)
    .sort((left, right) => right.score - left.score)
    .slice(0, 5)
    .map(({ candidate, score, reason }) => ({
      caseId: candidate.id,
      score,
      type: score >= 0.7 ? "重复" : "关联",
      reason,
    }));
}

export interface GroupSuggestion { caseIds: string[]; suggestedName: string; objectType: ObjectType; score: number }
// 把互相高相似的 Case 聚成簇（并查集），建议「归纳为一个 Issue」
export function suggestIssueGroups(all: CaseItem[], min = 0.5): GroupSuggestion[] {
  const parent: Record<string, string> = {};
  const find = (x: string): string => (parent[x] === x || !parent[x] ? (parent[x] = parent[x] ?? x) : (parent[x] = find(parent[x])));
  all.forEach((c) => { parent[c.id] = c.id; });
  const scores: Record<string, number> = {};
  for (let i = 0; i < all.length; i++) {
    for (let j = i + 1; j < all.length; j++) {
      const s = caseSimilarity(all[i], all[j]);
      if (s >= min) {
        const ra = find(all[i].id), rb = find(all[j].id);
        if (ra !== rb) parent[ra] = rb;
        scores[all[i].id] = Math.max(scores[all[i].id] ?? 0, s);
        scores[all[j].id] = Math.max(scores[all[j].id] ?? 0, s);
      }
    }
  }
  const clusters: Record<string, CaseItem[]> = {};
  all.forEach((c) => { const r = find(c.id); (clusters[r] ??= []).push(c); });
  return Object.values(clusters)
    .filter((cs) => cs.length >= 2)
    .map((cs) => {
      // 建议名：主 objectType + 最高频失效模式关键词
      const otCount: Record<string, number> = {};
      cs.forEach((c) => { const ot = caseProductOf(c)?.objectType; if (ot) otCount[ot] = (otCount[ot] ?? 0) + 1; });
      const objectType = (Object.entries(otCount).sort((a, b) => b[1] - a[1])[0]?.[0] as ObjectType) ?? OBJECT_TYPES[2];
      const modeCount: Record<string, number> = {};
      cs.forEach((c) => tokens(c.failMode).forEach((t) => { modeCount[t] = (modeCount[t] ?? 0) + 1; }));
      const topMode = Object.entries(modeCount).sort((a, b) => b[1] - a[1])[0]?.[0];
      const avg = cs.reduce((s, c) => s + (scores[c.id] ?? 0), 0) / cs.length;
      return {
        caseIds: cs.map((c) => c.id),
        suggestedName: `${objectType} · ${topMode ? topMode + " " : ""}共性失效`,
        objectType, score: avg,
      };
    })
    .sort((a, b) => b.score - a.score);
}
