import { useState, useMemo, useCallback, useEffect, useRef } from "react";
import {
  ReactFlow,
  Node,
  Edge,
  Background,
  MiniMap,
  useNodesState,
  useEdgesState,
  NodeTypes,
  ReactFlowInstance,
  Handle,
  Position,
} from "@xyflow/react";
import "@xyflow/react/dist/style.css";
import { MindMapZoomPill } from "./MindMapZoomPill";
import { Plus, Trash2, Edit2, User, Shield, Calendar, Users, X, Check, CheckCircle2, Maximize2, Minimize2, MousePointer2, Eye, AlarmClock, Flag, MoveVertical, MoveHorizontal, Tag, Radar, FlaskConical, ExternalLink, Link2, Copy } from "lucide-react";
import { CaseItem, Urgency, ownerToDepartment, urgencyBar, currentUser, TASK_TYPES, TaskType, BALL_TYPES, PROBLEM_DOMAINS, mockProducts, productById, EfaAnalysisCard, genEfaCode, mockCases, flattenTasks } from "./data";
import { ActionCard, ThoughtGroup } from "./CreateCase";
import { AttachmentInput } from "./AttachmentInput";
import { VoicePlayer, VoiceRecorder } from "./VoiceNote";
import { StatusBadge } from "./StatusBadge";
import { CaseProductPill } from "./CaseProductPill";
import { EfaOrderModal, EfaInlineFields } from "./EfaOrderModal";
import { TaskAssigneeField } from "./TaskAssigneeField";
import { CoverageOwnerFields, CoveragePatternFields } from "./CoveragePatternFields";
import { RelationTask, TaskRelationPicker } from "./TaskRelationPicker";

// ---- 思路模板：因为__原理说明__所以__（与 case 详情导图一致的填写引导）----
const THOUGHT_CATEGORIES = [...PROBLEM_DOMAINS, "Other"];
const MM_DEPARTMENTS = ["PTE", "CP", "FT", "DA", "PE", "QA", "EFA", "RD", "PM"];
const CREATE_STATUS_OPTIONS = ["全部", "待接受", "进行中", "已完成", "已中止", "已拒绝"];
const THOUGHT_PLACEHOLDER = "新的思路/怀疑方向";
const MM_CREATE_SPOTLIGHT_KEY = "ea_mm_create_spotlight_v13";
const COACH_DELAY = {
  NEW_TASK_READY: 520,
  FIRST_TASK_SAVED: 900,
  EXTRA_TASK_SAVED: 760,
} as const;
type Direction = "LR" | "TB";
type CreateViewMode = "all" | "incomplete" | "valid";
type CoachStep = "zoom" | "minimap" | "toolbar" | "caseRoot" | "thoughtCategory" | "thought" | "thoughtResult" | "task" | "urgencyCard" | "legend" | "addTask" | "extraTask" | "more" | "nested";
const COACH_STEPS: CoachStep[] = ["zoom", "minimap", "toolbar", "caseRoot", "thoughtCategory", "thought", "thoughtResult", "task", "urgencyCard", "legend", "addTask", "extraTask", "more", "nested"];

const COACH_CONTENT: Record<CoachStep, { index: number; title: string; description: string; target: string }> = {
  zoom: {
    index: 1,
    title: "缩放控件",
    description: "放大 / 缩小 / 100%，随时调整画布视野。",
    target: '[data-create-guide="zoom-pill"]',
  },
  minimap: {
    index: 2,
    title: "缩略图",
    description: "点击拖动，快速定位。",
    target: ".create-case-flow .react-flow__minimap",
  },
  toolbar: {
    index: 3,
    title: "顶部工具栏",
    description: "切换视图、筛选任务或调整布局。",
    target: '[data-create-guide="toolbar"]',
  },
  caseRoot: {
    index: 4,
    title: "Case 根节点",
    description: "Case 基本信息汇总在这里。",
    target: '[data-create-guide="case-root"]',
  },
  thoughtCategory: {
    index: 5,
    title: "选择思路分类",
    description: "选择设计、工艺、测试或其他。",
    target: '[data-create-guide="thought-category"]',
  },
  thought: {
    index: 6,
    title: "填写怀疑依据",
    description: "先填写「因为」，说明观察到的现象。",
    target: '[data-create-guide="thought-input"]',
  },
  thoughtResult: {
    index: 7,
    title: "填写怀疑结论",
    description: "填写「所以」，然后确认思路。",
    target: '[data-create-guide="thought-result"]',
  },
  task: {
    index: 8,
    title: "填写第一个任务",
    description: "填写相关信息；右上角可选择 FSA 分析、测试程式分析等任务类型。点击确认创建任务。",
    target: '[data-create-guide="task"]',
  },
  urgencyCard: {
    index: 9,
    title: "查看紧急程度",
    description: "任务卡左侧色条表示紧急程度。",
    target: '[data-create-guide="urgency-bar"]',
  },
  legend: {
    index: 10,
    title: "理解紧急程度",
    description: "图例颜色与任务卡色条一一对应。",
    target: '[data-create-guide="legend"]',
  },
  addTask: {
    index: 11,
    title: "添加更多任务",
    description: "点击思路卡上的蓝色加号，再添加一个任务。",
    target: '[data-create-guide="add-task"]',
  },
  extraTask: {
    index: 12,
    title: "填写新任务",
    description: "填写相关信息，点击确认，创建任务。",
    target: '[data-create-guide="task"]',
  },
  more: {
    index: 13,
    title: "添加更多思路",
    description: "点击「新建思路」，增加并列排查方向。",
    target: '[data-create-guide="case-add-thought"]',
  },
  nested: {
    index: 14,
    title: "添加更多细节思路",
    description: "点击蓝色加号，添加更多子思路。",
    target: '[data-create-guide="saved-task"]',
  },
};
function composeThought(parts: [string, string, string]): string {
  const [a, b, c] = parts.map((s) => (s || "").trim());
  if (!a && !b && !c) return "";
  return `因为${a}，原理说明${b}，所以${c}。`;
}
function parseThought(title: string): [string, string, string] {
  if (!title || title === THOUGHT_PLACEHOLDER) return ["", "", ""];
  const normalized = title.endsWith("。") ? title.slice(0, -1) : title;
  const m = normalized.match(/^因为([\s\S]*)，原理说明([\s\S]*)，所以([\s\S]*)$/);
  if (m) return [m[1], m[2], m[3]];
  return [title, "", ""];
}
function efaDefaults(caseData: CaseItem): EfaAnalysisCard {
  return {
    stage: caseData.failStage && caseData.failStage !== "—" ? caseData.failStage : "",
    package: caseData.failPackage && caseData.failPackage !== "—" ? caseData.failPackage : "",
    quality: caseData.ppm && caseData.ppm !== "—" ? `${caseData.ppm}${/ppm/i.test(caseData.ppm) ? "" : " PPM"}` : "",
    failRate: caseData.failRatio && caseData.failRatio !== "—" ? caseData.failRatio : "",
    chipList: [{ fsa: "", map: "", failMode: caseData.failMode === "—" ? "" : caseData.failMode, waferNo: "", chipNo: "", markCode: "" }],
  };
}
interface Props {
  caseData: CaseItem;
  thoughtGroups: ThoughtGroup[];
  onGroupsChange: (groups: ThoughtGroup[]) => void;
  coachEnabled?: boolean;
}

export function CreateCaseMindMapFlow({ caseData, thoughtGroups, onGroupsChange, coachEnabled = true }: Props) {
  const canvasRef = useRef<HTMLDivElement>(null);
  const [fullscreen, setFullscreen] = useState(false);
  const [direction, setDirection] = useState<Direction>("LR");
  const [viewMode, setViewMode] = useState<CreateViewMode>("all");
  const [onlyMine, setOnlyMine] = useState(false);
  const [statusFilter, setStatusFilter] = useState("全部");
  const [deptFilter, setDeptFilter] = useState("全部");
  const [collapsed, setCollapsed] = useState<Set<string>>(new Set());
  const [flowInstance, setFlowInstance] = useState<ReactFlowInstance | null>(null);
  const [manualPos, setManualPos] = useState<Record<string, { x: number; y: number }>>({});
  const [editingThought, setEditingThought] = useState<string | null>(null);
  const [editingAction, setEditingAction] = useState<string | null>(null);
  const [thoughtText, setThoughtText] = useState("");
  const [thoughtCategory, setThoughtCategory] = useState("Testing");
  const [thoughtSourceTaskIds, setThoughtSourceTaskIds] = useState<string[]>([]);
  const [actionForm, setActionForm] = useState<Partial<ActionCard>>({});
  const seededRef = useRef(false);
  const initialActionIdRef = useRef<string | null>(null);
  const coachAdvanceTimerRef = useRef<number | null>(null);

  useEffect(() => () => {
    if (coachAdvanceTimerRef.current !== null) window.clearTimeout(coachAdvanceTimerRef.current);
  }, []);

  // ---- 新建 Case 专用 Spotlight 引导：首次自动出现，填写动作会推进步骤 ----
  const [coach, setCoach] = useState<{ active: boolean; step: CoachStep }>(() => {
    if (!coachEnabled) return { active: false, step: "zoom" };
    try {
      return { active: !localStorage.getItem(MM_CREATE_SPOTLIGHT_KEY), step: "zoom" };
    } catch {
      return { active: true, step: "zoom" };
    }
  });
  const closeCoach = (dontShowAgain: boolean) => {
    if (dontShowAgain) {
      try { localStorage.setItem(MM_CREATE_SPOTLIGHT_KEY, "1"); } catch {}
    }
    setCoach((c) => ({ ...c, active: false }));
  };

  const allActions = useMemo(() => {
    const actions: ActionCard[] = [];
    const collect = (groups: ThoughtGroup[]) => groups.forEach((group) => group.actions.forEach((action) => {
      actions.push(action);
      if (action.childGroups?.length) collect(action.childGroups);
    }));
    collect(thoughtGroups);
    return actions;
  }, [thoughtGroups]);
  const relationTasks = useMemo<RelationTask[]>(() => {
    const items: RelationTask[] = [];
    const collect = (groups: ThoughtGroup[]) => groups.forEach((group) => group.actions.forEach((action) => {
      items.push({ id: action.id, title: action.title, groupTitle: group.thought || "未命名思路", owner: action.assignee || "待指派", status: "待创建", expectation: action.expectation, isPatternFanout: group.thought.includes("Pattern Fanout"), speed: action.coverageSpeed, tester: action.coverageTester, ballType: action.coverageBallType, qg: action.coverageQG });
      if (action.childGroups?.length) collect(action.childGroups);
    }));
    collect(thoughtGroups);
    return items;
  }, [thoughtGroups]);
  const deptOptions = useMemo(
    () => ["全部", ...Array.from(new Set(allActions.map((action) => action.department).filter(Boolean)))],
    [allActions]
  );
  const collapsibleActionIds = useMemo(
    () => allActions.filter((action) => action.childGroups?.length).map((action) => action.id),
    [allActions]
  );

  // 后续新建思路只创建思路；首屏的首个任务由初始化逻辑单独预置
  const addThoughtGroup = () => {
    const newGroup: ThoughtGroup = {
      id: `group-${Date.now()}`,
      thought: "新的思路/怀疑方向",
      category: "Testing",
      actions: [],
    };

    onGroupsChange([...thoughtGroups, newGroup]);

    setThoughtText("");
    setThoughtCategory("Testing");
    setThoughtSourceTaskIds([]);
    setEditingThought(newGroup.id);
  };

  // Update thought
  const updateThought = (groupId: string, newThought: string, newCategory?: string, sourceTaskIds?: string[]) => {
    const updateInGroups = (groups: ThoughtGroup[]): ThoughtGroup[] => {
      return groups.map((g) => {
        if (g.id === groupId) {
          return { ...g, thought: newThought, category: newCategory ?? g.category, sourceTaskIds: sourceTaskIds ?? g.sourceTaskIds };
        }
        return {
          ...g,
          actions: g.actions.map((a) => ({
            ...a,
            childGroups: a.childGroups ? updateInGroups(a.childGroups) : a.childGroups,
          })),
        };
      });
    };
    onGroupsChange(updateInGroups(thoughtGroups));
    setEditingThought(null);
    if (newThought.trim()) {
      const currentGroup = thoughtGroups.find((group) => group.id === groupId);
      const initialAction = currentGroup?.actions.find((action) => action.id === initialActionIdRef.current) ?? currentGroup?.actions[0];
      if (initialAction && initialAction.title === "新执行任务") {
        setActionForm(initialAction);
        setEditingAction(initialAction.id);
      }
      setCoach((c) => (c.active && (c.step === "thought" || c.step === "thoughtResult") ? { ...c, step: "task" } : c));
    }
  };

  // Delete group
  const deleteGroup = (groupId: string) => {
    const deleteFromGroups = (groups: ThoughtGroup[]): ThoughtGroup[] => {
      return groups.filter((g) => g.id !== groupId).map((g) => ({
        ...g,
        actions: g.actions.map((a) => ({
          ...a,
          childGroups: a.childGroups ? deleteFromGroups(a.childGroups) : a.childGroups,
        })),
      }));
    };
    onGroupsChange(deleteFromGroups(thoughtGroups));
  };

  // Add action (enters edit mode automatically)
  const addAction = (groupId: string) => {
    const newActionId = `action-${Date.now()}`;
    const newAction: ActionCard = {
      id: newActionId,
      title: "新执行任务",
      urgency: "一般",
      department: "PTE",
      assignee: "",
      dueDate: "",
      note: "",
    };
    const addToGroups = (groups: ThoughtGroup[]): ThoughtGroup[] => {
      return groups.map((g) => {
        if (g.id === groupId) {
          return { ...g, actions: [...g.actions, newAction] };
        }
        return {
          ...g,
          actions: g.actions.map((a) => ({
            ...a,
            childGroups: a.childGroups ? addToGroups(a.childGroups) : a.childGroups,
          })),
        };
      });
    };
    onGroupsChange(addToGroups(thoughtGroups));
    // Auto-enter edit mode
    setActionForm(newAction);
    setEditingAction(newActionId);
    if (coachAdvanceTimerRef.current !== null) window.clearTimeout(coachAdvanceTimerRef.current);
    coachAdvanceTimerRef.current = window.setTimeout(() => {
      setCoach((c) => (c.active && c.step === "addTask" ? { ...c, step: "extraTask" } : c));
      coachAdvanceTimerRef.current = null;
    }, COACH_DELAY.NEW_TASK_READY);
  };

  // Delete action
  const deleteAction = (groupId: string, actionId: string) => {
    const deleteFromGroups = (groups: ThoughtGroup[]): ThoughtGroup[] => {
      return groups.map((g) => {
        if (g.id === groupId) {
          return { ...g, actions: g.actions.filter((a) => a.id !== actionId) };
        }
        return {
          ...g,
          actions: g.actions.map((a) => ({
            ...a,
            childGroups: a.childGroups ? deleteFromGroups(a.childGroups) : a.childGroups,
          })),
        };
      });
    };
    onGroupsChange(deleteFromGroups(thoughtGroups));
  };

  // Update action
  const updateAction = (groupId: string, actionId: string, updates: Partial<ActionCard>) => {
    const updateInGroups = (groups: ThoughtGroup[]): ThoughtGroup[] => {
      return groups.map((g) => {
        if (g.id === groupId) {
          return {
            ...g,
            actions: g.actions.map((a) => (a.id === actionId ? { ...a, ...updates } : a)),
          };
        }
        return {
          ...g,
          actions: g.actions.map((a) => ({
            ...a,
            childGroups: a.childGroups ? updateInGroups(a.childGroups) : a.childGroups,
          })),
        };
      });
    };
    onGroupsChange(updateInGroups(thoughtGroups));
    setEditingAction(null);
    if ((updates.title || "").trim()) {
      if (coachAdvanceTimerRef.current !== null) window.clearTimeout(coachAdvanceTimerRef.current);
      const advanceDelay = coach.active && coach.step === "extraTask"
        ? COACH_DELAY.EXTRA_TASK_SAVED
        : coach.active && coach.step === "task"
        ? COACH_DELAY.FIRST_TASK_SAVED
        : 520;
      coachAdvanceTimerRef.current = window.setTimeout(() => {
        setCoach((c) => c.active && c.step === "task"
          ? { ...c, step: "urgencyCard" }
          : c.active && c.step === "extraTask"
          ? { ...c, step: "more" }
          : c);
        coachAdvanceTimerRef.current = null;
      }, advanceDelay);
    }
  };

  const updateEfaAnalysis = (groupId: string, actionId: string, value: EfaAnalysisCard) => {
    const updateInGroups = (groups: ThoughtGroup[]): ThoughtGroup[] => groups.map((group) => ({
      ...group,
      actions: group.actions.map((action) => action.id === actionId
        ? { ...action, efaAnalysis: value }
        : { ...action, childGroups: action.childGroups ? updateInGroups(action.childGroups) : action.childGroups }),
    }));
    onGroupsChange(updateInGroups(thoughtGroups));
  };

  // 在任务下新增子思路，任务仍由用户确认子思路后手动添加
  const addChildGroupToAction = (groupId: string, actionId: string) => {
    const newGroup: ThoughtGroup = {
      id: `group-${Date.now()}`,
      thought: "新的思路/怀疑方向",
      category: "Testing",
      actions: [],
    };

    const addToGroups = (groups: ThoughtGroup[]): ThoughtGroup[] => {
      return groups.map((g) => {
        if (g.id === groupId) {
          return {
            ...g,
            actions: g.actions.map((a) => {
              if (a.id === actionId) {
                return {
                  ...a,
                  childGroups: [...(a.childGroups || []), newGroup],
                };
              }
              return {
                ...a,
                childGroups: a.childGroups ? addToGroups(a.childGroups) : a.childGroups,
              };
            }),
          };
        }
        return {
          ...g,
          actions: g.actions.map((a) => ({
            ...a,
            childGroups: a.childGroups ? addToGroups(a.childGroups) : a.childGroups,
          })),
        };
      });
    };
    onGroupsChange(addToGroups(thoughtGroups));

    setThoughtText("");
    setThoughtCategory("Testing");
    setEditingThought(newGroup.id);
  };

  // 画布为空时预置「Case 根节点 + 第一个思路 + 第一个任务」，先进入思路填写
  useEffect(() => {
    if (!coachEnabled) { seededRef.current = true; return; }
    if (!seededRef.current && thoughtGroups.length === 0) {
      seededRef.current = true;
      const timestamp = Date.now();
      const initialAction: ActionCard = {
        id: `action-${timestamp}`,
        title: "新执行任务",
        urgency: "一般",
        department: "PTE",
        assignee: "",
        dueDate: "",
        note: "",
      };
      const initialGroup: ThoughtGroup = {
        id: `group-${timestamp}`,
        thought: THOUGHT_PLACEHOLDER,
        category: "Testing",
        actions: [initialAction],
      };
      initialActionIdRef.current = initialAction.id;
      onGroupsChange([initialGroup]);
      setThoughtText("");
      setThoughtCategory("Testing");
      setEditingThought(initialGroup.id);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [thoughtGroups.length]);

  // Convert to React Flow nodes and edges
  const { nodes, edges } = useMemo(() => {
    const nodes: Node[] = [];
    const edges: Edge[] = [];

    const caseX = 50;
    const caseY = 300;
    const place = (depth: number, cross: number) => direction === "LR" ? { x: depth, y: cross } : { x: cross, y: depth };

    // Add case node
    nodes.push({
      id: "case",
      type: "caseNode",
      position: manualPos.case || place(caseX, caseY),
      data: {
        caseItem: caseData,
        direction,
        onAddThought: addThoughtGroup,
        guideAddThought: coach.active && coach.step === "more",
      },
    });

    const firstThoughtXOffset = 380;
    const branchXOffset = 840;
    const ySpacing = 250;
    const actionSpacing = (_action: ActionCard) => ySpacing;

    // Recursively add nodes
    const addGroupNodes = (
      groups: ThoughtGroup[],
      parentId: string,
      parentType: "case" | "action",
      level: number,
      yStart: number
    ) => {
      let currentY = yStart;

      groups.forEach((group, groupIndex) => {
        // 第一层思路紧邻 Case 根节点；更深层级再逐层向右展开
        const thoughtDepth = caseX + firstThoughtXOffset + (level - 1) * branchXOffset;
        const thoughtCross = currentY;
        const thoughtPosition = manualPos[group.id] || place(thoughtDepth, thoughtCross);

        // Add thought node
        nodes.push({
          id: group.id,
          type: "thoughtNode",
          position: thoughtPosition,
          draggable: editingThought !== group.id,
          data: {
            group,
            direction,
            guideTarget: coach.active && coach.step === "thought",
            guideAddTask: coach.active && coach.step === "addTask",
            isEditing: editingThought === group.id,
            thoughtText,
            setThoughtText,
            thoughtCategory,
            setThoughtCategory,
            onEdit: () => {
              setThoughtText(group.thought === THOUGHT_PLACEHOLDER ? "" : group.thought);
              setThoughtCategory(group.category || "Testing");
              setThoughtSourceTaskIds(group.sourceTaskIds || []);
              setEditingThought(group.id);
            },
            onSave: () => updateThought(group.id, thoughtText, thoughtCategory, thoughtSourceTaskIds),
            onCancel: () => { setEditingThought(null); setThoughtSourceTaskIds([]); },
            onDelete: () => deleteGroup(group.id),
            onAddAction: () => addAction(group.id),
            thoughtSourceTaskIds,
            setThoughtSourceTaskIds,
            relationTasks,
          },
        });

        // 关联任务后隐藏原父节点入边，只保留任务 → 思路的关系线。
        if (!group.sourceTaskIds?.length) {
          edges.push({
            id: `${parentId}-${group.id}`,
            source: parentId,
            target: group.id,
            sourceHandle: direction === "LR" ? "right" : "bottom",
            targetHandle: direction === "LR" ? "left" : "top",
            type: "smoothstep",
            pathOptions: { borderRadius: 10, offset: 28 },
            style: { stroke: "#cbd5e1", strokeWidth: 2 },
          });
        }

        // Add action nodes below thought node
        // 任务卡始终排列在思路卡右侧；思路被拖动后也会以其实际位置为基准
        let actionY = thoughtPosition.y;
        group.actions.forEach((action, actionIndex) => {
          const autoActionPosition = direction === "LR"
            ? { x: thoughtPosition.x + 460, y: actionY }
            : { x: actionY, y: thoughtPosition.y + 360 };
          const dimmed =
            (onlyMine && action.assignee !== currentUser.name) ||
            (statusFilter !== "全部" && statusFilter !== "待接受") ||
            (deptFilter !== "全部" && action.department !== deptFilter);

          nodes.push({
            id: action.id,
            type: "actionNode",
            position: manualPos[action.id] || autoActionPosition,
            draggable: editingAction !== action.id,
            data: {
              action,
              caseData,
              direction,
              dimmed,
              guideUrgency: coach.active && (coach.step === "urgencyCard" || coach.step === "legend") && action.id === actionForm.id,
              guideTarget: coach.active && (coach.step === "task" || coach.step === "extraTask") && action.id === actionForm.id,
              guideAddChild: coach.active && coach.step === "nested" && action.id === actionForm.id && editingAction !== action.id,
              groupId: group.id,
              isEditing: editingAction === action.id,
              actionForm,
              setActionForm,
              onEdit: () => {
                setActionForm({ ...action, type: action.type || (action.efaAnalysis ? "EFA分析" : undefined), efaAnalysis: action.efaAnalysis || undefined });
                setEditingAction(action.id);
              },
              onSave: () => updateAction(group.id, action.id, actionForm as ActionCard),
              onCancel: () => setEditingAction(null),
              onDelete: () => deleteAction(group.id, action.id),
              onAddChildGroup: () => addChildGroupToAction(group.id, action.id),
            },
          });

          // Edge from thought to action
          edges.push({
            id: `${group.id}-${action.id}`,
            source: group.id,
            target: action.id,
            sourceHandle: direction === "LR" ? "right" : "bottom",
            targetHandle: direction === "LR" ? "left" : "top",
            type: "smoothstep",
            pathOptions: { borderRadius: 10, offset: 28 },
            zIndex: 2,
            style: { stroke: "#94a3b8", strokeWidth: 2 },
          });

          // Recursively add child groups from actions
          if (action.childGroups && action.childGroups.length > 0 && !collapsed.has(action.id)) {
            const childYStart = actionY - (action.childGroups.length * ySpacing) / 2;
            addGroupNodes(action.childGroups, action.id, "action", level + 1, childYStart);
          }

          actionY += actionSpacing(action);
        });

        currentY += Math.max(ySpacing, group.actions.reduce((sum, action) => sum + actionSpacing(action), 0));
      });
    };

    const totalHeight = thoughtGroups.reduce((sum, group) => sum + Math.max(ySpacing, group.actions.reduce((actionSum, action) => actionSum + actionSpacing(action), 0)), 0);
    addGroupNodes(thoughtGroups, "case", "case", 1, caseY - totalHeight / 2);
    const positionLinkedGroups = (groups: ThoughtGroup[]) => groups.forEach((group) => {
      if (group.sourceTaskIds?.length && !manualPos[group.id]) {
        const target = nodes.find((node) => node.id === group.id);
        const sources = group.sourceTaskIds.map((id) => nodes.find((node) => node.id === id)?.position).filter(Boolean) as { x: number; y: number }[];
        if (target && sources.length) target.position = direction === "LR"
          ? { x: Math.max(...sources.map((point) => point.x)) + 460, y: sources.reduce((sum, point) => sum + point.y, 0) / sources.length }
          : { x: sources.reduce((sum, point) => sum + point.x, 0) / sources.length, y: Math.max(...sources.map((point) => point.y)) + 360 };
      }
      group.actions.forEach((action) => { if (action.childGroups?.length) positionLinkedGroups(action.childGroups); });
    });
    positionLinkedGroups(thoughtGroups);
    const addRelationEdges = (groups: ThoughtGroup[]) => groups.forEach((group) => {
      (group.sourceTaskIds || []).forEach((sourceId) => {
        if (!nodes.some((node) => node.id === sourceId) || !nodes.some((node) => node.id === group.id)) return;
        edges.push({ id: `relation-${sourceId}-${group.id}`, source: sourceId, target: group.id, sourceHandle: "relation-source", targetHandle: "relation-target", type: "bezier", animated: true, zIndex: 8, style: { stroke: "#0052D9", strokeWidth: 2.5, strokeDasharray: "6 4" }, label: "任务关联", labelStyle: { fill: "#0052D9", fontSize: 9, fontWeight: 600 }, labelBgStyle: { fill: "#eff6ff", fillOpacity: 0.95 }, labelBgPadding: [5, 3], labelBgBorderRadius: 4 });
      });
      group.actions.forEach((action) => { if (action.childGroups?.length) addRelationEdges(action.childGroups); });
    });
    addRelationEdges(thoughtGroups);

    return { nodes, edges };
  }, [thoughtGroups, editingThought, editingAction, thoughtText, thoughtCategory, thoughtSourceTaskIds, actionForm, caseData, coach, manualPos, direction, onlyMine, statusFilter, deptFilter, collapsed, viewMode, relationTasks]);

  const [flowNodes, setNodes, onNodesChange] = useNodesState(nodes);
  const [flowEdges, setEdges] = useEdgesState(edges);

  // Update nodes when dependencies change
  useMemo(() => {
    setNodes(nodes);
    setEdges(edges);
  }, [nodes, edges, setNodes, setEdges]);
  useEffect(() => {
    const linkedGroups: ThoughtGroup[] = [];
    const collect = (groups: ThoughtGroup[]) => groups.forEach((group) => {
      if (group.sourceTaskIds?.length && !manualPos[group.id]) linkedGroups.push(group);
      group.actions.forEach((action) => { if (action.childGroups?.length) collect(action.childGroups); });
    });
    collect(thoughtGroups);
    if (!linkedGroups.length) return;
    setNodes((current) => {
      const byId = new Map(current.map((node) => [node.id, node]));
      let changed = false;
      const next = current.map((node) => {
        const group = linkedGroups.find((item) => item.id === node.id);
        if (!group) return node;
        const targetSize = node.measured;
        const sources = group.sourceTaskIds!.map((id) => byId.get(id)).filter((item): item is Node => !!item?.measured);
        if (!targetSize?.width || !targetSize.height || !sources.length) return node;
        const desired = direction === "LR"
          ? {
              x: Math.max(...sources.map((source) => source.position.x + (source.measured?.width || 0))) + 130,
              y: sources.reduce((sum, source) => sum + source.position.y + (source.measured?.height || 0) / 2, 0) / sources.length - targetSize.height / 2,
            }
          : {
              x: sources.reduce((sum, source) => sum + source.position.x + (source.measured?.width || 0) / 2, 0) / sources.length - targetSize.width / 2,
              y: Math.max(...sources.map((source) => source.position.y + (source.measured?.height || 0))) + 130,
            };
        if (Math.abs(node.position.x - desired.x) < 1 && Math.abs(node.position.y - desired.y) < 1) return node;
        changed = true;
        return { ...node, position: desired };
      });
      return changed ? next : current;
    });
  }, [flowNodes, thoughtGroups, direction, manualPos, setNodes]);

  // 分步新增节点后重新适配画布，保证 Case 根节点与当前卡片始终同时完整可见
  useEffect(() => {
    if (!flowInstance || flowNodes.length === 0) return;
    const frame = requestAnimationFrame(() => {
      flowInstance.fitView({ padding: 0.18, maxZoom: 0.95, duration: 260 });
    });
    return () => cancelAnimationFrame(frame);
  }, [flowInstance, flowNodes.length]);

  const nodeTypes: NodeTypes = useMemo(
    () => ({
      caseNode: CaseNodeComponent,
      thoughtNode: ThoughtNodeEditComponent,
      actionNode: ActionNodeEditComponent,
      efaAnalysisNode: EfaAnalysisNodeComponent,
    }),
    []
  );

  return (
    <div className="space-y-4">
      {/* React Flow Canvas */}
      <div
        ref={canvasRef}
        className={
          fullscreen
            ? "fixed inset-0 z-50 bg-gradient-to-br from-slate-50 to-white"
            : "relative bg-gradient-to-br from-slate-50 to-white border border-slate-200 rounded-lg overflow-hidden"
        }
      >
          <div data-create-guide="toolbar" className="absolute top-3 left-3 z-10 flex items-center gap-2 flex-wrap">
            <div className="inline-flex items-center bg-white/95 border border-slate-200 rounded-lg p-0.5 shadow-sm">
              {([
                { key: "all", label: "全局视图", icon: Eye },
                { key: "incomplete", label: "只看未完成", icon: AlarmClock },
                { key: "valid", label: "只看有效路径", icon: Flag },
              ] as { key: CreateViewMode; label: string; icon: any }[]).map(({ key, label, icon: Icon }) => (
                <button
                  key={key}
                  onClick={() => setViewMode(key)}
                  className={`h-7 px-2.5 rounded-md text-xs inline-flex items-center gap-1 transition-all ${viewMode === key ? "bg-[#0052D9] text-white shadow-sm" : "text-slate-600 hover:bg-slate-100"}`}
                >
                  <Icon size={12} /> {label}
                </button>
              ))}
              <span className="w-px h-4 bg-slate-200 mx-0.5" />
              <button
                onClick={() => setOnlyMine((value) => !value)}
                title="只看我负责的任务"
                className={`h-7 px-2.5 rounded-md text-xs inline-flex items-center gap-1 transition-all ${onlyMine ? "bg-[#0052D9] text-white shadow-sm" : "text-slate-600 hover:bg-slate-100"}`}
              >
                <User size={12} /> 只看我的
              </button>
            </div>
            <select
              value={statusFilter}
              onChange={(event) => setStatusFilter(event.target.value)}
              title="按任务状态筛选"
              className={`h-8 px-2 rounded-lg border shadow-sm text-xs outline-none cursor-pointer ${statusFilter === "全部" ? "bg-white/95 border-slate-200 text-slate-600" : "bg-[#0052D9] text-white border-[#0052D9]"}`}
            >
              {CREATE_STATUS_OPTIONS.map((status) => <option key={status} value={status} className="text-slate-700">{status === "全部" ? "状态：全部" : status}</option>)}
            </select>
            <select
              value={deptFilter}
              onChange={(event) => setDeptFilter(event.target.value)}
              title="按部门筛选"
              className={`h-8 px-2 rounded-lg border shadow-sm text-xs outline-none cursor-pointer ${deptFilter === "全部" ? "bg-white/95 border-slate-200 text-slate-600" : "bg-[#0052D9] text-white border-[#0052D9]"}`}
            >
              {deptOptions.map((department) => <option key={department} value={department} className="text-slate-700">{department === "全部" ? "部门：全部" : department}</option>)}
            </select>
            <button
              onClick={() => { setDirection((value) => value === "LR" ? "TB" : "LR"); setManualPos({}); }}
              title={direction === "LR" ? "切换为竖向布局" : "切换为横向布局"}
              className="h-8 px-2.5 rounded-lg bg-white/95 border border-slate-200 shadow-sm text-xs text-slate-600 hover:text-[#0052D9] inline-flex items-center gap-1"
            >
              {direction === "LR" ? <MoveVertical size={13} /> : <MoveHorizontal size={13} />}
              {direction === "LR" ? "竖向" : "横向"}
            </button>
            <button
              onClick={() => setCollapsed((previous) => previous.size ? new Set() : new Set(collapsibleActionIds))}
              disabled={collapsibleActionIds.length === 0}
              title="折叠已完成/死路 或 全部展开"
              className="h-8 px-2.5 rounded-lg bg-white/95 border border-slate-200 shadow-sm text-xs text-slate-600 hover:text-[#0052D9] disabled:opacity-40 disabled:cursor-not-allowed inline-flex items-center gap-1"
            >
              {collapsed.size ? "展开全部" : "折叠已完成"}
            </button>
            {Object.keys(manualPos).length > 0 && (
              <button
                onClick={() => setManualPos({})}
                title="清除手动拖拽，恢复自动布局"
                className="h-8 px-2.5 rounded-lg bg-white/95 border border-slate-200 shadow-sm text-xs text-slate-600 hover:text-[#0052D9] inline-flex items-center gap-1"
              >
                <Eye size={13} /> 重新布局
              </button>
            )}
          </div>
        <button
          onClick={() => setFullscreen((value) => !value)}
          title={fullscreen ? "退出全屏" : "全屏"}
          className="absolute top-3 right-3 z-20 w-8 h-8 rounded-md bg-white/90 border border-slate-200 shadow-sm hover:bg-white flex items-center justify-center text-slate-600 hover:text-[#0052D9]"
        >
          {fullscreen ? <Minimize2 size={14} /> : <Maximize2 size={14} />}
        </button>

        <div className={`${fullscreen ? "h-full w-full" : "h-[700px]"} create-case-flow`}>
          <ReactFlow
            nodes={flowNodes}
            edges={flowEdges}
            nodeTypes={nodeTypes}
            onInit={setFlowInstance}
            onNodesChange={onNodesChange}
            onNodeDragStop={(_, node) =>
              setManualPos((positions) => ({
                ...positions,
                [node.id]: { x: node.position.x, y: node.position.y },
              }))
            }
            fitView
            fitViewOptions={{ padding: 0.18, maxZoom: 0.95 }}
            minZoom={0.2}
            maxZoom={1.5}
            defaultViewport={{ x: 100, y: 100, zoom: 0.8 }}
            proOptions={{ hideAttribution: true }}
          >
            <Background />
            <MindMapZoomPill guideAttr="zoom-pill" />
            <MiniMap zoomable pannable nodeColor={(node) => {
              if (node.type === 'caseNode') return '#334155';
              if (node.type === 'thoughtNode') return '#F59E0B';
              if (node.type === 'actionNode') return '#0052D9';
              return '#CBD5E1';
            }} />
          </ReactFlow>
        </div>

        <div data-create-guide="legend" className="absolute bottom-3.5 left-[230px] z-10 px-3 py-1.5 text-[11px] text-slate-500 bg-white/95 border border-slate-200 rounded-lg shadow-sm flex items-center gap-2.5">
            {onlyMine && <span className="text-[#0052D9] font-medium">已聚焦我的</span>}
            <span className="text-slate-400">紧急度</span>
            <span className={`inline-flex items-center gap-1 rounded px-1 py-0.5 transition-all ${coach.active && coach.step === "legend" && actionForm.urgency === "非常紧急" ? "bg-red-50 text-red-600 ring-1 ring-red-200" : ""}`}><span className="inline-block w-0.5 h-3 bg-red-400" />非常紧急</span>
            <span className={`inline-flex items-center gap-1 rounded px-1 py-0.5 transition-all ${coach.active && coach.step === "legend" && actionForm.urgency === "紧急" ? "bg-orange-50 text-orange-600 ring-1 ring-orange-200" : ""}`}><span className="inline-block w-0.5 h-3 bg-orange-400" />紧急</span>
            <span className={`inline-flex items-center gap-1 rounded px-1 py-0.5 transition-all ${coach.active && coach.step === "legend" && (actionForm.urgency || "一般") === "一般" ? "bg-sky-50 text-sky-600 ring-1 ring-sky-200" : ""}`}><span className="inline-block w-0.5 h-3 bg-sky-400" />一般</span>
            <span className={`inline-flex items-center gap-1 rounded px-1 py-0.5 transition-all ${coach.active && coach.step === "legend" && actionForm.urgency === "不紧急" ? "bg-slate-100 text-slate-700 ring-1 ring-slate-300" : ""}`}><span className="inline-block w-0.5 h-3 bg-slate-300" />不紧急</span>
        </div>

        {coach.active && (
          <CreateCaseSpotlight
            step={coach.step}
            container={canvasRef.current}
            onNext={() => {
              if (coach.step === "thoughtResult" && editingThought) {
                updateThought(editingThought, thoughtText, thoughtCategory, thoughtSourceTaskIds);
                return;
              }
              setCoach((current) => ({
                ...current,
                step:
                  current.step === "zoom" ? "minimap" :
                  current.step === "minimap" ? "toolbar" :
                  current.step === "toolbar" ? "caseRoot" :
                  current.step === "caseRoot" ? "thoughtCategory" :
                  current.step === "thoughtCategory" ? "thought" :
                  current.step === "thought" ? "thoughtResult" :
                  current.step === "urgencyCard" ? "legend" :
                  current.step === "legend" ? "addTask" :
                  current.step === "more" ? "nested" : current.step,
              }));
            }}
            onGoTo={(nextStep) => setCoach((current) => ({ ...current, step: nextStep }))}
            canProceed={(thoughtCategory === "Other" || thoughtCategory === "其他")
              ? !!thoughtText.trim()
              : coach.step === "thoughtResult"
              ? !!parseThought(thoughtText)[2].trim()
              : !!parseThought(thoughtText)[0].trim()}
                isOtherThought={thoughtCategory === "Other" || thoughtCategory === "其他"}
            onClose={closeCoach}
          />
        )}
      </div>
    </div>
  );
}

function CreateCaseSpotlight({ step, container, onNext, onGoTo, canProceed, isOtherThought, onClose }: { step: CoachStep; container: HTMLDivElement | null; onNext: () => void; onGoTo: (step: CoachStep) => void; canProceed: boolean; isOtherThought: boolean; onClose: (dontShowAgain: boolean) => void }) {
  const [rect, setRect] = useState<{ top: number; left: number; width: number; height: number } | null>(null);
  const [cardAnchor, setCardAnchor] = useState<{ top: number; left: number; width: number; height: number } | null>(null);
  const [urgencyRect, setUrgencyRect] = useState<{ top: number; left: number; width: number; height: number } | null>(null);
  const [bounds, setBounds] = useState<{ top: number; left: number; width: number; height: number } | null>(null);
  const [dontShowAgain, setDontShowAgain] = useState(true);
  const content = COACH_CONTENT[step];

  useEffect(() => {
    let frame = 0;
    let revealed = false;
    const update = () => {
      const element = document.querySelector(content.target) as HTMLElement | null;
      if (element && container) {
        if (!revealed) {
          revealed = true;
          if (step !== "urgencyCard" && step !== "legend" && step !== "addTask" && step !== "extraTask" && step !== "more") {
            element.scrollIntoView({ behavior: "smooth", block: "center", inline: "center" });
          }
          if (step === "thought" || step === "thoughtResult") {
            window.setTimeout(() => {
              const input = (element.matches("input, textarea")
                ? element
                : element.querySelector("input, textarea")) as HTMLInputElement | HTMLTextAreaElement | null;
              input?.focus({ preventScroll: true });
            }, 120);
          }
        }
        const canvas = container.getBoundingClientRect();
        const canvasTop = Math.max(0, canvas.top);
        const canvasLeft = Math.max(0, canvas.left);
        const canvasRight = Math.min(window.innerWidth, canvas.right);
        const canvasBottom = Math.min(window.innerHeight, canvas.bottom);
        const nextBounds = {
          top: canvasTop,
          left: canvasLeft,
          width: Math.max(0, canvasRight - canvasLeft),
          height: Math.max(0, canvasBottom - canvasTop),
        };
        setBounds(nextBounds);
        const next = element.getBoundingClientRect();
        const urgencyElement = step === "legend" ? document.querySelector('[data-create-guide="urgency-bar"]') as HTMLElement | null : null;
        const urgency = urgencyElement?.getBoundingClientRect();
        setUrgencyRect(urgency ? { top: urgency.top, left: urgency.left, width: urgency.width, height: urgency.height } : null);
        const anchorElement = step === "nested" || step === "urgencyCard"
          ? element.closest(".react-flow__node") as HTMLElement | null
          : null;
        const anchor = anchorElement?.getBoundingClientRect() || next;
        setCardAnchor({ top: anchor.top, left: anchor.left, width: anchor.width, height: anchor.height });
        const padding = step === "zoom" ? 8 : 10;
        const top = Math.max(canvasTop + 6, next.top - padding);
        const left = Math.max(canvasLeft + 6, next.left - padding);
        const right = Math.min(canvasRight - 6, next.right + padding);
        const bottom = Math.min(canvasBottom - 6, next.bottom + padding);
        setRect((current) => {
          const updated = { top, left, width: right - left, height: bottom - top };
          return current && Math.abs(current.top - top) < 0.5 && Math.abs(current.left - left) < 0.5 &&
            Math.abs(current.width - updated.width) < 0.5 && Math.abs(current.height - updated.height) < 0.5
            ? current
            : updated;
        });
      } else {
        setRect(null);
        setCardAnchor(null);
        setUrgencyRect(null);
        setBounds(null);
      }
      frame = requestAnimationFrame(update);
    };
    frame = requestAnimationFrame(update);
    return () => cancelAnimationFrame(frame);
  }, [container, content.target, step]);

  if (!rect || !cardAnchor || !bounds) return null;

  const placementAnchor = step === "nested" || step === "urgencyCard" ? cardAnchor : rect;
  const right = placementAnchor.left + placementAnchor.width;
  const bottom = placementAnchor.top + placementAnchor.height;
  const cardWidth = 320;
  const gap = 18;
  let cardLeft: number;
  let cardTop: number;
  const boundsRight = bounds.left + bounds.width;
  const boundsBottom = bounds.top + bounds.height;
  if (right + gap + cardWidth <= boundsRight - 12) {
    cardLeft = right + gap;
    cardTop = Math.min(placementAnchor.top, boundsBottom - 300);
  } else if (placementAnchor.left - gap - cardWidth >= bounds.left + 12) {
    cardLeft = placementAnchor.left - gap - cardWidth;
    cardTop = Math.min(placementAnchor.top, boundsBottom - 300);
  } else {
    cardLeft = Math.max(bounds.left + 12, Math.min(boundsRight - cardWidth - 12, placementAnchor.left));
    cardTop = bottom + gap + 250 <= boundsBottom ? bottom + gap : Math.max(bounds.top + 12, placementAnchor.top - 268);
  }
  cardTop = Math.max(bounds.top + 12, cardTop);

  const needsInteraction = (step === "thought" && isOtherThought) || step === "addTask" || step === "task" || step === "extraTask";
  const isLast = step === "nested";
  const spotlightRadius = Math.min(14, rect.width / 3, rect.height / 3);
  const relativeRect = {
    x: rect.left - bounds.left,
    y: rect.top - bounds.top,
  };
  const legendLink = step === "legend" && urgencyRect ? {
    x1: rect.left + rect.width / 2,
    y1: rect.top,
    x2: urgencyRect.left + urgencyRect.width / 2,
    y2: urgencyRect.top + urgencyRect.height / 2,
  } : null;
  const isLongTravel = step === "legend" || step === "addTask" || step === "more" || step === "nested";
  const isTaskHandoff = step === "urgencyCard" || step === "extraTask";
  const spotlightTransition = isLongTravel ? 1200 : isTaskHandoff ? 900 : 680;
  const cardTransition = isLongTravel ? 1300 : isTaskHandoff ? 980 : 760;

  return (
    <>
      <div
        aria-hidden="true"
        className="fixed z-[80] pointer-events-none overflow-hidden"
        style={{ top: bounds.top, left: bounds.left, width: bounds.width, height: bounds.height }}
      >
        <div
          className="absolute"
          style={{
            top: relativeRect.y,
            left: relativeRect.x,
            width: rect.width,
            height: rect.height,
            borderRadius: spotlightRadius,
            boxShadow: "0 0 0 9999px rgba(2, 6, 23, 0.66)",
            transition: `top ${spotlightTransition}ms cubic-bezier(.22,.8,.26,1), left ${spotlightTransition}ms cubic-bezier(.22,.8,.26,1), width ${spotlightTransition}ms cubic-bezier(.22,.8,.26,1), height ${spotlightTransition}ms cubic-bezier(.22,.8,.26,1), border-radius ${spotlightTransition}ms cubic-bezier(.22,.8,.26,1)`,
            willChange: "top, left, width, height",
          }}
        />
      </div>
      <div
        className="fixed z-[82] pointer-events-none"
        style={{
          top: rect.top,
          left: rect.left,
          width: rect.width,
          height: rect.height,
          borderRadius: spotlightRadius,
          border: step === "thought" ? "1px solid rgba(251,191,36,.95)" : "1px solid rgba(125,211,252,.95)",
          boxShadow: step === "thought"
            ? "0 0 0 3px rgba(251,191,36,.18), 0 10px 34px rgba(245,158,11,.28), inset 0 0 0 1px rgba(255,255,255,.45)"
            : "0 0 0 3px rgba(56,189,248,.16), 0 10px 34px rgba(0,82,217,.28), inset 0 0 0 1px rgba(255,255,255,.45)",
          transition: `top ${spotlightTransition}ms cubic-bezier(.22,.8,.26,1), left ${spotlightTransition}ms cubic-bezier(.22,.8,.26,1), width ${spotlightTransition}ms cubic-bezier(.22,.8,.26,1), height ${spotlightTransition}ms cubic-bezier(.22,.8,.26,1), border-radius ${spotlightTransition}ms cubic-bezier(.22,.8,.26,1), border-color 320ms ease, box-shadow 320ms ease`,
          willChange: "top, left, width, height",
        }}
      />

      {legendLink && (
        <svg aria-hidden="true" className="fixed inset-0 z-[84] pointer-events-none w-screen h-screen">
          <defs>
            <filter id="legend-link-glow" x="-30%" y="-30%" width="160%" height="160%">
              <feGaussianBlur stdDeviation="3" result="blur" />
              <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
            </filter>
          </defs>
          <path
            d={`M ${legendLink.x1} ${legendLink.y1} C ${legendLink.x1} ${legendLink.y1 - 54}, ${legendLink.x2 - 70} ${legendLink.y2}, ${legendLink.x2} ${legendLink.y2}`}
            fill="none"
            stroke="rgba(56,189,248,.95)"
            strokeWidth="2.5"
            strokeLinecap="round"
            strokeDasharray="7 6"
            filter="url(#legend-link-glow)"
          />
          <circle cx={legendLink.x1} cy={legendLink.y1} r="4" fill="#38bdf8" />
          <circle cx={legendLink.x2} cy={legendLink.y2} r="6" fill="rgba(56,189,248,.22)" stroke="#38bdf8" strokeWidth="2" />
          <rect
            x={urgencyRect.left - 5}
            y={urgencyRect.top - 5}
            width={urgencyRect.width + 10}
            height={urgencyRect.height + 10}
            rx="6"
            fill="none"
            stroke="#38bdf8"
            strokeWidth="2"
            filter="url(#legend-link-glow)"
          />
        </svg>
      )}

      <div
        className="fixed z-[90] w-[320px] overflow-hidden rounded-2xl bg-white border border-slate-200 shadow-2xl"
        style={{
          left: cardLeft,
          top: cardTop,
          transition: `left ${cardTransition}ms cubic-bezier(.22,.8,.26,1), top ${cardTransition}ms cubic-bezier(.22,.8,.26,1)`,
          willChange: "left, top",
        }}
      >
        <div className="bg-gradient-to-br from-[#0052D9] to-[#00A4FF] px-4 pt-3.5 pb-3 text-white">
          <div className="flex items-center justify-between">
            <div className="inline-flex items-center gap-1.5 text-[11px] font-medium tracking-wide text-white/85">
              <MousePointer2 size={13} /> 新手引导 · {content.index} / {COACH_STEPS.length}
            </div>
            <button onClick={() => onClose(dontShowAgain)} title="关闭引导" className="w-6 h-6 rounded-md bg-white/15 hover:bg-white/25 flex items-center justify-center">
              <X size={13} />
            </button>
          </div>
          <div className="mt-1.5 text-[16px] font-bold leading-snug">{content.title}</div>
        </div>
        <div className="px-4 py-3.5">
          <p className="text-[12.5px] text-slate-600 leading-[1.7]">{content.description}</p>
          <div className="mt-3 flex items-center gap-1.5">
            {COACH_STEPS.map((coachStep, index) => index + 1 < content.index ? (
              <button
                key={coachStep}
                onClick={() => onGoTo(coachStep)}
                title={`第 ${index + 1} 步已完成，点击返回`}
                className="w-3 h-3 rounded-full bg-slate-400 text-white hover:bg-[#0052D9] hover:scale-110 transition-all inline-flex items-center justify-center"
              >
                <Check size={8} strokeWidth={3} />
              </button>
            ) : (
              <span key={coachStep} className={`h-1.5 rounded-full transition-all ${index + 1 === content.index ? "w-5 bg-[#0052D9]" : "w-1.5 bg-slate-200"}`} />
            ))}
          </div>
          <div className="mt-3 pt-3 border-t border-slate-100 flex items-center gap-3">
            <label className="text-[11.5px] text-slate-400 flex items-center gap-1.5 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={dontShowAgain}
                onChange={(event) => setDontShowAgain(event.target.checked)}
                className="w-3.5 h-3.5 rounded border-slate-300 accent-[#0052D9]"
              />
              下次不再显示
            </label>
            <div className="flex-1" />
            {!needsInteraction && (
              <button
                onClick={isLast ? () => onClose(dontShowAgain) : onNext}
                disabled={(step === "thought" || step === "thoughtResult") && !canProceed}
                className="h-8 px-4 rounded-lg bg-[#0052D9] text-white text-xs font-medium hover:bg-[#003FA8] disabled:bg-slate-300 disabled:cursor-not-allowed inline-flex items-center justify-center gap-1.5"
              >
                {isLast ? <><Check size={14} /> 完成</> : step === "thoughtCategory" ? <>选择并继续</> : step === "thoughtResult" ? <>完成思路并继续</> : <>下一步</>}
              </button>
            )}
          </div>
        </div>
      </div>
    </>
  );
}

// Components for nodes remain similar but simplified for create mode
function CaseNodeComponent({ data }: { data: any }) {
  const { caseItem, direction, onAddThought, guideAddThought } = data;
  return (
    <div data-create-guide="case-root" className="group/case relative bg-white border-2 border-slate-200 rounded-xl p-4 shadow-lg w-[280px]">
      <Handle type="source" position={direction === "LR" ? Position.Right : Position.Bottom} id={direction === "LR" ? "right" : "bottom"} />
      <button
        data-create-guide={guideAddThought ? "case-add-thought" : undefined}
        onClick={onAddThought}
        title="新建思路"
        className={`absolute top-2 right-2 z-20 w-7 h-7 rounded-full bg-[#0052D9] text-white shadow-sm flex items-center justify-center hover:bg-[#003FA8] transition-opacity ${guideAddThought ? "opacity-100" : "opacity-0 group-hover/case:opacity-100"}`}
      >
        <Plus size={14} />
      </button>
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-1">
          <div className="px-2 py-0.5 rounded text-xs border bg-slate-50 text-slate-600 border-slate-200">
            {caseItem.level || "L3"}
          </div>
          <CaseProductPill caseItem={caseItem} compact />
        </div>
        <div className="text-xs text-slate-400 font-mono">{caseItem.code}</div>
      </div>
      <h4 className="text-sm font-medium text-slate-900 leading-snug mb-2 line-clamp-2">
        {caseItem.name || "（未命名 Case）"}
      </h4>
      <div className="space-y-1.5 text-xs text-slate-500">
        <div className="flex items-center gap-1.5">
          <User size={12} />
          <span>Owner: {caseItem.owner}</span>
        </div>
        <div className="flex items-center gap-1.5">
          <Shield size={12} />
          <span>{caseItem.urgency}</span>
        </div>
      </div>
    </div>
  );
}

function ThoughtNodeEditComponent({ data }: { data: any }) {
  const {
    group,
    isEditing,
    thoughtText,
    setThoughtText,
    thoughtCategory,
    setThoughtCategory,
    onEdit,
    onSave,
    onCancel,
    onDelete,
    onAddAction,
    guideTarget,
    guideAddTask,
    direction,
    thoughtSourceTaskIds,
    setThoughtSourceTaskIds,
    relationTasks,
  } = data;

  const isThoughtEmpty = !group.thought?.trim() || group.thought === THOUGHT_PLACEHOLDER;
  const isOtherCategory = thoughtCategory === "Other" || thoughtCategory === "其他";
  const parts = isEditing ? parseThought(thoughtText) : ["", "", ""];
  const saveable = isOtherCategory
    ? !!thoughtText.trim()
    : !!(parts[0].trim() && parts[2].trim());
  const linkedTasks = (relationTasks || []).filter((candidate: RelationTask) => group.sourceTaskIds?.includes(candidate.id));
  const setPart = (idx: number, v: string) => {
    const next = [...parts] as [string, string, string];
    next[idx] = v;
    setThoughtText?.(composeThought(next));
  };

  return (
    <div data-create-guide={guideTarget ? "thought" : undefined} className="relative w-[320px] transition-all">
      <Handle type="target" position={direction === "LR" ? Position.Left : Position.Top} id={direction === "LR" ? "left" : "top"} />
      <Handle type="source" position={direction === "LR" ? Position.Right : Position.Bottom} id={direction === "LR" ? "right" : "bottom"} />
      <Handle type="target" id="relation-target" position={direction === "LR" ? Position.Left : Position.Top} style={{ opacity: 0, pointerEvents: "none" }} />

      <div className="relative bg-amber-50/60 border border-amber-300 rounded-xl p-3.5 group/thought transition-all duration-200 hover:scale-[1.03] hover:shadow-md">
        {!isEditing ? (
          <>
            <div className={`absolute top-2 right-2 z-20 flex items-center gap-0.5 transition-opacity ${guideAddTask ? "opacity-100" : "opacity-0 group-hover/thought:opacity-100"}`}>
              <button
                onClick={onEdit}
                title="编辑"
                className="w-6 h-6 rounded-md bg-white/90 border border-slate-200 shadow-sm flex items-center justify-center text-slate-500 hover:text-[#0052D9]"
              >
                <Edit2 size={12} />
              </button>
              <button
                onClick={() => { if (confirm(`删除思路「${group.thought}」及其所有执行任务？`)) onDelete?.(); }}
                title="删除"
                className="w-6 h-6 rounded-md bg-white/90 border border-slate-200 shadow-sm flex items-center justify-center text-slate-500 hover:text-red-500"
              >
                <Trash2 size={12} />
              </button>
              <button
                data-create-guide={guideAddTask ? "add-task" : undefined}
                onClick={onAddAction}
                title="添加执行任务"
                className="w-6 h-6 rounded-full bg-[#0052D9] text-white shadow-sm flex items-center justify-center hover:bg-[#003FA8]"
              >
                <Plus size={13} />
              </button>
            </div>
            <div className="flex items-center gap-1.5 mb-2">
              <span className="text-[11px] text-amber-700 font-medium tracking-wide shrink-0">思路 / 怀疑方向</span>
              {group.category && (
                <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded text-[10px] bg-amber-100 text-amber-700 border border-amber-200 shrink-0 whitespace-nowrap">
                  <Tag size={9} /> {group.category}
                </span>
              )}
            </div>
            {isThoughtEmpty ? (
              <button onClick={onEdit} className="text-left w-full text-[12px] text-amber-600/70 italic leading-relaxed hover:text-amber-700">
                点此填写：怀疑什么 + 为什么怀疑（一个方向写一个节点）
              </button>
            ) : (
              <p className="text-[13px] text-slate-800 leading-relaxed font-medium">{group.thought}</p>
            )}
            {group.sourceTaskIds?.length > 0 && (
              <button onClick={onEdit} className="mt-2 w-full rounded-md border border-blue-100 bg-blue-50/70 p-2 text-left hover:border-[#0052D9]/30">
                <span className="flex items-center gap-1 text-[10px] font-semibold text-[#0052D9]"><Link2 size={10} />关联结果 · {group.sourceTaskIds.length}</span>
                <span className="mt-1 block space-y-1">{linkedTasks.slice(0, 2).map((linked: RelationTask) => <span key={linked.id} className="block"><span className="block truncate text-[10.5px] font-medium text-slate-700">{linked.title}</span><span className="block truncate text-[9.5px] text-slate-500">预期：{linked.expectation || "暂无"}</span></span>)}</span>
                {group.sourceTaskIds.length > 2 && <span className="mt-1 block text-[9.5px] text-[#0052D9]">另有 {group.sourceTaskIds.length - 2} 个任务 · 点击管理</span>}
              </button>
            )}
          </>
        ) : (
          <>
            <div className="flex items-center justify-between mb-2.5">
              <div className="text-xs text-amber-700 font-medium">编辑思路 / 怀疑方向</div>
              <select
                data-create-guide="thought-category"
                value={thoughtCategory || "Testing"}
                onChange={(e) => setThoughtCategory?.(e.target.value)}
                className="h-6 rounded-full border px-2 text-[11px] outline-none border-amber-300 text-amber-700 bg-amber-50"
              >
                {THOUGHT_CATEGORIES.map((cName) => (
                  <option key={cName} value={cName}>{cName}</option>
                ))}
              </select>
            </div>
            {isOtherCategory ? (
              <div>
                <div className="text-[11px] font-semibold text-slate-600 mb-1">工作思路 <span className="text-red-500">*</span></div>
                <textarea
                  data-create-guide="thought-input"
                  value={thoughtText}
                  onChange={(e) => setThoughtText?.(e.target.value)}
                  placeholder="请填写工作思路"
                  autoFocus
                  className="nodrag nopan w-full min-h-[88px] p-2 rounded border border-slate-200 bg-white text-[12.5px] leading-relaxed outline-none focus:border-amber-500 resize-y"
                />
              </div>
            ) : (
              <>
                <div className="space-y-2">
                  <div>
                    <div className="text-[11px] font-semibold text-slate-600 mb-1">因为 <span className="text-red-500">*</span></div>
                    <input
                      data-create-guide="thought-input"
                      value={parts[0]}
                      onChange={(e) => setPart(0, e.target.value)}
                      placeholder="看到什么失效现象，关联以往什么 case"
                      autoFocus
                      className="nodrag nopan w-full h-8 px-2 rounded border border-slate-200 bg-white text-[12.5px] outline-none focus:border-amber-500"
                    />
                  </div>
                  <div>
                    <div className="text-[11px] font-semibold text-slate-600 mb-1 inline-flex items-center gap-1.5">
                      原理说明 <span className="text-[10px] font-normal text-slate-400 border border-slate-200 rounded-full px-1.5 leading-4">选填</span>
                    </div>
                    <input
                      value={parts[1]}
                      onChange={(e) => setPart(1, e.target.value)}
                      placeholder="补充原理内容，可增加Case评分"
                      className="nodrag nopan w-full h-8 px-2 rounded border border-dashed border-slate-300 bg-slate-50 text-[12.5px] outline-none focus:border-slate-400 focus:bg-white"
                    />
                  </div>
                  <div>
                    <div className="text-[11px] font-semibold text-slate-600 mb-1">所以 <span className="text-red-500">*</span></div>
                    <input
                      data-create-guide="thought-result"
                      value={parts[2]}
                      onChange={(e) => setPart(2, e.target.value)}
                      placeholder="怀疑和什么有关"
                      className="nodrag nopan w-full h-8 px-2 rounded border border-slate-200 bg-white text-[12.5px] outline-none focus:border-amber-500"
                    />
                  </div>
                </div>
                <div className="mt-1.5 text-[10px] text-amber-600/80">「因为」和「所以」必填，原理说明选填</div>
              </>
            )}
            <div className="mt-2.5 pt-2.5 border-t border-amber-200/70">
              <div className="flex items-center justify-between"><span className="text-[10.5px] text-slate-500">来源任务 <span className="text-slate-400">（选填）</span></span><TaskRelationPicker tasks={relationTasks || []} value={thoughtSourceTaskIds || []} onChange={setThoughtSourceTaskIds} /></div>
              {(thoughtSourceTaskIds?.length || 0) > 0 && <div className="mt-1.5 text-[10px] text-[#0052D9]">已关联 {thoughtSourceTaskIds.length} 个任务，确认思路后自动展示连线</div>}
            </div>
            <div className="flex gap-2 mt-2.5">
              <button
                onClick={onSave}
                disabled={!saveable}
                className={`flex-1 h-7 rounded text-white text-xs ${saveable ? "bg-[#0052D9] hover:bg-[#003FA8]" : "bg-slate-300 cursor-not-allowed"}`}
              >
                确认
              </button>
              <button
                onClick={onCancel}
                className="flex-1 h-7 rounded border border-slate-200 text-slate-600 text-xs hover:bg-slate-50"
              >
                取消
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

function EfaAnalysisNodeComponent({ data }: { data: any }) {
  const { action, value, direction, onSave } = data as { action: ActionCard; value: EfaAnalysisCard; direction: Direction; onSave: (value: EfaAnalysisCard) => void };
  const clone = (source: EfaAnalysisCard): EfaAnalysisCard => ({
    ...source,
    chipList: (source.chipList?.length ? source.chipList : [{ fsa: "", map: "", failMode: "", waferNo: "", chipNo: "", markCode: "" }]).map((chip) => ({ ...chip })),
  });
  const [draft, setDraft] = useState<EfaAnalysisCard>(() => clone(value));
  const [editing, setEditing] = useState(() => !value?.submitted);
  useEffect(() => {
    setDraft(clone(value));
    setEditing(!value?.submitted);
  }, [value]);
  const setField = (key: keyof EfaAnalysisCard, next: any) => setDraft((previous) => ({ ...previous, [key]: next }));
  const updateChip = (index: number, key: string, next: string) => setDraft((previous) => ({
    ...previous,
    chipList: (previous.chipList || []).map((chip, chipIndex) => chipIndex === index ? { ...chip, [key]: next } : chip),
  }));
  const inputClass = "nodrag nopan nowheel mt-1 w-full h-7 px-2 text-[11px] bg-white border border-slate-200 rounded outline-none focus:border-violet-500 disabled:bg-slate-50 disabled:text-slate-500";
  const chipList = draft.chipList || [];
  const submitted = !!draft.submitted && !editing;

  if (submitted) {
    const modeLabel = draft.mode === "component" ? "Component" : draft.mode === "wafer" ? "Wafer" : "未分类";
    const summary = draft.mode === "component"
      ? [draft.standard, draft.stage, draft.package, chipList.length ? `${chipList.length} 颗 chip` : ""].filter(Boolean).join(" · ")
      : [draft.stage, draft.bin && `Bin ${draft.bin}`, draft.chipNo && `Chip ${draft.chipNo}`].filter(Boolean).join(" · ");
    return (
      <div className="relative w-[256px]">
        <Handle type="target" position={direction === "LR" ? Position.Left : Position.Top} id={direction === "LR" ? "left" : "top"} />
        <Handle type="source" position={direction === "LR" ? Position.Right : Position.Bottom} id={direction === "LR" ? "right" : "bottom"} />
        <div className="rounded-xl border border-slate-200 bg-white shadow-sm overflow-hidden">
          <div className="px-3 py-2.5 flex items-center gap-2.5">
            <span className="w-7 h-7 rounded-lg bg-violet-50 text-violet-600 grid place-items-center shrink-0">
              <FlaskConical size={14} />
            </span>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5">
                <span className="text-[12px] font-semibold text-slate-800">EFA 分析单</span>
                <span className="inline-flex items-center gap-1 text-[9px] text-emerald-700">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" /> 已提交
                </span>
              </div>
              <div className="mt-0.5 text-[9.5px] text-slate-500 truncate" title={summary || modeLabel}>
                {modeLabel}{summary ? ` · ${summary}` : ""}
              </div>
            </div>
            <button
              type="button"
              onClick={() => setEditing(true)}
              title="展开并编辑 EFA 单"
              className="nodrag nopan w-7 h-7 rounded-md border border-slate-200 text-slate-400 hover:border-violet-300 hover:text-violet-600 grid place-items-center shrink-0"
            >
              <Edit2 size={11} />
            </button>
          </div>
          <div className="px-3 py-1.5 border-t border-slate-100 bg-slate-50/70 text-[9.5px] text-slate-400 truncate" title={action.title}>
            来源：{action.title}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="relative w-[360px]">
      <Handle type="target" position={direction === "LR" ? Position.Left : Position.Top} id={direction === "LR" ? "left" : "top"} />
      <Handle type="source" position={direction === "LR" ? Position.Right : Position.Bottom} id={direction === "LR" ? "right" : "bottom"} />
      <Handle type="source" id="relation-source" position={direction === "LR" ? Position.Right : Position.Bottom} style={{ opacity: 0, pointerEvents: "none" }} />
      <div className={`rounded-xl border-2 bg-white shadow-lg overflow-hidden transition-colors ${submitted ? "border-emerald-300" : "border-violet-300"}`}>
        <div className={`px-3.5 py-3 border-b transition-colors ${submitted ? "bg-gradient-to-r from-emerald-50 to-teal-50 border-emerald-100" : "bg-gradient-to-r from-violet-50 to-fuchsia-50 border-violet-100"}`}>
          <div className="flex items-center gap-2">
            <span className={`w-7 h-7 rounded-lg text-white grid place-items-center ${submitted ? "bg-emerald-600" : "bg-violet-600"}`}>{submitted ? <CheckCircle2 size={14} /> : <FlaskConical size={14} />}</span>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5"><div className="text-[13px] font-bold text-slate-800">新增EFA分析单</div>{submitted && <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-emerald-100 text-emerald-700 border border-emerald-200">已提交</span>}</div>
              <div className="text-[10px] text-slate-500 truncate">来源：{action.title}</div>
            </div>
          </div>
        </div>
        <div className="p-3 space-y-3">
          <div>
            <div className="text-[10px] text-slate-500 mb-1.5">分析对象</div>
            <div className="grid grid-cols-2 gap-2">
              {(["component", "wafer"] as const).map((mode) => (
                <button key={mode} type="button" disabled={submitted} onClick={() => setField("mode", mode)} className={`nodrag nopan h-8 rounded-lg border text-[11px] font-semibold transition-colors disabled:cursor-default ${draft.mode === mode ? submitted ? "border-emerald-500 bg-emerald-600 text-white" : "border-violet-500 bg-violet-600 text-white" : "border-slate-200 bg-white text-slate-600 hover:border-violet-300"}`}>{mode}</button>
              ))}
            </div>
          </div>

          {!draft.mode && <div className="rounded-lg border border-dashed border-violet-200 bg-violet-50/50 px-3 py-4 text-center text-[11px] text-violet-700">请先选择 component 或 wafer</div>}

          {draft.mode === "component" && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                {(["standard", "stage", "package", "quality", "failRate"] as const).map((key) => {
                  const label = key === "failRate" ? "fail rate" : key;
                  return <label key={key} className="text-[10px] text-slate-500">{label}<input disabled={submitted} value={String(draft[key] || "")} onChange={(e) => setField(key, e.target.value)} placeholder={`请输入 ${label}`} className={inputClass} /></label>;
                })}
              </div>
              <div className="pt-2 border-t border-slate-100">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-semibold text-slate-600">chiplist</span>
                  {!submitted && <button type="button" onClick={() => setField("chipList", [...chipList, { fsa: "", map: "", failMode: "", waferNo: "", chipNo: "", markCode: "" }])} className="nodrag nopan text-[10px] text-violet-600 hover:text-violet-800 inline-flex items-center gap-0.5"><Plus size={10} /> 添加颗粒</button>}
                </div>
                <div className="space-y-2">
                  {chipList.map((chip, index) => (
                    <div key={index} className="rounded-lg bg-slate-50 border border-slate-100 p-2">
                      <div className="flex items-center justify-between mb-1"><span className="text-[9px] text-slate-400">#{index + 1}</span>{!submitted && chipList.length > 1 && <button type="button" onClick={() => setField("chipList", chipList.filter((_, chipIndex) => chipIndex !== index))} className="nodrag nopan text-slate-300 hover:text-red-500"><X size={11} /></button>}</div>
                      <div className="grid grid-cols-3 gap-1.5">
                        {([['fsa', 'fsa'], ['map', 'map'], ['failMode', 'fail mode'], ['waferNo', 'waferno'], ['chipNo', 'chipno'], ['markCode', 'markcode']] as const).map(([key, label]) => (
                          <label key={key} className="text-[9px] text-slate-400">{label}<input disabled={submitted} value={chip[key] || ""} onChange={(e) => updateChip(index, key, e.target.value)} className={inputClass} /></label>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {draft.mode === "wafer" && (
            <div className="grid grid-cols-2 gap-2">
              {(["stage", "bin", "fsa", "map", "chipNo"] as const).map((key) => (
                <label key={key} className="text-[10px] text-slate-500">{key === "chipNo" ? "chipno" : key}<input disabled={submitted} value={String(draft[key] || "")} onChange={(e) => setField(key, e.target.value)} className={inputClass} /></label>
              ))}
            </div>
          )}

          {draft.mode && !submitted && <button type="button" onClick={() => { const submittedValue = { ...draft, submitted: true }; setDraft(submittedValue); setEditing(false); onSave(submittedValue); }} className="nodrag nopan w-full h-8 rounded-lg bg-violet-600 text-white text-[11px] font-semibold hover:bg-violet-700 inline-flex items-center justify-center gap-1.5"><Check size={12} /> 提交 EFA 单</button>}
          {submitted && (
            <div className="rounded-lg border border-emerald-200 bg-emerald-50 px-2.5 py-2 flex items-center gap-2">
              <CheckCircle2 size={14} className="text-emerald-600 shrink-0" />
              <div className="min-w-0 flex-1"><div className="text-[10.5px] font-semibold text-emerald-700">EFA 单已提交</div><div className="text-[9.5px] text-emerald-600/80">字段已保存并锁定</div></div>
              <button type="button" onClick={() => setEditing(true)} className="nodrag nopan h-7 px-2 rounded-md bg-white border border-emerald-200 text-[10px] text-emerald-700 hover:bg-emerald-100 inline-flex items-center gap-1"><Edit2 size={10} /> 编辑</button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function ActionNodeEditComponent({ data }: { data: any }) {
  const {
    action,
    caseData,
    isEditing,
    actionForm,
    setActionForm,
    onEdit,
    onSave,
    onCancel,
    onDelete,
    onAddChildGroup,
    guideTarget,
    guideAddChild,
    guideUrgency,
    direction,
    dimmed,
  } = data;

  const [efaModalOpen, setEfaModalOpen] = useState(false);
  const [reuseOpen, setReuseOpen] = useState(false);
  const [reuseTaskId, setReuseTaskId] = useState("");
  const [reuseError, setReuseError] = useState("");
  const [reusedTaskCode, setReusedTaskCode] = useState("");
  const reuseTask = (rawTaskId = reuseTaskId) => {
    const query = rawTaskId.trim().toLowerCase();
    const candidates = [
      ...flattenTasks(caseData?.tasks || []).map(({ task }) => task),
      ...mockCases.flatMap((item) => flattenTasks(item.tasks).map(({ task }) => task)),
    ];
    const sourceTask = candidates.find((task) => task.id.toLowerCase() === query || task.code?.toLowerCase() === query);
    if (!sourceTask) {
      setReuseError("未找到该任务 ID，请检查后重试。");
      return;
    }
    setActionForm?.({
      ...actionForm,
      title: sourceTask.title,
      expectation: sourceTask.expectation || "",
      urgency: sourceTask.urgency,
      department: sourceTask.department,
      assignee: sourceTask.owner === "待指派" ? "" : sourceTask.owner,
      assigneeType: sourceTask.assigneeType,
      skillId: sourceTask.skillId,
      skillRun: undefined,
      dueDate: sourceTask.dueDate || "",
      voiceNote: sourceTask.voiceNote,
      attachments: sourceTask.attachments?.map((attachment) => ({ ...attachment })) || [],
      type: sourceTask.type || (sourceTask.efaAnalysis ? "EFA分析" : undefined),
      coverageProgramVersion: sourceTask.coverageProgramVersion,
      coverageTestName: sourceTask.coverageTestName,
      coverageTestTime: sourceTask.coverageTestTime,
      coverageActionStage: sourceTask.coverageActionStage,
      coverageBallType: sourceTask.coverageBallType,
      coveragePackage: sourceTask.coveragePackage,
      coverageSpeed: sourceTask.coverageSpeed,
      coverageTester: sourceTask.coverageTester,
      coverageQG: sourceTask.coverageQG,
      coverageReleaseType: sourceTask.coverageReleaseType,
      coverageTeOwner: sourceTask.coverageTeOwner,
      coveragePeOwner: sourceTask.coveragePeOwner,
      efaAnalysis: sourceTask.efaAnalysis ? structuredClone(sourceTask.efaAnalysis) : undefined,
    });
    setReusedTaskCode(sourceTask.code || sourceTask.id);
    setReuseError("");
    setReuseOpen(false);
  };

  return (
    <div
      data-create-guide={guideTarget ? "task" : undefined}
      className={`relative transition-opacity ${dimmed ? "opacity-25" : "opacity-100"} ${isEditing ? (actionForm?.type === "EFA分析" ? "w-[560px] z-50" : "w-[280px] z-50") : "w-[256px]"}`}
    >
      <Handle type="target" position={direction === "LR" ? Position.Left : Position.Top} id={direction === "LR" ? "left" : "top"} style={direction === "LR" && isEditing ? { top: 62 } : undefined} />
      <Handle type="source" position={direction === "LR" ? Position.Right : Position.Bottom} id={direction === "LR" ? "right" : "bottom"} />

      {!isEditing ? (
        <div className={`relative bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm group/action transition-all duration-200 hover:scale-[1.03] hover:shadow-xl ${guideUrgency ? "ring-2 ring-[#0052D9]/30 shadow-lg" : ""}`}>
          <div data-create-guide={guideUrgency ? "urgency-bar" : undefined} className={`absolute left-0 top-0 bottom-0 w-1 ${urgencyBar[action.urgency] || "bg-slate-300"} ${guideUrgency ? "animate-pulse" : ""}`} title={`紧急度：${action.urgency}`} />
          <div className="relative pl-4 pr-3 py-3">
            {/* 卡片头：默认展示任务类型；hover 时原位切换编辑工具条，避免绝对定位互相覆盖 */}
            <div className="flex items-center gap-1.5 min-h-6 mb-1.5" title="待接受">
              <StatusBadge status="待接受" size={18} />
              <div className={`ml-auto items-center gap-1 ${guideAddChild ? "hidden" : "flex group-hover/action:hidden"}`}>
                {action.type && (
                  <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded text-[10px] border whitespace-nowrap bg-slate-100 text-slate-600 border-slate-200">
                    <Tag size={9} /> {action.type}
                  </span>
                )}
              </div>
              <div className={`ml-auto items-center gap-0.5 ${guideAddChild ? "flex" : "hidden group-hover/action:flex"}`}>
                <button onClick={onEdit} title="编辑" className="w-6 h-6 rounded-md bg-white/90 border border-slate-200 shadow-sm flex items-center justify-center text-slate-500 hover:text-[#0052D9]">
                  <Edit2 size={12} />
                </button>
                <button onClick={onDelete} title="删除" className="w-6 h-6 rounded-md bg-white/90 border border-slate-200 shadow-sm flex items-center justify-center text-slate-500 hover:text-red-500">
                  <Trash2 size={12} />
                </button>
                <button data-create-guide={guideAddChild ? "saved-task" : undefined} onClick={onAddChildGroup} title="基于此动作添加思路" className="w-6 h-6 rounded-full bg-[#0052D9] text-white shadow-sm flex items-center justify-center hover:bg-[#003FA8]">
                  <Plus size={13} />
                </button>
              </div>
            </div>
            <h5 className="text-[13px] font-semibold text-slate-900 leading-snug">{action.title}</h5>
            {action.expectation && (
              <div className="mt-2 flex items-start gap-1.5">
                <span className="shrink-0 text-[10px] text-slate-400 mt-px w-7">预期</span>
                <p className="flex-1 text-[11px] text-slate-600 leading-snug line-clamp-2">{action.expectation}</p>
              </div>
            )}
            {action.efaAnalysis && (
              <div className="mt-2 w-full flex items-center gap-1.5 px-2 py-1 rounded-md border border-violet-200 bg-violet-50/70 text-[10.5px] text-violet-700">
                <FlaskConical size={11} className="shrink-0" />
                <span className="font-medium shrink-0">EFA 分析单</span>
                {action.efaAnalysis.code && <span className="font-mono truncate">{action.efaAnalysis.code}</span>}
                <span className="ml-auto shrink-0">{action.efaAnalysis.submitted ? "已提交" : "待提交"}</span>
              </div>
            )}
            <div className="max-h-0 opacity-0 group-hover/action:max-h-[320px] group-hover/action:opacity-100 overflow-hidden transition-all duration-200">
              <div className="mt-2 pt-2 border-t border-slate-200/70 space-y-1.5 text-[11px] text-slate-500">
                <div className="flex items-center gap-1.5"><User size={11} /> 负责人：<span className="text-slate-700">{action.assignee || "待指派"}</span></div>
                <div className="flex items-center gap-1.5"><span className="text-slate-400">部门：</span>{action.department}</div>
                {action.dueDate && <div className="flex items-center gap-1.5"><Calendar size={11} /> 预期完成：{action.dueDate}</div>}
                {action.type === "Coverage上线" && (action.coverageProgramVersion || action.coverageTestName || action.coverageTestTime || action.coverageActionStage || action.coverageBallType || action.coveragePackage) && (
                  <div className="rounded-md border border-cyan-100 bg-cyan-50/70 px-2 py-1.5 space-y-1 text-[10px] text-cyan-800">
                    <div className="flex items-center gap-1 font-medium"><Radar size={10} /> Coverage 上线</div>
                    <div className="grid grid-cols-2 gap-x-2 gap-y-0.5">
                      {action.coverageProgramVersion && <span>程式版本：{action.coverageProgramVersion}</span>}
                      {action.coverageTestName && <span>测试项：{action.coverageTestName}</span>}
                      {action.coverageTestTime && <span>时长：{action.coverageTestTime}</span>}
                      {action.coverageActionStage && <span>站点：{action.coverageActionStage}</span>}
                      {action.coverageBallType && <span>Ball type：{action.coverageBallType}</span>}
                      {action.coveragePackage && <span>Package：{action.coveragePackage}</span>}
                    </div>
                  </div>
                )}
                {(action.attachments?.length || action.voiceNote) && (
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {action.attachments && action.attachments.length > 0 && (
                      <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded border border-slate-200 bg-white" title={action.attachments.map((item) => item.name).join("、")}>
                        附件 {action.attachments.length}
                      </span>
                    )}
                    {action.voiceNote && <VoicePlayer src={action.voiceNote} />}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className={`nowheel bg-white border-2 border-[#0052D9] rounded-xl p-3.5 shadow-xl overflow-y-auto overscroll-contain ${actionForm?.type === "EFA分析" ? "max-h-[55vh]" : "max-h-[78vh]"}`}>
          <div className="space-y-2.5">
            <div className="sticky top-[-14px] z-20 -mx-3.5 -mt-3.5 px-3.5 pt-3.5 pb-2 flex items-center justify-between border-b border-slate-100 bg-white/95 backdrop-blur">
              <div className="text-xs text-[#0052D9] font-medium">编辑执行任务</div>
              <div className="flex items-center gap-1.5">
                <button type="button" onClick={() => { setReuseOpen((open) => !open); setReuseError(""); }} className="nodrag nopan h-6 rounded-full border border-[#0052D9]/25 px-2 text-[11px] text-[#0052D9] hover:bg-[#0052D9]/5 inline-flex items-center gap-1"><Copy size={11} />复用</button>
                <select value={actionForm?.type || ""} onChange={(e) => { const type = (e.target.value || undefined) as TaskType | undefined; setActionForm?.({ ...actionForm, type, efaAnalysis: type === "EFA分析" ? (actionForm?.efaAnalysis || efaDefaults(caseData)) : undefined }); }} className="h-6 rounded-full border px-2 text-[11px] text-center outline-none border-[#0052D9]/30 text-[#0052D9] bg-[#0052D9]/5">
                  <option value="">通用</option>{TASK_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
            </div>
            {reuseOpen && <div className="nodrag nopan rounded-lg border border-[#0052D9]/20 bg-[#0052D9]/[0.04] p-2.5"><label className="text-[11px] text-slate-600">任务 ID<input autoFocus value={reuseTaskId} onChange={(event) => { setReuseTaskId(event.target.value); setReuseError(""); }} onKeyDown={(event) => { if (event.key === "Enter") { event.preventDefault(); event.stopPropagation(); reuseTask(event.currentTarget.value); } }} placeholder="输入任务 ID 或任务编号后回车" className="mt-1 h-8 w-full rounded border border-slate-200 bg-white px-2 text-xs outline-none focus:border-[#0052D9]" /></label>{reuseError && <div className="mt-1.5 text-[10px] text-red-500">{reuseError}</div>}</div>}
            {reusedTaskCode && <div className="rounded border border-emerald-200 bg-emerald-50 px-2 py-1 text-[10px] text-emerald-700">已复用 {reusedTaskCode} 的任务字段，当前任务 ID 与状态保持不变。</div>}
            <div>
              <label className="text-xs text-slate-500 block mb-1">任务名称</label>
              <input
                value={actionForm?.title || ""}
                onChange={(e) => setActionForm?.({ ...actionForm, title: e.target.value })}
                placeholder="符合预期怎么做 + 不符合怎么做"
                className="w-full h-8 px-2 text-sm border border-slate-200 rounded outline-none focus:border-[#0052D9]"
              />
              <div className="mt-1 text-[10px] text-slate-400">建议：执行任务名称 = 符合预期怎么做 + 不符合怎么做</div>
            </div>
            <div>
              <label className="text-xs text-slate-500 block mb-1">预期</label>
              <input
                value={actionForm?.expectation || ""}
                onChange={(e) => setActionForm?.({ ...actionForm, expectation: e.target.value })}
                placeholder="预期"
                className="w-full h-8 px-2 text-sm border border-slate-200 rounded outline-none focus:border-[#0052D9]"
              />
            </div>
            <div className="flex gap-2">
              <div className="flex-1">
                <label className="text-xs text-slate-500 block mb-1">紧急程度</label>
                <select value={actionForm?.urgency || "一般"} onChange={(e) => setActionForm?.({ ...actionForm, urgency: e.target.value as Urgency })} className="w-full h-8 px-2 text-sm border border-slate-200 rounded outline-none focus:border-[#0052D9]">
                  <option value="非常紧急">非常紧急</option><option value="紧急">紧急</option><option value="一般">一般</option><option value="不紧急">不紧急</option>
                </select>
              </div>
              <div className="flex-1">
                <label className="text-xs text-slate-500 block mb-1">期望完成时间</label>
                <input
                  type="date"
                  value={actionForm?.dueDate || ""}
                  onChange={(e) => setActionForm?.({ ...actionForm, dueDate: e.target.value })}
                  className="w-full h-8 px-2 text-sm border border-slate-200 rounded outline-none focus:border-[#0052D9]"
                />
              </div>
            </div>
            <div className="flex gap-2">
              <div className="flex-1 min-w-0">
                <label className="text-xs text-slate-500 block mb-1">负责人</label>
                <TaskAssigneeField compact value={{ assignee: actionForm?.assignee || "", department: actionForm?.department || "PTE", assigneeType: actionForm?.assigneeType, skillId: actionForm?.skillId, skillRun: actionForm?.skillRun }} onChange={(next) => setActionForm?.({ ...actionForm, ...next })} />
              </div>
              <div className="flex-1">
                <label className="text-xs text-slate-500 block mb-1">分派部门</label>
                <select
                  value={actionForm?.department || "PTE"}
                  onChange={(e) => setActionForm?.({ ...actionForm, department: e.target.value })}
                  className="w-full h-8 px-2 text-sm border border-slate-200 rounded outline-none focus:border-[#0052D9]"
                >
                  {MM_DEPARTMENTS.map((d) => (
                    <option key={d} value={d}>{d}</option>
                  ))}
                </select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div className="min-w-0">
                <label className="text-xs text-slate-500 block mb-1">附件</label>
                <AttachmentInput
                  value={actionForm?.attachments || []}
                  onChange={(next) => setActionForm?.({ ...actionForm, attachments: next })}
                  compact
                />
              </div>
              <div className="min-w-0">
                <label className="text-xs text-slate-500 block mb-1">语音备注</label>
                <VoiceRecorder
                  value={actionForm?.voiceNote}
                  onChange={(voiceNote) => setActionForm?.({ ...actionForm, voiceNote })}
                  compact
                />
              </div>
            </div>
            {actionForm?.type === "Coverage上线" && (
              <div className="rounded-lg border border-cyan-200 bg-cyan-50/60 p-2.5 space-y-2.5">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-cyan-800"><Radar size={13} /> Coverage 上线信息</div>
                <CoveragePatternFields compact value={actionForm || {}} onChange={(next) => setActionForm?.({ ...actionForm, ...next })} />
                <label className="text-[11px] text-slate-500 block">
                  程式版本 <span className="text-red-500">*</span>
                  <input value={actionForm?.coverageProgramVersion || ""} onChange={(e) => setActionForm?.({ ...actionForm, coverageProgramVersion: e.target.value })} placeholder="请输入程式版本" className="mt-1 nodrag nopan w-full h-8 px-2 text-xs bg-white border border-slate-200 rounded outline-none focus:border-cyan-500" />
                </label>
                <label className="text-[11px] text-slate-500 block">
                  测试项名称 <span className="text-red-500">*</span>
                  <input value={actionForm?.coverageTestName || ""} onChange={(e) => setActionForm?.({ ...actionForm, coverageTestName: e.target.value })} placeholder="请输入测试项名称" className="mt-1 nodrag nopan w-full h-8 px-2 text-xs bg-white border border-slate-200 rounded outline-none focus:border-cyan-500" />
                </label>
                <label className="text-[11px] text-slate-500 block">
                  测试时长 <span className="text-red-500">*</span>
                  <input value={actionForm?.coverageTestTime || ""} onChange={(e) => setActionForm?.({ ...actionForm, coverageTestTime: e.target.value })} placeholder="请输入测试时长" className="mt-1 nodrag nopan w-full h-8 px-2 text-xs bg-white border border-slate-200 rounded outline-none focus:border-cyan-500" />
                </label>
                <CoverageOwnerFields compact value={actionForm || {}} onChange={(next) => setActionForm?.({ ...actionForm, ...next })} />
              </div>
            )}
            {actionForm?.type === "EFA分析" && (
              <div className="rounded-lg border border-violet-300 bg-violet-50/70">
                <div className="flex items-center gap-2 p-2.5"><FlaskConical size={14} className="text-violet-600 shrink-0" /><span className="text-xs font-medium text-slate-700">EFA 分析信息</span>{actionForm?.efaAnalysis?.code && <span className="ml-auto font-mono text-[10px] text-violet-600 shrink-0">{actionForm.efaAnalysis.code}</span>}</div>
                <div className="px-2.5 pb-2.5 pt-2 border-t border-violet-100 nodrag nopan nowheel">
                  <EfaInlineFields value={actionForm.efaAnalysis || efaDefaults(caseData)} onChange={(v) => setActionForm?.({ ...actionForm, efaAnalysis: v })} />
                </div>
              </div>
            )}
            <div className="sticky bottom-[-14px] z-20 -mx-3.5 -mb-3.5 px-3.5 pt-2 pb-3.5 flex gap-2 border-t border-slate-100 bg-white/95 backdrop-blur">
              <button
                onClick={onSave}
                className="flex-1 h-7 rounded bg-[#0052D9] text-white text-xs hover:bg-[#003FA8]"
              >
                确认
              </button>
              <button
                onClick={onCancel}
                className="flex-1 h-7 rounded border border-slate-200 text-slate-600 text-xs hover:bg-slate-50"
              >
                取消
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}


