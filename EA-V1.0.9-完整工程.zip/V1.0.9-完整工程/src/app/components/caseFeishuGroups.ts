import { useEffect, useState } from "react";
import { currentUser, flattenTasks, mockCases, orgRole, ownerToDepartment } from "./data";
import { loadCaseTaskTree } from "./caseTaskTrees";
import { caseParticipants } from "./caseParticipants";

export interface DemoCaseGroup { id: string; caseId: string; name: string; createdBy: string; createdAt: string; members: string[]; failed: string[] }
const KEY = "ea_v109_case_group_demo";
let cache: Record<string, DemoCaseGroup> | undefined;
const listeners = new Set<() => void>();
function load() {
  if (!cache) { try { const raw = JSON.parse(localStorage.getItem(KEY) ?? "{}"); cache = raw && typeof raw === "object" && !Array.isArray(raw) ? raw : {}; } catch { cache = {}; } }
  return cache!;
}
function save(group: DemoCaseGroup) {
  const next = { ...load(), [group.caseId]: group };
  try { localStorage.setItem(KEY, JSON.stringify(next)); } catch { throw new Error("演示群组保存失败，请重试。"); }
  cache = next; listeners.forEach(listener => listener()); return group;
}
export function caseGroupCandidates(caseId: string, creator?: string) {
  const record = mockCases.find(item => item.id === caseId);
  if (!record) throw new Error("Case 不存在。");
  const tasks = loadCaseTaskTree(record.id, record.tasks);
  const participants = [
    ...(record.participants ?? []),
    ...flattenTasks(tasks).flatMap(({ task }) => !task.code ? [] : [
      ...(task.assigneeType === "skill" ? [] : [{ name: task.owner, department: task.department }]),
      ...(task.collaborators ?? []),
    ]),
    ...(creator ? [{ name: creator, department: ownerToDepartment[creator] ?? "管理层" }] : []),
  ];
  return caseParticipants({ ...record, tasks, participants });
}
export function getCaseGroup(caseId: string) { return load()[caseId]; }
export function canManageCaseGroup(actor = currentUser.name) {
  return ["主管", "总监", "VP"].includes(orgRole(actor));
}
export function updateDemoCaseGroup(caseId: string, action: "create" | "sync", failedNames: string[] = []) {
  if (!canManageCaseGroup()) throw new Error("仅主管及以上管理者可以操作HEMS群组。");
  const record = mockCases.find(item => item.id === caseId);
  if (!record) throw new Error("Case 不存在。");
  if (!["create", "sync"].includes(action)) throw new Error("不支持此操作，请通过补充参与人邀请新增成员。");
  const existing = getCaseGroup(caseId);
  if (action === "create" && existing) return existing;
  if (action !== "create" && !existing) throw new Error("请先由主管及以上管理者创建群。");
  const group = existing ?? { id: `demo-group-${crypto.randomUUID()}`, caseId, name: `${record.code} · ${record.name}`, createdBy: currentUser.name, createdAt: new Date().toISOString(), members: [currentUser.name], failed: [] };
  const requested = caseGroupCandidates(caseId, action === "create" ? currentUser.name : undefined).map(person => person.name);
  const additions = requested.filter(name => !group.members.includes(name));
  const failures = additions.filter(name => (!ownerToDepartment[name] && !canManageCaseGroup(name)) || failedNames.includes(name));
  const joined = additions.filter(name => !failures.includes(name));
  return save({ ...group, members: [...new Set([...group.members, ...joined])], failed: [...new Set([...group.failed.filter(name => !requested.includes(name)), ...failures])].filter(name => !group.members.includes(name) && !joined.includes(name)) });
}
export function useCaseGroup(caseId: string) {
  const [, setTick] = useState(0);
  useEffect(() => { const listener = () => setTick(value => value + 1); listeners.add(listener); return () => { listeners.delete(listener); }; }, []);
  return getCaseGroup(caseId);
}