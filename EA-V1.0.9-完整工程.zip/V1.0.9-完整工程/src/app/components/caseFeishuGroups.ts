import { useEffect, useState } from "react";
import { currentUser, mockCases, ownerToDepartment } from "./data";
import { loadCaseTaskTree } from "./caseTaskTrees";
import { caseParticipants } from "./caseParticipants";

export interface DemoCaseGroup { id: string; caseId: string; name: string; createdBy: string; createdAt: string; members: string[]; failed: string[] }
const KEY = "ea_v109_case_group_demo";
let cache: Record<string, DemoCaseGroup> | undefined;
const listeners = new Set<() => void>();
function load() {
  if (!cache) { try { const raw = JSON.parse(localStorage.getItem(KEY) ?? "{}"); cache = raw && typeof raw === "object" && !Array.isArray(raw) ? raw : {}; } catch { cache = {}; } }
  return cache!;
}
function save(group: DemoCaseGroup) {
  const next = { ...load(), [group.caseId]: group };
  try { localStorage.setItem(KEY, JSON.stringify(next)); } catch { throw new Error("演示群组保存失败，请重试。"); }
  cache = next; listeners.forEach(listener => listener()); return group;
}
export function caseGroupCandidates(caseId: string) {
  const record = mockCases.find(item => item.id === caseId);
  if (!record) throw new Error("Case 不存在。");
  return caseParticipants({ ...record, tasks: loadCaseTaskTree(record.id, record.tasks) });
}
export function getCaseGroup(caseId: string) { return load()[caseId]; }
export function updateDemoCaseGroup(caseId: string, action: "create" | "join" | "sync", failedNames: string[] = []) {
  const record = mockCases.find(item => item.id === caseId);
  if (!record) throw new Error("Case 不存在。");
  const people = caseGroupCandidates(caseId).map(person => person.name);
  if (action !== "join" && currentUser.name !== record.owner) throw new Error("仅 Case Owner 可以创建群或同步参与人。");
  if (action === "join" && !people.includes(currentUser.name)) throw new Error("仅当前 Case 参与人员可以加入。");
  if (!["create", "join", "sync"].includes(action)) throw new Error("不支持此操作。");
  const existing = getCaseGroup(caseId);
  if (action === "create" && existing) return existing;
  if (action !== "create" && !existing) throw new Error("请先由 Owner 创建群。");
  const group = existing ?? { id: `demo-group-${crypto.randomUUID()}`, caseId, name: `${record.code} · ${record.name}`, createdBy: currentUser.name, createdAt: new Date().toISOString(), members: [record.owner], failed: [] };
  const requested = action === "join" ? [currentUser.name] : people;
  const additions = requested.filter(name => !group.members.includes(name));
  const failures = additions.filter(name => !ownerToDepartment[name] || failedNames.includes(name));
  const joined = additions.filter(name => !failures.includes(name));
  if (action === "join" && failures.length) throw new Error("演示加入失败：账号未映射或模拟接口失败，请稍后重试。");
  return save({ ...group, members: [...new Set([...group.members, ...joined])], failed: [...new Set([...group.failed.filter(name => !requested.includes(name)), ...failures])].filter(name => !group.members.includes(name) && !joined.includes(name)) });
}
export function useCaseGroup(caseId: string) {
  const [, setTick] = useState(0);
  useEffect(() => { const listener = () => setTick(value => value + 1); listeners.add(listener); return () => { listeners.delete(listener); }; }, []);
  return getCaseGroup(caseId);
}