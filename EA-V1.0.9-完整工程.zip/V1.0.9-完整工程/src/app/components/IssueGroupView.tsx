import { useMemo, useState } from "react";
import {
  GitMerge, Sparkles, ChevronRight, FolderMinus, X, Plus, Layers,
} from "lucide-react";
import {
  mockCases, caseProductOf, issueStatusColors, objectTypeColors, ObjectType, OBJECT_TYPES, CaseItem,
} from "./data";
import { useIssues, groupCasesIntoIssue, aggregateCase } from "./domainStore";
import { suggestIssueGroups } from "./caseInsights";

function Chip({ text, cls }: { text: string; cls: string }) {
  return <span className={`inline-flex items-center px-1.5 py-0.5 rounded text-[11px] border ${cls}`}>{text}</span>;
}

interface Props {
  onOpenCase: (id: string) => void;
  onOpenIssue: (id: string) => void;
  filterCase?: (c: CaseItem) => boolean;
}

// Case 中心「Issue 归纳视图」（Jira backlog by Epic）：AI 建议归纳 + 按 Issue 分组泳道 + 未归纳多选归纳
export function IssueGroupView({ onOpenCase, onOpenIssue, filterCase }: Props) {
  const issues = useIssues();
  const grouped = new Set(issues.flatMap((i) => i.caseIds));
  const pass = (c: CaseItem) => (filterCase ? filterCase(c) : true);
  const ungrouped = mockCases.filter((c) => !grouped.has(c.id) && pass(c));

  const [sel, setSel] = useState<Set<string>>(new Set());
  const [groupOpen, setGroupOpen] = useState(false);
  const [aiHidden, setAiHidden] = useState<Set<string>>(new Set());

  const aiGroups = useMemo(() => suggestIssueGroups(mockCases).filter((g) => {
    // 过滤掉“已经整簇同属一个 Issue”的建议
    const iss = issues.find((i) => g.caseIds.every((id) => i.caseIds.includes(id)));
    return !iss && !aiHidden.has(g.caseIds.join(","));
  }), [issues, aiHidden]);

  const toggle = (id: string) => setSel((s) => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n; });

  return (
    <div className="space-y-4">

      {/* AI 建议归纳 */}
      {aiGroups.length > 0 && (
        <div className="rounded-xl border border-[#7A3DFF]/25 bg-[#7A3DFF]/[0.04] p-3.5">
          <div className="flex items-center gap-1.5 mb-2">
            <Sparkles size={15} className="text-[#7A3DFF]" />
            <span className="text-sm text-slate-800">AI 建议归纳</span>
            <span className="text-xs text-slate-400">检测到互相相似的 Case，建议归为同一 Issue</span>
          </div>
          <div className="space-y-2">
            {aiGroups.map((g) => (
              <div key={g.caseIds.join(",")} className="rounded-md border border-slate-200 bg-white p-2.5">
                <div className="flex items-center gap-2">
                  <span className="text-sm text-slate-800">{g.suggestedName}</span>
                  <Chip text={g.objectType} cls={objectTypeColors[g.objectType]} />
                  <span className="text-[11px] text-slate-400">相似度 {Math.round(g.score * 100)}% · {g.caseIds.length} 个 Case</span>
                  <div className="ml-auto flex items-center gap-2">
                    <button onClick={() => setAiHidden((s) => new Set(s).add(g.caseIds.join(",")))} className="text-[11px] text-slate-400 hover:text-slate-600">忽略</button>
                    <button onClick={() => { const iss = groupCasesIntoIssue(g.caseIds, { name: g.suggestedName, objectType: g.objectType }); onOpenIssue(iss.id); }}
                      className="text-[11px] px-2 py-1 rounded bg-[#7A3DFF] text-white hover:bg-[#6a2ee6] inline-flex items-center gap-1">
                      <GitMerge size={11} /> 一键归纳为 Issue
                    </button>
                  </div>
                </div>
                <div className="mt-1.5 flex flex-wrap gap-1">
                  {g.caseIds.map((id) => {
                    const c = mockCases.find((x) => x.id === id); if (!c) return null;
                    return (
                      <button key={id} onClick={() => onOpenCase(id)} className="text-[11px] px-1.5 py-0.5 rounded bg-slate-50 border border-slate-200 text-slate-600 hover:border-[#0052D9]/40">
                        <span className="font-mono text-slate-400">{c.code}</span> {c.name}
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Issue 泳道 */}
      <div className="space-y-2.5">
        {issues.map((iss) => {
          const memberIds = iss.caseIds.filter((id) => { const c = mockCases.find((x) => x.id === id); return c && pass(c); });
          // 有筛选时，隐藏无匹配成员的泳道
          if (iss.caseIds.length > 0 && memberIds.length === 0) return null;
          return (
          <div key={iss.id} className="rounded-xl border border-slate-200 bg-white overflow-hidden">
            <button onClick={() => onOpenIssue(iss.id)} className="w-full flex items-center gap-2 px-4 py-2.5 hover:bg-slate-50 border-b border-slate-100">
              <GitMerge size={14} className="text-[#7A3DFF]" />
              <span className="font-mono text-[11px] text-slate-400">{iss.code}</span>
              <span className="text-sm text-slate-900">{iss.name}</span>
              <Chip text={iss.status} cls={issueStatusColors[iss.status]} />
              <Chip text={iss.objectType} cls={objectTypeColors[iss.objectType]} />
              <span className="ml-auto text-xs text-slate-400">{iss.caseIds.length} 个 Case</span>
              <ChevronRight size={15} className="text-slate-300" />
            </button>
            <div className="divide-y divide-slate-50">
              {memberIds.map((id) => {
                const c = mockCases.find((x) => x.id === id); if (!c) return null;
                const prod = caseProductOf(c);
                return (
                  <button key={id} onClick={() => onOpenCase(id)} className="w-full flex items-center gap-2 px-4 py-2 hover:bg-slate-50 text-left">
                    <span className="font-mono text-[11px] text-slate-400">{c.code}</span>
                    <span className="text-sm text-slate-700 flex-1 min-w-0 truncate">{c.name}</span>
                    {prod && <Chip text={prod.code} cls="bg-slate-50 text-slate-500 border-slate-200" />}
                    {c.solutionPath?.length ? <Chip text="已给解题路径" cls="bg-emerald-50 text-emerald-600 border-emerald-200" /> : null}
                  </button>
                );
              })}
              {iss.caseIds.length === 0 && <div className="px-4 py-2 text-xs text-slate-400">暂无成员 Case</div>}
            </div>
          </div>
          );
        })}
      </div>

      {/* 未归纳 Case */}
      <div className="rounded-xl border border-slate-200 bg-white overflow-hidden">
        <div className="flex items-center gap-2 px-4 py-2.5 border-b border-slate-100 bg-slate-50/60">
          <FolderMinus size={14} className="text-slate-400" />
          <span className="text-sm text-slate-700">未归纳 Case</span>
          <span className="text-xs text-slate-400">{ungrouped.length} 个 · 勾选后可归纳为一个 Issue</span>
          {sel.size > 0 && (
            <div className="ml-auto flex items-center gap-2">
              <span className="text-xs text-slate-500">已选 {sel.size}</span>
              <button onClick={() => setGroupOpen(true)} className="text-[11px] px-2 py-1 rounded bg-[#0052D9] text-white hover:bg-[#0047b8] inline-flex items-center gap-1">
                <GitMerge size={11} /> 归纳为一个 Issue
              </button>
              <button onClick={() => setSel(new Set())} className="text-[11px] text-slate-400 hover:text-slate-600">清空</button>
            </div>
          )}
        </div>
        <div className="divide-y divide-slate-50">
          {ungrouped.map((c) => {
            const prod = caseProductOf(c);
            return (
              <label key={c.id} className={`flex items-center gap-2 px-4 py-2 cursor-pointer ${sel.has(c.id) ? "bg-[#0052D9]/[0.04]" : "hover:bg-slate-50"}`}>
                <input type="checkbox" checked={sel.has(c.id)} onChange={() => toggle(c.id)} className="accent-[#0052D9]" />
                <span className="font-mono text-[11px] text-slate-400">{c.code}</span>
                <button onClick={(e) => { e.preventDefault(); onOpenCase(c.id); }} className="text-sm text-slate-700 hover:text-[#0052D9] flex-1 min-w-0 truncate text-left">{c.name}</button>
                {prod && <Chip text={prod.code} cls="bg-slate-50 text-slate-500 border-slate-200" />}
              </label>
            );
          })}
          {ungrouped.length === 0 && <div className="px-4 py-3 text-xs text-slate-400">全部 Case 均已归纳。</div>}
        </div>
      </div>

      {groupOpen && (
        <GroupModal caseIds={[...sel]} onClose={() => setGroupOpen(false)} onDone={(id) => { setGroupOpen(false); setSel(new Set()); onOpenIssue(id); }} />
      )}
    </div>
  );
}

function GroupModal({ caseIds, onClose, onDone }: { caseIds: string[]; onClose: () => void; onDone: (id: string) => void }) {
  const cases = caseIds.map((id) => mockCases.find((c) => c.id === id)!).filter(Boolean);
  const defOt = caseProductOf(cases[0])?.objectType ?? "IC";
  const [name, setName] = useState(`${defOt} · ${cases[0]?.failMode || "共性失效"}`);
  const [objType, setObjType] = useState<ObjectType>(defOt);
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40" onClick={onClose}>
      <div className="w-[520px] bg-white rounded-lg shadow-xl border border-slate-200 p-5" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center gap-2 mb-3">
          <h3 className="text-slate-900">归纳 {caseIds.length} 个 Case 为一个 Issue</h3>
          <button onClick={onClose} className="ml-auto text-slate-400 hover:text-slate-600"><X size={16} /></button>
        </div>
        <div className="mb-2 flex flex-wrap gap-1">
          {cases.map((c) => <Chip key={c.id} text={c.code} cls="bg-slate-50 text-slate-500 border-slate-200" />)}
        </div>
        <label className="block text-xs text-slate-600">Issue 名称
          <input value={name} onChange={(e) => setName(e.target.value)} autoFocus className="mt-1 w-full h-9 px-2.5 text-sm rounded border border-slate-200 outline-none focus:border-[#0052D9]" />
        </label>
        <label className="block text-xs text-slate-600 mt-2">objectType
          <select value={objType} onChange={(e) => setObjType(e.target.value as ObjectType)} className="mt-1 w-full h-9 px-2 text-sm rounded border border-slate-200 outline-none focus:border-[#0052D9] bg-white">
            {OBJECT_TYPES.map((o) => <option key={o} value={o}>{o}</option>)}
          </select>
        </label>
        <div className="flex items-center justify-end gap-2 pt-3 mt-3 border-t border-slate-100">
          <button onClick={onClose} className="h-8 px-3 text-sm rounded-md border border-slate-200 text-slate-600 hover:bg-slate-50">取消</button>
          <button disabled={name.trim().length < 2} onClick={() => { const iss = groupCasesIntoIssue(caseIds, { name: name.trim(), objectType: objType }); onDone(iss.id); }}
            className="h-8 px-3.5 text-sm rounded-md bg-[#0052D9] text-white hover:bg-[#0047b8] disabled:opacity-40">创建 Issue</button>
        </div>
      </div>
    </div>
  );
}
