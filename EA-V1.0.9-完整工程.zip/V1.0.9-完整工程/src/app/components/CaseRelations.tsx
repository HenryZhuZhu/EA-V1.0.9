import { useMemo, useState } from "react";
import {
  GitMerge, Link2, Sparkles, Plus, X, ChevronRight, AlertTriangle, Unlink, Search,
} from "lucide-react";
import {
  mockCases, caseProductOf, issueStatusColors, objectTypeColors, ObjectType, OBJECT_TYPES,
  CaseLinkType, caseLinkColors, caseLinkPhrase, flattenTasks, urgencyBar, levelColors, CaseItem,
  PROBLEM_DOMAINS, ProblemDomain, PROBLEM_TYPES, ProblemType, currentUser,
} from "./data";
import {
  useIssues, useCaseLinks, useIssuePromotionSuggestion, aggregateCase, detachCase, createIssue, linkCases, unlinkCases,
} from "./domainStore";
import { suggestRelatedCases } from "./caseInsights";
import { ProgressRing } from "./ProgressRing";
import { RelatedCaseCard } from "./RelatedCaseCard";

function Chip({ text, cls, title }: { text: string; cls: string; title?: string }) {
  return <span title={title} className={`inline-flex items-center px-1.5 py-0.5 rounded text-[11px] border ${title ? "cursor-help" : ""} ${cls}`}>{text}</span>;
}

const caseLinkHelp: Record<CaseLinkType, string> = {
  重复: "两个 Case 描述的是同一问题；仅标记关系，不会自动合并或删除数据。",
  关联: "两个 Case 存在分析线索或业务关联，但仍各自独立推进。",
};

function progressOfCase(caseItem: CaseItem): number {
  const actions = flattenTasks(caseItem.tasks).map(({ task }) => task).filter((task) => task.code);
  const base = actions.length ? actions : caseItem.tasks;
  return Math.round(base.reduce((sum, task) => sum + (task.progress || 0), 0) / Math.max(base.length, 1));
}

function CaseCompletion({ caseItem }: { caseItem: CaseItem }) {
  const progress = progressOfCase(caseItem);
  return (
    <span className="shrink-0 inline-flex items-center" title={`任务平均完成度 ${progress}%`}>
      <ProgressRing value={progress} size={18} stroke={2.5} />
    </span>
  );
}

interface Props {
  caseId: string;
  onOpenCase?: (id: string) => void;
  onOpenIssue?: (id: string) => void;
  hideIssue?: boolean;
  inline?: boolean;
}

// Jira Epic 式：一个 Case 的「关联 Case（弱链接，多对多）」+ AI 建议
// V1.0.4：取消 Issue 概念 —— 只保留「关联 Case」，移除「升级为 Issue」
export function CaseRelations({ caseId, onOpenCase, onOpenIssue, hideIssue }: Props) {
  const c = mockCases.find((x) => x.id === caseId);
  if (!c) return null;
  return (
    <section aria-label="关联 Case" className="bg-white border border-slate-200 rounded-lg p-4 space-y-3">
      <CaseLinks caseId={caseId} onOpenCase={onOpenCase} onOpenIssue={onOpenIssue} inline />
    </section>
  );
}

/* ------------------------------ 归属 Issue（多对多） ------------------------------ */
function IssueOwnership({ caseId, onOpenCase, onOpenIssue }: Props) {
  const issues = useIssues();
  const suggestion = useIssuePromotionSuggestion(caseId);
  const c = mockCases.find((x) => x.id === caseId)!;
  const prod = caseProductOf(c);
  const myIssues = issues.filter((i) => i.caseIds.includes(caseId));
  const [picking, setPicking] = useState<null | "existing" | "new">(null);

  // 兄弟 Case：所有归属 Issue 的成员并集（排除自身）
  const siblingIds = Array.from(new Set(myIssues.flatMap((i) => i.caseIds))).filter((id) => id !== caseId);

  return (
    <div>
      <div className="flex items-center gap-1.5 mb-2.5">
        <GitMerge size={14} className="text-[#7A3DFF]" />
        <h3 className="text-sm text-slate-800">归属 Issue（共性问题）</h3>
        <span className="text-[11px] text-slate-400">可多个 · 可暂不关联</span>
      </div>

      {suggestion && (
        <div className="mb-2 rounded-md border border-[#7A3DFF]/25 bg-[#7A3DFF]/[0.05] p-2.5">
          <div className="flex items-start gap-2">
            <AlertTriangle size={14} className="text-[#7A3DFF] mt-0.5" />
            <div className="min-w-0 flex-1">
              <div className="text-xs text-slate-700">系统建议创建 Issue：{suggestion.reason}</div>
              <div className="text-[11px] text-slate-500 mt-0.5 truncate">
                关联范围：{suggestion.caseIds.length} 个 Case · {suggestion.productIds.length} 个产品
              </div>
            </div>
            <button
              onClick={() => setPicking("new")}
              className="shrink-0 h-7 px-2.5 rounded-md border border-[#7A3DFF]/35 text-[11px] text-[#7A3DFF] hover:bg-[#7A3DFF]/10"
            >
              建议创建
            </button>
          </div>
        </div>
      )}

      {myIssues.length > 0 ? (
        <div className="space-y-2">
          <div className="space-y-1.5">
            {myIssues.map((issue) => (
              <div key={issue.id} className="rounded-md border border-[#7A3DFF]/20 bg-[#7A3DFF]/5 p-2.5">
                <div className="flex items-center gap-1.5">
                  <span className="font-mono text-[11px] text-slate-400">{issue.code}</span>
                  <Chip text={issue.status} cls={issueStatusColors[issue.status]} />
                  <Chip text={issue.objectType} cls={objectTypeColors[issue.objectType]} />
                  <button onClick={() => detachCase(issue.id, caseId)} title="取消该归属" className="ml-auto text-slate-300 hover:text-red-500"><Unlink size={12} /></button>
                  <button onClick={() => onOpenIssue?.(issue.id)} className="text-slate-300 hover:text-[#0052D9]"><ChevronRight size={14} /></button>
                </div>
                <button onClick={() => onOpenIssue?.(issue.id)} className="text-sm text-slate-800 mt-1 text-left hover:text-[#0052D9]">{issue.name}</button>
              </div>
            ))}
          </div>
          {siblingIds.length > 0 && (
            <div>
              <div className="text-[11px] text-slate-400 mb-1">同 Issue 的兄弟 Case</div>
              <div className="space-y-1">
                {siblingIds.map((id) => {
                  const sib = mockCases.find((x) => x.id === id);
                  if (!sib) return null;
                  return (
                    <button key={id} onClick={() => onOpenCase?.(id)}
                      className="w-full text-left text-xs text-slate-600 hover:text-[#0052D9] flex items-center gap-1.5 py-0.5">
                      <span className="font-mono text-[10px] text-slate-400">{sib.code}</span>
                      <span className="truncate">{sib.name}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}
          <div className="flex items-center gap-3 pt-1">
            <button onClick={() => setPicking("existing")} className="text-[11px] text-[#0052D9] hover:underline inline-flex items-center gap-0.5"><Plus size={11} /> 关联更多 Issue</button>
            <button onClick={() => setPicking("new")} className="text-[11px] text-[#0052D9] hover:underline inline-flex items-center gap-0.5"><Plus size={11} /> 新建 Issue</button>
          </div>
        </div>
      ) : (
        <div className="space-y-2">
          <p className="text-xs text-slate-400 leading-relaxed">本 Case 尚未关联共性问题（当多个 Case 证明同类问题重复发生时，再归纳为 Issue 统一跟踪）。</p>
          <div className="flex items-center gap-2">
            <button onClick={() => setPicking("existing")} className="h-8 px-3 text-sm rounded-md border border-slate-200 text-slate-700 hover:border-[#0052D9]/40 inline-flex items-center gap-1">
              <Search size={13} /> 关联到已有 Issue
            </button>
            <button onClick={() => setPicking("new")} className="h-8 px-3 text-sm rounded-md bg-[#0052D9] text-white hover:bg-[#0047b8] inline-flex items-center gap-1">
              <Plus size={13} /> 新建 Issue 并关联
            </button>
          </div>
        </div>
      )}

      {picking === "existing" && <PickExistingIssueModal caseId={caseId} onClose={() => setPicking(null)} onDone={() => setPicking(null)} />}
      {picking === "new" && (
        <NewIssueFromCaseModal
          caseId={caseId}
          caseIds={suggestion?.caseIds}
          defObjectType={prod?.objectType ?? "IC"}
          onClose={() => setPicking(null)}
          onDone={(id) => { setPicking(null); onOpenIssue?.(id); }}
        />
      )}
    </div>
  );
}

function PickExistingIssueModal({ caseId, onClose, onDone }: { caseId: string; onClose: () => void; onDone: () => void }) {
  const issues = useIssues();
  const [q, setQ] = useState("");
  const [pick, setPick] = useState("");
  const list = issues.filter((i) => !i.caseIds.includes(caseId) && [i.code, i.name].join(" ").toLowerCase().includes(q.toLowerCase()));
  return (
    <Modal title="关联到已有 Issue" onClose={onClose}>
      <div className="relative mb-2">
        <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="搜索 Issue 编号 / 名称" autoFocus
          className="h-8 w-full pl-8 pr-3 text-sm rounded-md border border-slate-200 outline-none focus:border-[#0052D9]" />
      </div>
      <div className="max-h-[300px] overflow-y-auto space-y-1">
        {list.map((i) => (
          <label key={i.id} className={`flex items-center gap-2 p-2 rounded-md border cursor-pointer ${pick === i.id ? "border-[#0052D9] bg-[#0052D9]/5" : "border-slate-200 hover:bg-slate-50"}`}>
            <input type="radio" checked={pick === i.id} onChange={() => setPick(i.id)} className="accent-[#0052D9]" />
            <span className="font-mono text-[11px] text-slate-400">{i.code}</span>
            <span className="text-sm text-slate-800 flex-1 min-w-0 truncate">{i.name}</span>
            <Chip text={i.objectType} cls={objectTypeColors[i.objectType]} />
          </label>
        ))}
        {list.length === 0 && <div className="text-sm text-slate-400 py-6 text-center">无匹配 Issue</div>}
      </div>
      <ModalFooter okText="关联" okDisabled={!pick} onClose={onClose} onOk={() => { aggregateCase(pick, caseId); onDone(); }} />
    </Modal>
  );
}

function NewIssueFromCaseModal({ caseId, caseIds, defObjectType, suggestionReason, onClose, onDone }: { caseId: string; caseIds?: string[]; defObjectType: ObjectType; suggestionReason?: string; onClose: () => void; onDone: (id: string) => void }) {
  const c = mockCases.find((x) => x.id === caseId)!;
  const autoCaseIds = Array.from(new Set(caseIds?.length ? caseIds : [caseId]));
  const [name, setName] = useState(`${defObjectType} · ${c.failMode || c.name}`);
  const [objType, setObjType] = useState<ObjectType>(defObjectType);
  const [desc, setDesc] = useState(c.background || "");
  return (
    <Modal title={suggestionReason ? "根据重复发生建议建立 Issue" : "新建 Issue 并关联本 Case"} onClose={onClose}>
      {suggestionReason ? (
        <div className="mb-3 rounded-lg border border-[#7A3DFF]/20 bg-[#7A3DFF]/5 px-3 py-2.5">
          <div className="flex items-center gap-1.5 text-xs font-medium text-slate-700"><Sparkles size={13} className="text-[#7A3DFF]" />检测到同类问题再次发生</div>
          <p className="mt-1 text-[11px] leading-relaxed text-slate-500">这可能意味着问题已从单点 Case 升级为共性问题。建议将 {autoCaseIds.length} 个 Case 归纳到同一 Issue，统一跟踪影响范围与严重度。</p>
          <p className="mt-1 text-[11px] leading-relaxed text-slate-600"><span className="font-medium">判断依据：</span>{suggestionReason}</p>
        </div>
      ) : (
        <p className="text-xs text-slate-500 mb-2">将自动关联 {autoCaseIds.length} 个已有关联 Case（可后续继续归集新 Case）。</p>
      )}
      <label className="block text-xs text-slate-600">名称
        <input value={name} onChange={(e) => setName(e.target.value)} autoFocus className="mt-1 w-full h-9 px-2.5 text-sm rounded border border-slate-200 outline-none focus:border-[#0052D9]" />
      </label>
      <label className="block text-xs text-slate-600 mt-2">objectType
        <select value={objType} onChange={(e) => setObjType(e.target.value as ObjectType)} className="mt-1 w-full h-9 px-2 text-sm rounded border border-slate-200 outline-none focus:border-[#0052D9] bg-white">
          {OBJECT_TYPES.map((o) => <option key={o} value={o}>{o}</option>)}
        </select>
      </label>
      <label className="block text-xs text-slate-600 mt-2">共性描述
        <textarea value={desc} onChange={(e) => setDesc(e.target.value)} className="mt-1 w-full min-h-[70px] p-2.5 text-sm rounded border border-slate-200 outline-none focus:border-[#0052D9] leading-relaxed" />
      </label>
      <ModalFooter okText={suggestionReason ? "建立 Issue" : "创建并关联"} okDisabled={name.trim().length < 2}
        onClose={onClose}
        onOk={() => {
          const iss = createIssue({ name: name.trim(), source: "手动", objectType: objType, desc: desc.trim(), caseIds: autoCaseIds });
          onDone(iss.id);
        }} />
    </Modal>
  );
}

/* --------------- 归属 Issue（共性问题，多对多）· 融合控件顶部条 --------------- */
// 一个 Case 可同时归属多个 Issue：以徽章形式并列展示，可逐个解绑；就地关联已有 / 归纳新建。
function IssueOwnershipCompact({ caseId, onOpenCase, onOpenIssue }: Props) {
  const issues = useIssues();
  const links = useCaseLinks();
  const c = mockCases.find((x) => x.id === caseId)!;
  const prod = caseProductOf(c);
  const myIssues = issues.filter((i) => i.caseIds.includes(caseId));
  const [opening, setOpening] = useState(false);
  // 归纳为 Issue 时，默认把本 Case 及其已关联 Case 一并纳入（关联 → 升级为共性问题）
  const linkedIds = Array.from(
    new Set(links.filter((l) => l.from === caseId || l.to === caseId).flatMap((l) => [l.from, l.to]))
  );

  return (
    <div>
      <div className="flex items-center gap-1.5 mb-2">
        <GitMerge size={14} className="text-[#7A3DFF]" />
        <h3 className="text-sm text-slate-800">升级为 Issue</h3>
        <span className="text-[10.5px] text-slate-400">一个 Case 可同时归属多个 Issue</span>
        <div className="ml-auto flex items-center gap-2.5">
          <button onClick={() => setOpening(true)} className="text-[11px] text-[#7A3DFF] hover:underline inline-flex items-center gap-0.5"><Plus size={11} /> 关联 / 新建 Issue</button>
        </div>
      </div>

      {myIssues.length > 0 ? (
        <div className="flex flex-wrap gap-1.5">
          {myIssues.map((issue) => (
            <span key={issue.id} className="inline-flex items-center gap-1.5 rounded-md border border-[#7A3DFF]/25 bg-[#7A3DFF]/[0.06] pl-2 pr-1.5 py-1">
              <Chip text={issue.status} cls={issueStatusColors[issue.status]} />
              <button onClick={() => onOpenIssue?.(issue.id)} className="inline-flex items-center gap-1.5 min-w-0 hover:opacity-80">
                <span className="font-mono text-[10px] text-slate-300">{issue.code}</span>
                <span className="text-xs text-slate-800 truncate max-w-[220px]">{issue.name}</span>
              </button>
              <button onClick={() => detachCase(issue.id, caseId)} title="解除归属" className="text-slate-300 hover:text-red-500"><Unlink size={11} /></button>
            </span>
          ))}
        </div>
      ) : (
        <p className="text-xs text-slate-400 leading-relaxed">尚未归属共性问题。当多个 Case 反复出现同类问题时，可归纳为一个 Issue 统一跟踪影响范围与严重度（一个 Case 可同时属于多个 Issue）。</p>
      )}

      {opening && (
        <LinkOrCreateIssueModal
          caseId={caseId}
          linkedIds={linkedIds}
          defObjectType={prod?.objectType ?? "IC"}
          onClose={() => setOpening(false)}
          onLinked={() => setOpening(false)}
          onCreated={(id) => { setOpening(false); onOpenIssue?.(id); }}
        />
      )}
    </div>
  );
}

// 新建 Issue 时：自动将相关 Case 的背景拼接 + 归纳，预填「共性背景」供用户确认。
function buildCommonBackground(caseIds: string[]): string {
  const cs = caseIds.map((id) => mockCases.find((x) => x.id === id)).filter(Boolean) as CaseItem[];
  if (!cs.length) return "";
  const prods = Array.from(new Set(cs.map((c) => c.product).filter(Boolean)));
  const modes = Array.from(new Set(cs.map((c) => c.failMode).filter((v) => v && v !== "—")));
  const stages = Array.from(new Set(cs.map((c) => c.failStage).filter((v) => v && v !== "—")));
  const summary = `【AI 归纳】${cs.length} 个相关 Case 反映同类问题` +
    `${prods.length ? `，涉及产品 ${prods.join("、")}` : ""}` +
    `${modes.length ? `，失效模式 ${modes.join("、")}` : ""}` +
    `${stages.length ? `，集中在 ${stages.join("、")} 阶段` : ""}。`;
  const bodies = cs.map((c) => `· ${c.code} ${c.name}：${(c.background || c.reason || "—").trim()}`);
  return `${summary}\n\n各 Case 背景：\n${bodies.join("\n")}`;
}

// 单入口：先在已有 Issue 中搜索关联；若无可关联（或需要新的），就地切换到新建表单。
function LinkOrCreateIssueModal({ caseId, linkedIds, defObjectType, onClose, onLinked, onCreated }: {
  caseId: string; linkedIds: string[]; defObjectType: ObjectType;
  onClose: () => void; onLinked: () => void; onCreated: (id: string) => void;
}) {
  const issues = useIssues();
  const c = mockCases.find((x) => x.id === caseId)!;
  const [mode, setMode] = useState<"list" | "create">("list");
  const [q, setQ] = useState("");
  const [pick, setPick] = useState("");
  const list = issues.filter((i) => !i.caseIds.includes(caseId) && [i.code, i.name].join(" ").toLowerCase().includes(q.toLowerCase()));
  const autoCaseIds = Array.from(new Set(linkedIds.length ? linkedIds : [caseId]));
  const commonBackground = buildCommonBackground(autoCaseIds);

  const [name, setName] = useState("");
  const objType = defObjectType; // 自动带出（不再让用户选 objectType）
  const [domain, setDomain] = useState<ProblemDomain>((c.problemDomain as ProblemDomain) || "Design");
  const [problemType, setProblemType] = useState<ProblemType | "">((c.problemType as ProblemType) || "");
  const [expectedDate, setExpectedDate] = useState("");
  const [desc, setDesc] = useState(commonBackground);
  const startCreate = () => {
    setName(q.trim() || `${defObjectType} · ${c.failMode || c.name}`);
    setMode("create");
  };

  if (mode === "create") {
    return (
      <Modal title="新建 Issue 并关联本 Case" width="w-[680px]" onClose={onClose}>
        <button onClick={() => setMode("list")} className="mb-2 text-[11px] text-slate-500 hover:text-[#0052D9] inline-flex items-center gap-0.5"><ChevronRight size={12} className="rotate-180" /> 返回选择已有 Issue</button>
        <p className="text-xs text-slate-500 mb-2">将自动关联 {autoCaseIds.length} 个已有关联 Case（可后续继续归集新 Case）。</p>
        <label className="block text-xs text-slate-600">名称
          <input value={name} onChange={(e) => setName(e.target.value)} autoFocus className="mt-1 w-full h-9 px-2.5 text-sm rounded border border-slate-200 outline-none focus:border-[#0052D9]" />
        </label>
        <div className="grid grid-cols-2 gap-2 mt-2">
          <label className="block text-xs text-slate-600">预期解决日期
            <input type="date" value={expectedDate} onChange={(e) => setExpectedDate(e.target.value)} className="mt-1 w-full h-9 px-2 text-sm rounded border border-slate-200 outline-none focus:border-[#0052D9] bg-white" />
          </label>
          <label className="block text-xs text-slate-600">Domain
            <select value={domain} onChange={(e) => setDomain(e.target.value as ProblemDomain)} className="mt-1 w-full h-9 px-2 text-sm rounded border border-slate-200 outline-none focus:border-[#0052D9] bg-white">
              {PROBLEM_DOMAINS.map((d) => <option key={d} value={d}>{d}</option>)}
            </select>
          </label>
        </div>
        <label className="block text-xs text-slate-600 mt-2">类型（选填）
          <select value={problemType} onChange={(e) => setProblemType(e.target.value as ProblemType)} className="mt-1 w-full h-9 px-2 text-sm rounded border border-slate-200 outline-none focus:border-[#0052D9] bg-white">
            <option value="">（不选）</option>
            {PROBLEM_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
          </select>
        </label>
        <label className="block text-xs text-slate-600 mt-2">共性背景
          <span className="ml-1 text-[10px] text-[#7A3DFF]">· AI 已根据相关 Case 背景自动归纳，确认或修改</span>
          <textarea value={desc} onChange={(e) => setDesc(e.target.value)} className="mt-1 w-full min-h-[260px] p-2.5 text-sm rounded border border-slate-200 outline-none focus:border-[#0052D9] leading-relaxed" />
        </label>
        <ModalFooter okText="创建并关联" okDisabled={name.trim().length < 2 || !expectedDate}
          onClose={onClose}
          onOk={() => {
            const iss = createIssue({ name: name.trim(), source: "手动", objectType: objType, desc: desc.trim(), caseIds: autoCaseIds, domain, problemType: problemType || undefined, expectedResolveDate: expectedDate, requester: currentUser.name });
            onCreated(iss.id);
          }} />
      </Modal>
    );
  }

  return (
    <Modal title="升级为 Issue" onClose={onClose}>
      <div className="flex items-center gap-2 mb-2">
        <div className="relative flex-1">
          <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="搜索已有 Issue 编号 / 名称" autoFocus
            className="h-8 w-full pl-8 pr-3 text-sm rounded-md border border-slate-200 outline-none focus:border-[#0052D9]" />
        </div>
        <button onClick={startCreate} className="shrink-0 h-8 px-3 text-sm rounded-md border border-slate-200 text-slate-700 hover:border-[#0052D9]/40 hover:text-[#0052D9] inline-flex items-center gap-1"><Plus size={13} /> 新建</button>
      </div>
      <div className="max-h-[300px] overflow-y-auto space-y-1">
        {list.map((i) => (
          <label key={i.id} className={`flex items-center gap-2 p-2 rounded-md border cursor-pointer ${pick === i.id ? "border-[#0052D9] bg-[#0052D9]/5" : "border-slate-200 hover:bg-slate-50"}`}>
            <input type="radio" checked={pick === i.id} onChange={() => setPick(i.id)} className="accent-[#0052D9]" />
            <span className="font-mono text-[11px] text-slate-400">{i.code}</span>
            <span className="text-sm text-slate-800 flex-1 min-w-0 truncate">{i.name}</span>
          </label>
        ))}
        {list.length === 0 && (
          <button onClick={startCreate} className="w-full py-6 flex flex-col items-center gap-1.5 text-slate-400 hover:text-[#0052D9] transition-colors">
            <span className="text-sm">无匹配 Issue</span>
            <span className="inline-flex items-center gap-1 text-xs text-[#0052D9]"><Plus size={12} /> 新建 Issue{q.trim() ? `「${q.trim()}」` : ""} 并关联本 Case</span>
          </button>
        )}
      </div>
      <ModalFooter okText="关联" okDisabled={!pick} onClose={onClose} onOk={() => { aggregateCase(pick, caseId); onLinked(); }} />
    </Modal>
  );
}

/* ------------------------------ 关联 Case ------------------------------ */
function CaseLinks({ caseId, onOpenCase, onOpenIssue, inline }: Props) {
  const links = useCaseLinks();
  const [adding, setAdding] = useState(false);
  const current = mockCases.find((x) => x.id === caseId)!;
  // Fanout 类型 Case 不在「关联 Case」展示（详情页已有常驻「Fanout 进度」）
  const isFanoutCase = (id: string) => {
    const o = mockCases.find((x) => x.id === id);
    return !!o && (o.source === "fanout验证" || !!o.fanoutSourceCaseId);
  };
  const my = links.filter((l) => (l.from === caseId || l.to === caseId) && !isFanoutCase(l.from === caseId ? l.to : l.from));
  const suggestions = useMemo(() => suggestRelatedCases(current, mockCases), [caseId, links]);
  const newSuggestions = suggestions.filter((s) => !isFanoutCase(s.caseId) && !my.some((l) => l.from === s.caseId || l.to === s.caseId));

  return (
    <div className={inline ? "" : "border-l border-slate-100 pl-5"}>
      <div className="flex items-center gap-1.5 mb-2.5">
        <Link2 size={14} className="text-slate-500" />
        <h3 className="text-sm text-slate-800">关联 Case</h3>
        <span className="text-[10.5px] text-slate-400">两个 Case 关联或重复；仅标记，不合并数据</span>
        <div className="ml-auto flex items-center gap-2">
          {newSuggestions.length > 0 && <span className="text-[10px] text-[#7A3DFF]">{newSuggestions.length} 条 AI 建议</span>}
          <button onClick={() => setAdding(true)} className="text-[11px] text-[#0052D9] hover:underline inline-flex items-center gap-1">
            <Plus size={12} /> 添加关联 Case
          </button>
        </div>
      </div>

      {/* 已有链接 */}
      <div className="flex flex-wrap gap-1.5">
        {my.map((l, k) => {
          const otherId = l.from === caseId ? l.to : l.from;
          const other = mockCases.find((x) => x.id === otherId);
          if (!other) return null;
          const phrase = l.from === caseId ? caseLinkPhrase[l.type].out : caseLinkPhrase[l.type].in;
          return (
            <span key={k} className="inline-flex items-center gap-1.5 rounded-md border border-slate-200 bg-slate-50 pl-2 pr-1.5 py-1">
              <Chip text={phrase} cls={caseLinkColors[l.type]} title={caseLinkHelp[l.type]} />
              {l.byAi && <Sparkles size={11} className="text-[#7A3DFF]" />}
              <button onClick={() => onOpenCase?.(otherId)} className="inline-flex items-center gap-1.5 min-w-0 hover:opacity-80">
                <span className="font-mono text-[10px] text-slate-300">{other.code}</span>
                <span className="text-xs text-slate-800 truncate max-w-[220px]">{other.name}</span>
              </button>
              <CaseCompletion caseItem={other} />
              <button onClick={() => unlinkCases(l.from, l.to)} title="解除关联" className="text-slate-300 hover:text-red-500"><X size={12} /></button>
            </span>
          );
        })}
        {my.length === 0 && <div className="text-xs text-slate-400">暂无关联。可手动关联或标注重复，也可用 AI 建议自动发现相似 Case。</div>}
      </div>

      {adding && (
        <AddLinkModal
          caseId={caseId}
          suggestions={newSuggestions}
          onOpenCase={onOpenCase}
          onClose={() => setAdding(false)}
          onDone={() => setAdding(false)}
        />
      )}
    </div>
  );
}

function AddLinkModal({ caseId, suggestions, onOpenCase, onClose, onDone }: {
  caseId: string;
  suggestions: ReturnType<typeof suggestRelatedCases>;
  onOpenCase?: (id: string) => void;
  onClose: () => void;
  onDone: () => void;
}) {
  const links = useCaseLinks();
  const [mode, setMode] = useState<"ai" | "manual">(suggestions.length > 0 ? "ai" : "manual");
  const [q, setQ] = useState("");
  const [picks, setPicks] = useState<string[]>([]);
  const [product, setProduct] = useState("全部");
  const linked = new Set(links.filter((l) => l.from === caseId || l.to === caseId).flatMap((l) => [l.from, l.to]));
  const productOpts = ["全部", ...Array.from(new Set(mockCases.filter((c) => c.id !== caseId).map((c) => c.product).filter(Boolean)))];
  const list = mockCases.filter((c) =>
    c.id !== caseId && !linked.has(c.id) &&
    c.source !== "fanout验证" && !c.fanoutSourceCaseId &&
    (product === "全部" || c.product === product) &&
    [c.code, c.name].join(" ").toLowerCase().includes(q.toLowerCase())
  );
  const toggle = (id: string) => setPicks((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  return (
    <Modal title="关联 Case" onClose={onClose}>
      <div className="mb-3 flex items-center border-b border-slate-100">
        <button
          type="button"
          onClick={() => setMode("ai")}
          className={`h-9 border-b-2 px-3 text-xs inline-flex items-center gap-1.5 ${mode === "ai" ? "border-[#7A3DFF] text-[#7A3DFF]" : "border-transparent text-slate-500 hover:text-slate-700"}`}
        >
          <Sparkles size={12} /> AI 建议{suggestions.length ? `（${suggestions.length}）` : ""}
        </button>
        <button
          type="button"
          onClick={() => setMode("manual")}
          className={`h-9 border-b-2 px-3 text-xs inline-flex items-center gap-1.5 ${mode === "manual" ? "border-[#0052D9] text-[#0052D9]" : "border-transparent text-slate-500 hover:text-slate-700"}`}
        >
          <Search size={12} /> 手动关联
        </button>
      </div>

      {mode === "ai" ? (
        <>
          <div className="mb-2 flex items-center gap-1.5 text-[11px] text-slate-500">
            <Sparkles size={12} className="text-[#7A3DFF]" />
            根据产品、失效模式与问题描述推荐相似 Case
          </div>
          <div className="max-h-[420px] space-y-2.5 overflow-y-auto pr-0.5">
            {suggestions.length === 0 && <div className="py-8 text-center text-xs text-slate-400">暂无更多相似 Case 建议，可切换至“手动关联”查找 Case。</div>}
            {suggestions.map((suggestion) => {
              const suggestedCase = mockCases.find((caseItem) => caseItem.id === suggestion.caseId)!;
              return (
                <RelatedCaseCard
                  key={suggestion.caseId}
                  caseItem={suggestedCase}
                  score={suggestion.score}
                  reason={suggestion.reason}
                  onOpen={onOpenCase}
                  actions={
                    <>
                      <button onClick={() => linkCases(caseId, suggestion.caseId, "关联", { byAi: true })}
                        title="建立关联；两个 Case 仍独立推进"
                        className="h-6 px-2 rounded-md border border-[#0052D9]/25 text-[#0052D9] text-[10px] hover:bg-[#0052D9]/5">建立关联</button>
                      <button onClick={() => linkCases(caseId, suggestion.caseId, "重复", { byAi: true })}
                        title="标注为与该 Case 重复（同一问题）；仅标记，不合并数据"
                        className="h-6 px-2 rounded-md border border-red-200 text-red-500 text-[10px] hover:bg-red-50">标注重复</button>
                    </>
                  }
                />
              );
            })}
          </div>
          <div className="mt-3 flex justify-end border-t border-slate-100 pt-3">
            <button onClick={onClose} className="h-8 px-3 text-sm rounded-md border border-slate-200 text-slate-600 hover:bg-slate-50">关闭</button>
          </div>
        </>
      ) : (
        <>
          <div className="flex items-center gap-2 mb-2">
            <select value={product} onChange={(e) => setProduct(e.target.value)} className="h-8 px-2 text-sm rounded-md border border-slate-200 outline-none focus:border-[#0052D9] bg-white max-w-[140px]" title="按产品过滤">
              {productOpts.map((p) => <option key={p} value={p}>{p === "全部" ? "全部产品" : p}</option>)}
            </select>
            <div className="relative flex-1">
              <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="搜索 Case" className="h-8 w-full pl-8 pr-3 text-sm rounded-md border border-slate-200 outline-none focus:border-[#0052D9]" />
            </div>
          </div>
          <div className="flex items-center justify-between mb-1.5 px-0.5">
            <span className="text-[11px] text-slate-400">勾选可批量关联 · 或对单个 Case「标记重复」 · 已选 {picks.length} 个</span>
            <div className="flex items-center gap-2">
              <button type="button" onClick={() => setPicks(Array.from(new Set([...picks, ...list.map((c) => c.id)])))} className="text-[11px] text-[#0052D9] hover:underline">全选当前 {list.length}</button>
              {picks.length > 0 && <button type="button" onClick={() => setPicks([])} className="text-[11px] text-slate-400 hover:text-slate-600">清空</button>}
            </div>
          </div>
          <div className="max-h-[280px] overflow-y-auto space-y-1">
            {list.map((c) => (
              <div key={c.id} className={`group flex items-center gap-2 p-2 rounded-md border ${picks.includes(c.id) ? "border-[#0052D9] bg-[#0052D9]/5" : "border-slate-200 hover:bg-slate-50"}`}>
                <label className="flex items-center gap-2 flex-1 min-w-0 cursor-pointer">
                  <input type="checkbox" checked={picks.includes(c.id)} onChange={() => toggle(c.id)} className="accent-[#0052D9]" />
                  <span className="text-sm text-slate-800 flex-1 min-w-0 truncate">{c.name}</span>
                </label>
                {c.product && <span className="shrink-0 text-[10px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-500">{c.product}</span>}
                <span className="shrink-0 font-mono text-[10px] text-slate-300">{c.code}</span>
                <button
                  type="button"
                  onClick={() => { linkCases(caseId, c.id, "重复"); onDone(); }}
                  title="标记为与当前 Case 重复（同一问题）；仅标记，不合并数据"
                  className="shrink-0 h-6 px-2 rounded-md border border-red-200 text-red-500 text-[11px] hover:bg-red-50 opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  标记重复
                </button>
              </div>
            ))}
            {list.length === 0 && <div className="text-sm text-slate-400 py-6 text-center">无匹配 Case</div>}
          </div>
          <ModalFooter okText={picks.length > 1 ? `关联 ${picks.length} 个` : "关联"} okDisabled={picks.length === 0} onClose={onClose} onOk={() => { picks.forEach((id) => linkCases(caseId, id, "关联")); onDone(); }} />
        </>
      )}
    </Modal>
  );
}

/* ------------------------------ 通用弹窗 ------------------------------ */
function Modal({ title, onClose, children, width = "w-[540px]" }: { title: string; onClose: () => void; children: React.ReactNode; width?: string }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40" onClick={onClose}>
      <div className={`${width} bg-white rounded-lg shadow-xl border border-slate-200 p-5 max-h-[90vh] overflow-y-auto`} onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center gap-2 mb-3">
          <h3 className="text-slate-900">{title}</h3>
          <button onClick={onClose} className="ml-auto text-slate-400 hover:text-slate-600"><X size={16} /></button>
        </div>
        {children}
      </div>
    </div>
  );
}
function ModalFooter({ onClose, onOk, okText, okDisabled }: { onClose: () => void; onOk: () => void; okText: string; okDisabled?: boolean }) {
  return (
    <div className="flex items-center justify-end gap-2 pt-3 mt-3 border-t border-slate-100">
      <button onClick={onClose} className="h-8 px-3 text-sm rounded-md border border-slate-200 text-slate-600 hover:bg-slate-50">取消</button>
      <button disabled={okDisabled} onClick={onOk} className="h-8 px-3.5 text-sm rounded-md bg-[#0052D9] text-white hover:bg-[#0047b8] disabled:opacity-40">{okText}</button>
    </div>
  );
}
