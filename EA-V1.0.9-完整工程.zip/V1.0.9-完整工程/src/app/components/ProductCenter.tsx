import { useMemo, useState } from "react";
import {
  Boxes, ArrowLeft, Package, ChevronRight, ChevronDown, AlertTriangle, Link2, ClipboardList, ListTree,
} from "lucide-react";
import {
  Product, Project, StageId, CheckState, STAGE_DEFS, stageDefById, stageOrder,
  mockProducts, productById, checkStateColors, stageStatusColors,
  OBJECT_TYPES, ObjectType, Issue, CheckItemResult, checklistLeaves, checkRollup,
} from "./data";
import { useProjects, setCheckState } from "./domainStore";

const CHECK_STATES: CheckState[] = ["未开始", "进行中", "Pass", "Fail", "N/A"];

function Chip({ text, cls }: { text: string; cls: string }) {
  return <span className={`inline-flex items-center px-1.5 py-0.5 rounded text-[11px] border ${cls}`}>{text}</span>;
}

interface Props {
  onOpenCase: (id: string) => void;
  onOpenIssue?: (id: string) => void;
  embedded?: boolean;
}

export function ProductCenter({ onOpenCase, embedded }: Props) {
  const [sel, setSel] = useState<string | undefined>();
  const projects = useProjects();
  const current = sel ? productById(sel) : undefined;
  if (current) return <ProductDetail product={current} onBack={() => setSel(undefined)} onOpenCase={onOpenCase} embedded={embedded} />;
  return <ProductList onOpen={setSel} projects={projects} embedded={embedded} />;
}

/* ================================ 列表 ================================ */
function ProductList({ onOpen, projects, embedded }: { onOpen: (id: string) => void; projects: Project[]; embedded?: boolean }) {
  const [objType, setObjType] = useState<ObjectType | "全部">("全部");
  const list = objType === "全部" ? mockProducts : mockProducts.filter((p) => p.objectType === objType);

  const failCount = (productId: string) =>
    projects.filter((p) => p.productId === productId)
      .flatMap((p) => p.checklists).flatMap((c) => checklistLeaves(c)).filter((i) => i.state === "Fail").length;

  return (
    <div className={embedded ? "" : "p-6 max-w-[1200px] mx-auto"}>
      {!embedded && (
        <>
          <div className="flex items-center gap-2 mb-1">
            <Boxes size={20} className="text-[#0a9d63]" />
            <h1 className="text-lg text-slate-900">产品 · 项目监控中心</h1>
          </div>
          <p className="text-xs text-slate-500 mb-4">产品级 8 阶段生命周期主干（DKO→AR→FVR→DBR→FSO→ES→CS→MP）；项目挂靠阶段，逐项推进 Checklist，检查项 Fail 自动生成 Case。</p>
        </>
      )}

      <div className="flex items-center gap-2 mb-3">
        <label className="inline-flex items-center gap-1 text-xs text-slate-500">
          <span>objectType</span>
          <select value={objType} onChange={(e) => setObjType(e.target.value as any)}
            className="h-8 px-2 text-sm rounded-md border border-slate-200 outline-none focus:border-[#0052D9] bg-white">
            {["全部", ...OBJECT_TYPES].map((o) => <option key={o} value={o}>{o}</option>)}
          </select>
        </label>
      </div>

      <div className="space-y-2.5">
        {list.map((p) => {
          const fails = failCount(p.id);
          const prjs = projects.filter((x) => x.productId === p.id).length;
          return (
            <button key={p.id} onClick={() => onOpen(p.id)}
              className="w-full text-left rounded-lg border border-slate-200 bg-white hover:border-[#0a9d63]/40 hover:shadow-sm transition-all p-3.5">
              <div className="flex items-center gap-2 mb-2.5">
                <Package size={15} className="text-slate-400" />
                <span className="text-sm text-slate-900">{p.code}</span>
                <span className="text-xs text-slate-400">{p.name}</span>
                <span className="text-xs text-slate-400 ml-1">负责人 {p.owner}</span>
                <div className="ml-auto flex items-center gap-2">
                  {fails > 0 && <Chip text={`${fails} 项 Fail`} cls="bg-red-50 text-red-600 border-red-200" />}
                  <span className="text-xs text-slate-400">{prjs} 个项目</span>
                  <ChevronRight size={16} className="text-slate-300" />
                </div>
              </div>
              <StageBar product={p} />
            </button>
          );
        })}
      </div>
    </div>
  );
}

/* 8 阶段进度条 */
function StageBar({ product }: { product: Product }) {
  return (
    <div className="flex items-center gap-0.5">
      {STAGE_DEFS.map((s) => {
        const st = product.stageStatus[s.id];
        const bg = st === "已完成" ? "bg-emerald-400" : st === "进行中" ? "bg-blue-500" : "bg-slate-200";
        const txt = st === "未开始" ? "text-slate-400" : "text-white";
        return (
          <div key={s.id} title={`${s.full} · ${st}`}
            className={`flex-1 h-6 rounded-[3px] ${bg} ${txt} flex items-center justify-center text-[10px] tracking-wide ${s.id === product.currentStageId ? "ring-2 ring-[#0052D9]/40" : ""}`}>
            {s.name}
          </div>
        );
      })}
    </div>
  );
}

/* ================================ 详情 ================================ */
function ProductDetail({ product, onBack, onOpenCase, embedded }: { product: Product; onBack: () => void; onOpenCase: (id: string) => void; embedded?: boolean }) {
  const projects = useProjects().filter((p) => p.productId === product.id);
  const [open, setOpen] = useState<Record<string, boolean>>(() => Object.fromEntries(projects.map((p) => [p.id, true])));

  return (
    <div className={embedded ? "" : "p-6 max-w-[1100px] mx-auto"}>
      <button onClick={onBack} className="inline-flex items-center gap-1 text-sm text-slate-500 hover:text-slate-800 mb-3">
        <ArrowLeft size={15} /> 返回产品列表
      </button>

      {/* 头部 */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 mb-4">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-lg bg-[#0a9d63]/10 flex items-center justify-center shrink-0">
            <Package size={20} className="text-[#0a9d63]" />
          </div>
          <div>
            <div className="text-lg text-slate-900">{product.code}</div>
            <div className="text-xs text-slate-400">{product.name} · 负责人 {product.owner}</div>
          </div>
        </div>
        {/* 阶段时间线 */}
        <div className="mt-4 flex items-center gap-1">
          {STAGE_DEFS.map((s, i) => {
            const st = product.stageStatus[s.id];
            const dot = st === "已完成" ? "bg-emerald-400 border-emerald-400" : st === "进行中" ? "bg-blue-500 border-blue-500" : "bg-white border-slate-300";
            return (
              <div key={s.id} className="flex items-center gap-1 flex-1 last:flex-none">
                <div className="flex flex-col items-center">
                  <div className={`w-3 h-3 rounded-full border-2 ${dot}`} />
                  <div className={`text-[10px] mt-1 ${s.id === product.currentStageId ? "text-[#0052D9] font-medium" : "text-slate-400"}`}>{s.name}</div>
                </div>
                {i < STAGE_DEFS.length - 1 && <div className={`flex-1 h-0.5 ${stageOrder(product.currentStageId) > s.order ? "bg-emerald-300" : "bg-slate-200"}`} />}
              </div>
            );
          })}
        </div>
      </div>

      {/* 项目 · Checklist · 检查项 */}
      <div className="space-y-3">
        {projects.map((prj) => {
          const isOpen = open[prj.id];
          const items = prj.checklists.flatMap((c) => checklistLeaves(c));
          const passN = items.filter((i) => i.state === "Pass").length;
          const failN = items.filter((i) => i.state === "Fail").length;
          return (
            <div key={prj.id} className="rounded-xl border border-slate-200 bg-white overflow-hidden">
              <button onClick={() => setOpen((o) => ({ ...o, [prj.id]: !o[prj.id] }))}
                className="w-full flex items-center gap-2 px-4 py-3 hover:bg-slate-50">
                {isOpen ? <ChevronDown size={15} className="text-slate-400" /> : <ChevronRight size={15} className="text-slate-400" />}
                <ClipboardList size={15} className="text-[#0052D9]" />
                <span className="text-sm text-slate-900">{prj.name}</span>
                <Chip text={`${stageDefById(prj.stageSpan.from).name}~${stageDefById(prj.stageSpan.to).name}`} cls="bg-slate-50 text-slate-500 border-slate-200" />
                <div className="ml-auto flex items-center gap-1.5 text-xs">
                  <span className="text-emerald-600">{passN} Pass</span>
                  {failN > 0 && <span className="text-red-600">· {failN} Fail</span>}
                  <span className="text-slate-400">· {items.length} 项</span>
                </div>
              </button>
              {isOpen && (
                <div className="border-t border-slate-100 divide-y divide-slate-50">
                  {prj.checklists.map((cl) => (
                    <div key={cl.id} className="px-4 py-3">
                      <div className="flex items-center gap-1.5 mb-2">
                        <span className="text-xs text-slate-500">{cl.name}</span>
                        <Chip text={stageDefById(cl.stageId).name} cls="bg-slate-50 text-slate-400 border-slate-200" />
                      </div>
                      <div className="space-y-1">
                        {cl.items.map((it) => (
                          <CheckNode key={it.defId} node={it} depth={0} projectId={prj.id} checklistId={cl.id} onOpenCase={onOpenCase} />
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
        {projects.length === 0 && <div className="text-center text-sm text-slate-400 py-16">该产品暂无项目</div>}
      </div>
    </div>
  );
}

/* WBS×Checklist 递归节点：叶子＝可勾状态的具体 check item；父节点仅按后代叶子汇总，不可直接改态。叶子 Fail → 自动生成 Case */
function CheckNode({ node, depth, projectId, checklistId, onOpenCase }: {
  node: CheckItemResult; depth: number; projectId: string; checklistId: string; onOpenCase: (id: string) => void;
}) {
  const pad = { paddingLeft: 8 + depth * 16 };
  if (node.children?.length) {
    const roll = checkRollup(node);
    return (
      <div>
        <div className="flex items-center gap-2 py-1.5 px-2" style={pad}>
          <ListTree size={12} className="text-slate-300 shrink-0" />
          <span className="text-[13px] text-slate-500 flex-1 min-w-0">{node.title}</span>
          <Chip text={`汇总·${roll}`} cls={checkStateColors[roll]} />
        </div>
        <div className="ml-3 border-l border-slate-100">
          {node.children.map((ch) => (
            <CheckNode key={ch.defId} node={ch} depth={depth + 1} projectId={projectId} checklistId={checklistId} onOpenCase={onOpenCase} />
          ))}
        </div>
      </div>
    );
  }
  return (
    <div className={`flex items-center gap-2 py-1.5 px-2 rounded-md ${node.state === "Fail" ? "bg-red-50/60" : "hover:bg-slate-50"}`} style={pad}>
      {node.state === "Fail" && <AlertTriangle size={13} className="text-red-500 shrink-0" />}
      <span className="text-sm text-slate-700 flex-1 min-w-0">{node.title}</span>
      {node.caseId && (
        <button onClick={() => onOpenCase(node.caseId!)} className="text-[11px] text-[#0052D9] hover:underline inline-flex items-center gap-0.5">
          <Link2 size={11} /> 查看 Case
        </button>
      )}
      {node.by && <span className="text-[10px] text-slate-400">{node.by} · {node.at}</span>}
      <select value={node.state} onChange={(e) => setCheckState(projectId, checklistId, node.defId, e.target.value as CheckState)}
        className={`h-7 px-1.5 text-xs rounded border outline-none ${checkStateColors[node.state]}`}>
        {CHECK_STATES.map((s) => <option key={s} value={s}>{s}</option>)}
      </select>
    </div>
  );
}
