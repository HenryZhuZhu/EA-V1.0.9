import { useRef, useState, type ReactNode } from "react";
import { ChevronRight, FileSpreadsheet, FileText } from "lucide-react";
import { currentUser } from "./data";
import { AttachmentInput, type Att } from "./AttachmentInput";
import { completeStandaloneTask, saveStandaloneTaskWorkspace, terminateStandaloneTask, type StandaloneTask } from "./standaloneTasks";
import { StandaloneTaskWorkspace } from "./StandaloneTaskWorkspace";
import { TerminateTaskModal } from "./TerminateTaskModal";
import { TaskDetailActions } from "./TaskDetailActions";

export function StandaloneTaskResult({ task, onPreview, onCancel, children }: { task: StandaloneTask; onPreview: (attachment: Att) => void; onCancel: () => void; children?: ReactNode }) {
  const [attachments, setAttachments] = useState<Att[]>(task.resultAttachments ?? []);
  const [error, setError] = useState("");
  const [uploading, setUploading] = useState(false);
  const [workspaceOpen, setWorkspaceOpen] = useState(false);
  const [terminating, setTerminating] = useState(false);
  const [savedMessage, setSavedMessage] = useState("");
  const submitting = useRef(false);
  const isOwner = task.owner === currentUser.name;
  const active = !task.convertedCaseId && ["待接受", "进行中"].includes(task.status);
  const editable = isOwner && task.status === "进行中" && active;
  const shownAttachments = editable ? attachments : task.resultAttachments ?? [];
  const frozenReason = task.convertedCaseId ? "该任务已升级为 Case，请在对应 Case 任务中操作。" : undefined;
  const busyReason = uploading ? "请等待附件读取完成。" : undefined;
  const terminateReason = frozenReason || busyReason || (!isOwner ? "仅任务负责人可以中止。" : !active ? "仅待接受或进行中的任务可以中止。" : undefined);
  const completeReason = frozenReason || busyReason || (!isOwner ? "仅任务负责人可以完成。" : task.status !== "进行中" ? "仅进行中的任务可以完成。" : undefined);

  return <>
    <section aria-label="任务结果" className="rounded-lg border border-slate-200 bg-white p-5">
    <button type="button" aria-label={editable ? "进入 Workspace 编辑" : "查看 Workspace 文档"} disabled={uploading} onClick={() => setWorkspaceOpen(true)} className="group mb-4 block w-full rounded-xl border border-slate-200 p-4 text-left transition-colors hover:border-[#0052D9]/40 hover:shadow-sm disabled:cursor-wait disabled:opacity-50">
      <span className="flex items-center gap-2.5"><span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-[#0052D9]/8 text-[#0052D9]"><FileSpreadsheet size={16} /></span><span className="min-w-0"><span className="block text-sm font-medium text-slate-800">分析过程与结论</span><span className="block text-[11px] text-slate-400">Workspace 文档 · 记录任务处理过程与结论</span></span><span className="ml-auto inline-flex shrink-0 items-center gap-0.5 text-[11px] text-slate-400 group-hover:text-[#0052D9]">{editable ? "进入 Workspace 编辑" : "查看 Workspace 文档"}<ChevronRight size={13} /></span></span>
      <span className="mt-2.5 block rounded-lg border border-slate-100 bg-slate-50/70 px-3 py-2.5"><span className="line-clamp-3 whitespace-pre-wrap break-words text-xs leading-relaxed text-slate-600">{task.conclusion || task.analysisProcess || "暂无 Workspace 内容"}</span></span>
    </button>
    {savedMessage && <p role="status" className="mb-3 text-xs text-emerald-700">{savedMessage}</p>}
    {editable ? <form id={`standalone-result-${task.id}`} className="space-y-4" onSubmit={(event) => {
      event.preventDefault();
      if (submitting.current) return;
      if (uploading) { setError("请等待结果附件读取完成后再提交。"); return; }
      if (!task.conclusion?.trim()) { setError("请先进入 Workspace 填写并保存任务结论，再完成任务。"); return; }
      submitting.current = true;
      try { completeStandaloneTask(task.id, { conclusion: task.conclusion, resultAttachments: attachments }); setError(""); setSavedMessage(""); }
      catch (reason) { setError(reason instanceof Error ? reason.message : "结果保存失败，请重试。"); }
      finally { submitting.current = false; }
    }}>
      <fieldset aria-label="结果附件"><legend className="mb-2 text-xs text-slate-600">结果附件 <span className="text-[10px] text-slate-400">选填</span></legend><div className="rounded-md border border-dashed border-slate-300 p-4"><AttachmentInput value={attachments} onChange={(next) => { setAttachments(next); setSavedMessage(""); }} onUploadingChange={setUploading} /><p className="mt-2 text-[11px] text-slate-400">支持选择本地文件，可多选</p></div></fieldset>
      {error && <p role="alert" className="text-xs text-red-600">{error}</p>}
    </form> : <div className="space-y-4">
      <div><h3 className="text-xs text-slate-600">结果附件</h3>{!shownAttachments.length && <p className="mt-2 text-xs text-slate-400">暂无结果附件</p>}</div>
    </div>}
    {shownAttachments.length > 0 && <div className="mt-3 flex flex-wrap gap-2">{shownAttachments.map((attachment, index) => <button type="button" key={`${attachment.name}-${index}`} aria-label={`预览结果附件 ${attachment.name}`} onClick={() => onPreview(attachment)} className="inline-flex min-w-0 max-w-full items-center gap-1.5 rounded-md border border-slate-200 bg-white px-2.5 py-2 text-[11px] text-[#0052D9] hover:border-[#0052D9]/40"><FileText size={12} className="shrink-0" /><span className="truncate">{attachment.name}</span></button>)}</div>}
    </section>
    {workspaceOpen && <StandaloneTaskWorkspace title={task.title} description={task.description} canEdit={editable} initialConclusion={task.conclusion ?? ""} initialProcess={task.analysisProcess ?? ""} onClose={() => setWorkspaceOpen(false)} onSave={(document) => {
      if (uploading) throw new Error("请等待结果附件读取完成后再保存。");
      const saved = saveStandaloneTaskWorkspace(task.id, { ...document, resultAttachments: attachments });
      setAttachments(saved.resultAttachments ?? []);
      setError("");
      setSavedMessage("Workspace 文档已保存，任务仍为进行中。");
    }} />}
    {terminating && <TerminateTaskModal title={task.title} onClose={() => setTerminating(false)} onConfirm={(reason) => {
      if (uploading) throw new Error("请等待结果附件读取完成后再中止。");
      terminateStandaloneTask(task.id, reason, attachments);
      setError("");
      setSavedMessage("");
    }} />}
    {children}
    <TaskDetailActions onCancel={onCancel} onTerminate={() => setTerminating(true)} completeForm={editable ? `standalone-result-${task.id}` : undefined} terminateReason={terminateReason} completeReason={completeReason} hint={frozenReason || busyReason || "取消仅返回；完成前请在 Workspace 保存结论"} />
  </>;
}