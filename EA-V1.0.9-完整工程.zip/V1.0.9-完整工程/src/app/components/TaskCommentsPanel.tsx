import { X, MessageCircle, ThumbsUp, CornerDownRight, Send } from "lucide-react";
import { useState } from "react";
import { TaskComment, currentUser } from "./data";
import { VoiceInputButton } from "./VoiceInputButton";

interface Props {
  taskTitle: string;
  comments: TaskComment[];
  likes: number;
  likedByMe: boolean;
  onAddComment: (content: string) => void;
  onReply: (commentId: string, content: string) => void;
  onToggleLike: () => void;
  onClose: () => void;
}

export function TaskCommentsPanel({
  taskTitle,
  comments,
  likes,
  likedByMe,
  onAddComment,
  onReply,
  onToggleLike,
  onClose,
}: Props) {
  const [draft, setDraft] = useState("");
  const [replyFor, setReplyFor] = useState<string | null>(null);
  const [replyDraft, setReplyDraft] = useState("");

  return (
    <div className="absolute right-0 top-0 z-20 w-[340px] h-full bg-white border-l border-slate-200 shadow-xl flex flex-col">
      <div className="px-4 py-2.5 border-b border-slate-100 flex items-center gap-2">
        <MessageCircle size={14} className="text-[#0052D9]" />
        <h4 className="text-slate-900 text-sm">评论</h4>
        <span className="text-[11px] text-slate-400 ml-auto">仅显示该卡片</span>
        <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
          <X size={14} />
        </button>
      </div>
      <div className="px-4 py-2 border-b border-slate-100 flex items-center gap-2">
        <div className="text-[11px] text-slate-500 line-clamp-1 flex-1">{taskTitle}</div>
        <button
          onClick={onToggleLike}
          className={`h-7 px-2 text-xs rounded-md border inline-flex items-center gap-1 transition-all ${
            likedByMe
              ? "bg-[#0052D9]/10 border-[#0052D9]/30 text-[#0052D9]"
              : "border-slate-200 text-slate-600 hover:border-[#0052D9]/40"
          }`}
        >
          <ThumbsUp size={11} /> {likes}
        </button>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-3 space-y-3">
        {comments.length === 0 && (
          <div className="text-xs text-slate-400 text-center py-8">
            暂无评论 · 抢沙发 👇
          </div>
        )}
        {comments.map((c) => (
          <div key={c.id} className="rounded-md bg-slate-50/60 border border-slate-100 p-2.5">
            <div className="flex items-center gap-1.5">
              <span className="w-5 h-5 rounded-full bg-gradient-to-br from-[#00A4FF] to-[#0052D9] text-white text-[10px] flex items-center justify-center">
                {c.user[0]}
              </span>
              <span className="text-xs text-slate-700">{c.user}</span>
              <span className="text-[10px] text-slate-400">· {c.time}</span>
            </div>
            <div className="text-xs text-slate-700 leading-relaxed mt-1.5">{c.content}</div>
            {(c.replies ?? []).map((r) => (
              <div key={r.id} className="mt-1.5 ml-4 pl-2 border-l-2 border-slate-200">
                <div className="flex items-center gap-1.5">
                  <CornerDownRight size={10} className="text-slate-400" />
                  <span className="text-[11px] text-slate-700">{r.user}</span>
                  <span className="text-[10px] text-slate-400">· {r.time}</span>
                </div>
                <div className="text-[11px] text-slate-600 leading-relaxed mt-0.5">{r.content}</div>
              </div>
            ))}
            <div className="mt-1.5">
              {replyFor === c.id ? (
                <div className="flex items-center gap-1">
                  <input
                    autoFocus
                    value={replyDraft}
                    onChange={(e) => setReplyDraft(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" && replyDraft.trim()) {
                        onReply(c.id, replyDraft.trim());
                        setReplyDraft("");
                        setReplyFor(null);
                      }
                      if (e.key === "Escape") {
                        setReplyDraft("");
                        setReplyFor(null);
                      }
                    }}
                    placeholder={`回复 ${c.user}...`}
                    className="flex-1 h-7 px-2 text-xs rounded border border-slate-200 outline-none focus:border-[#0052D9] bg-white"
                  />
                  <VoiceInputButton
                    size="sm"
                    onTranscript={(t) => setReplyDraft((p) => (p ? p + " " + t : t))}
                  />
                </div>
              ) : (
                <button
                  onClick={() => setReplyFor(c.id)}
                  className="text-[11px] text-[#0052D9] hover:underline"
                >
                  回复
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      <div className="border-t border-slate-100 p-3 space-y-2">
        <div className="flex items-start gap-1.5">
          <span className="w-6 h-6 rounded-full bg-gradient-to-br from-[#00A4FF] to-[#0052D9] text-white text-[10px] flex items-center justify-center shrink-0">
            {currentUser.name[0]}
          </span>
          <textarea
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            placeholder="输入评论，Enter 发送"
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey && draft.trim()) {
                e.preventDefault();
                onAddComment(draft.trim());
                setDraft("");
              }
            }}
            className="flex-1 min-h-[44px] p-1.5 text-xs rounded border border-slate-200 outline-none focus:border-[#0052D9] resize-none"
          />
        </div>
        <div className="flex items-center justify-end gap-2">
          <VoiceInputButton size="sm" onTranscript={(t) => setDraft((p) => (p ? p + " " + t : t))} />
          <button
            disabled={!draft.trim()}
            onClick={() => {
              onAddComment(draft.trim());
              setDraft("");
            }}
            className="h-7 px-3 text-xs rounded-md bg-[#0052D9] text-white hover:bg-[#003FA8] disabled:opacity-40 inline-flex items-center gap-1"
          >
            <Send size={11} /> 发送
          </button>
        </div>
      </div>
    </div>
  );
}
