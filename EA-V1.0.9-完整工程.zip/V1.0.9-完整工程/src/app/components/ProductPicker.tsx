import { useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { ChevronsUpDown, Search, ChevronRight, Check, X, Filter } from "lucide-react";
import { mockProducts, PRODUCT_FAMILIES, PRODUCT_PLATFORMS, Product, ProductFamily, ProductPlatform } from "./data";

/**
 * 产品选择器（借鉴 Condition Table 原型的选择器交互，视觉套用 EA 蓝）：
 * 触发按钮显示当前产品 → 展开下拉：顶部搜索 + 左侧类型轨 + 右侧产品列表。
 * 支持单选与多选（multiple）。
 */
type BaseProps = {
  placeholder?: string;
  products?: Product[];            // 局部候选集；不传时使用全局产品
  excludeIds?: string[];        // 需要从候选中排除的产品 id
  triggerClassName?: string;    // 触发按钮额外样式（如高度对齐）
};
type SingleProps = BaseProps & {
  multiple?: false;
  value: string;                // 选中的产品 id
  onChange: (productId: string) => void;
};
type MultiProps = BaseProps & {
  multiple: true;
  value: string[];              // 选中的产品 id 列表
  onChange: (productIds: string[]) => void;
};
type Props = SingleProps | MultiProps;

export function ProductPicker(props: Props) {
  const { placeholder = "请选择产品", products = mockProducts, excludeIds, triggerClassName } = props;
  const multiple = props.multiple === true;
  const selectedIds = multiple ? (props.value as string[]) : props.value ? [props.value as string] : [];
  const selectedProductById = (id: string) => products.find((product) => product.id === id);

  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [family, setFamily] = useState<"all" | ProductFamily>("all");
  const [platform, setPlatform] = useState<"all" | ProductPlatform>("all");
  const [filtersOpen, setFiltersOpen] = useState(false);
  const wrapRef = useRef<HTMLDivElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  // 下拉用 portal + fixed 定位，避免被含 overflow 的父容器（如弹窗）裁切
  const [pos, setPos] = useState<{ left: number; top: number; maxH: number } | null>(null);

  const computePos = () => {
    const r = wrapRef.current?.getBoundingClientRect();
    if (!r) return;
    const W = 440;
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    let left = Math.min(r.left, vw - W - 8);
    left = Math.max(8, left);
    const below = vh - r.bottom - 12;
    const above = r.top - 12;
    const preferred = 380;
    let top: number;
    let maxH: number;
    if (below >= Math.min(preferred, 240) || below >= above) {
      top = r.bottom + 6;
      maxH = Math.max(220, Math.min(preferred, below));
    } else {
      maxH = Math.max(220, Math.min(preferred, above));
      top = r.top - 6 - maxH;
    }
    setPos({ left, top, maxH });
  };

  // 关闭：点击外部 / Esc
  useEffect(() => {
    if (!open) return;
    const onDocClick = (e: MouseEvent) => {
      const t = e.target as Node;
      if (wrapRef.current?.contains(t) || panelRef.current?.contains(t)) return;
      setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("mousedown", onDocClick);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDocClick);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  // 打开时计算位置，并随滚动 / 缩放实时更新
  useEffect(() => {
    if (!open) { setPos(null); return; }
    computePos();
    const on = () => computePos();
    window.addEventListener("resize", on);
    window.addEventListener("scroll", on, true);
    return () => {
      window.removeEventListener("resize", on);
      window.removeEventListener("scroll", on, true);
    };
  }, [open]);

  useEffect(() => {
    if (open) window.setTimeout(() => inputRef.current?.focus(), 20);
  }, [open]);

  const list = useMemo(() => {
    const q = query.trim().toLowerCase();
    return products.filter(
      (p) =>
        !(excludeIds ?? []).includes(p.id) &&
        (family === "all" || p.family === family) &&
          (platform === "all" || p.platform === platform) &&
          (!q || p.code.toLowerCase().includes(q) || p.name.toLowerCase().includes(q) || p.platform?.toLowerCase().includes(q)),
    );
        }, [query, family, platform, excludeIds, products]);

  const pick = (id: string) => {
    if (multiple) {
      const cur = selectedIds;
      const next = cur.includes(id) ? cur.filter((x) => x !== id) : [...cur, id];
      (props.onChange as (ids: string[]) => void)(next);
      // 多选保持展开，便于连续勾选
    } else {
      (props.onChange as (id: string) => void)(id);
      setOpen(false);
      setQuery("");
    }
  };

  const removeChip = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    (props.onChange as (ids: string[]) => void)(selectedIds.filter((x) => x !== id));
  };

  return (
    <div ref={wrapRef} className="relative w-full">
      {/* 触发按钮 */}
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className={`w-full min-h-8 py-1 pl-2.5 pr-2 rounded-md border bg-white flex items-center gap-2 text-left transition-colors ${
          open ? "border-[#0052D9]" : "border-slate-200 hover:border-[#0052D9]/45"
        } ${triggerClassName ?? ""}`}
      >
        {selectedIds.length === 0 ? (
          <span className="text-xs text-slate-400">{placeholder}</span>
        ) : multiple ? (
          <span className="min-w-0 flex flex-wrap gap-1">
            {selectedIds.map((id) => {
              const p = selectedProductById(id);
              if (!p) return null;
              return (
                <span key={id} className="inline-flex items-center gap-1 pl-1.5 pr-1 py-0.5 rounded bg-[#0052D9]/8 border border-[#0052D9]/15 text-[#0052D9]">
                  <span className="font-mono text-[11px] font-semibold">{p.code}</span>
                  <span onClick={(e) => removeChip(id, e)} className="hover:text-[#003FA8]"><X size={11} /></span>
                </span>
              );
            })}
          </span>
        ) : (
          <span className="min-w-0 flex items-baseline gap-1.5">
            <span className="font-mono text-xs font-semibold text-slate-800 truncate">{selectedProductById(selectedIds[0])?.code}</span>
            <span className="text-[10px] text-slate-400 shrink-0">{[selectedProductById(selectedIds[0])?.platform, selectedProductById(selectedIds[0])?.family].filter(Boolean).join(" · ")}</span>
          </span>
        )}
        <ChevronsUpDown size={13} className="ml-auto shrink-0 text-slate-400" />
      </button>

      {/* 下拉面板（portal + fixed，避免被 overflow 容器裁切） */}
      {open && pos && createPortal(
        <div
          ref={panelRef}
          style={{ position: "fixed", left: pos.left, top: pos.top, width: 440, maxHeight: pos.maxH }}
          className="z-[300] p-2.5 rounded-xl border border-slate-200 bg-white shadow-[0_20px_60px_rgba(15,23,42,0.16)] overflow-y-auto"
        >
          {/* 搜索 */}
          <div className="h-9 px-2.5 rounded-lg border border-slate-200 focus-within:border-[#0052D9] flex items-center gap-2">
            <Search size={14} className="text-slate-400 shrink-0" />
            <input
              ref={inputRef}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="搜索产品代号或名称"
              className="flex-1 min-w-0 border-0 outline-none bg-transparent text-xs text-slate-700 placeholder:text-slate-400"
            />
            {multiple && selectedIds.length > 0 && (
              <span className="shrink-0 text-[10px] text-[#0052D9]">已选 {selectedIds.length}</span>
            )}
            <button
              type="button"
              title="筛选平台和世代"
              onClick={() => setFiltersOpen((current) => !current)}
              className={`relative grid h-6 w-6 shrink-0 place-items-center rounded border transition-colors ${filtersOpen || platform !== "all" || family !== "all" ? "border-[#0052D9]/50 bg-[#0052D9]/[0.06] text-[#0052D9]" : "border-slate-200/80 text-slate-400 hover:border-[#0052D9]/30 hover:bg-slate-50 hover:text-[#0052D9]"}`}
            >
              <Filter size={11.5} strokeWidth={1.8} />
              {(platform !== "all" || family !== "all") && (
                <span className="absolute -right-1 -top-1 grid h-3 min-w-3 place-items-center rounded-full bg-[#0052D9] px-0.5 text-[7px] font-semibold leading-none text-white">
                  {(platform !== "all" ? 1 : 0) + (family !== "all" ? 1 : 0)}
                </span>
              )}
            </button>
          </div>

          {filtersOpen && (
            <div className="mt-2 space-y-2 rounded-lg border border-slate-200 bg-slate-50/70 p-2">
              <div className="flex items-center gap-1.5">
                <span className="w-9 shrink-0 text-[10px] font-medium text-slate-400">平台</span>
                {(["all", ...PRODUCT_PLATFORMS] as const).map((item) => {
                  const active = platform === item;
                  return (
                    <button
                      key={item}
                      type="button"
                      onClick={() => setPlatform(item)}
                      className={`h-7 min-w-12 rounded-md border px-2 text-[10.5px] transition-colors ${active ? "border-[#0052D9] bg-white font-semibold text-[#0052D9]" : "border-slate-200 bg-white text-slate-500 hover:border-[#0052D9]/40 hover:text-[#0052D9]"}`}
                    >
                      {item === "all" ? "全部" : item}
                    </button>
                  );
                })}
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-9 shrink-0 text-[10px] font-medium text-slate-400">世代</span>
                {(["all", ...PRODUCT_FAMILIES] as const).map((item) => {
                  const active = family === item;
                  return (
                    <button
                      key={item}
                      type="button"
                      onClick={() => setFamily(item)}
                      className={`h-7 min-w-12 rounded-md border px-2 text-[10.5px] transition-colors ${active ? "border-[#0052D9] bg-white font-semibold text-[#0052D9]" : "border-slate-200 bg-white text-slate-500 hover:border-[#0052D9]/40 hover:text-[#0052D9]"}`}
                    >
                      {item === "all" ? "全部" : item}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* 批量操作（多选）：全选当前筛选结果 / 清空 */}
          {multiple && (
            <div className="mt-2 flex items-center gap-2">
              <button
                type="button"
                onClick={() => (props.onChange as (ids: string[]) => void)(Array.from(new Set([...selectedIds, ...list.map((p) => p.id)])))}
                className="h-6 px-2 rounded border border-slate-200 text-[10px] text-slate-600 hover:border-[#0052D9]/40 hover:text-[#0052D9]"
              >
                全选当前 {list.length}
              </button>
              <button
                type="button"
                onClick={() => (props.onChange as (ids: string[]) => void)([])}
                className="h-6 px-2 rounded border border-slate-200 text-[10px] text-slate-600 hover:border-[#0052D9]/40 hover:text-[#0052D9]"
              >
                清空
              </button>
              <span className="ml-auto text-[10px] text-[#0052D9]">已选 {selectedIds.length}</span>
            </div>
          )}

          {/* 产品列表 */}
          <div className="mt-2.5 min-h-[240px]">
            <div className="max-h-[240px] overflow-y-auto pr-0.5">
              {list.length === 0 ? (
                <p className="py-8 text-center text-[11px] text-slate-400">没有找到匹配产品</p>
              ) : (
                list.map((p) => {
                  const active = selectedIds.includes(p.id);
                  return (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => pick(p.id)}
                      className={`w-full min-h-[46px] px-2 py-1.5 rounded-lg grid grid-cols-[1fr_14px] gap-2 items-center text-left transition-colors ${
                        active ? "bg-[#0052D9]/8" : "hover:bg-slate-50"
                      }`}
                    >
                      <span className="min-w-0">
                        <span className="block font-mono text-xs font-semibold text-slate-800 truncate">{p.code}</span>
                        <span className="block text-[10px] text-slate-400 truncate">{p.name} · {p.platform ?? "—"} · {p.family ?? p.objectType}</span>
                      </span>
                      {multiple ? (
                        <span className={`w-3.5 h-3.5 rounded border grid place-items-center ${active ? "bg-[#0052D9] border-[#0052D9] text-white" : "border-slate-300"}`}>
                          {active && <Check size={10} />}
                        </span>
                      ) : active ? (
                        <Check size={13} className="text-[#0052D9]" />
                      ) : (
                        <ChevronRight size={13} className="text-slate-300" />
                      )}
                    </button>
                  );
                })
              )}
            </div>
          </div>
        </div>,
        document.body,
      )}
    </div>
  );
}
