import { ReactNode } from "react";
import { CaseItem, urgencyBar, levelColors, flattenTasks } from "./data";
import { ProgressRing } from "./ProgressRing";

// 相关 Case 卡片 —— 「关联 Case · AI 建议」的统一样式，供 AI 建议 / 结案前查重 / 重复 Fanout 提示复用。
function progressOfCase(caseItem: CaseItem): number {
  const actions = flattenTasks(caseItem.tasks).map(({ task }) => task).filter((task) => task.code);
  const base = actions.length ? actions : caseItem.tasks;
  return Math.round(base.reduce((sum, task) => sum + (task.progress || 0), 0) / Math.max(base.length, 1));
}

export function RelatedCaseCard({
  caseItem,
  title,
  score,
  reason,
  topRight,
  actions,
  onOpen,
}: {
  caseItem: CaseItem;
  title?: string;                 // 覆盖显示名称（如去除【Fanout 验证】前缀）
  score?: number;                 // 相似度 0..1（提供时右上显示「相似度 X%」）
  reason?: string;                // 判断依据
  topRight?: ReactNode;           // 自定义右上内容（优先于 score）
  actions?: ReactNode;            // 右侧操作按钮
  onOpen?: (id: string) => void;  // 点击标题打开 Case
}) {
  const progress = progressOfCase(caseItem);
  const right = topRight ?? (score != null
    ? <span className="text-[9.5px] text-slate-400 whitespace-nowrap shrink-0">相似度 {Math.round(score * 100)}%</span>
    : null);
  return (
    <div className="relative overflow-hidden rounded-lg border border-slate-200/90 bg-white px-3.5 py-2.5 hover:border-[#0052D9]/35 hover:shadow-[0_5px_16px_-10px_rgba(0,82,217,0.28)] transition-all">
      <span aria-hidden="true" className={`absolute left-0 top-3 bottom-3 w-0.5 rounded-r ${urgencyBar[caseItem.urgency]}`} />
      <div className="flex items-center gap-1.5 pl-0.5">
        <span className={`px-1 py-0.5 rounded text-[9px] leading-none border shrink-0 ${levelColors[caseItem.level]}`}>{caseItem.level}</span>
        <span className="shrink-0 inline-flex items-center" title={`任务平均完成度 ${progress}%`}>
          <ProgressRing value={progress} size={18} stroke={2.5} />
        </span>
        <span className="font-mono text-[9.5px] text-slate-300 truncate">{caseItem.code}</span>
        {(right || actions) && (
          <div className="ml-auto shrink-0 flex items-center gap-1">
            {right}
            {actions}
          </div>
        )}
      </div>
      {onOpen ? (
        <button onClick={() => onOpen(caseItem.id)} className="mt-1.5 block w-full text-left text-[12px] leading-snug font-medium text-slate-800 hover:text-[#0052D9] truncate">{title ?? caseItem.name}</button>
      ) : (
        <div className="mt-1.5 text-[12px] leading-snug font-medium text-slate-800 truncate">{title ?? caseItem.name}</div>
      )}
      {reason && (
        <div className="mt-1 text-[10px] leading-relaxed text-slate-500 line-clamp-2">
          <span className="font-medium text-slate-600">判断依据：</span>{reason}
        </div>
      )}
    </div>
  );
}
