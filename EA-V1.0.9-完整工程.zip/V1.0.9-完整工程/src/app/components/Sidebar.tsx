import { useState } from "react";
import {
  Inbox,
  FolderKanban,
  Clock,
  Bookmark,
  Users,
  ChevronRight,
  LogOut,
  NotebookPen,
  PanelLeftClose,
  PanelLeft,
  Trophy,
  Crown,
  GitMerge,
  Library,
} from "lucide-react";
import { currentUser } from "./data";

export type PageKey = "todo" | "approvals" | "cases" | "products" | "issues" | "manager" | "skills" | "skill-center" | "contest" | "create" | "ai" | "profile";
// 「我的」下的二级导航
export type TodoTab = "task" | "own" | "dept" | "sub" | "recent" | "log" | "issue";

interface Props {
  active: PageKey;
  onChange: (k: PageKey) => void;
  todoTab: TodoTab;
  onTodoTab: (t: TodoTab) => void;
}

const todoSubs: { key: TodoTab; label: string; icon: any }[] = [
  { key: "task", label: "我的任务", icon: Inbox },
  { key: "own", label: "我的 Case", icon: FolderKanban },
  { key: "recent", label: "我的关注", icon: Bookmark },
  { key: "log", label: "智能汇总", icon: NotebookPen },
];

export function Sidebar({ active, onChange, todoTab, onTodoTab }: Props) {
  const onTodo = active === "todo";
  const [collapsed, setCollapsed] = useState(false);
  const [todoOpen, setTodoOpen] = useState(true);

  // 收起态：主导航项只显示图标
  const IconItem = ({ icon: Icon, label, on, onClick }: { icon: any; label: string; on: boolean; onClick: () => void }) => (
    <button
      onClick={onClick}
      title={label}
      className={`w-full flex items-center justify-center h-10 rounded-md transition-colors ${
        on ? "bg-[#0052D9]/8 text-[#0052D9]" : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
      }`}
    >
      <Icon size={18} />
    </button>
  );

  return (
    <aside
      className={`${collapsed ? "w-[64px]" : "w-[236px]"} shrink-0 h-full bg-white border-r border-slate-200 text-slate-700 flex flex-col transition-[width] duration-200`}
    >
      {/* Brand */}
      <div className={`h-14 flex items-center border-b border-slate-100 ${collapsed ? "justify-center px-0" : "gap-2 px-4"}`}>
        <div className="w-7 h-7 rounded-md bg-gradient-to-br from-[#00A4FF] to-[#0052D9] flex items-center justify-center text-white shrink-0">
          E
        </div>
        {!collapsed && (
          <>
            <div className="leading-tight">
              <div className="text-slate-900 tracking-wide">EA Platform</div>
              <div className="text-[11px] text-slate-400">Engineering Portal</div>
            </div>
            <button
              onClick={() => setCollapsed(true)}
              title="收起侧栏"
              className="ml-auto w-7 h-7 rounded-md hover:bg-slate-100 flex items-center justify-center text-slate-400 hover:text-slate-600"
            >
              <PanelLeftClose size={16} />
            </button>
          </>
        )}
      </div>

      {/* Main nav */}
      <nav className="flex-1 px-2 py-3 space-y-0.5 overflow-y-auto">
        {!collapsed && <div className="text-[11px] uppercase text-slate-400 px-3 py-2 tracking-wider">工作台</div>}

        {/* 我的 */}
        {collapsed ? (
          <IconItem icon={Inbox} label="我的" on={onTodo} onClick={() => { onChange("todo"); onTodoTab("task"); }} />
        ) : (
          <>
            <div className={`group flex items-center rounded-md ${onTodo ? "text-slate-900 font-medium" : "text-slate-600 hover:bg-slate-50"}`}>
              <button
                onClick={() => { onChange("todo"); onTodoTab("task"); setTodoOpen(true); }}
                className="flex-1 flex items-center gap-2.5 pl-3 py-2 text-sm"
              >
                <Inbox size={16} />
                <span className="flex-1 text-left">我的</span>
              </button>
              <button
                onClick={() => setTodoOpen((o) => !o)}
                title={todoOpen ? "收起" : "展开"}
                className="px-2.5 py-2 text-slate-400 hover:text-slate-600"
              >
                <ChevronRight size={14} className={`transition-transform ${todoOpen ? "rotate-90" : ""}`} />
              </button>
            </div>

            {/* 二级子项 */}
            {todoOpen && (
              <div className="relative ml-[19px] pl-3 border-l border-slate-200 space-y-0.5 mb-1">
                {todoSubs.map((s) => {
                  const Icon = s.icon;
                  const on = onTodo && todoTab === s.key;
                  return (
                    <button
                      key={s.key}
                      onClick={() => { onTodoTab(s.key); onChange("todo"); }}
                      className={`w-full flex items-center gap-2.5 px-3 py-1.5 rounded-md text-[13px] transition-colors ${
                        on ? "bg-[#0052D9]/8 text-[#0052D9] font-medium" : "text-slate-500 hover:bg-slate-50 hover:text-slate-800"
                      }`}
                    >
                      <Icon size={15} className="shrink-0" />
                      <span className="flex-1 text-left">{s.label}</span>
                    </button>
                  );
                })}
              </div>
            )}
          </>
        )}

        {/* Case 中心 */}
        {collapsed ? (
          <IconItem icon={FolderKanban} label="分析中心" on={active === "cases"} onClick={() => onChange("cases")} />
        ) : (
          <button
            onClick={() => onChange("cases")}
            className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-md text-sm transition-colors ${
              active === "cases" ? "bg-[#0052D9]/8 text-[#0052D9] font-medium" : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
            }`}
          >
            <FolderKanban size={16} />
            <span className="flex-1 text-left">分析中心</span>
          </button>
        )}

        {/* 团队看板 */}
        {collapsed ? <IconItem icon={Library} label="技能中心" on={active === "skill-center"} onClick={() => onChange("skill-center")} /> : <button type="button" onClick={() => onChange("skill-center")} className={`flex w-full items-center gap-2.5 rounded-md px-3 py-2 text-sm ${active === "skill-center" ? "bg-[#0052D9]/8 font-medium text-[#0052D9]" : "text-slate-600 hover:bg-slate-50"}`}><Library size={16} /><span className="flex-1 text-left">技能中心</span></button>}
        {collapsed ? (
          <IconItem icon={Users} label="团队看板" on={active === "manager"} onClick={() => onChange("manager")} />
        ) : (
          <button
            onClick={() => onChange("manager")}
            className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-md text-sm transition-colors ${
              active === "manager" ? "bg-[#0052D9]/8 text-[#0052D9] font-medium" : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
            }`}
          >
            <Users size={16} />
            <span className="flex-1 text-left">团队看板</span>
          </button>
        )}

        {/* AI 创新大赛入口已隐藏（V1.0.4） */}
      </nav>

      {/* Footer: collapse toggle (collapsed) + user card + utils */}
      <div className={`border-t border-slate-100 space-y-2 ${collapsed ? "px-2 py-3" : "px-3 py-3"}`}>
        {collapsed && (
          <button
            onClick={() => setCollapsed(false)}
            title="展开侧栏"
            className="w-full h-9 rounded-md hover:bg-slate-50 flex items-center justify-center text-slate-400 hover:text-slate-600"
          >
            <PanelLeft size={16} />
          </button>
        )}

        {collapsed ? (
          <button
            onClick={() => onChange("profile")}
            title={`${currentUser.name} · 个人主页`}
            className="w-full flex justify-center py-1"
          >
            <div className={`w-8 h-8 rounded-full bg-gradient-to-br from-[#00A4FF] to-[#0052D9] text-white flex items-center justify-center text-xs transition-all ${active === "profile" ? "ring-2 ring-[#0052D9]/30" : ""}`}>
              {currentUser.avatar}
            </div>
          </button>
        ) : (
          <>
            <div className={`flex items-center gap-2 p-2 rounded-md transition-colors ${active === "profile" ? "bg-[#0052D9]/8 ring-1 ring-[#0052D9]/20" : "bg-slate-50"}`}>
              <button
                onClick={() => onChange("profile")}
                title="查看个人主页"
                className="flex-1 flex items-center gap-2 min-w-0 text-left group"
              >
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#00A4FF] to-[#0052D9] text-white flex items-center justify-center text-xs shrink-0 group-hover:ring-2 group-hover:ring-[#0052D9]/25 transition-all">
                  {currentUser.avatar}
                </div>
                <div className="flex-1 leading-tight min-w-0">
                  <div className={`text-sm truncate transition-colors ${active === "profile" ? "text-[#0052D9] font-medium" : "text-slate-900 group-hover:text-[#0052D9]"}`}>{currentUser.name}</div>
                  <div className="text-[11px] text-slate-500 truncate">
                    {currentUser.role} · {currentUser.department}
                  </div>
                </div>
              </button>
              <button title="退出登录" className="w-6 h-6 rounded hover:bg-white flex items-center justify-center text-slate-400 shrink-0">
                <LogOut size={12} />
              </button>
            </div>
            <div className="px-1 flex items-center justify-center gap-1 text-[10px] text-slate-300 tracking-wide">
              <span>EA Platform</span>
              <span className="text-slate-200">·</span>
              <span className="tabular-nums" title="当前版本">V1.0.9</span>
            </div>
          </>
        )}
      </div>
    </aside>
  );
}
