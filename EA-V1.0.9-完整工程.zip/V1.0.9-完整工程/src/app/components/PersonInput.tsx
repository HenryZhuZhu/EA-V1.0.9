import { useEffect, useRef, useState } from "react";
import { Check, Search, UsersRound } from "lucide-react";
import { ownerToDepartment } from "./data";

const PEOPLE = Object.keys(ownerToDepartment).filter((n) => !n.endsWith("主管"));
const MOCK_GROUPS: Record<string, string[]> = { GID080520000: ["张三", "李四", "王五"] };

// @ 人员选择器：输入或键入 @ 后弹出人员候选（按姓名/部门检索）
export function PersonInput({
  id,
  value,
  onChange,
  placeholder = "@ 选择人员",
  className,
  disabled = false,
}: {
  id?: string;
  value: string;
  onChange: (name: string) => void;
  placeholder?: string;
  className?: string;
  disabled?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const i = value.lastIndexOf("@");
  const query = (i >= 0 ? value.slice(i + 1) : value).trim();
  const matches = PEOPLE.filter((p) => !query || p.includes(query) || ownerToDepartment[p].includes(query)).slice(0, 8);

  return (
    <div className="relative">
      <input
        id={id}
        value={value}
        disabled={disabled}
        onChange={(e) => { onChange(e.target.value); setOpen(true); }}
        onFocus={() => { if (!disabled) setOpen(true); }}
        onBlur={() => setTimeout(() => setOpen(false), 150)}
        placeholder={placeholder}
        className={className || "w-full h-8 px-2 text-sm rounded border border-slate-200 bg-white outline-none focus:border-[#0052D9]"}
      />
      {!disabled && open && matches.length > 0 && (
        <div className="absolute z-50 mt-1 left-0 right-0 min-w-[180px] max-h-52 overflow-auto bg-white border border-slate-200 rounded-md shadow-lg py-1">
          {matches.map((p) => (
            <button
              key={p}
              type="button"
              onMouseDown={(e) => { e.preventDefault(); onChange(p); setOpen(false); }}
              className="w-full text-left px-2.5 py-1.5 text-sm hover:bg-slate-50 flex items-center gap-2"
            >
              <span className="w-5 h-5 rounded-full bg-[#0052D9]/8 text-[#0052D9] text-[10px] font-medium flex items-center justify-center shrink-0">{p[0]}</span>
              <span className="text-slate-800">{p}</span>
              <span className="ml-auto text-[11px] text-slate-400">{ownerToDepartment[p]}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

export function MultiPersonInput({
  value,
  onChange,
  exclude = [],
  placeholder = "添加参与人（可选）",
  selectedInside = false,
}: {
  value: string[];
  onChange: (names: string[]) => void;
  exclude?: string[];
  placeholder?: string;
  selectedInside?: boolean;
}) {
  const root = useRef<HTMLDivElement>(null);
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [draft, setDraft] = useState<string[]>(value);
  const [groupId, setGroupId] = useState("");
  const [groupMessage, setGroupMessage] = useState("");
  const selectedNames = value.filter((name) => !exclude.includes(name)).join("、");
  useEffect(() => {
    if (!selectedInside || !open) return;
    const closeOutside = (event: PointerEvent) => {
      if (!root.current?.contains(event.target as Node)) { setOpen(false); setQuery(""); }
    };
    document.addEventListener("pointerdown", closeOutside);
    return () => document.removeEventListener("pointerdown", closeOutside);
  }, [selectedInside, open]);
  const matches = PEOPLE.filter((p) =>
    !exclude.includes(p)
    && (!query.trim() || p.includes(query.trim()) || ownerToDepartment[p].includes(query.trim())),
  );

  const openPicker = () => {
    if (selectedInside) { setQuery(""); setGroupMessage(""); }
    setDraft(value.filter((name) => !exclude.includes(name)));
    setOpen(true);
  };

  return (
    <div ref={root} className="relative" onKeyDown={selectedInside ? (event) => {
      if (event.key === "Escape") { event.stopPropagation(); setOpen(false); setQuery(""); }
    } : undefined} onBlur={selectedInside ? (event) => {
      if (!event.currentTarget.contains(event.relatedTarget as Node | null)) { setOpen(false); setQuery(""); }
    } : undefined}>
      <div className="relative">
        <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
        <input
          value={selectedInside && !open ? selectedNames : query}
          aria-label={placeholder}
          title={selectedInside && selectedNames ? selectedNames : undefined}
          autoComplete="off"
          onChange={(e) => { setQuery(e.target.value); if (!open) openPicker(); }}
          onFocus={() => { if (!selectedInside || !open) openPicker(); }}
          onClick={() => { if (!open) openPicker(); }}
          onBlur={selectedInside ? undefined : () => setTimeout(() => setOpen(false), 150)}
          placeholder={placeholder}
          className="w-full h-9 pl-9 pr-3 rounded-md border border-slate-200 bg-white focus:border-[#0052D9] outline-none text-sm"
        />
      </div>
      {open && (
        <div className="absolute z-50 bottom-full mb-1 left-0 right-0 min-w-[300px] bg-white border border-slate-200 rounded-lg shadow-xl overflow-hidden">
          <div className="p-2.5 border-b border-slate-100 bg-slate-50">
            <div className="flex items-center gap-1.5 text-[11px] font-medium text-slate-600 mb-1.5"><UsersRound size={12} />从群组导入</div>
            <div className="flex gap-1.5"><input value={groupId} onChange={(event) => { setGroupId(event.target.value); setGroupMessage(""); }} onMouseDown={(event) => event.stopPropagation()} placeholder="输入群组 ID" className="h-7 min-w-0 flex-1 px-2 text-xs rounded border border-slate-200 bg-white outline-none focus:border-[#0052D9]"/><button type="button" onMouseDown={(event) => { event.preventDefault(); const members = MOCK_GROUPS[groupId.trim().toUpperCase()]; if (!members) { setGroupMessage("未找到该群组"); return; } const next = Array.from(new Set([...draft, ...members.filter((name) => !exclude.includes(name))])); setDraft(next); setGroupMessage(`已读取 ${members.length} 人，新增 ${next.length - draft.length} 人`); }} className="h-7 px-2.5 rounded bg-[#0052D9] text-white text-xs">读取群组</button></div>
            {groupMessage && <div className={`mt-1.5 text-[10px] ${groupMessage.startsWith("未") ? "text-red-500" : "text-emerald-600"}`}>{groupMessage}</div>}
          </div>
          <div className="max-h-52 overflow-auto py-1">
            {matches.length > 0 ? matches.map((person) => {
              const selected = draft.includes(person);
              return (
                <button
                  key={person}
                  type="button"
                  onMouseDown={(e) => {
                    e.preventDefault();
                    setDraft((current) => selected
                      ? current.filter((name) => name !== person)
                      : [...current, person]);
                  }}
                  className={`w-full px-3 py-2 flex items-center gap-2.5 text-left hover:bg-slate-50 ${selected ? "bg-[#0052D9]/5" : ""}`}
                >
                  <span className="w-7 h-7 rounded-full bg-gradient-to-br from-[#0052D9] to-[#00A4FF] flex items-center justify-center text-white text-[10px] border-2 border-white shrink-0">
                    {person.slice(-2)}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block text-sm text-slate-800">{person}</span>
                    <span className="block text-[10px] text-slate-400">{ownerToDepartment[person]}</span>
                  </span>
                  <span className={`w-4 h-4 rounded border grid place-items-center ${selected ? "bg-[#0052D9] border-[#0052D9] text-white" : "border-slate-300"}`}>
                    {selected && <Check size={11} />}
                  </span>
                </button>
              );
            }) : (
              <div className="px-3 py-6 text-center text-xs text-slate-400">未找到匹配人员</div>
            )}
          </div>
          <div className="h-11 px-3 border-t border-slate-100 bg-slate-50 flex items-center justify-between">
            <span className="text-[11px] text-slate-400">已选择 {draft.length} 人</span>
            <div className="flex gap-2">
              <button
                type="button"
                onMouseDown={(e) => { e.preventDefault(); setOpen(false); setQuery(""); }}
                className="h-7 px-3 rounded text-xs text-slate-500 hover:bg-slate-200"
              >
                取消
              </button>
              <button
                type="button"
                onMouseDown={(e) => { e.preventDefault(); onChange(draft); setOpen(false); setQuery(""); }}
                className="h-7 px-3 rounded bg-[#0052D9] text-white text-xs hover:bg-[#003FA8]"
              >
                确定添加
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
