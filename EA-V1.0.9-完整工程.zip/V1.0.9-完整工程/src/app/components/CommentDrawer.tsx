import { useState, type ReactNode } from "react";
import * as Dialog from "@radix-ui/react-dialog";
import { MessageSquare, X, Send, CornerDownRight } from "lucide-react";
import { currentUser } from "./data";

export type CaseComment = {
  id: string;
  author: string;
  department?: string;
  at: string;
  text: string;
  replyTo?: string; // author name being replied to
};

const seed: CaseComment[] = [
  { id: "c1", author: "张伟", department: "PTE", at: "04-22 11:20", text: "低压 shmoo 边界明显收窄，建议优先验证 refresh timing margin。" },
  { id: "c2", author: "李娜", department: "PIE", at: "04-22 13:05", text: "我这边补了两片 wafer 边缘的 cross-section，疑似工艺偏移叠加。", replyTo: "张伟" },
  { id: "c3", author: "孙楠", department: "PE", at: "04-22 15:40", text: "客户那边催第二批退货结论，本周内需给初步方向。" },
];

export function CommentDrawer({
  caseName,
  caseCode,
  onClose,
  children,
  title = "Case 评论",
  count,
}: {
  caseName: string;
  caseCode: string;
  onClose: () => void;
  children?: ReactNode;
  title?: string;
  count?: number;
}) {
  const [comments, setComments] = useState<CaseComment[]>(seed);
  const [draft, setDraft] = useState("");
  const [replyTo, setReplyTo] = useState<string | null>(null);

  const submit = () => {
    const t = draft.trim();
    if (!t) return;
    setComments((prev) => [
      ...prev,
      {
        id: `c${Date.now()}`,
        author: currentUser.name,
        department: currentUser.department,
        at: new Date().toISOString().slice(5, 16).replace("T", " "),
        text: t,
        replyTo: replyTo || undefined,
      },
    ]);
    setDraft("");
    setReplyTo(null);
  };

  return (
    <Dialog.Root open onOpenChange={open => { if (!open) onClose(); }}><Dialog.Portal>
      {/* 遮罩 */}
      <Dialog.Overlay className="fixed inset-0 z-[80] bg-slate-900/30" />
      {/* 抽屉 */}
      <Dialog.Content aria-describedby={undefined} className="fixed right-0 top-0 z-[81] w-[420px] max-w-[90vw] h-full bg-white border-l border-slate-200 shadow-2xl flex flex-col animate-[slideIn_.22s_ease-out]">
        <style>{`@keyframes slideIn{from{transform:translateX(24px);opacity:.4}to{transform:translateX(0);opacity:1}}`}</style>
        {/* 头部 */}
        <div className="px-5 py-3.5 border-b border-slate-100 flex items-center gap-2 shrink-0">
          <MessageSquare size={16} className="text-[#0052D9]" />
          <div className="min-w-0">
            <Dialog.Title className="text-sm text-slate-800 font-medium flex items-center gap-2">
              {title} <span className="text-[11px] text-slate-400 font-normal">{count ?? comments.length} 条</span>
            </Dialog.Title>
            <div className="text-[11px] text-slate-400 truncate font-mono">{caseCode} · {caseName}</div>
          </div>
          <button aria-label="关闭评论" onClick={onClose} className="ml-auto text-slate-400 hover:text-slate-600 shrink-0">
            <X size={17} />
          </button>
        </div>

        {children ? <div className="min-h-0 flex-1 overflow-y-auto">{children}</div> : <>
        {/* 评论列表 */}
        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
          {comments.length === 0 && (
            <div className="text-center text-xs text-slate-400 py-12">还没有评论，来写下第一条吧。</div>
          )}
          {comments.map((c) => (
            <div key={c.id} className="flex gap-2.5">
              <div className="w-7 h-7 rounded-full bg-gradient-to-br from-[#0052D9] to-[#00A4FF] flex items-center justify-center text-white text-[10px] shrink-0 mt-0.5">
                {c.author.slice(-2)}
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-1.5">
                  <span className="text-xs text-slate-800 font-medium">{c.author}</span>
                  {c.department && <span className="text-[10px] text-slate-400">{c.department}</span>}
                  <span className="text-[10px] text-slate-300 ml-auto">{c.at}</span>
                </div>
                {c.replyTo && (
                  <div className="mt-1 text-[11px] text-slate-400 inline-flex items-center gap-1">
                    <CornerDownRight size={11} /> 回复 {c.replyTo}
                  </div>
                )}
                <div className="mt-1 text-[13px] text-slate-700 leading-relaxed bg-slate-50/70 border border-slate-100 rounded-lg px-3 py-2">
                  {c.text}
                </div>
                <button
                  onClick={() => setReplyTo(c.author)}
                  className="mt-1 text-[11px] text-slate-400 hover:text-[#0052D9]"
                >
                  回复
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* 输入区 */}
        <div className="border-t border-slate-100 px-4 py-3 shrink-0 bg-white">
          {replyTo && (
            <div className="mb-2 flex items-center gap-1.5 text-[11px] text-slate-500">
              <CornerDownRight size={11} /> 回复 <b className="text-slate-700">{replyTo}</b>
              <button onClick={() => setReplyTo(null)} className="ml-1 text-slate-400 hover:text-slate-600">
                <X size={12} />
              </button>
            </div>
          )}
          <div className="flex items-end gap-2">
            <textarea
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) submit();
              }}
              rows={2}
              placeholder="写下评论…（⌘/Ctrl + Enter 发送）"
              className="flex-1 resize-none text-sm rounded-lg border border-slate-200 px-3 py-2 outline-none focus:border-[#0052D9] leading-relaxed"
            />
            <button
              onClick={submit}
              disabled={!draft.trim()}
              className="h-9 px-3.5 rounded-lg bg-[#0052D9] text-white text-sm hover:bg-[#003FA8] disabled:opacity-40 inline-flex items-center gap-1.5 shrink-0"
            >
              <Send size={14} /> 发送
            </button>
          </div>
        </div>
        </>}
      </Dialog.Content>
    </Dialog.Portal></Dialog.Root>
  );
}
