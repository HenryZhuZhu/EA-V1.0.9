import { Ban, CheckCheck } from "lucide-react";

export function TaskDetailActions({ onCancel, onTerminate, onComplete, completeForm, terminateReason, completeReason, hint }: {
  onCancel: () => void;
  onTerminate: () => void;
  onComplete?: () => void;
  completeForm?: string;
  terminateReason?: string;
  completeReason?: string;
  hint: string;
}) {
  return <footer aria-label="任务操作" className="sticky bottom-0 z-20 -mx-6 flex items-center gap-3 border-t border-slate-200 bg-white/95 px-6 py-3 backdrop-blur">
    <span className="min-w-0 truncate text-[11px] text-slate-400" title={hint}>{hint}</span>
    <div className="ml-auto flex shrink-0 items-center gap-2">
      <button type="button" onClick={onCancel} title="返回任务列表，不改变任务状态" className="h-9 rounded-md border border-slate-200 bg-white px-4 text-sm text-slate-600 hover:bg-slate-50">取消</button>
      <button type="button" onClick={onTerminate} disabled={Boolean(terminateReason)} title={terminateReason || "填写中止原因并停止任务"} className="inline-flex h-9 items-center gap-1.5 rounded-md border border-red-200 bg-red-50/60 px-4 text-sm text-red-600 hover:bg-red-50 disabled:cursor-not-allowed disabled:opacity-40"><Ban size={14} />中止</button>
      <button type={completeForm ? "submit" : "button"} form={completeForm} onClick={onComplete} disabled={Boolean(completeReason)} title={completeReason || "保存结果并标记任务已完成"} className="inline-flex h-9 items-center gap-1.5 rounded-md bg-gradient-to-r from-[#00B578] to-[#0F9F6E] px-5 text-sm text-white hover:shadow-md disabled:cursor-not-allowed disabled:opacity-40"><CheckCheck size={15} />完成</button>
    </div>
  </footer>;
}