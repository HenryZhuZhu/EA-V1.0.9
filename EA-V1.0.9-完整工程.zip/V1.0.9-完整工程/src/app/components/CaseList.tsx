import {
  FolderOpen,
  CalendarClock,
  ChevronDown,
  Crown,
  Search,
  Bell,
  BellOff,
  Bookmark,
  User,
  Users,
  Flame,
  CircleDot,
  CheckCircle2,
  Building2,
  ListChecks,
  AlertTriangle,
  History,
  ArrowDownUp,
  ArrowLeft,
  Trophy,
  Eye,
  Ban,
  Clock4,
  Inbox,
  AlarmClock,
  Sparkles,
  LayoutGrid,
  List as ListIcon,
  ChevronRight,
  X,
  Plus,
  Filter,
  Trash2,
  Package,
  Layers,
  GitMerge,
  Share2,
  ChartNoAxesColumnIncreasing,
  MessageSquareWarning,
} from "lucide-react";
import { CategoryTimeline, PRODUCT_STAGES, PLATFORM_STAGES, platformOf } from "./CategoryTimeline";
import { useState, useMemo } from "react";
import {
  mockCases,
  levelColors,
  urgencyBar,
  flattenTasks,
  currentUser,
  myTasksInCase,
  ownerToDepartment,
  issueOfCase,
  issueStatusColors,
} from "./data";
import { useSubscriptions } from "./subscriptions";
import { RecoveryBadge } from "./RecoveryControls";
import { CaseCoreParticipants } from "./CaseCoreParticipants";
import { CaseScore } from "./CaseScore";
import { useClosures } from "./closures";
import { StatusBadge } from "./StatusBadge";
import { ProgressRing } from "./ProgressRing";
import { IssueHub } from "./IssueHub";
import { ProductCenter } from "./ProductCenter";
import { CaseProductPill } from "./CaseProductPill";
import { CaseMarkCodePill } from "./CaseMarkCodePill";
import { ProductAnalysisRestored as ProductAnalysis } from "./ProductAnalysisRestored";
import { CaseDisplayStatus, CaseStatusBadge, caseDisplayStatus } from "./CaseStatusBadge";
import { caseFilterOptions, CASE_LEVEL_OPTIONS, CASE_URGENCY_OPTIONS, CASE_ANALYSIS_STATUS_OPTIONS } from "./CaseFilterFields";
import { caseCreators } from "./caseWorkbenchModel";
import { CaseFilterPanel, CASE_FILTER_PANEL_CLASS_NAME } from "./CaseFilterPanel";
import { WorkbenchSort } from "./WorkbenchSort";
import { activeCustomRules, buildCustomFilterRecords, customFieldCatalog, customFilterOptions, customSelectionRules, matchesCustomRules, type CustomFilterRule } from "./caseCustomFilters";
import { loadCaseTaskTree, useCaseTaskRevision } from "./caseTaskTrees";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";

interface Props {
  onOpenCase: (id: string) => void;
  onOpenIssue?: (id: string) => void;
  initialView?: "focus" | "list" | "product" | "product-analysis" | "platform" | "issue" | "checklist";
}

const TODAY = "2026-06-09";

const levelOpts = CASE_LEVEL_OPTIONS;
const urgencyOpts = CASE_URGENCY_OPTIONS;
const statusOpts = CASE_ANALYSIS_STATUS_OPTIONS;
const scopeOpts = [
  { key: "all", label: "全部" },
  { key: "mine", label: "我作为 Case Owner" },
  { key: "related", label: "与我相关" },
  { key: "fanout", label: "Fanout我" },
] as const;
const sortOpts = [
  { key: "urgency", label: "紧迫度" },
  { key: "level", label: "层级" },
  { key: "progress", label: "进度(低→高)" },
  { key: "updated", label: "最近更新" },
] as const;

// Priority scoring for the default "紧迫度" sort
const dueWeight = (d: number) => (d <= 0 ? 1000 : d <= 1 ? 700 : d <= 3 ? 400 : Math.max(0, 200 - d * 5));
const levelWeight: Record<string, number> = { L0: 600, L1: 500, L2: 400, L3: 250 };
const levelRank: Record<string, number> = { L0: 0, L1: 1, L2: 2, L3: 3 };
const urgWeight: Record<string, number> = { 非常紧急: 300, 紧急: 200, 一般: 80, 不紧急: 20 };
const priorityScore = (c: any) =>
  dueWeight(c.dueIn) + (levelWeight[c.level] || 0) + (urgWeight[c.urgency] || 0);

const daysBetween = (a: string, b: string) =>
  Math.round(Math.abs(new Date(a).getTime() - new Date(b).getTime()) / 86400000);

type Row = { c: any; m: any };

export interface CustomCard {
  id: string;
  name: string;
  level: string;
  urgency: string;
  status: string;
  product: string;
  scope: "all" | "mine" | "related" | "fanout";
  subscribed: boolean;
}

function describeCustom(cc: CustomCard) {
  const parts: string[] = [];
  if (cc.level !== "全部") parts.push(cc.level);
  if (cc.urgency !== "全部") parts.push(cc.urgency);
  if (cc.status !== "全部") parts.push(cc.status);
  if (cc.product !== "全部") parts.push(cc.product);
  if (cc.scope === "mine") parts.push("我作为 Case Owner");
  if (cc.scope === "related") parts.push("与我相关");
  if (cc.scope === "fanout") parts.push("Fanout我");
  if (cc.subscribed) parts.push("已订阅");
  return parts.length ? parts.join(" · ") : "自定义筛选";
}

export function CaseList({ onOpenCase, onOpenIssue, initialView }: Props) {
  const subs = useSubscriptions();
  const closures = useClosures();
  useCaseTaskRevision();
  // 本次渲染共享同一份当前执行树；自定义任务筛选、数量、搜索和展开内容一致。
  const currentCases = mockCases.map(c => ({ ...c, tasks: loadCaseTaskTree(c.id, c.tasks) }));
  const [view, setView] = useState<"focus" | "list" | "product" | "product-analysis" | "platform" | "issue" | "checklist">(initialView ?? "focus");
  const [rankTab, setRankTab] = useState<"hot" | "attention">("hot"); // Case 排行：热门 / 关注度
  const [activeGroup, setActiveGroup] = useState<string | null>(null);
  const [level, setLevel] = useState<string>("全部");
  const [urgency, setUrgency] = useState<string>("全部");
  const [status, setStatus] = useState<string>("全部");
  const [product, setProduct] = useState<string>("全部");
  const [deptFilter, setDeptFilter] = useState<string>("全部"); // R05
  const [creator, setCreator] = useState<string>("全部");
  const creatorFilter = creator || "全部";
  const [q, setQ] = useState(""); // 统一搜索：Case 名称 / 编码 / 人员（R05 人名筛选已合并至此）
  const [showFanout, setShowFanout] = useState(false);
  const [scope, setScope] = useState<"all" | "mine" | "related" | "fanout" | "complaint">("all");
  const [riskOnly, setRiskOnly] = useState(false);
  const [sort, setSort] = useState<string>("urgency");
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const [customCards, setCustomCards] = useState<CustomCard[]>([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [filterOpen, setFilterOpen] = useState(false); // 方案3：筛选弹层开合
  const [customRulesDraft, setCustomRulesDraft] = useState<CustomFilterRule[]>([]);
  const customRules = customSelectionRules(customRulesDraft);
  const setCustomRules = (rules: CustomFilterRule[]) => setCustomRulesDraft(customSelectionRules(rules));

  const effectiveStatus = (c: any): CaseDisplayStatus => caseDisplayStatus(c, { closed: closures.isClosed(c.id), rootCaused: closures.isRootCaused(c.id) });
  const customRecords = buildCustomFilterRecords(currentCases, { loadTree: c => c.tasks, status: effectiveStatus, closure: closures.get });
  const customFields = customFieldCatalog(customRecords);
  const appliedCustomRules = activeCustomRules(customRules, customFields);
  const customRecordsById = new Map(customRecords.map(record => [record.caseData.id, record]));

  const metrics = (c: any) => {
    const actions = flattenTasks(c.tasks)
      .map((x) => x.task)
      .filter((t) => t.code);
    const base = actions.length ? actions : c.tasks;
    const prog = Math.round(
      base.reduce((s: number, t: any) => s + (t.progress || 0), 0) / Math.max(base.length, 1)
    );
    const count = (st: string) => actions.filter((t) => t.status === st).length;
    const blocked = count("已中止");
    const closed = closures.isClosed(c.id);
    return {
      taskTotal: actions.length,
      prog,
      inProgress: count("进行中"),
      blocked,
      pending: count("待接受"),
      done: count("已完成"),
      myTasks: myTasksInCase(c, currentUser.name).length,
      isOwner: c.owner === currentUser.name,
      closed,
      estatus: effectiveStatus(c),
      risk:
        !closed &&
        (c.dueIn <= 1 || blocked > 0 || ((c.level === "L0" || c.level === "L1") && c.dueIn <= 3)),
    };
  };

  const toggle = (id: string) =>
    setExpanded((s) => {
      const n = new Set(s);
      n.has(id) ? n.delete(id) : n.add(id);
      return n;
    });

  const { products: productOpts, departments: deptOpts, creators: creatorOpts } = caseFilterOptions(currentCases);

  // R05：某人是否参与该 Case（Owner / 参与人 / 任务负责人）
  const caseInvolvesPerson = (c: any, name: string) => {
    const n = name.trim();
    if (!n) return true;
    if ((c.owner || "").includes(n)) return true;
    if ((c.participants || []).some((p: any) => p.name.includes(n))) return true;
    return flattenTasks(c.tasks).some((x) => (x.task.owner || "").includes(n));
  };

  const isFanoutToMe = (c: any) =>
    (!!c.fanoutSourceCaseId || c.source === "fanout验证") &&
    c.createdBy !== currentUser.name &&
    (c.owner === currentUser.name || (c.participants || []).some((person: any) => person.name === currentUser.name));
  const isFanoutCase = (c: any) => !!c.fanoutSourceCaseId || c.source === "fanout验证";

  const goFocus = () => {
    setView("focus");
    setActiveGroup(null);
  };
  const resetFilters = () => {
    setLevel("全部"); setUrgency("全部"); setStatus("全部");
    setProduct("全部"); setQ(""); setShowFanout(false); setScope("all");
    setRiskOnly(false); setActiveGroup(null); setDeptFilter("全部");
    setCreator("全部");
    setCustomRules([]);
  };

  // Compute metrics once per case
  const rows: Row[] = currentCases.map((c) => ({ c, m: metrics(c) }));

  // Global overview counts (KPI strip — list view only)
  const kActive = rows.filter((r) => r.m.estatus === "进行中").length;
  const kRisk = rows.filter((r) => r.m.risk).length;
  const kMine = rows.filter((r) => r.m.isOwner && !r.m.closed).length;
  const kRelated = rows.filter((r) => r.m.myTasks > 0 && !r.m.closed).length;
  const kFanoutToMe = rows.filter((r) => isFanoutToMe(r.c)).length;
  const kClosed = rows.filter((r) => r.m.closed).length;

  // ---- Smart groups (the curated dashboard) ----
  const newestCreated = rows.map((r) => r.c.createdAt).sort().slice(-1)[0] || TODAY;
  const todayNew = rows.filter((r) => r.c.createdAt === TODAY);
  const newIsToday = todayNew.length > 0;

  const groupPredicate: Record<string, (r: Row) => boolean> = {
    todo: (r) =>
      !r.m.closed && (r.m.isOwner || r.m.myTasks > 0) && (r.m.pending > 0 || r.m.blocked > 0 || r.c.dueIn <= 2),
    deadline: (r) => !r.m.closed && r.c.dueIn <= 3,
    priority: (r) => !r.m.closed && (r.c.level === "L0" || r.c.level === "L1"),
    new: (r) => (newIsToday ? r.c.createdAt === TODAY : daysBetween(r.c.createdAt, newestCreated) <= 7),
    dept: (r) => !r.m.closed && ownerToDepartment[r.c.owner] === currentUser.department,
    subscribed: (r) => subs.isSubscribed(r.c.id),
  };
  const byScore = (a: Row, b: Row) => priorityScore(b.c) - priorityScore(a.c);
  const groupSort: Record<string, (a: Row, b: Row) => number> = {
    todo: byScore,
    deadline: (a, b) => a.c.dueIn - b.c.dueIn,
    priority: byScore,
    new: (a, b) => b.c.createdAt.localeCompare(a.c.createdAt),
    dept: byScore,
    subscribed: (a, b) => (b.c.updatedAt || "").localeCompare(a.c.updatedAt || ""),
  };
  const groupDefs = [
    { key: "todo", title: "需我处理", subtitle: "我作为 Case Owner/负责且待推进", icon: Inbox, tone: "text-[#0052D9] bg-[#0052D9]/8" },
    { key: "deadline", title: "临期与逾期", subtitle: "3 天内到期，优先处理", icon: AlarmClock, tone: "text-red-600 bg-red-50" },
    { key: "priority", title: "高优先级 · L0 / L1", subtitle: "影响大，重点跟进", icon: Flame, tone: "text-orange-600 bg-orange-50" },
    { key: "new", title: newIsToday ? "今日新增" : "近期新增", subtitle: newIsToday ? "今天创建的 Case" : "最新创建的 Case", icon: Sparkles, tone: "text-emerald-600 bg-emerald-50" },
    { key: "dept", title: "我的部门 Case", subtitle: `属于 ${currentUser.department} 的 Case`, icon: Building2, tone: "text-[#0052D9] bg-[#0052D9]/8" },
    { key: "subscribed", title: "我的订阅", subtitle: "你关注的 Case", icon: Bookmark, tone: "text-violet-600 bg-violet-50" },
  ];

  // ---- Custom card predicate (mirrors list filters) ----
  const customPredicate = (cc: CustomCard) => (r: Row) => {
    const { c, m } = r;
    if (cc.level !== "全部" && c.level !== cc.level) return false;
    if (cc.urgency !== "全部" && c.urgency !== cc.urgency) return false;
    if (cc.status !== "全部" && m.estatus !== cc.status) return false;
    if (cc.product !== "全部" && c.product !== cc.product) return false;
    if (cc.scope === "mine" && !m.isOwner) return false;
    if (cc.scope === "related" && m.myTasks === 0) return false;
    if (cc.scope === "fanout" && !isFanoutToMe(c)) return false;
    if (cc.subscribed && !subs.isSubscribed(c.id)) return false;
    return true;
  };
  const applyCustomToList = (cc: CustomCard) => {
    setLevel(cc.level); setUrgency(cc.urgency); setStatus(cc.status); setProduct(cc.product);
    setCreator("全部");
    setScope(cc.scope); setShowFanout(cc.scope === "fanout"); setRiskOnly(false); setActiveGroup(cc.subscribed ? "subscribed" : null);
    setCustomRules([]);
    setView("list");
  };

  // ---- List view filtering ----
  const filtered = rows.filter(({ c, m }) => {
    if (!showFanout && isFanoutCase(c)) return false;
    if (activeGroup && !groupPredicate[activeGroup]({ c, m })) return false;
    if (level !== "全部" && c.level !== level) return false;
    if (urgency !== "全部" && c.urgency !== urgency) return false;
    if (status !== "全部" && m.estatus !== status) return false;
    if (product !== "全部" && c.product !== product) return false;
    if (deptFilter !== "全部" && !(c.departments || []).includes(deptFilter)) return false;
    if (creatorFilter !== "全部" && !caseCreators(c).includes(creatorFilter)) return false;
    // 单一搜索框：同时匹配 Case 名称 / 编码 / 相关人员（牵头人、参与人、任务负责人）
    if (q && !c.name.includes(q) && !c.code.includes(q) && !caseInvolvesPerson(c, q)) return false;
    if (scope === "mine" && !m.isOwner) return false;
    if (scope === "related" && m.myTasks === 0) return false;
    if (scope === "fanout" && !isFanoutToMe(c)) return false;
    if (scope === "complaint" && c.source !== "Q·FAQA") return false;
    if (riskOnly && !m.risk) return false;
    if (appliedCustomRules.length && !matchesCustomRules(customRecordsById.get(c.id)!, appliedCustomRules, customFields)) return false;
    return true;
  });

  filtered.sort((A, B) => {
    if (A.m.closed !== B.m.closed) return A.m.closed ? 1 : -1;
    switch (sort) {
      case "level":
        return (levelRank[A.c.level] - levelRank[B.c.level]) || (priorityScore(B.c) - priorityScore(A.c));
      case "progress":
        return A.m.prog - B.m.prog;
      case "updated":
        return (B.c.updatedAt || "").localeCompare(A.c.updatedAt || "");
      default:
        return priorityScore(B.c) - priorityScore(A.c);
    }
  });

  const subscribedCount = mockCases.filter((c) => subs.isSubscribed(c.id)).length;
  // 方案3：已应用的筛选数量（用于「筛选」按钮徽标）
  const activeFilterCount =
    (level !== "全部" ? 1 : 0) + (urgency !== "全部" ? 1 : 0) + (status !== "全部" ? 1 : 0) +
    (product !== "全部" ? 1 : 0) + (deptFilter !== "全部" ? 1 : 0) + (creatorFilter !== "全部" ? 1 : 0) +
    (scope !== "all" ? 1 : 0) + (showFanout ? 1 : 0) + appliedCustomRules.length;

  const openGroup = (key: string) => {
    setActiveGroup(key);
    setView("list");
  };

  const kpiDefs = [
    { key: "active", label: "进行中", value: kActive, icon: CircleDot, tone: "text-[#0052D9] bg-[#0052D9]/8 border-[#0052D9]/30",
      active: status === "进行中", onClick: () => setStatus(status === "进行中" ? "全部" : "进行中") },
    { key: "risk", label: "需立即关注", value: kRisk, icon: Flame, tone: "text-red-600 bg-red-50 border-red-200",
      active: riskOnly, onClick: () => setRiskOnly((v) => !v) },
    { key: "mine", label: "我作为 Case Owner", value: kMine, icon: Crown, tone: "text-amber-600 bg-amber-50 border-amber-200",
      active: scope === "mine", onClick: () => setScope(scope === "mine" ? "all" : "mine") },
    { key: "related", label: "与我相关", value: kRelated, icon: Users, tone: "text-violet-600 bg-violet-50 border-violet-200",
      active: scope === "related", onClick: () => setScope(scope === "related" ? "all" : "related") },
    { key: "fanout", label: "Fanout我", value: kFanoutToMe, icon: Share2, tone: "text-cyan-600 bg-cyan-50 border-cyan-200",
      active: scope === "fanout", onClick: () => { const next = scope === "fanout" ? "all" : "fanout"; setScope(next); if (next === "fanout") setShowFanout(true); } },
    { key: "closed", label: "已结案", value: kClosed, icon: CheckCircle2, tone: "text-emerald-600 bg-emerald-50 border-emerald-200",
      active: status === "已结案", onClick: () => setStatus(status === "已结案" ? "全部" : "已结案") },
  ];

  const activeGroupTitle = activeGroup ? groupDefs.find((g) => g.key === activeGroup)?.title : null;

  // ---- 聚焦首页（门户分栏）派生数据 ----
  const recentCases = [...mockCases]
    .sort((a, b) => (b.updatedAt || "").localeCompare(a.updatedAt || ""))
    .slice(0, 6);
  // Case 排行：热门（按更新时间）/ 关注度（按参与人 + 协作部门数）
  const attentionScore = (c: any) => (c.participants?.length || 0) + (c.departments?.length || 0);
  // 浏览次数（热门排行右侧指标）——按 code/参与人派生的稳定数值
  const viewsOf = (c: any) => 86 + ((parseInt(String(c.code).replace(/\D/g, "").slice(-4)) || 0) % 840) + (c.participants?.length || 0) * 23;
  const rankCases = [...mockCases]
    .sort((a, b) =>
      rankTab === "attention"
        ? attentionScore(b) - attentionScore(a) || (b.updatedAt || "").localeCompare(a.updatedAt || "")
        : viewsOf(b) - viewsOf(a) || (b.updatedAt || "").localeCompare(a.updatedAt || "")
    )
    .slice(0, 10);
  // 按主题聚焦入口：仅保留「高优先级」与「近期新增」两个通用维度
  const topicGroups = groupDefs.filter((g) => g.key === "priority" || g.key === "new");
  const topicAccent: Record<string, string> = {
    deadline: "#FF3B30", priority: "#FF9500", new: "#34C759", dept: "#0052D9", subscribed: "#8b5cf6",
  };
  const groupCount = (key: string) => rows.filter(groupPredicate[key]).length;

  // —— 产品 / 平台 级联筛选树（组 → 子项），数据多时用下拉级联 ——
  const famOf = (p: any) => String(p || "").split("-")[0] || "其他";
  const productTree = useMemo(() => {
    const products = Array.from(new Set(mockCases.map((c) => c.product).filter(Boolean))) as string[];
    const fams = Array.from(new Set(products.map(famOf)));
    const groups = fams.map((f) => ({
      key: `fam:${f}`,
      label: f,
      match: (c: any) => famOf(c.product) === f,
      children: products
        .filter((p) => famOf(p) === f)
        .map((p) => ({ key: `prod:${p}`, label: p, match: (c: any) => c.product === p })),
    }));
    return [{ key: "all", label: "全部产品", match: (_c: any) => true }, ...groups];
  }, []);
  const platformTree = useMemo(() => {
    const plats = Array.from(new Set(mockCases.map((c) => platformOf(c))));
    const groups = plats.map((pl) => ({
      key: `plat:${pl}`,
      label: pl,
      match: (c: any) => platformOf(c) === pl,
      children: (Array.from(
        new Set(mockCases.filter((c) => platformOf(c) === pl).map((c) => c.product).filter(Boolean))
      ) as string[]).map((p) => ({ key: `pp:${p}`, label: p, match: (c: any) => c.product === p })),
    }));
    return [{ key: "all", label: "全部平台", match: (_c: any) => true }, ...groups];
  }, []);

  return (
    <div className="relative">
      <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(ellipse_80%_50%_at_0%_0%,rgba(0,82,217,0.05),transparent_60%)]" />

      <div className="relative p-8 space-y-6 max-w-[1400px] mx-auto">
        {/* 返回按钮 —— 非聚焦视图左上角，样式参照 Case 详情页 */}
        {view !== "focus" && (
          <button
            onClick={goFocus}
            className="text-sm text-slate-500 hover:text-[#0052D9] flex items-center gap-1"
          >
            <ArrowLeft size={14} /> 返回
          </button>
        )}
        {/* Header — 模块名随视图变化 */}
        <header className="flex items-start justify-between gap-4 flex-wrap">
          <div>
            <h1 className="text-slate-900 tracking-tight">
              {view === "focus" ? "分析中心"
                : view === "list" ? "全部 Case 列表"
                : view === "issue" ? "Issue 中心"
                : view === "checklist" ? "Checklist 管理"
                : view === "product-analysis" ? "产品分析"
                : view === "product" ? "产品分类"
                : "平台分类"}
            </h1>
            <p className="text-sm text-slate-500 mt-1">
              {view === "focus" ? "按维度聚合，快速定位你关心的 Case"
                : view === "list" ? "全部 Case · 可多维筛选与排序"
                : view === "issue" ? "共性问题 · 按 Case 分组 / Issue 列表 双视角"
                : view === "checklist" ? "产品 → 项目 → Checklist(WBS) → 检查项 · Fail 自动生成 Case"
                : view === "product-analysis" ? "按产品查看 Case 规模、来源部门，以及相似与重复情况"
                : view === "product" ? "按产品汇总全部关联 Case 的 Update，并查看从 0 到 1 的全生命周期时间轴"
                : "按平台查看从 0 到 1 的全生命周期时间轴"}
            </p>
          </div>
          {view === "product-analysis" && <div id="product-analysis-global-tools" className="ml-auto flex items-center" />}
        </header>

        {/* ============ ISSUE 中心 ============ */}
        {view === "issue" && (
          <IssueHub onOpenCase={onOpenCase} onOpenIssue={(id) => onOpenIssue?.(id)} />
        )}

        {/* ============ CHECKLIST 管理视图 ============ */}
        {view === "checklist" && (
          <ProductCenter embedded onOpenCase={onOpenCase} onOpenIssue={(id) => onOpenIssue?.(id)} />
        )}

        {/* ============ 产品分析 ============ */}
        {view === "product-analysis" && (
          <ProductAnalysis onOpenCase={onOpenCase} />
        )}

        {/* ============ FOCUS VIEW · 方案28 黄金比：左三叠（全部列表/高优/近期）/ 右排行主体 ============ */}
        {view === "focus" && (
          <div className="grid grid-cols-1 lg:grid-cols-[1fr_1.62fr] gap-5 items-stretch min-h-[calc(100vh-188px)]">
            {/* 左：全部 Case 列表 + 高优先级 + 近期新增（三块各自独立、按内容定高、不撑满整列） */}
            <div className="flex flex-col gap-3 self-start">
              {/* 模块一：全部 Case 列表 —— 与下方卡片一致的白底（搜索已统一收口到顶部全局搜索） */}
              <button
                onClick={() => { resetFilters(); setView("list"); }}
                className="h-[124px] w-full rounded-xl overflow-hidden bg-white border border-slate-200/80 shadow-[0_1px_2px_0_rgba(15,23,42,0.04)] flex items-center gap-3.5 px-5 text-left group hover:border-[#0052D9]/40 hover:shadow-[0_8px_24px_-12px_rgba(0,82,217,0.25)] transition-all"
              >
                <span className="w-[52px] h-[52px] rounded-xl bg-[#0052D9]/10 text-[#0052D9] flex items-center justify-center shrink-0">
                  <ListIcon size={26} />
                </span>
                <span className="flex-1 min-w-0">
                  <span className="block text-[19px] font-bold text-slate-900 group-hover:text-[#0052D9] transition-colors">全部 Case 列表</span>
                  <span className="block text-[13px] text-slate-500 mt-0.5">浏览 / 多维筛选 / 排序</span>
                </span>
                <span className="flex items-baseline gap-0.5 leading-none shrink-0">
                  <span className="text-[42px] font-extrabold tabular-nums tracking-tight text-[#0052D9]">{mockCases.length}</span>
                  <span className="text-[13px] text-slate-400">个</span>
                </span>
              </button>

              {/* 模块二、三：高优先级 / 今日新增 —— 仅显示数字（不展开 case 信息） */}
              {topicGroups.map((g) => {
                const Icon = g.icon;
                return (
                  <button
                    key={g.key}
                    onClick={() => openGroup(g.key)}
                    className="h-[100px] bg-white border border-slate-200/80 rounded-xl shadow-[0_1px_2px_0_rgba(15,23,42,0.04)] flex items-center gap-4 px-5 hover:border-[#0052D9]/40 hover:shadow-[0_8px_24px_-12px_rgba(0,82,217,0.25)] transition-all text-left"
                  >
                    <span className={`w-[52px] h-[52px] rounded-xl flex items-center justify-center shrink-0 ${g.tone}`}>
                      <Icon size={24} />
                    </span>
                    <span className="flex-1 min-w-0">
                      <span className="block text-[17px] font-semibold text-slate-800">{g.title}</span>
                      <span className="block text-[13px] text-slate-400 mt-0.5">{g.subtitle}</span>
                    </span>
                    <span className="text-[42px] font-extrabold tabular-nums leading-none shrink-0" style={{ color: topicAccent[g.key] }}>
                      {groupCount(g.key)}
                    </span>
                  </button>
                );
              })}

              <button
                onClick={() => setView("product-analysis")}
                className="h-[100px] bg-white border border-slate-200/80 rounded-xl shadow-[0_1px_2px_0_rgba(15,23,42,0.04)] flex items-center gap-4 px-5 hover:border-[#0052D9]/40 hover:shadow-[0_8px_24px_-12px_rgba(0,82,217,0.25)] transition-all text-left"
              >
                <span className="w-[52px] h-[52px] rounded-xl flex items-center justify-center shrink-0 text-[#0052D9] bg-[#0052D9]/8">
                  <ChartNoAxesColumnIncreasing size={24} />
                </span>
                <span className="flex-1 min-w-0">
                  <span className="block text-[17px] font-semibold text-slate-800">产品分析</span>
                  <span className="block text-[13px] text-slate-400 mt-0.5">Case 统计 · 来源部门 · 相似重复</span>
                </span>
              </button>

              {/* V1.0.4：取消 Issue 概念 —— 移除「Issue 中心」入口 */}
              {/* V1.0.4：暂隐藏「产品分类 / 平台分类 / Checklist 管理」三个入口卡片 */}
            </div>

            {/* 右：Case 排行（独立卡，标题行内置 + 热门/关注度切换，统一行高、铺满到底） */}
            <div className="flex flex-col min-h-0">
              <div className="flex-1 min-h-0 bg-white border border-slate-200/80 rounded-xl shadow-[0_1px_2px_0_rgba(15,23,42,0.04)] flex flex-col overflow-hidden">
                {/* 模块标题（内置于卡片，与左侧模块一致） */}
                <div className="flex items-center gap-2 px-4 h-10 border-b border-slate-100 shrink-0">
                  <span className="w-6 h-6 rounded-md bg-[#0052D9]/10 text-[#0052D9] flex items-center justify-center shrink-0">
                    <Trophy size={13} />
                  </span>
                  <span className="text-[13px] font-bold text-slate-800">Case 排行</span>
                  <div className="ml-auto inline-flex items-center bg-slate-100 rounded-lg p-0.5">
                    {([
                      { key: "hot", label: "热门排行" },
                      { key: "attention", label: "关注度排行" },
                    ] as const).map((t) => (
                      <button
                        key={t.key}
                        onClick={() => setRankTab(t.key)}
                        className={`h-6 px-2.5 rounded-md text-[11px] transition-colors ${
                          rankTab === t.key ? "bg-white text-[#0052D9] font-medium shadow-[0_1px_2px_rgba(15,23,42,0.08)]" : "text-slate-500 hover:text-slate-700"
                        }`}
                      >
                        {t.label}
                      </button>
                    ))}
                  </div>
                </div>
                {/* 排名行（统一行高，flex 均分铺满到底，舒适间距） */}
                <div className="flex-1 flex flex-col min-h-0">
                  {rankCases.map((c, i) => {
                    const m = metrics(c);
                    const overdue = (c.dueIn ?? 99) <= 0;
                    return (
                      <button
                        key={c.id}
                        onClick={() => onOpenCase(c.id)}
                        className="flex-1 min-h-[44px] w-full flex items-center gap-3 px-4 border-t border-slate-50 first:border-t-0 hover:bg-slate-50/60 transition-colors text-left"
                      >
                        <span className={`w-5 h-5 rounded-md flex items-center justify-center text-[12px] font-bold tabular-nums shrink-0 ${i < 3 ? "bg-[#0052D9]/8 text-[#0052D9]" : "bg-slate-100 text-slate-400"}`}>{i + 1}</span>
                        <span className={`px-1 py-0.5 rounded text-[9px] leading-none border shrink-0 ${levelColors[c.level]}`} title={`层级：${c.level}`}>{c.level}</span>
                        <CaseProductPill caseItem={c} compact />
                        <CaseMarkCodePill caseItem={c} compact />
                        <span className="flex-1 min-w-0 text-[13px] text-slate-700 truncate">{c.name}</span>
                        <span className="text-[11px] text-slate-400 shrink-0">{c.owner}</span>
                        {rankTab === "attention" ? (
                          <span className="text-[11px] font-medium text-slate-500 tabular-nums shrink-0 w-14 text-right inline-flex items-center gap-1 justify-end">
                            <Users size={11} className="text-slate-400" /> {attentionScore(c)} 关注
                          </span>
                        ) : (
                          <>
                            <ProgressRing value={m.prog} size={18} stroke={2.5} />
                            <span className="text-[11px] font-medium text-slate-500 tabular-nums shrink-0 w-16 text-right inline-flex items-center gap-1 justify-end">
                              <Eye size={11} className="text-slate-400" /> {viewsOf(c)} 次
                            </span>
                          </>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ============ LIST VIEW: KPI + filters + full list ============ */}
        {view === "list" && (
          <>
            {/* Filters · 方案3「搜索主导 + 筛选弹层」：主行只露 搜索 / 筛选 / 排序，筛选维度收进弹层 */}
            <div className="bg-white border border-slate-200/80 rounded-xl px-3.5 py-3 shadow-[0_1px_2px_0_rgba(15,23,42,0.04)]">
              <div className="flex items-center gap-2 flex-wrap">
                {/* 搜索：Case 名称 / 编码 / 相关人员（牵头人、参与人、任务负责人） */}
                <div className="relative w-[320px] max-w-full">
                  <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    value={q}
                    onChange={(e) => setQ(e.target.value)}
                    placeholder="搜索Case"
                    className="w-full h-9 pl-9 pr-8 rounded-lg border border-slate-200 bg-white text-sm text-slate-700 placeholder:text-slate-400 outline-none focus:border-[#0052D9] focus:ring-2 focus:ring-[#0052D9]/10 transition-all"
                  />
                  {q && (
                    <button
                      onClick={() => setQ("")}
                      title="清空搜索"
                      className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                    >
                      <X size={13} />
                    </button>
                  )}
                </div>
                {/* 筛选弹层（紧贴搜索栏右侧） */}
                <Popover open={filterOpen} onOpenChange={setFilterOpen}>
                  <PopoverTrigger asChild>
                  <button
                    type="button"
                    aria-label={activeFilterCount ? `筛选 ${activeFilterCount}` : "筛选"}
                    className={`h-9 px-3 rounded-lg border text-sm inline-flex items-center gap-1.5 transition-colors ${
                      filterOpen || activeFilterCount > 0
                        ? "border-[#0052D9]/40 bg-[#0052D9]/5 text-[#0052D9]"
                        : "border-slate-200 bg-white text-slate-600 hover:border-slate-300"
                    }`}
                  >
                    <Filter size={13} /> 筛选
                    {activeFilterCount > 0 && (
                      <span className="inline-flex items-center justify-center min-w-[16px] h-4 px-1 rounded-full bg-[#0052D9] text-white text-[10px] tabular-nums">
                        {activeFilterCount}
                      </span>
                    )}
                    <ChevronDown size={13} className={`transition-transform ${filterOpen ? "rotate-180" : ""}`} />
                  </button>
                  </PopoverTrigger>
                  <PopoverContent align="start" sideOffset={8} aria-label="分析中心 Case 筛选" className={CASE_FILTER_PANEL_CLASS_NAME}>
                    <CaseFilterPanel
                      values={{ level, urgency, status, product, department: deptFilter, creator: creatorFilter }} products={productOpts} departments={deptOpts} creators={creatorOpts}
                      onChange={(field, value) => ({ level: setLevel, urgency: setUrgency, status: setStatus, product: setProduct, department: setDeptFilter, creator: setCreator })[field](value)}
                      customEditor={{ fields: customFields, rules: customRules, optionsFor: field => customFilterOptions(customRecords, field), onChange: setCustomRules }}
                      onReset={resetFilters} onDone={() => setFilterOpen(false)}
                      scopeContent={
                        <section aria-label="Case 筛选范围">
                        {/* 范围 */}
                        <div className="text-[11px] text-slate-400 mb-2">范围</div>
                        <div className="flex items-center gap-2 flex-wrap mb-3.5">
                          {([
                            { k: "all", lab: "全部", I: LayoutGrid },
                            { k: "mine", lab: "我作为 Case Owner", I: User },
                            { k: "related", lab: "与我相关", I: Users },
                            { k: "fanout", lab: "Fanout我", I: Share2 },
                            { k: "complaint", lab: "客诉Case", I: MessageSquareWarning },
                          ] as const).map(({ k, lab, I }) => (
                            <button
                              key={k}
                              aria-pressed={scope === k}
                              onClick={() => { setScope(k); if (k === "fanout") setShowFanout(true); }}
                              className={`h-8 px-3 rounded-lg text-xs border inline-flex items-center gap-1.5 transition-colors ${
                                scope === k ? "border-[#0052D9]/40 bg-[#0052D9]/5 text-[#0052D9]" : "border-slate-200 text-slate-600 hover:border-slate-300"
                              }`}
                            >
                              <I size={12} /> {lab}
                            </button>
                          ))}
                        </div>
                        </section>
                      }
                      displaySettings={
                        <section aria-label="Case 显示设置" className="mt-3 border-t border-slate-100 pt-3">
                          <p className="mb-2 text-[11px] text-slate-400">显示设置</p>
                          <div className="flex items-center justify-between gap-3">
                            <p className="text-xs text-slate-700">查看 Fanout</p>
                            <button type="button" role="switch" aria-label="查看 Fanout" aria-checked={showFanout} onClick={() => { setShowFanout(!showFanout); if (showFanout && scope === "fanout") setScope("all"); }} className={`inline-flex h-5 w-9 shrink-0 items-center rounded-full p-0.5 transition-colors focus-visible:outline-2 focus-visible:outline-[#0052D9]/40 ${showFanout ? "bg-[#0052D9]" : "bg-slate-300"}`}><span aria-hidden="true" className={`h-4 w-4 rounded-full bg-white shadow-sm transition-transform ${showFanout ? "translate-x-4" : "translate-x-0"}`} /></button>
                          </div>
                        </section>
                      }
                    />
                  </PopoverContent>
                </Popover>

                {/* 排序 + 计数 靠右 */}
                <div className="ml-auto flex items-center gap-2">
                  <WorkbenchSort ariaLabel="分析中心 Case 排序" value={sort} options={sortOpts.map(option => ({ value: option.key, label: option.label }))} onChange={setSort} />
                  <span className="text-xs text-slate-500 tabular-nums">共 <b className="text-slate-800">{filtered.length}</b>/{mockCases.length}</span>
                </div>
              </div>

              {activeGroupTitle && (
                <div className="flex items-center gap-2 pt-3 mt-3 border-t border-dashed border-slate-100">
                  <span className="text-xs text-slate-400">分组：</span>
                  <span className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs bg-[#0052D9]/8 text-[#0052D9] border border-[#0052D9]/25">
                    {activeGroupTitle}
                    <button onClick={() => setActiveGroup(null)} className="hover:text-[#003FA8]">
                      <X size={11} />
                    </button>
                  </span>
                </div>
              )}
            </div>

            {/* Case cards */}
            <div className="space-y-3">
              {filtered.map(({ c, m }) => {
                const isOpen = expanded.has(c.id);
                const tasks = flattenTasks(c.tasks);
                const subscribed = subs.isSubscribed(c.id);

                return (
                  <div
                    key={c.id}
                    className="bg-white border border-slate-200/80 rounded-xl overflow-hidden shadow-[0_1px_2px_0_rgba(15,23,42,0.04)] transition-shadow hover:shadow-md"
                  >
                    <div className="flex">
                      {/* 方案 A：每行统一左色条 = 紧急度 */}
                      <div className={`w-1 shrink-0 ${urgencyBar[c.urgency]}`} title={`紧急度：${c.urgency}`} />
                      <div className="flex-1 min-w-0">
                        <div className="w-full px-5 pt-3.5 pb-2.5 flex items-center gap-2.5">
                          <button
                            onClick={() => toggle(c.id)}
                            className="w-6 h-6 rounded flex items-center justify-center text-slate-500 hover:text-[#0052D9] hover:bg-[#0052D9]/5 transition-all shrink-0"
                          >
                            <ChevronDown
                              size={14}
                              className={`transition-transform ${isOpen ? "rotate-0" : "-rotate-90"}`}
                            />
                          </button>
                          <FolderOpen size={15} className="text-[#0052D9] shrink-0" />
                          <span className={`px-1.5 py-0.5 rounded text-[10px] border ${levelColors[c.level]} shrink-0`}>
                            {c.level}
                          </span>
                          <CaseProductPill caseItem={c} compact />
                          <CaseMarkCodePill caseItem={c} compact />
                          <span className="text-[11px] text-slate-400 font-mono tracking-wide shrink-0">
                            {c.code}
                          </span>
                          <button
                            onClick={() => onOpenCase(c.id)}
                            className="text-sm text-slate-800 flex-1 truncate text-left hover:text-[#0052D9] transition-colors"
                          >
                            {c.name}
                          </button>
                          <CaseStatusBadge status={m.estatus} />
                          <RecoveryBadge record={closures.get(c.id) ?? {}} />
                          {c.childCaseIds?.length ? (
                            <span title={`已按颗粒拆分为 ${c.childCaseIds.length} 个子 Case`} className="shrink-0 inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] bg-[#0052D9]/8 text-[#0052D9] border border-[#0052D9]/20">
                              <Layers size={10} /> 母案 · {c.childCaseIds.length} 子
                            </span>
                          ) : null}
                          {c.parentCaseId ? (
                            <span title="由 DIMM 母案按颗粒拆分而来" className="shrink-0 inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] bg-[#00A4FF]/10 text-[#0284c7] border border-[#00A4FF]/20">
                              <Package size={10} /> 子案
                            </span>
                          ) : null}
                          {(!!c.fanoutSourceCaseId || c.source === "fanout验证") ? (
                            <span title="由其它 Case 结案 Fanout 派生，已共享问题与解决方案" className="shrink-0 inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] bg-[#00A4FF]/10 text-[#0284c7] border border-[#00A4FF]/25">
                              <Share2 size={10} /> Fanout
                            </span>
                          ) : null}

                          <button
                            onClick={() => subs.toggle(c.id)}
                            title={subscribed ? "已订阅 · 点击取消" : "订阅此 Case"}
                            className={`h-7 w-7 rounded-md border flex items-center justify-center shrink-0 transition-all ${
                              subscribed
                                ? "bg-[#0052D9]/8 border-[#0052D9]/30 text-[#0052D9]"
                                : "border-slate-200 text-slate-400 hover:border-slate-300 hover:text-slate-600"
                            }`}
                          >
                            {subscribed ? <Bookmark size={12} fill="currentColor" /> : <Bookmark size={12} />}
                          </button>
                        </div>

                        <div className="px-5 pb-3.5 pl-[52px] flex items-center gap-x-5 gap-y-2 flex-wrap text-[11px] text-slate-500">
                          <span className="inline-flex items-center gap-1">
                            <Crown size={11} className="text-slate-400" />
                            {c.owner}
                            <CaseCoreParticipants record={c} />
                          </span>
                          <span className="inline-flex items-center gap-1">
                            <Building2 size={11} className="text-slate-400" />
                            {c.departments.length} 部门协作
                          </span>
                          <span className="inline-flex items-center gap-1.5">
                            <ListChecks size={11} className="text-slate-400" />
                            <b className="text-slate-700 tabular-nums">{m.taskTotal}</b> 任务
                            {m.inProgress > 0 && (
                              <span className="inline-flex items-center gap-0.5 text-blue-600">
                                <CircleDot size={9} /> {m.inProgress}
                              </span>
                            )}
                            {m.blocked > 0 && (
                              <span className="inline-flex items-center gap-0.5 text-slate-500">
                                <Ban size={9} /> 已中止{m.blocked}
                              </span>
                            )}
                            {m.pending > 0 && (
                              <span className="inline-flex items-center gap-0.5 text-slate-500">
                                <Clock4 size={9} /> 待接受{m.pending}
                              </span>
                            )}
                          </span>
                          <span className="inline-flex items-center gap-1 text-slate-400">
                            <History size={11} />
                            更新 {c.updatedAt}
                          </span>

                          <div className="ml-auto flex items-center gap-4">
                            <CaseScore record={c} closure={closures.get(c.id)} compact />
                            <div className="flex items-center gap-1.5">
                              <ProgressRing value={m.prog} size={16} stroke={2.5} />
                              <span className="text-slate-600 tabular-nums w-9 text-right">{m.prog}%</span>
                            </div>
                            <span
                              className={`inline-flex items-center gap-1 px-2 py-1 rounded-md tracking-tight shrink-0 ${duePill(c.dueIn, m.closed)}`}
                            >
                              {m.risk && !m.closed && <AlertTriangle size={10} />}
                              <CalendarClock size={10} />
                              {dueText(c.dueIn, m.closed)}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {isOpen && (
                      <div className="divide-y divide-slate-100/70 border-t border-slate-100">
                        {tasks.map(({ task, depth, path }) => {
                          const overdue = (task.dueIn ?? 99) <= 1;
                          const urgent = task.urgency === "非常紧急";
                          const showStatus = task.status !== "待接受" && task.status !== "已中止";
                          const mine = task.owner === currentUser.name;
                          return (
                            <div
                              key={task.id}
                              title={`紧急度：${task.urgency}`}
                              className="group relative pl-6 pr-5 py-2.5 flex items-center gap-3 hover:bg-slate-50/60 transition-colors"
                            >
                              {/* 左侧紧急度色条（统一 urgencyBar 配色） */}
                              <div className={`absolute left-0 top-1.5 bottom-1.5 w-[3px] rounded-r ${urgencyBar[task.urgency]}`} />
                              {/* 状态：仅「待接受 / 进行中」展示徽章（方案 B；其余状态不展示，避免冗余） */}
                              <div className="w-20 shrink-0">
                                {(task.status === "待接受" || task.status === "进行中") && (
                                  <span className="inline-flex items-center gap-1.5 text-[11px] text-slate-500">
                                    <StatusBadge status={task.status} size={16} /> {task.status}
                                  </span>
                                )}
                              </div>
                              {/* 标题 + 来源面包屑 */}
                              <div className="flex-1 min-w-0">
                                <div className="text-sm text-slate-800 truncate">
                                  {depth > 0 && <span className="text-slate-300 mr-1">└</span>}
                                  {task.title}
                                </div>
                                {depth > 0 && path.length > 0 && (
                                  <div className="text-[11px] text-slate-400 truncate">{path[path.length - 1]}</div>
                                )}
                              </div>
                              {/* 负责人：头像 + 部门·姓名 */}
                              <div className="flex items-center gap-1.5 w-40 shrink-0 text-xs text-slate-600">
                                <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-medium shrink-0 ${
                                  task.owner === "待指派" ? "bg-slate-100 text-slate-400" : "bg-[#0052D9]/8 text-[#0052D9]"
                                }`}>
                                  {task.owner === "待指派" ? "—" : task.owner[0]}
                                </span>
                                <span className="truncate">{task.department} · {task.owner}</span>
                                {mine && <span className="shrink-0 text-[10px] text-slate-400 border border-slate-200 rounded px-1">我</span>}
                              </div>
                              {/* 到期：右对齐、等宽，仅临期上色 */}
                              <span
                                className={`w-16 text-right text-xs tabular-nums shrink-0 ${
                                  overdue ? "text-red-600" : (task.dueIn ?? 99) <= 3 ? "text-amber-600" : "text-slate-400"
                                }`}
                              >
                                {(task.dueIn ?? 99) === 0 ? "今日" : task.dueIn == null ? "—" : `${task.dueIn} 天`}
                              </span>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })}

              {filtered.length === 0 && (
                <div className="py-16 text-center bg-white border border-dashed border-slate-200 rounded-xl">
                  <div className="text-sm text-slate-600">没有匹配的 Case</div>
                  <div className="text-xs text-slate-400 mt-1">尝试调整筛选条件或返回聚焦视图</div>
                </div>
              )}
            </div>
          </>
        )}

        {/* ============ 产品分类：全生命周期时间轴 ============ */}
        {view === "product" && (
          <CategoryTimeline
            onOpenCase={onOpenCase}
            tree={productTree}
            stages={PRODUCT_STAGES}
            dimLabel="产品"
            title="产品全生命周期"
          />
        )}

        {/* ============ 平台分类：全生命周期时间轴 ============ */}
        {view === "platform" && (
          <CategoryTimeline
            onOpenCase={onOpenCase}
            tree={platformTree}
            stages={PLATFORM_STAGES}
            dimLabel="平台"
            title="平台全生命周期"
          />
        )}
      </div>

      {modalOpen && (
        <CustomCardModal
          productOpts={productOpts}
          onClose={() => setModalOpen(false)}
          onCreate={(cc) => {
            setCustomCards((list) => [...list, cc]);
            setModalOpen(false);
            setView("focus");
          }}
        />
      )}
    </div>
  );
}

// ---- Smart group card (built-in + custom) ----
function GroupCard({
  title,
  subtitle,
  Icon,
  tone,
  list,
  onViewAll,
  onOpen,
  onDelete,
}: {
  title: string;
  subtitle: string;
  Icon: any;
  tone: string;
  list: Row[];
  onViewAll: () => void;
  onOpen: (id: string) => void;
  onDelete?: () => void;
}) {
  const shown = list.slice(0, 3);
  return (
    <div className="bg-white border border-slate-200/80 rounded-xl shadow-[0_1px_2px_0_rgba(15,23,42,0.04)] flex flex-col overflow-hidden group/card">
      <div className="px-4 py-3 flex items-center gap-2.5 border-b border-slate-100">
        <span className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${tone}`}>
          <Icon size={16} />
        </span>
        <div className="min-w-0">
          <div className="text-sm text-slate-800 flex items-center gap-1.5">
            <span className="truncate">{title}</span>
            <span className="px-1.5 rounded-full text-[10px] bg-slate-100 text-slate-500 tabular-nums shrink-0">
              {list.length}
            </span>
          </div>
          <div className="text-[11px] text-slate-400 truncate">{subtitle}</div>
        </div>
        <div className="ml-auto shrink-0 flex items-center gap-1">
          {onDelete && (
            <button
              onClick={onDelete}
              title="删除卡片"
              className="w-6 h-6 rounded flex items-center justify-center text-slate-300 hover:text-red-500 hover:bg-red-50 opacity-0 group-hover/card:opacity-100 transition-all"
            >
              <Trash2 size={13} />
            </button>
          )}
          {list.length > 0 && (
            <button
              onClick={onViewAll}
              className="text-xs text-[#0052D9] hover:underline inline-flex items-center gap-0.5"
            >
              查看全部 <ChevronRight size={12} />
            </button>
          )}
        </div>
      </div>
      <div className="p-2 flex-1">
        {shown.length === 0 ? (
          <div className="h-[120px] flex items-center justify-center text-xs text-slate-300">暂无 Case</div>
        ) : (
          <div className="space-y-0.5">
            {shown.map(({ c, m }) => (
              <MiniCase key={c.id} c={c} m={m} onOpen={onOpen} />
            ))}
            {list.length > 3 && (
              <button
                onClick={onViewAll}
                className="w-full text-center py-1.5 text-[11px] text-slate-400 hover:text-[#0052D9]"
              >
                还有 {list.length - 3} 个 →
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

// Compact case row used inside group cards
function MiniCase({ c, m, onOpen }: { c: any; m: any; onOpen: (id: string) => void }) {
  return (
    <div
      onClick={() => onOpen(c.id)}
      className="relative group/mini cursor-pointer w-full text-left px-2.5 py-2 rounded-lg hover:bg-slate-50 flex items-center gap-2 transition-colors"
    >
      <span className={`px-1.5 py-0.5 rounded text-[10px] border shrink-0 ${levelColors[c.level]}`}>
        {c.level}
      </span>
      <CaseProductPill caseItem={c} compact />
      <CaseMarkCodePill caseItem={c} compact />
      <div className="flex-1 min-w-0">
        <div className="text-[13px] text-slate-800 truncate group-hover/mini:text-[#0052D9]">{c.name}</div>
        <div className="text-[11px] text-slate-400 flex items-center gap-2 mt-0.5">
          <span className="inline-flex items-center gap-0.5">
            <Crown size={9} className="text-amber-400" />
            {c.owner}
          </span>
          <span className="tabular-nums">{m.prog}%</span>
          {m.isOwner ? (
            <span className="text-amber-600">我作为 Case Owner</span>
          ) : m.myTasks > 0 ? (
            <span className="text-[#0052D9]">我负责 {m.myTasks}</span>
          ) : null}
        </div>
      </div>
      <span className={`shrink-0 text-[10px] px-1.5 py-0.5 rounded ${duePill(c.dueIn, m.closed)}`}>
        {m.closed ? "已结案" : c.dueIn <= 0 ? "今日" : `${c.dueIn}d`}
      </span>
    </div>
  );
}

// ---- Custom card creation modal ----
function CustomCardModal({
  productOpts,
  onClose,
  onCreate,
}: {
  productOpts: string[];
  onClose: () => void;
  onCreate: (cc: CustomCard) => void;
}) {
  const [name, setName] = useState("");
  const [level, setLevel] = useState("全部");
  const [urgency, setUrgency] = useState("全部");
  const [status, setStatus] = useState("全部");
  const [product, setProduct] = useState("全部");
  const [scope, setScope] = useState<"all" | "mine" | "related" | "fanout">("all");
  const [subscribed, setSubscribed] = useState(false);

  const submit = () => {
    const trimmed = name.trim();
    if (!trimmed) return;
    onCreate({
      id: `cc${Date.now()}`,
      name: trimmed,
      level, urgency, status, product, scope, subscribed,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4" onClick={onClose}>
      <div
        className="w-[480px] max-w-full bg-white rounded-xl shadow-2xl border border-slate-200 flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="px-5 py-3.5 border-b border-slate-100 flex items-center gap-2">
          <span className="w-7 h-7 rounded-lg bg-[#0052D9]/8 text-[#0052D9] flex items-center justify-center">
            <Filter size={14} />
          </span>
          <h3 className="text-slate-900 text-sm font-medium">新建自定义卡片</h3>
          <button onClick={onClose} className="ml-auto text-slate-400 hover:text-slate-600">
            <X size={16} />
          </button>
        </div>

        <div className="p-5 space-y-4">
          <div>
            <label className="text-xs text-slate-500 block mb-1.5">卡片名称</label>
            <input
              autoFocus
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="如：我的 L0/L1 紧急 Case"
              className="w-full h-9 px-3 text-sm rounded-md border border-slate-200 outline-none focus:border-[#0052D9]"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <ModalSelect label="层级" value={level} onChange={setLevel} options={[...levelOpts]} />
            <ModalSelect label="紧急程度" value={urgency} onChange={setUrgency} options={[...urgencyOpts]} />
            <ModalSelect label="状态" value={status} onChange={setStatus} options={[...statusOpts]} />
            <ModalSelect label="产品" value={product} onChange={setProduct} options={productOpts} />
            <ModalSelect
              label="范围"
              value={scope}
              onChange={(v) => setScope(v as any)}
              options={scopeOpts.map((s) => s.key)}
              display={(v) => scopeOpts.find((s) => s.key === v)?.label || v}
            />
            <div className="flex flex-col justify-end pb-1">
              <label className="flex items-center gap-2 text-sm text-slate-600 cursor-pointer h-9">
                <input
                  type="checkbox"
                  checked={subscribed}
                  onChange={(e) => setSubscribed(e.target.checked)}
                  className="w-4 h-4 rounded border-slate-300 accent-[#0052D9]"
                />
                仅看已订阅
              </label>
            </div>
          </div>
        </div>

        <div className="px-5 py-3.5 border-t border-slate-100 flex items-center justify-end gap-2">
          <button
            onClick={onClose}
            className="h-8 px-3.5 text-sm rounded-md border border-slate-200 text-slate-600 hover:bg-slate-50"
          >
            取消
          </button>
          <button
            onClick={submit}
            disabled={!name.trim()}
            className="h-8 px-4 text-sm rounded-md bg-[#0052D9] text-white hover:bg-[#003FA8] disabled:opacity-40 inline-flex items-center gap-1.5"
          >
            <Plus size={14} /> 创建卡片
          </button>
        </div>
      </div>
    </div>
  );
}

function ModalSelect({
  label,
  value,
  onChange,
  options,
  display,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  options: string[];
  display?: (v: string) => string;
}) {
  return (
    <div>
      <label className="text-xs text-slate-500 block mb-1.5">{label}</label>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full h-9 pl-2.5 pr-7 rounded-md border border-slate-200 bg-white text-sm text-slate-700 outline-none focus:border-[#0052D9] appearance-none cursor-pointer"
        style={{ backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%2394a3b8' stroke-width='2'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E\")", backgroundRepeat: "no-repeat", backgroundPosition: "right 8px center" }}
      >
        {options.map((o) => (
          <option key={o} value={o}>
            {display ? display(o) : o}
          </option>
        ))}
      </select>
    </div>
  );
}

// Due-date pill helpers (case level)
function dueText(dueIn: number, closed: boolean) {
  if (closed) return "已结案";
  if (dueIn <= 0) return "今日到期";
  return `${dueIn} 天到期`;
}
function duePill(dueIn: number, closed: boolean) {
  if (closed) return "bg-slate-50 text-slate-400 border border-slate-200";
  if (dueIn <= 1) return "bg-red-50 text-red-600 border border-red-200";
  if (dueIn <= 3) return "bg-amber-50 text-amber-600 border border-amber-200";
  return "bg-slate-50 text-slate-600 border border-slate-200";
}

function statusPillColor(status: string) {
  switch (status) {
    case "进行中":
      return "bg-blue-50 text-blue-700 border-blue-200";
    case "暂存":
      return "bg-slate-100 text-slate-600 border-slate-200";
    case "已结案":
      return "bg-emerald-50 text-emerald-700 border-emerald-200";
    default:
      return "bg-slate-50 text-slate-600 border-slate-200";
  }
}

const CHEVRON = {
  backgroundImage:
    "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%2394a3b8' stroke-width='2'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E\")",
  backgroundRepeat: "no-repeat",
  backgroundPosition: "right 6px center",
} as const;

// 统一的“标签 + 下拉”筛选控件，命中（非全部）时高亮
function Sel({
  label, value, options, onChange, display, icon, alwaysActive,
}: { label: string; value: string; options: string[]; onChange: (v: string) => void; display?: (v: string) => string; icon?: React.ReactNode; alwaysActive?: boolean }) {
  const hi = !alwaysActive && value !== "全部";
  return (
    <div
      className={`inline-flex items-center gap-1 h-8 pl-2.5 pr-0.5 rounded-lg border text-xs transition-colors ${
        hi ? "border-[#0052D9]/40 bg-[#0052D9]/5" : "border-slate-200 bg-white"
      }`}
    >
      {icon && <span className={hi ? "text-[#0052D9]" : "text-slate-400"}>{icon}</span>}
      <span className={hi ? "text-[#0052D9]/70" : "text-slate-400"}>{label}</span>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className={`h-7 pl-1 pr-5 bg-transparent outline-none appearance-none cursor-pointer text-xs max-w-[130px] ${hi ? "text-[#0052D9] font-medium" : "text-slate-700"}`}
        style={CHEVRON}
      >
        {options.map((o) => <option key={o} value={o} className="text-slate-700 font-normal">{display ? display(o) : o}</option>)}
      </select>
    </div>
  );
}

function FilterGroup({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: string;
  options: string[];
  onChange: (v: string) => void;
}) {
  return (
    <div className="flex items-center gap-1">
      <span className="text-xs text-slate-500 mr-0.5">{label}:</span>
      {options.map((o) => {
        const active = value === o;
        return (
          <button
            key={o}
            onClick={() => onChange(o)}
            className={`h-7 px-2.5 rounded-md text-xs border transition-all ${
              active
                ? "bg-[#0052D9]/8 text-[#0052D9] border-[#0052D9]/40"
                : "bg-white border-slate-200 text-slate-600 hover:border-slate-300"
            }`}
          >
            {o}
          </button>
        );
      })}
    </div>
  );
}
