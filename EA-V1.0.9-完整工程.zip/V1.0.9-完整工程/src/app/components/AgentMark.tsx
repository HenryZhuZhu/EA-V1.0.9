import { AGENT_GIF, AGENT_POSTER } from "./agentGif";

// 抽象环境光球体：仅视觉层，不表达录音、联网或 AI 正在执行等业务状态。
export function AgentMark({ className = "" }: { className?: string }) {
  return <span className={`ea-agent-orb ${className}`} aria-hidden="true">
    <picture className="block h-full w-full"><source media="(prefers-reduced-motion: reduce)" srcSet={AGENT_POSTER} /><img src={AGENT_GIF} alt="" width={112} height={112} draggable={false} className="block h-full w-full object-contain" /></picture>
  </span>;
}