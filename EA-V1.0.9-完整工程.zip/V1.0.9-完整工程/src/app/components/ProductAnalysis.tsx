import { useMemo, useState } from "react";
import { ArrowDownUp, ArrowLeft, Building2, ChevronRight, Copy, ExternalLink, Layers, Package, Search, Users } from "lucide-react";
import {
  CaseItem, caseProductId, flattenTasks, levelColors, mockCases, mockProducts,
  ownerToDepartment, urgencyColors,
} from "./data";
import { caseSimilarity } from "./caseInsights";
import { useClosures } from "./closures";
import { ProductCycleAnalysis } from "./ProductCycleAnalysis";

interface Props { onOpenCase: (id: string) => void }
interface SimilarPair { left: CaseItem; right: CaseItem; score: number }
interface SimilarGroup { id: string; cases: CaseItem[]; pairs: SimilarPair[]; score: number }
interface ProductStats {
  id: string; code: string; name: string; owner: string; cases: CaseItem[];
  departments: [string, number][]; similarGroups: SimilarGroup[]; duplicateGroups: SimilarGroup[];
  similarCaseIds: Set<string>; duplicateCaseIds: Set<string>;
}

const departmentOf = (item: CaseItem) =>
  ownerToDepartment[item.createdBy || ""] || ownerToDepartment[item.owner] || item.departments?.[0] || "未归属";

const progressOf = (item: CaseItem) => {
  const actions = flattenTasks(item.tasks).map(({ task }) => task).filter((task) => task.code);
  const base = actions.length ? actions : item.tasks;
  return Math.round(base.reduce((sum, task) => sum + (task.progress || 0), 0) / Math.max(base.length, 1));
};

const highRiskOf = (item: CaseItem, closed: boolean) => {
  const blocked = flattenTasks(item.tasks).some(({ task }) => task.status === "已中止");
  return !closed && (item.dueIn <= 1 || blocked || ((item.level === "L0" || item.level === "L1") && item.dueIn <= 3));
};

function groupPairs(pairs: SimilarPair[], prefix: string): SimilarGroup[] {
  const links = new Map<string, Set<string>>();
  const caseMap = new Map<string, CaseItem>();
  pairs.forEach((pair) => {
    caseMap.set(pair.left.id, pair.left); caseMap.set(pair.right.id, pair.right);
    if (!links.has(pair.left.id)) links.set(pair.left.id, new Set());
    if (!links.has(pair.right.id)) links.set(pair.right.id, new Set());
    links.get(pair.left.id)!.add(pair.right.id); links.get(pair.right.id)!.add(pair.left.id);
  });
  const visited = new Set<string>();
  const groups: SimilarGroup[] = [];
  links.forEach((_, startId) => {
    if (visited.has(startId)) return;
    const pending = [startId]; const caseIds: string[] = []; visited.add(startId);
    while (pending.length) {
      const currentId = pending.shift()!; caseIds.push(currentId);
      links.get(currentId)?.forEach((nextId) => {
        if (!visited.has(nextId)) { visited.add(nextId); pending.push(nextId); }
      });
    }
    const related = pairs.filter((pair) => caseIds.includes(pair.left.id) && caseIds.includes(pair.right.id));
    groups.push({
      id: `${prefix}-${groups.length + 1}`,
      cases: caseIds.map((id) => caseMap.get(id)!).filter(Boolean), pairs: related,
      score: Math.round(related.reduce((sum, pair) => sum + pair.score, 0) / Math.max(related.length, 1) * 100),
    });
  });
  return groups.sort((a, b) => b.score - a.score || b.cases.length - a.cases.length);
}

function buildProductStats(productId: string, cases: CaseItem[]): ProductStats {
  const product = mockProducts.find((item) => item.id === productId);
  const departments = new Map<string, number>();
  cases.forEach((item) => departments.set(departmentOf(item), (departments.get(departmentOf(item)) || 0) + 1));
  const similarPairs: SimilarPair[] = []; const duplicatePairs: SimilarPair[] = [];
  for (let leftIndex = 0; leftIndex < cases.length; leftIndex += 1) {
    for (let rightIndex = leftIndex + 1; rightIndex < cases.length; rightIndex += 1) {
      const score = caseSimilarity(cases[leftIndex], cases[rightIndex]);
      const pair = { left: cases[leftIndex], right: cases[rightIndex], score };
      if (score >= 0.7) duplicatePairs.push(pair); else if (score >= 0.45) similarPairs.push(pair);
    }
  }
  return {
    id: productId, code: product?.code || productId, name: product?.name || productId, owner: product?.owner || "—", cases,
    departments: [...departments.entries()].sort((a, b) => b[1] - a[1]),
    similarGroups: groupPairs(similarPairs, "similar"), duplicateGroups: groupPairs(duplicatePairs, "duplicate"),
    similarCaseIds: new Set(similarPairs.flatMap((pair) => [pair.left.id, pair.right.id])),
    duplicateCaseIds: new Set(duplicatePairs.flatMap((pair) => [pair.left.id, pair.right.id])),
  };
}

export function ProductAnalysis({ onOpenCase }: Props) {
  const closures = useClosures(); const [selectedId, setSelectedId] = useState<string>(); const [query, setQuery] = useState("");
  const [sort, setSort] = useState<"cases" | "risk" | "duplicate" | "health">("cases");
  const products = useMemo(() => {
    const grouped = new Map<string, CaseItem[]>();
    mockCases.forEach((item) => {
      const legacyProduct = item.product && item.product !== "—" ? item.product : undefined;
      const productId = caseProductId(item) || legacyProduct || "未归属产品";
      if (!grouped.has(productId)) grouped.set(productId, []); grouped.get(productId)!.push(item);
    });
    return [...grouped.entries()].map(([productId, cases]) => buildProductStats(productId, cases)).sort((a, b) => b.cases.length - a.cases.length);
  }, []);
  const selected = products.find((item) => item.id === selectedId);
  if (selected) return <ProductDetail stats={selected} isClosed={(id) => closures.isClosed(id)} closedAt={(id) => closures.get(id)?.closedAt} onBack={() => setSelectedId(undefined)} onOpenCase={onOpenCase} />;
  const healthOf = (stats: ProductStats) => {
    const active = stats.cases.filter((item) => !closures.isClosed(item.id)).length;
    const overdue = stats.cases.filter((item) => !closures.isClosed(item.id) && item.dueIn < 0).length;
    const highRisk = stats.cases.filter((item) => highRiskOf(item, closures.isClosed(item.id))).length;
    const nearDue = stats.cases.filter((item) => !closures.isClosed(item.id) && item.dueIn >= 0 && item.dueIn <= 3 && !highRiskOf(item, false)).length;
    const status = overdue > 0 || highRisk > 0 ? "需立即关注" : nearDue > 0 ? "持续观察" : "正常";
    return { active, overdue, highRisk, nearDue, status, rank: status === "需立即关注" ? 2 : status === "持续观察" ? 1 : 0 };
  };
  const filtered = products
    .filter((item) => `${item.code} ${item.name} ${item.owner}`.toLowerCase().includes(query.trim().toLowerCase()))
    .sort((left, right) => {
      if (sort === "risk") return healthOf(right).highRisk - healthOf(left).highRisk || healthOf(right).overdue - healthOf(left).overdue || right.cases.length - left.cases.length;
      if (sort === "duplicate") return right.duplicateCaseIds.size / Math.max(right.cases.length, 1) - left.duplicateCaseIds.size / Math.max(left.cases.length, 1) || right.cases.length - left.cases.length;
      if (sort === "health") return healthOf(right).rank - healthOf(left).rank || healthOf(right).highRisk - healthOf(left).highRisk || right.cases.length - left.cases.length;
      return right.cases.length - left.cases.length;
    });
  const totalCases = products.reduce((sum, item) => sum + item.cases.length, 0);
  const similarCases = new Set(products.flatMap((item) => [...item.similarCaseIds])).size;
  const duplicateCases = new Set(products.flatMap((item) => [...item.duplicateCaseIds])).size;
  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <SummaryMetric icon={Package} label="产品数" value={products.length} tone="text-[#0052D9] bg-[#0052D9]/8" />
        <SummaryMetric icon={Layers} label="Case 总数" value={totalCases} tone="text-sky-600 bg-sky-50" />
        <SummaryMetric icon={Users} label="相似 Case" value={similarCases} tone="text-amber-600 bg-amber-50" />
        <SummaryMetric icon={Copy} label="重复 Case" value={duplicateCases} tone="text-red-600 bg-red-50" />
      </div>
      <div className="flex items-center gap-3">
        <div className="relative w-full max-w-[360px]"><Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="搜索产品或负责人" className="w-full h-9 pl-9 pr-3 rounded-md border border-slate-200 bg-white text-sm outline-none focus:border-[#0052D9]" />
        </div><span className="ml-auto text-xs text-slate-400">相似度 45%–69% · 重复度 ≥ 70%</span>
      </div>
      <div className="flex items-center gap-2">
        <ArrowDownUp size={14} className="text-slate-400" />
        <span className="text-xs text-slate-400">排序</span>
        {([
          ["cases", "Case 规模"], ["risk", "风险"], ["duplicate", "重复率"], ["health", "健康状态"],
        ] as const).map(([key, label]) => (
          <button key={key} onClick={() => setSort(key)} className={`h-8 px-3 rounded-md border text-xs transition-colors ${sort === key ? "border-[#0052D9] bg-[#0052D9]/8 text-[#0052D9] font-medium" : "border-slate-200 bg-white text-slate-500 hover:border-[#0052D9]/30 hover:text-[#0052D9]"}`}>{label}</button>
        ))}
      </div>
      <div className="bg-white border border-slate-200 rounded-lg overflow-hidden">
        <div className="grid grid-cols-[36px_190px_1fr_104px_82px_82px_116px_28px] gap-4 items-center px-4 h-10 bg-slate-50 border-b border-slate-100 text-[10px] font-medium text-slate-400">
          <span>排名</span><span>产品 / 负责人</span><span>Case 规模</span><span>风险</span><span>相似</span><span>重复</span><span>健康状态</span><span></span>
        </div>
        <div className="divide-y divide-slate-100">
          {filtered.map((item, index) => <ProductComparisonRow key={item.id} stats={item} rank={index + 1} maxCases={Math.max(...products.map((product) => product.cases.length), 1)} health={healthOf(item)} onOpen={() => setSelectedId(item.id)} />)}
          {!filtered.length && <div className="py-12 text-center text-sm text-slate-400">没有匹配的产品</div>}
        </div>
      </div>
    </div>
  );
}

function ProductComparisonRow({ stats, rank, maxCases, health, onOpen }: {
  stats: ProductStats;
  rank: number;
  maxCases: number;
  health: { active: number; overdue: number; highRisk: number; nearDue: number; status: string; rank: number };
  onOpen: () => void;
}) {
  const duplicateRate = Math.round(stats.duplicateCaseIds.size / Math.max(stats.cases.length, 1) * 100);
  const healthTone = health.status === "需立即关注" ? "bg-red-50 text-red-600 border-red-200" : health.status === "持续观察" ? "bg-amber-50 text-amber-600 border-amber-200" : "bg-emerald-50 text-emerald-600 border-emerald-200";
  return (
    <button onClick={onOpen} className="w-full grid grid-cols-[36px_190px_1fr_104px_82px_82px_116px_28px] gap-4 items-center px-4 min-h-[70px] text-left hover:bg-slate-50/70 transition-colors group">
      <span className={`w-6 h-6 rounded-md grid place-items-center text-[11px] font-semibold ${rank <= 3 ? "bg-[#0052D9]/8 text-[#0052D9]" : "bg-slate-100 text-slate-400"}`}>{rank}</span>
      <span className="min-w-0">
        <span className="block text-[13px] font-semibold text-slate-800 truncate">{stats.code}</span>
        <span className="block text-[11px] text-slate-400 truncate mt-0.5">{stats.owner} · {stats.name}</span>
      </span>
      <span className="min-w-0 flex items-center gap-3">
        <span className="flex-1 h-6 rounded bg-slate-100 overflow-hidden relative">
          <span className="block h-full bg-[#0052D9]/45" style={{ width: `${stats.cases.length / maxCases * 100}%` }} />
          <span className="absolute inset-y-0 left-2 flex items-center text-[10px] font-semibold text-slate-700">{stats.cases.length} Case</span>
        </span>
        <span className="w-12 text-right text-[11px] text-slate-400">进行中 {health.active}</span>
      </span>
      <span className="text-[11px] text-slate-500">
        <span className={health.highRisk ? "font-semibold text-red-600" : ""}>{health.highRisk} 高风险</span>
        {health.overdue > 0 && <span className="block text-[10px] text-red-500 mt-0.5">{health.overdue} 已逾期</span>}
      </span>
      <span><b className="text-[14px] text-slate-800">{stats.similarCaseIds.size}</b><small className="block text-[10px] text-slate-400">Case</small></span>
      <span><b className="text-[14px] text-slate-800">{stats.duplicateCaseIds.size}</b><small className="block text-[10px] text-slate-400">{duplicateRate}%</small></span>
      <span className={`w-fit px-2 py-1 rounded border text-[10px] font-medium ${healthTone}`}>{health.status}</span>
      <ChevronRight size={16} className="text-slate-300 group-hover:text-[#0052D9]" />
    </button>
  );
}

function ProductDetail({ stats, isClosed, closedAt, onBack, onOpenCase }: { stats: ProductStats; isClosed: (id: string) => boolean; closedAt: (id: string) => string | undefined; onBack: () => void; onOpenCase: (id: string) => void }) {
  const statusOf = (item: CaseItem) => isClosed(item.id) ? "已结案" : "进行中";
  const active = stats.cases.filter((item) => !isClosed(item.id)).length; const closed = stats.cases.length - active;
  const overdue = stats.cases.filter((item) => !isClosed(item.id) && item.dueIn < 0).length;
  const highRisk = stats.cases.filter((item) => highRiskOf(item, isClosed(item.id))).length;
  const statusStats = [
    { label: "进行中", value: stats.cases.filter((item) => statusOf(item) === "进行中").length, color: "bg-[#0052D9]" },
    { label: "已结案", value: closed, color: "bg-emerald-500" },
  ];
  const levelStats = ["L0", "L1", "L2", "L3"].map((level) => ({ label: level, value: stats.cases.filter((item) => item.level === level).length, color: level === "L0" ? "bg-red-500" : level === "L1" ? "bg-orange-500" : level === "L2" ? "bg-sky-500" : "bg-slate-400" }));
  const urgencyStats = [
    { label: "非常紧急", value: stats.cases.filter((item) => item.urgency === "非常紧急").length, color: "bg-red-500" },
    { label: "紧急", value: stats.cases.filter((item) => item.urgency === "紧急").length, color: "bg-orange-500" },
    { label: "一般", value: stats.cases.filter((item) => item.urgency === "一般").length, color: "bg-sky-500" },
    { label: "不紧急", value: stats.cases.filter((item) => item.urgency === "不紧急").length, color: "bg-slate-400" },
  ];
  const riskOf = (item: CaseItem) => {
    if (isClosed(item.id)) return "正常";
    if (item.dueIn < 0) return "已逾期";
    if (highRiskOf(item, false)) return "高风险";
    if (item.dueIn <= 3) return "临期";
    return "正常";
  };
  const riskStats = [
    { label: "已逾期", value: stats.cases.filter((item) => riskOf(item) === "已逾期").length, color: "bg-red-600" },
    { label: "高风险", value: stats.cases.filter((item) => riskOf(item) === "高风险").length, color: "bg-orange-500" },
    { label: "临期", value: stats.cases.filter((item) => riskOf(item) === "临期").length, color: "bg-amber-400" },
    { label: "正常", value: stats.cases.filter((item) => riskOf(item) === "正常").length, color: "bg-emerald-500" },
  ];
  const progressStats = [
    { label: "未开始 0%", value: stats.cases.filter((item) => progressOf(item) === 0).length, color: "bg-slate-400" },
    { label: "起步 1–30%", value: stats.cases.filter((item) => progressOf(item) > 0 && progressOf(item) <= 30).length, color: "bg-sky-400" },
    { label: "推进中 31–70%", value: stats.cases.filter((item) => progressOf(item) > 30 && progressOf(item) <= 70).length, color: "bg-[#0052D9]" },
    { label: "待收敛 71–99%", value: stats.cases.filter((item) => progressOf(item) > 70 && progressOf(item) < 100).length, color: "bg-teal-500" },
    { label: "完成 100%", value: stats.cases.filter((item) => progressOf(item) >= 100).length, color: "bg-emerald-500" },
  ];
  const dateValues = stats.cases.flatMap((item) => [item.createdAt, closedAt(item.id)?.slice(0, 10)]).filter(Boolean) as string[];
  const anchor = dateValues.sort().slice(-1)[0] || new Date().toISOString().slice(0, 10);
  const anchorDate = new Date(`${anchor}T00:00:00`);
  const localDateText = (date: Date) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
  const trend = Array.from({ length: 6 }, (_, index) => {
    const end = new Date(anchorDate); end.setDate(end.getDate() - (5 - index) * 5);
    const start = new Date(end); start.setDate(start.getDate() - 4);
    const startText = localDateText(start); const endText = localDateText(end);
    return {
      label: `${start.getMonth() + 1}/${start.getDate()}`,
      created: stats.cases.filter((item) => { const date = item.createdAt.slice(0, 10); return date >= startText && date <= endText; }).length,
      closed: stats.cases.filter((item) => { const date = closedAt(item.id)?.slice(0, 10); return !!date && date >= startText && date <= endText; }).length,
    };
  });
  return (
    <div className="space-y-5">
      <button onClick={onBack} className="inline-flex items-center gap-1 text-sm text-slate-500 hover:text-[#0052D9]"><ArrowLeft size={14} /> 返回产品总览</button>
      <section className="bg-white border border-slate-200 rounded-lg p-5"><div className="flex items-center gap-3"><span className="w-10 h-10 rounded-md bg-[#0052D9]/8 text-[#0052D9] grid place-items-center"><Package size={20} /></span><div><h2 className="text-lg font-semibold text-slate-900">{stats.code}</h2><p className="text-xs text-slate-400">{stats.name} · 产品负责人 {stats.owner}</p></div></div>
        <div className="grid grid-cols-2 lg:grid-cols-6 gap-3 mt-5"><DetailMetric label="Case 总数" value={stats.cases.length} /><DetailMetric label="进行中" value={active} tone="text-[#0052D9]" /><DetailMetric label="已结案" value={closed} tone="text-emerald-600" /><DetailMetric label="逾期" value={overdue} tone="text-red-600" /><DetailMetric label="高风险" value={highRisk} tone="text-orange-600" /><DetailMetric label="相似 / 重复" value={`${stats.similarCaseIds.size} / ${stats.duplicateCaseIds.size}`} tone="text-amber-600" /></div>
      </section>
      <section className="bg-white border border-slate-200 rounded-lg overflow-hidden"><ModuleHeader index="01" title="整体统计" subtitle="状态、层级、紧急度、风险健康度、分析进度与趋势" icon={Layers} />
        <div className="grid grid-cols-1 lg:grid-cols-2 border-b border-slate-100"><Distribution title="Case 状态分布" items={statusStats} total={stats.cases.length} /><Distribution title="Case 层级分布" items={levelStats} total={stats.cases.length} bordered /></div>
        <div className="grid grid-cols-1 lg:grid-cols-2 border-b border-slate-100"><Distribution title="紧急度分布" items={urgencyStats} total={stats.cases.length} /><Distribution title="风险健康度" items={riskStats} total={stats.cases.length} bordered note="逾期：到期日已过；高风险：1 天内到期、L0/L1 且 3 天内到期，或存在已中止任务；临期：其余 3 天内到期。已结案统一计为正常。" /></div>
        <div className="grid grid-cols-1 lg:grid-cols-2 border-b border-slate-100"><Distribution title="分析进度分布" items={progressStats} total={stats.cases.length} /><TrendChart data={trend} anchor={anchor} /></div>
        <div className="px-4 py-3 text-xs font-medium text-slate-600 bg-slate-50/60">全部 Case</div><div className="divide-y divide-slate-100">{stats.cases.map((item) => <button key={item.id} onClick={() => onOpenCase(item.id)} className="w-full grid grid-cols-[130px_52px_1fr_72px_80px_20px] items-center gap-3 px-4 py-3 text-left hover:bg-slate-50"><span className="text-[11px] font-mono text-slate-500 truncate">{item.code}</span><span className={`w-fit px-1.5 py-0.5 rounded text-[9px] border ${levelColors[item.level]}`}>{item.level}</span><span className="text-[13px] text-slate-700 truncate">{item.name}</span><span className="text-[11px] text-slate-500">{statusOf(item)}</span><span className="text-[11px] text-slate-400 truncate">{departmentOf(item)}</span><ChevronRight size={14} className="text-slate-300" /></button>)}</div>
      </section>
      <section className="bg-white border border-slate-200 rounded-lg overflow-visible"><ModuleHeader index="02" title="Case 耗时与部门任务分析" subtitle="Case 平均耗时趋势、部门任务耗时占比，以及高耗时 Case 与成员联动" icon={Building2} /><ProductCycleAnalysis productCode={stats.code} cases={stats.cases} isClosed={isClosed} closedAt={closedAt} onOpenCase={onOpenCase} /></section>
      <section className="space-y-3"><div className="bg-white border border-slate-200 rounded-lg overflow-hidden"><ModuleHeader index="03" title="相似 / 重复 Case 检测" subtitle="相似度 45%–69% · 重复度 ≥ 70%，按关联关系自动成组" icon={Copy} /></div><GroupSection title="疑似重复 Case" tone="red" groups={stats.duplicateGroups} isClosed={isClosed} onOpenCase={onOpenCase} /><GroupSection title="相似 Case" tone="amber" groups={stats.similarGroups} isClosed={isClosed} onOpenCase={onOpenCase} /></section>
    </div>
  );
}

function GroupSection({ title, tone, groups, isClosed, onOpenCase }: { title: string; tone: "red" | "amber"; groups: SimilarGroup[]; isClosed: (id: string) => boolean; onOpenCase: (id: string) => void }) {
  const statusOf = (item: CaseItem) => isClosed(item.id) ? "已结案" : "进行中";
  return <div className="space-y-2.5"><div className="flex items-center gap-2 px-1"><span className={`w-2 h-2 rounded-full ${tone === "red" ? "bg-red-500" : "bg-amber-500"}`} /><h3 className="text-sm font-semibold text-slate-800">{title}</h3><span className="text-xs text-slate-400">{groups.length} 组</span></div>
    {groups.length ? groups.map((group, index) => <div key={group.id} className="bg-white border border-slate-200 rounded-lg overflow-hidden"><div className="flex items-center gap-3 px-4 py-3 border-b border-slate-100"><span className={`text-xs font-semibold ${tone === "red" ? "text-red-600" : "text-amber-600"}`}>{tone === "red" ? "重复" : "相似"}组 {String(index + 1).padStart(2, "0")}</span><span className="text-[11px] text-slate-400">{group.cases.length} 个 Case</span><span className={`ml-auto px-2 py-1 rounded text-[11px] font-semibold ${tone === "red" ? "bg-red-50 text-red-600" : "bg-amber-50 text-amber-600"}`}>组内平均 {group.score}%</span></div><div className="overflow-x-auto"><div className="min-w-[1160px]"><GroupHeader />
      <div className="divide-y divide-slate-100">{group.cases.map((item) => {
        const scores = group.pairs.filter((pair) => pair.left.id === item.id || pair.right.id === item.id).map((pair) => pair.score);
        const score = Math.round(Math.max(...scores, 0) * 100); const closed = isClosed(item.id); const highRisk = highRiskOf(item, closed);
        return <div key={item.id} className="grid grid-cols-[64px_140px_1fr_72px_86px_80px_90px_74px_74px_64px] items-center gap-3 px-4 py-3 hover:bg-slate-50"><span className={`text-[12px] font-semibold ${tone === "red" ? "text-red-600" : "text-amber-600"}`}>{score}%</span><span className="text-[11px] font-mono text-[#0052D9] truncate" title={item.code}>{item.code}</span><span className="text-[12px] text-slate-700 truncate" title={item.name}>{item.name}</span><span className="text-[11px] text-slate-500">{statusOf(item)}</span><span className="text-[11px] text-slate-500 truncate">{departmentOf(item)}</span><span className="text-[11px] text-slate-500 truncate">{item.owner}</span><span className={`w-fit px-1.5 py-0.5 rounded text-[10px] border ${urgencyColors[item.urgency]}`}>{item.urgency}</span><span className={`w-fit px-1.5 py-0.5 rounded text-[10px] border ${highRisk ? "bg-red-50 text-red-600 border-red-200" : "bg-emerald-50 text-emerald-600 border-emerald-200"}`}>{highRisk ? "高风险" : "正常"}</span><span className="text-[11px] text-slate-500">{progressOf(item)}%</span><button onClick={() => onOpenCase(item.id)} title="查看 Case" className="w-7 h-7 rounded-md border border-slate-200 text-[#0052D9] hover:bg-[#0052D9]/5 grid place-items-center"><ExternalLink size={13} /></button></div>;
      })}</div></div></div></div>) : <div className="bg-white border border-slate-200 rounded-lg py-8 text-center text-xs text-slate-400">暂无{title}</div>}
  </div>;
}

function GroupHeader() { return <div className="grid grid-cols-[64px_140px_1fr_72px_86px_80px_90px_74px_74px_64px] gap-3 px-4 py-2 bg-slate-50 text-[10px] text-slate-400"><span>判断分数</span><span>EA Case ID</span><span>Case Name</span><span>状态</span><span>提出部门</span><span>Case Owner</span><span>紧急度</span><span>风险</span><span>进度</span><span>操作</span></div>; }
function ModuleHeader({ index, title, subtitle, icon: Icon }: { index: string; title: string; subtitle: string; icon: typeof Layers }) { return <div className="flex items-center gap-3 px-5 py-4 border-b border-slate-100"><span className="w-8 h-8 rounded-md bg-[#0052D9]/8 text-[#0052D9] grid place-items-center"><Icon size={16} /></span><div><div className="flex items-center gap-2"><span className="text-[10px] font-semibold text-[#0052D9]">{index}</span><h3 className="text-sm font-semibold text-slate-800">{title}</h3></div><p className="text-[11px] text-slate-400 mt-0.5">{subtitle}</p></div></div>; }
function Distribution({ title, items, total, bordered = false, note }: { title: string; items: { label: string; value: number; color: string }[]; total: number; bordered?: boolean; note?: string }) { return <div className={`p-5 ${bordered ? "lg:border-l border-slate-100" : ""}`}><div className="text-xs font-medium text-slate-600 mb-4">{title}</div><div className="flex h-2.5 rounded-full overflow-hidden bg-slate-100">{items.map((item) => item.value > 0 && <span key={item.label} className={item.color} style={{ width: `${item.value / Math.max(total, 1) * 100}%` }} />)}</div><div className="flex flex-wrap gap-x-5 gap-y-2 mt-3">{items.map((item) => <span key={item.label} className="inline-flex items-center gap-1.5 text-[11px] text-slate-500"><span className={`w-2 h-2 rounded-full ${item.color}`} />{item.label}<b className="text-slate-700">{item.value}</b><span className="text-slate-300">{Math.round(item.value / Math.max(total, 1) * 100)}%</span></span>)}</div>{note && <p className="mt-3 pt-3 border-t border-slate-100 text-[10px] leading-4 text-slate-400">评估口径：{note}</p>}</div>; }
function TrendChart({ data, anchor }: { data: { label: string; created: number; closed: number }[]; anchor: string }) { const max = Math.max(...data.flatMap((item) => [item.created, item.closed]), 1); return <div className="p-5 lg:border-l border-slate-100"><div className="flex items-center"><span className="text-xs font-medium text-slate-600">近 30 天新增 / 结案趋势</span><span className="ml-auto text-[10px] text-slate-400">截至 {anchor}</span></div><div className="h-[112px] flex items-end gap-4 mt-4">{data.map((item) => <div key={item.label} className="flex-1 h-full flex flex-col justify-end"><div className="flex items-end justify-center gap-1 h-[82px]"><span title={`新增 ${item.created}`} className="w-2.5 rounded-t bg-[#0052D9] min-h-[2px]" style={{ height: `${Math.max(item.created / max * 100, 2)}%` }} /><span title={`结案 ${item.closed}`} className="w-2.5 rounded-t bg-emerald-500 min-h-[2px]" style={{ height: `${Math.max(item.closed / max * 100, 2)}%` }} /></div><span className="text-[9px] text-slate-400 text-center mt-1">{item.label}</span></div>)}</div><div className="flex items-center gap-4 mt-2 text-[10px] text-slate-400"><span className="inline-flex items-center gap-1"><i className="w-2 h-2 rounded-sm bg-[#0052D9]" />新增</span><span className="inline-flex items-center gap-1"><i className="w-2 h-2 rounded-sm bg-emerald-500" />结案</span><span className="ml-auto">窗口按产品最新业务日期计算</span></div></div>; }
function SummaryMetric({ icon: Icon, label, value, tone }: { icon: typeof Package; label: string; value: number; tone: string }) { return <div className="bg-white border border-slate-200 rounded-lg p-4 flex items-center gap-3"><span className={`w-9 h-9 rounded-md grid place-items-center ${tone}`}><Icon size={17} /></span><div><div className="text-2xl font-bold text-slate-900">{value}</div><div className="text-xs text-slate-400">{label}</div></div></div>; }
function MiniMetric({ label, value, accent = "text-slate-800" }: { label: string; value: number; accent?: string }) { return <span className="rounded-md bg-slate-50 px-2.5 py-2"><span className={`block text-lg font-bold ${accent}`}>{value}</span><span className="block text-[10px] text-slate-400">{label}</span></span>; }
function DetailMetric({ label, value, tone = "text-slate-900" }: { label: string; value: number | string; tone?: string }) { return <div className="rounded-md bg-slate-50 px-3 py-2.5"><div className={`text-xl font-bold ${tone}`}>{value}</div><div className="text-[11px] text-slate-400">{label}</div></div>; }