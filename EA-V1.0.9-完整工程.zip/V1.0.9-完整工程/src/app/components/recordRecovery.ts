import { currentUser, directors, managerDeptScope, ownerToDepartment, reportsTo } from "./data";

export type RecoveryFile = { name: string; kind: "pdf" | "image" | "sheet" | "file"; url?: string };
export interface RecoveryEntry {
  id: string;
  kind: "reopen" | "return" | "supplement";
  by: string;
  at: string;
  reason: string;
  files?: RecoveryFile[];
  before?: Record<string, unknown>;
  outcome?: string;
  outcomeBy?: string;
  outcomeAt?: string;
  completedAt?: string;
  dueDate?: string;
  startedAt?: string;
  lastEditedAt?: string;
  submittedAt?: string;
  submittedBy?: string;
  after?: Record<string, unknown>;
  recipients: string[];
  authorizedByCaseReturn?: { caseId: string; recoveryId: string };
}
export interface Recoverable { recovery?: RecoveryEntry[] }
export type RecoveryAction = "reopen" | "return" | "supplement";

export function canReopenRecord(owner: string, actor = currentUser.name) {
  const knownOwner = Boolean(ownerToDepartment[owner]) || directors.some(director => director.name === owner);
  return actor !== owner && knownOwner && reportsTo(owner) === actor;
}
export function validateRecoveryAction(owner: string, action: RecoveryAction) {
  if (!["reopen", "return", "supplement"].includes(action)) throw new Error("修改结果请保存到原文档，不再单独填写处理说明。");
  if (action === "reopen") {
    if (!canReopenRecord(owner)) throw new Error("请先与自己的主管线下沟通，由负责人直属主管点击重新处理。");
  } else if (action === "return" ? !canReturnRecord(owner) : owner !== currentUser.name) throw new Error("没有该记录的操作权限。");
}

export function recoveryText(value: string, label = "原因") {
  const text = value.trim();
  if (!text || text.length > 2000) throw new Error(`请填写${label}，最多 2000 字。`);
  return text;
}
export function canReturnRecord(owner: string, actor = currentUser.name) {
  return actor !== owner && Boolean(ownerToDepartment[owner]) &&
    (reportsTo(owner) === actor || managerDeptScope(actor).includes(ownerToDepartment[owner]));
}
export function activeRecovery(record: Recoverable) {
  return [...(record.recovery ?? [])].reverse().find(entry => entry.kind !== "supplement" && !entry.completedAt);
}
export function needsCorrection(record: Recoverable) { return activeRecovery(record)?.kind === "return"; }
export function recoverySnapshot(record: object) {
  const { recovery, ...snapshot } = record as Record<string, unknown>;
  return JSON.parse(JSON.stringify(snapshot)) as Record<string, unknown>;
}
export function recoveryDeadline(value?: string) {
  if (!value) return undefined;
  const date = new Date(`${value}T00:00:00Z`);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value) || !Number.isFinite(date.getTime()) || date.toISOString().slice(0, 10) !== value) throw new Error("请选择有效的期望反馈日期。");
  return value;
}
export function startRecovery<T extends Recoverable>(record: T, kind: "reopen" | "return", reason: string, recipients: string[], dueDate?: string): T {
  if (activeRecovery(record)) throw new Error("当前已有重新处理事项，请先完成处理。 ");
  const entry: RecoveryEntry = { id: crypto.randomUUID(), kind, by: currentUser.name, at: new Date().toISOString(), reason: recoveryText(reason, kind === "return" ? "整改要求" : "重新处理原因"), before: recoverySnapshot(record), recipients: [...new Set(recipients.filter(Boolean))], ...(kind === "return" ? { dueDate: recoveryDeadline(dueDate) } : {}) };
  return { ...record, recovery: [...(record.recovery ?? []), entry] };
}
export function supplementRecord<T extends Recoverable>(record: T, text: string, files: RecoveryFile[] = []): T {
  const entry: RecoveryEntry = { id: crypto.randomUUID(), kind: "supplement", by: currentUser.name, at: new Date().toISOString(), reason: recoveryText(text, "补充说明"), files: files.map(file => ({ ...file })), recipients: [] };
  return { ...record, recovery: [...(record.recovery ?? []), entry] };
}
const resultFields = ["conclusion", "analysisProcess", "attachments", "resultAttachments", "workspace", "caseEdits", "domain", "problemType", "followupNote", "files", "solutionPath"];
function resultContent(record: object) {
  const values = record as Record<string, unknown>;
  return resultFields.map(key => {
    if (key === "caseEdits" && values[key]) {
      const { updatedAt, ...fields } = values[key] as Record<string, unknown>;
      return fields;
    }
    return values[key] ?? null;
  });
}
export function trackRecoveryEdit<T extends Recoverable>(before: T, after: T): T {
  const active = activeRecovery(before);
  if (!active || JSON.stringify(resultContent(before)) === JSON.stringify(resultContent(after))) return after;
  const now = new Date().toISOString();
  return { ...after, recovery: (after.recovery ?? before.recovery)!.map(entry => entry.id === active.id ? { ...entry, startedAt: entry.startedAt ?? now, lastEditedAt: now } : entry) };
}
export function submitRecovery<T extends Recoverable>(record: T): T {
  const active = activeRecovery(record);
  if (!active) return record;
  return { ...record, recovery: record.recovery!.map(entry => entry.id === active.id ? { ...entry, submittedAt: new Date().toISOString(), submittedBy: currentUser.name, after: recoverySnapshot(record) } : entry) };
}
export function finishRecovery<T extends Recoverable>(record: T): T {
  const active = activeRecovery(record);
  if (!active) return record;
  const submitted = active.submittedAt && active.after && JSON.stringify(resultContent(active.after)) === JSON.stringify(resultContent(record)) ? record : submitRecovery(record);
  return { ...submitted, recovery: submitted.recovery!.map(entry => entry.id === active.id ? { ...entry, completedAt: new Date().toISOString() } : entry) };
}

export interface RecoveryDifference { field: string; before: string; after: string }
export function recoveryDifferences(entry: RecoveryEntry): RecoveryDifference[] {
  if (!entry.after) return [];
  const old = entry.before ?? {}, next = entry.after;
  const text = (value: unknown) => typeof value === "string" ? value : "";
  const workspace = (value: unknown) => (value && typeof value === "object" ? value : {}) as Record<string, unknown>;
  const from = workspace(old.workspace), to = workspace(next.workspace);
  const pairs: [string, unknown, unknown][] = [
    ["结论", old.conclusion, next.conclusion], ["任务分析过程", old.analysisProcess, next.analysisProcess],
    ["Case 文档结论", from.conclusion, to.conclusion], ["Case 文档过程", from.process, to.process],
    ["根因 Domain", old.domain, next.domain], ["问题类型", old.problemType, next.problemType], ["跟进内容", old.followupNote, next.followupNote],
  ];
  const changes = pairs.filter(([, before, after]) => text(before) !== text(after)).map(([field, before, after]) => ({ field, before: text(before) || "未填写", after: text(after) || "未填写" }));
  for (const key of ["attachments", "resultAttachments", "files", "workspace"] as const) {
    const before = (key === "workspace" ? from.attachments : old[key]) as RecoveryFile[] | undefined;
    const after = (key === "workspace" ? to.attachments : next[key]) as RecoveryFile[] | undefined;
    if (JSON.stringify(before ?? []) !== JSON.stringify(after ?? [])) changes.push({ field: key === "workspace" ? "Case 文档附件" : key === "resultAttachments" ? "结果附件" : key === "files" ? "结案附件" : "任务附件", before: (before ?? []).map(file => file.name).join("、") || "无附件", after: (after ?? []).map(file => file.name).join("、") || "无附件" });
  }
  const oldEdits = workspace(old.caseEdits), newEdits = workspace(next.caseEdits), original = workspace(old.caseInfo);
  for (const [key, label] of [["name", "Case 名称"], ["background", "Case 背景"], ["reason", "发起事由"], ["impact", "影响"], ["remark", "备注"]]) {
    const before = text(oldEdits[key] ?? original[key]), after = text(newEdits[key] ?? before);
    if (before !== after) changes.push({ field: label, before: before || "未填写", after: after || "未填写" });
  }
  return changes;
}