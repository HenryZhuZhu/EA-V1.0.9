import { currentUser, directors, ownerToDepartment, reportsTo, vp } from "./data";

export const REWORK_REASON_LIMIT = 2000;

export function taskReworkDisabledReason(task: { owner: string; initiator?: string; status: string }, actor = currentUser.name): string | undefined {
  const knownOwner = Boolean(ownerToDepartment[task.owner]) || directors.some((director) => director.name === task.owner) || task.owner === vp;
  const supervisor = knownOwner ? reportsTo(task.owner) : null;
  if (actor !== task.initiator && actor !== supervisor) return "仅任务发起人或负责人主管可以退回重做。";
  if (task.status !== "已完成") return "仅已完成的任务可以退回重做。";
  return undefined;
}

export function validateRework(task: { owner: string; initiator?: string; status: string }, reason: string) {
  const blocked = taskReworkDisabledReason(task);
  if (blocked) throw new Error(blocked);
  const trimmed = reason.trim();
  if (!trimmed) throw new Error("请填写退回重做原因。");
  if (trimmed.length > REWORK_REASON_LIMIT) throw new Error(`退回原因最多 ${REWORK_REASON_LIMIT} 字。`);
  return trimmed;
}