import { Share2, X, GitBranch, Target, ArrowRight, Copy, CheckCircle2, ChevronDown, FlaskConical, Clock, PencilRuler, Factory, Cpu, Package, Boxes, AlertTriangle } from "lucide-react";
import { useState, Fragment } from "react";
import { mockProducts, productById, mockCases, PROBLEM_DOMAINS, PROBLEM_TYPES, ProblemDomain, ProblemType, domainProductKR, ownerToDepartment } from "./data";
import { suggestRelatedCases } from "./caseInsights";
import { RelatedCaseCard } from "./RelatedCaseCard";
import { ProductPicker } from "./ProductPicker";
import { OptionCard } from "./OptionCard";
import { VoiceInputButton } from "./VoiceInputButton";
import { AttachmentInput, Att } from "./AttachmentInput";
import { useCaseLinks, linkCases, unlinkCases } from "./domainStore";
import { getClosure } from "./closures";

export interface RootCauseFanoutResult {
  domain: ProblemDomain;
  problemType: ProblemType;
  krByProduct: Record<string, string>;  // 产品 id → KR（同一 Domain 下各产品负责人不同）
  followupNote?: string;
  fanoutTargets: string[];   // 空 = 不 Fanout
  fanoutSkipReason?: string;
}

interface Props {
  caseId?: string;                 // 用于结案前查重（找相似 Case）
  caseCode: string;
  caseName: string;
  caseProductIds?: string[];       // 本 Case 的产品（Fanout 目标默认为「其它全部产品」，排除这些）
  initialDomain?: string;
  initialProblemType?: string;
  noFanout?: boolean;              // L3 等低层级：无需 Fanout，仅确认根因
  resume?: boolean;                // 已确认根因：跳到第 4 步、锁定 1-3、默认「直接结案」
  initialConclusion?: string;      // 结案信息表单：结论（引用 Case 分析结论）
  initialFiles?: Att[];            // 结案信息表单：附件（引用 Case 数据与附件）
  initialSolutionPath?: string[];
  onCancel: () => void;
  onSubmit: (result: CloseWizardResult) => void;
}

export type CloseWizardResult = RootCauseFanoutResult & {
  decision: "defer" | "close";     // 暂不结案（进入待验证）/ 直接结案（提交结案信息）
  conclusion?: string;
  files?: Att[];
  solutionPath?: string[];
};

// 根因归属 Domain 的图标
const DOMAIN_ICONS: Record<string, typeof Target> = {
  Design: PencilRuler,
  Process: Factory,
  Testing: FlaskConical,
  System: Cpu,
  Package: Package,
  Module: Boxes,
};

export function RootCauseFanoutModal({ caseId, caseCode, caseName, caseProductIds = [], initialDomain, initialProblemType, noFanout = false, resume = false, initialConclusion, initialFiles, initialSolutionPath, onCancel, onSubmit }: Props) {
  const otherProductIds = mockProducts.filter((p) => !caseProductIds.includes(p.id)).map((p) => p.id);
  const [skipFanout, setSkipFanout] = useState(false);
  const [fanoutTargets, setFanoutTargets] = useState<string[]>(otherProductIds);
  const [skipReason, setSkipReason] = useState("");
  const [domain, setDomain] = useState<ProblemDomain | "">(
    (PROBLEM_DOMAINS as readonly string[]).includes(initialDomain ?? "") ? (initialDomain as ProblemDomain) : "",
  );
  const [followupNote, setFollowupNote] = useState("");
  const [problemType, setProblemType] = useState<ProblemType | "">(
    (PROBLEM_TYPES as readonly string[]).includes(initialProblemType ?? "") ? (initialProblemType as ProblemType) : "",
  );
  // 结案前查重：列出与本 Case 相似度 ≥70% 的「疑似重复」Case，需用户确认均非重复方可提交
  const [dedupeConfirmed, setDedupeConfirmed] = useState(false);
  const caseLinks = useCaseLinks();
  const dupLinkedIds = new Set(
    caseLinks.filter((l) => (l.from === caseId || l.to === caseId) && l.type === "重复").flatMap((l) => [l.from, l.to]),
  );
  const dupCandidates = (() => {
    const current = mockCases.find((x) => x.id === caseId);
    return current ? suggestRelatedCases(current, mockCases).filter((s) => s.score >= 0.7) : [];
  })();
  const unmarkedCandidateCount = dupCandidates.filter((s) => !dupLinkedIds.has(s.caseId)).length;
  const markDuplicate = (candidateId: string) => {
    if (!caseId || dupLinkedIds.has(candidateId)) return;
    unlinkCases(caseId, candidateId);
    linkCases(caseId, candidateId, "重复");
  };
  const unmarkDuplicate = (candidateId: string) => {
    if (!caseId) return;
    unlinkCases(caseId, candidateId);
  };
  const duplicateFanoutWarnings = Array.from(dupLinkedIds).flatMap((duplicateId) => {
    if (duplicateId === caseId) return [];
    const duplicateCase = mockCases.find((x) => x.id === duplicateId);
    if (!duplicateCase) return [];
    const closureTargets = getClosure(duplicateId)?.fanoutTargets ?? [];
    const targetCount = new Set([...(duplicateCase.fanoutTargets ?? []), ...closureTargets]).size;
    const spawnedCount = mockCases.filter((x) => x.fanoutSourceCaseId === duplicateId).length;
    const fanoutCount = Math.max(targetCount, spawnedCount);
    if (fanoutCount > 0) {
      return [{ id: duplicateId, status: `已向 ${fanoutCount} 个产品 Fanout` }];
    }
    if (duplicateCase.fanoutSourceCaseId) {
      return [{ id: duplicateId, status: "已 Fanout" }];
    }
    return [];
  });
  const [insistFanout, setInsistFanout] = useState(false);
  const [krListOpen, setKrListOpen] = useState(false);
  const [coverageKrListOpen, setCoverageKrListOpen] = useState(false);
  const hasDuplicateFanoutWarning = duplicateFanoutWarnings.length > 0;
  const duplicateFanoutSuppressed = hasDuplicateFanoutWarning && !insistFanout;
  const fanoutPanelVisible = !hasDuplicateFanoutWarning || insistFanout;
  const krList = domain && !skipFanout && !noFanout && fanoutPanelVisible
    ? fanoutTargets.map((pid) => ({ pid, code: productById(pid)?.code || pid, kr: domainProductKR(domain, pid) }))
    : [];
  const coverageKrList = !skipFanout && !noFanout && fanoutPanelVisible
    ? fanoutTargets.map((pid) => ({ pid, code: productById(pid)?.code || pid, kr: domainProductKR("Testing", pid) }))
    : [];

  // 第 4 步：结案决策 + 结案信息
  const [decision, setDecision] = useState<"" | "defer" | "close">(resume ? "close" : "");
  const [conclusion, setConclusion] = useState(initialConclusion ?? "");
  const [files, setFiles] = useState<Att[]>(initialFiles ?? []);

  // 向导：1 结案前查重 · 2 确认根因 · 3 提交 Fanout · 4 结案
  const [step, setStep] = useState<1 | 2 | 3 | 4>(resume ? 4 : 1);
  const canNext1 = unmarkedCandidateCount === 0 || dedupeConfirmed;
  const canNext2 = !!domain && !!problemType;
  const canNext3 = noFanout || duplicateFanoutSuppressed ? true : (skipFanout ? skipReason.trim().length >= 2 : fanoutTargets.length > 0);
  const canFinish = decision === "close" ? conclusion.trim().length >= 10 : decision === "defer";
  const STEPS: { n: 1 | 2 | 3 | 4; label: string }[] = [
    { n: 1, label: "结案前查重" },
    { n: 2, label: "确认根因" },
    { n: 3, label: "提交 Fanout" },
    { n: 4, label: "结案" },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40" onClick={onCancel}>
      <div
        className="w-[720px] max-w-[95vw] bg-white rounded-lg shadow-xl border border-slate-200 p-5 space-y-4 max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-2">
          <GitBranch size={16} className="text-[#00B578]" />
          <h3 className="text-slate-900">{step === 1 ? "结案前查重" : step === 2 ? "确认根因" : step === 3 ? "提交 Fanout" : "结案"}</h3>
          <span className="text-[11px] px-1.5 py-0.5 rounded-full bg-[#00B578]/10 text-[#00B578] border border-[#00B578]/20">结案 · 第一阶段</span>
          <button onClick={onCancel} className="ml-auto text-slate-400 hover:text-slate-600"><X size={16} /></button>
        </div>

        {/* 三步进度指示 */}
        <div className="flex items-center gap-1.5">
          {STEPS.map((s, i) => (
            <Fragment key={s.n}>
              <div className="flex items-center gap-1.5 shrink-0">
                <span className={`w-5 h-5 rounded-full grid place-items-center text-[11px] font-medium border ${step === s.n ? "bg-[#00B578] text-white border-[#00B578]" : step > s.n ? "bg-[#00B578]/10 text-[#00B578] border-[#00B578]/30" : "text-slate-400 border-slate-200"}`}>{step > s.n ? "✓" : s.n}</span>
                <span className={`text-[12px] ${step === s.n ? "text-slate-800 font-medium" : "text-slate-400"}`}>{s.label}</span>
              </div>
              {i < STEPS.length - 1 && <div className={`flex-1 h-px ${step > s.n ? "bg-[#00B578]/40" : "bg-slate-200"}`} />}
            </Fragment>
          ))}
        </div>

        {/* Step 1：结案前查重 */}
        {step === 1 && (
          dupCandidates.length > 0 ? (
            <div className="space-y-2.5">
              <div className="grid grid-cols-2 gap-2.5">
                {dupCandidates.map((s) => {
                  const cc = mockCases.find((x) => x.id === s.caseId)!;
                  const markedDuplicate = dupLinkedIds.has(s.caseId);
                  return (
                    <RelatedCaseCard
                      key={s.caseId}
                      caseItem={cc}
                      title={cc.name.replace(/^【Fanout 验证】\s*/, "")}
                      score={s.score}
                      reason={s.reason}
                      actions={caseId ? (
                        <button
                          type="button"
                          onClick={() => (markedDuplicate ? unmarkDuplicate(s.caseId) : markDuplicate(s.caseId))}
                          aria-pressed={markedDuplicate}
                          title={markedDuplicate ? "已标注为与该 Case 重复，点击可撤销" : "标注为与该 Case 重复（同一问题）；仅标记，不合并数据"}
                          className={`h-6 px-2 rounded-md border text-[10px] font-medium inline-flex items-center gap-1 transition-colors ${markedDuplicate ? "border-red-300 bg-red-50 text-red-600 hover:bg-red-100" : "border-red-200 text-red-500 hover:border-red-300 hover:bg-red-50"}`}
                        >
                          {markedDuplicate && <CheckCircle2 size={11} />}
                          {markedDuplicate ? "已标注重复" : "标注重复"}
                        </button>
                      ) : undefined}
                    />
                  );
                })}
              </div>
            {unmarkedCandidateCount > 0 ? (
              <label className="flex items-center gap-2 text-[13px] text-slate-700 cursor-pointer select-none">
                <input type="checkbox" checked={dedupeConfirmed} onChange={(e) => setDedupeConfirmed(e.target.checked)} className="accent-[#00B578]" />
                <span>我已确认，以上未标注 Case 与本 Case 均<b>不重复</b></span>
              </label>
            ) : (
              <div className="flex items-center gap-1.5 text-[12px] font-medium text-[#00B578]"><CheckCircle2 size={14} />以上疑似重复 Case 均已标注</div>
            )}
            <div className="pl-6 text-[11px] text-slate-400 leading-relaxed">若确为重复：点右侧「标注重复」即可（同一问题只需最早创建的 Case 结案），标注后按钮将显示「已标注重复」。</div>
            </div>
          ) : (
            <div className="rounded-md border border-slate-200 bg-slate-50/60 p-5 text-center text-xs text-slate-500">
              <Copy size={16} className="text-slate-300 mx-auto mb-1.5" />
              未发现相似度 ≥70% 的疑似重复 Case，可直接进入下一步。
            </div>
          )
        )}

        {/* Step 2：确认根因 */}
        {step === 2 && (
          <>
            <div className="space-y-2.5">
              <div className="flex items-center gap-2">
                <span className="text-[13px] font-medium text-slate-800">根因归属 Domain <span className="text-red-500">*</span></span>
              </div>
              <div className="grid grid-cols-6 gap-2 [&_.lucide-check]:hidden">
                {PROBLEM_DOMAINS.map((d) => {
                  const Icon = DOMAIN_ICONS[d] ?? Target;
                  const active = domain === d;
                  return (
                    <OptionCard
                      key={d}
                      active={active}
                      onClick={() => setDomain(d)}
                      icon={<Icon size={18} className={active ? "text-[#0052D9]" : "text-slate-400"} />}
                      label={d}
                    />
                  );
                })}
              </div>
            </div>
            <label className="block text-xs text-slate-600">
              类型 <span className="text-red-500">*</span>
              <select value={problemType} onChange={(event) => setProblemType(event.target.value as ProblemType | "")} className="mt-1 h-9 w-full rounded border border-slate-200 bg-white px-2.5 text-sm outline-none focus:border-[#0052D9]">
                <option value="">请选择</option>
                {PROBLEM_TYPES.map((type) => <option key={type} value={type}>{type}</option>)}
              </select>
            </label>
            <label className="block text-xs text-slate-600">
              根因说明 <span className="text-slate-400">（选填，简述根因方向与线下验证计划）</span>
              <textarea
                value={followupNote}
                onChange={(e) => setFollowupNote(e.target.value)}
                placeholder="例：根因初判为 P_ICC2_07 timing margin 不足，已安排跨 3 批次线下复测验证，预计 2 个月内出结论。"
                className="mt-1 w-full min-h-[72px] p-2.5 text-sm rounded border border-slate-200 outline-none focus:border-[#0052D9] leading-relaxed"
              />
            </label>
          </>
        )}

        {/* Step 3：提交 Fanout */}
        {step === 3 && (
          noFanout ? (
            <div className="rounded-md bg-[#00B578]/5 border border-[#00B578]/20 p-3 text-xs text-slate-700 leading-relaxed">
              <div className="flex items-center gap-2 mb-1">
                <Share2 size={14} className="text-[#0052D9]" />
                <span className="text-[13px] font-medium text-slate-800">Fanout 扩散验证</span>
              </div>
              本 Case 为 <b className="text-[#00B578]">L3</b> 级别，<b className="text-[#00B578]">本级别无需 Fanout</b>；确认后直接进入<b className="text-slate-700">第 2 步·提交结案信息</b>。
            </div>
          ) : (
            <>
              {duplicateFanoutWarnings.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2 text-amber-800">
                      <AlertTriangle size={15} className="shrink-0" />
                      <span className="text-[13px] font-medium">已有重复 Case 进行过 Fanout</span>
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={() => setInsistFanout(true)}
                        className={`h-7 px-2.5 rounded-md border text-[11px] font-medium transition-colors ${insistFanout ? "border-[#0052D9] bg-[#0052D9]/[0.06] text-[#0052D9]" : "border-slate-200 text-slate-500 hover:bg-slate-50"}`}
                      >仍要继续 Fanout</button>
                      <button
                        type="button"
                        onClick={() => { setInsistFanout(false); setSkipFanout(false); setSkipReason(""); }}
                        className={`h-7 px-2.5 rounded-md border text-[11px] font-medium transition-colors ${!insistFanout ? "border-[#0052D9] bg-[#0052D9]/[0.06] text-[#0052D9]" : "border-slate-200 text-slate-500 hover:bg-slate-50"}`}
                      >不需要 Fanout</button>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2.5">
                    {duplicateFanoutWarnings.map((item) => {
                      const cc = mockCases.find((x) => x.id === item.id)!;
                      return (
                        <RelatedCaseCard
                          key={item.id}
                          caseItem={cc}
                          title={cc.name.replace(/^【Fanout 验证】\s*/, "")}
                          topRight={<span className="text-[9.5px] text-amber-600 font-medium whitespace-nowrap shrink-0">{item.status}</span>}
                        />
                      );
                    })}
                  </div>
                  <div className={`rounded border px-2.5 py-1.5 text-[11px] ${insistFanout ? "border-[#0052D9]/20 bg-[#0052D9]/5 text-[#0052D9]" : "border-amber-200 bg-white/80 text-amber-800"}`}>
                    {insistFanout ? "你已选择继续 Fanout，请确认下方目标产品与相关 KR。" : "建议：本次不再重复 Fanout，直接进入下一步。"}
                  </div>
                </div>
              )}
              {fanoutPanelVisible && (
                <div className="rounded-md border border-slate-200 p-3 space-y-2.5">
                  <div className="flex items-center gap-2">
                    <Share2 size={14} className="text-[#0052D9]" />
                    <span className="text-[13px] font-medium text-slate-800">Fanout 扩散验证</span>
                  </div>
                  {!skipFanout ? (
                    <>
                      <div className="flex items-center justify-between gap-2 mb-1.5">
                        <span className="text-[11px] text-slate-500">目标产品 · 已选 {fanoutTargets.length} 个</span>
                        {!hasDuplicateFanoutWarning && (
                          <button type="button" onClick={() => setSkipFanout(true)} className="inline-flex items-center h-6 px-2 rounded-md border border-slate-300 text-[11px] font-medium text-slate-600 hover:border-red-300 hover:text-red-500 hover:bg-red-50 transition-colors">本次不进行 Fanout</button>
                        )}
                      </div>
                      <ProductPicker multiple value={fanoutTargets} onChange={setFanoutTargets} excludeIds={caseProductIds} placeholder="选择要 Fanout 的产品" triggerClassName="min-h-[40px]" />
                    </>
                  ) : (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-[11px] text-amber-600">本次不进行 Fanout，请说明理由（必填）：</span>
                        <button type="button" onClick={() => setSkipFanout(false)} className="text-[11px] text-[#0052D9] hover:underline">重新启用 Fanout</button>
                      </div>
                      <textarea
                        value={skipReason}
                        onChange={(e) => setSkipReason(e.target.value)}
                        placeholder="如：本问题为该产品特有的封装工艺，其它产品不涉及，无需扩散验证。"
                        className="w-full min-h-[64px] p-2.5 text-sm rounded border border-slate-200 outline-none focus:border-[#0052D9] leading-relaxed"
                      />
                    </div>
                  )}
                </div>
              )}
              {!skipFanout && domain && krList.length > 0 && (
                <div className="rounded-md border border-slate-200 overflow-hidden">
                  <button type="button" onClick={() => setKrListOpen((open) => !open)} aria-expanded={krListOpen} className="flex w-full items-center gap-2 px-3 py-2.5 text-left hover:bg-slate-50">
                    <span className="text-[11px] text-slate-600">{domain} 相关 KR</span>
                    <span className="text-[10px] text-slate-400">{krList.length} 个</span>
                    <span className="ml-auto text-[10px] text-slate-400">{krListOpen ? "收起" : "展开"}</span>
                    <ChevronDown size={13} className={`text-slate-400 transition-transform ${krListOpen ? "rotate-180" : ""}`} />
                  </button>
                  {krListOpen && <div className="grid grid-cols-2 gap-1.5 max-h-[180px] overflow-y-auto border-t border-slate-100 p-3">
                    {krList.map((x) => (
                      <div key={x.pid} className="flex items-center gap-2 rounded-md border border-slate-200 bg-slate-50/60 px-2 py-1.5">
                        <span className="font-mono text-[11px] text-slate-600 truncate" title={x.code}>{x.code}</span>
                        <ArrowRight size={12} className="text-slate-300 shrink-0" />
                        <span className="ml-auto inline-flex items-center gap-1.5 shrink-0">
                          <span className="w-5 h-5 rounded-full bg-gradient-to-br from-[#7A3DFF] to-[#A06BFF] text-white grid place-items-center text-[9px] font-medium">{x.kr.slice(-2)}</span>
                          <span className="text-[11.5px] text-slate-700">{x.kr}</span>
                          <span className="text-[10px] text-slate-400">{ownerToDepartment[x.kr] ?? "—"}</span>
                        </span>
                      </div>
                    ))}
                  </div>}
                </div>
              )}
              {!skipFanout && coverageKrList.length > 0 && (
                <div className="rounded-md border border-cyan-200 bg-cyan-50/50 overflow-hidden">
                  <button type="button" onClick={() => setCoverageKrListOpen((open) => !open)} aria-expanded={coverageKrListOpen} className="flex w-full items-center gap-2 px-3 py-2.5 text-left hover:bg-cyan-50">
                    <FlaskConical size={13} className="text-cyan-700" />
                    <span className="text-[11px] font-medium text-cyan-800">Coverage 相关 KR</span>
                    <span className="text-[10px] text-cyan-700/70">{coverageKrList.length} 个</span>
                    <span className="ml-auto text-[10px] text-cyan-700/70">{coverageKrListOpen ? "收起" : "展开"}</span>
                    <ChevronDown size={13} className={`text-cyan-700/70 transition-transform ${coverageKrListOpen ? "rotate-180" : ""}`} />
                  </button>
                  {coverageKrListOpen && <div className="grid grid-cols-2 gap-1.5 max-h-[180px] overflow-y-auto border-t border-cyan-200 p-3">
                    {coverageKrList.map((item) => (
                      <div key={item.pid} className="flex items-center gap-2 rounded-md border border-cyan-200 bg-white px-2 py-1.5">
                        <span className="font-mono text-[11px] text-slate-600 truncate" title={item.code}>{item.code}</span>
                        <ArrowRight size={12} className="text-cyan-300 shrink-0" />
                        <span className="ml-auto inline-flex items-center gap-1.5 shrink-0"><span className="w-5 h-5 rounded-full bg-cyan-600 text-white grid place-items-center text-[9px] font-medium">{item.kr.slice(-2)}</span><span className="text-[11.5px] text-slate-700">{item.kr}</span><span className="text-[10px] text-slate-400">{ownerToDepartment[item.kr] ?? "—"}</span></span>
                      </div>
                    ))}
                  </div>}
                </div>
              )}
            </>
          )
        )}

        {/* Step 4：结案决策 + 结案信息 */}
        {step === 4 && (
          <>
            {!resume ? (
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setDecision("close")}
                  className={`text-left rounded-md border p-3 transition-colors ${decision === "close" ? "border-[#00B578] bg-[#00B578]/[0.06] ring-1 ring-[#00B578]/30" : "border-slate-200 hover:border-slate-300"}`}
                >
                  <div className="flex items-center gap-1.5 text-[13px] font-medium text-slate-800"><CheckCircle2 size={15} className="text-[#00B578]" /> 直接结案</div>
                  <div className="text-[11px] text-slate-500 mt-1 leading-relaxed">方案已验证，立即填写结案信息并结案。</div>
                </button>
                <button
                  type="button"
                  onClick={() => setDecision("defer")}
                  className={`text-left rounded-md border p-3 transition-colors ${decision === "defer" ? "border-[#0052D9] bg-[#0052D9]/[0.05] ring-1 ring-[#0052D9]/30" : "border-slate-200 hover:border-slate-300"}`}
                >
                  <div className="flex items-center gap-1.5 text-[13px] font-medium text-slate-800"><Clock size={15} className="text-[#0052D9]" /> 暂不结案，需验证解决方案</div>
                  <div className="text-[11px] text-slate-500 mt-1 leading-relaxed">方案需线下验证（可能历时数月），验证无误后再回来完成结案。</div>
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2 text-[12px]">
                <span className="text-slate-400 shrink-0">结案方式：</span>
                <button type="button" onClick={() => setDecision("close")} className={`h-7 px-2.5 rounded-md border transition-colors ${decision === "close" ? "border-[#00B578] bg-[#00B578]/[0.06] text-[#00B578] font-medium" : "border-slate-200 text-slate-500 hover:bg-slate-50"}`}><CheckCircle2 size={12} className="inline mr-1 -mt-0.5" />直接结案</button>
                <button type="button" onClick={() => setDecision("defer")} className={`h-7 px-2.5 rounded-md border transition-colors ${decision === "defer" ? "border-[#0052D9] bg-[#0052D9]/[0.05] text-[#0052D9] font-medium" : "border-slate-200 text-slate-400 hover:bg-slate-50"}`}>暂不结案，需验证解决方案</button>
              </div>
            )}

            {decision === "close" && (
              <>
                <label className="block text-xs text-slate-600">
                  结案结论 <span className="text-slate-400">（已引用 Case「分析过程与结论」，确认无误即可，可编辑）</span>
                  <div className="mt-1 relative">
                    <textarea
                      value={conclusion}
                      onChange={(e) => setConclusion(e.target.value)}
                      placeholder="例：根因为 P_ICC2_07 在 0.6V 下 timing margin 不足，已通过 BIST pattern 调整 + 测试程序 P017 升级修复，跨 5 批次复测良率回升至基线之上。"
                      className="w-full min-h-[120px] p-2.5 pr-9 text-sm rounded border border-slate-200 outline-none focus:border-[#0052D9] leading-relaxed"
                    />
                    <div className="absolute right-2 top-2">
                      <VoiceInputButton size="sm" onTranscript={(t) => setConclusion((p) => (p ? p + " " + t : t))} hint="语音输入结论" />
                    </div>
                  </div>
                </label>
                <label className="block text-xs text-slate-600">
                  结案文件 <span className="text-slate-400">（已引用 Case「数据与附件」，可增删）</span>
                  <div className="mt-1">
                    <AttachmentInput value={files} onChange={setFiles} />
                  </div>
                </label>
              </>
            )}

            {decision === "defer" && (
              <div className="rounded-md bg-[#0052D9]/[0.04] border border-[#0052D9]/20 p-3 text-xs text-slate-600 leading-relaxed">
                解决方案线下验证无误后，在详情页点击<b className="text-slate-700">「提交结案信息」</b>即可回到本步完成结案。
              </div>
            )}
          </>
        )}

        {/* 底部导航 */}
        <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
          <button onClick={onCancel} className="h-8 px-3 text-sm rounded-md border border-slate-200 text-slate-600 hover:bg-slate-50">取消</button>
          {step > 1 && !resume && (
            <button onClick={() => setStep((step - 1) as 1 | 2 | 3 | 4)} className="h-8 px-3 text-sm rounded-md border border-slate-200 text-slate-600 hover:bg-slate-50">上一步</button>
          )}
          {step < 4 ? (
            <button
              disabled={step === 1 ? !canNext1 : step === 2 ? !canNext2 : !canNext3}
              onClick={() => setStep((step + 1) as 1 | 2 | 3 | 4)}
              className="h-8 px-3.5 text-sm rounded-md bg-[#00B578] text-white hover:bg-[#009962] disabled:opacity-40 inline-flex items-center gap-1"
            >
              下一步 <ArrowRight size={13} />
            </button>
          ) : (
            <button
              disabled={!canFinish}
              onClick={() => onSubmit({
                domain: domain as ProblemDomain,
                problemType: problemType as ProblemType,
                krByProduct: Object.fromEntries(krList.map((x) => [x.pid, x.kr])),
                followupNote: followupNote.trim() || undefined,
                fanoutTargets: (skipFanout || noFanout || duplicateFanoutSuppressed) ? [] : fanoutTargets,
                fanoutSkipReason: noFanout ? "L3 级别无需 Fanout" : duplicateFanoutSuppressed ? "重复 Case 已进行 Fanout，本次不再重复 Fanout" : (skipFanout ? skipReason.trim() : undefined),
                decision: decision as "defer" | "close",
                conclusion: decision === "close" ? conclusion.trim() : undefined,
                files: decision === "close" ? files : undefined,
                solutionPath: initialSolutionPath,
              })}
              className={`h-8 px-3.5 text-sm rounded-md text-white disabled:opacity-40 inline-flex items-center gap-1 ${decision === "defer" ? "bg-[#0052D9] hover:bg-[#003FA8]" : "bg-[#00B578] hover:bg-[#009962]"}`}
            >
              {decision === "defer" ? <><FlaskConical size={13} /> 暂不结案，待验证解决方案</> : <><CheckCircle2 size={13} /> 完成结案</>}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
