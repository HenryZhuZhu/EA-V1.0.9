import { CheckCircle2, X, ShieldCheck } from "lucide-react";
import { useState } from "react";
import { VoiceInputButton } from "./VoiceInputButton";

interface Props {
  caseCode: string;
  caseName: string;
  initialConclusion?: string;
  onCancel: () => void;
  onSubmit: (conclusion: string) => void;
}

export function CloseCaseModal({ caseCode, caseName, initialConclusion, onCancel, onSubmit }: Props) {
  const [conclusion, setConclusion] = useState(initialConclusion ?? "");
  const canSubmit = conclusion.trim().length >= 2;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40"
      onClick={onCancel}
    >
      <div
        className="w-[560px] max-w-[95vw] bg-white rounded-lg shadow-xl border border-slate-200 p-5 space-y-4 max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-2">
          <ShieldCheck size={16} className="text-[#00B578]" />
          <h3 className="text-slate-900">结案 Fanout Case</h3>
          <span className="text-[11px] px-1.5 py-0.5 rounded-full bg-cyan-50 text-cyan-700 border border-cyan-200">单步结案</span>
          <button onClick={onCancel} className="ml-auto text-slate-400 hover:text-slate-600">
            <X size={16} />
          </button>
        </div>

        <div className="text-xs text-slate-600 bg-slate-50 border border-slate-100 rounded p-2.5 leading-relaxed">
          <span className="font-mono text-slate-500">{caseCode}</span>
          <span className="mx-1.5 text-slate-300">·</span>
          <span className="text-slate-800">{caseName}</span>
        </div>

        <div className="rounded-md bg-cyan-50/60 border border-cyan-200 p-2.5 text-xs text-slate-700 leading-relaxed">
          Fanout Case 已继承源 Case 的问题与解决方案，只需填写验证结论即可直接结案。
        </div>

        <div className="space-y-4 min-w-0">
          <label className="block text-xs text-slate-600">
            结案结论 <span className="text-red-500">*</span>
            <div className="mt-1 relative">
              <textarea
                autoFocus
                value={conclusion}
                onChange={(e) => setConclusion(e.target.value)}
                placeholder="简要填写验证结果与结案结论"
                className="w-full min-h-[130px] p-2.5 pr-9 text-sm rounded border border-slate-200 outline-none focus:border-[#0052D9] leading-relaxed"
              />
              <div className="absolute right-2 top-2">
                <VoiceInputButton
                  size="sm"
                  onTranscript={(t) => setConclusion((p) => (p ? p + " " + t : t))}
                  hint="语音输入结论"
                />
              </div>
            </div>
          </label>

        </div>

        <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
          <button
            onClick={onCancel}
            className="h-8 px-3 text-sm rounded-md border border-slate-200 text-slate-600 hover:bg-slate-50"
          >
            取消
          </button>
          <button
            disabled={!canSubmit}
            onClick={() => onSubmit(conclusion.trim())}
            className="h-8 px-3.5 text-sm rounded-md bg-[#00B578] text-white hover:bg-[#009962] disabled:opacity-40 inline-flex items-center gap-1"
          >
            <CheckCircle2 size={13} /> 结案
          </button>
        </div>
      </div>
    </div>
  );
}
