import type { CaseItem } from "./data";
import { coreCaseParticipants } from "./caseParticipants";

export function CaseCoreParticipants({ record }: { record: CaseItem }) {
  const { selected, total } = coreCaseParticipants(record);
  if (!selected.length) return null;
  return <span className="inline-flex min-w-0 max-w-[260px] items-center gap-1 text-slate-400" aria-label={`核心参与者：${selected.map(person => person.name).join("、")}${total > 2 ? "等" : ""}`} title={selected.map(person => `${person.name} · ${person.department} · ${person.taskCount} 项执行任务${person.evidenceCount ? ` · ${person.evidenceCount} 项有结果记录` : ""}`).join("\n")}><span aria-hidden="true">·</span><span className="truncate">{selected.map(person => person.name).join(" / ")}{total > 2 ? " 等" : ""}</span></span>;
}