import { departmentSupervisors, domainProductKR, ownerToDepartment, PROBLEM_DOMAINS, PROBLEM_TYPES, type ProblemDomain, type ProblemType } from "./data";

export const TASK_INVOLVEMENT_KINDS = ["产品", "Project", "TF", "无"] as const;
export type TaskInvolvementKind = typeof TASK_INVOLVEMENT_KINDS[number];
export type TaskInvolvement = { kind: "无" } | { kind: Exclude<TaskInvolvementKind, "无">; id: string; name: string };
export type TaskAssignmentMethod = "department" | "domain-type";

// 经确认暂用演示配置；真实组织映射/TF 服务接入时集中替换本文件，不使用随机分派。
export const DEMO_TASK_FORCES = [
  { id: "tf-demo-yield", name: "良率提升专项（演示）" },
  { id: "tf-demo-test", name: "测试效率优化专项（演示）" },
  { id: "tf-demo-quality", name: "质量问题闭环专项（演示）" },
];

const DEMO_DOMAIN_OWNERS: Record<ProblemDomain, { owner: string; types: Partial<Record<ProblemType, string>> }> = {
  Design: { owner: "李娜", types: { DFT: "张伟", IO: "刘洋", Layout: "孙主管", PDK: "孙主管" } },
  Process: { owner: "周宇", types: { PDK: "李昊", Model: "吴迪" } },
  Testing: { owner: "张伟", types: { DFT: "周杰", IO: "王芳", "Analog/DC": "赵敏" } },
  System: { owner: "刘洋", types: { Model: "李娜", Others: "孙楠" } },
  Package: { owner: "陈磊", types: { "Analog/DC": "周宇", Others: "孙楠" } },
  Module: { owner: "赵敏", types: { IO: "王芳", DFT: "周杰" } },
};

export interface TaskAssignment {
  owner: string;
  department: string;
  source: "domain-type" | "department-leader";
}

export const DEMO_TASK_OWNER_RULES = PROBLEM_DOMAINS.flatMap((domain) => PROBLEM_TYPES.map((type) => {
  const config = DEMO_DOMAIN_OWNERS[domain];
  const owner = config.types[type] ?? config.owner;
  return { domain, type, owner, department: ownerToDepartment[owner] };
}));

export function taskTypeHasKR(domain: ProblemDomain | "", type: ProblemType | "") {
  return Boolean(domain && type && DEMO_DOMAIN_OWNERS[domain].types[type]);
}

export function resolveStandaloneAssignment(domain: ProblemDomain | "", type: ProblemType | "", department: string, productId = ""): TaskAssignment | null {
  if (domain && type) {
    if (productId) {
      if (!taskTypeHasKR(domain, type)) return null;
      const owner = domainProductKR(domain, productId), resolvedDepartment = ownerToDepartment[owner];
      return resolvedDepartment ? { owner, department: resolvedDepartment, source: "domain-type" } : null;
    }
    const rule = DEMO_TASK_OWNER_RULES.find((item) => item.domain === domain && item.type === type);
    return rule?.department ? { owner: rule.owner, department: rule.department, source: "domain-type" } : null;
  }
  const owner = departmentSupervisors[department];
  return owner ? { owner, department, source: "department-leader" } : null;
}