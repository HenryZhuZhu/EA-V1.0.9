import { useState } from "react";
import { currentUser } from "./data";
import { decideCaseRecovery, useClosures } from "./closures";

export function CaseRecoveryPanel({ caseId }: { caseId: string }) {
  const closure = useClosures().get(caseId);
  const [note, setNote] = useState("");
  const [error, setError] = useState("");
  const request = closure?.approval?.kind === "closure" || closure?.approval?.decision ? closure.approval : undefined;
  const decide = (approved: boolean) => {
    try { decideCaseRecovery(caseId, request!.id, approved, note); setError(""); setNote(""); }
    catch (cause) { setError(cause instanceof Error ? cause.message : "保存失败"); }
  };
  return <>
    {request && <section aria-label="Case 重新处理审批" className="mt-3 border-l-2 border-blue-300 bg-blue-50/50 p-3 text-xs text-slate-600"><b>{request.kind === "reopen" ? "重新处理申请" : "再次结案申请"} · {request.decision === "approved" ? "已通过" : request.decision === "rejected" ? "已驳回" : "待确认"}</b><p className="mt-1">{request.requestedBy} 提交 · 原结案审核人 {request.reviewer}</p><p className="mt-1 whitespace-pre-wrap">{request.reason}</p>{request.note && <p className="mt-1">审核意见：{request.note}</p>}{!request.decision && currentUser.name === request.reviewer && <div className="mt-3"><textarea aria-label="审核意见" placeholder="审核意见（驳回时必填）" value={note} maxLength={2000} onChange={event => setNote(event.target.value)} className="h-16 w-full rounded border border-slate-200 bg-white p-2 outline-none focus:border-blue-500" /><div className="mt-2 flex gap-2"><button className="rounded bg-[#0052D9] px-3 py-1.5 text-white" onClick={() => decide(true)}>通过</button><button className="rounded border border-slate-200 bg-white px-3 py-1.5" onClick={() => decide(false)}>驳回</button></div>{error && <p role="alert" className="mt-2 text-red-600">{error}</p>}</div>}</section>}
  </>;
}