import { useEffect, useMemo, useState } from "react";
import { CalendarDays, ChartGantt, Lightbulb } from "lucide-react";
import { CaseItem, flattenTasks, TaskNode, urgencyBar } from "./data";
import { StatusBadge } from "./StatusBadge";
import { formatCaseTime, taskLifecycleTimes } from "./caseTiming";

interface Props {
  caseItem: CaseItem;
  tasks: TaskNode[];
  onTaskClick: (taskId: string) => void;
}

interface GanttTask {
  task: TaskNode;
  depth: number;
  path: string[];
  isThought: boolean;
  start: Date | null;
  end: Date | null;
  timeline: ReturnType<typeof taskLifecycleTimes>;
}

const DAY = 24 * 60 * 60 * 1000;

function parseDate(value?: string): Date | null {
  if (!value) return null;
  const date = new Date(/^\d{4}-\d{2}-\d{2}$/.test(value) ? `${value}T00:00:00` : value);
  return Number.isNaN(date.getTime()) ? null : date;
}

function addDays(date: Date, days: number): Date {
  const next = new Date(date);
  next.setDate(next.getDate() + days);
  return next;
}

function dayDiff(from: Date, to: Date): number {
  return Math.round((Date.UTC(to.getFullYear(), to.getMonth(), to.getDate()) - Date.UTC(from.getFullYear(), from.getMonth(), from.getDate())) / DAY);
}

function startOfDay(date: Date): Date {
  const start = new Date(date);
  start.setHours(0, 0, 0, 0);
  return start;
}

function timeOffset(from: Date, to: Date, dayWidth: number): number {
  const dayStart = startOfDay(to);
  const fraction = (to.getTime() - dayStart.getTime()) / (addDays(dayStart, 1).getTime() - dayStart.getTime());
  return (dayDiff(from, to) + fraction) * dayWidth;
}

function dateLabel(date: Date): string {
  return `${date.getMonth() + 1}/${date.getDate()}`;
}

function fullDate(date: Date): string {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

const statusBar = {
  completed: { fill: "bg-emerald-500", label: "已完成" },
  overdue: { fill: "bg-red-500", label: "超时" },
  active: { fill: "bg-blue-500", label: "进行中" },
  inactive: { fill: "bg-slate-400", label: "待接受 / 已结束" },
};

export function CaseGanttView({ caseItem, tasks, onTaskClick }: Props) {
  const [density, setDensity] = useState<"day" | "week">("day");
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 60000);
    return () => clearInterval(timer);
  }, []);

  const ganttTasks = useMemo<GanttTask[]>(() => {
    return flattenTasks(tasks)
      .map(({ task, depth, path }) => {
        const timeline = taskLifecycleTimes(task, now);
        return {
          task,
          depth,
          path,
          isThought: !task.code,
          start: parseDate(timeline.start),
          end: parseDate(timeline.end),
          timeline,
        };
      });
  }, [tasks, now]);

  const bounds = useMemo(() => {
    const executableTasks = ganttTasks.filter(item => !item.isThought && item.start && item.end && item.end >= item.start);
    if (!executableTasks.length) {
      const start = startOfDay(now);
      return { start, end: addDays(start, 7) };
    }
    const earliest = new Date(Math.min(...executableTasks.map(item => item.start!.getTime())));
    const latest = new Date(Math.max(...executableTasks.map(item => item.end!.getTime())));
    return { start: addDays(startOfDay(earliest), -1), end: addDays(startOfDay(latest), 1) };
  }, [ganttTasks, now]);

  if (!ganttTasks.length) {
    return (
      <div className="grid min-h-[320px] place-items-center text-sm text-slate-400">
        <span className="inline-flex items-center gap-2"><ChartGantt size={17} />暂无可展示的任务</span>
      </div>
    );
  }

  const dayWidth = density === "day" ? 38 : 16;
  const totalDays = Math.max(2, dayDiff(bounds.start, bounds.end) + 1);
  const timelineWidth = totalDays * dayWidth;
  const dates = Array.from({ length: totalDays }, (_, index) => addDays(bounds.start, index));
  const todayOffset = now >= bounds.start && now < addDays(bounds.end, 1) ? timeOffset(bounds.start, now, dayWidth) : null;

  return (
    <div role="region" aria-label={`${caseItem.name}任务甘特图`} className="overflow-hidden rounded-lg border border-slate-200 bg-white">
      <div className="flex h-12 items-center gap-3 border-b border-slate-200 px-4">
        <span className="inline-flex items-center gap-2 text-sm font-semibold text-slate-800"><ChartGantt size={15} className="text-[#0052D9]" />任务甘特图</span>
        <span className="text-[10.5px] text-slate-400">{ganttTasks.filter((item) => item.isThought).length} 个思路 · {ganttTasks.filter((item) => !item.isThought).length} 个任务</span>
        <div className="ml-auto flex items-center gap-3 text-[10.5px] text-slate-500">{["completed", "overdue", "active"].map(state => <span key={state} className="inline-flex items-center gap-1"><span className={`h-2 w-2 rounded-sm ${statusBar[state as keyof typeof statusBar].fill}`} />{statusBar[state as keyof typeof statusBar].label}</span>)}</div>
        <div className="inline-flex rounded-md border border-slate-200 bg-slate-50 p-0.5">
          <button type="button" aria-pressed={density === "day"} onClick={() => setDensity("day")} className={`h-6 rounded px-2 text-[10.5px] ${density === "day" ? "bg-white font-medium text-[#0052D9] shadow-sm" : "text-slate-500"}`}>日</button>
          <button type="button" aria-pressed={density === "week"} onClick={() => setDensity("week")} className={`h-6 rounded px-2 text-[10.5px] ${density === "week" ? "bg-white font-medium text-[#0052D9] shadow-sm" : "text-slate-500"}`}>周</button>
        </div>
      </div>

      <div className="max-h-[560px] overflow-auto">
        <div style={{ minWidth: 320 + timelineWidth }}>
          <div className="sticky top-0 z-20 flex h-12 border-b border-slate-200 bg-slate-50">
            <div className="sticky left-0 z-30 flex w-[320px] shrink-0 items-center border-r border-slate-200 bg-slate-50 px-3 text-[10.5px] font-semibold text-slate-500">思路 / 任务 / 负责人</div>
            <div className="relative flex" style={{ width: timelineWidth }}>
              {dates.map((date, index) => {
                const showLabel = density === "day" || index % 7 === 0;
                return (
                  <div key={date.toISOString()} className={`h-12 shrink-0 border-r border-slate-200/80 text-center ${date.getDay() === 0 || date.getDay() === 6 ? "bg-slate-100/70" : ""}`} style={{ width: dayWidth }}>
                    {showLabel && <><div className="mt-2 text-[9.5px] font-medium text-slate-500">{dateLabel(date)}</div>{density === "day" && <div className="mt-0.5 text-[8.5px] text-slate-400">{["日", "一", "二", "三", "四", "五", "六"][date.getDay()]}</div>}</>}
                  </div>
                );
              })}
            </div>
          </div>

          {ganttTasks.map(({ task, depth, path, isThought, start, end, timeline }) => {
            if (isThought) {
              const directTasks = (task.children ?? []).filter((child) => Boolean(child.code)).length;
              return (
                <div key={task.id} className="flex min-h-[46px] border-b border-[#0052D9]/10 bg-[#0052D9]/[0.035]">
                  <div className="sticky left-0 z-10 flex w-[320px] shrink-0 items-center border-r border-slate-200 bg-[#F7FAFF] px-3">
                    <div className="min-w-0" style={{ paddingLeft: depth * 20 }}>
                      <div className="flex min-w-0 items-center gap-1.5">
                        {depth > 0 && <span className="text-slate-300">└</span>}
                        <span className="inline-flex shrink-0 items-center gap-1 rounded border border-amber-200 bg-amber-50 px-1.5 py-0.5 text-[9px] text-amber-700"><Lightbulb size={9} />思路</span>
                        <span className="truncate text-[11px] font-semibold text-slate-700">{task.title}</span>
                      </div>
                      <div className="mt-0.5 text-[9px] text-slate-400">{directTasks} 个直接任务{path.length > 0 ? ` · 上级：${path[path.length - 1]}` : ""}</div>
                    </div>
                  </div>
                  <div className="relative min-h-[46px] bg-[#0052D9]/[0.018]" style={{ width: timelineWidth, backgroundImage: `repeating-linear-gradient(to right, transparent 0, transparent ${dayWidth - 1}px, rgb(226 232 240 / 0.55) ${dayWidth - 1}px, rgb(226 232 240 / 0.55) ${dayWidth}px)` }}>
                    {todayOffset !== null && <div className="absolute inset-y-0 z-10 w-px bg-red-400/70" style={{ left: todayOffset }} title="今天" />}
                  </div>
                </div>
              );
            }
            const hasRange = start && end && end >= start;
            const left = hasRange ? timeOffset(bounds.start, start, dayWidth) : 0;
            const width = hasRange ? Math.max(8, timeOffset(bounds.start, end, dayWidth) - left) : 0;
            const accepted = parseDate(timeline.acceptedAt);
            const acceptedOffset = hasRange && accepted && accepted >= start && accepted <= end ? timeOffset(bounds.start, accepted, dayWidth) - left : null;
            const colors = statusBar[timeline.state];
            const stateLabel = timeline.state === "inactive" ? task.status : colors.label;
            const incomplete = !timeline.createdAt || (["已完成", "已拒绝", "已中止"].includes(task.status) && !timeline.endedAt);
            const tooltip = `${task.title}\n创建：${formatCaseTime(timeline.createdAt)}\n接受开始：${timeline.acceptedAt ? formatCaseTime(timeline.acceptedAt) : task.status === "待接受" ? "尚未接受" : "未记录"}\n${task.status === "已完成" ? `完成：${formatCaseTime(timeline.completedAt)}` : ["已拒绝", "已中止"].includes(task.status) ? `结束：${formatCaseTime(timeline.endedAt)}` : `截至：${formatCaseTime(now.toISOString())}`}\n${stateLabel} · ${task.owner}`;
            return (
              <div key={task.id} data-gantt-row={task.id} className="flex min-h-[64px] border-b border-slate-100 last:border-b-0 hover:bg-slate-50/60">
                <button type="button" onClick={() => onTaskClick(task.id)} className="sticky left-0 z-10 flex w-[320px] shrink-0 items-center border-r border-slate-200 bg-white px-3 text-left hover:bg-slate-50">
                  <span className="flex min-w-0 flex-1 items-stretch gap-2" style={{ paddingLeft: depth * 20 }}>
                    <span className={`w-[3px] shrink-0 rounded-full ${urgencyBar[task.urgency]}`} aria-hidden="true" />
                    <span className="flex min-w-0 flex-1 items-center gap-2">
                      <StatusBadge status={task.status} size={17} />
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-[11.5px] font-medium text-slate-700">{depth > 0 && <span className="mr-1 text-slate-300">└</span>}{task.title}</span>
                        <span className="mt-1 flex items-center gap-1.5 truncate text-[9.5px] text-slate-400"><span className="font-mono">{task.code ?? task.id}</span><span>·</span><span>{task.owner}</span></span>
                      </span>
                    </span>
                  </span>
                </button>
                <div
                  className="relative min-h-[64px]"
                  style={{
                    width: timelineWidth,
                    backgroundImage: `repeating-linear-gradient(to right, transparent 0, transparent ${dayWidth - 1}px, rgb(226 232 240 / 0.7) ${dayWidth - 1}px, rgb(226 232 240 / 0.7) ${dayWidth}px)`,
                  }}
                >
                  {todayOffset !== null && <div className="absolute inset-y-0 z-10 w-px bg-red-400/70" style={{ left: todayOffset }} title="今天" />}
                  {hasRange ? <button
                    type="button"
                    onClick={() => onTaskClick(task.id)}
                    data-gantt-bar={task.id}
                    data-gantt-state={timeline.state}
                    data-start={timeline.start}
                    data-end={timeline.end}
                    aria-label={tooltip}
                    className={`absolute top-1/2 h-7 -translate-y-1/2 overflow-hidden rounded text-left shadow-sm ${colors.fill} ${incomplete ? "border border-dashed border-slate-700" : "border border-transparent"}`}
                    style={{ left, width }}
                    title={tooltip}
                  >
                    {timeline.createdAt && <span data-gantt-milestone="created" title={`创建：${formatCaseTime(timeline.createdAt)}`} className="absolute left-0.5 top-1/2 h-1.5 w-1.5 -translate-y-1/2 rounded-full border border-white" />}
                    {acceptedOffset !== null && <span data-gantt-milestone="accepted" data-at={timeline.acceptedAt} title={`接受开始：${formatCaseTime(timeline.acceptedAt)}`} className="absolute inset-y-0 w-0.5" style={{ left: Math.min(Math.max(0, acceptedOffset), width - 4) }}><span className="absolute inset-x-0 top-0 h-1.5 bg-white/90" /><span className="absolute inset-x-0 bottom-0 h-1.5 bg-white/90" /></span>}
                    {timeline.completedAt && <span data-gantt-milestone="completed" title={`完成：${formatCaseTime(timeline.completedAt)}`} className="absolute right-0.5 top-1/2 h-1.5 w-1.5 -translate-y-1/2 rotate-45 bg-white" />}
                    {width >= 80 && <span className="relative z-10 block truncate px-3 text-[10px] font-medium leading-[26px] text-white">{stateLabel} · {task.owner}</span>}
                  </button> : <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[10.5px] text-slate-400" title={tooltip}>时间未记录</span>}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="flex h-9 items-center gap-4 border-t border-slate-100 px-4 text-[9.5px] text-slate-400">
        <span className="inline-flex items-center gap-1"><CalendarDays size={11} />时间范围 {fullDate(bounds.start)} 至 {fullDate(bounds.end)}</span>
        <div className="ml-auto flex items-center gap-3"><span className="inline-flex items-center gap-1"><span className="h-1.5 w-1.5 rounded-full border border-slate-400" />创建</span><span className="inline-flex items-center gap-1"><span className="h-3 w-0.5 bg-slate-400" />接受开始</span><span className="inline-flex items-center gap-1"><span className="h-1.5 w-1.5 rotate-45 bg-slate-400" />完成</span></div>
      </div>
    </div>
  );
}