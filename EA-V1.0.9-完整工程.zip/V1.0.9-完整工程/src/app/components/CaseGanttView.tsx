import { useMemo, useState } from "react";
import { CalendarDays, ChartGantt, Lightbulb } from "lucide-react";
import { CaseItem, flattenTasks, TaskNode, urgencyBar } from "./data";
import { StatusBadge } from "./StatusBadge";

interface Props {
  caseItem: CaseItem;
  tasks: TaskNode[];
  onTaskClick: (taskId: string) => void;
}

interface GanttTask {
  task: TaskNode;
  depth: number;
  path: string[];
  isThought: boolean;
  start: Date;
  end: Date;
  estimated: boolean;
}

const DAY = 24 * 60 * 60 * 1000;

function parseDate(value?: string): Date | null {
  if (!value) return null;
  const date = new Date(`${value.slice(0, 10)}T00:00:00`);
  return Number.isNaN(date.getTime()) ? null : date;
}

function addDays(date: Date, days: number): Date {
  return new Date(date.getTime() + days * DAY);
}

function dayDiff(from: Date, to: Date): number {
  return Math.round((to.getTime() - from.getTime()) / DAY);
}

function dateLabel(date: Date): string {
  return `${date.getMonth() + 1}/${date.getDate()}`;
}

function fullDate(date: Date): string {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

const statusBar: Record<TaskNode["status"], { base: string; fill: string }> = {
  待接受: { base: "bg-slate-100", fill: "bg-slate-400" },
  进行中: { base: "bg-blue-50", fill: "bg-blue-500" },
  已拒绝: { base: "bg-slate-100", fill: "bg-slate-400" },
  已完成: { base: "bg-emerald-50", fill: "bg-emerald-500" },
  已中止: { base: "bg-slate-100", fill: "bg-slate-400" },
};

export function CaseGanttView({ caseItem, tasks, onTaskClick }: Props) {
  const [density, setDensity] = useState<"day" | "week">("day");

  const ganttTasks = useMemo<GanttTask[]>(() => {
    const caseStart = parseDate(caseItem.createdAt) ?? new Date();
    return flattenTasks(tasks)
      .map(({ task, depth, path }) => {
        const startedEntry = task.statusHistory?.find((entry) => entry.status === "进行中");
        const firstEntry = task.statusHistory?.[0];
        const completedEntry = [...(task.statusHistory ?? [])].reverse().find((entry) => entry.status === "已完成");
        const start = parseDate(startedEntry?.at) ?? parseDate(firstEntry?.at) ?? caseStart;
        const explicitEnd = parseDate(completedEntry?.at) ?? parseDate(task.dueDate) ?? parseDate(task.requestedDueDate);
        const end = explicitEnd && explicitEnd >= start ? explicitEnd : addDays(start, 1);
        return {
          task,
          depth,
          path,
          isThought: !task.code,
          start,
          end,
          estimated: !startedEntry || !explicitEnd,
        };
      });
  }, [caseItem.createdAt, tasks]);

  const bounds = useMemo(() => {
    if (!ganttTasks.length) {
      const start = parseDate(caseItem.createdAt) ?? new Date();
      return { start, end: addDays(start, 7) };
    }
    const executableTasks = ganttTasks.filter((item) => !item.isThought);
    const earliest = new Date(Math.min(...executableTasks.map((item) => item.start.getTime())));
    const latest = new Date(Math.max(...executableTasks.map((item) => item.end.getTime())));
    return { start: addDays(earliest, -1), end: addDays(latest, 1) };
  }, [caseItem.createdAt, ganttTasks]);

  if (!ganttTasks.length) {
    return (
      <div className="grid min-h-[320px] place-items-center text-sm text-slate-400">
        <span className="inline-flex items-center gap-2"><ChartGantt size={17} />暂无可展示的任务</span>
      </div>
    );
  }

  const dayWidth = density === "day" ? 38 : 16;
  const totalDays = Math.max(2, dayDiff(bounds.start, bounds.end) + 1);
  const timelineWidth = totalDays * dayWidth;
  const dates = Array.from({ length: totalDays }, (_, index) => addDays(bounds.start, index));
  const today = parseDate(new Date().toISOString());
  const todayOffset = today && today >= bounds.start && today <= bounds.end ? dayDiff(bounds.start, today) * dayWidth : null;

  return (
    <div className="overflow-hidden rounded-lg border border-slate-200 bg-white">
      <div className="flex h-12 items-center gap-3 border-b border-slate-200 px-4">
        <span className="inline-flex items-center gap-2 text-sm font-semibold text-slate-800"><ChartGantt size={15} className="text-[#0052D9]" />任务甘特图</span>
        <span className="text-[10.5px] text-slate-400">{ganttTasks.filter((item) => item.isThought).length} 个思路 · {ganttTasks.filter((item) => !item.isThought).length} 个任务</span>
        <span className="ml-auto text-[10.5px] text-slate-400">虚线边框表示日期区间含估算</span>
        <div className="inline-flex rounded-md border border-slate-200 bg-slate-50 p-0.5">
          <button type="button" onClick={() => setDensity("day")} className={`h-6 rounded px-2 text-[10.5px] ${density === "day" ? "bg-white font-medium text-[#0052D9] shadow-sm" : "text-slate-500"}`}>日</button>
          <button type="button" onClick={() => setDensity("week")} className={`h-6 rounded px-2 text-[10.5px] ${density === "week" ? "bg-white font-medium text-[#0052D9] shadow-sm" : "text-slate-500"}`}>周</button>
        </div>
      </div>

      <div className="max-h-[560px] overflow-auto">
        <div style={{ minWidth: 320 + timelineWidth }}>
          <div className="sticky top-0 z-20 flex h-12 border-b border-slate-200 bg-slate-50">
            <div className="sticky left-0 z-30 flex w-[320px] shrink-0 items-center border-r border-slate-200 bg-slate-50 px-3 text-[10.5px] font-semibold text-slate-500">思路 / 任务 / 负责人</div>
            <div className="relative flex" style={{ width: timelineWidth }}>
              {dates.map((date, index) => {
                const showLabel = density === "day" || index % 7 === 0;
                return (
                  <div key={date.toISOString()} className={`h-12 shrink-0 border-r border-slate-200/80 text-center ${date.getDay() === 0 || date.getDay() === 6 ? "bg-slate-100/70" : ""}`} style={{ width: dayWidth }}>
                    {showLabel && <><div className="mt-2 text-[9.5px] font-medium text-slate-500">{dateLabel(date)}</div>{density === "day" && <div className="mt-0.5 text-[8.5px] text-slate-400">{["日", "一", "二", "三", "四", "五", "六"][date.getDay()]}</div>}</>}
                  </div>
                );
              })}
            </div>
          </div>

          {ganttTasks.map(({ task, depth, path, isThought, start, end, estimated }) => {
            if (isThought) {
              const directTasks = (task.children ?? []).filter((child) => Boolean(child.code)).length;
              return (
                <div key={task.id} className="flex min-h-[46px] border-b border-[#0052D9]/10 bg-[#0052D9]/[0.035]">
                  <div className="sticky left-0 z-10 flex w-[320px] shrink-0 items-center border-r border-slate-200 bg-[#F7FAFF] px-3">
                    <div className="min-w-0" style={{ paddingLeft: depth * 20 }}>
                      <div className="flex min-w-0 items-center gap-1.5">
                        {depth > 0 && <span className="text-slate-300">└</span>}
                        <span className="inline-flex shrink-0 items-center gap-1 rounded border border-amber-200 bg-amber-50 px-1.5 py-0.5 text-[9px] text-amber-700"><Lightbulb size={9} />思路</span>
                        <span className="truncate text-[11px] font-semibold text-slate-700">{task.title}</span>
                      </div>
                      <div className="mt-0.5 text-[9px] text-slate-400">{directTasks} 个直接任务{path.length > 0 ? ` · 上级：${path[path.length - 1]}` : ""}</div>
                    </div>
                  </div>
                  <div className="relative min-h-[46px] bg-[#0052D9]/[0.018]" style={{ width: timelineWidth, backgroundImage: `repeating-linear-gradient(to right, transparent 0, transparent ${dayWidth - 1}px, rgb(226 232 240 / 0.55) ${dayWidth - 1}px, rgb(226 232 240 / 0.55) ${dayWidth}px)` }}>
                    {todayOffset !== null && <div className="absolute inset-y-0 z-10 w-px bg-red-400/70" style={{ left: todayOffset }} title="今天" />}
                  </div>
                </div>
              );
            }
            const left = dayDiff(bounds.start, start) * dayWidth + 3;
            const width = Math.max(dayWidth - 6, (dayDiff(start, end) + 1) * dayWidth - 6);
            const colors = statusBar[task.status];
            return (
              <div key={task.id} className="flex min-h-[64px] border-b border-slate-100 last:border-b-0 hover:bg-slate-50/60">
                <button type="button" onClick={() => onTaskClick(task.id)} className="sticky left-0 z-10 flex w-[320px] shrink-0 items-center border-r border-slate-200 bg-white px-3 text-left hover:bg-slate-50">
                  <span className="flex min-w-0 flex-1 items-stretch gap-2" style={{ paddingLeft: depth * 20 }}>
                    <span className={`w-[3px] shrink-0 rounded-full ${urgencyBar[task.urgency]}`} aria-hidden="true" />
                    <span className="flex min-w-0 flex-1 items-center gap-2">
                      <StatusBadge status={task.status} size={17} />
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-[11.5px] font-medium text-slate-700">{depth > 0 && <span className="mr-1 text-slate-300">└</span>}{task.title}</span>
                        <span className="mt-1 flex items-center gap-1.5 truncate text-[9.5px] text-slate-400"><span className="font-mono">{task.code ?? task.id}</span><span>·</span><span>{task.owner}</span></span>
                      </span>
                    </span>
                  </span>
                </button>
                <div
                  className="relative min-h-[64px]"
                  style={{
                    width: timelineWidth,
                    backgroundImage: `repeating-linear-gradient(to right, transparent 0, transparent ${dayWidth - 1}px, rgb(226 232 240 / 0.7) ${dayWidth - 1}px, rgb(226 232 240 / 0.7) ${dayWidth}px)`,
                  }}
                >
                  {todayOffset !== null && <div className="absolute inset-y-0 z-10 w-px bg-red-400/70" style={{ left: todayOffset }} title="今天" />}
                  <button
                    type="button"
                    onClick={() => onTaskClick(task.id)}
                    className={`absolute top-1/2 h-7 -translate-y-1/2 overflow-hidden rounded-md text-left shadow-sm ${colors.base} ${estimated ? "border border-dashed border-slate-400" : "border border-transparent"}`}
                    style={{ left, width }}
                    title={`${task.title}\n${fullDate(start)} 至 ${fullDate(end)}${estimated ? "（含估算）" : ""}\n${task.status} · ${task.progress}%`}
                  >
                    <span className={`absolute inset-y-0 left-0 opacity-90 ${colors.fill}`} style={{ width: `${Math.max(0, Math.min(100, task.progress))}%` }} />
                    <span className="relative z-10 block truncate px-2 text-[10px] font-medium leading-[26px] text-slate-800 mix-blend-multiply">{task.progress}% · {task.owner}</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="flex h-9 items-center gap-4 border-t border-slate-100 px-4 text-[9.5px] text-slate-400">
        <span className="inline-flex items-center gap-1"><CalendarDays size={11} />时间范围 {fullDate(bounds.start)} 至 {fullDate(bounds.end)}</span>
        <span className="ml-auto">点击任务名称或时间条查看任务详情</span>
      </div>
    </div>
  );
}