/**
 * 单色进度环 —— Case / 任务进度统一用它（参考状态方案 F 的单色进度环）。
 * 灰色轨道 + 深灰进度弧，零彩色；可选环内百分比文字。
 */
export function ProgressRing({
  value,
  size = 18,
  stroke = 2.5,
  showValue = false,
  track = "#e2e8f0",
  arc = "#475569",
}: {
  value: number;
  size?: number;
  stroke?: number;
  showValue?: boolean;
  track?: string;
  arc?: string;
}) {
  const v = Math.max(0, Math.min(100, value));
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const off = c * (1 - v / 100);
  return (
    <span
      className="relative inline-flex items-center justify-center shrink-0"
      style={{ width: size, height: size }}
      title={`进度 ${Math.round(v)}%`}
    >
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="block">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={track} strokeWidth={stroke} />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={arc}
          strokeWidth={stroke}
          strokeDasharray={c}
          strokeDashoffset={off}
          strokeLinecap="round"
          transform={`rotate(-90 ${size / 2} ${size / 2})`}
        />
      </svg>
      {showValue && (
        <span
          className="absolute inset-0 flex items-center justify-center tabular-nums text-slate-600"
          style={{ fontSize: Math.max(8, size * 0.3) }}
        >
          {Math.round(v)}
        </span>
      )}
    </span>
  );
}
