// PTE AI 大赛 · Skill 开发市场 —— 模块单例存储（含 localStorage 持久化与订阅）
import { useEffect, useState } from "react";
import { currentUser } from "./data";

export interface Skill {
  id: string;
  name: string;
  category: string; // 分类：分析 / 自动化 / 报告 / 数据 / 其他
  author: string;
  description: string;
  tags: string[];
  installs: number; // 被引用/安装次数
  rating: number;   // 1–5
  status: "已发布" | "草稿";
  updatedAt: string;
}

export const SKILL_CATEGORIES = ["失效分析", "测试自动化", "数据处理", "报告生成", "知识问答", "其他"] as const;

const KEY = "ea_ai_skills_v1";

const SEED: Skill[] = [
  { id: "sk-001", name: "FSA 失效模式自动归类", category: "失效分析", author: "张伟", description: "根据 bitmap 与测试项自动归类失效模式，输出 Top 失效 bin 与建议下一步动作。", tags: ["FSA", "bitmap", "归类"], installs: 128, rating: 5, status: "已发布", updatedAt: "2026-06-28" },
  { id: "sk-002", name: "测试程式 timing 体检", category: "测试自动化", author: "刘洋", description: "扫描测试程式 timing set，标记 setup/hold 余量不足项并给出修正建议。", tags: ["程式", "timing", "体检"], installs: 86, rating: 4, status: "已发布", updatedAt: "2026-06-25" },
  { id: "sk-003", name: "日报管理", category: "报告生成", author: "王芳", description: "按日期管理日报会话，合并工作笔记并生成结构化日报，支持下载与 HEMS 推送。", tags: ["日报", "笔记合并", "HEMS"], installs: 203, rating: 5, status: "已发布", updatedAt: "2026-08-17" },
  { id: "sk-004", name: "良率异常波动预警", category: "数据处理", author: "赵敏", description: "对接 CP/FT 良率数据，检测异常波动并按站点推送预警。", tags: ["良率", "预警", "SPC"], installs: 54, rating: 4, status: "已发布", updatedAt: "2026-06-20" },
  { id: "sk-005", name: "EA 知识库智能问答", category: "知识问答", author: "陈磊", description: "基于历史 Case 与 SOP 的检索增强问答，回答失效分析常见问题。", tags: ["RAG", "知识库", "问答"], installs: 171, rating: 5, status: "已发布", updatedAt: "2026-07-02" },
];

let cache: Skill[] | null = null;
const listeners = new Set<() => void>();

function load(): Skill[] {
  if (cache) return cache;
  try {
    const raw = typeof localStorage !== "undefined" ? localStorage.getItem(KEY) : null;
    cache = raw ? (JSON.parse(raw) as Skill[]) : [...SEED];
    const dailyReport = SEED.find((skill) => skill.id === "sk-003");
    if (dailyReport) cache = cache.map((skill) => skill.id === dailyReport.id ? { ...skill, ...dailyReport } : skill);
  } catch {
    cache = [...SEED];
  }
  return cache;
}

function persist() {
  try {
    if (cache) localStorage.setItem(KEY, JSON.stringify(cache));
  } catch {}
}

function notify() {
  persist();
  listeners.forEach((fn) => fn());
}

const today = () => new Date().toISOString().slice(0, 10);

export function listSkills(): Skill[] {
  return [...load()];
}

export function upsertSkill(input: Omit<Skill, "id" | "installs" | "rating" | "updatedAt"> & { id?: string }) {
  const s = load();
  if (input.id) {
    const idx = s.findIndex((x) => x.id === input.id);
    if (idx >= 0) s[idx] = { ...s[idx], ...input, updatedAt: today() };
  } else {
    s.unshift({
      id: `sk-${Date.now()}`,
      installs: 0,
      rating: 5,
      updatedAt: today(),
      ...input,
    });
  }
  notify();
}

export function removeSkill(id: string) {
  cache = load().filter((x) => x.id !== id);
  notify();
}

export function useSkills() {
  const [, setTick] = useState(0);
  useEffect(() => {
    const fn = () => setTick((t) => t + 1);
    listeners.add(fn);
    return () => { listeners.delete(fn); };
  }, []);
  return { skills: listSkills(), upsert: upsertSkill, remove: removeSkill, currentUser };
}
