import { CASE_CUSTOM_FIELDS, type CustomFieldDefinition } from "./caseCustomFilterFields";
import type { CaseItem, TaskNode } from "./data";
import type { ClosureRecord } from "./closures";

export type CustomFilterOperator = "in" | "notIn" | "contains" | "notContains" | "gt" | "gte" | "lt" | "lte" | "between" | "empty" | "notEmpty";
export interface CustomFilterRule { id: string; fieldId: string; operator: CustomFilterOperator; values: string[] }
// 当前 UI 只提供值选择；旧操作符草稿不应变成不可见的限制。
export function customSelectionRules(rules: CustomFilterRule[]): CustomFilterRule[] {
  return rules.map(rule => rule.operator === "in" ? rule : { ...rule, operator: "in", values: [] });
}
export interface CustomFilterRecord { caseData: Record<string, unknown>; tasks: TaskNode[] }
export const CUSTOM_FILTER_OPERATORS: { value: CustomFilterOperator; label: string }[] = [
  { value: "in", label: "是其中之一" }, { value: "notIn", label: "不是任一项" },
  { value: "contains", label: "包含" }, { value: "notContains", label: "不包含" },
  { value: "gt", label: "大于 / 晚于" }, { value: "gte", label: "大于等于 / 不早于" },
  { value: "lt", label: "小于 / 早于" }, { value: "lte", label: "小于等于 / 不晚于" },
  { value: "between", label: "介于（含边界）" }, { value: "empty", label: "为空" }, { value: "notEmpty", label: "不为空" },
];
export function customFieldOperators(field: CustomFieldDefinition) {
  return CUSTOM_FILTER_OPERATORS.filter(({ value }) => ["in", "notIn", "empty", "notEmpty"].includes(value) ||
    (field.type === "text" ? ["contains", "notContains"].includes(value) : field.type !== "boolean" && ["gt", "gte", "lt", "lte", "between"].includes(value)));
}
const isObject = (value: unknown): value is Record<string, unknown> => Boolean(value) && typeof value === "object" && !Array.isArray(value);
const own = (value: Record<string, unknown>, key: string) => Object.prototype.hasOwnProperty.call(value, key) ? value[key] : undefined;
const payloadKey = /^(url|voiceNote|map|password|token|secret|dataUrl|base64)$/i;
const unsafePath = (path: readonly string[]) => path.some(key => ["__proto__", "constructor", "prototype"].includes(key));
const isPayload = (value: string) => /^\s*(data:|blob:)/i.test(value);
function dateDay(value: unknown): string | undefined {
  if (typeof value !== "string") return;
  const match = /^(\d{4}-\d{2}-\d{2})(?:$|[T ][0-9])/.exec(value);
  if (!match) return;
  const time = Date.parse(`${match[1]}T00:00:00Z`);
  if (Number.isFinite(time) && new Date(time).toISOString().slice(0, 10) === match[1]) return match[1];
}
function canonical(value: unknown, field: CustomFieldDefinition): string | undefined {
  if (field.type === "boolean") return typeof value === "boolean" ? String(value) : undefined;
  if (field.type === "date") return dateDay(value);
  if (field.type === "number") {
    if ((typeof value !== "number" && typeof value !== "string") || String(value).trim() === "") return;
    const number = Number(value);
    return Number.isFinite(number) ? String(number) : undefined;
  }
  if (!["string", "number", "boolean"].includes(typeof value)) return;
  const text = String(value);
  return text.trim() && !isPayload(text) ? text : undefined;
}
function readPath(root: unknown, path: readonly string[], mode: CustomFieldDefinition["mode"]): unknown[] {
  if (!path.length) {
    if (mode === "count") return [Array.isArray(root) ? root.length : isObject(root) ? Object.keys(root).length : 0];
    if (mode === "present") return [root !== null && root !== undefined && root !== "" && (!Array.isArray(root) || root.length > 0)];
    return Array.isArray(root) ? root.flatMap(value => readPath(value, [], mode)) : [root];
  }
  if (Array.isArray(root)) return root.flatMap(value => readPath(value, path, mode));
  if (!isObject(root)) return readPath(undefined, [], mode);
  const [key, ...rest] = path;
  if (key === "*") return Object.values(root).flatMap(value => readPath(value, rest, mode));
  return readPath(own(root, key), rest, mode);
}
export function customFieldValues(root: unknown, field: CustomFieldDefinition): string[] {
  if (unsafePath(field.path) || (field.mode !== "present" && field.path.some(key => payloadKey.test(key)))) return [];
  return [...new Set(readPath(root, field.path, field.mode).map(value => canonical(value, field)).filter((value): value is string => value !== undefined))];
}
export function customValueLabel(value: string, field: CustomFieldDefinition) {
  return field.type === "boolean" ? value === "true" ? "是" : "否" : value;
}
export function customRuleError(rule: CustomFilterRule, field?: CustomFieldDefinition): string {
  if (!field) return "字段已不可用，请移除此条件";
  if (!customFieldOperators(field).some(option => option.value === rule.operator)) return "请选择有效的筛选方式";
  if (["empty", "notEmpty"].includes(rule.operator)) return "";
  if (!Array.isArray(rule.values) || rule.values.some(value => typeof value !== "string")) return "存在无效筛选值";
  if (rule.operator === "in" || rule.operator === "notIn") {
    if (!rule.values.length) return "请选择筛选项";
    return rule.values.every(value => canonical(field.type === "boolean" ? value === "true" ? true : value === "false" ? false : undefined : value, field) !== undefined) ? "" : "存在无效筛选值";
  }
  if (["contains", "notContains"].includes(rule.operator)) return rule.values[0]?.trim() && !isPayload(rule.values[0]) ? "" : "请输入筛选内容";
  const expected = rule.operator === "between" ? 2 : 1;
  if (rule.values.length < expected || rule.values.slice(0, expected).some(value => canonical(value, field) === undefined)) return field.type === "date" ? "请输入有效日期" : "请输入有效数字";
  const values = rule.values.slice(0, expected).map(value => field.type === "date" ? Date.parse(dateDay(value)!) : Number(value));
  return expected === 2 && values[0] > values[1] ? "起始值不能大于结束值" : "";
}
export function activeCustomRules(rules: CustomFilterRule[], fields: readonly CustomFieldDefinition[]) {
  const byId = new Map(fields.map(field => [field.id, field]));
  return rules.filter(rule => !customRuleError(rule, byId.get(rule.fieldId)));
}
function matchesRule(root: unknown, field: CustomFieldDefinition, rule: CustomFilterRule) {
  const values = customFieldValues(root, field);
  if (rule.operator === "empty") return !values.length;
  if (rule.operator === "notEmpty") return Boolean(values.length);
  // 未填写值不与“不等于”混为一谈；可显式选择“为空”。
  if (!values.length) return false;
  const selected = rule.values.map(value => canonical(field.type === "boolean" ? value === "true" : value, field));
  if (rule.operator === "in") return values.some(value => selected.includes(value));
  if (rule.operator === "notIn") return values.every(value => !selected.includes(value));
  const query = rule.values[0]?.trim().toLocaleLowerCase();
  if (rule.operator === "contains") return values.some(value => value.toLocaleLowerCase().includes(query));
  if (rule.operator === "notContains") return values.every(value => !value.toLocaleLowerCase().includes(query));
  const numeric = (value: string) => field.type === "date" ? Date.parse(value) : Number(value);
  const first = numeric(selected[0]!), second = numeric(selected[1]!);
  return values.some(value => {
    const actual = numeric(value);
    switch (rule.operator) {
      case "gt": return actual > first;
      case "gte": return actual >= first;
      case "lt": return actual < first;
      case "lte": return actual <= first;
      case "between": return actual >= first && actual <= second;
      default: return false;
    }
  });
}
export function matchesCustomRules(record: CustomFilterRecord, rules: CustomFilterRule[], fields: readonly CustomFieldDefinition[]) {
  const byId = new Map(fields.map(field => [field.id, field]));
  const active = activeCustomRules(rules, fields).map(rule => ({ rule, field: byId.get(rule.fieldId)! }));
  const cases = active.filter(({ field }) => field.entity === "case"), tasks = active.filter(({ field }) => field.entity === "task");
  return cases.every(({ field, rule }) => matchesRule(record.caseData, field, rule)) && (!tasks.length || record.tasks.some(task => tasks.every(({ field, rule }) => matchesRule(task, field, rule))));
}
export function customFilterOptions(records: CustomFilterRecord[], field: CustomFieldDefinition) {
  const values = [...new Set(records.flatMap(record => (field.entity === "case" ? [record.caseData] : record.tasks).flatMap(root => customFieldValues(root, field))))];
  return values.sort((a, b) => field.type === "number" ? Number(a) - Number(b) : a.localeCompare(b, "zh-CN", { numeric: true }));
}
export function buildCustomFilterRecords(cases: CaseItem[], options: { loadTree: (c: CaseItem) => TaskNode[]; status: (c: CaseItem) => string; closure: (id: string) => ClosureRecord | undefined }): CustomFilterRecord[] {
  const flatten = (nodes: TaskNode[]): TaskNode[] => nodes.flatMap(node => [...(node.code ? [node] : []), ...flatten(node.children ?? [])]);
  return cases.map(c => {
    const tasks = flatten(options.loadTree(c));
    return { caseData: { ...c, storedStatus: c.status, status: options.status(c), closure: options.closure(c.id) ?? {}, tasks }, tasks };
  });
}

// 已知字段始终可添加；已有记录中的扩展字段补入目录，不序列化对象或文件载荷。
export function customFieldCatalog(records: CustomFilterRecord[]): CustomFieldDefinition[] {
  const fields = new Map(CASE_CUSTOM_FIELDS.map(field => [field.id, field]));
  const paths = new Set(CASE_CUSTOM_FIELDS.map(field => `${field.entity}:${field.path.join(".")}`));
  const wildcards = CASE_CUSTOM_FIELDS.filter(field => field.path.includes("*"));
  const registered = (entity: string, path: string[]) => paths.has(`${entity}:${path.join(".")}`) || wildcards.some(field => field.entity === entity && field.path.length === path.length && field.path.every((key, i) => key === "*" || key === path[i]));
  const walk = (value: unknown, entity: "case" | "task", path: string[], ancestors: Set<unknown>) => {
    if (path.length > 12 || unsafePath(path)) return;
    if ((entity === "case" && path[0] === "tasks") || (entity === "task" && path[0] === "children")) return;
    if (path.some(key => payloadKey.test(key))) return;
    if (Array.isArray(value)) {
      if (ancestors.has(value)) return;
      const next = new Set(ancestors).add(value);
      value.forEach(item => walk(item, entity, path, next)); return;
    }
    if (isObject(value)) {
      if (ancestors.has(value)) return;
      const next = new Set(ancestors).add(value);
      Object.entries(value).forEach(([key, child]) => walk(child, entity, [...path, key], next)); return;
    }
    if (!path.length || registered(entity, path) || value === null || value === undefined || (typeof value === "string" && isPayload(value))) return;
    if (!["string", "number", "boolean"].includes(typeof value)) return;
    const type = typeof value === "boolean" ? "boolean" : typeof value === "number" ? "number" : "text";
    const id = `${entity}:${path.join(".")}`;
    paths.add(id);
    fields.set(id, { id, entity, path, type, label: path.join(" · "), group: entity === "case" ? "Case 扩展字段" : "任务扩展字段" });
  };
  records.forEach(record => { walk(record.caseData, "case", [], new Set()); record.tasks.forEach(task => walk(task, "task", [], new Set())); });
  return [...fields.values()];
}