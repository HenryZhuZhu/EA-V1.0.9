import { Mic } from "lucide-react";
import { useEffect, useRef, useState } from "react";

interface Props {
  onTranscript: (text: string) => void;
  size?: "sm" | "md";
  className?: string;
  hint?: string;
  // sample lines used to simulate voice transcription
  samples?: string[];
}

const DEFAULT_SAMPLES = [
  "请协助核对最近一周的 datalog，重点对比基线分布。",
  "怀疑 Pattern timing margin 不足，需要安排小批量复测。",
  "请尽快回复进度，今晚 6 点前同步给我。",
  "麻烦@相关同学协同一下，明天上午 10 点对齐。",
];

export function VoiceInputButton({
  onTranscript,
  size = "sm",
  className = "",
  hint = "语音输入",
  samples = DEFAULT_SAMPLES,
}: Props) {
  const [recording, setRecording] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const timer = useRef<number | null>(null);

  useEffect(() => {
    if (recording) {
      timer.current = window.setInterval(() => setElapsed((e) => e + 1), 1000) as any;
    } else {
      if (timer.current) {
        clearInterval(timer.current);
        timer.current = null;
      }
      setElapsed(0);
    }
    return () => {
      if (timer.current) clearInterval(timer.current);
    };
  }, [recording]);

  const stop = () => {
    if (!recording) return;
    setRecording(false);
    const text = samples[Math.floor(Math.random() * samples.length)];
    onTranscript(text);
  };

  const dim = size === "sm" ? "h-7 w-7" : "h-9 w-9";
  return (
    <button
      type="button"
      title={recording ? "停止录音" : hint}
      onClick={() => (recording ? stop() : setRecording(true))}
      className={`${dim} inline-flex items-center justify-center rounded-md border transition-all shrink-0 ${
        recording
          ? "bg-red-500 border-red-500 text-white animate-pulse"
          : "bg-white border-slate-200 text-slate-500 hover:border-[#0052D9]/40 hover:text-[#0052D9]"
      } ${className}`}
    >
      <Mic size={size === "sm" ? 12 : 14} />
      {recording && <span className="ml-1 text-[10px] tabular-nums">{elapsed}s</span>}
    </button>
  );
}
