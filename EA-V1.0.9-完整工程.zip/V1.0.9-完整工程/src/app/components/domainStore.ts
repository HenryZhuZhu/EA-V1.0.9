// domainStore.ts —— 领域可变状态：共性问题 Issue + 项目/Checklist 检查项结果。
// 遵循仓库既有模式（subscriptions.ts / closures.ts）：module-singleton + localStorage + listeners。
// 以 data.ts 的 mock 常量为种子；提供 Issue 全生命周期管理与检查项 Fail→Issue 冒泡。
import { useEffect, useState } from "react";
import {
  Issue, Project, Checklist, CheckState, Fanout, FanoutStatus, IssueSource, IssueStatus, ObjectType, CheckItemResult, CaseItem,
  CaseLink, CaseLinkType, ProblemDomain, ProblemType,
  mockIssues, mockProjects, mockProducts, mockCases, mockCaseLinks, caseProductId, productById, stageDefById,
} from "./data";

const KEY = "ea_domain_v6";

interface DomainCache { issues: Issue[]; projects: Project[]; caseLinks: CaseLink[]; spawnedCases: CaseItem[]; moduleIcRelationsVersion?: number }
let cache: DomainCache | null = null;
const listeners = new Set<() => void>();

const clone = <T,>(x: T): T => JSON.parse(JSON.stringify(x));
const now = () => new Date().toISOString().slice(0, 16).replace("T", " ");
const today = () => new Date().toISOString().slice(0, 10).replace(/-/g, "");

function seed(): DomainCache { return { issues: clone(mockIssues), projects: clone(mockProjects), caseLinks: clone(mockCaseLinks), spawnedCases: [] }; }
// 把持久化的 Fail 派生 Case 回注到共享 mockCases，让所有读 mockCases 的界面都能看到
function injectSpawned(list: CaseItem[]) {
  list.forEach((sc) => { if (!mockCases.some((x) => x.id === sc.id)) mockCases.push(sc); });
}

function moduleIcLinks(child: CaseItem, cases: CaseItem[]): CaseLink[] {
  if (!["die/ic", "ic", "chip", "lot/ic"].includes(child.material.trim().toLowerCase())) return [];
  if (child.source === "fanout验证" || child.fanoutSourceCaseId) return [];
  const sourceIds = new Set([child.sourceModuleCaseId, child.parentCaseId, ...(child.relatedCaseIds ?? [])]);
  return cases.filter((source) => source.id !== child.id && ["DIMM", "CAMM"].includes(source.material.trim().toUpperCase())
    && source.source !== "fanout验证" && !source.fanoutSourceCaseId
    && (sourceIds.has(source.id) || source.childCaseIds?.includes(child.id) || source.relatedCaseIds?.includes(child.id)))
    .map((source) => ({ from: source.id, to: child.id, type: "关联", note: `由 ${source.material} 物料拆解 IC 建立，来源与新 Case 双向关联。` }));
}

function mergeCaseLinks(existing: CaseLink[], additions: CaseLink[]): CaseLink[] {
  const links = [...existing];
  const pairs = new Set(links.map((link) => JSON.stringify([link.from, link.to].sort())));
  additions.forEach((link) => {
    const pair = JSON.stringify([link.from, link.to].sort());
    if (!pairs.has(pair)) { links.push(link); pairs.add(pair); }
  });
  return links;
}

function syncRelatedCaseIds(c: DomainCache) {
  const byId = new Map<string, Set<string>>();
  c.caseLinks.forEach(({ from, to }) => {
    if (from === to) return;
    if (!byId.has(from)) byId.set(from, new Set());
    if (!byId.has(to)) byId.set(to, new Set());
    byId.get(from)!.add(to); byId.get(to)!.add(from);
  });
  [...mockCases, ...c.spawnedCases].forEach((item) => {
    const related = byId.get(item.id);
    if (related) item.relatedCaseIds = Array.from(new Set([...(item.relatedCaseIds ?? []), ...related]));
  });
}

function load(): DomainCache {
  if (cache) return cache;
  try {
    const raw = typeof localStorage !== "undefined" ? localStorage.getItem(KEY) : null;
    cache = raw ? JSON.parse(raw) : seed();
    if (cache && !cache.caseLinks) cache.caseLinks = clone(mockCaseLinks);
    if (cache && !cache.spawnedCases) cache.spawnedCases = [];
  } catch {
    cache = seed();
  }
  injectSpawned(cache!.spawnedCases);
  // 旧版只保留来源/单侧关联的模块→IC记录，一次性补齐关系边，不按名称猜测。
  if (cache!.moduleIcRelationsVersion !== 1) {
    cache!.caseLinks = mergeCaseLinks(cache!.caseLinks, mockCases.flatMap((item) => moduleIcLinks(item, mockCases)));
    cache!.moduleIcRelationsVersion = 1;
    syncRelatedCaseIds(cache!);
    try { if (typeof localStorage !== "undefined") localStorage.setItem(KEY, JSON.stringify(cache)); } catch { /* 只读环境仍可展示已恢复的关联 */ }
  } else syncRelatedCaseIds(cache!);
  return cache!;
}
function persist() {
  try { if (cache) localStorage.setItem(KEY, JSON.stringify(cache)); } catch {}
  listeners.forEach((fn) => fn());
}

// Issue 升格规则（可调）：同类型关联 Case ≥ 3 且跨产品 → 提示建议创建 Issue。
export const ISSUE_PROMOTION_MIN_CASES = 3;
export const ISSUE_PROMOTION_RELATION_TYPE: CaseLinkType = "关联";

export interface IssuePromotionSuggestion {
  relationType: CaseLinkType;
  caseIds: string[];
  productIds: string[];
  reason: string;
}

/* ------------------------------- Issue 读取 ------------------------------- */
export function allIssues(): Issue[] { return load().issues; }
export function issueById(id: string): Issue | undefined { return load().issues.find((i) => i.id === id); }

// 某 Issue 是否与某用户相关：创建者 / 负责 KR / 受影响产品 KR / Fanout 目标负责人
export function isIssueRelevantTo(iss: Issue, name: string): boolean {
  if (iss.requester === name || iss.registeredBy === name || iss.kr === name) return true;
  if (iss.affectedProductIds.some((pid) => productById(pid)?.owner === name)) return true;
  if (iss.fanouts.some((f) => f.targetOwner === name)) return true;
  return false;
}
// 用户在某 Issue 中的角色（用于通知/列表标注）
export function issueRoleFor(iss: Issue, name: string): string {
  if (iss.affectedProductIds.some((pid) => productById(pid)?.owner === name)) return "负责产品受影响";
  if (iss.requester === name || iss.registeredBy === name) return "我创建";
  if (iss.kr === name) return "我负责";
  if (iss.fanouts.some((f) => f.targetOwner === name)) return "Fanout 指派";
  return "相关";
}

/* ------------------------------- Issue 操作 ------------------------------- */
// 归集：把某 Case 挂入 Issue（多对多：一个 Case 可归属多个 Issue，也可不归属）
export function aggregateCase(issueId: string, caseId: string) {
  const iss = issueById(issueId); if (!iss) return;
  if (!iss.caseIds.includes(caseId)) iss.caseIds.push(caseId);
  const c = mockCases.find((x) => x.id === caseId);
  const pid = c ? caseProductId(c) : undefined;
  if (pid && !iss.affectedProductIds.includes(pid)) iss.affectedProductIds.push(pid);
  iss.updatedAt = now();
  persist();
}
export function detachCase(issueId: string, caseId: string) {
  const iss = issueById(issueId); if (!iss) return;
  iss.caseIds = iss.caseIds.filter((id) => id !== caseId);
  iss.updatedAt = now();
  persist();
}

// 新建 Issue（客诉/Q 直接提报、或人工新建）
export function createIssue(input: {
  name: string; source: IssueSource; objectType: ObjectType; desc?: string;
  customer?: string; registeredBy?: string; affectedProductIds?: string[]; caseIds?: string[];
  requester?: string; kr?: string;
  domain?: ProblemDomain; problemType?: ProblemType; expectedResolveDate?: string;
}): Issue {
  const c = load();
  const normalizedCaseIds = Array.from(new Set((input.caseIds ?? []).filter(Boolean)));
  // Case 归集自动推导受影响产品（并与调用方显式传入合并去重）
  const caseProductIds = normalizedCaseIds
    .map((cid) => mockCases.find((x) => x.id === cid))
    .filter(Boolean)
    .map((x) => caseProductId(x!))
    .filter(Boolean) as string[];
  const affectedProductIds = Array.from(new Set([...(input.affectedProductIds ?? []), ...caseProductIds]));
  const iss: Issue = {
    id: `iss-${Date.now()}`,
    code: `ISS-${today()}${String(c.issues.length + 1).padStart(2, "0")}`,
    name: input.name, source: input.source, objectType: input.objectType,
    status: "进行中",
    desc: input.desc ?? "", affectedProductIds,
    memberFails: [], caseIds: normalizedCaseIds, fanouts: [],
    customer: input.customer, registeredBy: input.registeredBy,
    requester: input.requester ?? input.registeredBy,
    kr: input.kr ?? input.requester ?? input.registeredBy,
    domain: input.domain, problemType: input.problemType, expectedResolveDate: input.expectedResolveDate,
    createdAt: new Date().toISOString().slice(0, 10),
  };
  c.issues.unshift(iss);
  persist();
  return iss;
}

export function updateIssueStatus(issueId: string, status: IssueStatus) {
  const iss = issueById(issueId); if (!iss) return;
  iss.status = status;
  if (status === "已结案" && !iss.solvedAt) iss.solvedAt = now();
  persist();
}

// KR 提交解决方案 → 进入 requester Review；此时不 fanout、不自动写 Checklist。
export function submitSolution(issueId: string, solution: string, rootCause?: string) {
  const iss = issueById(issueId); if (!iss) return;
  iss.solution = solution;
  if (rootCause) iss.rootCause = rootCause;
  iss.status = "已准备好解决方案";
  iss.reviewedBy = undefined;
  iss.reviewedAt = undefined;
  iss.reviewResult = undefined;
  persist();
}

// requester Review：通过后问题即结案，并【强制】Fanout 到其它产品（创建真实 Fanout Case）；打回则回到进行中。
export function reviewIssue(issueId: string, by: string, result: "通过" | "打回") {
  const iss = issueById(issueId); if (!iss) return;
  iss.reviewedBy = by;
  iss.reviewedAt = now();
  iss.reviewResult = result;
  if (result === "通过") {
    if (!iss.solvedAt) iss.solvedAt = now();
    // 结案必经步骤：为其它产品各建 1 个真实 Fanout 验证 Case 并推送负责人
    runIssueFanout(iss, by);
  } else {
    iss.status = "进行中";
  }
  persist();
}

// Issue 结案 Fanout —— 为选定的目标产品各创建真实 Fanout 验证 Case（Owner=产品负责人，带入共性描述/根因/解决方案），
// 并写入 iss.fanouts（含真实 Case id，可跳转）。幂等：已 Fanout 过则不重复创建。
// targetProductIds 省略时，默认全部其它产品（源产品自动排除）。
function runIssueFanout(iss: Issue, by: string, targetProductIds?: string[]) {
  if (iss.fanouts.length > 0) { // 已 Fanout 过，仅确保状态
    if (!iss.distributedAt) iss.distributedAt = now();
    iss.status = "解决方案验证中";
    return;
  }
  const sources = new Set(iss.affectedProductIds);
  const pick = targetProductIds ? new Set(targetProductIds) : null;
  const targets = mockProducts.filter((p) => !sources.has(p.id) && (!pick || pick.has(p.id))); // 选定的其它产品（源产品自动排除）
  const firstCase = iss.caseIds.map((id) => mockCases.find((c) => c.id === id)).find(Boolean);
  iss.fanouts = targets.map((p) => {
    const failStage = firstCase?.failStage || "—";
    const failMode = firstCase?.failMode || "—";
    const nc = createManualCase({
      name: `${p.code} · ${failStage} · ${failMode}`,
      owner: p.owner,
      createdBy: by,
      level: firstCase?.level ?? "L3",
      urgency: firstCase?.urgency ?? "一般",
      reason: `源自 Issue ${iss.code}「${iss.name}」的 Fanout 验证。`,
      background: `【源自 Issue ${iss.code}「${iss.name}」的 Fanout 验证】\n共性描述：${iss.desc}` +
        `${iss.rootCause ? `\n根因：${iss.rootCause}` : ""}${iss.solution ? `\n解决方案：${iss.solution}` : ""}`,
      product: p.code,
      productIds: [p.id],
      failStage,
      failMode,
      source: "fanout验证",
    });
    nc.status = "验证中";
    nc.aiSummary = {
      progress: "由 Issue 结案 Fanout 生成，无需重复分析，请产品负责人查看并确认是否存在同类问题。",
      method: "",
      conclusion: "",
      solution: iss.solution ?? "",
      risk: "",
    };
    nc.timeline = [{
      time: now(),
      user: by,
      content: `由 Issue ${iss.code} 结案 Fanout 分发到产品 ${p.code}，已同步共性描述与解决方案，指派 ${p.owner} 查看确认。`,
    }];
    return {
      targetProductId: p.id,
      targetOwner: p.owner,
      spawnedCaseId: nc.id,
      spawnedCaseCode: nc.code,
      status: "待验证" as FanoutStatus,
    };
  });
  iss.distributedAt = now();
  iss.status = "解决方案验证中";
}

// 手动分发入口（兼容旧数据 / 已结案但尚未 Fanout 的 Issue）：走同一套真实 Case 创建逻辑。
export function distributeIssue(issueId: string, by = "系统") {
  const iss = issueById(issueId); if (!iss || iss.reviewResult !== "通过") return;
  runIssueFanout(iss, by);
  persist();
}

// 分发后，由 requester / KR 显式决定是否把本 Issue 沉淀进 Checklist。
export function decideIssueChecklist(issueId: string, by: string, inChecklist: boolean, title?: string) {
  const iss = issueById(issueId); if (!iss) return;
  iss.inChecklist = inChecklist;
  iss.checklistDecisionBy = by;
  iss.backwriteDefTitle = inChecklist ? (title?.trim() || iss.name) : undefined;
  persist();
}

export function setFanoutStatus(issueId: string, targetProductId: string, status: FanoutStatus) {
  const iss = issueById(issueId); if (!iss) return;
  const f = iss.fanouts.find((x) => x.targetProductId === targetProductId);
  if (f) f.status = status;
  iss.updatedAt = now();
  persist();
}

// RETs 同步：Issue 已结案或解决方案验证中后允许，单向推送整个 Issue
export function syncRETs(issueId: string) {
  const iss = issueById(issueId); if (!iss || !["已结案", "解决方案验证中"].includes(iss.status)) return;
  iss.retsSynced = true; iss.retsSyncedAt = now();
  persist();
}

// V1.0.4 结案流程第一步：填写根因 + 强制 Fanout（不经 Review 网关）。
// targetProductIds 省略时默认全部其它产品；传入时仅 Fanout 到选定产品。
export function resolveIssueRootCause(issueId: string, rootCause: string, by = "系统", targetProductIds?: string[]) {
  const iss = issueById(issueId); if (!iss) return;
  iss.rootCause = rootCause;
  if (iss.status === "进行中") iss.status = "已准备好解决方案";
  runIssueFanout(iss, by, targetProductIds); // 强制 Fanout：设置 distributedAt + status=解决方案验证中
  iss.updatedAt = now();
  persist();
}

// V1.0.4 结案流程第二步：填写结案内容（复用 Case 结论/过程/附件文档），并折叠 RETs 同步。
export function closeIssue(
  issueId: string,
  payload: { conclusion: string; process: string; attachments: Issue["issueAttachments"] },
  _by = "系统",
) {
  const iss = issueById(issueId); if (!iss) return;
  iss.issueConclusion = payload.conclusion;
  iss.issueProcess = payload.process;
  iss.issueAttachments = payload.attachments;
  iss.status = "已结案";
  if (!iss.solvedAt) iss.solvedAt = now();
  iss.retsSynced = true; iss.retsSyncedAt = now();
  iss.updatedAt = now();
  persist();
}

/* ------------------------------ 项目 / 检查项 ------------------------------ */
export function allProjects(): Project[] { return load().projects; }
export function projectsForProduct(productId: string): Project[] {
  return load().projects.filter((p) => p.productId === productId);
}

// 设定检查项结果（仅叶子）；置 Fail 时自动生成一个 Case（挂对应产品），由用户再归纳进 Issue
export function setCheckState(projectId: string, checklistId: string, defId: string, state: CheckState, by = "张伟") {
  const c = load();
  const prj = c.projects.find((p) => p.id === projectId); if (!prj) return;
  const cl = prj.checklists.find((x) => x.id === checklistId); if (!cl) return;
  // 递归定位叶子检查项（WBS×Checklist 融合：状态只落在叶子）
  const find = (nodes: CheckItemResult[]): CheckItemResult | undefined => {
    for (const n of nodes) {
      if (n.defId === defId && !n.children?.length) return n;
      if (n.children?.length) { const hit = find(n.children); if (hit) return hit; }
    }
    return undefined;
  };
  const item = find(cl.items); if (!item) return;
  item.state = state; item.by = by; item.at = new Date().toISOString().slice(0, 10);
  if (state === "Fail" && !item.caseId) {
    // 新模型：检查项 Fail → 自动生成一个 Case（挂产品，来源=检查项Fail），不再直接建 Issue
    const nc = buildFailCase(prj, cl, item);
    c.spawnedCases.push(nc);
    if (!mockCases.some((x) => x.id === nc.id)) mockCases.push(nc);
    item.caseId = nc.id;
  }
  persist();
}

// 由检查项 Fail 构造一个 Case（挂对应产品）
function buildFailCase(prj: Project, cl: Checklist, item: CheckItemResult): CaseItem {
  const prod = productById(prj.productId);
  const day = new Date().toISOString().slice(0, 10);
  const seq = String(Date.now()).slice(-6);
  return {
    id: `case-ck-${Date.now()}`,
    code: `EA-CK-${today()}${seq.slice(-3)}`,
    name: `${prod?.code ?? prj.productId} · 检查项失败：${item.title}`,
    owner: prod?.owner ?? "张伟",
    level: "L3", urgency: "一般", status: "进行中",
    reason: `Checklist「${cl.name}」检查项「${item.title}」判为 Fail，自动生成 Case 立案调查。`,
    background: `来源：${prod?.code ?? prj.productId} · 项目「${prj.name}」· ${stageDefById(cl.stageId).name} 阶段 · Checklist「${cl.name}」· 检查项「${item.title}」= Fail。`,
    levelReason: "由检查项 Fail 自动生成，默认 L3，可按影响升级。",
    product: prod?.code ?? prj.productId,
    productId: prod?.id ?? prj.productId,
    source: "检查项Fail",
    material: "—", density: "—", ioType: "—",
    failStage: stageDefById(cl.stageId).name,
    customer: "—", failPlatform: "—", failMode: item.title, ppm: "—", pdId: "—",
    createdAt: day, updatedAt: day, dueIn: 7,
    departments: [],
    tasks: [],
    aiSummary: { progress: "自动立案，待接受与分析。", method: "", conclusion: "", solution: "", risk: "" },
    timeline: [{ time: now(), user: prod?.owner ?? "系统", content: `检查项「${item.title}」判为 Fail，系统自动生成本 Case。` }],
  };
}

// 人工立案：由「新建 Case」表单持久化一个真实 Case（注入共享 mockCases）
let manualSeq = 0;
export function createManualCase(input: {
  name: string; owner: string; level: CaseItem["level"]; urgency: CaseItem["urgency"];
  createdBy?: string; createdForOther?: boolean;
  participants?: CaseItem["participants"];
  reason: string; background: string; impact?: string; levelReason?: string;
  problemDomain?: CaseItem["problemDomain"]; problemType?: CaseItem["problemType"];
  product?: string; material?: string; materialSubtype?: string; density?: string; ioType?: string; failStage?: string;
  productIds?: string[];
  markCode?: string;
  customer?: string; failPlatform?: string; failMode?: string; failRatio?: string; failPackage?: string;
  maskVersion?: string; program?: string; ppm?: string; pdId?: string;
  caseAttribute?: string; productGeneration?: string; dimmCapacity?: string; bitWidth?: string;
  projectName?: string; platformModel?: string; productPartNumber?: string;
  customerApplication?: string; sampleCount?: string; sampleReceivedAt?: string;
  returnedSamples?: CaseItem["returnedSamples"];
  productSpeed?: string; productForm?: string; productSubtype?: string; productInternalCode?: string; grainDeviceInfo?: string;
  source: IssueSource; tasks?: CaseItem["tasks"] | ((caseCode: string) => CaseItem["tasks"]); caseAttachments?: CaseItem["caseAttachments"];
  dueDate?: string;
  parentCaseId?: string; childCaseIds?: string[]; splitGranule?: CaseItem["splitGranule"];
  sourceModuleCaseId?: string;
  granules?: CaseItem["granules"];
  relatedCaseIds?: string[];
  sourceStandaloneTaskId?: string;
  sourceStandaloneTaskIds?: string[];
  analysisTemplate?: CaseItem["analysisTemplate"]; pipeline?: CaseItem["pipeline"];
}, options: { strict?: boolean } = {}): CaseItem {
  const c = load();
  const day = new Date().toISOString().slice(0, 10);
  manualSeq += 1;
  const uid = `${Date.now()}${manualSeq}`;
  const seq = uid.slice(-6);
  const prod = productById(input.productIds?.[0] ?? input.product);
  const code = `EA-M-${today()}${seq.slice(-3)}`;
  const tasks = typeof input.tasks === "function" ? input.tasks(code) : input.tasks ?? [];
  const sourceTaskIds = Array.from(new Set([...(input.sourceStandaloneTaskId ? [input.sourceStandaloneTaskId] : []), ...(input.sourceStandaloneTaskIds ?? [])]));
  const nc: CaseItem = {
    id: `case-m-${uid}`,
    code,
    name: input.name,
    owner: input.owner,
    createdBy: input.createdBy,
    createdForOther: input.createdForOther,
    participants: input.participants,
    level: input.level, urgency: input.urgency, status: "进行中",
    reason: input.reason, background: input.background, problemDomain: input.problemDomain, problemType: input.problemType, impact: input.impact,
    caseAttachments: input.caseAttachments,
    levelReason: input.levelReason ?? "",
    product: prod?.code ?? input.product ?? "",
    productId: prod?.id ?? input.productIds?.[0] ?? input.product,
    productIds: input.productIds && input.productIds.length > 1 ? input.productIds : undefined,
    source: input.source,
    material: input.material ?? "—", materialSubtype: input.materialSubtype,
    markCode: input.markCode,
    density: input.density ?? "—", ioType: input.ioType ?? "—",
    failStage: input.failStage ?? "—", customer: input.customer ?? "—",
    failPlatform: input.failPlatform ?? "—", failMode: input.failMode ?? "—",
    failRatio: input.failRatio, failPackage: input.failPackage,
    maskVersion: input.maskVersion, program: input.program,
    caseAttribute: input.caseAttribute,
    productGeneration: input.productGeneration,
    dimmCapacity: input.dimmCapacity,
    bitWidth: input.bitWidth,
    projectName: input.projectName,
    platformModel: input.platformModel,
    productPartNumber: input.productPartNumber,
    customerApplication: input.customerApplication,
    sampleCount: input.sampleCount,
    sampleReceivedAt: input.sampleReceivedAt,
    returnedSamples: input.returnedSamples,
    productSpeed: input.productSpeed,
    productForm: input.productForm,
    productSubtype: input.productSubtype,
    productInternalCode: input.productInternalCode,
    grainDeviceInfo: input.grainDeviceInfo,
    ppm: input.ppm ?? "—", pdId: input.pdId ?? "—",
    parentCaseId: input.parentCaseId,
    sourceModuleCaseId: input.sourceModuleCaseId,
    childCaseIds: input.childCaseIds,
    relatedCaseIds: input.relatedCaseIds,
    sourceStandaloneTaskId: sourceTaskIds[0],
    sourceStandaloneTaskIds: sourceTaskIds.length ? sourceTaskIds : undefined,
    splitGranule: input.splitGranule,
    granules: input.granules,
    analysisTemplate: input.analysisTemplate,
    pipeline: input.pipeline,
    createdAt: day, updatedAt: day, dueDate: input.dueDate, dueIn: 7,
    departments: Array.from(new Set([
      ...tasks.map((t) => t.department),
      ...(input.participants ?? []).map((p) => p.department),
    ].filter(Boolean))),
    tasks,
    aiSummary: { progress: "人工立案。", method: "", conclusion: "", solution: "", risk: "" },
    timeline: [
      {
        time: now(),
        user: input.createdBy ?? input.owner,
        content: input.createdForOther
          ? `${input.createdBy ?? "创建人"} 为 ${input.owner} 创建 Case（来源：${input.source}）。`
          : `人工新建 Case（来源：${input.source}）。`,
      },
      ...((input.participants?.length ?? 0) > 0 ? [{
        time: now(),
        user: input.createdBy ?? input.owner,
        content: `已添加参与人：${input.participants!.map((p) => p.name).join("、")}；无需接受，已发送通知并开放 Case 编辑权限。`,
      }] : []),
      ...(sourceTaskIds.length ? [{
        time: now(),
        user: input.createdBy ?? input.owner,
        content: `由 ${sourceTaskIds.length} 条自由任务升级创建，已保留来源关联并带入执行任务。`,
      }] : []),
    ],
  };
  const moduleLinks = moduleIcLinks(nc, mockCases);
  if (moduleLinks.length) nc.relatedCaseIds = Array.from(new Set([...(nc.relatedCaseIds ?? []), ...moduleLinks.map((link) => link.from)]));
  // 自动关联与新 Case 一次保存；批量创建中的每个 IC 都执行，不能仅关联 primaryId。
  if (options.strict || moduleLinks.length) {
    const next = { ...c, spawnedCases: [...c.spawnedCases, nc], caseLinks: mergeCaseLinks(c.caseLinks, moduleLinks) };
    const persistedNext = { ...next, spawnedCases: next.spawnedCases.map((item) => {
      const peers = moduleLinks.flatMap((link) => link.from === item.id ? [link.to] : link.to === item.id ? [link.from] : []);
      return peers.length ? { ...item, relatedCaseIds: Array.from(new Set([...(item.relatedCaseIds ?? []), ...peers])) } : item;
    }) };
    try { localStorage.setItem(KEY, JSON.stringify(persistedNext)); }
    catch { throw new Error(moduleLinks.length ? "未能保存新 Case 及来源关联，请检查浏览器存储后重试。" : "未能保存新 Case，原任务未改变，请检查浏览器存储后重试。"); }
    cache = next;
    injectSpawned([nc]);
    syncRelatedCaseIds(next);
    listeners.forEach((fn) => fn());
    return nc;
  }
  c.spawnedCases.push(nc);
  if (!mockCases.some((x) => x.id === nc.id)) mockCases.push(nc);
  persist();
  return nc;
}

export function caseByStandaloneTask(taskId: string): CaseItem | undefined {
  load();
  return mockCases.find((item) => item.sourceStandaloneTaskId === taskId || item.sourceStandaloneTaskIds?.includes(taskId));
}

// —— V1.0.4：结案 Fanout —— 为每个目标产品建立一个 Fanout Case，Owner = 产品负责人，
// 直接带入源 Case 的问题背景与解决方案；对方通常无需修改，仅需查看确认。
export function createFanoutCasesFromClose(input: {
  sourceCaseId: string;
  productIds: string[];
  conclusion: string;
  solution?: string;
  by: string;
}): CaseItem[] {
  const src = mockCases.find((x) => x.id === input.sourceCaseId);
  if (!src) return [];
  const baseName = src.name.replace(/（.*?）\s*$/, "");
  const created: CaseItem[] = [];
  input.productIds.forEach((pid) => {
    const prod = productById(pid);
    if (!prod) return;
    const failStage = src.failStage || "—";
    const failMode = src.failMode || "—";
    const nc = createManualCase({
      name: `${prod.code} · ${failStage} · ${failMode}`,
      owner: prod.owner || src.owner,
      createdBy: input.by,
      level: src.level,
      urgency: src.urgency,
      reason: src.reason,
      background: `【源自 ${src.code}「${baseName}」的 Fanout 验证】\n${src.background}`,
      impact: src.impact,
      problemDomain: src.problemDomain,
      problemType: src.problemType,
      product: prod.code,
      productIds: [prod.id],
      material: src.material,
      materialSubtype: src.materialSubtype,
      density: src.density,
      ioType: src.ioType,
      failStage,
      customer: src.customer,
      failPlatform: src.failPlatform,
      failMode,
      source: "fanout验证",
    });
    // Fanout 专属：待产品负责人查看确认；共享问题与解决方案
    nc.status = "验证中";
    nc.fanoutSourceCaseId = src.id;
    nc.aiSummary = {
      progress: "由 Fanout 分发生成，无需重复分析，请产品负责人查看并确认是否存在同类问题。",
      method: src.aiSummary?.method ?? "",
      conclusion: input.conclusion || src.aiSummary?.conclusion || "",
      solution: input.solution || src.aiSummary?.solution || "",
      risk: src.aiSummary?.risk ?? "",
    };
    nc.timeline = [{
      time: now(),
      user: input.by,
      content: `由 ${src.code} 结案 Fanout 分发到产品 ${prod.code}，已同步问题背景与解决方案，指派 ${prod.owner || src.owner} 查看确认。`,
    }];
    bindRelatedCases([src.id, nc.id], { note: "Fanout 验证" });
    created.push(nc);
  });
  src.fanoutTargets = Array.from(new Set([...(src.fanoutTargets ?? []), ...input.productIds]));
  persist();
  return created;
}


// 拆解：将子 Case 列表回写到父 Case（childCaseIds）
export function linkChildren(parentId: string, childIds: string[]) {
  const p = mockCases.find((x) => x.id === parentId);
  if (p) p.childCaseIds = childIds;
  const sp = load().spawnedCases.find((x) => x.id === parentId);
  if (sp) sp.childCaseIds = childIds;
  persist();
}

/* --------------------------------- hooks --------------------------------- */
function useDomainTick() {
  const [, setTick] = useState(0);
  useEffect(() => {
    const fn = () => setTick((t) => t + 1);
    listeners.add(fn);
    return () => { listeners.delete(fn); };
  }, []);
}
export function useIssues(): Issue[] { useDomainTick(); return load().issues; }
export function useProjects(): Project[] { useDomainTick(); return load().projects; }

/* --------------------- Case↔Issue 归属（多对多）快捷封装 --------------------- */
export function attachCaseToIssue(caseId: string, issueId: string) { aggregateCase(issueId, caseId); }
export function detachCaseFromIssue(caseId: string) {
  load().issues.forEach((i) => { i.caseIds = i.caseIds.filter((id) => id !== caseId); });
  persist();
}
// 把多个 Case 归纳为一个新 Issue（Jira：多选 → Move to new Epic）
export function groupCasesIntoIssue(caseIds: string[], input: {
  name: string; objectType: ObjectType; source?: IssueSource; desc?: string;
}): Issue {
  const iss = createIssue({ name: input.name, source: input.source ?? "手动", objectType: input.objectType, desc: input.desc });
  caseIds.forEach((cid) => aggregateCase(iss.id, cid));
  return iss;
}

/* ------------------------- Case↔Case 弱链接（多对多）------------------------- */
export function allCaseLinks(): CaseLink[] { return load().caseLinks; }
export function linksOfCase(caseId: string): CaseLink[] {
  return load().caseLinks.filter((l) => l.from === caseId || l.to === caseId);
}

// 基于同类型关系边构造与 caseId 同连通分量的 Case 集合（无向图）
function connectedCasesByRelation(caseId: string, relationType: CaseLinkType): string[] {
  const edges = load().caseLinks.filter((l) => l.type === relationType);
  const adj = new Map<string, Set<string>>();
  const add = (a: string, b: string) => {
    if (!adj.has(a)) adj.set(a, new Set());
    adj.get(a)!.add(b);
  };
  edges.forEach((e) => { add(e.from, e.to); add(e.to, e.from); });
  const q: string[] = [caseId];
  const vis = new Set<string>([caseId]);
  while (q.length) {
    const cur = q.shift()!;
    (adj.get(cur) ?? new Set()).forEach((n) => {
      if (!vis.has(n)) { vis.add(n); q.push(n); }
    });
  }
  return Array.from(vis).filter((id) => !!mockCases.find((c) => c.id === id));
}

// 单 Case 视角：是否触发 Issue 升格建议（同类型关联 Case ≥ 3 且跨产品）
export function issuePromotionSuggestionOfCase(caseId: string): IssuePromotionSuggestion | null {
  const caseIds = connectedCasesByRelation(caseId, ISSUE_PROMOTION_RELATION_TYPE);
  if (caseIds.length < ISSUE_PROMOTION_MIN_CASES) return null;
  const productIds = Array.from(new Set(
    caseIds
      .map((id) => mockCases.find((c) => c.id === id))
      .filter(Boolean)
      .map((c) => caseProductId(c!))
      .filter(Boolean) as string[]
  ));
  if (productIds.length < 2) return null;
  return {
    relationType: ISSUE_PROMOTION_RELATION_TYPE,
    caseIds,
    productIds,
    reason: `同类型关联 Case ≥ ${ISSUE_PROMOTION_MIN_CASES} 且跨产品（当前 ${caseIds.length} 个 Case，${productIds.length} 个产品）`,
  };
}

export function useIssuePromotionSuggestion(caseId: string): IssuePromotionSuggestion | null {
  useDomainTick();
  return issuePromotionSuggestionOfCase(caseId);
}

export function linkCases(from: string, to: string, type: CaseLinkType, opts: { note?: string; byAi?: boolean } = {}) {
  if (from === to) return;
  const c = load();
  const exists = c.caseLinks.some((l) =>
    (l.from === from && l.to === to) || (l.from === to && l.to === from));
  if (exists) return;
  c.caseLinks.push({ from, to, type, note: opts.note, byAi: opts.byAi });
  persist();
}

// 批量建案后：把同批 Case 互相写入「关联 Case」，并补齐「关联」关系边。
export function bindRelatedCases(caseIds: string[], opts: { note?: string } = {}) {
  const c = load();
  const ids = Array.from(new Set(caseIds.filter(Boolean)));
  if (ids.length < 2) return;

  ids.forEach((id) => {
    const siblings = ids.filter((x) => x !== id);
    const target = mockCases.find((x) => x.id === id);
    if (target) {
      target.relatedCaseIds = Array.from(new Set([...(target.relatedCaseIds ?? []), ...siblings]));
    }
    const spawned = c.spawnedCases.find((x) => x.id === id);
    if (spawned) {
      spawned.relatedCaseIds = Array.from(new Set([...(spawned.relatedCaseIds ?? []), ...siblings]));
    }
  });

  for (let i = 0; i < ids.length; i += 1) {
    for (let j = i + 1; j < ids.length; j += 1) {
      const from = ids[i];
      const to = ids[j];
      const exists = c.caseLinks.some((l) =>
        (l.from === from && l.to === to) || (l.from === to && l.to === from));
      if (!exists) c.caseLinks.push({ from, to, type: "关联", note: opts.note });
    }
  }

  persist();
}

export function unlinkCases(from: string, to: string) {
  const c = load();
  c.caseLinks = c.caseLinks.filter((l) =>
    !((l.from === from && l.to === to) || (l.from === to && l.to === from)));
  [...mockCases, ...c.spawnedCases].forEach((item) => {
    if (item.id === from) item.relatedCaseIds = item.relatedCaseIds?.filter((id) => id !== to);
    if (item.id === to) item.relatedCaseIds = item.relatedCaseIds?.filter((id) => id !== from);
  });
  persist();
}
export function useCaseLinks(): CaseLink[] { useDomainTick(); return load().caseLinks; }

export function resetDomain() {
  cache = seed();
  persist();
}
