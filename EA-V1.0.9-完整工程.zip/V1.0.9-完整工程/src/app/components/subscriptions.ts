// Lightweight in-memory subscription store with React hook.
import { useEffect, useState } from "react";

const KEY = "ea_subscribed_cases_v1";
let cache: Set<string> | null = null;
const listeners = new Set<() => void>();

function load(): Set<string> {
  if (cache) return cache;
  try {
    const raw = typeof localStorage !== "undefined" ? localStorage.getItem(KEY) : null;
    cache = new Set<string>(raw ? JSON.parse(raw) : ["c001"]);
  } catch {
    cache = new Set<string>(["c001"]);
  }
  return cache;
}

function persist() {
  try {
    if (cache) localStorage.setItem(KEY, JSON.stringify([...cache]));
  } catch {}
}

export function isSubscribed(id: string) {
  return load().has(id);
}

export function toggleSubscription(id: string) {
  const s = load();
  if (s.has(id)) s.delete(id);
  else s.add(id);
  persist();
  listeners.forEach((fn) => fn());
}

export function subscribedIds(): string[] {
  return [...load()];
}

export function useSubscriptions() {
  const [, setTick] = useState(0);
  useEffect(() => {
    const fn = () => setTick((t) => t + 1);
    listeners.add(fn);
    return () => {
      listeners.delete(fn);
    };
  }, []);
  return {
    isSubscribed,
    toggle: toggleSubscription,
    ids: subscribedIds(),
  };
}
