import { useRef, useState } from "react";
import type { RefObject } from "react";
import * as Popover from "@radix-ui/react-popover";
import { Blocks, Check, ChevronDown, Search, X } from "lucide-react";
import { useSkills } from "./skills";
import type { AgentConversation } from "./useAgentConversation";

export function AgentSkillPicker({ conversation, inputRef }: {
  conversation: AgentConversation;
  inputRef: RefObject<HTMLTextAreaElement>;
}) {
  const { skills } = useSkills();
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const focusComposer = useRef(false);
  const search = useRef<HTMLInputElement>(null);
  const keywords = query.trim().toLowerCase().split(/\s+/).filter(Boolean);
  const published = skills.filter(skill => skill.status === "已发布" && keywords.every(keyword => `${skill.name} ${skill.category}`.toLowerCase().includes(keyword)));

  return <div className={`ea-agent-skill-selection${conversation.activeSkill ? " is-selected" : ""}`}>
    <Popover.Root open={open} onOpenChange={value => { setOpen(value); if (value) { setQuery(""); focusComposer.current = false; } }}>
      <Popover.Trigger asChild><button type="button" aria-label="选择 Skill" title={conversation.activeSkill?.name || "选择 Skill"} className="ea-agent-skill-trigger"><Blocks size={14} /><span className="ea-agent-skill-selection-name">{conversation.activeSkill?.name || "选择 Skill"}</span><ChevronDown size={12} /></button></Popover.Trigger>
      <Popover.Portal>
        <Popover.Content align="start" side="top" sideOffset={8} collisionPadding={16} aria-label="选择已发布 Skill"
          className="z-[110] w-[320px] max-w-[calc(100vw-32px)] overflow-hidden rounded-lg border border-slate-200 bg-white text-slate-700 shadow-lg outline-none"
          onOpenAutoFocus={event => { event.preventDefault(); search.current?.focus(); }}
          onCloseAutoFocus={event => { if (focusComposer.current) { event.preventDefault(); inputRef.current?.focus(); focusComposer.current = false; } }}>
          <div className="flex items-center gap-2 border-b border-slate-100 px-3 py-2"><Search size={14} className="shrink-0 text-slate-400" /><input ref={search} aria-label="搜索已发布 Skill" placeholder="搜索名称或分类" value={query} onChange={event => setQuery(event.target.value)} className="h-8 min-w-0 flex-1 bg-transparent text-xs outline-none" /></div>
          <div role="group" aria-label="已发布 Skill" className="max-h-[240px] overflow-y-auto overscroll-contain p-1.5">
            {published.map(skill => <button key={skill.id} type="button" aria-pressed={conversation.activeSkill?.id === skill.id}
              onClick={() => { conversation.selectSkill(skill); focusComposer.current = true; setOpen(false); }}
              className="flex w-full items-center gap-2 rounded-md px-2.5 py-2 text-left hover:bg-slate-50 focus-visible:outline-2 focus-visible:outline-[#0052D9]">
              <span className="min-w-0 flex-1"><span className="block truncate text-xs" title={skill.name}>{skill.name}</span><span className="block text-[10px] text-slate-400">{skill.category}</span></span>
              {conversation.activeSkill?.id === skill.id && <Check size={14} className="shrink-0 text-[#0052D9]" />}
            </button>)}
            {!published.length && <p className="px-3 py-5 text-center text-xs text-slate-400">没有匹配的已发布 Skill</p>}
          </div>
        </Popover.Content>
      </Popover.Portal>
    </Popover.Root>
    <button type="button" className="ea-agent-skill-clear" aria-label="清除已选 Skill" disabled={!conversation.activeSkill} aria-hidden={!conversation.activeSkill || undefined} tabIndex={conversation.activeSkill ? 0 : -1} onClick={() => { conversation.selectSkill(null); inputRef.current?.focus(); }}><X size={12} /></button>
  </div>;
}