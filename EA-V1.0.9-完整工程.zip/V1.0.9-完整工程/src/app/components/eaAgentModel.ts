export type AgentPoint = { x: number; y: number };
export type AgentViewport = { width: number; height: number };
export type AgentSkill = Readonly<{ id: string; name: string; category: string }>;
export type AgentMessage = { id: number; role: "ai" | "user"; text: string; skillName?: string; createdAt?: string; generatedFileIds?: string[] };
export const AGENT_DEMO_FILES = [
  {
    id: "analysis-report",
    name: "Case分析报告_示例.md",
    format: "MD",
    mime: "text/markdown",
    content: "# Case 分析报告（示例）\n\n本文件为原型示例，不代表真实业务数据或诊断结果。\n\n## 问题概述\n现象：高温、低压组合条件下出现间歇性训练失败。\n范围：待补充物料、批次、平台与测试阶段。\n\n## 验证计划\n- 对比常温与高温条件，保留原始测试记录。\n- 核对电压、时序与程式版本，设置单变量对照。\n- 汇总失败样本和通过样本，记录复现率。\n\n## 当前结论\n尚无足够证据确认根因，以上均为待验证方向。\n\n## 下一步\n补齐测试数据与对照结果，再更新结论。\n",
  },
  {
    id: "verification-data",
    name: "验证计划明细_示例.csv",
    format: "CSV",
    mime: "text/csv",
    content: "序号,验证方向,对照条件,预期输出,状态\r\n1,温度对照,常温与高温,失败样本与复现率,待验证\r\n2,电压对照,标称电压与低压,电压边界记录,待验证\r\n3,版本对照,基线与当前程式,版本差异清单,待验证\r\n备注,原型示例不代表真实业务数据,,,\r\n",
  },
] as const;
export const AGENT_SIZE = 64;
export const AGENT_MARGIN = 16;
export const AGENT_POSITION_KEY = "ea_agent_position_v1";
export const AGENT_MAX_MESSAGE = 6000;

export function agentDemoFileIds(question: string): string[] {
  return /生成|导出|下载/.test(question) && /报告|文件|表格|明细|清单|计划/.test(question)
    ? AGENT_DEMO_FILES.map(file => file.id)
    : [];
}

export function clampAgentPosition(point: AgentPoint, viewport: AgentViewport): AgentPoint {
  const maxX = Math.max(AGENT_MARGIN, viewport.width - AGENT_SIZE - AGENT_MARGIN);
  const maxY = Math.max(AGENT_MARGIN, viewport.height - AGENT_SIZE - AGENT_MARGIN);
  return { x: Math.min(maxX, Math.max(AGENT_MARGIN, point.x)), y: Math.min(maxY, Math.max(AGENT_MARGIN, point.y)) };
}

export function initialAgentPosition(raw: string | null, viewport: AgentViewport): AgentPoint {
  const fallback = { x: viewport.width - AGENT_SIZE - 24, y: viewport.height - AGENT_SIZE - 96 };
  try {
    const saved = raw ? JSON.parse(raw) : null;
    if (saved && typeof saved.x === "number" && typeof saved.y === "number" && Number.isFinite(saved.x) && Number.isFinite(saved.y)) return clampAgentPosition(saved, viewport);
  } catch { /* Invalid preferences should not prevent opening the assistant. */ }
  return clampAgentPosition(fallback, viewport);
}

export function agentPanelBounds(position: AgentPoint, viewport: AgentViewport) {
  const width = Math.min(420, Math.max(280, viewport.width - AGENT_MARGIN * 2));
  const height = Math.min(620, Math.max(280, viewport.height - AGENT_MARGIN * 2));
  const left = Math.max(AGENT_MARGIN, Math.min(position.x + AGENT_SIZE - width, viewport.width - width - AGENT_MARGIN));
  const top = Math.max(AGENT_MARGIN, Math.min(position.y + AGENT_SIZE - height, viewport.height - height - AGENT_MARGIN));
  return { left, top, width, height };
}

// Transparent offline replies: no fabricated queries, Case counts, or execution claims.
export function agentDemoReply(question: string, skill?: AgentSkill | null): string {
  if (skill) {
    const guidance = skill.category === "报告生成" && /日报/.test(skill.name)
      ? "整理日报时，可以按日期提供工作笔记，再按已完成事项、进行中事项、风险与下一步组织内容。只记录已有事实；需要日期对话与文档操作时，可在 Skill 列表中选择「打开工作区」。"
      : skill.category === "报告生成"
        ? agentDemoReply("Workspace 结论怎么写？")
        : skill.category === "失效分析"
          ? agentDemoReply("Case 分析从哪里开始？")
          : skill.category === "测试自动化"
            ? "检查测试程式时，先提供 timing set、适用规格与测试条件，再逐项核对 setup/hold、corner 和对照程式。实际余量与风险需用输入数据验证；这里不会扫描或运行程式。"
            : skill.category === "数据处理"
              ? "分析数据前，先明确时间范围、样本量与统计口径，再按站点、Lot、设备或版本分组对照。请提供原始良率数据后核验波动与异常，不能把时间上的接近直接当作根因；这里没有检测到或推送任何预警。"
              : skill.category === "知识问答"
                ? "知识问答可先明确问题、产品与适用条件，并提供相关 SOP 或历史 Case 摘录。比对资料版本和证据来源后再整理步骤，区分资料原文与待验证推断；这里尚未检索知识库或历史案例。"
                : agentDemoReply(question);
    return `使用 Skill · ${skill.name}\n\n${guidance}\n\n仅本地 Skill 指引，未调用真实 AI 服务、读取业务数据或执行操作，也不会保存文档或推送结果。`;
  }
  if (agentDemoFileIds(question).length) {
    return "已准备好 Case 分析报告和验证计划明细，分别保留文字结论与逐项验证安排。\n\n以下文件使用示例内容，未读取业务数据，可下载后查看或继续编辑。";
  }
  if (/任务|todo|checklist/i.test(question)) {
    return "可以按这条路径处理任务：\n\n1. 日常事务使用「新建自由任务」，产品问题分析使用「新建 Case」。\n2. 收到分派后，先接受任务，或拒绝并填写原因。\n3. 在 Workspace 记录处理过程与结论；新建附件和结果附件分别保留。\n4. 完成前保存必填结论；不再执行时，可填写原因后中止。\n\n以上是本地流程提示；我没有更改任何任务。";
  }
  if (/结论|workspace|汇报|总结/i.test(question)) {
    return "可以按以下结构组织 Workspace 文档：\n\n结论：目前确认了什么，哪些判断仍待验证。\n过程：执行了哪些步骤，使用了哪些条件和对照。\n证据：记录数据来源、关键结果和支撑附件。\n下一步：明确待验证项与建议动作。\n\n请只写入已有证据支持的内容；示例不会自动保存到你的文档。";
  }
  if (/case|分析|失效|异常|排查|debug|dimm|camm/i.test(question)) {
    return "建议先把问题整理成可验证的分析路径：\n\n1. 描述现象：物料、测试阶段、失效条件和影响范围。\n2. 列出假设：每个怀疑方向分别说明依据。\n3. 设计验证：设定对照条件、预期结果和排除标准。\n4. 记录结论：区分已确认事实与待验证推断。\n\n这是离线分析框架，不是对当前 Case 的诊断；我尚未读取页面数据或检索历史案例。";
  }
  if (/你好|hello|hi\b|帮助/i.test(question)) {
    return "你好！可以和我讨论 EA 使用流程、Case 分析思路或 Workspace 文档结构。\n\n当前为离线演示，回复来自本地规则，并非真实 AI 推理。你可以体验文本发送、窗口展开与收起；对话不会提交到服务器。";
  }
  return `已收到你的问题：\n「${question.length > 140 ? `${question.slice(0, 140)}…` : question}」\n\n当前是离线对话演示，无法对这个问题进行真实检索或推理。可以先明确目标、已知信息和需要的输出，再整理为待验证步骤。\n\n你也可以试问「Case 分析从哪里开始」「Workspace 结论怎么写」或「自由任务如何处理」。`;
}