import type { SummaryStatus } from "./taskWorkbenchModel";

const STATUS_CARDS = [
  { status: "待接受", accent: "#0D9488", bg: "#f1faf8" },
  { status: "进行中", accent: "#0052D9", bg: "#f5f8ff" },
  { status: "已完成", accent: "#64748b", bg: "#f6f8fb" },
] as const;

// 用户指定以 V1.0.7 MyTasksPanel 状态模块为视觉基准，不随工作台布局优化改版。
// 本次明确授权缩窄已完成；三个状态为固定主分类，不再重复点击取消状态。
export function TaskStatusSummary({ counts, status: selectedStatus, scope = "mine", onChange }: {
  counts: Record<SummaryStatus, number>;
  status: SummaryStatus;
  scope?: "mine" | "assigned";
  onChange: (status: SummaryStatus) => void;
}) {
  return <section aria-label="任务状态汇总" className="grid grid-cols-[minmax(0,2fr)_minmax(0,2fr)_minmax(0,1fr)] gap-3">
    {STATUS_CARDS.map(({ status, accent, bg }) => {
      const pressed = selectedStatus === status;
      const hint = status === "已完成" ? "成果与记录" : status === "待接受" ? (scope === "assigned" ? "等待对方接受" : "需要我确认") : "继续推进";
      const title = scope === "assigned" ? `我分派的${status}任务数` : status === "待接受" ? "待我接受的任务数" : `我负责的${status}任务数`;
      return <button key={status} type="button" aria-label={`${status} ${counts[status]} 件`} aria-pressed={pressed} aria-controls="task-status-content" title={title} onClick={() => onChange(status)}
        className={`relative text-left px-[18px] pt-[15px] pb-[14px] bg-white border rounded-xl overflow-hidden transition-all focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0052D9]/40 ${pressed ? "" : "border-slate-200 hover:border-slate-300"}`}
        style={pressed ? { borderColor: accent, background: bg, boxShadow: `0 8px 20px -14px ${accent}` } : undefined}>
        <span aria-hidden="true" className="absolute left-0 right-0 top-0 h-[3px] origin-left transition-transform" style={{ background: accent, transform: pressed ? "scaleX(1)" : "scaleX(0)" }} />
        <div className="text-xs tracking-wide transition-colors" style={{ color: pressed ? accent : "#64748b", fontWeight: pressed ? 600 : 400 }}>{status}</div>
        <div className="text-[32px] leading-none font-bold tabular-nums mt-2.5" style={{ color: pressed ? accent : "#0f172a" }}>{counts[status]}<span className="text-xs text-slate-400 font-normal ml-1">件</span></div>
        <div className="mt-2 text-[11px] flex items-center gap-1.5 text-slate-400"><span aria-hidden="true" className="w-[5px] h-[5px] rounded-full" style={{ background: accent, opacity: pressed ? 1 : 0.55 }} />{hint}</div>
      </button>;
    })}
  </section>;
}