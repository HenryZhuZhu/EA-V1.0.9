import { useState } from "react";
import { Check, ChevronDown } from "lucide-react";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "./ui/command";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";
import type { BusinessKind, BusinessReference, TaskFilters } from "./taskWorkbenchModel";

type BusinessFilter = Pick<TaskFilters, "businessKind" | "businessKey">;
const KINDS = ["产品", "Project", "TF"] as const;
const objectLabel = (ref: BusinessReference) => `${ref.name}${ref.nameOnly ? "（名称记录）" : ""}`;
const compactObjectLabel = (ref: BusinessReference) => ref.kind === "产品" ? ref.name.split(" · ")[0] : objectLabel(ref);

export function businessKindFilter(kind: string): BusinessFilter | undefined {
  if (kind === "all" || kind === "none" || KINDS.some(item => item === kind)) {
    return { businessKind: kind as BusinessFilter["businessKind"], businessKey: "" };
  }
}

export function businessObjectFilter(kind: BusinessFilter["businessKind"], key: string, options: BusinessReference[]): BusinessFilter | undefined {
  if (kind === "all" || kind === "none") return;
  if (!key || options.some(ref => ref.kind === kind && ref.key === key)) return { businessKind: kind, businessKey: key };
}

export function searchBusinessOptions(options: BusinessReference[], kind: BusinessFilter["businessKind"], query = "") {
  const terms = query.trim().toLocaleLowerCase().split(/\s+/).filter(Boolean);
  return options.filter(ref => ref.kind === kind && terms.every(term => objectLabel(ref).toLocaleLowerCase().includes(term)));
}

// 类型与对象是同一个业务条件：先选整类，再可选地缩小到精确对象。
export function TaskBusinessFilter({ filters, options, onChange, className, kinds = KINDS }: {
  filters: BusinessFilter;
  options: BusinessReference[];
  onChange: (patch: BusinessFilter) => void;
  className: string;
  kinds?: readonly BusinessKind[];
}) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const kind = filters.businessKind;
  const hasKind = kind !== "all" && kind !== "none";
  const allLabel = `全部${kind === "产品" ? "产品" : ` ${kind}`}`;
  const selected = options.find(ref => ref.kind === kind && ref.key === filters.businessKey);
  const label = !hasKind ? "—" : filters.businessKey ? selected ? compactObjectLabel(selected) : "已选对象" : allLabel;
  const title = !hasKind ? kind === "none" ? "未关联涉及对象，无需选择具体对象" : "选择产品、Project 或 TF 后可选择具体对象" : filters.businessKey ? selected ? objectLabel(selected) : "已选对象（当前视角无任务）" : allLabel;
  const visible = searchBusinessOptions(options, kind, query);
  const choose = (key: string) => {
    const patch = businessObjectFilter(kind, key, options);
    if (patch) { onChange(patch); setOpen(false); setQuery(""); }
  };

  return <div data-slot="task-business-filter" className="mt-1 flex h-8 min-w-0 items-center rounded-md border border-slate-200 bg-white focus-within:border-[#0052D9]">
    <select aria-label="任务涉及类型" value={kind} className={`${className} !mt-0 !h-[26px] !w-[100px] !border-0 !bg-transparent shrink-0`} onChange={event => {
      const patch = businessKindFilter(event.target.value);
      if (patch) { onChange(patch); setOpen(false); setQuery(""); }
    }}>
      <option value="all">全部</option>
      <option value="none">无</option>
      {kinds.map(value => <option key={value} value={value}>{value}</option>)}
    </select>
    <span aria-hidden="true" className="h-4 w-px shrink-0 bg-slate-200" />
    <Popover open={open && hasKind} onOpenChange={next => { setOpen(next); setQuery(""); }}>
      <PopoverTrigger asChild>
        <button type="button" aria-label="具体涉及对象" disabled={!hasKind} title={title} className={`${className} !mt-0 !h-6 !border-0 !bg-transparent !flex flex-1 items-center justify-between gap-2 text-left disabled:cursor-not-allowed`}>
          <span className="truncate">{label}</span><ChevronDown size={12} className="shrink-0" />
        </button>
      </PopoverTrigger>
      <PopoverContent align="start" aria-label="选择具体涉及对象" className="w-[var(--radix-popover-trigger-width)] min-w-[280px] max-w-[420px] p-0">
        <Command label="搜索涉及对象" shouldFilter={false} defaultValue={filters.businessKey || "all-objects"}>
          <CommandInput aria-label="搜索涉及对象" placeholder="搜索" value={query} onValueChange={setQuery} className="text-xs" />
          <CommandList label="涉及对象候选" className="max-h-60">
            <CommandEmpty>{query.trim() ? "没有匹配的对象" : "当前范围暂无可选对象"}</CommandEmpty>
            <CommandGroup>
              {!query.trim() && <CommandItem value="all-objects" onSelect={() => choose("")} className="text-xs data-[selected=true]:bg-blue-50 data-[selected=true]:text-[#0052D9]">
                <Check className={filters.businessKey ? "opacity-0" : "opacity-100"} />{allLabel}
              </CommandItem>}
              {visible.map(ref => <CommandItem key={ref.key} value={ref.key} title={objectLabel(ref)} onSelect={() => choose(ref.key)} className="text-xs data-[selected=true]:bg-blue-50 data-[selected=true]:text-[#0052D9]">
                <Check className={filters.businessKey === ref.key ? "opacity-100" : "opacity-0"} /><span className="min-w-0 break-words">{objectLabel(ref)}</span>
              </CommandItem>)}
            </CommandGroup>
            {!query.trim() && !visible.length && <p className="px-3 py-3 text-center text-xs text-slate-400">当前范围暂无可选对象</p>}
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  </div>;
}