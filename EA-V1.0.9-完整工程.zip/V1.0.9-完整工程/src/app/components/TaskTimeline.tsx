import { CheckCircle2, Circle, Clock, AlertCircle, Ban, Hourglass, ChevronRight } from "lucide-react";
import { TaskNode, levelColors } from "./data";

interface Props {
  tasks: TaskNode[];
  pinnedId?: string | null;
  onTaskClick: (taskId: string) => void;
}

interface FlatTask {
  task: TaskNode;
  depth: number;
  path: string;
}

function flatten(nodes: TaskNode[], depth = 0, parentPath = ""): FlatTask[] {
  const out: FlatTask[] = [];
  nodes.forEach((n, i) => {
    const path = parentPath ? `${parentPath}.${i + 1}` : `${i + 1}`;
    out.push({ task: n, depth, path });
    if (n.children?.length) out.push(...flatten(n.children, depth + 1, path));
  });
  return out;
}

const statusMeta: Record<TaskNode["status"], { icon: any; color: string; bg: string; ring: string }> = {
  "待接受": { icon: Hourglass, color: "#d97706", bg: "#fef3c7", ring: "#fcd34d" },
  "进行中": { icon: Clock, color: "#0052D9", bg: "#dbeafe", ring: "#93c5fd" },
  "已拒绝": { icon: Ban, color: "#dc2626", bg: "#fee2e2", ring: "#fca5a5" },
  "已完成": { icon: CheckCircle2, color: "#16a34a", bg: "#dcfce7", ring: "#86efac" },
  "已中止": { icon: AlertCircle, color: "#64748b", bg: "#f1f5f9", ring: "#cbd5e1" },
};

export function TaskTimeline({ tasks, pinnedId, onTaskClick }: Props) {
  const flat = flatten(tasks);
  if (flat.length === 0) return null;

  const done = flat.filter((f) => f.task.status === "已完成").length;
  const inProgress = flat.filter((f) => f.task.status === "进行中").length;
  const blocked = flat.filter((f) => f.task.status === "已中止").length;
  const pct = Math.round((done / flat.length) * 100);

  return (
    <div className="border border-slate-200 rounded-lg bg-white">
      {/* Header */}
      <div className="px-4 py-3 border-b border-slate-100 flex items-center gap-3">
        <div className="flex items-center gap-1.5">
          <span className="text-sm text-slate-900">任务推进路径</span>
          <span className="text-xs text-slate-400">任务视图 · 线性视图</span>
        </div>
        <div className="ml-auto flex items-center gap-3 text-xs">
          <span className="text-slate-500">共 {flat.length} 个任务</span>
          <span className="flex items-center gap-1 text-emerald-600">
            <CheckCircle2 size={12} /> {done} 完成
          </span>
          <span className="flex items-center gap-1 text-[#0052D9]">
            <Clock size={12} /> {inProgress} 进行中
          </span>
          {blocked > 0 && (
            <span className="flex items-center gap-1 text-red-600">
              <AlertCircle size={12} /> {blocked} 已中止
            </span>
          )}
        </div>
      </div>

      {/* Progress bar */}
      <div className="px-4 pt-3">
        <div className="flex items-center gap-2 mb-2">
          <div className="flex-1 h-1.5 rounded-full bg-slate-100 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-emerald-400 to-emerald-500 transition-all"
              style={{ width: `${pct}%` }}
            />
          </div>
          <span className="text-xs text-slate-500 tabular-nums w-10 text-right">{pct}%</span>
        </div>
      </div>

      {/* Horizontal timeline (scrollable) */}
      <div className="px-4 py-4 overflow-x-auto">
        <div className="relative flex items-start min-w-min" style={{ minHeight: 104 }}>
          {/* Connecting line */}
          <div
            className="absolute left-0 right-0 h-0.5 bg-slate-200"
            style={{ top: 20 }}
          />

          {flat.map((f, idx) => {
            const meta = statusMeta[f.task.status];
            const Icon = meta.icon;
            const isPinned = pinnedId === f.task.id;
            const lvlKey = (`L${Math.min(f.depth + 1, 5)}`) as keyof typeof levelColors;
            const lvlClass = levelColors[lvlKey];
            return (
              <div
                key={f.task.id}
                className="relative flex flex-col items-center px-2 shrink-0"
                style={{ width: 168 }}
              >
                {/* Step index above node */}
                <div className="absolute -top-0 left-0 right-0 flex justify-center pointer-events-none">
                  <span className="text-[10px] text-slate-400 tabular-nums bg-white px-1">
                    {f.path}
                  </span>
                </div>

                {/* Node */}
                <button
                  onClick={() => onTaskClick(f.task.id)}
                  className="relative z-10 w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all hover:scale-110 shadow-sm"
                  style={{
                    background: meta.bg,
                    borderColor: isPinned ? "#0052D9" : meta.ring,
                    boxShadow: isPinned ? "0 0 0 3px rgba(0,82,217,0.15)" : undefined,
                  }}
                  title={f.task.title}
                >
                  <Icon size={16} style={{ color: meta.color }} />
                </button>

                {/* Level chip + arrow indicator for depth */}
                <div className="mt-2 flex items-center gap-1">
                  <span className={`text-[10px] px-1.5 py-0.5 rounded border font-medium tabular-nums ${lvlClass}`}>
                    {lvlKey}
                  </span>
                  {f.task.urgency === "高" && (
                    <span className="text-[10px] px-1 py-0.5 rounded bg-red-50 text-red-600">急</span>
                  )}
                </div>

                {/* Title */}
                <button
                  onClick={() => onTaskClick(f.task.id)}
                  className="mt-1.5 text-xs text-slate-800 text-center line-clamp-2 hover:text-[#0052D9] transition-colors leading-tight"
                  style={{ maxWidth: 144 }}
                >
                  {f.task.title}
                </button>

                {/* Owner */}
                <div className="mt-1 text-[10px] text-slate-500 truncate" style={{ maxWidth: 144 }}>
                  {f.task.owner}
                </div>

                {/* Arrow between nodes */}
                {idx < flat.length - 1 && (
                  <div
                    className="absolute z-0 text-slate-300"
                    style={{ top: 14, right: -6 }}
                  >
                    <ChevronRight size={14} />
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
