import type { ReactNode } from "react";
import * as Dialog from "@radix-ui/react-dialog";
import { X } from "lucide-react";

export function TaskDialog({ title, description, onClose, children, footer, wide = false }: {
  title: string;
  description: string;
  onClose: () => void;
  children: ReactNode;
  footer: ReactNode;
  wide?: boolean;
}) {
  return <Dialog.Root open onOpenChange={(open) => { if (!open) onClose(); }}>
    <Dialog.Portal>
      <Dialog.Overlay className="fixed inset-0 z-[100] bg-slate-900/35 backdrop-blur-[2px]" />
      <Dialog.Content onPointerDownOutside={(event) => event.preventDefault()} className={`fixed left-1/2 top-1/2 z-[101] flex max-h-[90vh] ${wide ? "w-[860px]" : "w-[720px]"} -translate-x-1/2 -translate-y-1/2 flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-[0_24px_80px_-20px_rgba(15,23,42,0.3)] outline-none`}>
        <div className="flex shrink-0 items-start justify-between border-b border-slate-100 px-7 py-5"><div><Dialog.Title className="text-[20px] font-semibold tracking-tight text-slate-900">{title}</Dialog.Title><Dialog.Description className="mt-1.5 text-[12px] leading-relaxed text-slate-500">{description}</Dialog.Description></div><Dialog.Close aria-label="关闭弹窗" className="-mr-1 grid h-8 w-8 place-items-center rounded-lg text-slate-400 hover:bg-slate-100 hover:text-slate-600"><X size={17} /></Dialog.Close></div>
        <div className="min-h-0 flex-1 overflow-y-auto px-7 py-5">{children}</div>
        <div className="flex shrink-0 items-center justify-end gap-2.5 border-t border-slate-100 bg-slate-50/50 px-7 py-4">{footer}</div>
      </Dialog.Content>
    </Dialog.Portal>
  </Dialog.Root>;
}