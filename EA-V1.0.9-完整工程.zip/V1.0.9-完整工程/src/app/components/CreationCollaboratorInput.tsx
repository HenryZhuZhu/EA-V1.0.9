import { ownerToDepartment } from "./data";
import { MultiPersonInput } from "./PersonInput";

// 创建 Case / 任务共用人员选择及已选头像样式；不改变各自保存的人员模型。
export function CreationCollaboratorInput({ value, onChange, exclude = [], selectedInside = false }: {
  value: { name: string; department?: string }[];
  onChange: (names: string[]) => void;
  exclude?: string[];
  selectedInside?: boolean;
}) {
  return <div role="group" aria-label="协作者选择">
    <MultiPersonInput value={value.map((person) => person.name)} onChange={onChange} exclude={exclude} placeholder="添加协作者（可选）" selectedInside={selectedInside} />
    {!selectedInside && value.length > 0 && <div className="mt-2 flex items-center justify-between gap-3">
      <span className="text-[11px] text-slate-400">已选 {value.length} 人</span>
      <div className="flex items-center -space-x-1.5">
        {value.map((person) => {
          const label = `${person.name} · ${person.department ?? ownerToDepartment[person.name] ?? "—"}`;
          return <div key={person.name} className="relative group" title={label}>
            <div className="w-6 h-6 rounded-full bg-gradient-to-br from-[#0052D9] to-[#00A4FF] flex items-center justify-center text-white text-[10px] border-2 border-white cursor-pointer">
              {person.name.slice(-2)}
            </div>
            <div className="absolute bottom-full right-0 mb-2 px-2 py-1 bg-slate-800 text-white text-[10px] rounded whitespace-nowrap opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity z-10">
              {label}
            </div>
          </div>;
        })}
      </div>
    </div>}
  </div>;
}