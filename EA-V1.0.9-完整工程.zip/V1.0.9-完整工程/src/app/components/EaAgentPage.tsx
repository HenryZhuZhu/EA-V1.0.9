import { useEffect, useRef, useState } from "react";
import { Check, Minimize2, Pencil, X } from "lucide-react";
import { AiAssistant } from "./AiAssistant";
import { AgentSessionControls } from "./AgentSessionControls";
import type { AgentConversation } from "./useAgentConversation";
import { AGENT_MAX_MESSAGE } from "./eaAgentModel";
import "./eaAgent.css";

export function EaAgentPage({ conversation, onOpenWindow }: { conversation: AgentConversation; onOpenWindow: () => void }) {
  const input = useRef<HTMLTextAreaElement>(null);
  const [historyExpanded, setHistoryExpanded] = useState(false);
  const [renaming, setRenaming] = useState(false);
  const activeSession = conversation.sessions.find(item => item.id === conversation.activeSessionId)!;
  const [titleDraft, setTitleDraft] = useState(activeSession.title);
  useEffect(() => { input.current?.focus(); }, []);
  useEffect(() => { setRenaming(false); setTitleDraft(activeSession.title); }, [activeSession.id]);
  const saveTitle = () => {
    const title = titleDraft.trim();
    if (title) conversation.renameSession(activeSession.id, title);
    setRenaming(false);
  };
  return <section aria-label="EA Agent 助手页面" className="ea-agent-page">
    <aside aria-label="EA Agent 对话侧栏" className={`ea-agent-session-sidebar${historyExpanded ? " is-expanded" : ""}`}><AgentSessionControls sidebar conversation={conversation} onExpandedChange={setHistoryExpanded} /></aside>
    <div className="ea-agent-page-main">
    <div className={`ea-agent-page-title${renaming ? " is-editing" : ""}`}>{renaming ? <form className="ea-agent-page-title-form" onSubmit={event => { event.preventDefault(); saveTitle(); }}><input autoFocus aria-label="对话名称" maxLength={80} value={titleDraft} onChange={event => setTitleDraft(event.target.value)} /><button type="submit" aria-label="保存对话名称" disabled={!titleDraft.trim()}><Check size={13} /></button><button type="button" aria-label="取消重命名" onClick={() => { setTitleDraft(activeSession.title); setRenaming(false); }}><X size={13} /></button></form> : <><span title={activeSession.title}>{activeSession.title}</span><button type="button" aria-label={`重命名 ${activeSession.title}`} title="重命名" className="ea-agent-page-title-rename" onClick={() => { setTitleDraft(activeSession.title); setRenaming(true); }}><Pencil size={12} /></button></>}<button type="button" aria-label="返回 EA Agent 小窗" title="返回小窗" className="ea-agent-page-window" onClick={onOpenWindow}><Minimize2 size={14} /></button></div>
    {conversation.storageError && <p role="alert" className="px-6 py-2 text-xs text-amber-700">{conversation.storageError}<button type="button" onClick={conversation.retrySave} className="ml-2 underline">重试保存</button></p>}
    <AiAssistant key={conversation.activeSessionId} messages={conversation.messages} draft={conversation.draft} isRunning={conversation.isRunning} onDraftChange={conversation.setDraft} onSend={text => {
      if (text.trim() && text.trim().length <= AGENT_MAX_MESSAGE) conversation.send(text, { useSkill: false });
      input.current?.focus();
    }} inputRef={input} expanded showPrompts />
    </div>
  </section>;
}