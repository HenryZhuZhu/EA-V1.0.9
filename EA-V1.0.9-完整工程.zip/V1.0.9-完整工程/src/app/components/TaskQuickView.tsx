import { useState } from "react";
import * as Dialog from "@radix-ui/react-dialog";
import { ArrowUpRight, X } from "lucide-react";
import { currentUser, urgencyColors, type TaskNode } from "./data";
import { commentOnStandaloneTask, type StandaloneTask } from "./standaloneTasks";
import { commentOnCaseTask } from "./caseTaskTrees";
import { TaskAttachmentList } from "./TaskAttachmentList";
import { VoicePlayer } from "./VoiceNote";
import { TaskActivityPanel } from "./TaskActivityPanel";
import { RejectTaskModal } from "./RejectTaskModal";
import { businessLabel, taskCanAct, type WorkbenchTask } from "./taskWorkbenchModel";

export function TaskQuickView({ row, onClose, onOpenDetail, onOpenCase, onRespond, onRestoreFocus }: {
  row: WorkbenchTask; onClose: () => void; onOpenDetail: () => void; onOpenCase: (id: string) => void;
  onRespond: (response: "accept" | "reject", reason?: string) => void; onRestoreFocus: (event: Event) => void;
}) {
  const [rejecting, setRejecting] = useState(false);
  const [error, setError] = useState("");
  const pending = taskCanAct(row, currentUser.name) && row.status === "待接受";
  const record = row.record;
  const resultFiles = row.source === "standalone" ? (record as StandaloneTask).resultAttachments : undefined;
  const accept = () => {
    try { onRespond("accept"); setError(""); } catch (reason) { setError(reason instanceof Error ? reason.message : "操作失败，请重试。"); }
  };
  return <Dialog.Root open onOpenChange={open => { if (!open) onClose(); }}>
    <Dialog.Portal>
      <Dialog.Overlay className="fixed inset-0 z-[100] bg-slate-900/25" />
      <Dialog.Content onCloseAutoFocus={onRestoreFocus} className="fixed inset-y-0 right-0 z-[101] flex w-[680px] max-w-[calc(100vw-64px)] flex-col border-l border-slate-200 bg-white shadow-2xl outline-none">
        <header className="flex shrink-0 items-start gap-3 border-b border-slate-100 p-5">
          <div className="min-w-0 flex-1"><div className="mb-2 flex items-center gap-2 text-xs text-slate-500"><span>{row.convertedCaseId ? "已升级为 Case" : row.status}</span><span className={`rounded px-1.5 py-0.5 text-[10px] ${urgencyColors[row.urgency]}`}>{row.urgency}</span></div><Dialog.Title className="break-words text-base font-semibold text-slate-900">{row.title}</Dialog.Title><Dialog.Description className="mt-1 font-mono text-[11px] text-slate-400">{row.code}</Dialog.Description></div>
          <Dialog.Close aria-label="关闭任务速览" className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-slate-400 hover:bg-slate-100 focus-visible:outline-2 focus-visible:outline-[#0052D9]"><X size={17} /></Dialog.Close>
        </header>
        <div className="min-h-0 flex-1 space-y-4 overflow-y-auto bg-slate-50/50 p-5">
          <section aria-label="任务基本信息" className="rounded-xl border border-slate-200 bg-white p-4">
            {row.caseItem && <button type="button" onClick={() => onOpenCase(row.caseItem!.id)} className="mb-3 flex w-full items-start gap-1.5 text-left text-xs text-[#0052D9] hover:underline"><span className="min-w-0 break-words">{row.caseItem.code} · {row.caseItem.name}</span><ArrowUpRight size={13} className="shrink-0" /></button>}
            {row.caseClosed && <p className="mb-3 rounded-lg bg-slate-100 p-2 text-xs text-slate-500">所属 Case 已结案，任务保留原状态供查阅。</p>}
            {row.convertedCaseId && <button type="button" onClick={() => onOpenCase(row.convertedCaseId!)} className="mb-3 flex items-center gap-1 text-xs text-[#0052D9]">{row.convertedCaseName || "查看升级后的 Case"}<ArrowUpRight size={13} /></button>}
            <dl className="grid grid-cols-2 gap-x-5 gap-y-3 text-xs">
              <div><dt className="mb-1 text-slate-400">负责人</dt><dd className="text-slate-700">{row.owner}</dd></div>
              <div><dt className="mb-1 text-slate-400">{row.source === "case" ? "分派人" : "创建人"}</dt><dd className="text-slate-700">{row.creator || "未记录"}</dd></div>
              <div><dt className="mb-1 text-slate-400">截止日期</dt><dd className="text-slate-700">{row.dueDate || "未设置"}</dd></div>
              <div><dt className="mb-1 text-slate-400">最近更新</dt><dd className="text-slate-700">{row.updatedAt ? new Date(row.updatedAt).toLocaleString("zh-CN", { hour12: false }) : "未记录"}</dd></div>
              <div className="col-span-2"><dt className="mb-1 text-slate-400">协作者{row.participantsFromCase && row.participants.length > 0 ? "（来自 Case）" : ""}</dt><dd className="break-words text-slate-700">{row.participants.join("、") || "无"}</dd></div>
              {row.business.length > 0 && <div className="col-span-2"><dt className="mb-1 text-slate-400">任务涉及</dt><dd className="space-y-1 break-words text-slate-700">{row.business.map(ref => <p key={ref.key}>{businessLabel(ref)}</p>)}</dd></div>}
            </dl>
            <div className="mt-4 border-t border-slate-100 pt-3"><h3 className="mb-2 text-xs text-slate-400">任务说明</h3><p className="whitespace-pre-wrap break-words text-sm leading-relaxed text-slate-600">{row.description || "未填写"}</p></div>
            <TaskAttachmentList attachments={record.attachments} modalPreview />
            {record.voiceNote && <div className="mt-3"><VoicePlayer src={record.voiceNote} /></div>}
            {[["拒绝理由", row.status === "已拒绝" ? row.rejectReason : undefined], ["中止原因", row.status === "已中止" ? row.terminateReason : undefined], ["退回重做原因", row.status === "进行中" ? row.reworkReason : undefined]].map(([label, reason]) => reason ? <div key={label} className="mt-3 rounded-md bg-slate-50 p-3 text-xs"><span className="block text-slate-400">{label}</span><p className="mt-1 whitespace-pre-wrap break-words text-slate-600">{reason}</p></div> : null)}
          </section>
          {(row.conclusion || row.analysisProcess || resultFiles?.length) && <section aria-label="处理过程与结果" className="rounded-xl border border-slate-200 bg-white p-4">
            <h3 className="mb-3 text-sm font-medium text-slate-800">处理过程与结果</h3>
            {row.conclusion && <p className="whitespace-pre-wrap break-words text-sm leading-relaxed text-slate-700">{row.conclusion}</p>}
            {row.analysisProcess && <details className="mt-3 text-xs text-slate-500"><summary className="cursor-pointer text-[#0052D9]">查看处理过程</summary><p className="mt-2 whitespace-pre-wrap break-words leading-relaxed">{row.analysisProcess}</p></details>}
            {resultFiles && resultFiles.length > 0 && <TaskAttachmentList attachments={resultFiles} label="结果附件" modalPreview />}
          </section>}
          <TaskActivityPanel compact activities={record.activityLog} comments={record.comments} statusHistory={row.source === "case" ? (record as TaskNode).statusHistory : undefined} onComment={(content, replyTo) => { if (row.source === "case") commentOnCaseTask(row.caseItem!.id, row.id, content, replyTo); else commentOnStandaloneTask(row.id, content, replyTo); }} readOnlyReason={row.convertedCaseId ? "来源记录保留供追溯，请在关联 Case 的对应任务中继续讨论。" : undefined} />
        </div>
        <footer className="shrink-0 border-t border-slate-200 bg-white p-4">
          {error && <p role="alert" className="mb-2 text-xs text-red-600">{error}</p>}
          <div className="flex justify-end gap-2">
            {pending && <><button type="button" onClick={() => setRejecting(true)} className="h-9 rounded-md border border-slate-200 px-3 text-sm text-slate-600">拒绝</button><button type="button" onClick={accept} className="h-9 rounded-md bg-[#0052D9] px-3 text-sm text-white hover:bg-[#003FA8]">接受并开始</button></>}
            <button type="button" onClick={onOpenDetail} className="inline-flex h-9 items-center gap-1.5 rounded-md border border-[#0052D9]/30 px-3 text-sm text-[#0052D9] hover:bg-blue-50">进入完整详情<ArrowUpRight size={14} /></button>
          </div>
        </footer>
        {rejecting && <RejectTaskModal title={row.title} onClose={() => setRejecting(false)} onConfirm={reason => { onRespond("reject", reason); setError(""); }} />}
      </Dialog.Content>
    </Dialog.Portal>
  </Dialog.Root>;
}