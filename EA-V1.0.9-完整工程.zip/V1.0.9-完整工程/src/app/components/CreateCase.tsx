import React, { useEffect, useMemo, useRef, useState } from "react";
import { saveCaseEdit } from "./closures";
import {
  Lightbulb,
  Shield,
  Sparkles,
  Plus,
  Network,
  Check,
  Search,
  X as XIcon,
  Users,
  Globe,
  Edit2,
  Trash2,
  Calendar,
  RotateCcw,
  HelpCircle,
  Fingerprint,
  MousePointerClick,
  Hash,
  ChevronLeft,
  ChevronRight,
  Cpu,
  ClipboardList,
  ExternalLink,
  Wand2,
  Loader2,
  ClipboardPaste,
  TableProperties,
  ChevronDown,
} from "lucide-react";
import {
  departments,
  mockCases,
  levelColors,
  LEVEL_DESC,
  LEVEL_ORDER,
  currentUser,
  CaseItem,
  TaskNode,
  Urgency,
  Level,
  ownerToDepartment,
  productById,
  IssueSource,
  issueStatusColors,
  objectTypeColors,
  OBJECT_TYPES,
  ANALYSIS_TEMPLATES,
  AnalysisTemplateId,
  CR_PIPELINE,
  crStageDefaultOwner,
  buildCrPipelineStages,
  PROBLEM_DOMAINS,
  PROBLEM_TYPES,
  ProblemDomain,
  ProblemType,
  TaskType,
  resolveDimmIcTree,
  DimmDie,
  DimmIcTree,
  CaseGranule,
  genMarkCode,
  markCodeMaterialOf,
} from "./data";
import { createManualCase, aggregateCase, createIssue, useIssues, linkChildren, bindRelatedCases, linkCases } from "./domainStore";
import { AIPolishButton } from "./AIPolishButton";
import { VoiceInputButton } from "./VoiceInputButton";
import { AttachmentInput, Att } from "./AttachmentInput";
import { MultiPersonInput, PersonInput } from "./PersonInput";
import { CreationCollaboratorInput } from "./CreationCollaboratorInput";
import { CreateCaseMindMapFlow } from "./CreateCaseMindMapFlow";
import { CreateCaseWbsTable } from "./CreateCaseWbsTable";
import { CaseProductPill } from "./CaseProductPill";
import { ProductPicker } from "./ProductPicker";
import { OptionCard } from "./OptionCard";
import { SegmentedControl } from "./ui/segmented-control";
import { DraftCaseSimilarityInput, suggestRelatedCasesForDraft } from "./caseInsights";

export type CreateCaseMode =
  | "create"
  | "upgrade"
  | "approve"
  | "edit";

// 从详情页「DIMM Chip ID」跳转新建时携带的预填数据
export interface CreatePrefill {
  parentCaseId?: string;
  sourceStandaloneTaskIds?: string[];
  name?: string;
  reason?: string;
  background?: string;
  impact?: string;
  problemDomain?: ProblemDomain;
  problemType?: ProblemType;
  level?: Level;
  urgency?: Urgency;
  dueDate?: string;
  productIds?: string[];
  material?: string;
  density?: string;
  ioType?: string;
  failStage?: string;
  customer?: string;
  failPlatform?: string;
  failMode?: string;
  chipId?: string;
  failCondition?: string;
  relatedCaseIds?: string[];
}

interface Props {
  onDone: () => void;
  mode?: CreateCaseMode;
  initialCase?: CaseItem;
  onCreated?: (caseId: string) => void;
  prefill?: CreatePrefill;
}

import { standaloneTaskById, upgradeStandaloneTasksToCase } from "./standaloneTasks";

const CASE_SOURCES: IssueSource[] = ["手动", "Q·FAQA", "MC·WBS", "SC·FAE"];
// 紧急度 → 建议层级（默认值，用户可手动改；L0 保留给手动，用于客户/生产中断级重大问题）
const AUTO_LEVEL: Record<Urgency, Level> = { 非常紧急: "L1", 紧急: "L2", 一般: "L3", 不紧急: "L3" };
const ISSUE_STATUS_OPTS = ["进行中", "已准备好解决方案", "解决方案验证中", "已结案"];
const MATERIAL_OPTIONS = ["不适用", "Wafer", "Die/IC", "DIMM", "CAMM"] as const;
const MATERIAL_SUBTYPES: Record<"DIMM" | "CAMM", readonly string[]> = {
  DIMM: ["RDIMM", "UDIMM", "SoDIMM", "MRDIMM", "LRDIMM", "CUDIMM", "CSODIMM"],
  CAMM: ["LPCAMM", "LRCAMM"],
};

// 物料层级元信息：用于图形化选择卡片（晶圆 → 颗粒 → 模组）
const MATERIAL_META: Record<(typeof MATERIAL_OPTIONS)[number], { level: string; desc: string }> = {
  "不适用": { level: "无载体", desc: "不涉及具体物料" },
  "Wafer": { level: "晶圆级", desc: "按 Wafer + IC 定位失效位置" },
  "Die/IC": { level: "颗粒级", desc: "已封装 DRAM 芯片（内存颗粒）" },
  "DIMM": { level: "模组级", desc: "内存模组（RDIMM/UDIMM），可拆分为多个独立 Case" },
  "CAMM": { level: "模组级", desc: "压接式内存模组（LPCAMM/LRCAMM），可拆分为多个独立 Case" },
};

const SUBTYPE_META: Record<string, string> = {
  RDIMM: "带寄存器缓冲",
  UDIMM: "无缓冲直连",
  SoDIMM: "笔电/小型模组",
  MRDIMM: "多路复用高带宽",
  LRDIMM: "降载缓冲",
  CUDIMM: "带时钟驱动无缓冲",
  CSODIMM: "带时钟驱动小型模组",
  LPCAMM: "低功耗压接",
  LRCAMM: "降载缓冲压接",
};

interface WaferLotDraft {
  id: string;
  lotId: string;
  waferIds: string[];
  wholeLot: boolean;
}

function waferLotsFromGranules(granules?: CaseGranule[]): WaferLotDraft[] {
  const grouped = new Map<string, { waferIds: Set<string>; wholeLot: boolean }>();
  (granules ?? []).forEach((granule) => {
    const waferId = granule.waferId?.trim().toUpperCase();
    const lotId = (granule.lotId?.trim() || (waferId?.length === 12 ? waferId.slice(0, 7) : "")).toUpperCase();
    if (!lotId) return;
    if (!grouped.has(lotId)) grouped.set(lotId, { waferIds: new Set(), wholeLot: false });
    const group = grouped.get(lotId)!;
    if (granule.wholeLot) group.wholeLot = true;
    else if (waferId) group.waferIds.add(waferId);
  });
  return [...grouped.entries()].map(([lotId, group]) => ({
    id: crypto.randomUUID(),
    lotId,
    waferIds: [...group.waferIds].sort(),
    wholeLot: group.wholeLot,
  }));
}

function parseWaferIdentifiers(raw: string): { values: string[]; invalid: string[] } {
  const values = raw.split(/[,，、;；\s]+/).map((value) => value.trim().toUpperCase()).filter(Boolean);
  return {
    values: Array.from(new Set(values.filter((value) => /^[A-Z0-9]{7}$|^[A-Z0-9]{12}$/.test(value)))),
    invalid: values.filter((value) => !/^[A-Z0-9]{7}$|^[A-Z0-9]{12}$/.test(value)),
  };
}

// 物料图形化图标：明暗随选中态切换，配色遵循 #0052D9 主色（金手指 #E0A437）
function MaterialIcon({ value, active }: { value: string; active: boolean }) {
  const c = active ? "#0052D9" : "#94A3B8";
  const soft = active ? "#7FA8F0" : "#CBD5E1";
  const gold = active ? "#E0A437" : "#CBD5E1";
  const fill = active ? "#0052D9" : "#E2E8F0";
  const fillOp = active ? 0.12 : 1;
  switch (value) {
    case "不适用":
      return (
        <svg width="30" height="26" viewBox="0 0 30 26" fill="none" aria-hidden>
          <circle cx="15" cy="13" r="8.5" stroke={c} strokeWidth="1.5" strokeDasharray="3 2.5" />
          <line x1="9.5" y1="18.5" x2="20.5" y2="7.5" stroke={c} strokeWidth="1.5" strokeLinecap="round" />
        </svg>
      );
    case "Wafer":
      return (
        <svg width="30" height="26" viewBox="0 0 30 26" fill="none" aria-hidden>
          <circle cx="15" cy="13" r="9.5" fill={fill} fillOpacity={fillOp} stroke={c} strokeWidth="1.4" />
          <g stroke={soft} strokeWidth="0.8">
            <line x1="6" y1="9" x2="24" y2="9" /><line x1="5.5" y1="13" x2="24.5" y2="13" /><line x1="6" y1="17" x2="24" y2="17" />
            <line x1="11" y1="4" x2="11" y2="22" /><line x1="15" y1="3.5" x2="15" y2="22.5" /><line x1="19" y1="4" x2="19" y2="22" />
          </g>
          <path d="M13 22.3 a9.5 9.5 0 0 0 4 0 l0 1.4 l-4 0 z" fill="#fff" />
        </svg>
      );
    case "Die/IC":
      return (
        <svg width="30" height="26" viewBox="0 0 30 26" fill="none" aria-hidden>
          <rect x="9" y="6" width="12" height="14" rx="2" fill={fill} fillOpacity={fillOp} stroke={c} strokeWidth="1.4" />
          <rect x="12.5" y="9.5" width="5" height="7" rx="1" fill={c} fillOpacity={active ? 0.45 : 0.3} />
          <g stroke={c} strokeWidth="1.3" strokeLinecap="round">
            <line x1="5.5" y1="9.5" x2="9" y2="9.5" /><line x1="5.5" y1="13" x2="9" y2="13" /><line x1="5.5" y1="16.5" x2="9" y2="16.5" />
            <line x1="21" y1="9.5" x2="24.5" y2="9.5" /><line x1="21" y1="13" x2="24.5" y2="13" /><line x1="21" y1="16.5" x2="24.5" y2="16.5" />
          </g>
        </svg>
      );
    case "DIMM":
      return (
        <svg width="34" height="24" viewBox="0 0 34 24" fill="none" aria-hidden>
          <rect x="2" y="3.5" width="30" height="13" rx="1.8" fill={fill} fillOpacity={fillOp} stroke={c} strokeWidth="1.2" />
          <rect x="5" y="6.5" width="4.5" height="7" rx="0.8" fill={c} />
          <rect x="11" y="6.5" width="4.5" height="7" rx="0.8" fill={c} />
          <rect x="17" y="6.5" width="4.5" height="7" rx="0.8" fill={c} />
          <rect x="23" y="6.5" width="4.5" height="7" rx="0.8" fill={c} />
          <g stroke={gold} strokeWidth="1.3" strokeLinecap="round">
            <line x1="6" y1="18" x2="6" y2="21" /><line x1="10" y1="18" x2="10" y2="21" /><line x1="14" y1="18" x2="14" y2="21" /><line x1="20" y1="18" x2="20" y2="21" /><line x1="24" y1="18" x2="24" y2="21" /><line x1="28" y1="18" x2="28" y2="21" />
          </g>
        </svg>
      );
    case "CAMM":
      return (
        <svg width="30" height="26" viewBox="0 0 30 26" fill="none" aria-hidden>
          <rect x="4" y="5" width="22" height="14" rx="2.5" fill={fill} fillOpacity={fillOp} stroke={c} strokeWidth="1.3" />
          <rect x="7.5" y="8" width="4" height="8" rx="0.8" fill={c} />
          <rect x="13" y="8" width="4" height="8" rx="0.8" fill={c} />
          <rect x="18.5" y="8" width="4" height="8" rx="0.8" fill={c} />
          <line x1="7" y1="21.5" x2="23" y2="21.5" stroke={gold} strokeWidth="1.4" strokeDasharray="1.6 1.6" strokeLinecap="round" />
        </svg>
      );
    default:
      return null;
  }
}

// 物料二级图形化图标：RDIMM/LRCAMM 高亮寄存器颗粒（青色，避开 AI 专用紫）
function SubtypeIcon({ subtype, active }: { subtype: string; active: boolean }) {
  const c = active ? "#0052D9" : "#94A3B8";
  const reg = active ? "#0EA5B7" : "#CBD5E1";
  const gold = active ? "#E0A437" : "#CBD5E1";
  const isReg = subtype === "RDIMM" || subtype === "LRCAMM";
  return (
    <svg width="32" height="20" viewBox="0 0 34 20" fill="none" aria-hidden className="shrink-0">
      <rect x="2" y="2" width="30" height="12" rx="1.6" fill="none" stroke={c} strokeWidth="1.2" />
      <rect x="5" y="4.5" width="4" height="7" rx="0.7" fill={c} />
      <rect x="10.5" y="4.5" width="4" height="7" rx="0.7" fill={c} />
      <rect x="16" y="4.5" width="4" height="7" rx="0.7" fill={isReg ? reg : c} />
      <rect x="21.5" y="4.5" width="4" height="7" rx="0.7" fill={c} />
      <rect x="27" y="4.5" width="3" height="7" rx="0.7" fill={c} />
      <g stroke={gold} strokeWidth="1.2" strokeLinecap="round">
        <line x1="6" y1="16" x2="6" y2="18.5" /><line x1="12" y1="16" x2="12" y2="18.5" /><line x1="18" y1="16" x2="18" y2="18.5" /><line x1="24" y1="16" x2="24" y2="18.5" />
      </g>
    </svg>
  );
}

function normalizeMaterial(value?: string) {
  if (value === "lot/wafer" || value === "Lot/wafer") return "Wafer";
  if (value === "Lot/IC" || value === "IC" || value === "Chip" || value === "Die/IC") return "Die/IC";
  return value ?? "";
}

const urgencies: Urgency[] = [
  "非常紧急",
  "紧急",
  "一般",
  "不紧急",
];

// R08：权限设置本地记忆
type PermPreset = { type: "all" | "partial"; list: Array<{ id: string; name: string; type: "user" | "dept" }> };
const PERM_KEY = "ea_perm_preset_v1";
function loadPermPreset(): PermPreset | null {
  try {
    const raw = localStorage.getItem(PERM_KEY);
    return raw ? (JSON.parse(raw) as PermPreset) : null;
  } catch {
    return null;
  }
}
function savePermPreset(p: PermPreset) {
  try {
    localStorage.setItem(PERM_KEY, JSON.stringify(p));
  } catch {}
}

export function CreateCase({
  onDone,
  mode = "create",
  initialCase,
  onCreated,
  prefill,
}: Props) {
  const [submitError, setSubmitError] = useState("");
  const savingCase = useRef(false);
  // Core fields
  const [name, setName] = useState(initialCase?.name ?? "");
  const [reason, setReason] = useState(
    initialCase?.reason ?? "",
  );
  const [background, setBackground] = useState(
    initialCase?.background ?? "",
  );
  const [problemDomain, setProblemDomain] = useState<ProblemDomain | "">(
    initialCase?.problemDomain ?? "",
  );
  const [problemType, setProblemType] = useState<ProblemType | "">(
    initialCase?.problemType ?? "",
  );
  const [impact, setImpact] = useState(
    initialCase?.impact ?? "",
  );
  const [caseAttachments, setCaseAttachments] = useState<Att[]>(
    initialCase?.caseAttachments ?? [],
  );
  const [levelReason, setLevelReason] = useState(
    initialCase?.levelReason ?? "",
  );
  const [remark, setRemark] = useState(
    initialCase?.remark ?? "",
  );
  const [level, setLevel] = useState<Level>(
    (initialCase?.level as Level) ?? AUTO_LEVEL["一般"],
  );
  // 是否已被用户/AI/预填手动指定层级；未指定时层级随紧急度自动建议
  const [levelTouched, setLevelTouched] = useState<boolean>(!!initialCase?.level);
  const [levelMenuOpen, setLevelMenuOpen] = useState(false);
  const [urgency, setUrgency] = useState<Urgency>(
    (initialCase?.urgency as Urgency) ?? "一般",
  );
  const [caseOwner, setCaseOwner] = useState(
    initialCase?.owner ?? currentUser.name,
  );
  // 层级默认随紧急度自动建议；一旦用户/AI 手动指定则不再自动跟随
  useEffect(() => {
    if (!levelTouched) setLevel(AUTO_LEVEL[urgency]);
  }, [urgency, levelTouched]);
  const [createdForOther, setCreatedForOther] = useState(
    mode === "create" ? false : !!initialCase?.createdForOther,
  );
  const [collaborators, setCollaborators] = useState(
    initialCase?.participants ?? [],
  );
  const [dueDate, setDueDate] = useState("");

  // Case 之间关联 + 新建过程中动态相似 Case 推荐
  const [relatedCaseIds, setRelatedCaseIds] = useState<string[]>(initialCase?.relatedCaseIds ?? []);
  const [dismissedSimilarityIds, setDismissedSimilarityIds] = useState<string[]>([]);
  const [similarityPreviewId, setSimilarityPreviewId] = useState<string | null>(null);
  const [reuseSourceId, setReuseSourceId] = useState<string | null>(null);
  const [reuseSelectedBranchIds, setReuseSelectedBranchIds] = useState<string[]>([]);
  const [reusedBranchIds, setReusedBranchIds] = useState<Record<string, string[]>>({});
  const [debouncedSimilarityInput, setDebouncedSimilarityInput] = useState<DraftCaseSimilarityInput | null>(null);

  // V1.0.3：来源 + 归属 Issue（人工立案）
  const [source, setSource] = useState<IssueSource>((initialCase?.source as IssueSource) ?? "手动");
  const [attachIssueIds, setAttachIssueIds] = useState<string[]>([]);
  const [newIssueName, setNewIssueName] = useState("");
  const [issueLinkMode, setIssueLinkMode] = useState<"later" | "now">("later");
  const allIssues = useIssues();
  // 归属 Issue 查找 / 过滤（具体过滤项待定，当前：搜索 + objectType + 状态）
  const [issueQ, setIssueQ] = useState("");
  const [issueObjType, setIssueObjType] = useState("全部");
  const [issueStatusF, setIssueStatusF] = useState("全部");
  const filteredIssues = allIssues.filter((iss) => {
    if (issueObjType !== "全部" && iss.objectType !== issueObjType) return false;
    if (issueStatusF !== "全部" && iss.status !== issueStatusF) return false;
    if (issueQ.trim() && ![iss.code, iss.name].join(" ").toLowerCase().includes(issueQ.trim().toLowerCase())) return false;
    return true;
  });

  // Extended basic info (formerly the "expand 全部创建信息" section)
  // 产品可多选（一个 Case 可能覆盖多个产品）；product 为主产品
  const [productIds, setProductIds] = useState<string[]>(
    initialCase?.productIds ?? (initialCase?.product ? [initialCase.product] : []),
  );
  const product = productIds[0] ?? "";
  const [material, setMaterial] = useState(normalizeMaterial(initialCase?.material));
  const [materialSubtype, setMaterialSubtype] = useState(initialCase?.materialSubtype ?? "");
  const materialKey = material === "Die/IC" ? "IC" : material;
  // Mark Code：系统自动生成的 5 位编号，仅 Die/IC · DIMM · CAMM 物料使用
  const [markCode, setMarkCode] = useState(() => initialCase?.markCode || genMarkCode());
  const showMarkCode = !!markCodeMaterialOf(material);
  const isModule = material === "DIMM" || material === "CAMM";
  const [density, setDensity] = useState(
    initialCase?.density ?? "",
  );
  const [ioType, setIoType] = useState(
    initialCase?.ioType ?? initialCase?.bitWidth ?? "",
  );
  const [failStage, setFailStage] = useState(
    initialCase?.failStage ?? "",
  );
  const [customer, setCustomer] = useState(
    initialCase?.customer ?? "",
  );
  const [failPlatform, setFailPlatform] = useState(
    initialCase?.failPlatform ?? "",
  );
  const [failMode, setFailMode] = useState(
    initialCase?.failMode ?? "",
  );
  const [ppm, setPpm] = useState(initialCase?.ppm ?? "");
  const [pdId, setPdId] = useState(initialCase?.pdId ?? "");

  // Wafer / IC / DIMM optional detail fields
  const [failRatio, setFailRatio] = useState(initialCase?.failRatio ?? "");
  const [maskVersion, setMaskVersion] = useState(initialCase?.maskVersion ?? "");
  const [failPackage, setFailPackage] = useState(initialCase?.failPackage ?? "");
  const [program, setProgram] = useState(initialCase?.program ?? "");
  const [caseAttribute, setCaseAttribute] = useState(initialCase?.caseAttribute ?? "");
  const [productGeneration, setProductGeneration] = useState(initialCase?.productGeneration ?? "");
  const [dimmCapacity, setDimmCapacity] = useState(initialCase?.dimmCapacity ?? "");
  const [bitWidth, setBitWidth] = useState(initialCase?.bitWidth ?? "");
  const [projectName, setProjectName] = useState(initialCase?.projectName ?? "");
  const [platformModel, setPlatformModel] = useState(initialCase?.platformModel ?? "");
  const [productPartNumber, setProductPartNumber] = useState(initialCase?.productPartNumber ?? "");

  // Wafer：统一输入 7 位 Lot ID 或 12 位 Wafer ID；Wafer 前 7 位自动识别所属 Lot。
  const [waferLots, setWaferLots] = useState<WaferLotDraft[]>(() => waferLotsFromGranules(initialCase?.granules));
  const [waferIdentifierInput, setWaferIdentifierInput] = useState("");
  const [waferIdentifierError, setWaferIdentifierError] = useState("");

  const commitWaferIdentifiers = (raw = waferIdentifierInput) => {
    if (!raw.trim()) return;
    const parsed = parseWaferIdentifiers(raw);
    setWaferLots((previous) => {
      const next = previous.map((lot) => ({ ...lot, waferIds: [...lot.waferIds] }));
      parsed.values.forEach((value) => {
        const isWafer = value.length === 12;
        const lotId = isWafer ? value.slice(0, 7) : value;
        let lot = next.find((item) => item.lotId === lotId);
        if (!lot) {
          lot = { id: crypto.randomUUID(), lotId, waferIds: [], wholeLot: false };
          next.push(lot);
        }
        if (isWafer) {
          if (!lot.waferIds.includes(value)) lot.waferIds.push(value);
          lot.waferIds.sort();
        } else {
          lot.wholeLot = true;
        }
      });
      return next;
    });
    if (parsed.invalid.length) {
      setWaferIdentifierError(`无法识别：${parsed.invalid.join("、")}。请输入 7 位 Lot ID 或 12 位 Wafer ID。`);
    } else {
      setWaferIdentifierInput("");
      setWaferIdentifierError("");
    }
  };

  const removeWaferLot = (id: string) => {
    setWaferLots((previous) => previous.filter((lot) => lot.id !== id));
  };

  const removeWaferId = (lotDraftId: string, waferId: string) => {
    setWaferLots((previous) => previous
      .map((lot) => lot.id === lotDraftId ? { ...lot, waferIds: lot.waferIds.filter((id) => id !== waferId) } : lot)
      .filter((lot) => lot.wholeLot || lot.waferIds.length > 0));
  };

  const selectedWaferCount = waferLots.reduce((count, lot) => count + (lot.wholeLot ? 25 : lot.waferIds.length), 0);

  // DIMM / CAMM grain list
  interface DimmGrain {
    id: string;
    markCode: string;
    sn: string;
    workOrder: string;
    failMode: string;
    failCondition: string;
    icTree?: DimmIcTree;
  }
  const [dimmGrains, setDimmGrains] = useState<DimmGrain[]>([
    { id: crypto.randomUUID(), markCode: genMarkCode(), sn: "", workOrder: "", failMode: "", failCondition: "" },
  ]);

  const updateDimmGrain = (id: string, field: keyof Omit<DimmGrain, "id" | "icTree">, value: string) => {
    setDimmGrains(prev =>
      prev.map(g => g.id === id ? { ...g, [field]: value } : g)
    );
  };

  // 依据 SN 检索该 DIMM 内的 IC / Die / Chip ID 结构（mock）
  const retrieveDimmIc = (id: string, sn: string) => {
    setDimmGrains(prev => prev.map(g => {
      if (g.id !== id) return g;
      const retrieved = resolveDimmIcTree(sn);
      const manualIc = g.icTree?.ics.find((ic) => ic.icId === "手动录入");
      return {
        ...g,
        icTree: manualIc?.dies.length ? { ...retrieved, ics: [...retrieved.ics, manualIc] } : retrieved,
      };
    }));
  };

  const addDimmChip = (grainId: string) => {
    setDimmGrains((previous) => previous.map((grain) => {
      if (grain.id !== grainId) return grain;
      const tree = grain.icTree ?? { sn: grain.sn, ics: [] };
      const manualIc = tree.ics.find((ic) => ic.icId === "手动录入");
      const nextIndex = Math.max(0, ...(manualIc?.dies.map((die) => Number(die.dieId.match(/\d+$/)?.[0] ?? 0)) ?? [])) + 1;
      const nextDie: DimmDie = { dieId: `Manual ${nextIndex}`, chipId: "", isFailChip: false, manual: true };
      return {
        ...grain,
        icTree: {
          ...tree,
          sn: grain.sn,
          ics: manualIc
            ? tree.ics.map((ic) => ic.icId === manualIc.icId ? { ...ic, dies: [...ic.dies, nextDie] } : ic)
            : [...tree.ics, { icId: "手动录入", dies: [nextDie] }],
        },
      };
    }));
  };

  const updateDimmChip = (grainId: string, icId: string, dieId: string, patch: Partial<DimmDie>) => {
    setDimmGrains((previous) => previous.map((grain) => grain.id !== grainId || !grain.icTree ? grain : {
      ...grain,
      icTree: {
        ...grain.icTree,
        ics: grain.icTree.ics.map((ic) => ic.icId !== icId ? ic : {
          ...ic,
          dies: ic.dies.map((die) => die.dieId === dieId ? { ...die, ...patch } : die),
        }),
      },
    }));
  };

  const removeDimmChip = (grainId: string, icId: string, dieId: string) => {
    setDimmGrains((previous) => previous.map((grain) => grain.id !== grainId || !grain.icTree ? grain : {
      ...grain,
      icTree: {
        ...grain.icTree,
        ics: grain.icTree.ics
          .map((ic) => ic.icId === icId ? { ...ic, dies: ic.dies.filter((die) => die.dieId !== dieId) } : ic)
          .filter((ic) => ic.dies.length > 0),
      },
    }));
  };

  const addDimmGrain = () => {
    setDimmGrains(prev => [
      ...prev,
      { id: crypto.randomUUID(), markCode: genMarkCode(), sn: "", workOrder: "", failMode: "", failCondition: "" },
    ]);
  };

  const removeDimmGrain = (id: string) => {
    setDimmGrains(prev => prev.filter(g => g.id !== id));
  };

  const getDimmMarkCode = (g: DimmGrain) => {
    const filled = [g.sn, g.workOrder, g.failMode, g.failCondition].every(v => v.trim() !== "");
    if (!filled) return "—";
    return `MC-${g.sn.slice(-4).toUpperCase()}-${g.workOrder.slice(-4).toUpperCase()}-${g.failMode.slice(0, 3).toUpperCase()}-${g.failCondition.slice(0, 3).toUpperCase()}`;
  };

  // IC grain list
  interface IcGrain {
    id: string;
    markCode: string;
    barcode: string;
    chipid: string;
    failMode: string;
    failCondition: string;
  }
  const [icGrains, setIcGrains] = useState<IcGrain[]>([
    { id: crypto.randomUUID(), markCode: genMarkCode(), barcode: "", chipid: "", failMode: "", failCondition: "" },
  ]);

  const updateIcGrain = (id: string, field: keyof Omit<IcGrain, "id" | "markCode">, value: string) => {
    setIcGrains(prev => prev.map(g => g.id === id ? { ...g, [field]: value } : g));
  };

  const addIcGrain = () => {
    setIcGrains(prev => [
      ...prev,
      { id: crypto.randomUUID(), markCode: genMarkCode(), barcode: "", chipid: "", failMode: "", failCondition: "" },
    ]);
  };

  const removeIcGrain = (id: string) => {
    setIcGrains(prev => prev.filter(g => g.id !== id));
  };

  // 从详情页「DIMM Chip ID」跳转新建时，一次性预填表单
  useEffect(() => {
    if (mode !== "create" || !prefill) return;
    if (prefill.name !== undefined) setName(prefill.name);
    if (prefill.reason !== undefined) setReason(prefill.reason);
    if (prefill.background !== undefined) setBackground(prefill.background);
    if (prefill.impact !== undefined) setImpact(prefill.impact);
    if (prefill.problemDomain) setProblemDomain(prefill.problemDomain);
    if (prefill.problemType) setProblemType(prefill.problemType);
    if (prefill.level) { setLevel(prefill.level); setLevelTouched(true); }
    if (prefill.urgency) setUrgency(prefill.urgency);
    if (prefill.dueDate) setDueDate(prefill.dueDate);
    if (prefill.productIds) setProductIds(prefill.productIds);
    if (prefill.material) setMaterial(prefill.material);
    if (prefill.density) setDensity(prefill.density);
    if (prefill.ioType) setIoType(prefill.ioType);
    if (prefill.failStage) setFailStage(prefill.failStage);
    if (prefill.customer) setCustomer(prefill.customer);
    if (prefill.failPlatform) setFailPlatform(prefill.failPlatform);
    if (prefill.failMode) setFailMode(prefill.failMode);
    if (prefill.relatedCaseIds) setRelatedCaseIds(prefill.relatedCaseIds);
    if (prefill.chipId) {
      setIcGrains([{ id: crypto.randomUUID(), markCode: genMarkCode(), barcode: "", chipid: prefill.chipId, failMode: prefill.failMode ?? "", failCondition: prefill.failCondition ?? "" }]);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const getIcMarkCode = (g: IcGrain) => {
    const filled = [g.barcode, g.chipid, g.failMode, g.failCondition].every(v => v.trim() !== "");
    if (!filled) return "—";
    return `MC-${g.barcode.slice(-4).toUpperCase()}-${g.chipid.slice(-4).toUpperCase()}-${g.failMode.slice(0, 3).toUpperCase()}-${g.failCondition.slice(0, 3).toUpperCase()}`;
  };

  // 查看 Chip DNA / One Click：在新建页内打开对应的全屏页面（保留新建表单状态）
  const [viewer, setViewer] = useState<null | { kind: "chipdna" | "oneclick" | "cpindex"; mark: string; title: string; rows: { k: string; v: string }[] }>(null);
  const icRows = (g: IcGrain) => [
    { k: "Mark Code", v: getIcMarkCode(g) },
    { k: "Barcode", v: g.barcode || "—" },
    { k: "Chip ID", v: g.chipid || "—" },
    { k: "Fail Mode", v: g.failMode || "—" },
    { k: "Fail Condition", v: g.failCondition || "—" },
  ];
  const openChipDNA = (mark: string, rows: { k: string; v: string }[]) => setViewer({ kind: "chipdna", mark, title: mark === "—" ? "未填写完整" : mark, rows });
  const openOneClick = (mark: string, rows: { k: string; v: string }[]) => setViewer({ kind: "oneclick", mark, title: mark === "—" ? "未填写完整" : mark, rows });
  const openCpIndex = (mark: string, rows: { k: string; v: string }[]) => setViewer({ kind: "cpindex", mark, title: mark === "—" ? "未填写完整" : mark, rows });

  // Tasks tree
  const [tasks, setTasks] = useState<TaskNode[]>(
    initialCase?.tasks ?? [],
  );

  // Permission settings — R08：新建时记住上次设置（仅 create 模式预填）
  const savedPerm = mode === "create" ? loadPermPreset() : null;
  const [permissionType, setPermissionType] = useState<
    "all" | "partial"
  >(savedPerm?.type ?? "all");
  const [permissionList, setPermissionList] = useState<
    Array<{ id: string; name: string; type: "user" | "dept" }>
  >(savedPerm?.list ?? []);

  // Mind map groups for create mode - Tree structure
  const [thoughtGroups, setThoughtGroups] = useState<
    ThoughtGroup[]
  >([]);
  const [inheritOpen, setInheritOpen] = useState(false);
  const [inheritCaseId, setInheritCaseId] = useState("");
  const [inheritError, setInheritError] = useState("");
  const [inheritedCase, setInheritedCase] = useState<CaseItem | null>(null);
  const inheritCase = () => {
    const query = inheritCaseId.trim().toLowerCase();
    const sourceCase = mockCases.find((caseItem) => caseItem.id.toLowerCase() === query || caseItem.code.toLowerCase() === query);
    if (!sourceCase) {
      setInheritError("未找到该 Case ID，请检查后重试。");
      return;
    }
    setName(sourceCase.name);
    setReason(sourceCase.reason || "");
    setBackground(sourceCase.background || "");
    setImpact(sourceCase.impact || "");
    setProblemDomain(sourceCase.problemDomain || "");
    setProblemType(sourceCase.problemType || "");
    setLevel(sourceCase.level);
    setLevelTouched(true);
    setUrgency(sourceCase.urgency);
    setCaseOwner(currentUser.name);
    setCreatedForOther(false);
    setCollaborators((sourceCase.participants || []).map((participant) => ({ ...participant })));
    setDueDate(sourceCase.dueDate || "");
    setLevelReason(sourceCase.levelReason || "");
    setRemark(sourceCase.remark || "");
    setProductIds(sourceCase.productIds?.length ? [...sourceCase.productIds] : (sourceCase.product ? [sourceCase.product] : []));
    setMaterial(normalizeMaterial(sourceCase.material));
    setMaterialSubtype(sourceCase.materialSubtype || "");
    setMarkCode(sourceCase.markCode || genMarkCode());
    setDensity(sourceCase.density || "");
    setIoType(sourceCase.ioType || sourceCase.bitWidth || "");
    setFailStage(sourceCase.failStage || "");
    setCustomer(sourceCase.customer || "");
    setFailMode(sourceCase.failMode || "");
    setFailPlatform(sourceCase.failPlatform || "");
    setPpm(sourceCase.ppm || "");
    setPdId(sourceCase.pdId || "");
    setFailRatio(sourceCase.failRatio || "");
    setFailPackage(sourceCase.failPackage || "");
    setMaskVersion(sourceCase.maskVersion || "");
    setProgram(sourceCase.program || "");
    setCaseAttribute(sourceCase.caseAttribute || "");
    setProductGeneration(sourceCase.productGeneration || "");
    setDimmCapacity(sourceCase.dimmCapacity || "");
    setBitWidth(sourceCase.bitWidth || "");
    setProjectName(sourceCase.projectName || "");
    setPlatformModel(sourceCase.platformModel || "");
    setProductPartNumber(sourceCase.productPartNumber || "");
    setSource((sourceCase.source as IssueSource) || "手动");
    setRelatedCaseIds([...new Set([sourceCase.id, ...(sourceCase.relatedCaseIds || [])])]);
    const sourceIssueIds = allIssues.filter((issue) => issue.caseIds.includes(sourceCase.id)).map((issue) => issue.id);
    setAttachIssueIds(sourceIssueIds);
    setIssueLinkMode(sourceIssueIds.length ? "now" : "later");
    setNewIssueName("");
    setCaseAttachments((sourceCase.caseAttachments || []).map((attachment) => ({ ...attachment })));
    setTasks([]);
    setThoughtGroups([]);
    setAnalysisTemplate(sourceCase.analysisTemplate === "table-wbs" ? "table-wbs" : "blank");
    setWaferLots(waferLotsFromGranules(sourceCase.granules));
    setWaferIdentifierInput("");
    setWaferIdentifierError("");
    const moduleGranules = (sourceCase.granules || []).filter((granule) => granule.sn || granule.workOrder || granule.kind === "module");
    setDimmGrains(moduleGranules.length ? moduleGranules.map((granule) => ({
      id: crypto.randomUUID(),
      markCode: granule.markCode || genMarkCode(),
      sn: granule.sn || "",
      workOrder: granule.workOrder || "",
      failMode: granule.failMode || "",
      failCondition: granule.failCondition || "",
      icTree: granule.icTree ? structuredClone(granule.icTree) : undefined,
    })) : [{ id: crypto.randomUUID(), markCode: sourceCase.markCode || genMarkCode(), sn: "", workOrder: "", failMode: "", failCondition: "" }]);
    const sourceIcSamples = sourceCase.returnedSamples || [];
    setIcGrains(sourceIcSamples.length ? sourceIcSamples.map((sample) => ({
      id: crypto.randomUUID(),
      markCode: sample.markCode || genMarkCode(),
      barcode: sample.barcode || "",
      chipid: sample.chipId || "",
      failMode: sample.failMode || "",
      failCondition: sample.failCondition || "",
    })) : [{ id: crypto.randomUUID(), markCode: sourceCase.markCode || genMarkCode(), barcode: "", chipid: "", failMode: "", failCondition: "" }]);
    setIcSplit(false);
    setModuleSplit(false);
    setInheritedCase(sourceCase);
    setInheritError("");
    setInheritOpen(false);
  };
  // —— 拆解视图：思维导图（blank）/ 任务表格（table-wbs）。两视图共享同一份 thoughtGroups，可随时切换 ——
  const [analysisTemplate, setAnalysisTemplate] = useState<AnalysisTemplateId>(
    mode === "create" ? "blank" : (initialCase?.analysisTemplate === "table-wbs" ? "table-wbs" : "blank"),
  );

  // —— 功能1：AI 智能识别填充（演示）——
  const [aiOpen, setAiOpen] = useState(false);
  const [aiText, setAiText] = useState("");
  const [aiBusy, setAiBusy] = useState(false);
  const [aiResult, setAiResult] = useState<null | AiField[]>(null);
  const [aiPicked, setAiPicked] = useState<Record<string, boolean>>({});

  // —— 功能2：DIMM 按颗粒拆分为子 Case（演示）——
  const [dimmSplitOpen, setDimmSplitOpen] = useState(false);
  const [dimmSplitDone, setDimmSplitDone] = useState(false);
  const [dimmSplitSel, setDimmSplitSel] = useState<Record<string, boolean>>({});
  const [dimmSplitMerge, setDimmSplitMerge] = useState(false);
  const dimmSplittable = dimmGrains.filter((g) => g.sn.trim() && g.failMode.trim());
  const dimmSplitGroups: { label: string; grains: typeof dimmGrains }[] = (() => {
    const gs = dimmSplittable.filter((g) => dimmSplitSel[g.id]);
    if (!dimmSplitMerge) return gs.map((g) => ({ label: g.failMode || "DIMM", grains: [g] }));
    const m = new Map<string, typeof dimmGrains>();
    gs.forEach((g) => { const k = g.failMode || "未分类"; if (!m.has(k)) m.set(k, [] as any); (m.get(k) as any).push(g); });
    return [...m.entries()].map(([label, grains]) => ({ label, grains }));
  })();

  // —— IC 拆解为多个独立 Case（可选）——
  const [icSplit, setIcSplit] = useState(false);
  const [moduleSplit, setModuleSplit] = useState(false);
  const [showOptional, setShowOptional] = useState(false);
  const [icSplitSel, setIcSplitSel] = useState<Record<string, boolean>>({});
  const [materialSplitOpen, setMaterialSplitOpen] = useState(false);
  const icSplittable = icGrains.filter((g) => getIcMarkCode(g) !== "—");
  const icSelected = icSplittable.filter((g) => !!icSplitSel[g.id]);

  const AI_SAMPLE = "客户：北美 A 客户 反馈 DMJFC 产品在 FT 高温段出现批量 Icc 漏电超规，失效比例约 0.8%，密度 16Gb，封装 FBGA，IO x8，平台 X86。当前已影响 3 个 Lot 的交付，存在退货风险，PPM 约 1200。请尽快定位根因，紧急，建议按 L1 处理。物料为 DIMM。";

  const runAiParse = () => {
    if (!aiText.trim()) return;
    setAiBusy(true);
    setAiResult(null);
    // 演示：模拟 AI 识别延迟
    setTimeout(() => {
      const fields = parseCaseDescription(aiText);
      const picked: Record<string, boolean> = {};
      fields.forEach((f) => (picked[f.key] = true));
      setAiResult(fields);
      setAiPicked(picked);
      setAiBusy(false);
    }, 700);
  };

  const updateAiFieldValue = (key: string, value: string) => {
    setAiResult((previous) => previous?.map((field) => {
      if (field.key === key) return { ...field, value };
      if (key === "material" && field.key === "materialSubtype") {
        const allowed = value === "DIMM" ? MATERIAL_SUBTYPES.DIMM : value === "CAMM" ? MATERIAL_SUBTYPES.CAMM : [];
        return allowed.includes(field.value) ? field : { ...field, value: "" };
      }
      return field;
    }) ?? null);
    setAiPicked((previous) => ({ ...previous, [key]: true }));
  };

  const aiFieldOptions = (field: AiField): string[] | null => {
    if (field.key === "level") return ["L0", "L1", "L2", "L3"];
    if (field.key === "urgency") return ["非常紧急", "紧急", "一般", "不紧急"];
    if (field.key === "material") return [...MATERIAL_OPTIONS];
    if (field.key === "failStage") return ["CP1", "CP2", "FT", "SLT", "FAB", "其他"];
    if (field.key === "materialSubtype") {
      const recognizedMaterial = aiResult?.find((item) => item.key === "material")?.value;
      return recognizedMaterial === "CAMM" ? [...MATERIAL_SUBTYPES.CAMM] : recognizedMaterial === "DIMM" ? [...MATERIAL_SUBTYPES.DIMM] : null;
    }
    return null;
  };

  const applyAiFields = () => {
    if (!aiResult) return;
    const set: Record<string, (v: string) => void> = {
      name: setName, background: setBackground, impact: setImpact, product: (v) => setProductIds(v ? [v] : []),
      material: (v) => { setMaterial(normalizeMaterial(v)); setMaterialSubtype(""); },
      materialSubtype: setMaterialSubtype,
      density: setDensity, ioType: setIoType, failStage: setFailStage,
      customer: setCustomer, failPlatform: setFailPlatform, failMode: setFailMode,
      failRatio: setFailRatio, failPackage: setFailPackage, ppm: setPpm,
      caseAttribute: setCaseAttribute, productGeneration: setProductGeneration, dimmCapacity: setDimmCapacity,
      bitWidth: setBitWidth, projectName: setProjectName, platformModel: setPlatformModel, productPartNumber: setProductPartNumber,
      level: (v) => { setLevel(v as Level); setLevelTouched(true); }, urgency: (v) => setUrgency(v as Urgency),
    };
    aiResult.forEach((f) => {
      if (aiPicked[f.key] && set[f.key]) set[f.key](f.value);
    });
    setAiOpen(false);
    setAiResult(null);
    setAiText("");
  };

  // 复用「AI 润色」按钮：润色背景/影响 + 识别其它字段，统一在弹窗中确认
  const polishText = (input: string): string => {
    const trimmed = input.trim();
    if (!trimmed) return "";
    const withPunct = /[。.!?！？]$/.test(trimmed) ? trimmed : trimmed + "。";
    return `${withPunct}（已由 AI 润色：调整表述与措辞，使内容更清晰、专业。）`;
  };
  const runAiPolishFill = () => {
    const bg = background.trim();
    const im = impact.trim();
    if (!bg && !im) return;
    const text = [background, impact].filter((s) => s.trim()).join("\n");
    setAiText(text);
    setAiOpen(true);
    setAiBusy(true);
    setAiResult(null);
    setTimeout(() => {
      // 识别其它字段（排除背景/影响本身；名称仅在为空时建议）
      let fields = parseCaseDescription(text).filter((f) => f.key !== "background" && f.key !== "impact");
      if (name.trim()) fields = fields.filter((f) => f.key !== "name");
      // 润色后的背景/影响作为可确认项（复用 applyAiFields 中 background/impact 的映射）
      const polished: AiField[] = [];
      if (bg) polished.push({ key: "background", label: "背景 · 发生了什么（AI 润色）", value: polishText(background) });
      if (im) polished.push({ key: "impact", label: "影响 · 带来什么影响（AI 润色）", value: polishText(impact) });
      const all = [...polished, ...fields];
      const picked: Record<string, boolean> = {};
      all.forEach((f) => (picked[f.key] = true));
      setAiResult(all);
      setAiPicked(picked);
      setAiBusy(false);
    }, 600);
  };

  // Synthesized CaseItem for the shared MindMap to render against
  const synthesizedCase: CaseItem = useMemo(() => {
    const base = (initialCase ?? mockCases[0]) as CaseItem;
    return {
      ...base,
      id: initialCase?.id ?? "__draft__",
      code: initialCase?.code ?? "DRAFT-NEW",
      name: name || "（未命名 Case）",
      owner: caseOwner,
      participants: collaborators,
      level,
      urgency,
      reason,
      background,
      problemDomain: problemDomain || undefined,
      problemType: problemType || undefined,
      impact,
      caseAttachments,
      levelReason,
      remark: remark || undefined,
      product,
      productIds: productIds.length ? productIds : undefined,
      material,
      materialSubtype: materialSubtype || undefined,
      markCode: showMarkCode ? ((materialKey === "IC" ? icGrains[0]?.markCode : dimmGrains[0]?.markCode) || markCode) : undefined,
      density,
      ioType,
      failStage,
      customer,
      failPlatform,
      failMode,
      failRatio,
      failPackage,
      maskVersion,
      program,
      caseAttribute,
      productGeneration,
      dimmCapacity,
      bitWidth: ioType || undefined,
      projectName,
      platformModel,
      productPartNumber,
      ppm,
      pdId,
      tasks,
      analysisTemplate: analysisTemplate ?? undefined,
      pipeline: analysisTemplate === "cr-standard" ? (initialCase?.pipeline ?? buildCrPipelineStages()) : undefined,
      departments: Array.from(
        new Set(tasks.map((t) => t.department).filter(Boolean)),
      ),
    } as CaseItem;
  }, [
    initialCase,
    name,
    caseOwner,
    collaborators,
    level,
    urgency,
    reason,
    background,
    problemDomain,
    problemType,
    impact,
    caseAttachments,
    levelReason,
    remark,
    product,
    productIds,
    material,
    materialSubtype,
    density,
    ioType,
    failStage,
    customer,
    failPlatform,
    failMode,
    failRatio,
    failPackage,
    maskVersion,
    program,
    caseAttribute,
    productGeneration,
    dimmCapacity,
    bitWidth,
    projectName,
    platformModel,
    productPartNumber,
    ppm,
    pdId,
    tasks,
    analysisTemplate,
  ]);

  const insertTask = (parentId: string | null, t: TaskNode) => {
    if (parentId === null) {
      setTasks([...tasks, t]);
      return;
    }
    const insert = (nodes: TaskNode[]): TaskNode[] =>
      nodes.map((n) =>
        n.id === parentId
          ? { ...n, children: [...(n.children ?? []), t] }
          : {
              ...n,
              children: n.children
                ? insert(n.children)
                : n.children,
            },
      );
    setTasks(insert(tasks));
  };

  const submitTask = (
    parentId: string | null,
    p: AddTaskPayload,
  ) => {
    insertTask(parentId, {
      id: `t${Date.now()}`,
      title: p.title,
      owner: p.assignee.trim() || "待指派",
      department: p.department,
      urgency: p.urgency,
      progress: 0,
      status: "待接受",
      dueDate: p.dueDate || undefined,
      type: p.type,
      note: p.note,
      supervisor: p.supervisor,
      site: p.site,
    });
  };

  const editTask = (id: string, p: AddTaskPayload) => {
    const apply = (nodes: TaskNode[]): TaskNode[] =>
      nodes.map((n) =>
        n.id === id
          ? {
              ...n,
              title: p.title,
              owner: p.assignee.trim() || n.owner,
              department: p.department || n.department,
              urgency: p.urgency,
              dueDate: p.dueDate || n.dueDate,
              type: p.type ?? n.type,
              note: p.note ?? n.note,
              supervisor: p.supervisor ?? n.supervisor,
              site: p.site ?? n.site,
            }
          : {
              ...n,
              children: n.children
                ? apply(n.children)
                : n.children,
            },
      );
    setTasks(apply(tasks));
  };

  const deleteTask = (id: string) => {
    const remove = (nodes: TaskNode[]): TaskNode[] =>
      nodes
        .filter((n) => n.id !== id)
        .map((n) => ({
          ...n,
          children: n.children
            ? remove(n.children)
            : n.children,
        }));
    setTasks(remove(tasks));
  };

  const pageLabel =
    mode === "upgrade"
      ? "Case 升级"
      : mode === "approve"
        ? "审批 · Case 复核"
        : mode === "edit"
          ? "编辑 Case"
          : "新建 Case";
  const submitLabel =
    mode === "upgrade"
      ? "提交升级申请"
      : mode === "approve"
        ? "确定"
        : mode === "edit"
          ? "确定"
          : "确定";
  const heroHint =
    mode === "upgrade"
      ? `当前 Case：${initialCase?.code ?? ""} · 原层级 ${initialCase?.level ?? "—"}。请确认基础信息并重新拆解、分派任务。`
      : mode === "approve"
        ? `审批中：${initialCase?.code ?? ""}。可直接修改 Case 背景、负责人及任务分派。`
        : mode === "edit"
          ? `编辑 Case：${initialCase?.code ?? ""}。可修改 Case 基础信息、任务分派及拆解视图。`
          : "先填写 Case 信息，再通过思维导图或任务视图拆解任务。";

  const draftSimilarityFailMode = useMemo(() => Array.from(new Set([
    failMode.trim(),
    ...icGrains.map((grain) => grain.failMode.trim()),
    ...dimmGrains.map((grain) => grain.failMode.trim()),
  ].filter(Boolean))).join(" "), [failMode, icGrains, dimmGrains]);
  const draftSimilarityInput = useMemo<DraftCaseSimilarityInput>(() => ({
    name: name.trim(),
    background: background.trim(),
    product,
    material,
    problemDomain: problemDomain || undefined,
    problemType: problemType || undefined,
    failMode: draftSimilarityFailMode || undefined,
    failStage: failStage || undefined,
    failPlatform: failPlatform.trim() || undefined,
  }), [name, background, product, material, problemDomain, problemType, draftSimilarityFailMode, failStage, failPlatform]);
  const structuredSimilaritySignalCount = [product, material, problemDomain, problemType, draftSimilarityFailMode, failStage, failPlatform.trim()].filter(Boolean).length;
  const similarityRecommendationReady = mode === "create" && background.trim().length >= 12 && structuredSimilaritySignalCount >= 2;

  useEffect(() => {
    if (!similarityRecommendationReady) {
      setDebouncedSimilarityInput(null);
      return;
    }
    const timer = window.setTimeout(() => setDebouncedSimilarityInput(draftSimilarityInput), 600);
    return () => window.clearTimeout(timer);
  }, [draftSimilarityInput, similarityRecommendationReady]);

  const similaritySuggestions = useMemo(() => debouncedSimilarityInput
    ? suggestRelatedCasesForDraft(
        debouncedSimilarityInput,
        mockCases.filter((caseItem) => caseItem.id !== initialCase?.id && caseItem.source !== "fanout验证" && !caseItem.fanoutSourceCaseId),
      )
    : [], [debouncedSimilarityInput, initialCase?.id]);
  const visibleSimilaritySuggestions = similaritySuggestions.filter((suggestion) => !dismissedSimilarityIds.includes(suggestion.caseId));
  const displayedSimilaritySuggestions = visibleSimilaritySuggestions.slice(0, 3);
  const similarityPreviewCase = similarityPreviewId ? mockCases.find((caseItem) => caseItem.id === similarityPreviewId) : undefined;
  const reuseSourceCase = reuseSourceId ? mockCases.find((caseItem) => caseItem.id === reuseSourceId) : undefined;

  const toggleRelatedCase = (caseId: string) => {
    setRelatedCaseIds((previous) => previous.includes(caseId) ? previous.filter((id) => id !== caseId) : [...previous, caseId]);
  };
  const openReuseModal = (caseId: string) => {
    setReuseSourceId(caseId);
    setReuseSelectedBranchIds([]);
  };
  const applyReusedBranches = () => {
    if (!reuseSourceCase || reuseSelectedBranchIds.length === 0) return;
    const selected = reusableThoughtBranches(reuseSourceCase).filter((branch) => reuseSelectedBranchIds.includes(branch.id));
    setThoughtGroups((previous) => [...previous, ...selected.map(cloneReusableThoughtBranch)]);
    setReusedBranchIds((previous) => ({
      ...previous,
      [reuseSourceCase.id]: Array.from(new Set([...(previous[reuseSourceCase.id] ?? []), ...reuseSelectedBranchIds])),
    }));
    setReuseSourceId(null);
    setReuseSelectedBranchIds([]);
  };

  const materialNeedsFailStage = materialKey === "Wafer" || materialKey === "IC" || isModule;
  const waferDetailsValid = material !== "Wafer" || (!waferIdentifierInput.trim() && !waferIdentifierError);

  const canSubmit = Boolean(
    name.trim() && caseOwner.trim() && dueDate && background.trim() && impact.trim()
    && level && urgency && productIds.length > 0 && material
    && (!isModule || materialSubtype)
    && (!materialNeedsFailStage || failStage)
    && waferDetailsValid,
  );

  // 人工立案提交：持久化 Case → 关联/新建 Issue → 打开新 Case
  const submitCase = () => {
    if (prefill?.sourceStandaloneTaskIds?.length && ((isModule && moduleSplit && dimmSplittable.length > 1) || (materialKey === "IC" && icSplit && icSplittable.length > 1))) throw new Error("自由任务只能带入一个 Case，请关闭批量拆分后提交。");
    savePermPreset({ type: permissionType, list: permissionList });
    if (mode === "create") {
      const persistedTasks = thoughtGroupsToTasks(thoughtGroups);
      const base = {
        name: name.trim(), owner: caseOwner, createdBy: currentUser.name, createdForOther, participants: collaborators, level, urgency, dueDate,
        reason: reason || background, background, problemDomain, problemType: problemType || undefined, impact, levelReason, remark: remark || undefined,
        product, productIds: productIds.length ? productIds : undefined,
        material, materialSubtype: materialSubtype || undefined,
        markCode: showMarkCode ? ((materialKey === "IC" ? icGrains[0]?.markCode : dimmGrains[0]?.markCode) || markCode) : undefined,
        density, ioType, failStage, customer, failPlatform, failMode,
        failRatio, failPackage, maskVersion, program, ppm, pdId,
        caseAttribute, productGeneration, dimmCapacity, bitWidth, projectName, platformModel, productPartNumber,
        source, tasks: persistedTasks, caseAttachments,
        sourceModuleCaseId: prefill?.parentCaseId,
        relatedCaseIds: relatedCaseIds.length ? relatedCaseIds : undefined,
        analysisTemplate: analysisTemplate ?? undefined,
        pipeline: analysisTemplate === "cr-standard" ? buildCrPipelineStages() : undefined,
      };
      let primaryId: string;

      // DIMM / CAMM 颗粒（含检索到的 IC 结构）持久化到 Case，供详情页展示与点击建案
      const grainToGranule = (g: typeof dimmGrains[number]) => {
        const icTree = g.icTree ? {
          ...g.icTree,
          sn: g.icTree.sn || g.sn,
          ics: g.icTree.ics
            .map((ic) => ({ ...ic, dies: ic.dies.filter((die) => die.chipId.trim()) }))
            .filter((ic) => ic.dies.length > 0),
        } : undefined;
        return {
          markCode: getDimmMarkCode(g), sn: g.sn, workOrder: g.workOrder,
          failMode: g.failMode, failCondition: g.failCondition,
          icTree: icTree?.ics.length ? icTree : undefined,
        };
      };
      const moduleGranules = isModule
        ? dimmGrains
          .filter((g) => g.sn.trim() || g.workOrder.trim() || g.failMode.trim() || g.icTree?.ics.some((ic) => ic.dies.some((die) => die.chipId.trim())))
          .map(grainToGranule)
        : undefined;
      const waferGranules: CaseGranule[] | undefined = materialKey === "Wafer"
        ? waferLots.flatMap((lot) => [
            ...(lot.wholeLot ? [{
              kind: "wafer" as const,
              markCode: `LOT-${lot.lotId}`,
              lotId: lot.lotId,
              wholeLot: true,
              failMode: failMode || undefined,
            }] : []),
            ...lot.waferIds.map((waferId) => ({
              kind: "wafer" as const,
              markCode: `WF-${waferId}`,
              lotId: lot.lotId,
              waferId,
              failMode: failMode || undefined,
            })),
          ])
        : undefined;

      if (prefill?.sourceStandaloneTaskIds?.length) {
        primaryId = upgradeStandaloneTasksToCase(prefill.sourceStandaloneTaskIds, { ...base, granules: materialKey === "Wafer" ? waferGranules : moduleGranules }).id;
      } else if (isModule && moduleSplit && dimmSplittable.length > 1) {
        // DIMM / CAMM → N 个独立 Case（背景相同）
        const ids = dimmSplittable.map((g) => createManualCase({
          ...base,
          name: `${name.trim()} · ${getDimmMarkCode(g) !== "—" ? getDimmMarkCode(g) : (g.sn || g.failMode || material)}`,
          failMode: g.failMode || failMode,
          splitGranule: { markCode: getDimmMarkCode(g), sn: g.sn, failMode: g.failMode, failCondition: g.failCondition },
          granules: [grainToGranule(g)],
        }).id);
        bindRelatedCases(ids, { note: "批量拆分自动关联" });
        primaryId = ids[0];
      } else if (materialKey === "IC" && icSplit && icSplittable.length > 1) {
        // IC → N 个独立 Case（背景相同）
        const ids = icSplittable.map((g) => createManualCase({
          ...base,
          name: `${name.trim()} · ${getIcMarkCode(g)}`,
          failMode: g.failMode || failMode,
          splitGranule: { markCode: getIcMarkCode(g), sn: g.barcode, failMode: g.failMode, failCondition: g.failCondition },
        }).id);
        bindRelatedCases(ids, { note: "批量拆分自动关联" });
        primaryId = ids[0];
      } else {
        primaryId = createManualCase({ ...base, granules: materialKey === "Wafer" ? waferGranules : moduleGranules }).id;
      }

      // 由详情页 Chip ID 跳转而来：与来源 Case 互相关联
      if (inheritedCase) bindRelatedCases([inheritedCase.id, primaryId], { note: "承接已有 Case" });
      if (prefill?.parentCaseId) {
        bindRelatedCases([prefill.parentCaseId, primaryId], { note: "由 DIMM / CAMM Chip ID 建立" });
      }

      // 新建时手动多选的关联 Case：写入弱链接（关联），使详情页「关联 Case」区可见
      if (relatedCaseIds.length) {
        relatedCaseIds.forEach((id) => linkCases(primaryId, id, "关联", { note: "新建时关联" }));
      }

      attachIssueIds.forEach((iid) => aggregateCase(iid, primaryId));
      if (newIssueName.trim()) {
        createIssue({ name: newIssueName.trim(), source, objectType: productById(product)?.objectType ?? "IC", caseIds: [primaryId] });
      }
      if (onCreated) onCreated(primaryId); else onDone();
      return;
    }
    if (mode === "edit" && initialCase) {
      saveCaseEdit(initialCase.id, { name: name.trim(), reason, background, impact, level, urgency, levelReason, remark, dueDate: dueDate || initialCase.dueDate, problemDomain: problemDomain || undefined, problemType: problemType || undefined, caseAttachments, product, productId: productIds[0], productIds, material, materialSubtype: materialSubtype || undefined, density, ioType, failStage, customer, failPlatform, failMode, failRatio, failPackage, maskVersion, program, ppm, pdId, caseAttribute, productGeneration, dimmCapacity, bitWidth, projectName, platformModel, productPartNumber });
    }
    onDone();
  };

  const handleReset = () => {
    setInheritedCase(null);
    setName(initialCase?.name ?? "");
    setReason(initialCase?.reason ?? "");
    setBackground(initialCase?.background ?? "");
    setProblemDomain(initialCase?.problemDomain ?? "");
    setProblemType(initialCase?.problemType ?? "");
    setImpact(initialCase?.impact ?? "");
    setLevelReason(initialCase?.levelReason ?? "");
    setRemark(initialCase?.remark ?? "");
    setLevel((initialCase?.level as Level) ?? AUTO_LEVEL["一般"]);
    setLevelTouched(!!initialCase?.level);
    setUrgency((initialCase?.urgency as Urgency) ?? "一般");
    setCaseOwner(initialCase?.owner ?? currentUser.name);
    setCreatedForOther(mode === "create" ? false : !!initialCase?.createdForOther);
    setCollaborators(initialCase?.participants ?? []);
    setDueDate("");
    setRelatedCaseIds(initialCase?.relatedCaseIds ?? []);
    setDismissedSimilarityIds([]);
    setSimilarityPreviewId(null);
    setReuseSourceId(null);
    setReuseSelectedBranchIds([]);
    setReusedBranchIds({});
    setDebouncedSimilarityInput(null);
    setProductIds(initialCase?.productIds ?? (initialCase?.product ? [initialCase.product] : []));
    setMaterial(normalizeMaterial(initialCase?.material));
    setMaterialSubtype(initialCase?.materialSubtype ?? "");
    setMaterialSplitOpen(false);
    setDensity(initialCase?.density ?? "");
    setIoType(initialCase?.ioType ?? initialCase?.bitWidth ?? "");
    setFailStage(initialCase?.failStage ?? "");
    setCustomer(initialCase?.customer ?? "");
    setFailPlatform(initialCase?.failPlatform ?? "");
    setFailMode(initialCase?.failMode ?? "");
    setPpm(initialCase?.ppm ?? "");
    setPdId(initialCase?.pdId ?? "");
    setFailRatio(initialCase?.failRatio ?? "");
    setFailPackage(initialCase?.failPackage ?? "");
    setMaskVersion(initialCase?.maskVersion ?? "");
    setProgram(initialCase?.program ?? "");
    setCaseAttribute(initialCase?.caseAttribute ?? "");
    setProductGeneration(initialCase?.productGeneration ?? "");
    setDimmCapacity(initialCase?.dimmCapacity ?? "");
    setBitWidth(initialCase?.bitWidth ?? "");
    setProjectName(initialCase?.projectName ?? "");
    setPlatformModel(initialCase?.platformModel ?? "");
    setProductPartNumber(initialCase?.productPartNumber ?? "");
    setTasks(initialCase?.tasks ?? []);
    setPermissionType("all");
    setPermissionList([]);
    setThoughtGroups([]);
    setIcSplit(false);
    setModuleSplit(false);
    setShowOptional(false);
    setIcSplitSel({});
    setWaferLots(waferLotsFromGranules(initialCase?.granules));
    setWaferIdentifierInput("");
    setWaferIdentifierError("");
    setDimmSplitDone(false);
    setDimmSplitOpen(false);
  };

  const finalSubmit = () => {
    if (!canSubmit || savingCase.current) return;
    savingCase.current = true;
    try { submitCase(); setSubmitError(""); }
    catch (reason) { setSubmitError(reason instanceof Error ? reason.message : "保存失败，请重试。"); }
    finally { savingCase.current = false; }
  };

  // 「查看 Chip DNA / One Click」对应的独立页面（在新建页内跳转，返回不丢失表单）
  if (viewer) {
    const isDNA = viewer.kind === "chipdna";
    const isCP = viewer.kind === "cpindex";
    const vLabel = isDNA ? "Chip DNA 溯源" : isCP ? "CP Index 查看" : "One Click 一键分析";
    const vSystem = isDNA ? "Chip DNA" : isCP ? "CP Index" : "One Click";
    const vBadge = isDNA ? "全链路履历" : isCP ? "CP 测试索引" : "自动失效分析";
    const vSource = isDNA ? "Chip DNA 系统" : isCP ? "CP Index 平台" : "One Click 平台";
    const accent = "#0052D9";
    const Icon = isDNA ? Fingerprint : isCP ? Hash : MousePointerClick;
    return (
      <div className="relative min-h-full">
        <div className="absolute inset-0 pointer-events-none" style={{ background: `radial-gradient(ellipse 80% 50% at 0% 0%, ${accent}0d, transparent 60%)` }} />
        <div className="relative p-8 max-w-[1100px] mx-auto space-y-6">
          {/* 顶部：返回 + 标题 */}
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setViewer(null)}
              className="h-9 px-3 rounded-md border border-slate-200 text-sm text-slate-600 hover:bg-slate-50 flex items-center gap-1.5"
            >
              <ChevronLeft size={15} /> 返回新建 Case
            </button>
            <span className="text-slate-300">/</span>
            <span className="text-sm text-slate-500">{vLabel}</span>
          </div>

          {/* Hero */}
          <div className="rounded-2xl border border-slate-200/80 bg-white shadow-[0_1px_2px_0_rgba(15,23,42,0.04)] overflow-hidden">
            <div className="h-1.5" style={{ background: `linear-gradient(90deg, ${accent}, ${accent}55)` }} />
            <div className="p-6 flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl grid place-items-center text-white shrink-0" style={{ background: accent }}>
                <Icon size={22} />
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <h2 className="text-[20px] font-bold text-slate-900 tracking-tight">{vLabel}</h2>
                  <span className="text-[11px] px-2 py-0.5 rounded-full border" style={{ color: accent, borderColor: `${accent}40`, background: `${accent}0d` }}>{vBadge}</span>
                </div>
                <div className="text-[12.5px] text-slate-500 mt-1.5">
                  Mark Code <span className="font-mono" style={{ color: accent }}>{viewer.title}</span> · 数据来源于 {vSource}（演示数据）
                </div>
              </div>
              <button type="button" className="h-9 px-3 rounded-md text-sm text-white flex items-center gap-1.5 shrink-0 hover:opacity-90" style={{ background: accent }}>
                <ExternalLink size={14} /> 在{vSystem}系统中打开
              </button>
            </div>
          </div>

          <div className="grid grid-cols-[300px_minmax(0,1fr)] gap-5 items-start">
            {/* 左：颗粒信息卡 */}
            <div className="rounded-xl border border-slate-200/80 bg-white shadow-[0_1px_2px_0_rgba(15,23,42,0.04)] overflow-hidden">
              <div className="px-4 h-11 flex items-center gap-2 border-b border-slate-100">
                <Cpu size={14} className="text-slate-400" />
                <span className="text-[13px] font-bold text-slate-800">失效单元信息</span>
              </div>
              <div className="divide-y divide-slate-50">
                {viewer.rows.map((r) => (
                  <div key={r.k} className="px-4 py-2.5 flex items-center gap-3">
                    <span className="text-[12px] text-slate-400 w-[92px] shrink-0">{r.k}</span>
                    <span className="text-[12.5px] text-slate-800 font-mono truncate">{r.v}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* 右：对应页面主体（演示占位） */}
            <div className="space-y-5 min-w-0">
              {isDNA ? (
                <div className="rounded-xl border border-slate-200/80 bg-white shadow-[0_1px_2px_0_rgba(15,23,42,0.04)] overflow-hidden">
                  <div className="px-4 h-11 flex items-center gap-2 border-b border-slate-100">
                    <Fingerprint size={14} style={{ color: accent }} />
                    <span className="text-[13px] font-bold text-slate-800">制造履历溯源</span>
                  </div>
                  <div className="p-5">
                    <div className="relative pl-5">
                      <div className="absolute left-[6px] top-1.5 bottom-1.5 w-px bg-slate-100" />
                      <div className="space-y-4">
                        {[
                          { s: "晶圆制造 (FAB)", d: "Lot 投片 · Mask 版本核对 · 关键工艺参数留痕" },
                          { s: "晶圆测试 (CP)", d: "CP1 / CP2 bin map · 同 Wafer 邻位失效分布" },
                          { s: "封装 (Assembly)", d: "封装批次 · 引线 / 基板批号 · X-ray 抽检记录" },
                          { s: "成品测试 (FT)", d: "FT bin 履历 · Retest 记录 · 测试程序版本" },
                          { s: "出货 / 客户", d: "出货批次 · 客户端失效回溯与退货关联" },
                        ].map((n) => (
                          <div key={n.s} className="relative">
                            <span className="absolute -left-[18px] top-1 w-2.5 h-2.5 rounded-full ring-2 ring-white" style={{ background: accent }} />
                            <div className="text-[13px] font-semibold text-slate-800">{n.s}</div>
                            <div className="text-[12px] text-slate-500 mt-0.5 leading-relaxed">{n.d}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              ) : isCP ? (
                <>
                  <div className="grid grid-cols-3 gap-4">
                    {[
                      { k: "CP1 Yield", v: "96.2%", t: "#16a34a" },
                      { k: "CP2 Yield", v: "94.8%", t: "#16a34a" },
                      { k: "主要失效 Bin", v: "Bin 7 · ICC2", t: accent },
                    ].map((c) => (
                      <div key={c.k} className="rounded-xl border border-slate-200/80 bg-white p-4 shadow-[0_1px_2px_0_rgba(15,23,42,0.04)]">
                        <div className="text-[12px] text-slate-400">{c.k}</div>
                        <div className="text-[16px] font-bold mt-1.5 truncate" style={{ color: c.t }}>{c.v}</div>
                      </div>
                    ))}
                  </div>
                  <div className="rounded-xl border border-slate-200/80 bg-white shadow-[0_1px_2px_0_rgba(15,23,42,0.04)] overflow-hidden">
                    <div className="px-4 h-11 flex items-center gap-2 border-b border-slate-100">
                      <Hash size={14} style={{ color: accent }} />
                      <span className="text-[13px] font-bold text-slate-800">CP 测试索引</span>
                    </div>
                    <div className="p-5 space-y-3">
                      {[
                        "定位该颗粒在 Wafer 上的 CP bin map 坐标与邻位失效分布。",
                        "汇总 CP1 / CP2 各 bin 占比与关键参数（ICC2 / VDDmin / Leakage）索引。",
                        "关联同 Lot / 邻位 Wafer 的 CP 失效趋势，辅助判断批次性 / 区域性失效。",
                      ].map((t, i) => (
                        <div key={i} className="flex items-start gap-2.5 text-[13px] text-slate-600 leading-relaxed">
                          <span className="mt-0.5 w-5 h-5 rounded-full grid place-items-center text-[11px] font-bold shrink-0 text-white" style={{ background: accent }}>{i + 1}</span>
                          <span>{t}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </>
              ) : (
                <>
                  <div className="grid grid-cols-3 gap-4">
                    {[
                      { k: "失效复现", v: "已复现", t: "#16a34a" },
                      { k: "疑似根因", v: "PKG 内引线偏移", t: accent },
                      { k: "置信度", v: "82%", t: "#d97706" },
                    ].map((c) => (
                      <div key={c.k} className="rounded-xl border border-slate-200/80 bg-white p-4 shadow-[0_1px_2px_0_rgba(15,23,42,0.04)]">
                        <div className="text-[12px] text-slate-400">{c.k}</div>
                        <div className="text-[16px] font-bold mt-1.5 truncate" style={{ color: c.t }}>{c.v}</div>
                      </div>
                    ))}
                  </div>
                  <div className="rounded-xl border border-slate-200/80 bg-white shadow-[0_1px_2px_0_rgba(15,23,42,0.04)] overflow-hidden">
                    <div className="px-4 h-11 flex items-center gap-2 border-b border-slate-100">
                      <MousePointerClick size={14} style={{ color: accent }} />
                      <span className="text-[13px] font-bold text-slate-800">一键分析报告</span>
                    </div>
                    <div className="p-5 space-y-3">
                      {[
                        "自动归集该单元 CP / FT / 客户端测试数据，定位失效 bin 与异常 pattern。",
                        "比对同 Lot / 邻位 Wafer 失效分布，判断是否为批次性 / 区域性失效。",
                        "关联 Chip DNA 制造履历，输出疑似根因与下一步验证建议。",
                      ].map((t, i) => (
                        <div key={i} className="flex items-start gap-2.5 text-[13px] text-slate-600 leading-relaxed">
                          <span className="mt-0.5 w-5 h-5 rounded-full grid place-items-center text-[11px] font-bold shrink-0 text-white" style={{ background: accent }}>{i + 1}</span>
                          <span>{t}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </>
              )}
              <p className="text-xs text-slate-400">以上为演示页面占位，正式版将对接 {vSystem} 系统的真实数据。</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="relative">
      <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(ellipse_80%_50%_at_0%_0%,rgba(0,82,217,0.05),transparent_60%)]" />

      <div className="relative p-8 pb-28 max-w-[1200px] mx-auto space-y-6">
        {/* Hero */}
        <div className="flex items-end justify-between gap-4">
          <div className="space-y-2">
            {mode !== "create" && (
              <div className="flex items-center gap-2 text-xs text-slate-500 tracking-wider uppercase">
                <Sparkles size={12} className="text-[#0052D9]" />
                {mode === "upgrade"
                  ? "Case Upgrade · 重新拆解"
                  : mode === "approve"
                    ? "Case Approval · 复核修改"
                    : "Edit Case · 编辑信息"}
              </div>
            )}
            <h1 className="text-slate-900 tracking-tight">
              {pageLabel}
            </h1>
            <p className="text-sm text-slate-500 max-w-xl leading-relaxed">
              {heroHint}
            </p>
          </div>
          {mode === "create" && (
            <button type="button" onClick={() => { setInheritOpen(true); setInheritError(""); }} className="h-9 shrink-0 rounded-md border border-[#0052D9]/30 bg-white px-3 text-sm text-[#0052D9] hover:bg-[#0052D9]/5 inline-flex items-center gap-1.5">
              <ClipboardPaste size={14} /> 承接
            </button>
          )}
        </div>
        {inheritedCase && mode === "create" && (
          <div className="flex w-fit items-center gap-2 rounded-md border border-emerald-200 bg-emerald-50 px-3 py-2 text-[11px] text-emerald-700">
            <Check size={12} /> 承接来源 <span className="font-mono">{inheritedCase.code}</span>
          </div>
        )}
        {inheritOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/40 p-6" onMouseDown={() => setInheritOpen(false)}>
            <div className="w-[480px] max-w-[95vw] rounded-xl border border-slate-200 bg-white p-5 shadow-2xl" onMouseDown={(event) => event.stopPropagation()}>
              <div className="flex items-center gap-2"><ClipboardPaste size={16} className="text-[#0052D9]" /><h3 className="text-slate-900">承接已有 Case</h3><button type="button" onClick={() => setInheritOpen(false)} className="ml-auto text-slate-400 hover:text-slate-600"><XIcon size={16} /></button></div>
              <p className="mt-2 text-xs leading-relaxed text-slate-500">沿用基础资料，不带入思维导图和执行任务；创建后与来源 Case 相互关联。</p>
              <label className="mt-4 block text-xs text-slate-600">Case ID <span className="text-red-500">*</span><input autoFocus value={inheritCaseId} onChange={(event) => { setInheritCaseId(event.target.value); setInheritError(""); }} onKeyDown={(event) => { if (event.key === "Enter") inheritCase(); }} placeholder="例如：EA-260511000001 或 c001" className="mt-1 h-9 w-full rounded-md border border-slate-200 px-3 text-sm outline-none focus:border-[#0052D9]" /></label>
              {inheritError && <div className="mt-2 text-xs text-red-500">{inheritError}</div>}
              <div className="mt-5 flex justify-end gap-2"><button type="button" onClick={() => setInheritOpen(false)} className="h-8 rounded-md border border-slate-200 px-3 text-xs text-slate-600 hover:bg-slate-50">取消</button><button type="button" disabled={!inheritCaseId.trim()} onClick={inheritCase} className="h-8 rounded-md bg-[#0052D9] px-3 text-xs text-white hover:bg-[#003FA8] disabled:opacity-40">确认承接</button></div>
            </div>
          </div>
        )}
        {mode !== "create" && (
          <div className="text-[11px] text-slate-500 bg-[#0052D9]/5 border border-[#0052D9]/20 rounded-md px-3 py-2 flex items-center gap-2 w-fit">
            <span className="w-1.5 h-1.5 rounded-full bg-[#0052D9]" />
            {mode === "upgrade"
              ? "升级申请将发送至新层级对应的审批人（L0/L1 → PEL，L2/L3 → 部门主管）。"
              : mode === "approve"
                ? "审批通过后将以此版本覆盖原 Case，并通知所有被分派人。"
                : "保存后将更新 Case 信息，已分派的任务负责人将收到通知。"}
          </div>
        )}

        {mode === "create" && (displayedSimilaritySuggestions.length > 0 || relatedCaseIds.length > 0) && (
          <section className="overflow-hidden rounded-xl border border-[#7A3DFF]/20 bg-white shadow-[0_5px_18px_-14px_rgba(122,61,255,0.35)]">
            <div className="flex items-center gap-3 border-b border-slate-100 bg-[#7A3DFF]/[0.035] px-5 py-3">
              <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-[#7A3DFF]/10 text-[#7A3DFF]"><Sparkles size={16} /></span>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-semibold text-slate-900">动态相似 Case 推荐</h3>
                  {visibleSimilaritySuggestions.length > 0 && <span className="rounded-full bg-[#7A3DFF]/10 px-2 py-0.5 text-[10px] font-medium text-[#7A3DFF]">发现 {visibleSimilaritySuggestions.length} 个</span>}
                </div>
                <p className="mt-0.5 text-[10.5px] text-slate-500">基于名称、背景、产品、Domain、失效模式与阶段动态计算；推荐仅供参考，不阻止新建</p>
              </div>
              <div className="ml-auto flex items-center gap-2 text-[10px]">
                <span className="rounded border border-amber-200 bg-amber-50 px-1.5 py-0.5 text-amber-700">45%–69% 相似</span>
                <span className="rounded border border-red-200 bg-red-50 px-1.5 py-0.5 text-red-600">≥70% 疑似重复</span>
              </div>
            </div>

            {relatedCaseIds.length > 0 && (
              <div className="flex flex-wrap items-center gap-1.5 border-b border-slate-100 px-5 py-2.5">
                <span className="inline-flex items-center gap-1 text-[10.5px] text-slate-500"><Network size={11} className="text-[#0052D9]" />待关联</span>
                {relatedCaseIds.map((id) => {
                  const relatedCase = mockCases.find((caseItem) => caseItem.id === id);
                  if (!relatedCase) return null;
                  return (
                    <span key={id} className="inline-flex h-6 items-center gap-1 rounded-full border border-[#0052D9]/20 bg-[#0052D9]/5 pl-2 pr-1 text-[10.5px] text-slate-700">
                      <span className="font-mono text-[9.5px] text-slate-400">{relatedCase.code}</span>
                      <span className="max-w-[180px] truncate">{relatedCase.name}</span>
                      <button type="button" onClick={() => toggleRelatedCase(id)} title={`移除 ${relatedCase.name}`} className="grid h-4 w-4 place-items-center rounded-full text-slate-400 hover:bg-slate-200"><XIcon size={10} /></button>
                    </span>
                  );
                })}
              </div>
            )}

            {displayedSimilaritySuggestions.length > 0 && (
              <div className="grid grid-cols-3 gap-3 p-4">
                {displayedSimilaritySuggestions.map((suggestion) => {
                  const suggestedCase = mockCases.find((caseItem) => caseItem.id === suggestion.caseId)!;
                  const linked = relatedCaseIds.includes(suggestion.caseId);
                  const branches = reusableThoughtBranches(suggestedCase);
                  const reusedCount = reusedBranchIds[suggestion.caseId]?.length ?? 0;
                  const allBranchesReused = branches.length > 0 && reusedCount >= branches.length;
                  const duplicate = suggestion.score >= 0.7;
                  return (
                    <article key={suggestion.caseId} className={`relative overflow-hidden rounded-lg border bg-white p-3.5 ${duplicate ? "border-red-200" : "border-amber-200"}`}>
                      <span aria-hidden="true" className={`absolute inset-y-3 left-0 w-0.5 rounded-r ${duplicate ? "bg-red-500" : "bg-amber-500"}`} />
                      <div className="flex items-center gap-1.5">
                        <span className={`rounded border px-1.5 py-0.5 text-[9.5px] font-medium ${duplicate ? "border-red-200 bg-red-50 text-red-600" : "border-amber-200 bg-amber-50 text-amber-700"}`}>{duplicate ? "疑似重复" : "相似 Case"}</span>
                        <span className={`rounded border px-1 py-0.5 text-[9px] ${levelColors[suggestedCase.level]}`}>{suggestedCase.level}</span>
                        <CaseProductPill caseItem={suggestedCase} compact />
                        <span className="ml-auto text-[10px] font-medium tabular-nums text-slate-500">{Math.round(suggestion.score * 100)}%</span>
                      </div>
                      <div className="mt-2 truncate text-[13px] font-semibold text-slate-800" title={suggestedCase.name}>{suggestedCase.name}</div>
                      <div className="mt-1 line-clamp-2 min-h-[34px] text-[10.5px] leading-relaxed text-slate-500"><span className="font-medium text-slate-600">判断依据：</span>{suggestion.reason}</div>
                      <div className="mt-3 flex flex-wrap items-center gap-1.5 border-t border-slate-100 pt-2.5">
                        <button type="button" onClick={() => setSimilarityPreviewId(suggestion.caseId)} className="h-7 rounded-md border border-slate-200 px-2 text-[10.5px] text-slate-600 hover:border-[#0052D9]/30 hover:text-[#0052D9]">查看 Case</button>
                        <button type="button" onClick={() => toggleRelatedCase(suggestion.caseId)} className={`h-7 rounded-md border px-2 text-[10.5px] ${linked ? "border-emerald-200 bg-emerald-50 text-emerald-700" : "border-[#0052D9]/25 text-[#0052D9] hover:bg-[#0052D9]/5"}`}>{linked ? "已关联" : "关联并继续"}</button>
                        <button type="button" disabled={branches.length === 0 || allBranchesReused} onClick={() => openReuseModal(suggestion.caseId)} className="h-7 rounded-md border border-[#7A3DFF]/25 px-2 text-[10.5px] text-[#7A3DFF] hover:bg-[#7A3DFF]/5 disabled:cursor-not-allowed disabled:opacity-40">{allBranchesReused ? "已复用" : reusedCount > 0 ? "继续复用" : "复用思路/任务"}</button>
                        <button type="button" onClick={() => setDismissedSimilarityIds((previous) => [...previous, suggestion.caseId])} className="ml-auto h-7 px-1.5 text-[10.5px] text-slate-400 hover:text-slate-600">忽略</button>
                      </div>
                    </article>
                  );
                })}
              </div>
            )}
            {visibleSimilaritySuggestions.length > displayedSimilaritySuggestions.length && <div className="px-5 pb-3 text-right text-[10px] text-slate-400">已优先展示匹配度最高的 3 个 Case</div>}
          </section>
        )}

        {/* Section 1: Basic info */}
        <section className="bg-white rounded-xl border border-slate-200/80 shadow-[0_1px_2px_0_rgba(15,23,42,0.04)] overflow-visible">
          <div className="px-5 py-3 border-b border-slate-100 flex items-center gap-2">
            <div className="w-6 h-6 rounded-md bg-[#0052D9]/8 text-[#0052D9] flex items-center justify-center text-[11px]">
              1
            </div>
            <h3 className="text-slate-900">Case 信息</h3>
          </div>
          <div className="p-5 space-y-5">

            {/* ===== 两栏：基础 + 背景 ===== */}
            <div className="grid grid-cols-2 gap-6 items-stretch">

            {/* ===== 基础 ===== */}
            <div>
              <div className="flex items-center gap-2 mb-3">
                <ClipboardList size={13} className="text-[#0052D9]" />
                <span className="text-xs font-semibold text-slate-700">基础</span>
              </div>
              <div className="space-y-4">
            <Field label="Case 名称" required>
              <div className={`relative ${levelMenuOpen ? "z-[70]" : ""}`}>
                <input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder=""
                  className="w-full h-10 pl-3 pr-36 rounded-md border border-slate-200 bg-slate-50/60 focus:bg-white focus:border-[#0052D9] outline-none text-sm"
                />
                <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
                  {/* 层级：默认随紧急度自动建议，可点击手动选择 */}
                  <div className="relative">
                    <button
                      type="button"
                      onClick={() => setLevelMenuOpen((o) => !o)}
                      title="点击手动选择层级"
                      className={`inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded text-[10px] border font-medium hover:brightness-95 ${levelColors[level]}`}
                    >
                      {level}
                      <ChevronDown size={10} className="opacity-70" />
                    </button>
                    {levelMenuOpen && (
                      <>
                        <div className="fixed inset-0 z-40" onClick={() => setLevelMenuOpen(false)} />
                        <div className="absolute top-full right-0 mt-1.5 w-80 bg-white border border-slate-200 rounded-lg shadow-xl z-50 p-1.5">
                          {LEVEL_ORDER.map((lv) => (
                            <button
                              key={lv}
                              type="button"
                              onClick={() => { setLevel(lv); setLevelTouched(true); setLevelMenuOpen(false); }}
                              className={`w-full text-left px-2 py-1.5 rounded-md flex items-start gap-2 hover:bg-slate-50 ${lv === level ? "bg-[#0052D9]/5" : ""}`}
                            >
                              <span className={`shrink-0 mt-0.5 px-1.5 py-0.5 rounded text-[10px] border font-medium ${levelColors[lv]}`}>{lv}</span>
                              <span className="text-[11px] leading-snug text-slate-600">{LEVEL_DESC[lv]}</span>
                              {lv === level && <Check size={13} className="ml-auto shrink-0 text-[#0052D9] mt-0.5" />}
                            </button>
                          ))}
                          <div className="px-2 pt-1 pb-0.5 text-[10px] text-slate-400 border-t border-slate-100 mt-1">默认根据紧急度自动建议，可在此手动调整。</div>
                        </div>
                      </>
                    )}
                  </div>
                  <div className="relative group inline-flex mr-1">
                    <HelpCircle size={12} className="text-slate-400 cursor-help" />
                    <div className="absolute top-full right-0 mt-2 w-72 bg-slate-800 text-white text-[11px] rounded-md px-3 py-2.5 leading-relaxed opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity z-50 shadow-lg space-y-1">
                      <div className="text-slate-300 mb-1">层级 = 问题重要性与影响范围，决定审批层级与响应时效：</div>
                      <div><b className="text-red-300">L0</b> {LEVEL_DESC.L0}</div>
                      <div><b className="text-orange-300">L1</b> {LEVEL_DESC.L1}</div>
                      <div><b className="text-amber-300">L2</b> {LEVEL_DESC.L2}</div>
                      <div><b className="text-blue-300">L3</b> {LEVEL_DESC.L3}</div>
                      <div><b className="text-slate-300">L4</b> {LEVEL_DESC.L4}</div>
                      <div className="text-slate-400 pt-0.5">默认按紧急度自动建议，可点击层级手动选择。</div>
                      <div className="absolute bottom-full right-0.5 border-4 border-transparent border-b-slate-800" />
                    </div>
                  </div>
                  <span className="h-4 w-px bg-slate-200 mx-0.5" />
                  <VoiceInputButton
                    size="sm"
                    onTranscript={(t) => setName((p) => (p ? p + " " + t : t))}
                  />
                  <AIPolishButton
                    size="sm"
                    getText={() => name}
                    onPolished={(t) => setName(t)}
                    hint="AI 润色 Case 名称"
                  />
                </div>
              </div>
            </Field>

            <div className="grid grid-cols-2 gap-4 items-start">
              <Field label="Case Owner" required>
                {mode === "create" ? (
                  <>
                    <SegmentedControl
                      ariaLabel="Case Owner 创建方式"
                      value={createdForOther ? "other" : "self"}
                      options={[
                        { value: "self", label: <>我（{currentUser.name}）</> },
                        { value: "other", label: "为分派" },
                      ]}
                      onChange={(value) => {
                        if (value === "self") {
                          setCreatedForOther(false);
                          setCaseOwner(currentUser.name);
                        } else {
                          setCreatedForOther(true);
                          setCaseOwner("");
                        }
                      }}
                    />
                    {createdForOther && (
                      <div className="mt-2">
                        <PersonInput
                          value={caseOwner}
                          onChange={setCaseOwner}
                          placeholder="请选择"
                          className="w-full h-10 px-3 rounded-md border border-slate-200 bg-white focus:border-[#0052D9] outline-none text-sm"
                        />
                        <div className="mt-1 text-[10px] text-[#0052D9]">Case创建后将通知Ta</div>
                      </div>
                    )}
                  </>
                ) : (
                  <div className="min-w-0">
                    <PersonInput
                      value={caseOwner}
                      onChange={setCaseOwner}
                      placeholder="请选择"
                      className="w-full h-10 px-3 rounded-md border border-slate-200 bg-white focus:border-[#0052D9] outline-none text-sm"
                    />
                  </div>
                )}
              </Field>
              <Field label="协作者" labelExtra={
                <div className="relative group inline-flex ml-1">
                  <HelpCircle size={12} className="text-slate-400 cursor-help" />
                  <div className="absolute bottom-full right-0 mb-2 w-72 bg-slate-800 text-white text-[11px] rounded-md px-3 py-2.5 leading-relaxed opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity z-50 shadow-lg space-y-1.5">
                    <div>1. 协作者可以协助 Case Owner 编辑拆解视图，添加思路、阶段与任务。</div>
                    <div className="absolute top-full right-0.5 border-4 border-transparent border-t-slate-800" />
                  </div>
                </div>
              }>
                <CreationCollaboratorInput
                  value={collaborators}
                  exclude={caseOwner ? [caseOwner] : []}
                  onChange={(names) => setCollaborators(names.map((name) => ({
                    name,
                    department: ownerToDepartment[name] ?? "—",
                  })))}
                />
              </Field>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <Field label="紧急程度" required>
                <div className="flex gap-1">
                  {urgencies.map((u) => (
                    <button
                      key={u}
                      onClick={() => setUrgency(u)}
                      className={`h-10 flex-1 rounded-md border text-[11px] transition-all ${
                        urgency === u
                          ? "bg-[#0052D9] text-white border-[#0052D9] shadow-sm"
                          : "border-slate-200 text-slate-600 hover:bg-slate-50"
                      }`}
                    >
                      {u}
                    </button>
                  ))}
                </div>
              </Field>
              <Field label="截止日期" required>
                <input
                  type="date"
                  value={dueDate}
                  onChange={(e) => setDueDate(e.target.value)}
                  className="w-full h-10 px-3 rounded-md border border-slate-200 bg-slate-50/60 focus:bg-white focus:border-[#0052D9] outline-none text-sm"
                />
              </Field>
            </div>
            <Field label="可见范围">
              <div className="space-y-2">
                <SegmentedControl
                  ariaLabel="Case 可见范围"
                  value={permissionType}
                  options={[
                    { value: "all", label: <><Globe size={15} />全员可见</> },
                    { value: "partial", label: <><Users size={15} />部分人可见</> },
                  ]}
                  onChange={setPermissionType}
                />

                {permissionType === "partial" && (
                  <div className="space-y-2 pt-2">
                    <MultiPersonInput
                      value={permissionList.filter((item) => item.type === "user").map((item) => item.name)}
                      onChange={(names) => setPermissionList(names.map((name) => ({
                        id: `perm-${name}`,
                        name,
                        type: "user",
                      })))}
                      placeholder="请选择可见人员"
                    />
                    {permissionList.length > 0 && (
                      <div className="flex items-center justify-between gap-3">
                        <span className="text-[11px] text-slate-400">已选 {permissionList.length} 人</span>
                        <div className="flex items-center -space-x-1.5">
                          {permissionList.map((person) => (
                            <div key={person.id} className="relative group" title={`${person.name} · ${ownerToDepartment[person.name] ?? "—"}`}>
                              <div className="w-6 h-6 rounded-full bg-gradient-to-br from-[#0052D9] to-[#00A4FF] flex items-center justify-center text-white text-[10px] border-2 border-white cursor-pointer">
                                {person.name.slice(-2)}
                              </div>
                              <div className="absolute bottom-full right-0 mb-2 px-2 py-1 bg-slate-800 text-white text-[10px] rounded whitespace-nowrap opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity z-10">
                                {person.name} · {ownerToDepartment[person.name] ?? "—"}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </Field>
              </div>
            </div>

            {/* ===== 背景 ===== */}
            <div className="flex flex-col">
              <div className="flex items-center gap-2 mb-3">
                <Edit2 size={13} className="text-[#0052D9]" />
                <span className="text-xs font-semibold text-slate-700">背景</span>
              </div>
              <div className="flex-1 min-h-0 flex flex-col gap-4">
                {/* 背景.事由 */}
                <div className="flex-1 min-h-0 flex flex-col">
                  <div className="text-xs text-slate-600 mb-1.5 tracking-wide flex items-center">发生了什么？ <span className="text-red-500 ml-0.5">*</span></div>
                  <div className="flex-1 min-h-0 flex flex-col rounded-lg border border-slate-200 bg-slate-50/60 overflow-hidden focus-within:bg-white focus-within:border-[#0052D9] transition-colors">
                    <div className="shrink-0 flex items-center gap-2 px-2.5 py-2 border-b border-slate-200/80 bg-white/70">
                      <label className="flex items-center gap-1.5 min-w-0">
                        <span className="text-[10.5px] text-slate-500 shrink-0">Domain</span>
                        <select
                          aria-label="Domain"
                          value={problemDomain}
                          onChange={(e) => setProblemDomain(e.target.value as ProblemDomain | "")}
                          className="w-[112px] h-7 rounded border border-slate-200 bg-white px-1.5 text-[11px] text-slate-700 outline-none focus:border-[#0052D9]"
                        >
                          <option value="">请选择</option>
                          {PROBLEM_DOMAINS.map((domain) => <option key={domain} value={domain}>{domain}</option>)}
                        </select>
                      </label>
                      <span className="h-4 w-px bg-slate-200" />
                      <label className="flex items-center gap-1.5 min-w-0">
                        <span className="text-[10.5px] text-slate-500 shrink-0">类型</span>
                        <select
                          aria-label="问题类型"
                          value={problemType}
                          onChange={(e) => setProblemType(e.target.value as ProblemType | "")}
                          className="w-[132px] h-7 rounded border border-slate-200 bg-white px-1.5 text-[11px] text-slate-700 outline-none focus:border-[#0052D9]"
                        >
                          <option value="">请选择</option>
                          {PROBLEM_TYPES.map((type) => <option key={type} value={type}>{type}</option>)}
                        </select>
                      </label>
                      <div className="ml-auto flex gap-1">
                        <VoiceInputButton size="sm" onTranscript={(t) => setBackground((p) => (p ? p + " " + t : t))} />
                        <AIPolishButton size="sm" hint="AI 润色并识别填充字段" onClick={runAiPolishFill} />
                        <AttachmentInput variant="icon" value={caseAttachments} onChange={setCaseAttachments} />
                      </div>
                    </div>
                    <textarea
                      value={background}
                      onChange={(e) => setBackground(e.target.value)}
                      placeholder="请描述具体发生的现象、影响范围、客户侧情况及已尝试措施..."
                      className="w-full flex-1 min-h-[72px] resize-none p-3 border-0 bg-transparent text-sm outline-none"
                    />
                  </div>
                  <AttachmentInput variant="chips" value={caseAttachments} onChange={setCaseAttachments} />
                </div>
                {/* 影响 */}
                <div className="flex-1 min-h-0 flex flex-col">
                  <div className="text-xs text-slate-600 mb-1.5 tracking-wide flex items-center">带来什么影响？ <span className="text-red-500 ml-0.5">*</span></div>
                  <div className="relative flex-1 min-h-0">
                    <textarea
                      value={impact}
                      onChange={(e) => setImpact(e.target.value)}
                      placeholder="对良率 / 交付 / 客户 / 成本的影响，量化范围（如影响 Lot 数、PPM、停机时长等）..."
                      className="w-full h-full resize-none p-3 pr-20 rounded-md border border-slate-200 bg-slate-50/60 text-sm outline-none focus:bg-white focus:border-[#0052D9]"
                    />
                    <div className="absolute right-2 top-2 flex gap-1">
                      <VoiceInputButton size="sm" onTranscript={(t) => setImpact((p) => (p ? p + " " + t : t))} />
                      <AIPolishButton size="sm" hint="AI 润色并识别填充字段" onClick={runAiPolishFill} />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            </div>
            {/* ===== 两栏结束 ===== */}

            {/* ===== 产品信息 ===== */}
            <div className="pt-5 border-t border-slate-100">
              <div className="flex items-center gap-2 mb-3">
                <Cpu size={13} className="text-[#0052D9]" />
                <span className="text-xs font-semibold text-slate-700">产品信息</span>
                <span className="text-[10.5px] text-slate-400">产品、物料必填；DIMM/CAMM 需选择类型；Fail Stage 必填；其余字段可展开选填</span>
              </div>
              <div>
            {/* 影响 / 产品 / 物料 / 失效 */}
            <div className="pt-0">
              <div className="flex flex-col gap-4">
                {/* 产品 + 物料（顶部带） */}
                <div className="grid grid-cols-4 gap-3 items-start">
                  {/* 产品编码 */}
                  <div className="flex flex-col gap-1">
                    <label className="text-[11px] text-slate-500">
                      产品 <span className="text-red-400">*</span>
                    </label>
                    <ProductPicker multiple value={productIds} onChange={setProductIds} placeholder="选择一个或多个产品" triggerClassName="min-h-[52px]" />
                  </div>

                  {/* 案件物料 */}
                  <div className="col-span-3 flex flex-col gap-1.5">
                    <label className="text-[11px] text-slate-500">
                      物料 <span className="text-red-400">*</span>
                    </label>
                    <div className="grid grid-cols-5 gap-1.5">
                      {MATERIAL_OPTIONS.map((m) => {
                        const on = material === m;
                        const meta = MATERIAL_META[m];
                        return (
                          <OptionCard
                            key={m}
                            active={on}
                            title={meta.desc}
                            onClick={() => {
                              setMaterial(m);
                              setMaterialSubtype("");
                              setMaterialSplitOpen(false);
                            }}
                            icon={<MaterialIcon value={m} active={on} />}
                            label={m}
                            sublabel={meta.level}
                          />
                        );
                      })}
                    </div>
                  </div>
                </div>

                {/* 通用产品明细（全部选填） */}
                {(materialKey === "Wafer" || materialKey === "IC" || isModule) && (
                  <>
                    {/* Fail Stage 与 类型（模组时同一行） */}
                    <div className="grid grid-cols-4 gap-3 items-start">
                      {/* Fail Stage（必填，常显） */}
                      <div className="flex flex-col gap-1">
                        <label className="text-[11px] text-slate-500">Fail Stage <span className="text-red-400">*</span></label>
                        <select value={failStage} onChange={e => setFailStage(e.target.value)} className="h-8 rounded-md border border-slate-200 bg-white px-2 text-xs text-slate-800 focus:outline-none focus:border-[#0052D9]">
                          <option value="">请选择</option>
                          <option value="CP1">CP1</option>
                          <option value="CP2">CP2</option>
                          <option value="FT">FT</option>
                          <option value="SLT">SLT</option>
                          <option value="FAB">FAB</option>
                          <option value="其他">其他</option>
                        </select>
                      </div>
                      {/* 类型（仅模组，5 列均分） */}
                      {isModule && (
                        <div className="col-span-3 flex min-w-0 flex-col gap-1">
                          <label className="text-[11px] text-slate-500">
                            类型 <span className="text-red-400">*</span>
                          </label>
                          <div className="grid grid-cols-5 gap-1.5">
                            {MATERIAL_SUBTYPES[material as "DIMM" | "CAMM"].map((subtype) => {
                              const on = materialSubtype === subtype;
                              return (
                                <button
                                  key={subtype}
                                  type="button"
                                  title={SUBTYPE_META[subtype]}
                                  onClick={() => setMaterialSubtype(subtype)}
                                  className={`flex items-center gap-2 rounded-lg border px-2.5 py-2 transition-all ${
                                    on
                                      ? "border-[#0052D9] bg-[#0052D9]/[0.06] shadow-sm"
                                      : "border-slate-200 hover:border-[#0052D9]/40 hover:bg-slate-50"
                                  }`}
                                >
                                  <SubtypeIcon subtype={subtype} active={on} />
                                  <div className="flex min-w-0 flex-col items-start leading-tight">
                                    <span className={`text-[11px] font-medium ${on ? "text-[#0052D9]" : "text-slate-700"}`}>{subtype}</span>
                                    <span className={`truncate text-[9px] ${on ? "text-[#0052D9]/70" : "text-slate-400"}`}>{SUBTYPE_META[subtype]}</span>
                                  </div>
                                  {on && <Check className="ml-auto h-3.5 w-3.5 shrink-0 text-[#0052D9]" />}
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      )}
                    </div>
                    <button
                      type="button"
                      onClick={() => setShowOptional(v => !v)}
                      className="mt-1 inline-flex items-center gap-1 text-[11px] text-[#0052D9] hover:text-[#003FA8] transition-colors"
                    >
                      <ChevronRight className={`w-3.5 h-3.5 transition-transform ${showOptional ? "rotate-90" : ""}`} />
                      {showOptional ? "收起选填项" : "展开更多选填项（Fail Ratio、Density、Mask Version、Fail Package、IO Type、Fail Platform、Customer、Program 等）"}
                    </button>
                    {showOptional && (
                    <>
                    <div className="grid grid-cols-4 gap-3">
                    {/* Fail Ratio */}
                    <div className="flex flex-col gap-1">
                      <label className="text-[11px] text-slate-500">Fail Ratio</label>
                      <input type="text" value={failRatio} onChange={e => setFailRatio(e.target.value)} placeholder="如：0.5%" className="h-8 rounded-md border border-slate-200 bg-white px-2 text-xs text-slate-800 placeholder:text-slate-300 focus:outline-none focus:border-[#0052D9]" />
                    </div>
                    {/* Density */}
                    <div className="flex flex-col gap-1">
                      <label className="text-[11px] text-slate-500">Density</label>
                      <select value={density} onChange={e => setDensity(e.target.value)} className="h-8 rounded-md border border-slate-200 bg-white px-2 text-xs text-slate-800 focus:outline-none focus:border-[#0052D9]">
                        <option value="">请选择</option>
                        <option value="8Gb">8Gb</option>
                        <option value="16Gb">16Gb</option>
                        <option value="24Gb">24Gb</option>
                        <option value="32Gb">32Gb</option>
                        <option value="其他">其他</option>
                      </select>
                    </div>
                    {/* Mask Version */}
                    <div className="flex flex-col gap-1">
                      <label className="text-[11px] text-slate-500">Mask Version</label>
                      <select value={maskVersion} onChange={e => setMaskVersion(e.target.value)} className="h-8 rounded-md border border-slate-200 bg-white px-2 text-xs text-slate-800 focus:outline-none focus:border-[#0052D9]">
                        <option value="">请选择</option>
                        <option value="A0">A0</option>
                        <option value="A1">A1</option>
                        <option value="B0">B0</option>
                        <option value="B1">B1</option>
                        <option value="C0">C0</option>
                        <option value="其他">其他</option>
                      </select>
                    </div>
                    {/* Fail Package */}
                    <div className="flex flex-col gap-1">
                      <label className="text-[11px] text-slate-500">Fail Package</label>
                      <select value={failPackage} onChange={e => setFailPackage(e.target.value)} className="h-8 rounded-md border border-slate-200 bg-white px-2 text-xs text-slate-800 focus:outline-none focus:border-[#0052D9]">
                        <option value="">请选择</option>
                        <option value="BGA">BGA</option>
                        <option value="FBGA">FBGA</option>
                        <option value="WLCSP">WLCSP</option>
                        <option value="QFP">QFP</option>
                        <option value="裸片">裸片</option>
                        <option value="其他">其他</option>
                      </select>
                    </div>
                    {/* IO Type / 位宽（同一概念，已合并） */}
                    <div className="flex flex-col gap-1">
                      <label className="text-[11px] text-slate-500">位宽（IO）</label>
                      <select value={ioType} onChange={e => setIoType(e.target.value)} className="h-8 rounded-md border border-slate-200 bg-white px-2 text-xs text-slate-800 focus:outline-none focus:border-[#0052D9]">
                        <option value="">请选择</option>
                        <option value="x4">x4</option>
                        <option value="x8">x8</option>
                        <option value="x16">x16</option>
                        <option value="x32">x32</option>
                        <option value="其他">其他</option>
                      </select>
                    </div>
                    {/* Fail Platform */}
                    <div className="flex flex-col gap-1">
                      <label className="text-[11px] text-slate-500">Fail Platform</label>
                      <input type="text" value={failPlatform} onChange={e => setFailPlatform(e.target.value)} placeholder="如：X86 / ARM" className="h-8 rounded-md border border-slate-200 bg-white px-2 text-xs text-slate-800 placeholder:text-slate-300 focus:outline-none focus:border-[#0052D9]" />
                    </div>
                    {/* Customer */}
                    <div className="flex flex-col gap-1">
                      <label className="text-[11px] text-slate-500">Customer</label>
                      <input type="text" value={customer} onChange={e => setCustomer(e.target.value)} placeholder="客户名称" className="h-8 rounded-md border border-slate-200 bg-white px-2 text-xs text-slate-800 placeholder:text-slate-300 focus:outline-none focus:border-[#0052D9]" />
                    </div>
                    {/* Program */}
                    <div className="flex flex-col gap-1">
                      <label className="text-[11px] text-slate-500">Program</label>
                      <input type="text" value={program} onChange={e => setProgram(e.target.value)} placeholder="程序名称" className="h-8 rounded-md border border-slate-200 bg-white px-2 text-xs text-slate-800 placeholder:text-slate-300 focus:outline-none focus:border-[#0052D9]" />
                    </div>
                    </div>

                    {isModule && (
                      <div className="mt-3 pt-3 border-t border-dashed border-slate-200">
                        <div className="text-[11px] text-slate-500 mb-2">{material} 扩展信息（选填）</div>
                        <div className="grid grid-cols-4 gap-3">
                          <div className="flex flex-col gap-1">
                            <label className="text-[11px] text-slate-500">案件属性</label>
                            <select value={caseAttribute} onChange={e => setCaseAttribute(e.target.value)} className="h-8 rounded-md border border-slate-200 bg-white px-2 text-xs text-slate-800 focus:outline-none focus:border-[#0052D9]">
                              <option value="">请选择</option>
                              <option value="VOC">VOC</option>
                              <option value="RMA">RMA</option>
                              <option value="ORT">ORT</option>
                              <option value="其他">其他</option>
                            </select>
                          </div>
                          <div className="flex flex-col gap-1">
                            <label className="text-[11px] text-slate-500">产品世代</label>
                            <input type="text" value={productGeneration} onChange={e => setProductGeneration(e.target.value)} placeholder="如：G4B" className="h-8 rounded-md border border-slate-200 bg-white px-2 text-xs text-slate-800 placeholder:text-slate-300 focus:outline-none focus:border-[#0052D9]" />
                          </div>
                          <div className="flex flex-col gap-1">
                            <label className="text-[11px] text-slate-500">容量</label>
                            <input type="text" value={dimmCapacity} onChange={e => setDimmCapacity(e.target.value)} placeholder="如：96GE" className="h-8 rounded-md border border-slate-200 bg-white px-2 text-xs text-slate-800 placeholder:text-slate-300 focus:outline-none focus:border-[#0052D9]" />
                          </div>
                          <div className="flex flex-col gap-1 col-span-2">
                            <label className="text-[11px] text-slate-500">项目名称</label>
                            <input type="text" value={projectName} onChange={e => setProjectName(e.target.value)} placeholder="如：幻方DRJPA 96GB 6400" className="h-8 rounded-md border border-slate-200 bg-white px-2 text-xs text-slate-800 placeholder:text-slate-300 focus:outline-none focus:border-[#0052D9]" />
                          </div>
                          <div className="flex flex-col gap-1">
                            <label className="text-[11px] text-slate-500">平台型号</label>
                            <input type="text" value={platformModel} onChange={e => setPlatformModel(e.target.value)} placeholder="如：联想：SR665V3" className="h-8 rounded-md border border-slate-200 bg-white px-2 text-xs text-slate-800 placeholder:text-slate-300 focus:outline-none focus:border-[#0052D9]" />
                          </div>
                          <div className="flex flex-col gap-1">
                            <label className="text-[11px] text-slate-500">产品料号</label>
                            <input type="text" value={productPartNumber} onChange={e => setProductPartNumber(e.target.value)} placeholder="如：CXMR5E4812312312" className="h-8 rounded-md border border-slate-200 bg-white px-2 text-xs text-slate-800 placeholder:text-slate-300 focus:outline-none focus:border-[#0052D9]" />
                          </div>
                        </div>
                      </div>
                    )}
                    </>
                    )}
                  </>
                )}
              </div>

              {(materialKey === "Wafer" || materialKey === "IC" || isModule) && (
              <div className="mt-4 pt-4 border-t border-slate-100">
                <div className="mb-3">
                  <div className="text-xs font-medium text-slate-700">
                    {materialKey === "IC"
                      ? "IC 明细（选填）"
                      : materialKey === "Wafer"
                        ? "Wafer 明细（选填）"
                      : isModule
                        ? `${material} 明细（选填）`
                        : "失效明细（选填）"}
                    <span className="text-slate-400 font-normal">
                      {isModule
                        ? ` · ${dimmGrains.length} 条`
                        : materialKey === "IC"
                          ? ` · ${icGrains.length} 颗`
                          : materialKey === "Wafer"
                            ? ` · ${waferLots.length} 个 Lot · ${selectedWaferCount} 片 Wafer`
                            : ""}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    {materialKey === "IC"
                      ? "可添加多颗 IC，每颗独立填写属性，不影响 Case 提交"
                      : materialKey === "Wafer"
                        ? "同一个输入框支持 Lot ID 和 Wafer ID；系统按长度识别，并由 Wafer ID 前 7 位自动归属 Lot"
                      : isModule
                        ? `可添加多条 ${material} 并独立填写属性，不影响 Case 提交`
                          : ""}
                  </div>
                </div>
              {/* IC 颗粒信息列表 */}
              {materialKey === "IC" && (
                <div className="mt-2">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs text-slate-500">IC 列表</span>
                    <button
                      type="button"
                      onClick={addIcGrain}
                      className="flex items-center gap-1 text-[11px] text-[#0052D9] hover:text-[#003FA8] transition-colors"
                    >
                      <Plus className="w-3 h-3" />
                      添加更多
                    </button>
                  </div>
                  <label className={`mb-2 flex items-center gap-2 rounded-lg border px-3 py-2 ${icGrains.length > 1 ? "border-slate-200 bg-slate-50/60 cursor-pointer" : "border-slate-100 bg-slate-50/40 cursor-not-allowed"}`}>
                    <input type="checkbox" checked={icSplit} onChange={e => setIcSplit(e.target.checked)} disabled={icGrains.length <= 1} className="accent-[#0052D9]" />
                    <span className={`text-[11px] ${icGrains.length > 1 ? "text-slate-600" : "text-slate-400"}`}>为每颗 IC 分别建立一个独立 Case（背景 / 影响等信息相同）</span>
                    {icGrains.length <= 1 && <span className="ml-auto text-[10px] text-slate-400">添加第 2 颗后可开启</span>}
                  </label>
                  <div className="grid grid-cols-2 gap-3">
                    {icGrains.map((grain, idx) => {
                      const mc = getIcMarkCode(grain);
                      const ready = mc !== "—";
                      const inputCls = "mt-0.5 w-full h-7 rounded border border-slate-200 bg-white px-2 text-[11px] text-slate-900 placeholder:text-slate-300 focus:outline-none focus:ring-1 focus:ring-[#0052D9]/40";
                      return (
                        <div key={grain.id} className="rounded-xl border border-slate-200 bg-white p-3">
                          <div className="flex items-center gap-2.5 mb-2.5">
                            <IcChipIcon active={ready} />
                            <div className="min-w-0 flex-1">
                              <div className="flex items-center gap-1.5">
                                <span className="text-[10.5px] text-slate-400">IC #{idx + 1}</span>
                                <span title="系统自动生成的 Mark Code（5 位）" className="inline-flex items-center gap-0.5 rounded-full border border-amber-200 bg-amber-50 px-1.5 py-0.5 text-[9px] font-medium text-amber-700"><Hash size={9} strokeWidth={2} /> {grain.markCode}</span>
                              </div>
                              <div className={`font-mono text-[11px] truncate ${ready ? "text-[#0052D9]" : "text-slate-300"}`}>{mc}</div>
                            </div>
                            <button type="button" onClick={() => removeIcGrain(grain.id)} disabled={icGrains.length === 1} className="text-slate-300 hover:text-red-400 transition-colors disabled:opacity-30 disabled:cursor-not-allowed shrink-0">
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <label className="text-[10px] text-slate-500">Barcode</label>
                              <input type="text" value={grain.barcode} onChange={e => updateIcGrain(grain.id, "barcode", e.target.value)} placeholder="条形码" className={inputCls} />
                            </div>
                            <div>
                              <label className="text-[10px] text-slate-500">Chip ID</label>
                              <input type="text" value={grain.chipid} onChange={e => updateIcGrain(grain.id, "chipid", e.target.value)} placeholder="Chip 编号" className={inputCls} />
                            </div>
                            <div>
                              <label className="text-[10px] text-slate-500">Fail Mode</label>
                              <input type="text" value={grain.failMode} onChange={e => updateIcGrain(grain.id, "failMode", e.target.value)} placeholder="失效模式" className={inputCls} />
                            </div>
                            <div>
                              <label className="text-[10px] text-slate-500">Fail Condition</label>
                              <input type="text" value={grain.failCondition} onChange={e => updateIcGrain(grain.id, "failCondition", e.target.value)} placeholder="失效条件" className={inputCls} />
                            </div>
                          </div>
                          <div className="flex items-center gap-1.5 mt-2.5 pt-2.5 border-t border-slate-100">
                            <span className={`text-[10px] px-1.5 py-0.5 rounded ${ready ? "bg-emerald-50 text-emerald-600" : "bg-slate-100 text-slate-400"}`}>{ready ? "✓ 已识别" : "选填"}</span>
                            <button type="button" onClick={() => openChipDNA(mc, icRows(grain))} title="查看 Chip DNA" className="ml-auto h-6 px-2 rounded border border-slate-200 text-[10.5px] text-slate-600 hover:border-[#0052D9]/50 hover:text-[#0052D9] hover:bg-[#0052D9]/5 transition-colors inline-flex items-center gap-1">
                              <Fingerprint className="w-3 h-3" /> Chip DNA
                            </button>
                            <button type="button" onClick={() => openOneClick(mc, icRows(grain))} title="查看 One Click" className="h-6 px-2 rounded border border-slate-200 text-[10.5px] text-slate-600 hover:border-[#0052D9]/50 hover:text-[#0052D9] hover:bg-[#0052D9]/5 transition-colors inline-flex items-center gap-1">
                              <MousePointerClick className="w-3 h-3" /> One Click
                            </button>
                            <button type="button" onClick={() => openCpIndex(mc, icRows(grain))} title="查看 CP Index" className="h-6 px-2 rounded border border-slate-200 text-[10.5px] text-slate-600 hover:border-[#0052D9]/50 hover:text-[#0052D9] hover:bg-[#0052D9]/5 transition-colors inline-flex items-center gap-1">
                              <Hash className="w-3 h-3" /> CP Index
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* DIMM / CAMM 列表 */}
              {isModule && (
                <div className="mt-3 pt-3 border-t border-dashed border-slate-200">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs text-slate-500">{material} 列表</span>
                    <button
                      type="button"
                      onClick={addDimmGrain}
                      className="flex items-center gap-1 text-[11px] text-[#0052D9] hover:text-[#003FA8] transition-colors"
                    >
                      <Plus className="w-3 h-3" />
                      添加更多
                    </button>
                  </div>
                  <label className={`mb-2 flex items-center gap-2 rounded-lg border px-3 py-2 ${dimmGrains.length > 1 ? "border-slate-200 bg-slate-50/60 cursor-pointer" : "border-slate-100 bg-slate-50/40 cursor-not-allowed"}`}>
                    <input type="checkbox" checked={moduleSplit} onChange={e => setModuleSplit(e.target.checked)} disabled={dimmGrains.length <= 1} className="accent-[#0052D9]" />
                    <span className={`text-[11px] ${dimmGrains.length > 1 ? "text-slate-600" : "text-slate-400"}`}>为每条 {material} 分别建立一个独立 Case（背景 / 影响等信息相同）</span>
                    {dimmGrains.length <= 1 && <span className="ml-auto text-[10px] text-slate-400">添加第 2 条后可开启</span>}
                  </label>
                  <div className="grid grid-cols-2 gap-3">
                    {dimmGrains.map((grain, idx) => {
                      const mc = getDimmMarkCode(grain);
                      const ready = mc !== "—";
                      const inputCls = "mt-0.5 w-full h-7 rounded border border-slate-200 bg-white px-2 text-[11px] text-slate-900 placeholder:text-slate-300 focus:outline-none focus:ring-1 focus:ring-[#0052D9]/40";
                      return (
                        <div key={grain.id} className="rounded-xl border border-slate-200 bg-white p-3">
                          <div className="flex items-center gap-2.5 mb-2.5">
                            <DimmModuleIcon active={ready} />
                            <div className="min-w-0 flex-1">
                              <div className="flex items-center gap-1.5">
                                <span className="text-[10.5px] text-slate-400">{material} #{idx + 1}</span>
                                <span title="系统自动生成的 Mark Code（5 位）" className="inline-flex items-center gap-0.5 rounded-full border border-amber-200 bg-amber-50 px-1.5 py-0.5 text-[9px] font-medium text-amber-700"><Hash size={9} strokeWidth={2} /> {grain.markCode}</span>
                              </div>
                              <div className={`font-mono text-[11px] truncate ${ready ? "text-[#0052D9]" : "text-slate-300"}`}>{mc}</div>
                            </div>
                            <button type="button" onClick={() => removeDimmGrain(grain.id)} disabled={dimmGrains.length === 1} className="text-slate-300 hover:text-red-400 transition-colors disabled:opacity-30 disabled:cursor-not-allowed shrink-0">
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <label className="text-[10px] text-slate-500">SN</label>
                              <input type="text" value={grain.sn} onChange={e => updateDimmGrain(grain.id, "sn", e.target.value)} placeholder="序列号" className={inputCls} />
                              {grain.sn.trim() && (
                                <button
                                  type="button"
                                  onClick={() => retrieveDimmIc(grain.id, grain.sn)}
                                  className="mt-1 inline-flex items-center gap-1 text-[10.5px] font-medium text-[#0052D9] hover:text-[#003FA8] transition-colors"
                                >
                                  <Search className="w-3 h-3" /> {grain.icTree ? "重新检索 IC 信息" : "检索 IC 信息"}
                                </button>
                              )}
                            </div>
                            <div>
                              <label className="text-[10px] text-slate-500">Work Order</label>
                              <input type="text" value={grain.workOrder} onChange={e => updateDimmGrain(grain.id, "workOrder", e.target.value)} placeholder="工单号" className={inputCls} />
                            </div>
                            <div>
                              <label className="text-[10px] text-slate-500">Fail Mode</label>
                              <input type="text" value={grain.failMode} onChange={e => updateDimmGrain(grain.id, "failMode", e.target.value)} placeholder="失效模式" className={inputCls} />
                            </div>
                            <div>
                              <label className="text-[10px] text-slate-500">Fail Condition</label>
                              <input type="text" value={grain.failCondition} onChange={e => updateDimmGrain(grain.id, "failCondition", e.target.value)} placeholder="失效条件" className={inputCls} />
                            </div>
                          </div>
                          <div className="mt-2.5 rounded-lg border border-[#0052D9]/15 bg-[#0052D9]/[0.02] p-2.5">
                            <div className="flex items-center gap-1.5 mb-2 text-[10.5px] text-slate-600">
                              <Cpu className="w-3 h-3 text-[#0052D9]" />
                              <span className="font-medium">Chip ID List</span>
                              {grain.icTree && <span className="text-slate-400">· {grain.icTree.ics.reduce((count, ic) => count + ic.dies.length, 0)} 条</span>}
                              <button type="button" onClick={() => addDimmChip(grain.id)} className="ml-auto inline-flex h-6 items-center gap-1 rounded-md border border-[#0052D9]/20 bg-white px-2 text-[10px] font-medium text-[#0052D9] hover:bg-[#0052D9]/5"><Plus size={10} />添加 Chip ID</button>
                            </div>
                            {grain.icTree?.ics.some((ic) => ic.dies.length > 0) ? (
                              <div className="grid max-h-[220px] grid-cols-2 gap-1.5 overflow-y-auto pr-0.5">
                                {grain.icTree.ics.map((ic) => (
                                  <div key={ic.icId} className="rounded-md border border-slate-200 bg-white px-2 py-1.5">
                                    <div className="mb-1 text-[10px] font-medium text-slate-600">{ic.icId}</div>
                                    <div className="space-y-1.5">
                                      {ic.dies.map((die) => (
                                        <div key={die.dieId} className={`rounded-md border p-1.5 ${die.isFailChip ? "border-red-200 bg-red-50/70" : "border-slate-200 bg-slate-50/60"}`}>
                                          <div className="flex items-center gap-1.5">
                                            <span className="w-[48px] shrink-0 truncate text-[9px] text-slate-400" title={die.dieId}>{die.dieId}</span>
                                            <input value={die.chipId} onChange={(event) => updateDimmChip(grain.id, ic.icId, die.dieId, { chipId: event.target.value })} placeholder="输入 Chip ID" className="h-7 min-w-0 flex-1 rounded border border-slate-200 bg-white px-2 font-mono text-[10px] text-slate-700 outline-none focus:border-[#0052D9]" />
                                            {die.manual && <button type="button" onClick={() => removeDimmChip(grain.id, ic.icId, die.dieId)} title="删除该 Chip ID" className="grid h-7 w-6 shrink-0 place-items-center text-slate-300 hover:text-red-500"><Trash2 size={11} /></button>}
                                          </div>
                                          <label className="mt-1 flex cursor-pointer items-center gap-1.5 text-[9.5px]">
                                            <input type="checkbox" checked={!!die.isFailChip} onChange={(event) => updateDimmChip(grain.id, ic.icId, die.dieId, { isFailChip: event.target.checked })} className="accent-red-600" />
                                            <span className={die.isFailChip ? "font-medium text-red-600" : "text-slate-500"}>{die.isFailChip ? "Fail Chip" : "标记为 Fail Chip"}</span>
                                          </label>
                                        </div>
                                      ))}
                                    </div>
                                  </div>
                                ))}
                              </div>
                            ) : <div className="rounded-md border border-dashed border-slate-200 bg-white px-3 py-4 text-center text-[10px] text-slate-400">暂无 Chip ID，可手动添加或通过 SN 检索</div>}
                            <div className="mt-1.5 text-[9.5px] text-slate-400">Chip ID 可手动修改；勾选后将在 Case 中标记为 Fail Chip。</div>
                          </div>
                          <div className="flex items-center gap-1.5 mt-2.5 pt-2.5 border-t border-slate-100">
                            <span className={`text-[10px] px-1.5 py-0.5 rounded ${ready ? "bg-emerald-50 text-emerald-600" : "bg-slate-100 text-slate-400"}`}>{ready ? "✓ 已识别" : "选填"}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Wafer 信息列表 */}
              {material === "Wafer" && (
                <div className="mt-3 pt-3 border-t border-dashed border-slate-200">
                  <div className="rounded-xl border border-slate-200 bg-slate-50/50 p-3">
                    <div className="flex items-center justify-between mb-1.5">
                      <label className="text-[11px] font-medium text-slate-600">Lot ID / Wafer ID（选填，支持多个，按逗号分隔）</label>
                    </div>
                    <div className={`min-h-10 flex items-center rounded-md border bg-white px-2 transition-colors focus-within:border-[#0052D9] ${waferIdentifierError ? "border-red-300" : "border-slate-200"}`}>
                      <Search className="w-3.5 h-3.5 shrink-0 text-slate-400" />
                      <input
                        type="text"
                        value={waferIdentifierInput}
                        onChange={(event) => {
                          setWaferIdentifierInput(event.target.value.toUpperCase());
                          if (waferIdentifierError) setWaferIdentifierError("");
                        }}
                        onKeyDown={(event) => {
                          if (event.key !== "Enter") return;
                          event.preventDefault();
                          commitWaferIdentifiers(event.currentTarget.value);
                        }}
                        onBlur={(event) => commitWaferIdentifiers(event.currentTarget.value)}
                        placeholder="输入 7 位 Lot ID 或 12 位 Wafer ID，可批量输入（逗号分隔，回车识别）"
                        className="h-9 min-w-[260px] flex-1 bg-transparent px-2 text-[11px] font-mono text-slate-800 placeholder:font-sans placeholder:text-slate-300 focus:outline-none"
                      />
                      <span className="shrink-0 rounded bg-slate-100 px-1.5 py-0.5 text-[9.5px] text-slate-400">自动识别</span>
                    </div>
                    {waferIdentifierError ? (
                      <div className="mt-1.5 text-[10px] text-red-500">{waferIdentifierError}</div>
                    ) : null}
                  </div>
                  {waferLots.length === 0 ? (
                    <div className="mt-3 rounded-xl border border-dashed border-slate-200 bg-white px-4 py-6 text-center">
                      <div className="text-[11px] text-slate-400">输入后，系统将自动按 Lot 分组展示识别结果</div>
                    </div>
                  ) : (
                    <div className="mt-3 grid grid-cols-4 gap-3 items-start">
                      {waferLots.map((lot) => (
                        <div key={lot.id} className="rounded-xl border border-slate-200 bg-white p-3">
                          <div className="flex items-center gap-2">
                            <div className="w-7 h-7 rounded-full border-2 border-[#0052D9]/25 bg-[#0052D9]/5 grid place-items-center text-[9px] font-semibold text-[#0052D9]">W</div>
                            <div className="min-w-0">
                              <div className="text-[10px] text-slate-400">识别 Lot ID</div>
                              <div className="font-mono text-[11.5px] font-medium text-slate-700">{lot.lotId}</div>
                            </div>
                            <span className={`ml-2 rounded px-1.5 py-0.5 text-[10px] ${lot.wholeLot ? "bg-emerald-50 text-emerald-600" : "bg-[#0052D9]/8 text-[#0052D9]"}`}>
                              {lot.wholeLot ? "整 Lot · 25 片" : `${lot.waferIds.length} 片 Wafer`}
                            </span>
                            <button type="button" onClick={() => removeWaferLot(lot.id)} className="ml-auto text-slate-300 hover:text-red-400" title={`删除 Lot ${lot.lotId}`}>
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                          {lot.waferIds.length > 0 && (
                            <div className="mt-2.5 border-t border-slate-100 pt-2.5">
                              <div className="mb-1.5 text-[10px] text-slate-400">Wafer ID（均以 {lot.lotId} 开头）</div>
                              <div className="flex flex-wrap gap-1.5">
                                {lot.waferIds.map((waferId) => (
                                  <span key={waferId} className="inline-flex h-6 items-center gap-1 rounded border border-[#0052D9]/20 bg-[#0052D9]/5 px-2 font-mono text-[10px] text-[#0052D9]">
                                    {waferId}
                                    <button type="button" onClick={() => removeWaferId(lot.id, waferId)} className="text-[#0052D9]/40 hover:text-[#0052D9]" title={`删除 Wafer ${waferId}`}>
                                      <XIcon className="w-3 h-3" />
                                    </button>
                                  </span>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
              </div>
              )}
            </div>
              </div>
            </div>
          </div>
        </section>

        {mode === "create" && false && (
          <section className="bg-white rounded-xl border border-slate-200/80 shadow-[0_1px_2px_0_rgba(15,23,42,0.04)] overflow-hidden">
            <div className="px-5 py-3 border-b border-slate-100 flex items-center gap-2">
              <div className="w-6 h-6 rounded-md bg-[#0052D9]/8 text-[#0052D9] flex items-center justify-center text-[11px]">2</div>
              <h3 className="text-slate-900">Case 来源与相关 Issue</h3>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <label className="text-[11px] text-slate-500">立案来源</label>
                <div className="mt-1 flex items-center gap-1.5 flex-wrap">
                  {CASE_SOURCES.map((s) => (
                    <button key={s} type="button" onClick={() => setSource(s)}
                      className={`h-10 px-3 text-[11px] rounded-md border transition-all ${source === s ? "bg-[#0052D9] text-white border-[#0052D9] shadow-sm" : "border-slate-200 text-slate-600 hover:bg-slate-50"}`}>
                      {s === "手动" ? "Checklist 检查" : s === "Q·FAQA" ? "Q·FAQA 客诉" : s}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <div className="flex items-center gap-2">
                  <label className="text-[11px] text-slate-500">归属 Issue</label>
                </div>
                <div className="mt-1.5 flex gap-2">
                  <button
                    type="button"
                    onClick={() => { setIssueLinkMode("later"); setAttachIssueIds([]); setNewIssueName(""); }}
                    className={`h-10 px-3 text-[11px] rounded-md border transition-all ${issueLinkMode === "later" ? "bg-[#0052D9] text-white border-[#0052D9] shadow-sm" : "border-slate-200 text-slate-600 hover:bg-slate-50"}`}
                  >
                    暂时无法关联
                  </button>
                  <button
                    type="button"
                    onClick={() => setIssueLinkMode("now")}
                    className={`h-10 px-3 text-[11px] rounded-md border transition-all ${issueLinkMode === "now" ? "bg-[#0052D9] text-white border-[#0052D9] shadow-sm" : "border-slate-200 text-slate-600 hover:bg-slate-50"}`}
                  >
                    现在关联 Issue
                  </button>
                </div>
                {issueLinkMode === "later" ? (
                  <div className="mt-2 text-[11px] text-slate-500 bg-slate-50 border border-slate-100 rounded px-3 py-2">
                    暂不关联 Issue。现在还不清楚共性时可先跳过；<b className="text-slate-600">后续多个 Case 证明同类问题重复发生时，再归纳为 Issue</b>。
                  </div>
                ) : (
                <>
                <div className="mt-1.5 flex items-center gap-2 flex-wrap">
                  <div className="relative flex-1 min-w-[180px]">
                    <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input value={issueQ} onChange={(e) => setIssueQ(e.target.value)} placeholder="查找 Issue 编号 / 名称"
                      className="h-8 w-full pl-8 pr-3 text-sm rounded-md border border-slate-200 outline-none focus:border-[#0052D9]" />
                  </div>
                  <select value={issueObjType} onChange={(e) => setIssueObjType(e.target.value)} className="h-8 px-2 text-sm rounded-md border border-slate-200 bg-white outline-none focus:border-[#0052D9]">
                    {["全部", ...OBJECT_TYPES].map((o) => <option key={o} value={o}>{o === "全部" ? "对象类型" : o}</option>)}
                  </select>
                  <select value={issueStatusF} onChange={(e) => setIssueStatusF(e.target.value)} className="h-8 px-2 text-sm rounded-md border border-slate-200 bg-white outline-none focus:border-[#0052D9]">
                    {["全部", ...ISSUE_STATUS_OPTS].map((o) => <option key={o} value={o}>{o === "全部" ? "状态" : o}</option>)}
                  </select>
                </div>
                <div className="mt-1.5 max-h-[160px] overflow-y-auto rounded-md border border-slate-200 divide-y divide-slate-50">
                  {filteredIssues.map((iss) => {
                    const on = attachIssueIds.includes(iss.id);
                    return (
                      <label key={iss.id} className={`flex items-center gap-2 px-3 py-2 cursor-pointer ${on ? "bg-[#0052D9]/[0.04]" : "hover:bg-slate-50"}`}>
                        <input type="checkbox" checked={on} onChange={() => setAttachIssueIds((prev) => on ? prev.filter((x) => x !== iss.id) : [...prev, iss.id])} className="accent-[#0052D9]" />
                        <span className="font-mono text-[11px] text-slate-400">{iss.code}</span>
                        <span className="text-sm text-slate-800 flex-1 min-w-0 truncate">{iss.name}</span>
                        <span className={`px-1.5 py-0.5 rounded text-[10px] border ${objectTypeColors[iss.objectType]}`}>{iss.objectType}</span>
                        <span className={`px-1.5 py-0.5 rounded text-[10px] border ${issueStatusColors[iss.status]}`}>{iss.status}</span>
                      </label>
                    );
                  })}
                  {filteredIssues.length === 0 && <div className="px-3 py-3 text-xs text-slate-400">无匹配 Issue</div>}
                </div>
                <div className="mt-2 flex items-center gap-2">
                  <span className="text-[11px] text-slate-500 shrink-0">或新建 Issue</span>
                  <input value={newIssueName} onChange={(e) => setNewIssueName(e.target.value)} placeholder="填写 Issue 名称将新建并关联（可留空）"
                    className="flex-1 h-8 px-2.5 text-sm rounded-md border border-slate-200 outline-none focus:border-[#0052D9]" />
                </div>
                </>
                )}
              </div>
            </div>
          </section>
        )}

        {prefill?.sourceStandaloneTaskIds?.length && <section aria-label="带入的自由任务" className="border-y border-blue-100 bg-blue-50/40 px-5 py-3"><h3 className="text-sm text-slate-800">带入的自由任务 · {prefill.sourceStandaloneTaskIds.length}</h3><ul className="mt-2 space-y-1 text-xs text-slate-600">{prefill.sourceStandaloneTaskIds.map(id => <li key={id}>{standaloneTaskById(id)?.code} · {standaloneTaskById(id)?.title ?? "任务不存在"}</li>)}</ul></section>}
        {submitError && <p role="alert" className="sticky bottom-20 z-50 rounded-md bg-red-50 p-3 text-sm text-red-600">{submitError}</p>}
        {/* Section 2: Tasks via shared MindMap */}
        <section className="bg-white rounded-xl border border-slate-200/80 shadow-[0_1px_2px_0_rgba(15,23,42,0.04)] overflow-hidden">
          <div className="px-5 py-3 border-b border-slate-100 flex items-center gap-3">
            <div className="w-6 h-6 rounded-md bg-[#0052D9]/8 text-[#0052D9] flex items-center justify-center text-[11px]">
              2
            </div>
            <h3 className="text-slate-900">Case 拆解与协作</h3>
            {/* 视图切换：思维导图 / 任务视图（共享同一份数据） */}
            <div className="ml-auto inline-flex items-center rounded-lg border border-slate-200 bg-slate-50 p-0.5">
              <button
                type="button"
                onClick={() => setAnalysisTemplate("blank")}
                className={`inline-flex items-center gap-1.5 h-7 px-2.5 rounded-md text-[12px] font-medium transition-colors ${analysisTemplate !== "table-wbs" ? "bg-white text-[#0052D9] shadow-sm" : "text-slate-500 hover:text-slate-700"}`}
              >
                <Network size={13} /> 思维导图
              </button>
              <button
                type="button"
                onClick={() => setAnalysisTemplate("table-wbs")}
                className={`inline-flex items-center gap-1.5 h-7 px-2.5 rounded-md text-[12px] font-medium transition-colors ${analysisTemplate === "table-wbs" ? "bg-white text-[#0052D9] shadow-sm" : "text-slate-500 hover:text-slate-700"}`}
              >
                <TableProperties size={13} /> 任务视图
              </button>
            </div>
            <span className="text-[11px] text-slate-500 shrink-0">
              共 <b className="text-slate-800">{thoughtGroups.length}</b> 个思路
            </span>
          </div>

          <div className="p-5">
            <div className="mb-3 text-[11.5px] text-slate-400">
              {analysisTemplate === "table-wbs"
                ? "任务视图：以思路 / 任务清单录入；与思维导图共享同一份数据，随时可切换。"
                : "思维导图视图：以思路 / 怀疑方向 + 任务的树状图录入；与任务视图共享同一份数据，随时可切换。"}
            </div>
            {analysisTemplate === "table-wbs" ? (
              <CreateCaseWbsTable
                caseData={synthesizedCase}
                thoughtGroups={thoughtGroups}
                onGroupsChange={setThoughtGroups}
              />
            ) : (
              <CreateCaseMindMapFlow
                caseData={synthesizedCase}
                thoughtGroups={thoughtGroups}
                onGroupsChange={setThoughtGroups}
                coachEnabled={false}
              />
            )}
          </div>
        </section>

        {/* Section 3: 备注 / 补充说明 */}
        <section className="bg-white rounded-xl border border-slate-200/80 shadow-[0_1px_2px_0_rgba(15,23,42,0.04)] overflow-hidden">
          <div className="px-5 py-3 border-b border-slate-100 flex items-center gap-2">
            <div className="w-6 h-6 rounded-md bg-[#0052D9]/8 text-[#0052D9] flex items-center justify-center text-[11px]">
              3
            </div>
            <h3 className="text-slate-900">备注 / 补充说明</h3>
            <span className="text-[10.5px] text-slate-400">选填</span>
          </div>
          <div className="p-5">
            <textarea
              value={remark}
              onChange={(e) => setRemark(e.target.value)}
              placeholder="补充说明、遗留问题、协同提醒等，可选填..."
              className="w-full min-h-[88px] resize-y p-3 rounded-md border border-slate-200 bg-slate-50/60 text-sm outline-none focus:bg-white focus:border-[#0052D9]"
            />
          </div>
        </section>
      </div>

      {/* Frozen bottom action bar */}
      <div className="sticky bottom-0 left-0 right-0 z-30 border-t border-slate-200 bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/80 shadow-[0_-2px_8px_rgba(15,23,42,0.04)]">
        <div className="max-w-[1200px] mx-auto px-8 py-3 flex items-center justify-end gap-2">
          <button
            onClick={onDone}
            className="h-9 px-4 rounded-md border border-slate-200 text-sm text-slate-700 hover:bg-slate-50"
          >
            取消
          </button>
          <button
            onClick={handleReset}
            className="h-9 px-4 rounded-md border border-slate-200 text-sm text-slate-700 hover:bg-slate-50 flex items-center gap-1.5"
          >
            <RotateCcw size={14} />
            重置
          </button>
          {mode === "create" && (
            <button
              onClick={onDone}
              disabled={!name.trim()}
              title="暂存草稿，可在 Case 中心『暂存』状态继续编辑"
              className="h-9 px-4 rounded-md border border-amber-300 bg-amber-50 text-sm text-amber-700 hover:bg-amber-100 disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1.5"
            >
              暂存
            </button>
          )}
          <button
            onClick={finalSubmit}
            disabled={!canSubmit}
            className="h-9 px-4 rounded-md bg-gradient-to-r from-[#0052D9] to-[#003FA8] text-white text-sm hover:shadow-md disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1.5"
          >
            <Check size={14} />
            {submitLabel}
          </button>
        </div>
      </div>

      {/* 功能1：AI 智能识别填充弹窗 */}
      {similarityPreviewCase && <SimilarityCasePreviewModal caseItem={similarityPreviewCase} onClose={() => setSimilarityPreviewId(null)} />}
      {reuseSourceCase && (
        <ReuseAnalysisBranchesModal
          caseItem={reuseSourceCase}
          reusedBranchIds={reusedBranchIds[reuseSourceCase.id] ?? []}
          selectedBranchIds={reuseSelectedBranchIds}
          onSelectedBranchIdsChange={setReuseSelectedBranchIds}
          onClose={() => { setReuseSourceId(null); setReuseSelectedBranchIds([]); }}
          onApply={applyReusedBranches}
        />
      )}

      {aiOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-6" onMouseDown={() => setAiOpen(false)}>
          <div className="w-[720px] max-w-[92vw] max-h-[86vh] bg-white rounded-2xl shadow-2xl border border-slate-200 flex flex-col overflow-hidden" onMouseDown={(e) => e.stopPropagation()}>
            <div className="px-5 py-4 border-b border-slate-100 flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#7A3DFF] to-[#0052D9] text-white grid place-items-center"><Wand2 size={16} /></div>
              <div>
                <div className="text-slate-900 font-semibold text-[15px]">AI 智能识别填充</div>
                <div className="text-[11.5px] text-slate-400">识别「发生了什么 / 影响」中的关键信息；填充前可直接修改识别值</div>
              </div>
              <button onClick={() => setAiOpen(false)} className="ml-auto w-8 h-8 rounded-md hover:bg-slate-100 grid place-items-center text-slate-400"><XIcon size={16} /></button>
            </div>
            <div className="p-5 space-y-3 overflow-y-auto">
              <div className="relative">
                <textarea
                  value={aiText}
                  onChange={(e) => setAiText(e.target.value)}
                  placeholder="例如：客户反馈 DMJFC 在 FT 高温段出现批量 Icc 漏电超规，失效比例 0.8%，密度 16Gb……"
                  className="w-full min-h-[130px] p-3 rounded-lg border border-slate-200 bg-slate-50/60 text-sm outline-none focus:bg-white focus:border-[#7A3DFF]"
                />
                <button onClick={() => setAiText(AI_SAMPLE)} className="absolute right-2 bottom-2 text-[11px] px-2 py-1 rounded border border-slate-200 bg-white text-slate-500 hover:text-[#7A3DFF] hover:border-[#7A3DFF]/40 flex items-center gap-1"><ClipboardPaste size={12} /> 用示例</button>
              </div>
              <div className="flex justify-end">
                <button onClick={runAiParse} disabled={!aiText.trim() || aiBusy} className="h-9 px-4 rounded-md bg-gradient-to-r from-[#7A3DFF] to-[#0052D9] text-white text-sm hover:shadow-md disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1.5">
                  {aiBusy ? <><Loader2 size={14} className="animate-spin" /> 识别中…</> : <><Sparkles size={14} /> 识别并预览</>}
                </button>
              </div>
              {aiResult && (
                <div className="rounded-lg border border-slate-200 overflow-hidden">
                  <div className="px-3 py-2 bg-slate-50 border-b border-slate-100 text-[12px] text-slate-600 flex items-center justify-between">
                    <span>识别到 <b className="text-[#7A3DFF]">{aiResult.length}</b> 个字段，确认或修正后填充</span>
                    <span className="text-[11px] text-slate-400">值可编辑 · 不需要的字段可取消勾选</span>
                  </div>
                  <div className="max-h-[340px] overflow-y-auto divide-y divide-slate-100">
                    {aiResult.map((f) => {
                      const options = aiFieldOptions(f);
                      const isLongText = ["background", "impact", "name"].includes(f.key);
                      const selected = !!aiPicked[f.key];
                      return (
                        <div key={f.key} className={`grid grid-cols-[20px_138px_minmax(0,1fr)] items-start gap-2.5 px-3 py-2.5 transition-colors ${selected ? "bg-white hover:bg-slate-50" : "bg-slate-50/70"}`}>
                          <input
                            type="checkbox"
                            checked={selected}
                            onChange={(e) => setAiPicked((p) => ({ ...p, [f.key]: e.target.checked }))}
                            aria-label={`填充${f.label}`}
                            className="mt-2 accent-[#7A3DFF]"
                          />
                          <label htmlFor={`ai-field-${f.key}`} className={`pt-1.5 text-[11px] leading-4 ${selected ? "text-slate-500" : "text-slate-300"}`}>{f.label}</label>
                          {options ? (
                            <select
                              id={`ai-field-${f.key}`}
                              value={f.value}
                              onChange={(e) => updateAiFieldValue(f.key, e.target.value)}
                              className={`h-8 w-full rounded-md border bg-white px-2 text-[12px] outline-none focus:border-[#7A3DFF] ${selected ? "border-slate-200 text-slate-800" : "border-slate-100 text-slate-400"}`}
                            >
                              {!options.includes(f.value) && <option value={f.value}>{f.value}</option>}
                              {options.map((option) => <option key={option} value={option}>{option}</option>)}
                            </select>
                          ) : isLongText ? (
                            <textarea
                              id={`ai-field-${f.key}`}
                              value={f.value}
                              onChange={(e) => updateAiFieldValue(f.key, e.target.value)}
                              rows={f.key === "background" ? 3 : 2}
                              className={`w-full resize-y rounded-md border bg-white px-2 py-1.5 text-[12px] leading-5 outline-none focus:border-[#7A3DFF] ${selected ? "border-slate-200 text-slate-800" : "border-slate-100 text-slate-400"}`}
                            />
                          ) : (
                            <input
                              id={`ai-field-${f.key}`}
                              type="text"
                              value={f.value}
                              onChange={(e) => updateAiFieldValue(f.key, e.target.value)}
                              className={`h-8 w-full rounded-md border bg-white px-2 text-[12px] outline-none focus:border-[#7A3DFF] ${selected ? "border-slate-200 text-slate-800" : "border-slate-100 text-slate-400"}`}
                            />
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
            <div className="px-5 py-3 border-t border-slate-100 flex items-center justify-end gap-2">
              <button onClick={() => setAiOpen(false)} className="h-9 px-4 rounded-md border border-slate-200 text-sm text-slate-600 hover:bg-slate-50">取消</button>
              <button onClick={applyAiFields} disabled={!aiResult || aiResult.length === 0 || !aiResult.some((field) => aiPicked[field.key])} className="h-9 px-4 rounded-md bg-[#0052D9] text-white text-sm hover:bg-[#003FA8] disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1.5"><Check size={14} /> 应用修改并填充</button>
            </div>
          </div>
        </div>
      )}

      {/* 功能2：DIMM 按颗粒拆分为子 Case 弹窗 */}
      {dimmSplitOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-6" onMouseDown={() => setDimmSplitOpen(false)}>
          <div className="w-[720px] max-w-[94vw] max-h-[86vh] bg-white rounded-2xl shadow-2xl border border-slate-200 flex flex-col overflow-hidden" onMouseDown={(e) => e.stopPropagation()}>
            <div className="px-5 py-4 border-b border-slate-100 flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#0052D9] to-[#00A4FF] text-white grid place-items-center"><Network size={16} /></div>
              <div>
                <div className="text-slate-900 font-semibold text-[15px]">拆分 DIMM 为子 Case</div>
                <div className="text-[11.5px] text-slate-400">每个失效 DIMM 拆成一个独立子 Case，与当前 Case 建立父子关系（演示）</div>
              </div>
              <button onClick={() => setDimmSplitOpen(false)} className="ml-auto w-8 h-8 rounded-md hover:bg-slate-100 grid place-items-center text-slate-400"><XIcon size={16} /></button>
            </div>
            <div className="p-5 overflow-y-auto space-y-4">
              <div className="rounded-lg border border-[#0052D9]/30 bg-[#0052D9]/5 px-4 py-3">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#0052D9] text-white">父 Case</span>
                  <span className="text-[14px] font-medium text-slate-900 truncate">{name || "（未命名 Case）"}</span>
                  <span className="text-[11px] text-slate-400 ml-auto font-mono">DRAFT-NEW · DIMM</span>
                </div>
                <div className="text-[11.5px] text-slate-500 mt-1">保留整体背景与影响；拆分后作为 {dimmSplitGroups.length} 个子 Case 的父节点，用于汇总跟踪。</div>
              </div>

              <div className="flex items-center justify-between">
                <div className="text-[12px] text-slate-600">选择要拆分的 DIMM（可只拆部分，不必每个都拆）</div>
                <label className="flex items-center gap-1.5 text-[12px] text-slate-600 cursor-pointer">
                  <input type="checkbox" checked={dimmSplitMerge} onChange={(e) => setDimmSplitMerge(e.target.checked)} className="accent-[#0052D9]" />
                  按失效模式合并同类 DIMM
                </label>
              </div>
              <div className="rounded-lg border border-slate-200 divide-y divide-slate-100">
                {dimmSplittable.map((g) => (
                  <label key={g.id} className="flex items-center gap-3 px-3 py-2 hover:bg-slate-50 cursor-pointer">
                    <input type="checkbox" checked={!!dimmSplitSel[g.id]} onChange={(e) => setDimmSplitSel((p) => ({ ...p, [g.id]: e.target.checked }))} className="accent-[#0052D9]" />
                    <span className="font-mono text-[11px] text-slate-500 w-28 shrink-0 truncate">{getDimmMarkCode(g)}</span>
                    <span className="text-[12px] text-slate-700 flex-1 truncate">{g.failMode} · {g.failCondition}</span>
                    <span className="text-[11px] text-slate-400 font-mono shrink-0">{g.sn}</span>
                  </label>
                ))}
              </div>

              <div>
                <div className="text-[12px] text-slate-600 mb-2">将生成 <b className="text-[#0052D9]">{dimmSplitGroups.length}</b> 个子 Case{dimmSplitMerge ? "（同失效模式已合并）" : ""}</div>
                {dimmSplitGroups.length === 0 ? (
                  <div className="text-[12px] text-slate-400 border border-dashed border-slate-200 rounded-lg px-4 py-4 text-center">未选择 DIMM，请至少勾选一个</div>
                ) : (
                  <div className="relative pl-5">
                    <span className="absolute left-1.5 top-0 bottom-3 w-px bg-slate-200" />
                    <div className="space-y-2.5">
                      {dimmSplitGroups.map((grp, idx) => (
                        <div key={idx} className="relative">
                          <span className="absolute -left-[14px] top-5 w-3 h-px bg-slate-200" />
                          <div className="rounded-lg border border-slate-200 bg-white px-4 py-3">
                            <div className="flex items-center gap-2">
                              <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#00A4FF]/12 text-[#0284c7]">子 Case {idx + 1}</span>
                              <span className="text-[13.5px] font-medium text-slate-900 truncate">{(name || "（未命名 Case）")} · {grp.label}</span>
                              <span className="text-[11px] text-slate-400 ml-auto font-mono">DRAFT-C{String(idx + 1).padStart(2, "0")}</span>
                            </div>
                            <div className="mt-2 flex flex-wrap gap-1.5">
                              {grp.grains.map((g) => (
                                <span key={g.id} className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 font-mono">{getDimmMarkCode(g)} · {g.failCondition || "—"}</span>
                              ))}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
              {dimmSplitDone && (
                <div className="rounded-lg bg-emerald-50 border border-emerald-200 px-4 py-2.5 text-[12.5px] text-emerald-700 flex items-center gap-2">
                  <Check size={14} /> 已生成 {dimmSplitGroups.length} 个子 Case（演示）。父子关系已建立，可在 Case 中心查看层级。
                </div>
              )}
            </div>
            <div className="px-5 py-3 border-t border-slate-100 flex items-center justify-between gap-2">
              <span className="text-[11px] text-slate-400">已选 {dimmSplitGroups.reduce((a, g) => a + g.grains.length, 0)} / {dimmSplittable.length} 颗粒 · 生成 {dimmSplitGroups.length} 子 Case</span>
              <div className="flex gap-2">
                <button onClick={() => setDimmSplitOpen(false)} className="h-9 px-4 rounded-md border border-slate-200 text-sm text-slate-600 hover:bg-slate-50">{dimmSplitDone ? "关闭" : "取消"}</button>
                {!dimmSplitDone && (
                  <button onClick={() => setDimmSplitDone(true)} disabled={dimmSplitGroups.length === 0} className="h-9 px-4 rounded-md bg-gradient-to-r from-[#0052D9] to-[#003FA8] text-white text-sm hover:shadow-md disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1.5"><Network size={14} /> 确认拆分为 {dimmSplitGroups.length} 个子 Case</button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function reusableThoughtBranches(caseItem: CaseItem): TaskNode[] {
  return (caseItem.tasks ?? []).filter((task) => !task.code);
}

function reusableTaskCount(node: TaskNode): number {
  return (node.children ?? []).reduce((count, child) => count + (child.code ? 1 : 0) + reusableTaskCount(child), 0);
}

function cloneReusableThoughtBranch(source: TaskNode): ThoughtGroup {
  const cloneThought = (thought: TaskNode): ThoughtGroup => ({
    id: crypto.randomUUID(),
    thought: thought.title,
    category: thought.category,
    actions: (thought.children ?? [])
      .filter((child) => !!child.code)
      .map((action): ActionCard => ({
        id: crypto.randomUUID(),
        title: action.title,
        expectation: action.expectation,
        urgency: "一般",
        department: currentUser.department,
        assignee: "",
        dueDate: "",
        type: action.type,
        childGroups: (action.children ?? []).filter((child) => !child.code).map(cloneThought),
      })),
  });
  return cloneThought(source);
}

function SimilarityCaseModalShell({ title, onClose, children, width = "w-[720px]" }: {
  title: string;
  onClose: () => void;
  children: React.ReactNode;
  width?: string;
}) {
  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center bg-slate-900/40 p-6 backdrop-blur-sm" onMouseDown={onClose}>
      <div className={`${width} max-h-[88vh] max-w-[94vw] overflow-hidden rounded-xl border border-slate-200 bg-white shadow-2xl`} onMouseDown={(event) => event.stopPropagation()}>
        <div className="flex items-center gap-2.5 border-b border-slate-100 px-5 py-4">
          <span className="grid h-8 w-8 place-items-center rounded-lg bg-[#7A3DFF]/10 text-[#7A3DFF]"><Sparkles size={15} /></span>
          <h3 className="text-[15px] font-semibold text-slate-900">{title}</h3>
          <button type="button" onClick={onClose} className="ml-auto grid h-8 w-8 place-items-center rounded-md text-slate-400 hover:bg-slate-100 hover:text-slate-600"><XIcon size={16} /></button>
        </div>
        {children}
      </div>
    </div>
  );
}

function SimilarityCasePreviewModal({ caseItem, onClose }: { caseItem: CaseItem; onClose: () => void }) {
  const actionTasks = reusableTaskCount({ ...caseItem, children: caseItem.tasks });
  const status = caseItem.status === "已关闭" || caseItem.status === "已结案" || caseItem.status === "已归档" ? "已结案" : "进行中";
  return (
    <SimilarityCaseModalShell title="查看相似 Case" onClose={onClose}>
      <div className="max-h-[calc(88vh-72px)] overflow-y-auto p-5">
        <div className="flex items-center gap-2">
          <span className={`rounded border px-1.5 py-0.5 text-[10px] ${levelColors[caseItem.level]}`}>{caseItem.level}</span>
          <CaseProductPill caseItem={caseItem} compact />
          <span className="rounded border border-slate-200 bg-slate-50 px-1.5 py-0.5 text-[10px] text-slate-600">{status}</span>
          <span className="ml-auto font-mono text-[11px] text-slate-400">{caseItem.code}</span>
        </div>
        <h4 className="mt-3 text-lg font-semibold text-slate-900">{caseItem.name}</h4>
        <div className="mt-4 grid grid-cols-4 gap-3 rounded-lg border border-slate-200 bg-slate-50/60 p-3 text-[11px]">
          <div><span className="block text-slate-400">Owner</span><span className="mt-1 block text-slate-700">{caseItem.owner}</span></div>
          <div><span className="block text-slate-400">Domain</span><span className="mt-1 block text-slate-700">{caseItem.problemDomain || "—"}</span></div>
          <div><span className="block text-slate-400">Fail Mode</span><span className="mt-1 block truncate text-slate-700">{caseItem.failMode || "—"}</span></div>
          <div><span className="block text-slate-400">思路 / 任务</span><span className="mt-1 block text-slate-700">{reusableThoughtBranches(caseItem).length} / {actionTasks}</span></div>
        </div>
        <div className="mt-4 grid grid-cols-2 gap-4">
          <div className="rounded-lg border border-slate-200 p-3">
            <div className="text-[11px] font-medium text-slate-500">问题背景</div>
            <div className="mt-1.5 max-h-[150px] overflow-y-auto whitespace-pre-wrap text-[12px] leading-relaxed text-slate-700">{caseItem.background || caseItem.reason || "—"}</div>
          </div>
          <div className="rounded-lg border border-slate-200 p-3">
            <div className="text-[11px] font-medium text-slate-500">已有结论</div>
            <div className="mt-1.5 max-h-[150px] overflow-y-auto whitespace-pre-wrap text-[12px] leading-relaxed text-slate-700">{caseItem.aiSummary?.conclusion || "暂无结论"}</div>
          </div>
        </div>
        <div className="mt-4 flex justify-end border-t border-slate-100 pt-3">
          <button type="button" onClick={onClose} className="h-8 rounded-md border border-slate-200 px-3 text-sm text-slate-600 hover:bg-slate-50">关闭</button>
        </div>
      </div>
    </SimilarityCaseModalShell>
  );
}

function ReuseAnalysisBranchesModal({ caseItem, reusedBranchIds, selectedBranchIds, onSelectedBranchIdsChange, onClose, onApply }: {
  caseItem: CaseItem;
  reusedBranchIds: string[];
  selectedBranchIds: string[];
  onSelectedBranchIdsChange: (ids: string[]) => void;
  onClose: () => void;
  onApply: () => void;
}) {
  const branches = reusableThoughtBranches(caseItem);
  const toggle = (branchId: string) => onSelectedBranchIdsChange(
    selectedBranchIds.includes(branchId)
      ? selectedBranchIds.filter((id) => id !== branchId)
      : [...selectedBranchIds, branchId],
  );
  return (
    <SimilarityCaseModalShell title="复用分析思路 / 任务" onClose={onClose} width="w-[680px]">
      <div className="max-h-[calc(88vh-72px)] overflow-y-auto p-5">
        <div className="rounded-lg border border-[#7A3DFF]/20 bg-[#7A3DFF]/5 px-3 py-2.5">
          <div className="flex items-center gap-2 text-xs text-slate-700"><span className="font-mono text-[10.5px] text-slate-400">{caseItem.code}</span><span className="font-medium">{caseItem.name}</span></div>
          <p className="mt-1 text-[10.5px] leading-relaxed text-slate-500">仅复制思路、任务名称、预期和类型；负责人、部门分派、日期、状态、结论、附件及 EFA 数据不会复制。新任务部门默认使用 {currentUser.department}。</p>
        </div>
        <div className="mt-3 text-[11px] font-medium text-slate-600">选择要导入的思路分支</div>
        <div className="mt-2 space-y-2">
          {branches.map((branch) => {
            const reused = reusedBranchIds.includes(branch.id);
            const selected = selectedBranchIds.includes(branch.id);
            return (
              <label key={branch.id} className={`flex items-start gap-3 rounded-lg border p-3 ${reused ? "cursor-not-allowed border-slate-100 bg-slate-50/70" : selected ? "cursor-pointer border-[#7A3DFF]/40 bg-[#7A3DFF]/5" : "cursor-pointer border-slate-200 hover:border-[#7A3DFF]/25"}`}>
                <input type="checkbox" disabled={reused} checked={reused || selected} onChange={() => toggle(branch.id)} className="mt-0.5 accent-[#7A3DFF]" />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2"><span className="truncate text-[12.5px] font-medium text-slate-800">{branch.title}</span>{branch.category && <span className="rounded border border-amber-200 bg-amber-50 px-1.5 py-0.5 text-[9px] text-amber-700">{branch.category}</span>}{reused && <span className="ml-auto shrink-0 text-[10px] text-emerald-600">已复用</span>}</div>
                  <div className="mt-1 text-[10.5px] text-slate-400">包含 {reusableTaskCount(branch)} 个执行任务</div>
                </div>
              </label>
            );
          })}
          {branches.length === 0 && <div className="rounded-lg border border-dashed border-slate-200 py-8 text-center text-xs text-slate-400">该 Case 暂无可复用的思路分支</div>}
        </div>
        <div className="mt-4 flex items-center justify-end gap-2 border-t border-slate-100 pt-3">
          <button type="button" onClick={onClose} className="h-8 rounded-md border border-slate-200 px-3 text-sm text-slate-600 hover:bg-slate-50">取消</button>
          <button type="button" disabled={selectedBranchIds.length === 0} onClick={onApply} className="h-8 rounded-md bg-[#0052D9] px-3.5 text-sm text-white hover:bg-[#003FA8] disabled:cursor-not-allowed disabled:opacity-40">导入 {selectedBranchIds.length} 个分支</button>
        </div>
      </div>
    </SimilarityCaseModalShell>
  );
}

// ---------- 功能1：AI 智能识别填充 —— 启发式解析器（演示） ----------interface AiField { key: string; label: string; value: string; }
function parseCaseDescription(text: string): AiField[] {
  const t = text;
  const firstIncl = (arr: string[]) => arr.find((v) => new RegExp(v, "i").test(t)) || "";
  const pick = (re: RegExp) => { const m = t.match(re); return m ? (m[1] ?? m[0]).trim() : ""; };
  const material = /(LPCAMM|LRCAMM|CAMM)/i.test(t)
      ? "CAMM"
      : /(RDIMM|UDIMM|DIMM)/i.test(t)
        ? "DIMM"
        : /(wafer|晶圆)/i.test(t)
          ? "Wafer"
          : /(lot\s*\/?\s*ic|\bIC\b|lot|颗粒|裸片|芯片)/i.test(t)
            ? "IC"
            : "";
  const materialSubtype = firstIncl(["LPCAMM", "LRCAMM", "RDIMM", "UDIMM"]);
  const product = firstIncl(["DMJFC", "PAROG", "RCPQC", "CCNPM", "GTROC"]);
  const density = firstIncl(["8Gb", "16Gb", "24Gb", "32Gb"]);
  const failStage = firstIncl(["CP1", "CP2", "FT", "SLT", "FAB"]);
  const ioType = ["x4", "x8", "x16", "x32"].find((v) => new RegExp(`\\b${v}\\b`, "i").test(t)) || "";
  const failPackage = firstIncl(["FBGA", "WLCSP", "BGA", "QFP"]);
  const failPlatform = firstIncl(["X86", "ARM"]);
  const customer = pick(/客户[:：]?\s*([^\s，。,；;]+)/);
  const failRatio = pick(/(\d+(?:\.\d+)?\s*%)/);
  const ppm = pick(/(\d+)\s*ppm/i);
  const level = pick(/\b(L[1-5])\b/);
  const urgency = firstIncl(["非常紧急", "不紧急", "紧急", "一般"]);
  const failMode = firstIncl(["漏电", "开路", "短路", "停机", "保持力", "时序", "漂移", "翻转", "良率", "yield", "超规"]);
  const name = (t.split(/[\n。]/).map((s) => s.trim()).filter(Boolean)[0] || "").slice(0, 40);
  const impact = (t.split(/[\n。]/).map((s) => s.trim()).find((s) => /影响|退货|停机|交付|损失|风险/.test(s)) || "");
  const background = t.trim();
  const raw: [string, string, string][] = [
    ["name", "Case 名称", name],
    ["level", "层级", level],
    ["urgency", "紧急程度", urgency],
    ["product", "产品编码", product],
    ["material", "案件物料", material],
    ["materialSubtype", "物料二级", materialSubtype],
    ["density", "Density", density],
    ["failStage", "Fail Stage", failStage],
    ["ioType", "IO Type", ioType],
    ["failPackage", "Fail Package", failPackage],
    ["failPlatform", "Fail Platform", failPlatform],
    ["failRatio", "Fail Ratio", failRatio],
    ["customer", "Customer", customer],
    ["failMode", "失效模式", failMode],
    ["ppm", "PPM", ppm],
    ["impact", "影响", impact],
    ["background", "背景.事由", background],
  ];
  return raw.filter(([, , v]) => v && v.trim()).map(([key, label, value]) => ({ key, label, value }));
}

function KV({ k, v }: { k: string; v: string }) {
  return (
    <div className="min-w-0">
      <span className="text-slate-400">{k}</span>
      <div className={`font-mono truncate ${v === "—" ? "text-slate-300" : "text-slate-700"}`}>{v}</div>
    </div>
  );
}

function IcChipIcon({ active = false }: { active?: boolean }) {
  const body = active ? "#0052D9" : "#CBD5E1";
  const pin = active ? "#00A4FF" : "#94A3B8";
  return (
    <svg viewBox="0 0 40 40" className="w-9 h-9 shrink-0">
      <g fill={pin}>
        <rect x="3" y="13" width="4" height="2.4" rx="1" />
        <rect x="3" y="18.8" width="4" height="2.4" rx="1" />
        <rect x="3" y="24.6" width="4" height="2.4" rx="1" />
        <rect x="33" y="13" width="4" height="2.4" rx="1" />
        <rect x="33" y="18.8" width="4" height="2.4" rx="1" />
        <rect x="33" y="24.6" width="4" height="2.4" rx="1" />
        <rect x="13" y="3" width="2.4" height="4" rx="1" />
        <rect x="18.8" y="3" width="2.4" height="4" rx="1" />
        <rect x="24.6" y="3" width="2.4" height="4" rx="1" />
        <rect x="13" y="33" width="2.4" height="4" rx="1" />
        <rect x="18.8" y="33" width="2.4" height="4" rx="1" />
        <rect x="24.6" y="33" width="2.4" height="4" rx="1" />
      </g>
      <rect x="7" y="7" width="26" height="26" rx="6" fill={body} />
      <rect x="14.5" y="14.5" width="11" height="11" rx="2.5" fill="#ffffff" opacity="0.22" />
      <circle cx="11.5" cy="11.5" r="1.7" fill="#ffffff" opacity="0.9" />
    </svg>
  );
}

function DimmModuleIcon({ active = false }: { active?: boolean }) {
  const body = active ? "#0052D9" : "#CBD5E1";
  const pin = active ? "#00A4FF" : "#94A3B8";
  return (
    <svg viewBox="0 0 40 40" className="w-9 h-9 shrink-0">
      <rect x="4" y="11" width="32" height="15" rx="2.5" fill={body} />
      <g fill="#ffffff" opacity="0.85">
        <rect x="8" y="15" width="6" height="7" rx="1" />
        <rect x="17" y="15" width="6" height="7" rx="1" />
        <rect x="26" y="15" width="6" height="7" rx="1" />
      </g>
      <g fill={pin}>
        <rect x="7" y="27" width="2.2" height="5" rx="0.8" />
        <rect x="11.5" y="27" width="2.2" height="5" rx="0.8" />
        <rect x="16" y="27" width="2.2" height="5" rx="0.8" />
        <rect x="20.5" y="27" width="2.2" height="5" rx="0.8" />
        <rect x="25" y="27" width="2.2" height="5" rx="0.8" />
        <rect x="29.5" y="27" width="2.2" height="5" rx="0.8" />
      </g>
    </svg>
  );
}

function Field({
  label,
  required,
  labelExtra,
  children,
}: {
  label: string;
  required?: boolean;
  labelExtra?: React.ReactNode;
  children: any;
}) {
  return (
    <div>
      <div className="text-xs text-slate-600 mb-1.5 tracking-wide flex items-center">
        {label}{" "}
        {required && <span className="text-red-500 ml-0.5">*</span>}
        {labelExtra}
      </div>
      {children}
    </div>
  );
}

function SmallField({
  label,
  value,
  onChange,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
}) {
  return (
    <label className="block text-xs text-slate-500">
      {label}
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="mt-1 w-full h-9 px-2.5 text-sm rounded border border-slate-200 bg-white outline-none focus:border-[#0052D9]"
      />
    </label>
  );
}

export type ActionCard = {
  id: string;
  title: string;
  expectation?: string;
  status?: TaskNode["status"];
  actualDurationHours?: number;
  urgency: Urgency;
  department: string;
  supervisor?: string;
  assignee: string;
  assigneeType?: "person" | "skill";
  skillId?: string;
  skillRun?: TaskNode["skillRun"];
  dueDate: string;
  note?: string;
  voiceNote?: string;
  attachments?: Att[];
  type?: TaskType;
  coverageProgramVersion?: string;
  coverageTestName?: string;
  coverageTestTime?: string;
  coverageActionStage?: string;
  coverageBallType?: string;
  coveragePackage?: string;
  coverageSpeed?: string;
  coverageTester?: string;
  coverageQG?: string;
  coverageReleaseType?: "Reject" | "Monitor";
  coverageTeOwner?: string;
  coveragePeOwner?: string;
  coverageNtc?: "是" | "否";
  efaAnalysis?: import("./data").EfaAnalysisCard;
  childGroups?: ThoughtGroup[];
};

export type ThoughtGroup = {
  id: string;
  thought: string;
  category?: string;
  sourceTaskIds?: string[];
  actions: ActionCard[];
};

function caseTaskTreeToDraftGroups(nodes: TaskNode[] | undefined): ThoughtGroup[] {
  const cloneGroups = (items: TaskNode[] | undefined): ThoughtGroup[] => (items ?? []).map((group) => ({
    id: crypto.randomUUID(),
    thought: group.title,
    category: group.category,
    sourceTaskIds: undefined,
    actions: (group.children ?? []).map((action): ActionCard => ({
      id: crypto.randomUUID(),
      title: action.title,
      expectation: action.expectation,
      status: "待接受",
      urgency: action.urgency,
      department: action.department,
      supervisor: action.supervisor,
      assignee: action.owner === "待指派" ? "" : action.owner,
      assigneeType: action.assigneeType,
      skillId: action.skillId,
      dueDate: action.dueDate ?? "",
      note: action.note,
      voiceNote: action.voiceNote,
      attachments: action.attachments?.map((attachment) => ({ ...attachment })),
      type: action.type || (action.efaAnalysis ? "EFA分析" : undefined),
      coverageProgramVersion: action.coverageProgramVersion,
      coverageTestName: action.coverageTestName,
      coverageTestTime: action.coverageTestTime,
      coverageActionStage: action.coverageActionStage,
      coverageBallType: action.coverageBallType,
      coveragePackage: action.coveragePackage,
      coverageSpeed: action.coverageSpeed,
      coverageTester: action.coverageTester,
      coverageQG: action.coverageQG,
      coverageReleaseType: action.coverageReleaseType,
      coverageTeOwner: action.coverageTeOwner,
      coveragePeOwner: action.coveragePeOwner,
      efaAnalysis: action.efaAnalysis ? structuredClone(action.efaAnalysis) : undefined,
      childGroups: cloneGroups(action.children),
    })),
  }));
  return cloneGroups(nodes);
}

function thoughtGroupsToTasks(groups: ThoughtGroup[]): TaskNode[] {
  let actionIndex = 0;
  const datePart = new Date().toISOString().slice(2, 10).replace(/-/g, "");
  const convertGroups = (items: ThoughtGroup[]): TaskNode[] => items.map((group) => ({
    id: group.id,
    title: group.thought,
    owner: "待指派",
    department: "PTE",
    urgency: "一般",
    progress: 0,
    status: "待接受",
    category: group.category,
    sourceTaskIds: group.sourceTaskIds,
    children: group.actions.map((action) => {
      actionIndex += 1;
      return {
        id: action.id,
        code: `EA-${datePart}${String(actionIndex).padStart(6, "0")}.001`,
        title: action.title,
        expectation: action.expectation,
        owner: action.assignee.trim() || "待指派",
        assigneeType: action.assigneeType,
        skillId: action.skillId,
        skillRun: action.skillRun,
        department: action.department,
        supervisor: action.supervisor,
        urgency: action.urgency,
        progress: action.skillRun?.status === "已采用" ? 100 : 0,
        status: action.skillRun?.status === "已采用" ? "已完成" as const : "待接受" as const,
        dueDate: action.dueDate || undefined,
        note: action.note,
        voiceNote: action.voiceNote,
        attachments: action.attachments,
        type: action.type,
        coverageProgramVersion: action.type === "Coverage上线" ? action.coverageProgramVersion : undefined,
        coverageTestName: action.type === "Coverage上线" ? action.coverageTestName : undefined,
        coverageTestTime: action.type === "Coverage上线" ? action.coverageTestTime : undefined,
        coverageActionStage: action.type === "Coverage上线" ? action.coverageActionStage : undefined,
        coverageBallType: action.type === "Coverage上线" ? action.coverageBallType : undefined,
        coveragePackage: action.type === "Coverage上线" ? action.coveragePackage : undefined,
        coverageSpeed: action.type === "Coverage上线" ? action.coverageSpeed : undefined,
        coverageTester: action.type === "Coverage上线" ? action.coverageTester : undefined,
        coverageQG: action.type === "Coverage上线" ? action.coverageQG : undefined,
        coverageReleaseType: action.type === "Coverage上线" ? action.coverageReleaseType : undefined,
        coverageTeOwner: action.type === "Coverage上线" ? action.coverageTeOwner : undefined,
        coveragePeOwner: action.type === "Coverage上线" ? action.coveragePeOwner : undefined,
        efaAnalysis: action.efaAnalysis,
        children: action.childGroups?.length ? convertGroups(action.childGroups) : undefined,
      };
    }),
  }));
  return convertGroups(groups);
}

// —— CR 标准分析流程模版：预置 6 段（dailyupdate / System / ATE / EFA / Coverage / 结案）——
// 各段并列为独立思路节点（可同步进行），每段下挂一个默认任务（带默认负责部门/负责人）。
export function buildCrTemplateGroups(): ThoughtGroup[] {
  const ts = Date.now();
  return CR_PIPELINE.map((stage) => ({
    id: `cr-grp-${stage.id}-${ts}`,
    thought: `${stage.order}. ${stage.name}`,
    category: "其他",
    actions: [
      {
        id: `cr-act-${stage.id}-${ts}`,
        title: `${stage.name} · 分析`,
        urgency: "一般",
        department: stage.dept,
        assignee: crStageDefaultOwner(stage.dept),
        dueDate: "",
        note: "",
      },
    ],
  }));
}

export function buildTableWbsGroups(): ThoughtGroup[] {
  const ts = Date.now();
  const task = (index: number, title: string, department: string, type?: TaskType): ActionCard => ({
    id: `wbs-act-${index}-${ts}`,
    title,
    expectation: "",
    urgency: "一般",
    department,
    assignee: "",
    dueDate: "",
    note: "",
    type,
  });
  return [
    {
      id: `wbs-group-collect-${ts}`,
      thought: "1. 信息收集与问题定义",
      category: "Testing",
      actions: [
        task(1, "收集失效样品与测试数据", "PTE"),
        task(2, "确认影响范围与失效基线", "QA"),
      ],
    },
    {
      id: `wbs-group-analysis-${ts}`,
      thought: "2. 根因分析与定位",
      category: "Testing",
      actions: [
        task(3, "执行 FSA / MAP 失效特征分析", "EFA", "FSA分析"),
        task(4, "评估测试程式与 Coverage Pattern", "PTE", "Coverage上线"),
      ],
    },
    {
      id: `wbs-group-verify-${ts}`,
      thought: "3. 改善方案与验证",
      category: "Process",
      actions: [
        task(5, "制定改善方案与验证计划", "PTE"),
        task(6, "执行验证并输出结论", "PTE"),
      ],
    },
    {
      id: `wbs-group-close-${ts}`,
      thought: "4. 结案与经验沉淀",
      category: "System",
      actions: [task(7, "汇总结论、风险与解题路径", "PM")],
    },
  ];
}