import {
  ArrowLeft,
  Sparkles,
  MonitorPlay,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  Pin,
  ArrowUpCircle,
  Download,
  Share2,
  FileSpreadsheet,
  Network,
  Database,
  Link as LinkIcon,
  Bookmark,
  MessageSquare,
  ShieldCheck,
  Lock,
  GitBranch,
  Edit2,
  CheckCircle2,
  X,
  Check,
  XCircle,
  Ban,
  ChevronLeft,
  ChevronRight,
  Clock,
  ListTree,
  CircleDot,
  Crown,
  FlaskConical,
  ExternalLink,
  Cpu,
  ChartGantt,
  ClipboardList,
} from "lucide-react";
import { useState, useEffect, useMemo, useRef } from "react";
import { mockCases, levelColors, urgencyColors, statusColors, statusDot, TaskNode, currentUser, Participant, flattenTasks, efaTicketStatusColors, CR_PIPELINE, crStageDefById, CrStageState, EfaAnalysisCard } from "./data";
import { CaseStatusBadge, caseDisplayStatus } from "./CaseStatusBadge";
import { CaseProductPill } from "./CaseProductPill";
import { CaseMarkCodePill } from "./CaseMarkCodePill";
import type { ActionCard, CreatePrefill, ThoughtGroup } from "./CreateCase";
import { MindMapFlow, PatternFanoutSelection } from "./MindMapFlow";
import { ProgressRing } from "./ProgressRing";
import { DemoMode } from "./DemoMode";
import { TaskTimeline } from "./TaskTimeline";
import { AddTaskPayload } from "./AddTaskModal";
import { CommentDrawer } from "./CommentDrawer";
import { useSubscriptions } from "./subscriptions";
import { useClosures, recoverCase, saveCaseWorkspace } from "./closures";
import { RecoveryActions, RecoveryBadge, RecoveryHistoryEntry } from "./RecoveryControls";
import { activeRecovery, type RecoveryEntry } from "./recordRecovery";
import { CaseRecoveryPanel } from "./CaseRecoveryPanel";
import { CaseScore } from "./CaseScore";
import { CaseFeishuGroup } from "./CaseFeishuGroup";
import { TaskAttachmentList } from "./TaskAttachmentList";
import { RootCauseFanoutModal } from "./RootCauseFanoutModal";
import { CaseRelations } from "./CaseRelations";
import { AttachmentInput } from "./AttachmentInput";
import { createFanoutCasesFromClose } from "./domainStore";
import { productById } from "./data";
import { submitEfaTicket, ticketOfTask, useEfaTickets } from "./efaTickets";
import { loadCaseTaskTree, saveCaseTaskTree } from "./caseTaskTrees";
import { CaseGanttView } from "./CaseGanttView";
import { CreateCaseWbsTable } from "./CreateCaseWbsTable";
import { ClosureSummaryModal } from "./ClosureSummaryModal";
import { CloseCaseModal } from "./CloseCaseModal";
import { standaloneTaskById, standaloneTaskDisplayStatus, useStandaloneTasks } from "./standaloneTasks";

// R09/R10：把 Case 的 sub（每个顶层思路/怀疑方向）生成 WS「分析过程」结构
// 一级标题「分析过程」下，每个 sub 用二级标题，格式：标题@OWNER@DUEDAY
// 某 Fanout 验证 Case 的进度（任务平均完成度）
function fanoutCaseProgress(fc: any): number {
  const actions = flattenTasks(fc?.tasks || []).map((x) => x.task).filter((t) => t.code);
  const base = actions.length ? actions : (fc?.tasks || []);
  return Math.round(base.reduce((s: number, t: any) => s + (t.progress || 0), 0) / Math.max(base.length, 1));
}
function buildAnalysisProcess(caseItem: any): string {
  const lines: string[] = ["# 分析过程", ""];
  (caseItem.tasks || []).forEach((thought: any) => {
    const flat = flattenTasks([thought]).map((x) => x.task);
    const actions = flat.filter((t) => t.code);
    const owner = actions.find((a) => a.owner && a.owner !== "待指派")?.owner || thought.owner || "待指派";
    const dues = actions.map((a) => a.dueDate).filter(Boolean).sort();
    const dueDay = dues.length ? dues[dues.length - 1] : "—";
    lines.push(`## ${thought.title}@${owner}@${dueDay}`);
    actions.forEach((a) => {
      if (a.conclusion) lines.push(`- ${a.title}：${a.conclusion}${a.validity ? `（结论${a.validity}）` : ""}`);
      else lines.push(`- ${a.title}（${a.status}）`);
    });
    lines.push("");
  });
  return lines.join("\n");
}

function taskTreeToThoughtGroups(nodes: TaskNode[] | undefined): ThoughtGroup[] {
  return (nodes ?? []).map((group) => ({
    id: group.id,
    thought: group.title,
    category: group.category,
    sourceTaskIds: group.sourceTaskIds,
    actions: (group.children ?? []).map((action): ActionCard => ({
      id: action.id,
      title: action.title,
      expectation: action.expectation,
      status: action.status,
      urgency: action.urgency,
      department: action.department,
      supervisor: action.supervisor,
      assignee: action.owner === "待指派" ? "" : action.owner,
      assigneeType: action.assigneeType,
      skillId: action.skillId,
      skillRun: action.skillRun,
      dueDate: action.dueDate ?? "",
      note: action.note,
      voiceNote: action.voiceNote,
      attachments: action.attachments,
      type: action.type,
      coverageProgramVersion: action.coverageProgramVersion,
      coverageTestName: action.coverageTestName,
      coverageTestTime: action.coverageTestTime,
      coverageActionStage: action.coverageActionStage,
      coverageBallType: action.coverageBallType,
      coveragePackage: action.coveragePackage,
      coverageSpeed: action.coverageSpeed,
      coverageTester: action.coverageTester,
      coverageQG: action.coverageQG,
      coverageTeOwner: action.coverageTeOwner,
      coveragePeOwner: action.coveragePeOwner,
      coverageNtc: action.coverageNtc,
      efaAnalysis: action.efaAnalysis,
      childGroups: taskTreeToThoughtGroups(action.children),
    })),
  }));
}

function thoughtGroupsToTaskTree(groups: ThoughtGroup[], previous: TaskNode[]): TaskNode[] {
  const existingById = new Map(flattenTasks(previous).map(({ task }) => [task.id, task]));
  let newTaskIndex = 0;
  const datePart = new Date().toISOString().slice(2, 10).replace(/-/g, "");

  const convertGroups = (items: ThoughtGroup[]): TaskNode[] => items.map((group) => {
    const existingGroup = existingById.get(group.id);
    return {
      ...existingGroup,
      id: group.id,
      title: group.thought,
      owner: existingGroup?.owner ?? "待指派",
      department: existingGroup?.department ?? "PTE",
      urgency: existingGroup?.urgency ?? "一般",
      progress: existingGroup?.progress ?? 0,
      status: existingGroup?.status ?? "待接受",
      category: group.category,
      sourceTaskIds: group.sourceTaskIds,
      children: group.actions.map((action) => {
        const existingAction = existingById.get(action.id);
        newTaskIndex += 1;
        return {
          ...existingAction,
          id: action.id,
          code: existingAction?.code ?? `EA-${datePart}${String(Date.now() + newTaskIndex).slice(-6)}.001`,
          title: action.title,
          expectation: action.expectation,
          owner: action.assignee.trim() || "待指派",
          assigneeType: action.assigneeType,
          skillId: action.skillId,
          skillRun: action.skillRun,
          department: action.department,
          supervisor: action.supervisor,
          urgency: action.urgency,
          progress: existingAction?.progress ?? 0,
          status: existingAction?.status ?? "待接受",
          dueDate: action.dueDate || undefined,
          note: action.note,
          voiceNote: action.voiceNote,
          attachments: action.attachments,
          type: action.type,
          coverageProgramVersion: action.coverageProgramVersion,
          coverageTestName: action.coverageTestName,
          coverageTestTime: action.coverageTestTime,
          coverageActionStage: action.coverageActionStage,
          coverageBallType: action.coverageBallType,
          coveragePackage: action.coveragePackage,
          coverageSpeed: action.coverageSpeed,
          coverageTester: action.coverageTester,
          coverageQG: action.coverageQG,
          coverageTeOwner: action.coverageTeOwner,
          coveragePeOwner: action.coveragePeOwner,
          coverageNtc: action.coverageNtc,
          efaAnalysis: action.efaAnalysis,
          children: action.childGroups?.length ? convertGroups(action.childGroups) : undefined,
        };
      }),
    };
  });

  return convertGroups(groups);
}

interface Props {
  caseId: string;
  onBack: () => void;
  onOpenTask: (caseId: string, taskId: string) => void;
  onOpenStandaloneTask?: (taskId: string) => void;
  onOpenCase?: (id: string) => void;
  onUpgrade?: (caseId: string) => void;
  onEdit?: (caseId: string) => void;
  onOpenIssue?: (id: string) => void;
  onCreateRelated?: (prefill: CreatePrefill) => void;
}

type Tab = "mindmap" | "data" | "gantt" | "related";

const tabDefs: { key: Tab; label: string; icon: any }[] = [
  { key: "mindmap", label: "思维导图", icon: Network },
  { key: "data", label: "任务视图", icon: ListTree },
  { key: "gantt", label: "甘特图", icon: ChartGantt },
];

function CrPipelineProgress({ pipeline }: { pipeline: CrStageState[] }) {
  const stages = CR_PIPELINE.map((def) => pipeline.find((stage) => stage.id === def.id) ?? {
    id: def.id,
    owner: "待指派",
    status: "未开始" as const,
  });
  const completed = stages.filter((stage) => stage.status === "已完成").length;
  const activeIndex = stages.findIndex((stage) => stage.status === "进行中");

  return (
    <div className="mt-4 rounded-lg border border-slate-200 bg-white px-5 py-4">
      <div className="flex items-center gap-2 mb-4">
        <ListTree size={15} className="text-[#0052D9]" />
        <span className="text-sm font-medium text-slate-800">分析流程总览</span>
        <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#0052D9]/8 text-[#0052D9] border border-[#0052D9]/15">六段流程</span>
        <span className="ml-auto text-xs text-slate-400">已完成 {completed} / {stages.length}</span>
      </div>
      <div className="flex items-start">
        {stages.map((stage, index) => {
          const def = crStageDefById(stage.id);
          const done = stage.status === "已完成";
          const active = stage.status === "进行中" || (activeIndex < 0 && index === completed && completed < stages.length);
          return (
            <div key={stage.id} className="relative flex-1 min-w-0 text-center">
              {index > 0 && <span className={`absolute top-3 right-1/2 w-full h-0.5 ${done || active ? "bg-[#0052D9]" : "bg-slate-200"}`} />}
              <div className={`relative z-10 mx-auto w-6 h-6 rounded-full grid place-items-center border-2 ${
                done ? "bg-[#00B578] border-[#00B578] text-white" : active ? "bg-white border-[#0052D9] text-[#0052D9]" : "bg-white border-slate-200 text-slate-400"
              }`}>
                {done ? <Check size={12} strokeWidth={3} /> : <span className="text-[10px] font-semibold">{def.order}</span>}
              </div>
              <div className={`mt-2 text-[12px] font-medium truncate px-1 ${done ? "text-emerald-700" : active ? "text-[#0052D9]" : "text-slate-500"}`}>{def.short}</div>
              <div className="mt-0.5 text-[10px] text-slate-400 truncate px-1" title={`${def.dept} · ${stage.owner ?? "待指派"}`}>{def.dept} · {stage.owner ?? "待指派"}</div>
              <div className={`mt-1 text-[10px] ${done ? "text-emerald-600" : active ? "text-[#0052D9]" : "text-slate-400"}`}>{done ? "已完成" : active ? "进行中" : "未开始"}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export function CaseDetail({ caseId, onBack, onOpenTask, onOpenStandaloneTask, onOpenCase, onUpgrade, onEdit, onOpenIssue, onCreateRelated }: Props) {
  const c = mockCases.find((x) => x.id === caseId)!;
  useStandaloneTasks();
  const sourceStandaloneTasks = Array.from(new Set([...(c.sourceStandaloneTaskId ? [c.sourceStandaloneTaskId] : []), ...(c.sourceStandaloneTaskIds ?? [])])).flatMap((id) => {
    const task = standaloneTaskById(id);
    return task ? [task] : [];
  });
  const waferLotGroups = (() => {
    const grouped = new Map<string, { waferIds: string[]; wholeLot: boolean }>();
    (c.granules ?? []).forEach((granule) => {
      const waferId = granule.waferId?.trim();
      const lotId = (granule.lotId?.trim() || (waferId?.length === 12 ? waferId.slice(0, 7) : "")).toUpperCase();
      if (!lotId) return;
      if (!grouped.has(lotId)) grouped.set(lotId, { waferIds: [], wholeLot: false });
      const group = grouped.get(lotId)!;
      if (granule.wholeLot) group.wholeLot = true;
      else if (waferId) group.waferIds.push(waferId);
    });
    return [...grouped.entries()].map(([lotId, group]) => ({
      lotId,
      wholeLot: group.wholeLot,
      waferIds: Array.from(new Set(group.waferIds)).sort(),
    }));
  })();
  const [tab, setTab] = useState<Tab>("mindmap");
  const [demoOpen, setDemoOpen] = useState(false);
  const [commentOpen, setCommentOpen] = useState(false);
  const [showMore, setShowMore] = useState(false);
  const [icTreeOpen, setIcTreeOpen] = useState(false);
  const [taskDataOpen, setTaskDataOpen] = useState(false);
  const [focusMine, setFocusMine] = useState(false);
  const [showUrgency, setShowUrgency] = useState(true);
  const [tasks, setTasks] = useState(() => loadCaseTaskTree(c.id, c.tasks));
  const savedTaskSnapshot = useRef(tasks);
  const [taskSaveError, setTaskSaveError] = useState("");
  useEffect(() => {
    try { savedTaskSnapshot.current = saveCaseTaskTree(c.id, tasks, true, savedTaskSnapshot.current); setTaskSaveError(""); }
    catch (reason) { setTaskSaveError(reason instanceof Error ? reason.message : "任务保存失败，请重试。"); }
  }, [c, tasks]);
  const [owner, setOwner] = useState(c.owner);
  const [transferOpen, setTransferOpen] = useState(false);
  const [transferDraft, setTransferDraft] = useState("");
  const subs = useSubscriptions();
  const subscribed = subs.isSubscribed(caseId);
  const closures = useClosures();
  const closure = closures.get(caseId);
  const currentReturn = activeRecovery(closure ?? {});
  const caseEditingAllowed = c.owner === currentUser.name && !closures.isClosed(caseId) && !(closure?.approval && !closure.approval.decision);
  const [rootCauseOpen, setRootCauseOpen] = useState(false);
  const [fanoutCloseOpen, setFanoutCloseOpen] = useState(false);
  const [closureSummaryOpen, setClosureSummaryOpen] = useState(false);
  const [wizardResume, setWizardResume] = useState(false);
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const showToast = (m: string) => { setToastMsg(m); window.setTimeout(() => setToastMsg(null), 3200); };
  const [fanoutDetailOpen, setFanoutDetailOpen] = useState(false);
  // —— V1.0.3：已创建的 DIMM Case 按颗粒拆分 ——
  const [splitOpen, setSplitOpen] = useState(false);
  const [splitDone, setSplitDone] = useState(false);
  const [splitSel, setSplitSel] = useState<Record<string, boolean>>({});
  const [splitMerge, setSplitMerge] = useState(false);
  const [, forceTick] = useState(0);
  const [conclusionDocOpen, setConclusionDocOpen] = useState(false);
  const [caseConclusion, setCaseConclusion] = useState(closure?.workspace?.conclusion ?? closure?.conclusion ?? c.aiSummary.conclusion);
  const [caseProcess, setCaseProcess] = useState(closure?.workspace?.process ?? "");
  const [caseWsAtts, setCaseWsAtts] = useState<{ name: string; kind: "pdf" | "image" | "sheet" | "file"; url?: string }[]>(closure?.workspace?.attachments ?? []);
  const isFanoutDerived = !!c.fanoutSourceCaseId || c.source === "fanout验证";

  // 参与人 = 显式协作者（participants）∪ 任务负责人（自动成为协作者），排除 Owner 与待指派
  const mergedParticipants = useMemo(() => {
    const map = new Map<string, { name: string; department: string }>();
    (c.participants ?? []).forEach((p) => map.set(p.name, { name: p.name, department: p.department }));
    flattenTasks(c.tasks).forEach(({ task }) => {
      const nm = task.owner;
      if (!nm || nm === "待指派" || nm === "待分派" || nm === owner) return;
      if (!map.has(nm)) map.set(nm, { name: nm, department: task.department || "—" });
    });
    return [...map.values()];
  }, [c, tasks, owner]);

  // R03 · Case 流转日志（Owner / 时间 / 层级 / 状态等变更）
  type Activity = { id: string; type: "owner" | "due" | "level" | "status" | "create" | "recovery"; by: string; at: string; summary: string; from?: string; to?: string; recovery?: RecoveryEntry };
  const [activityLog, setActivityLog] = useState<Activity[]>([
    { id: "av3", type: "level", by: "张伟", at: "2026-04-21 18:30", summary: "Case 层级升级", from: "L3", to: "L1" },
    { id: "av2", type: "due", by: "张伟", at: "2026-04-21 10:12", summary: "调整截止时间", from: "2026-04-22", to: "2026-04-24" },
    { id: "av1", type: "create", by: "系统", at: "2026-04-20 14:00", summary: "SPC monitor 自动创建 Case 并指派 Owner", to: c.owner },
  ]);
  const pushActivity = (e: Omit<Activity, "id" | "at">) =>
    setActivityLog((prev) => [{ id: `av${Date.now()}`, at: new Date().toISOString().slice(0, 16).replace("T", " "), ...e }, ...prev]);
  const caseActivity: Activity[] = [...activityLog, ...(closure?.recovery ?? []).map((entry): Activity => ({
    id: `recovery-${entry.id}`, type: "recovery", by: entry.by, at: entry.at,
    summary: entry.kind === "return" ? "退回整改" : entry.kind === "reopen" ? "重新处理" : "补充记录",
    recovery: entry,
  }))].sort((left, right) => (Date.parse(right.at) || 0) - (Date.parse(left.at) || 0));

  // 按颗粒拆分：在内存中为每个颗粒生成子 Case，并建立父子关系（演示）
  const nowStr = () => new Date().toISOString().slice(0, 16).replace("T", " ");
  const splitGroups: { label: string; granules: any[] }[] = (() => {
    const gs = (c.granules || []).filter((g: any) => splitSel[g.markCode]);
    if (!splitMerge) return gs.map((g: any) => ({ label: g.failMode || "颗粒", granules: [g] }));
    const m = new Map<string, any[]>();
    gs.forEach((g: any) => {
      const k = g.failMode || "未分类";
      if (!m.has(k)) m.set(k, []);
      m.get(k)!.push(g);
    });
    return [...m.entries()].map(([label, arr]) => ({ label, granules: arr }));
  })();
  const doSplitDimm = () => {
    const baseName = c.name.replace(/（.*?）\s*$/, "");
    const children = splitGroups.map((grp, i) => {
      const id = `${c.id}-c${i + 1}`;
      const existing = mockCases.find((x) => x.id === id);
      const single = grp.granules.length === 1;
      if (existing) return existing;
      const child: any = {
        ...c,
        id,
        code: `${c.code}.C${String(i + 1).padStart(2, "0")}`,
        name: `${baseName} · ${grp.label}${single ? `（${grp.granules[0].markCode}）` : `（${grp.granules.length} 颗粒）`}`,
        parentCaseId: c.id,
        childCaseIds: undefined,
        splitGranule: single
          ? { markCode: grp.granules[0].markCode, sn: grp.granules[0].sn, failMode: grp.granules[0].failMode, failCondition: grp.granules[0].failCondition }
          : { markCode: `${grp.granules.length} 颗粒`, sn: "-", failMode: grp.label, failCondition: "-" },
        granules: grp.granules,
        participants: [],
        tasks: [
          { id: `${id}-th`, title: `${grp.label} 失效定位`, owner: "待指派", department: c.departments?.[0] || "PTE", urgency: c.urgency, progress: 0, status: "待接受" },
        ],
        timeline: [{ time: nowStr(), user: currentUser.name, content: `由母案 ${c.code} 拆分生成（${grp.granules.map((x: any) => x.markCode).join("\u3001")}）。` }],
        updatedAt: nowStr(),
      };
      mockCases.push(child);
      return child;
    });
    (c as any).childCaseIds = children.map((ch) => ch.id);
    pushActivity({ type: "status", by: currentUser.name, summary: `按颗粒拆分为 ${children.length} 个子 Case` });
    setSplitDone(true);
    forceTick((t) => t + 1);
  };

  // —— V1.0.4：点击 DIMM 的某个 Chip ID → 跳转新建 Case 并预填（共享背景、互相关联），由用户确认后提交 ——
  const spawnCaseFromChip = (chipId: string, meta: { sn?: string; icId?: string; dieId?: string }) => {
    const dueDate = new Date(Date.now() + 7 * 864e5).toISOString().slice(0, 10);
    onCreateRelated?.({
      parentCaseId: c.id,
      name: `${c.name.replace(/（.*?）\s*$/, "")} · ${chipId}`,
      reason: c.reason,
      background: c.background,
      impact: c.impact,
      problemDomain: c.problemDomain,
      problemType: c.problemType,
      level: c.level,
      urgency: c.urgency,
      dueDate,
      productIds: c.productId ? [c.productId] : (c.product ? [c.product] : undefined),
      material: "Die/IC",
      density: c.density,
      ioType: c.ioType,
      failStage: c.failStage,
      customer: c.customer,
      failPlatform: c.failPlatform,
      failMode: c.failMode,
      chipId,
      failCondition: [meta.icId, meta.dieId].filter(Boolean).join(" / "),
      relatedCaseIds: [c.id],
    });
  };

  const insertTask = (parentId: string | null, t: TaskNode) => {
    if (parentId === null) {
      setTasks([...tasks, t]);
      return;
    }
    const insert = (nodes: TaskNode[]): TaskNode[] =>
      nodes.map((n) =>
        n.id === parentId
          ? { ...n, children: [...(n.children ?? []), t] }
          : { ...n, children: n.children ? insert(n.children) : n.children }
      );
    setTasks(insert(tasks));
  };

  const submitTask = (parentId: string | null, p: AddTaskPayload): string => {
    const now = new Date();
    const dateStr = now.toISOString().slice(2, 10).replace(/-/g, '').slice(0, 6);
    const taskCounter = String(Date.now()).slice(-6);
    const code = p.kind === "执行任务" ? `EA-${dateStr}${taskCounter}.001` : undefined;
    const newId = `t${Date.now()}`;

    insertTask(parentId, {
      id: newId,
      code,
      title: p.title,
      sourceTaskIds: p.sourceTaskIds,
      owner: p.assignee.trim() || "待指派",
      assigneeType: p.assigneeType,
      skillId: p.skillId,
      skillRun: p.skillRun,
      department: p.department,
      urgency: p.urgency,
      progress: 0,
      status: "待接受",
      dueDate: p.dueDate || undefined,
      type: p.type,
      coverageSpeed: p.coverageSpeed,
      coverageTester: p.coverageTester,
      coverageQG: p.coverageQG,
      coverageBallType: p.coverageBallType,
      coverageTeOwner: p.coverageTeOwner,
      coveragePeOwner: p.coveragePeOwner,
      category: p.category,
      voiceNote: p.voiceNote,
      attachments: p.attachments,
      note: p.note,
      supervisor: p.supervisor,
      site: p.site,
    });
    if (p.efaRequest) {
      submitEfaTicket({
        caseId,
        taskId: newId,
        taskTitle: p.title,
        submittedBy: currentUser.name,
        ...p.efaRequest,
      });
    }
    return newId;
  };

  const editTask = (id: string, p: AddTaskPayload) => {
    const apply = (nodes: TaskNode[]): TaskNode[] =>
      nodes.map((n) =>
        n.id === id
          ? {
              ...n,
              title: p.title,
              expectation: p.expectation ?? n.expectation,
              owner: p.assignee.trim() || n.owner,
              assigneeType: p.assigneeType,
              skillId: p.skillId,
              skillRun: p.skillRun,
              department: p.department || n.department,
              urgency: p.urgency,
              dueDate: p.dueDate || n.dueDate,
              type: p.kind === "执行任务" ? p.type : n.type,
              coverageProgramVersion: p.type === "Coverage上线" ? p.coverageProgramVersion : undefined,
              coverageTestName: p.type === "Coverage上线" ? p.coverageTestName : undefined,
              coverageTestTime: p.type === "Coverage上线" ? p.coverageTestTime : undefined,
              coverageActionStage: p.type === "Coverage上线" ? p.coverageActionStage : undefined,
              coverageBallType: p.type === "Coverage上线" ? p.coverageBallType : undefined,
              coveragePackage: p.type === "Coverage上线" ? p.coveragePackage : undefined,
              coverageSpeed: p.type === "Coverage上线" ? p.coverageSpeed : undefined,
              coverageTester: p.type === "Coverage上线" ? p.coverageTester : undefined,
              coverageQG: p.type === "Coverage上线" ? p.coverageQG : undefined,
              coverageReleaseType: p.type === "Coverage上线" ? p.coverageReleaseType : undefined,
              coverageTeOwner: p.type === "Coverage上线" ? p.coverageTeOwner : undefined,
              coveragePeOwner: p.type === "Coverage上线" ? p.coveragePeOwner : undefined,
              coverageNtc: p.type === "Coverage上线" ? p.coverageNtc : undefined,
              efaAnalysis: p.efaAnalysis === undefined ? n.efaAnalysis : p.efaAnalysis ?? undefined,
              category: p.category ?? n.category,
              sourceTaskIds: p.sourceTaskIds ?? n.sourceTaskIds,
              voiceNote: p.voiceNote ?? n.voiceNote,
              attachments: p.attachments ?? n.attachments,
              note: p.note ?? n.note,
              supervisor: p.supervisor ?? n.supervisor,
              site: p.site ?? n.site,
            }
          : { ...n, children: n.children ? apply(n.children) : n.children }
      );
    setTasks(apply(tasks));
    if (p.efaRequest && !ticketOfTask(caseId, id)) {
      submitEfaTicket({
        caseId,
        taskId: id,
        taskTitle: p.title,
        submittedBy: currentUser.name,
        ...p.efaRequest,
      });
    }
  };

  const completeCoverage = (taskId: string) => {
    const source = flattenTasks(tasks).find((entry) => entry.task.id === taskId)?.task;
    if (!source || source.type !== "Coverage上线" || source.patternFanoutTaskIds?.length) return false;
    if (!source.coverageSpeed || !source.coverageTester || !source.coverageQG || !source.coverageBallType || !source.coverageTeOwner || !source.coveragePeOwner) {
      showToast("请先补齐 Speed、Tester、QG、Ball type 及 TE/PE 负责人");
      return false;
    }
    const patch = (nodes: TaskNode[]): TaskNode[] => nodes.map((node) => node.id === taskId
      ? {
          ...node,
          status: "已完成",
          progress: 100,
          coverageSeedTaskIds: undefined,
        }
      : { ...node, children: node.children ? patch(node.children) : node.children });
    setTasks((current) => patch(current));
    showToast("Coverage 上线已完成 · 请设置 Pattern Fanout 参数");
    return true;
  };

  const createPatternFanout = (sourceTaskId: string, selection: PatternFanoutSelection) => {
    const sourceTask = flattenTasks(tasks).find((entry) => entry.task.id === sourceTaskId)?.task;
    if (!sourceTask || sourceTask.type !== "Coverage上线" || sourceTask.patternFanoutTaskIds?.length) return;
    const teOwner = sourceTask.coverageTeOwner || "待指派";
    const peOwner = sourceTask.coveragePeOwner || "待指派";
    const generated: TaskNode[] = [];
    const stamp = Date.now();
    for (const speed of selection.speeds) for (const tester of selection.testers) for (const ballType of selection.ballTypes) for (const qg of selection.qgs) for (const role of ["TE", "PE"] as const) {
      generated.push({ id: `pattern-${generated.length}-${stamp}`, code: `${c.code}.PF${String(generated.length + 1).padStart(3, "0")}`, title: `Coverage 上线 · ${speed} / ${tester} / ${ballType} / ${qg} · ${role}`, owner: role === "TE" ? teOwner : peOwner, department: role, urgency: "一般", progress: 0, status: "待接受", type: "Coverage上线", coverageSpeed: speed, coverageTester: tester, coverageBallType: ballType, coverageQG: qg, coverageTeOwner: teOwner, coveragePeOwner: peOwner, patternRole: role, patternParams: { speed, tester, ballType, qg }, generatedFromTaskId: sourceTaskId });
    }
    const combinations = selection.speeds.length * selection.testers.length * selection.ballTypes.length * selection.qgs.length;
    const fanoutThought: TaskNode = { id: `pattern-fanout-${stamp}`, title: `Pattern Fanout · ${combinations} 组 Coverage`, owner: "待指派", department: "PTE", urgency: "一般", progress: 0, status: "待接受", patternFanoutTaskIds: generated.map((task) => task.id), children: generated };
    const patchSource = (nodes: TaskNode[]): TaskNode[] => nodes.map((node) => node.id === sourceTaskId
      ? {
          ...node,
          status: "已完成",
          progress: 100,
          coverageSeedTaskIds: undefined,
          patternFanoutTaskIds: generated.map((task) => task.id),
          children: [...(node.children ?? []).filter((child) => !child.id.startsWith("pattern-seed-thought-")), fanoutThought],
        }
      : { ...node, children: node.children ? patchSource(node.children) : node.children });
    setTasks((current) => patchSource(current));
    showToast(`Pattern Fanout 已创建 · ${combinations} 组 / ${generated.length} 个 Coverage 上线任务`);
  };


  const saveEfaAnalysis = (id: string, value: EfaAnalysisCard) => {
    const apply = (nodes: TaskNode[]): TaskNode[] =>
      nodes.map((n) =>
        n.id === id
          ? { ...n, efaAnalysis: value }
          : { ...n, children: n.children ? apply(n.children) : n.children }
      );
    setTasks((prev) => apply(prev));
  };

  const deleteTask = (id: string) => {
    const remove = (nodes: any[]): any[] =>
      nodes
        .filter((n) => n.id !== id)
        .map((n) => ({ ...n, children: n.children ? remove(n.children) : n.children }));
    setTasks(remove(tasks));
  };

  const findInList = (nodes: TaskNode[], id: string): TaskNode | undefined => {
    for (const n of nodes) {
      if (n.id === id) return n;
      if (n.children) {
        const r = findInList(n.children, id);
        if (r) return r;
      }
    }
    return undefined;
  };

  // 复制/粘贴节点子树（R29）：深拷贝并生成新 id / 任务编码
  const cloneTask = (sourceId: string, targetParentId: string | null) => {
    const src = findInList(tasks, sourceId);
    if (!src) return;
    let counter = 0;
    const stamp = String(Date.now());
    const dateStr = new Date().toISOString().slice(2, 10).replace(/-/g, "").slice(0, 6);
    const clone = (n: TaskNode, isRoot: boolean): TaskNode => {
      counter += 1;
      const isAction = !!n.code;
      return {
        ...n,
        id: `t${stamp}_${counter}`,
        code: isAction ? `EA-${dateStr}${stamp.slice(-6)}.${String(counter).padStart(3, "0")}` : undefined,
        title: isRoot ? `${n.title}（副本）` : n.title,
        likes: 0,
        likedByMe: false,
        comments: [],
        children: n.children ? n.children.map((c) => clone(c, false)) : undefined,
      };
    };
    insertTask(targetParentId === "case" ? null : targetParentId, clone(src, true));
  };
  const executionTasks = flattenTasks(tasks).map(({ task }) => task).filter((task) => Boolean(task.code));
  const taskStatusCounts = (["待接受", "进行中", "已完成", "已拒绝", "已中止"] as const)
    .map((status) => ({ status, count: executionTasks.filter((task) => task.status === status).length }))
    .filter((item) => item.count > 0);
  const progress = Math.round(
    executionTasks.reduce((sum, task) => sum + task.progress, 0) / Math.max(executionTasks.length, 1)
  );

  // Fanout 进度：由本 Case 结案 Fanout 派生的验证 Case（fanoutSourceCaseId === c.id）
  const fanoutCases = mockCases.filter((x) => x.fanoutSourceCaseId === c.id);
  const fanoutProgs = fanoutCases.map((fc) => fanoutCaseProgress(fc));
  const fanoutAvg = fanoutProgs.length ? Math.round(fanoutProgs.reduce((a, b) => a + b, 0) / fanoutProgs.length) : 0;
  const fanoutDone = fanoutProgs.filter((p) => p >= 100).length;

  return (
    <div className="p-6">
      {taskSaveError && <div role="alert" className="mb-3 flex items-center gap-3 rounded-lg bg-red-50 p-3 text-xs text-red-600"><span>{taskSaveError} 当前更改尚未保存。</span><button type="button" onClick={() => setTasks((previous) => [...previous])} className="ml-auto underline">重试保存</button></div>}
      <button
        onClick={onBack}
        className="text-sm text-slate-500 hover:text-[#0052D9] flex items-center gap-1 mb-4"
      >
        <ArrowLeft size={14} /> 返回
      </button>

      {/* —— DIMM 拆分：父子 Case 关系 —— */}
      {(() => {
        const parent = c.parentCaseId ? mockCases.find((x) => x.id === c.parentCaseId) : null;
        const children = (c.childCaseIds || [])
          .map((id) => mockCases.find((x) => x.id === id))
          .filter(Boolean) as typeof mockCases;
        if (!parent && children.length === 0) return null;
        return (
          <div className="mb-4 rounded-lg border border-slate-200 bg-white px-4 py-2.5 space-y-2.5">
            {parent && (
              <div className="flex items-center gap-2.5">
                <span className="w-7 h-7 rounded-lg bg-[#00A4FF]/12 text-[#0284c7] grid place-items-center shrink-0"><ArrowUpCircle size={15} /></span>
                <div className="min-w-0 flex-1">
                  <div className="text-[11px] text-slate-500">本 Case 由 DIMM 母案按颗粒拆分而来{c.splitGranule ? ` · 对应颗粒 ${c.splitGranule.markCode}（${c.splitGranule.failMode}）` : ""}</div>
                  <button onClick={() => onOpenCase?.(parent.id)} className="mt-0.5 text-[13.5px] font-medium text-slate-800 hover:text-[#0052D9] inline-flex items-center gap-1.5 truncate">
                    <span className="font-mono text-[11px] text-slate-400">{parent.code}</span> {parent.name} <ChevronRight size={13} />
                  </button>
                </div>
                <span className="shrink-0 text-[10px] px-1.5 py-0.5 rounded bg-[#00A4FF]/10 text-[#0284c7] border border-[#00A4FF]/20">子案</span>
              </div>
            )}
            {children.length > 0 && (
              <div className="flex items-center gap-x-2.5 gap-y-1.5 flex-wrap">
                <span className="inline-flex items-center gap-1.5 text-[12px] text-slate-600 shrink-0">
                  <Network size={14} className="text-[#0052D9]" />
                  已按颗粒拆分为 <b className="text-slate-800">{children.length}</b> 个子 Case
                </span>
                {children.map((ch) => (
                  <button
                    key={ch.id}
                    onClick={() => onOpenCase?.(ch.id)}
                    title={ch.name}
                    className="inline-flex items-center gap-1.5 h-7 pl-2 pr-2 rounded-full border border-slate-200 bg-white hover:border-[#0052D9]/40 hover:bg-[#0052D9]/5 transition-colors"
                  >
                    <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${ch.status === "进行中" ? "bg-blue-500" : "bg-slate-300"}`} />
                    {ch.splitGranule && <span className="font-mono text-[11px] text-slate-500">{ch.splitGranule.markCode}</span>}
                    <span className="text-[12px] text-slate-700 max-w-[120px] truncate">{ch.splitGranule?.failMode || ch.name}</span>
                    <ChevronRight size={12} className="text-slate-400" />
                  </button>
                ))}
              </div>
            )}
          </div>
        );
      })()}

      {/* 已创建 DIMM Case 按颗粒拆分弹窗 */}
      {splitOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-6" onMouseDown={() => setSplitOpen(false)}>
          <div className="w-[720px] max-w-[94vw] max-h-[86vh] bg-white rounded-2xl shadow-2xl border border-slate-200 flex flex-col overflow-hidden" onMouseDown={(e) => e.stopPropagation()}>
            <div className="px-5 py-4 border-b border-slate-100 flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#0052D9] to-[#00A4FF] text-white grid place-items-center"><Network size={16} /></div>
              <div>
                <div className="text-slate-900 font-semibold text-[15px]">按颗粒拆分 DIMM Case</div>
                <div className="text-[11.5px] text-slate-400">Case 已创建 · 每个失效颗粒拆成独立子 Case，与本 Case 建立父子关系</div>
              </div>
              <button onClick={() => setSplitOpen(false)} className="ml-auto w-8 h-8 rounded-md hover:bg-slate-100 grid place-items-center text-slate-400"><X size={16} /></button>
            </div>
            <div className="p-5 overflow-y-auto space-y-4">
              <div className="rounded-lg border border-[#0052D9]/30 bg-[#0052D9]/5 px-4 py-3">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#0052D9] text-white">父 Case</span>
                  <span className="text-[14px] font-medium text-slate-900 truncate">{c.name}</span>
                  <span className="text-[11px] text-slate-400 ml-auto font-mono">{c.code} · DIMM</span>
                </div>
              </div>

              {/* 选择要拆分的颗粒 + 合并选项 */}
              <div className="flex items-center justify-between">
                <div className="text-[12px] text-slate-600">选择要拆分的颗粒（可只拆部分，不必每颗都拆）</div>
                <label className="flex items-center gap-1.5 text-[12px] text-slate-600 cursor-pointer">
                  <input type="checkbox" checked={splitMerge} onChange={(e) => setSplitMerge(e.target.checked)} className="accent-[#0052D9]" />
                  按失效模式合并同类颗粒
                </label>
              </div>
              <div className="rounded-lg border border-slate-200 divide-y divide-slate-100">
                {(c.granules || []).map((g: any, idx: number) => (
                  <label key={idx} className="flex items-center gap-3 px-3 py-2 hover:bg-slate-50 cursor-pointer">
                    <input type="checkbox" checked={!!splitSel[g.markCode]} onChange={(e) => setSplitSel((p) => ({ ...p, [g.markCode]: e.target.checked }))} className="accent-[#0052D9]" />
                    <span className="font-mono text-[11px] text-slate-500 w-20 shrink-0">{g.markCode}</span>
                    <span className="text-[12px] text-slate-700 flex-1 truncate">{g.failMode} · {g.failCondition}</span>
                    <span className="text-[11px] text-slate-400 font-mono shrink-0">{g.sn}</span>
                  </label>
                ))}
              </div>

              {/* 结果预览 */}
              <div>
                <div className="text-[12px] text-slate-600 mb-2">将生成 <b className="text-[#0052D9]">{splitGroups.length}</b> 个子 Case{splitMerge ? "（同失效模式已合并）" : ""}</div>
                {splitGroups.length === 0 ? (
                  <div className="text-[12px] text-slate-400 border border-dashed border-slate-200 rounded-lg px-4 py-4 text-center">未选择颗粒，请至少勾选一个</div>
                ) : (
                  <div className="relative pl-5">
                    <span className="absolute left-1.5 top-0 bottom-3 w-px bg-slate-200" />
                    <div className="space-y-2.5">
                      {splitGroups.map((grp, idx) => (
                        <div key={idx} className="relative">
                          <span className="absolute -left-[14px] top-5 w-3 h-px bg-slate-200" />
                          <div className="rounded-lg border border-slate-200 bg-white px-4 py-3">
                            <div className="flex items-center gap-2">
                              <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#00A4FF]/12 text-[#0284c7]">子 Case {idx + 1}</span>
                              <span className="text-[13.5px] font-medium text-slate-900 truncate">{c.name.replace(/（.*?）\s*$/, "")} · {grp.label}</span>
                              <span className="text-[11px] text-slate-400 ml-auto font-mono">{c.code}.C{String(idx + 1).padStart(2, "0")}</span>
                            </div>
                            <div className="mt-2 flex flex-wrap gap-1.5">
                              {grp.granules.map((g: any) => (
                                <span key={g.markCode} className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 font-mono">{g.markCode} · {g.failCondition}</span>
                              ))}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
              {splitDone && (
                <div className="rounded-lg bg-emerald-50 border border-emerald-200 px-4 py-2.5 text-[12.5px] text-emerald-700 flex items-center gap-2">
                  <Check size={14} /> 已生成 {(c.childCaseIds || []).length} 个子 Case，父子关系已建立。可在下方关系区或 Case 中心查看 / 进入。
                </div>
              )}
            </div>
            <div className="px-5 py-3 border-t border-slate-100 flex items-center justify-between gap-2">
              <span className="text-[11px] text-slate-400">已选 {splitGroups.reduce((a, g) => a + g.granules.length, 0)} / {(c.granules || []).length} 颗粒 · 生成 {splitGroups.length} 子 Case</span>
              <div className="flex gap-2">
                <button onClick={() => setSplitOpen(false)} className="h-9 px-4 rounded-md border border-slate-200 text-sm text-slate-600 hover:bg-slate-50">{splitDone ? "关闭" : "取消"}</button>
                {!splitDone && (
                  <button onClick={doSplitDimm} disabled={splitGroups.length === 0} className="h-9 px-4 rounded-md bg-gradient-to-r from-[#0052D9] to-[#003FA8] text-white text-sm hover:shadow-md disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1.5"><Network size={14} /> 确认拆分为 {splitGroups.length} 个子 Case</button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Header — 方案 02：左主信息（操作置顶 + 背景/影响双栏）/ 右识别侧栏 */}
      <div className="bg-white border border-slate-200 rounded-lg p-5">
        <div className="grid grid-cols-[1fr_232px] gap-[18px]">
          {/* 左：主信息 */}
          <div className="min-w-0">
            {/* 编号（左）+ 操作（右对齐，顶着竖线） */}
            <div className="flex items-center justify-between gap-4">
              <span className="font-mono text-xs text-slate-500">{c.code}</span>
              <div className="flex flex-wrap justify-end items-center gap-2">
                <RecoveryActions record={closure ?? {}} owner={c.owner} title={c.name} completed={closures.isClosed(caseId)} active={!closures.isClosed(caseId)} isCase reviewed={closure?.approvedBy} blocked={closure?.approval?.kind === "closure" && !closure.approval.decision ? "请先处理当前审批" : undefined} onAction={(action, text, files, dueDate) => { recoverCase(caseId, action, text, files, dueDate); showToast(action === "reopen" ? "已重新开启，由负责人继续修改原文档" : "已保存"); }} />
                {/* 演示 */}
                <button
                  onClick={() => setDemoOpen(true)}
                  title="演示模式（汇报放映）"
                  className="h-8 px-3 text-sm rounded-md border border-slate-200 bg-white text-slate-600 hover:border-[#0052D9]/40 hover:text-[#0052D9] hover:bg-[#0052D9]/5 flex items-center gap-1.5 transition-all"
                >
                  <MonitorPlay size={14} /> 演示
                </button>
                {/* 编辑（主） */}
                <button
                  onClick={() => onEdit?.(caseId)}
                  disabled={closures.isClosed(caseId) || c.owner !== currentUser.name || Boolean(closure?.approval && !closure.approval.decision)}
                  className="h-8 px-3 text-sm rounded-md border border-[#0052D9]/30 bg-white text-[#0052D9] hover:bg-[#0052D9]/5 flex items-center gap-1.5 transition-all"
                  title="编辑 Case"
                >
                  <Edit2 size={14} /> 编辑
                </button>
                {/* 根因与结案（两步：① 确认根因·提交 Fanout → 线下验证 → ② 提交结案信息） */}
                {(() => {
                  const isClosed = closures.isClosed(caseId);
                  const rootCaused = closures.isRootCaused(caseId);
                  const noFanout = c.level === "L3";
                  const label = isClosed ? "已结案" : isFanoutDerived ? "结案" : rootCaused ? "结案" : "根因与结案";
                  return (
                    <button
                      disabled={!isClosed && (c.owner !== currentUser.name || Boolean(closure?.approval && !closure.approval.decision))}
                      onClick={() => {
                        if (isClosed) {
                          setClosureSummaryOpen(true);
                          return;
                        }
                        if (isFanoutDerived) setFanoutCloseOpen(true);
                        else {
                          setWizardResume(rootCaused);
                          setRootCauseOpen(true);
                        }
                      }}
                      title={isClosed ? "查看结案信息" : isFanoutDerived ? "填写结案结论并直接结案" : rootCaused ? "提交结案信息 · 完成结案" : "确认根因 · 提交 Fanout · 结案"}
                      className={`h-8 px-3 text-sm rounded-md border flex items-center gap-1.5 transition-all ${
                        isClosed
                          ? "bg-emerald-50 text-emerald-700 border-emerald-300 hover:bg-emerald-100"
                          : rootCaused
                            ? "bg-[#00B578] text-white border-[#00B578] hover:bg-[#009962]"
                            : "bg-white text-[#00B578] border-[#00B578]/40 hover:bg-[#00B578]/5"
                      }`}
                    >
                      <ShieldCheck size={14} />
                      {label}
                    </button>
                  );
                })()}

                {/* 分隔 */}
                <span className="w-px h-5 bg-slate-200 mx-0.5" />

                {/* 订阅（书签） */}
                <button
                  onClick={() => subs.toggle(caseId)}
                  title={subscribed ? "已订阅 · 点击取消" : "订阅此 Case"}
                  className={`h-8 w-8 rounded-md border flex items-center justify-center transition-all ${
                    subscribed
                      ? "bg-[#0052D9]/8 text-[#0052D9] border-[#0052D9]/30"
                      : "bg-white text-slate-700 border-slate-200 hover:border-[#0052D9]/40"
                  }`}
                >
                  {subscribed ? <Bookmark size={15} fill="currentColor" /> : <Bookmark size={15} />}
                </button>
                {/* 分享 */}
                <button
                  title="分享链接"
                  className="h-8 w-8 rounded-md border border-slate-200 text-slate-700 bg-white hover:bg-slate-50 flex items-center justify-center transition-all"
                >
                  <Share2 size={15} />
                </button>
                {/* 评论 */}
                <button
                  onClick={() => setCommentOpen(true)}
                  title="Case 评论"
                  className="h-8 w-8 rounded-md border border-slate-200 text-slate-700 bg-white hover:border-[#0052D9]/40 hover:text-[#0052D9] flex items-center justify-center transition-all"
                >
                  <MessageSquare size={15} />
                </button>
              </div>
            </div>

            <div className="mt-1.5 flex items-center gap-2 flex-wrap">
              {(!!c.fanoutSourceCaseId || c.source === "fanout验证") && (
                <span className="shrink-0 inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-medium bg-[#00A4FF]/10 text-[#0284c7] border border-[#00A4FF]/25">
                  <Share2 size={12} /> Fanout
                </span>
              )}
              <h1 className="text-slate-900">{c.name}</h1>
              <RecoveryBadge record={closure ?? {}} />
              <CaseMarkCodePill caseItem={c} />
            </div>

            {currentReturn?.kind === "return" && <section aria-label="当前整改要求" className="mt-3 border-l-2 border-amber-400 bg-amber-50/50 px-3 py-2.5">
              <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-slate-500"><span className="font-medium text-amber-700">退回整改</span><span>{currentReturn.by} · {new Date(currentReturn.at).toLocaleString("zh-CN")}</span>{currentReturn.dueDate && <span>期望反馈：{currentReturn.dueDate}</span>}</div>
              <p className="mt-1 whitespace-pre-wrap break-words text-xs leading-5 text-slate-700">{currentReturn.reason}</p>
            </section>}
            <CaseRecoveryPanel caseId={caseId} />
            {/* 背景与影响 · 双栏平行 */}
            <div className="mt-4">
              <div className="grid grid-cols-2 gap-4">
                <InfoItem label="发起事由与背景（What & Why）" value={[c.reason, c.background].filter(Boolean).join(" ")} />
                <div>
                  <InfoItem label="影响" value={c.impact || "—"} />
                  {closure?.domain && (
                    <div className="mt-1.5">
                      <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded border border-[#7A3DFF]/25 bg-[#7A3DFF]/8 text-[#7A3DFF] text-[11px] font-medium">
                        <GitBranch size={11} /> 根因 Domain · {closure.domain}
                      </span>
                    </div>
                  )}
                </div>
              </div>
              {sourceStandaloneTasks.map((sourceTask) => (
                <button key={sourceTask.id} type="button" aria-label={`查看来源自由任务 ${sourceTask.title}`} onClick={() => onOpenStandaloneTask?.(sourceTask.id)} disabled={!onOpenStandaloneTask} className="mt-3 flex w-full items-center gap-2 rounded-md border border-[#0052D9]/20 bg-[#0052D9]/5 px-3 py-2 text-left text-xs text-[#0052D9] disabled:cursor-default">
                  <ClipboardList size={13} />
                  <span className="font-medium">来源自由任务</span>
                  <span className="font-mono text-[10px] text-slate-400">{sourceTask.code}</span>
                  <span className="min-w-0 flex-1 truncate text-slate-600">{sourceTask.title}</span>
                  <span className="shrink-0 rounded bg-slate-100 px-1.5 py-0.5 text-[10px] text-slate-500">{standaloneTaskDisplayStatus(sourceTask)}</span>
                </button>
              ))}
              <button
                onClick={() => setShowMore(!showMore)}
                className="mt-3 text-xs text-[#0052D9] hover:underline flex items-center gap-1"
              >
                {showMore ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
                {showMore ? "收起创建信息" : "展开全部创建信息（产品 / 物料 / 失效）"}
              </button>
              {showMore && (
                <>
                <div className="mt-3 grid grid-cols-5 gap-x-4 gap-y-3 text-xs p-3 bg-slate-50/60 rounded border border-slate-100">
                  {[
                    ["Domain", c.problemDomain || "—"],
                    ["问题类型", c.problemType || "—"],
                    ["产品编码", c.product],
                    ["案件物料", c.material],
                    ["物料二级", c.materialSubtype],
                    ["Density", c.density],
                    ["IO Type", c.ioType],
                    ["Fail Stage", c.failStage],
                    ["Customer", c.customer],
                    ["Fail Platform", c.failPlatform],
                    ["Fail Mode", c.failMode],
                    ["Fail Ratio", c.failRatio],
                    ["Fail Package", c.failPackage],
                    ["Mask Version", c.maskVersion],
                    ["Program", c.program],
                    ["PPM", c.ppm],
                    ["PD ID", c.pdId],
                    ["创建时间", c.createdAt],
                    ["更新时间", c.updatedAt],
                  ].map(([k, v]) => (
                    <div key={k}>
                      <div className="text-slate-400">{k}</div>
                      <div className="text-slate-700 mt-0.5">{v || "—"}</div>
                    </div>
                  ))}
                </div>

                {c.material === "Wafer" ? (
                  <div className="mt-4">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="text-xs font-medium text-slate-500">Wafer 信息</div>
                      <span className="text-[10.5px] text-slate-400">
                        {waferLotGroups.length} 个 Lot
                        {` · ${waferLotGroups.reduce((count, lot) => count + (lot.wholeLot ? 25 : lot.waferIds.length), 0)} 片 Wafer`}
                      </span>
                    </div>
                    {waferLotGroups.length ? (
                      <div className="space-y-2">
                        {waferLotGroups.map((lot) => (
                          <div key={lot.lotId} className="flex items-start gap-4 rounded-lg border border-slate-200 bg-slate-50/40 px-3 py-2.5">
                            <div className="w-40 shrink-0">
                              <div className="text-[10px] text-slate-400">Lot ID</div>
                              <div className="mt-0.5 font-mono text-xs font-medium text-slate-700">{lot.lotId}</div>
                            </div>
                            <div className="min-w-0 flex-1">
                              <div className="mb-1.5 text-[10px] text-slate-400">Wafer ID · {lot.wholeLot ? "整 Lot 25 片" : `${lot.waferIds.length} / 25`}</div>
                              {lot.wholeLot ? (
                                <span className="inline-flex h-6 items-center rounded border border-emerald-200 bg-emerald-50 px-2 text-[10px] text-emerald-600">已按 Lot ID 录入全部 25 片</span>
                              ) : (
                                <div className="flex flex-wrap gap-1">
                                  {lot.waferIds.map((waferId) => (
                                    <span key={waferId} className="inline-flex h-6 items-center justify-center rounded border border-[#0052D9]/20 bg-[#0052D9]/5 px-1.5 font-mono text-[10px] text-[#0052D9]">{waferId}</span>
                                  ))}
                                </div>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="rounded border border-dashed border-slate-200 px-3 py-4 text-center text-xs text-slate-400">暂无 Wafer 信息</div>
                    )}
                  </div>
                ) : (
                  /* 颗粒信息表 */
                  <div className="mt-4">
                    <div className="text-xs font-medium text-slate-500 mb-2">颗粒信息</div>
                    <div className="overflow-x-auto rounded border border-slate-200">
                      <table className="w-full text-xs border-collapse">
                        <thead>
                          <tr className="bg-slate-100 text-slate-500">
                            {["Mark Code", "SN", "Work Order", "Fail Mode", "Fail Condition"].map((h) => (
                              <th key={h} className="px-3 py-2 text-left font-medium border-b border-slate-200 whitespace-nowrap">{h}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {(c.granules && c.granules.length > 0) ? c.granules.map((g: any, i: number) => (
                            <tr key={i} className="border-b border-slate-100 last:border-0 hover:bg-slate-50">
                              <td className="px-3 py-2 text-slate-700">{g.markCode || "—"}</td>
                              <td className="px-3 py-2 text-slate-700">{g.sn || "—"}</td>
                              <td className="px-3 py-2 text-slate-700">{g.workOrder || "—"}</td>
                              <td className="px-3 py-2 text-slate-700">{g.failMode || "—"}</td>
                              <td className="px-3 py-2 text-slate-700">{g.failCondition || "—"}</td>
                            </tr>
                          )) : (
                            <tr>
                              <td colSpan={5} className="px-3 py-4 text-center text-slate-400">暂无颗粒信息</td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
                </>
              )}
            </div>

            {/* —— V1.0.4：DIMM IC / Die 结构（默认收起，点击 Chip ID 建立关联 Case）—— */}
            {(c.granules || []).some((g: any) => g.icTree) && (
              <div className="mt-4 rounded-xl border border-slate-200">
                <button
                  type="button"
                  onClick={() => setIcTreeOpen((v) => !v)}
                  className="w-full flex items-center gap-2 px-4 py-3 text-left"
                >
                  <Cpu size={15} className="text-[#0052D9]" />
                  <span className="text-sm font-medium text-slate-800">DIMM IC / Die 结构</span>
                  <span className="text-[11px] text-slate-400">
                    共 {(c.granules || []).filter((g: any) => g.icTree).reduce((n: number, g: any) => n + g.icTree.ics.length, 0)} 颗 IC · 点击 Chip ID 可预填新建关联 Case
                  </span>
                  {icTreeOpen ? <ChevronUp size={16} className="ml-auto text-slate-400" /> : <ChevronDown size={16} className="ml-auto text-slate-400" />}
                </button>
                {icTreeOpen && (
                  <div className="px-4 pb-4 space-y-3">
                    {(c.granules || []).filter((g: any) => g.icTree).map((g: any) => (
                      <div key={g.sn || g.markCode} className="rounded-lg border border-slate-100 bg-slate-50/40 p-3">
                        <div className="flex items-center gap-2 mb-2 text-xs text-slate-600">
                          <span className="font-mono">SN {g.icTree.sn || g.sn}</span>
                          <span className="text-slate-400">·</span>
                          <span><b className="text-[#0052D9]">{g.icTree.ics.length}</b> 颗 IC</span>
                          <span className="text-slate-400">·</span>
                          <span><b className="text-[#0052D9]">{g.icTree.ics.reduce((n: number, ic: any) => n + ic.dies.length, 0)}</b> 个 Die</span>
                        </div>
                        <div className="grid grid-cols-3 gap-2">
                          {g.icTree.ics.map((ic: any) => (
                            <div key={ic.icId} className="rounded-md border border-slate-200 bg-white px-2.5 py-2">
                              <div className="text-[11px] font-medium text-slate-600 mb-1.5">{ic.icId}</div>
                              <div className="flex flex-wrap gap-1.5">
                                {ic.dies.map((d: any) => (
                                  <button
                                    key={d.chipId}
                                    type="button"
                                    onClick={() => spawnCaseFromChip(d.chipId, { sn: g.icTree.sn || g.sn, icId: ic.icId, dieId: d.dieId })}
                                    title={`点击预填新建关联 Case：${ic.icId} / ${d.dieId} / ${d.chipId}`}
                                    className={`inline-flex items-center gap-1 rounded border px-1.5 py-0.5 text-[10px] font-mono transition-colors ${d.isFailChip ? "border-red-300 bg-red-50 text-red-600 hover:bg-red-100" : "border-[#0052D9]/30 bg-[#0052D9]/[0.04] text-[#0052D9] hover:bg-[#0052D9]/10 hover:border-[#0052D9]"}`}
                                  >
                                    <span className={d.isFailChip ? "text-red-400" : "text-[#0052D9]/50"}>{d.dieId}</span>{d.chipId}
                                    {d.isFailChip && <span className="font-sans text-[8.5px] font-semibold">Fail Chip</span>}
                                  </button>
                                ))}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* 分析过程与结论 —— 位于背景/影响下方，共用同一框体、不越过右侧竖线 */}
            <div
              onClick={() => setConclusionDocOpen(true)}
              className="mt-4 group cursor-pointer rounded-xl border border-slate-200 p-4 hover:border-[#0052D9]/40 hover:shadow-sm transition-all"
            >
              <div className="flex items-center gap-2.5">
                <span className="w-8 h-8 rounded-lg bg-[#0052D9]/8 text-[#0052D9] flex items-center justify-center shrink-0">
                  <FileSpreadsheet size={16} />
                </span>
                <div className="min-w-0">
                  <div className="text-sm text-slate-800 font-medium">分析过程与结论</div>
                  <div className="text-[11px] text-slate-400">现象 → 假设 → 验证 → 结论 · 支持富文本 / 图表 / 附件</div>
                </div>
                <span className="ml-auto shrink-0 text-[11px] text-slate-400 group-hover:text-[#0052D9] inline-flex items-center gap-0.5">
                  进入 Workspace 编辑 <ChevronRight size={13} />
                </span>
              </div>
              <div className="mt-2.5 rounded-lg bg-slate-50/70 border border-slate-100 px-3 py-2.5">
                <div className="text-xs text-slate-600 leading-relaxed line-clamp-2">
                  {caseConclusion || (
                    <span className="text-slate-400">暂无结论，点击撰写分析过程与结论。</span>
                  )}
                </div>
              </div>
            </div>
          </div>
          {/* 右：识别侧栏 */}
          <div className="border-l border-slate-200 pl-[18px] flex flex-col">
            {/* 等级 / 产品 / 紧急（结案状态由顶部「根因与结案」按钮体现，此处不再重复） */}
            <div className="flex items-center gap-2 flex-wrap">
              <span className={`px-2 py-0.5 rounded text-xs border ${levelColors[c.level]}`}>{c.level}</span>
              <CaseProductPill caseItem={c} />
              <span className={`px-2 py-0.5 rounded text-xs ${urgencyColors[c.urgency]}`}>{c.urgency}</span>
              <CaseStatusBadge status={caseDisplayStatus(c, { closed: closure?.state === "closed", rootCaused: closure?.state === "rootcause" })} />
            </div>
            {closure?.state === "closed" && (
              <span className="mt-2 px-2 py-0.5 rounded text-xs bg-emerald-50 text-emerald-700 border border-emerald-200 inline-flex items-center gap-1 w-fit">
                <Lock size={11} /> 结案于 {closure.closedAt}
              </span>
            )}

            {/* 进度环 + 到期 */}
            <div className="mt-4 flex flex-col gap-2.5 text-xs">
              <div data-case-progress className="flex h-5 items-center justify-between gap-2">
                <span className="text-slate-400">整体进度</span>
                <span className="inline-flex items-center gap-1.5 text-slate-700">
                  <ProgressRing value={progress} size={16} stroke={2} />
                  <span className="tabular-nums">{progress}%</span>
                </span>
              </div>
              <CaseScore record={c} tasks={tasks} closure={closure} />
              <div className="flex h-5 items-center justify-between gap-2">
                <span className="text-slate-400">距到期</span>
                <span className={c.dueIn <= 3 ? "text-[#FF3B30]" : "text-slate-700"}>{c.dueIn} 天</span>
              </div>
            </div>

            {/* Fanout 进度（由本 Case 结案 Fanout 派生） */}
            {(fanoutCases.length > 0 || c.fanoutSkipReason) && (
              <div className="mt-4 pt-3.5 border-t border-slate-100 flex flex-col gap-2 text-xs">
                <div className="flex items-center gap-1.5">
                  <Share2 size={13} className="text-[#0052D9]" />
                  <span className="text-slate-500">Fanout 进度</span>
                  {fanoutCases.length > 0 && (
                    <span className="ml-auto text-slate-700">{fanoutDone}/{fanoutCases.length} 完成 · 均 {fanoutAvg}%</span>
                  )}
                </div>
                {fanoutCases.length > 0 ? (
                  <>
                    <div className="h-1.5 rounded-full bg-slate-100 overflow-hidden">
                      <div className="h-full bg-emerald-400" style={{ width: `${fanoutAvg}%` }} />
                    </div>
                    <button
                      type="button"
                      onClick={() => setFanoutDetailOpen((v) => !v)}
                      className="inline-flex items-center gap-1 text-[11px] text-[#0052D9] hover:underline w-fit"
                    >
                      {fanoutDetailOpen ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
                      {fanoutDetailOpen ? "收起明细" : `展开各产品明细（${fanoutCases.length}）`}
                    </button>
                    {fanoutDetailOpen && (
                      <div className="space-y-1.5 max-h-[200px] overflow-y-auto pr-0.5">
                        {fanoutCases.map((fc) => {
                          const prog = fanoutCaseProgress(fc);
                          const prod = productById(fc.productIds?.[0] ?? fc.productId);
                          return (
                            <div key={fc.id} className="flex items-center gap-2">
                              <div className="flex-1 min-w-0">
                                <div className="text-slate-600 truncate text-[11px]">{prod?.code ?? fc.product} <span className="text-slate-400">· {fc.owner}</span></div>
                                <button onClick={() => onOpenCase?.(fc.id)} className="font-mono text-[10px] text-[#0052D9] hover:underline">{fc.code}</button>
                              </div>
                              <span className="shrink-0 inline-flex items-center gap-1" title={`Case 任务平均完成度 ${prog}%`}>
                                <ProgressRing value={prog} size={16} stroke={2} />
                                <span className="text-[10px] text-slate-500 tabular-nums w-8 text-right">{prog}%</span>
                              </span>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </>
                ) : (
                  <div className="text-[11px] text-slate-500 leading-relaxed">
                    <span className="text-amber-600">本次未 Fanout</span> · 理由：{c.fanoutSkipReason}
                  </div>
                )}
              </div>
            )}

            {/* 属性组：Owner / 参与人 / 协作·任务 */}
            <div className="mt-4 pt-3.5 border-t border-slate-100 flex flex-col gap-2.5 text-xs relative">
              <div className="flex items-center justify-between gap-2">
                <span className="text-slate-400">Owner</span>
                <span className="text-slate-700 inline-flex items-center gap-1.5">
                  <b className="font-medium">{owner}</b>
                  <button
                    onClick={() => {
                      setTransferDraft("");
                      setTransferOpen((v) => !v);
                    }}
                    className="text-[11px] text-[#0052D9] hover:underline"
                  >
                    转移
                  </button>
                </span>
              </div>
              {c.createdBy && c.createdBy !== c.owner && (
                <div className="flex items-center justify-between gap-2">
                  <span className="text-slate-400 shrink-0">代创建</span>
                  <span className="text-slate-600">{c.createdBy} 替 <b className="font-medium text-slate-700">{c.owner}</b> 创建</span>
                </div>
              )}
              {mergedParticipants.length > 0 && (
                <div className="flex items-center justify-between gap-2">
                  <span className="text-slate-400 shrink-0">参与人</span>
                  <div className="flex items-center -space-x-1.5">
                    {mergedParticipants.map((p, idx) => (
                      <div key={idx} className="relative group" title={`${p.name} · ${p.department}`}>
                        <div className="w-6 h-6 rounded-full bg-gradient-to-br from-[#0052D9] to-[#00A4FF] flex items-center justify-center text-white text-[10px] border-2 border-white cursor-pointer">
                          {p.name.slice(-2)}
                        </div>
                        <div className="absolute bottom-full right-0 mb-2 px-2 py-1 bg-slate-800 text-white text-[10px] rounded whitespace-nowrap opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity z-10">
                          {p.name} · {p.department}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              <div className="flex items-center justify-between gap-2">
                <span className="text-slate-400">协作 / 任务</span>
                <span className="text-slate-700">{c.departments.length} 部门 · {executionTasks.length} 任务</span>
              </div>
              <CaseFeishuGroup caseId={c.id} owner={owner} code={c.code} />
              {taskStatusCounts.length > 0 && (
                <div className="flex flex-wrap justify-end gap-1.5">
                  {taskStatusCounts.map(({ status, count }) => (
                    <span key={status} className={`inline-flex items-center rounded border px-1.5 py-0.5 text-[10px] ${statusColors[status]}`}>{count} {status}</span>
                  ))}
                </div>
              )}
              {transferOpen && (
                <div className="absolute right-0 top-7 z-20 w-64 bg-white border border-slate-200 rounded-lg shadow-lg p-3 space-y-2">
                  <div className="text-xs text-slate-700">转移 Case Owner</div>
                  <input
                    autoFocus
                    value={transferDraft}
                    onChange={(e) => setTransferDraft(e.target.value)}
                    placeholder="新 Owner 姓名"
                    className="w-full h-8 px-2 text-sm rounded border border-slate-200 outline-none focus:border-[#0052D9]"
                  />
                  <div className="flex gap-2 justify-end">
                    <button
                      onClick={() => setTransferOpen(false)}
                      className="h-7 px-2.5 text-xs rounded border border-slate-200 text-slate-600 hover:bg-slate-50"
                    >
                      取消
                    </button>
                    <button
                      disabled={!transferDraft.trim()}
                      onClick={() => {
                        pushActivity({ type: "owner", by: currentUser.name, summary: "Owner 变更", from: owner, to: transferDraft.trim() });
                        setOwner(transferDraft.trim());
                        setTransferOpen(false);
                      }}
                      className="h-7 px-2.5 text-xs rounded bg-[#0052D9] text-white hover:bg-[#003FA8] disabled:opacity-40"
                    >
                      确认转移
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* 时间组 */}
            <div className="mt-3.5 pt-3.5 border-t border-slate-100 flex flex-col gap-2 text-[11px] text-slate-400">
              <div className="flex items-center justify-between"><span>Case 截止日期</span><span className={c.dueDate && c.dueDate < new Date().toISOString().slice(0, 10) ? "text-red-600 font-medium" : "text-slate-500"}>{c.dueDate || "未设置"}</span></div>
              <div className="flex items-center justify-between"><span>创建</span><span className="text-slate-500">{c.createdAt}</span></div>
              <div className="flex items-center justify-between"><span>更新</span><span className="text-slate-500">{c.updatedAt}</span></div>
            </div>
          </div>
        </div>
      </div>

      {c.analysisTemplate === "cr-standard" && c.pipeline?.length ? <CrPipelineProgress pipeline={c.pipeline} /> : null}

      {/* 关联控件：归属 Issue（共性问题，多对多）+ 关联 Case（弱链接）融合 */}
      <div id="case-relations" className="mt-4">
        <CaseRelations
          caseId={caseId}
          onOpenCase={onOpenCase}
          onOpenIssue={onOpenIssue}
          hideIssue
        />
      </div>

      {conclusionDocOpen && (
        <CaseCloudDocModal
          caseItem={c}
          canEdit={c.owner === currentUser.name && !closures.isClosed(caseId) && !(closure?.approval && !closure.approval.decision)}
          initialConclusion={caseConclusion}
          initialProcess={caseProcess}
          initialAttachments={caseWsAtts}
          onClose={() => setConclusionDocOpen(false)}
          onSave={(payload) => {
            saveCaseWorkspace(caseId, payload);
            setCaseConclusion(payload.conclusion);
            setCaseProcess(payload.process);
            setCaseWsAtts(payload.attachments);
            setConclusionDocOpen(false);
          }}
        />
      )}

      {/* Layout - single column */}
      <div className="mt-4 relative">
        {/* Tabs */}
        <div className="bg-white border border-slate-200 rounded-lg">
          <div className="border-b border-slate-100 px-4 py-3 flex items-center gap-2">
            <h3 className="text-sm font-semibold text-slate-800">Case 分析</h3>
            {/* 视图切换：思维导图 / 任务视图（右对齐，与新建 Case 一致） */}
            <div className="ml-auto inline-flex items-center rounded-lg border border-slate-200 bg-slate-50 p-0.5">
              {tabDefs.map((t) => {
                const Icon = t.icon;
                const active = t.key === tab;
                return (
                  <button
                    key={t.key}
                    onClick={() => setTab(t.key)}
                    className={`inline-flex items-center gap-1.5 h-7 px-2.5 rounded-md text-[12px] font-medium transition-colors ${
                      active
                        ? "bg-white text-[#0052D9] shadow-sm"
                        : "text-slate-500 hover:text-slate-700"
                    }`}
                  >
                    <Icon size={13} /> {t.label}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="p-4 min-h-[360px]">
            {tab === "mindmap" && (
              <MindMapFlow
                caseItem={c}
                tasks={tasks}
                focusMine={focusMine}
                showUrgency={showUrgency}
                onTaskClick={(tid) => onOpenTask(c.id, tid)}
                onAddChild={caseEditingAllowed ? submitTask : undefined}
                onEditTask={caseEditingAllowed ? editTask : undefined}
                onSaveEfa={caseEditingAllowed ? saveEfaAnalysis : undefined}
                onDelete={caseEditingAllowed ? deleteTask : undefined}
                onClone={caseEditingAllowed ? cloneTask : undefined}
                onCompleteCoverage={caseEditingAllowed ? completeCoverage : undefined}
                onPatternFanout={caseEditingAllowed ? createPatternFanout : undefined}
              />
            )}
            {tab === "data" && (
              <CreateCaseWbsTable
                caseData={c}
                readOnly={!caseEditingAllowed}
                thoughtGroups={taskTreeToThoughtGroups(tasks)}
                onGroupsChange={(groups) => setTasks(thoughtGroupsToTaskTree(groups, tasks))}
                onTaskOpen={(tid) => onOpenTask(c.id, tid)}
                compact
              />
            )}
            {tab === "gantt" && (
              <CaseGanttView
                caseItem={c}
                tasks={tasks}
                onTaskClick={(tid) => onOpenTask(c.id, tid)}
              />
            )}
            {tab === "related" && <RelatedTab c={c} />}
          </div>
        </div>
      </div>

      {/* Case 流转日志（#1：独立模块，置于思维导图下方） */}
      <section aria-label="Case 流转日志" className="mt-4 bg-white border border-slate-200 rounded-xl p-5">
        <div className="flex items-center gap-2 mb-4">
          <Clock size={15} className="text-[#0052D9]" />
          <h3 className="text-sm text-slate-800 font-medium">Case 流转日志</h3>
          <span className="text-[11px] text-slate-400">Owner / 时间 / 层级 / 状态等变更</span>
        </div>
        <div className="relative pl-5">
          <div className="absolute left-[5px] top-1 bottom-1 w-px bg-slate-200" />
          <div className="space-y-4">
            {caseActivity.map((a) => (
              <div key={a.id} className="relative">
                <span
                  className={`absolute -left-[18px] top-1 w-2.5 h-2.5 rounded-full ring-2 ring-white ${
                    a.type === "owner" ? "bg-violet-500"
                    : a.type === "due" ? "bg-amber-500"
                    : a.type === "level" ? "bg-blue-500"
                    : a.type === "recovery" ? "bg-amber-500"
                    : a.type === "status" ? "bg-[#0052D9]"
                    : "bg-slate-400"
                  }`}
                />
                <div className="text-sm text-slate-800">
                  {a.summary}
                  {(a.from || a.to) && (
                    <span className="ml-1 text-xs text-slate-500">
                      {a.from && <span className="line-through decoration-slate-300">{a.from}</span>}
                      {a.from && a.to && <span className="mx-1">→</span>}
                      {a.to && <b className="text-slate-700">{a.to}</b>}
                    </span>
                  )}
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5">{a.by} · {a.recovery ? new Date(a.at).toLocaleString("zh-CN") : a.at}</div>
                {a.recovery && <RecoveryHistoryEntry entry={a.recovery} showProgress />}
              </div>
            ))}
          </div>
        </div>
      </section>

      {rootCauseOpen && (
        <RootCauseFanoutModal
          caseId={caseId}
          caseCode={c.code}
          caseName={c.name}
          caseProductIds={c.productIds ?? (c.productId ? [c.productId] : [])}
          initialDomain={wizardResume ? closure?.domain : c.problemDomain}
          initialProblemType={wizardResume ? closure?.problemType : c.problemType}
          noFanout={c.level === "L3"}
          resume={wizardResume}
          initialConclusion={caseConclusion}
          initialFiles={(c.caseAttachments ?? []).map((a) => ({ ...a }))}
          initialSolutionPath={c.solutionPath}
          onCancel={() => setRootCauseOpen(false)}
          onSubmit={(result) => {
            try {
            const alreadyRootCaused = closures.isRootCaused(caseId);
            const hadFanout = Boolean(closure?.recovery?.length && (closure.fanoutTargets?.length || fanoutCases.length));
            if (!alreadyRootCaused) {
              closures.submitRootCause({
                caseId,
                domain: result.domain,
                problemType: result.problemType,
                krByProduct: result.krByProduct,
                followupNote: result.followupNote,
                fanoutTargets: result.fanoutTargets,
                fanoutSkipReason: result.fanoutSkipReason,
                by: currentUser.name,
              });
              // 提交 Fanout：为目标产品各建 1 个验证 Case；手动取消则记录理由
              if (!hadFanout && result.fanoutTargets.length > 0) {
                createFanoutCasesFromClose({ sourceCaseId: caseId, productIds: result.fanoutTargets, conclusion: result.followupNote || `根因归属 ${result.domain}`, by: currentUser.name });
                c.fanoutTargets = result.fanoutTargets;
                c.fanoutSkipReason = undefined;
              } else if (result.fanoutSkipReason) {
                c.fanoutSkipReason = result.fanoutSkipReason;
              }
            }
            const createdFanout = (!alreadyRootCaused && !hadFanout && result.fanoutTargets.length > 0) ? result.fanoutTargets.length : 0;
            if (result.decision === "close") {
              closures.submit({
                caseId,
                conclusion: result.conclusion || "",
                submittedBy: currentUser.name,
                files: result.files,
                solutionPath: result.solutionPath,
              });
              c.solutionPath = result.solutionPath;
              setCaseConclusion(result.conclusion || "");
              setCaseProcess(buildAnalysisProcess(c));
              if (result.files && result.files.length) setCaseWsAtts((prev) => [...prev, ...result.files!]);
              setRootCauseOpen(false);
              showToast(closures.get(caseId)?.approval?.kind === "closure" && !closures.get(caseId)?.approval?.decision ? "已提交再次结案申请，等待原审核人确认" : createdFanout ? `已结案 · 已创建 ${createdFanout} 个 Fanout 验证 Case` : "已结案");
            } else {
              setRootCauseOpen(false);
              showToast(createdFanout ? `已进入待验证结案 · 已创建 ${createdFanout} 个 Fanout 验证 Case` : "已进入待验证结案");
            }
            } catch (cause) { showToast(cause instanceof Error ? cause.message : "保存失败，请重试"); }
          }}
        />
      )}
      {fanoutCloseOpen && (
        <CloseCaseModal
          caseCode={c.code}
          caseName={c.name}
          initialConclusion={caseConclusion}
          onCancel={() => setFanoutCloseOpen(false)}
          onSubmit={(conclusion) => {
            try {
            closures.submit({ caseId, conclusion, submittedBy: currentUser.name });
            setCaseConclusion(conclusion);
            setFanoutCloseOpen(false);
            showToast(closures.isClosed(caseId) ? "已结案" : "已提交再次结案申请，等待原审核人确认");
            } catch (cause) { showToast(cause instanceof Error ? cause.message : "保存失败，请重试"); }
          }}
        />
      )}
      {closureSummaryOpen && closure?.state === "closed" && (
        <ClosureSummaryModal
          caseItem={c}
          closure={closure}
          fallbackConclusion={caseConclusion}
          fallbackFiles={[...(c.caseAttachments ?? []), ...caseWsAtts]}
          onClose={() => setClosureSummaryOpen(false)}
        />
      )}
      {demoOpen && <DemoMode caseItem={c} tasks={tasks} onClose={() => setDemoOpen(false)} />}
      {toastMsg && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-[120] px-4 py-2.5 rounded-lg bg-slate-900 text-white text-sm shadow-xl flex items-center gap-2">
          <CheckCircle2 size={15} className="text-emerald-400" /> {toastMsg}
        </div>
      )}
      {commentOpen && <CommentDrawer caseName={c.name} caseCode={c.code} onClose={() => setCommentOpen(false)} />}
    </div>
  );
}

function DataTab({ caseItem, onRequestDownload }: { caseItem?: any; onRequestDownload?: (file: string) => void }) {
  const caseAtts = (caseItem?.caseAttachments ?? []) as { name: string; kind: string; url?: string }[];
  const efaTickets = useEfaTickets(caseItem?.id).forCase;
  const files = [
    { name: "datalog_lotA.csv", size: "12.4 MB", from: "张伟", time: "04-22 10:20" },
    { name: "shmoo_vddmin.xlsx", size: "3.1 MB", from: "李娜", time: "04-22 09:10" },
    { name: "FIB_edge01.png", size: "2.7 MB", from: "陈磊", time: "04-22 10:24" },
    { name: "SEM_crosssection_02.png", size: "3.8 MB", from: "陈磊", time: "04-22 10:30" },
  ];

  // R04 · 下载权限：仅 Owner / 参与人 / 任务执行者可直接下载，否则需申请
  const isOwner = caseItem?.owner === currentUser.name;
  const isParticipant = (caseItem?.participants ?? []).some((p: any) => p.name === currentUser.name);
  const isExecutor = caseItem ? flattenTasks(caseItem.tasks).some((x) => x.task.owner === currentUser.name) : false;
  const [guest, setGuest] = useState(false); // 模拟无权限访客，便于演示
  const canDownload = !guest && (isOwner || isParticipant || isExecutor);
  const [requested, setRequested] = useState(false); // #2：按 Case 整体申请
  const request = () => {
    setRequested(true);
    onRequestDownload?.("整个 Case 的全部附件");
  };

  return (
    <div>
      <div className="flex items-center gap-2 mb-3">
        <div className="text-xs text-slate-500">所有原始数据永久关联至 Case，支持多年追溯与复现</div>
        <label className="ml-auto inline-flex items-center gap-1.5 text-[11px] text-slate-500 cursor-pointer">
          <input type="checkbox" checked={guest} onChange={(e) => setGuest(e.target.checked)} className="w-3.5 h-3.5 accent-[#0052D9]" />
          模拟无权限访客
        </label>
      </div>
      {!canDownload && (
        <div className="mb-3 flex items-center gap-3 bg-amber-50 border border-amber-200 rounded-md px-3 py-2">
          <div className="text-[11px] text-amber-700 flex-1 leading-relaxed">
            你非本 Case 的 Owner / 参与人 / 任务执行者，需按 Case 整体向「任务执行者 + Case Owner」申请下载权限。
          </div>
          {requested ? (
            <span className="shrink-0 text-xs text-amber-600">审批中</span>
          ) : (
            <button onClick={request} className="shrink-0 h-7 px-3 rounded-md bg-[#0052D9] text-white text-xs hover:bg-[#003FA8] inline-flex items-center gap-1">
              <Lock size={12} /> 申请下载权限
            </button>
          )}
        </div>
      )}
      <div className="mb-4 rounded-xl border border-violet-200 overflow-hidden">
        <div className="px-3.5 py-2.5 bg-gradient-to-r from-violet-50 to-blue-50 flex items-center gap-2">
          <FlaskConical size={14} className="text-violet-600" />
          <div className="text-xs font-medium text-slate-700">EFA 分析单 · QMS 同步</div>
          <span className="ml-auto text-[11px] text-slate-400">共 {efaTickets.length} 单</span>
        </div>
        {efaTickets.length === 0 ? (
          <div className="px-4 py-5 text-center text-xs text-slate-400 bg-white">暂无 EFA 分析单，可从具体分析任务中发起。</div>
        ) : (
          <div className="divide-y divide-slate-100 bg-white">
            {efaTickets.map((ticket) => (
              <div key={ticket.id} className="px-3.5 py-3 flex items-start gap-3">
                <div className="min-w-[170px]">
                  <div className="font-mono text-[11.5px] font-medium text-[#0052D9] inline-flex items-center gap-1">{ticket.qmsCode} <ExternalLink size={10} /></div>
                  <div className="text-[10.5px] text-slate-400 mt-0.5">{ticket.submittedAt} · {ticket.submittedBy}</div>
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-xs text-slate-700 truncate">来源任务：{ticket.taskTitle}</div>
                  <div className="text-[10.5px] text-slate-400 mt-0.5">{ticket.sample || "—"} · {ticket.failMode || "—"}</div>
                  {ticket.conclusion && <div className="mt-1.5 text-[11px] text-emerald-700 line-clamp-2">回同步：{ticket.conclusion}</div>}
                </div>
                <div className="shrink-0 text-right">
                  <span className={`px-2 py-0.5 rounded border text-[10.5px] ${efaTicketStatusColors[ticket.status]}`}>{ticket.status}</span>
                  {!!ticket.attachments?.length && <div className="mt-1 text-[10px] text-slate-400">附件 {ticket.attachments.length} 个</div>}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      {caseAtts.length > 0 && (
        <div className="mb-3">
          <div className="text-[11px] text-slate-400 mb-1.5">背景附件</div>
          <div className="flex flex-wrap gap-2">
            {caseAtts.map((a, i) => (
              <span key={i} title={a.name} className="inline-flex items-center gap-1.5 p-1.5 pr-2 rounded border border-slate-200 bg-white text-xs text-slate-700 max-w-[200px]">
                {a.url && a.kind === "image" ? (
                  <img src={a.url} alt={a.name} className="w-8 h-8 rounded object-cover shrink-0" />
                ) : (
                  <FileSpreadsheet size={14} className="text-[#00B578] shrink-0" />
                )}
                <span className="truncate">{a.name}</span>
              </span>
            ))}
          </div>
        </div>
      )}
      <div className="grid grid-cols-2 gap-2">
        {files.map((f) => (
          <div
            key={f.name}
            className="flex items-center gap-2 p-2.5 rounded border border-slate-100 hover:border-[#0052D9]/30"
          >
            <FileSpreadsheet size={16} className="text-[#00B578]" />
            <div className="flex-1 min-w-0">
              <div className="text-sm text-slate-800 truncate">{f.name}</div>
              <div className="text-[11px] text-slate-500">
                {f.size} · {f.from} · {f.time}
              </div>
            </div>
            {canDownload ? (
              <button className="text-xs text-[#0052D9] hover:underline shrink-0">下载</button>
            ) : (
              <span className="text-xs text-slate-300 shrink-0 inline-flex items-center gap-1"><Lock size={11} /> 受限</span>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

function RelatedTab({ c }: { c: any }) {
  const related = mockCases.filter((x) => x.id !== c.id).slice(0, 4);
  return (
    <div className="space-y-2">
      <div className="text-xs text-slate-500 mb-2">
        基于标题、产品、失效模式智能推荐；点击可查看或发起合并
      </div>
      {related.map((s) => (
        <div
          key={s.id}
          className="flex items-center gap-2 p-3 rounded border border-slate-100 hover:border-[#0052D9]/30"
        >
          <span className={`px-1.5 py-0.5 rounded text-[10px] border ${levelColors[s.level]}`}>
            {s.level}
          </span>
          <CaseProductPill caseItem={s} compact />
          <span className="font-mono text-xs text-slate-500">{s.code}</span>
          <span className="text-sm text-slate-800 flex-1 truncate">{s.name}</span>
          <span className="text-xs text-slate-500">{s.status}</span>
          <button className="text-xs text-[#0052D9] hover:underline">建议合并</button>
        </div>
      ))}
    </div>
  );
}

function InfoItem({ label, value }: { label: string; value: string }) {
  return (
    <div className="p-3 rounded bg-slate-50/60 border border-slate-100">
      <div className="text-xs text-slate-400">{label}</div>
      <div className="text-sm text-slate-700 mt-1 leading-relaxed">{value}</div>
    </div>
  );
}

export function CaseCloudDocModal({
  caseItem,
  canEdit = false,
  initialConclusion,
  initialProcess,
  initialAttachments,
  onClose,
  onSave,
}: {
  caseItem: any;
  canEdit?: boolean;
  initialConclusion: string;
  initialProcess: string;
  initialAttachments: { name: string; kind: "pdf" | "image" | "sheet" | "file"; url?: string }[];
  onClose: () => void;
  onSave: (payload: { conclusion: string; process: string; attachments: any[] }) => void;
}) {
  const [conclusion, setConclusion] = useState(initialConclusion);
  const [process, setProcess] = useState(initialProcess);
  const [attachments, setAttachments] = useState(initialAttachments || []);
  const [saveError, setSaveError] = useState("");
  const [uploading, setUploading] = useState(false);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50" onClick={onClose}>
      <div
        className="w-[860px] max-h-[88vh] bg-white rounded-xl shadow-2xl border border-slate-200 flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="px-5 py-3 border-b border-slate-100 flex items-center gap-2">
          <FileSpreadsheet size={14} className="text-[#0052D9]" />
          <h3 className="text-slate-900">{caseItem.name} · 结论与分析 WS 文档</h3>
          <span className="text-[11px] text-slate-400">{canEdit ? "编辑后保存并回写" : "只读"}</span>
          <button onClick={onClose} className="ml-auto text-slate-400 hover:text-slate-600">
            <X size={16} />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          {/* R09a：主 Case 描述带入 WS 背景 */}
          <section>
            <div className="text-xs text-slate-600 mb-1.5">背景（取自主 Case 描述）</div>
            <div className="p-3 text-sm rounded-md border border-slate-200 bg-slate-50/60 text-slate-700 leading-relaxed whitespace-pre-wrap">
              {caseItem.background || "—"}
              {caseItem.impact ? `\n\n影响：${caseItem.impact}` : ""}
            </div>
          </section>
          <section>
            <div className="text-xs text-slate-600 mb-1.5">结论（一句话写清）</div>
            <textarea
              value={conclusion}
              readOnly={!canEdit}
              onChange={(e) => setConclusion(e.target.value)}
              placeholder="如：Pattern P_ICC2_07 在低压下过激，叠加 wafer 边缘工艺偏移。"
              className="w-full min-h-[80px] p-3 text-sm rounded-md border border-slate-200 outline-none focus:border-[#0052D9]"
            />
          </section>
          <section>
            <div className="flex items-center mb-1.5">
              <div className="text-xs text-slate-600">分析过程（一级标题「分析过程」下，每个 sub 用二级标题 标题@OWNER@DUEDAY）</div>
              <button
                disabled={!canEdit}
                onClick={() => setProcess(buildAnalysisProcess(caseItem))}
                className="ml-auto text-[11px] text-[#0052D9] hover:underline inline-flex items-center gap-1"
              >
                <Sparkles size={12} /> 按结构生成
              </button>
            </div>
            <textarea
              value={process}
              readOnly={!canEdit}
              onChange={(e) => setProcess(e.target.value)}
              placeholder="点「按结构生成」自动汇总各 sub case 的分析过程，或手动编辑..."
              className="w-full min-h-[260px] p-3 text-sm rounded-md border border-slate-200 outline-none focus:border-[#0052D9] leading-relaxed font-mono"
            />
          </section>
          {/* R11：结案文件作为附件贴在 WS 里 */}
          <section>
            <div className="text-xs text-slate-600 mb-1.5">附件（结案文件 / 支撑材料）</div>
            {canEdit ? <AttachmentInput value={attachments} onChange={setAttachments} onUploadingChange={setUploading} /> : <TaskAttachmentList attachments={attachments} />}
          </section>
        </div>
        <div className="px-5 py-3 border-t border-slate-100 flex items-center justify-end gap-2">
          {saveError && <p role="alert" className="mr-auto text-xs text-red-600">{saveError}</p>}
          <button
            onClick={onClose}
            className="h-8 px-3 text-sm rounded-md border border-slate-200 text-slate-600 hover:bg-slate-50"
          >
            关闭
          </button>
          <button
            disabled={!canEdit || uploading}
            onClick={() => { try { onSave({ conclusion: conclusion.trim(), process, attachments }); } catch (cause) { setSaveError(cause instanceof Error ? cause.message : "保存失败"); } }}
            className="h-8 px-3.5 text-sm rounded-md bg-[#0052D9] text-white hover:bg-[#003FA8] inline-flex items-center gap-1"
          >
            <CheckCircle2 size={13} /> 保存并回写
          </button>
        </div>
      </div>
    </div>
  );
}
