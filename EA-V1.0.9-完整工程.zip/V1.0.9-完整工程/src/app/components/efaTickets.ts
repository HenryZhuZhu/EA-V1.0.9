// EFA/QMS mock integration store: EA analysis request → QMS EFA ticket → result sync back.
import { useEffect, useState } from "react";
import { EfaTicket, EfaTicketStatus } from "./data";

const KEY = "ea_efa_tickets_v1";

export interface EfaTicketEntry extends EfaTicket {
  caseId: string;
  taskId: string;
  taskTitle: string;
}

let cache: EfaTicketEntry[] | null = null;
const listeners = new Set<() => void>();

function load(): EfaTicketEntry[] {
  if (cache) return cache;
  try {
    const raw = typeof localStorage !== "undefined" ? localStorage.getItem(KEY) : null;
    cache = raw ? JSON.parse(raw) : [];
  } catch {
    cache = [];
  }
  return cache ?? [];
}

function persist() {
  try {
    if (cache) localStorage.setItem(KEY, JSON.stringify(cache));
  } catch {}
}

function emit() {
  persist();
  listeners.forEach((fn) => fn());
}

export function submitEfaTicket(input: {
  caseId: string;
  taskId: string;
  taskTitle: string;
  sample?: string;
  failMode?: string;
  request?: string;
  submittedBy?: string;
}): EfaTicketEntry {
  const now = new Date();
  const stamp = now.toISOString().slice(2, 10).replace(/-/g, "");
  const serial = String(Date.now()).slice(-5);
  const entry: EfaTicketEntry = {
    id: `efa-${Date.now()}`,
    qmsCode: `QMS-EFA-${stamp}-${serial}`,
    caseId: input.caseId,
    taskId: input.taskId,
    taskTitle: input.taskTitle,
    sample: input.sample,
    failMode: input.failMode,
    request: input.request,
    status: "已提交",
    submittedAt: now.toISOString().slice(0, 16).replace("T", " "),
    submittedBy: input.submittedBy,
  };
  cache = [entry, ...load()];
  emit();
  return entry;
}

export function updateEfaTicket(id: string, patch: Partial<EfaTicketEntry>) {
  cache = load().map((ticket) => ticket.id === id ? { ...ticket, ...patch } : ticket);
  emit();
}

export function setEfaTicketStatus(id: string, status: EfaTicketStatus) {
  updateEfaTicket(id, { status });
}

export function syncEfaTicketResult(id: string, conclusion: string) {
  updateEfaTicket(id, {
    status: "已回同步",
    conclusion,
    syncedAt: new Date().toISOString().slice(0, 16).replace("T", " "),
    attachments: [
      { name: `${id}-EFA分析报告.pdf`, kind: "pdf" },
      { name: `${id}-定位图片.png`, kind: "image" },
    ],
  });
}

export function ticketsOfCase(caseId: string): EfaTicketEntry[] {
  return load().filter((ticket) => ticket.caseId === caseId);
}

export function ticketOfTask(caseId: string, taskId: string): EfaTicketEntry | undefined {
  return load().find((ticket) => ticket.caseId === caseId && ticket.taskId === taskId);
}

export function useEfaTickets(caseId?: string) {
  const [, setTick] = useState(0);
  useEffect(() => {
    const listener = () => setTick((value) => value + 1);
    listeners.add(listener);
    return () => { listeners.delete(listener); };
  }, []);
  return {
    all: [...load()],
    forCase: caseId ? ticketsOfCase(caseId) : [],
    getForTask: (taskId: string) => caseId ? ticketOfTask(caseId, taskId) : undefined,
    submit: submitEfaTicket,
    setStatus: setEfaTicketStatus,
    syncResult: syncEfaTicketResult,
  };
}
