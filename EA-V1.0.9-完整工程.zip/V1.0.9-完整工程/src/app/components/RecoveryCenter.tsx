import { useState } from "react";
import { UsersRound } from "lucide-react";
import { currentUser, directors, orgRole, ownerToDepartment, vp } from "./data";
import { TaskDialog } from "./TaskDialog";

export const RECOVERY_DEMO_ACTOR_KEY = "ea_v109_demo_actor";
export const recoveryDemoPeople = [...new Set(["张伟", ...Object.keys(ownerToDepartment), ...directors.map(item => item.name), vp])];
export function restoreRecoveryDemoActor() {
  try {
    const name = localStorage.getItem(RECOVERY_DEMO_ACTOR_KEY);
    if (!name || !recoveryDemoPeople.includes(name)) return;
    currentUser.name = name;
    currentUser.department = ownerToDepartment[name] ?? directors.find(item => item.name === name)?.departments[0] ?? "管理层";
    currentUser.role = orgRole(name) === "工程师" ? "Engineer" : orgRole(name);
    currentUser.avatar = name.slice(0, 1);
  } catch {}
}

export function RecoveryCenter({ onOpenCase, onOpenTask, onOpenStandaloneTask }: { onOpenCase: (id: string) => void; onOpenTask?: (caseId: string, taskId: string) => void; onOpenStandaloneTask?: (id: string) => void }) {
  const [open, setOpen] = useState(false);
  const [actor, setActor] = useState(currentUser.name);
  const [error, setError] = useState("");
  return <>
    <button type="button" title="仅原型演示使用" className="inline-flex h-8 shrink-0 items-center gap-1 rounded-md border border-dashed border-slate-200 bg-white px-2 text-xs text-slate-400" onClick={() => setOpen(true)}><UsersRound size={14} />演示身份</button>
    {open && <TaskDialog title="演示身份" description="仅用于本地原型角色切换，不是正式用户的业务入口或登录授权。" onClose={() => setOpen(false)} footer={<button className="rounded border border-slate-200 px-3 py-1.5 text-xs" onClick={() => setOpen(false)}>关闭</button>}>
      <div className="mb-5 flex items-center gap-2 border-b border-slate-100 pb-4"><label className="text-xs text-slate-500" htmlFor="recovery-demo-actor">演示身份</label><select id="recovery-demo-actor" value={actor} onChange={event => setActor(event.target.value)} className="h-8 rounded border border-slate-200 px-2 text-xs">{recoveryDemoPeople.map(name => <option key={name}>{name}</option>)}</select><button disabled={actor === currentUser.name} className="h-8 rounded bg-[#0052D9] px-3 text-xs text-white disabled:opacity-40" onClick={() => { try { localStorage.setItem(RECOVERY_DEMO_ACTOR_KEY, actor); window.location.reload(); } catch { setError("身份切换保存失败，请重试。"); } }}>切换并刷新</button><span className="text-[10px] text-slate-400">请先保存未提交内容</span></div>
      {error && <p role="alert" className="mb-2 text-xs text-red-600">{error}</p>}
    </TaskDialog>}
  </>;
}