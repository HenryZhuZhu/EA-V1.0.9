import { useEffect, useMemo, useState } from "react";
import { createPortal } from "react-dom";
import { CalendarDays, Search, Users, X } from "lucide-react";
import {
  CaseItem,
  flattenTasks,
  levelColors,
  mockCases,
  mockProducts,
  TaskNode,
} from "./data";
import { useClosures } from "./closures";

type Grain = "day" | "week" | "month";
type CaseRecord = { caseItem: CaseItem; closedAt: string; hours: number };
type TaskRecord = { caseItem: CaseItem; task: TaskNode; hours: number };
type ChartFilter = {
  periodKey?: string;
  periodLabel?: string;
  product?: string;
  department?: string;
} | null;
type ResultTab = "cases" | "members";

interface Props {
  onOpenCase: (id: string) => void;
}

const DAY = 86400000;
const COLORS = [
  "#0052D9",
  "#00A4C7",
  "#16A085",
  "#E19A26",
  "#D94B52",
  "#7C6EDB",
  "#64748B",
];
const dateText = (date: Date) =>
  `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
const parseDate = (value: string) => new Date(`${value.slice(0, 10)}T00:00:00`);
const addDays = (date: Date, days: number) =>
  new Date(date.getTime() + days * DAY);
const hoursBetween = (start: string, end: string) =>
  Math.max(
    12,
    (parseDate(end).getTime() - parseDate(start).getTime()) / 3600000,
  );
const average = (values: number[]) =>
  values.length
    ? values.reduce((sum, value) => sum + value, 0) / values.length
    : 0;
const hash = (value: string) =>
  [...value].reduce((sum, char) => sum + char.charCodeAt(0), 0);
const formatHours = (hours: number) => ({
  hours: `${hours.toFixed(1)}h`,
  days: `${(hours / 24).toFixed(1)}天`,
});

function bucketStart(date: Date, grain: Grain) {
  const copy = new Date(date);
  if (grain === "week") {
    const day = copy.getDay();
    copy.setDate(copy.getDate() - (day === 0 ? 6 : day - 1));
  }
  if (grain === "month") copy.setDate(1);
  return copy;
}
function nextBucket(date: Date, grain: Grain) {
  const copy = new Date(date);
  if (grain === "month") copy.setMonth(copy.getMonth() + 1);
  else copy.setDate(copy.getDate() + (grain === "week" ? 7 : 1));
  return copy;
}
function bucketKey(value: string | Date, grain: Grain) {
  const start = bucketStart(
    typeof value === "string" ? parseDate(value) : value,
    grain,
  );
  return grain === "month" ? dateText(start).slice(0, 7) : dateText(start);
}
function bucketLabel(key: string, grain: Grain) {
  if (grain === "month") {
    const [year, month] = key.split("-");
    return `${year.slice(2)}/${Number(month)}`;
  }
  const [, month, day] = key.split("-");
  return `${Number(month)}/${Number(day)}`;
}
function arcPath(startAngle: number, endAngle: number) {
  const center = 64;
  const radius = 46;
  const point = (angle: number) => {
    const radians = ((angle - 90) * Math.PI) / 180;
    return {
      x: center + radius * Math.cos(radians),
      y: center + radius * Math.sin(radians),
    };
  };
  const start = point(startAngle);
  const end = point(endAngle);
  return `M ${start.x} ${start.y} A ${radius} ${radius} 0 ${endAngle - startAngle > 180 ? 1 : 0} 1 ${end.x} ${end.y}`;
}
function realClosedAt(item: CaseItem, closureAt?: string) {
  if (closureAt) return closureAt.slice(0, 10);
  if (item.status === "已关闭") return item.updatedAt.slice(0, 10);
  return undefined;
}
function taskHours(task: TaskNode) {
  const history = task.statusHistory || [];
  if (history.length > 1)
    return hoursBetween(history[0].at, history.at(-1)!.at);
  return 24 + (hash(task.id || task.title) % 180);
}
function groupTasksByCase(tasks: TaskRecord[], cases: CaseRecord[]) {
  return cases
    .map((caseRecord) => ({
      caseRecord,
      tasks: tasks.filter(
        (record) => record.caseItem.id === caseRecord.caseItem.id,
      ),
    }))
    .filter((group) => group.tasks.length > 0);
}
function departmentOfTask(task: TaskNode) {
  return task.department || "未归属";
}
function productMeta(code: string) {
  return mockProducts.find(
    (product) => product.code === code || product.id === code,
  );
}

export function ProductAnalysisRestored({ onOpenCase }: Props) {
  const closures = useClosures();
  const allProducts = useMemo(
    () => [
      ...new Set(
        mockCases
          .map((item) => item.product)
          .filter((value) => value && value !== "—"),
      ),
    ],
    [],
  );
  const [selectedProducts, setSelectedProducts] = useState<string[]>(
    allProducts.slice(0, 1),
  );
  const [grain, setGrain] = useState<Grain>("day");
  const [customOpen, setCustomOpen] = useState(false);
  const businessAnchor = useMemo(
    () =>
      mockCases
        .map((item) => item.updatedAt.slice(0, 10))
        .sort()
        .at(-1) || dateText(new Date()),
    [],
  );
  const [start, setStart] = useState(
    dateText(addDays(parseDate(businessAnchor), -89)),
  );
  const [end, setEnd] = useState(businessAnchor);
  const [draftStart, setDraftStart] = useState(start);
  const [draftEnd, setDraftEnd] = useState(end);
  const [chartFilter, setChartFilter] = useState<ChartFilter>(null);
  const [tab, setTab] = useState<ResultTab>("cases");
  const [query, setQuery] = useState("");
  const [expandedCase, setExpandedCase] = useState("");
  const [expandedMember, setExpandedMember] = useState<string | null>(null);
  const [toolsHost, setToolsHost] = useState<HTMLElement | null>(null);
  useEffect(
    () =>
      setToolsHost(document.getElementById("product-analysis-global-tools")),
    [],
  );

  const productCases = useMemo(
    () => mockCases.filter((item) => selectedProducts.includes(item.product)),
    [selectedProducts],
  );
  const records = useMemo<CaseRecord[]>(
    () =>
      productCases.flatMap((item, caseIndex) => {
        const actual = realClosedAt(item, closures.get(item.id)?.closedAt);
        if (actual)
          return [
            {
              caseItem: item,
              closedAt: actual,
              hours: hoursBetween(item.createdAt, actual),
            },
          ];
        return Array.from({ length: 4 }, (_, historyIndex) => ({
          caseItem: item,
          closedAt: dateText(
            addDays(
              parseDate(businessAnchor),
              -(historyIndex * 21 + caseIndex * 4) % 88,
            ),
          ),
          hours: 144 + (hash(`${item.id}-${historyIndex}`) % 900),
        }));
      }),
    [productCases, closures, businessAnchor],
  );
  const rangedRecords = records.filter(
    (record) => record.closedAt >= start && record.closedAt <= end,
  );

  const productRows = useMemo(
    () =>
      allProducts
        .map((product) => {
          const rows = mockCases
            .filter((item) => item.product === product)
            .flatMap((item, caseIndex) => {
              const actual = realClosedAt(
                item,
                closures.get(item.id)?.closedAt,
              );
              return actual
                ? [
                    {
                      caseItem: item,
                      hours: hoursBetween(item.createdAt, actual),
                    },
                  ]
                : Array.from({ length: 4 }, (_, index) => ({
                    caseItem: item,
                    hours: 144 + (hash(`${item.id}-${index}`) % 900),
                  }));
            });
          return {
            product,
            cases: rows,
            averageHours: average(rows.map((row) => row.hours)),
          };
        })
        .sort((left, right) => right.averageHours - left.averageHours),
    [allProducts, closures],
  );

  const taskRecords = useMemo<TaskRecord[]>(
    () =>
      productCases.flatMap((caseItem) => {
        const tasks = flattenTasks(caseItem.tasks).map(({ task }) => task);
        const analysisTasks: TaskNode[] = tasks.length
          ? tasks
          : (caseItem.departments?.length ? caseItem.departments : ["PTE"]).map(
              (department, index) => ({
                id: `${caseItem.id}-${department}`,
                title: `${department} 分析任务`,
                owner:
                  index === 0
                    ? caseItem.owner
                    : caseItem.participants?.find(
                        (person) => person.department === department,
                      )?.name || caseItem.owner,
                department,
                urgency: caseItem.urgency,
                progress: 100,
                status: "已完成",
              }),
            );
        return analysisTasks.map((task) => ({
          caseItem,
          task,
          hours: taskHours(task),
        }));
      }),
    [productCases],
  );

  const buckets = useMemo(() => {
    const map = new Map<string, CaseRecord[]>();
    rangedRecords.forEach((record) => {
      const key = bucketKey(record.closedAt, grain);
      map.set(key, [...(map.get(key) || []), record]);
    });
    const result: {
      key: string;
      label: string;
      records: CaseRecord[];
      average: number | null;
    }[] = [];
    let cursor = bucketStart(parseDate(start), grain);
    const rangeEnd = parseDate(end);
    while (cursor <= rangeEnd && result.length < 400) {
      const key = bucketKey(cursor, grain);
      const rows = map.get(key) || [];
      result.push({
        key,
        label: bucketLabel(key, grain),
        records: rows,
        average: rows.length ? average(rows.map((row) => row.hours)) : null,
      });
      cursor = nextBucket(cursor, grain);
    }
    return result;
  }, [rangedRecords, grain, start, end]);

  const productSeries = useMemo(
    () =>
      selectedProducts.map((product, index) => {
        const averages = new Map<string, number>();
        const grouped = new Map<string, CaseRecord[]>();
        rangedRecords
          .filter((record) => record.caseItem.product === product)
          .forEach((record) => {
            const key = bucketKey(record.closedAt, grain);
            grouped.set(key, [...(grouped.get(key) || []), record]);
          });
        grouped.forEach((rows, key) =>
          averages.set(key, average(rows.map((row) => row.hours))),
        );
        return {
          product,
          color: COLORS[index % COLORS.length],
          values: buckets.map((bucket) => averages.get(bucket.key) ?? null),
        };
      }),
    [selectedProducts, rangedRecords, grain, buckets],
  );

  const periodRecords = rangedRecords.filter(
    (record) =>
      (!chartFilter?.periodKey ||
        bucketKey(record.closedAt, grain) === chartFilter.periodKey) &&
      (!chartFilter?.product ||
        record.caseItem.product === chartFilter.product),
  );
  const periodCaseIds = new Set(
    periodRecords.map((record) => record.caseItem.id),
  );
  const periodTasks = taskRecords.filter((record) =>
    periodCaseIds.has(record.caseItem.id),
  );
  const departmentMap = new Map<
    string,
    {
      records: TaskRecord[];
      caseIds: Set<string>;
      members: Set<string>;
      totalHours: number;
    }
  >();
  periodTasks.forEach((record) => {
    const name = departmentOfTask(record.task);
    const row = departmentMap.get(name) || {
      records: [],
      caseIds: new Set<string>(),
      members: new Set<string>(),
      totalHours: 0,
    };
    row.records.push(record);
    row.caseIds.add(record.caseItem.id);
    row.members.add(record.task.owner);
    row.totalHours += record.hours;
    departmentMap.set(name, row);
  });
  const departments = [...departmentMap.entries()]
    .map(([name, value]) => ({
      name,
      ...value,
      percentage: 0,
      averageHours: value.totalHours / Math.max(value.caseIds.size, 1),
    }))
    .sort((left, right) => right.caseIds.size - left.caseIds.size);
  const totalDepartmentCases =
    departments.reduce((sum, item) => sum + item.caseIds.size, 0) || 1;
  departments.forEach((item) => {
    item.percentage = (item.caseIds.size / totalDepartmentCases) * 100;
  });
  const filteredTasks = chartFilter?.department
    ? periodTasks.filter(
        (record) => departmentOfTask(record.task) === chartFilter.department,
      )
    : periodTasks;
  const filteredIds = new Set(
    filteredTasks.map((record) => record.caseItem.id),
  );
  const highCaseMap = new Map<string, CaseRecord>();
  periodRecords
    .filter(
      (record) =>
        !chartFilter?.department || filteredIds.has(record.caseItem.id),
    )
    .forEach((record) => {
      const current = highCaseMap.get(record.caseItem.id);
      if (!current || record.hours > current.hours)
        highCaseMap.set(record.caseItem.id, record);
    });
  const highCases = [...highCaseMap.values()].sort(
    (left, right) => right.hours - left.hours,
  );
  const memberMap = new Map<
    string,
    { cases: Map<string, CaseRecord>; tasks: TaskRecord[]; totalHours: number }
  >();
  filteredTasks.forEach((record) => {
    const row = memberMap.get(record.task.owner) || {
      cases: new Map<string, CaseRecord>(),
      tasks: [],
      totalHours: 0,
    };
    const caseRecord = periodRecords.find(
      (item) => item.caseItem.id === record.caseItem.id,
    );
    if (caseRecord) row.cases.set(record.caseItem.id, caseRecord);
    row.tasks.push(record);
    row.totalHours += record.hours;
    memberMap.set(record.task.owner, row);
  });
  const members = [...memberMap.entries()]
    .map(([name, value]) => ({
      name,
      cases: [...value.cases.values()].sort((a, b) => b.hours - a.hours),
      tasks: value.tasks.sort((a, b) => b.hours - a.hours),
      caseCount: value.cases.size,
      taskCount: value.tasks.length,
      averageHours: value.totalHours / Math.max(value.cases.size, 1),
    }))
    .sort((a, b) => b.averageHours - a.averageHours);
  const normalizedQuery = query.trim().toLowerCase();
  const visibleCases = highCases.filter(
    (record) =>
      !normalizedQuery ||
      `${record.caseItem.code} ${record.caseItem.name} ${record.caseItem.owner} ${flattenTasks(
        record.caseItem.tasks,
      )
        .map(({ task }) => `${task.title} ${task.owner}`)
        .join(" ")}`
        .toLowerCase()
        .includes(normalizedQuery),
  );
  const visibleMembers = members.filter(
    (member) =>
      !normalizedQuery ||
      `${member.name} ${member.cases.map((item) => item.caseItem.name).join(" ")} ${member.tasks.map((item) => item.task.title).join(" ")}`
        .toLowerCase()
        .includes(normalizedQuery),
  );

  const title =
    selectedProducts.length === 1
      ? selectedProducts[0]
      : `${selectedProducts.length} 个产品`;
  const subtitle =
    selectedProducts.length === 1
      ? `${productMeta(selectedProducts[0])?.platform || "—"} · ${productMeta(selectedProducts[0])?.family || "—"}`
      : selectedProducts.join(" / ");
  const averageHours = average(rangedRecords.map((record) => record.hours));
  const averageText = formatHours(averageHours);
  const chartWidth = 640;
  const chartHeight = 150;
  const left = 40;
  const right = 12;
  const top = 12;
  const bottom = 28;
  const chartValues = productSeries
    .flatMap((series) => series.values)
    .filter((value): value is number => value !== null);
  const maxValue = Math.max(24, ...chartValues) * 1.12;
  const x = (index: number) =>
    left +
    (buckets.length <= 1
      ? (chartWidth - left - right) / 2
      : (index * (chartWidth - left - right)) / (buckets.length - 1));
  const y = (value: number) =>
    top + ((maxValue - value) * (chartHeight - top - bottom)) / maxValue;
  const labelStep = Math.max(1, Math.ceil(buckets.length / 7));
  let angle = 0;
  const filterLabel = chartFilter
    ? [
        chartFilter.product,
        chartFilter.periodLabel,
        chartFilter.department && `部门 · ${chartFilter.department}`,
      ]
        .filter(Boolean)
        .join(" · ")
    : "";
  const toggleDepartment = (department: string) =>
    setChartFilter((current) =>
      current?.department === department
        ? current.periodKey
          ? { periodKey: current.periodKey, periodLabel: current.periodLabel }
          : null
        : { ...(current || {}), department },
    );

  const sparkPoints = (row: { cases: { hours: number }[] }) => {
    const values = row.cases
      .slice(0, 6)
      .map((item) => item.hours)
      .reverse();
    if (!values.length) return "0,12 70,12";
    if (values.length === 1) values.push(values[0]);
    const min = Math.min(...values);
    const max = Math.max(...values);
    return values
      .map(
        (value, index) =>
          `${(index / Math.max(values.length - 1, 1)) * 70},${max === min ? 12 : 22 - ((value - min) / (max - min)) * 18}`,
      )
      .join(" ");
  };

  const globalTools = (
    <div className="relative flex items-center gap-2">
      <div className="inline-flex items-center rounded-lg border border-slate-200 bg-slate-50 p-0.5">
        {(
          [
            ["day", "按天"],
            ["week", "按周"],
            ["month", "按月"],
          ] as const
        ).map(([key, label]) => (
          <button
            key={key}
            onClick={() => {
              setGrain(key);
              setChartFilter(null);
            }}
            className={`h-7 rounded-md px-3 text-xs ${grain === key ? "bg-white text-[#0052D9] shadow-sm" : "text-slate-500"}`}
          >
            {label}
          </button>
        ))}
      </div>
      <button
        onClick={() => {
          setDraftStart(start);
          setDraftEnd(end);
          setCustomOpen((open) => !open);
        }}
        className={`inline-flex h-8 items-center gap-1.5 rounded-lg border px-3 text-xs ${customOpen ? "border-[#0052D9]/40 bg-[#0052D9]/5 text-[#0052D9]" : "border-slate-200 bg-white text-slate-600"}`}
      >
        <CalendarDays size={13} />
        分析范围
      </button>
      {customOpen && (
        <div className="absolute right-0 top-full z-30 mt-2 w-[340px] rounded-xl border border-slate-200 bg-white p-4 shadow-xl">
          <div className="grid grid-cols-2 gap-3">
            <label className="text-[11px] text-slate-500">
              开始日期
              <input
                type="date"
                value={draftStart}
                onChange={(event) => setDraftStart(event.target.value)}
                className="mt-1 h-9 w-full rounded-md border border-slate-200 px-2 text-xs outline-none focus:border-[#0052D9]"
              />
            </label>
            <label className="text-[11px] text-slate-500">
              结束日期
              <input
                type="date"
                value={draftEnd}
                onChange={(event) => setDraftEnd(event.target.value)}
                className="mt-1 h-9 w-full rounded-md border border-slate-200 px-2 text-xs outline-none focus:border-[#0052D9]"
              />
            </label>
          </div>
          <div className="mt-4 flex justify-end gap-2">
            <button
              onClick={() => setCustomOpen(false)}
              className="h-8 rounded-md border border-slate-200 px-3 text-xs text-slate-600"
            >
              取消
            </button>
            <button
              disabled={!draftStart || !draftEnd || draftStart > draftEnd}
              onClick={() => {
                setStart(draftStart);
                setEnd(draftEnd);
                setCustomOpen(false);
                setChartFilter(null);
              }}
              className="h-8 rounded-md bg-[#0052D9] px-3 text-xs text-white disabled:opacity-40"
            >
              应用
            </button>
          </div>
        </div>
      )}
    </div>
  );

  return (
    <>
      {toolsHost && createPortal(globalTools, toolsHost)}
      <div className="grid min-h-[650px] grid-cols-[300px_minmax(0,1fr)] gap-4">
        <aside className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-[0_1px_2px_rgba(15,23,42,0.04)]">
          <div className="border-b border-slate-100 px-3 py-3">
            <div className="text-[11px] font-medium text-slate-600">
              产品选择
            </div>
            <div className="mt-1 text-[10px] text-slate-400">
              可选择一个或多个产品进行合并分析
            </div>
          </div>
          <div className="max-h-[680px] overflow-y-auto p-2">
            {productRows.map((row) => {
              const selected = selectedProducts.includes(row.product);
              const value = formatHours(row.averageHours);
              const points = sparkPoints(row);
              const last = points.split(" ").at(-1)?.split(",") || [70, 12];
              return (
                <button
                  key={row.product}
                  type="button"
                  aria-pressed={selected}
                  onClick={() => {
                    setSelectedProducts((current) =>
                      current.includes(row.product)
                        ? current.length === 1
                          ? current
                          : current.filter((item) => item !== row.product)
                        : [...current, row.product],
                    );
                    setChartFilter(null);
                  }}
                  className={`mb-1 w-full rounded-lg border px-3 py-3 text-left transition-colors ${selected ? "border-[#0052D9]/25 bg-[#0052D9]/[0.07]" : "border-transparent hover:bg-slate-50"}`}
                >
                  <div className="flex items-center gap-2">
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-sm font-semibold text-slate-800">
                        {row.product}
                      </span>
                      <span className="mt-1 block text-[10.5px] text-slate-400">
                        {productMeta(row.product)?.platform || "—"} ·{" "}
                        {productMeta(row.product)?.family || "—"}
                      </span>
                    </span>
                    <svg
                      width="72"
                      height="24"
                      viewBox="0 0 72 24"
                      className="shrink-0"
                    >
                      <polyline
                        points={points}
                        fill="none"
                        stroke={selected ? "#0052D9" : "#94A3B8"}
                        strokeWidth="1.6"
                        strokeLinejoin="round"
                        strokeLinecap="round"
                      />
                      <circle
                        cx={Number(last[0])}
                        cy={Number(last[1])}
                        r="2"
                        fill={selected ? "#0052D9" : "#94A3B8"}
                      />
                    </svg>
                    <span className="w-[66px] shrink-0 text-right">
                      <span className="block text-sm font-semibold tabular-nums text-slate-800">
                        {value.hours}
                      </span>
                      <span className="text-[10px] text-slate-400">
                        {value.days}
                      </span>
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </aside>

        <section className="overflow-visible rounded-xl border border-slate-200 bg-white shadow-[0_1px_2px_rgba(15,23,42,0.04)]">
          <div className="flex h-[76px] items-center gap-6 border-b border-slate-100 px-5">
            <div className="min-w-0 flex-1">
              <div className="truncate text-base font-semibold text-slate-900">
                {title}
              </div>
              <div className="mt-1 text-[11px] text-slate-400">{subtitle}</div>
            </div>
            <div className="h-8 w-px bg-slate-100" />
            <div className="text-right">
              <div className="text-[10.5px] text-slate-400">平均结案时间</div>
              <div className="mt-0.5 flex items-baseline justify-end gap-1">
                <span className="text-xl font-bold text-slate-900">
                  {averageText.hours}
                </span>
                <span className="text-xs text-slate-400">
                  {averageText.days}
                </span>
              </div>
            </div>
            <div className="h-8 w-px bg-slate-100" />
            <div className="text-right">
              <div className="text-[10.5px] text-slate-400">已结案 Case</div>
              <div className="mt-0.5 text-xl font-bold text-slate-900">
                {rangedRecords.length}
              </div>
            </div>
          </div>

          <div className="grid min-h-[574px] grid-cols-[46%_54%]">
            <div className="border-r border-slate-100 px-5 py-4">
              <div>
                <div className="text-sm font-semibold text-slate-800">
                  Case 平均耗时趋势
                </div>
                <div className="mt-1 text-[10.5px] text-slate-400">
                  点击时间点联动右侧结果 · {start} 至 {end}
                </div>
              </div>
              <div className="mt-2 flex flex-wrap gap-x-3 gap-y-1">
                {productSeries.map((series) => (
                  <span
                    key={series.product}
                    className="inline-flex items-center gap-1 text-[9.5px] text-slate-500"
                  >
                    <i
                      className="h-2 w-2 rounded-full"
                      style={{ backgroundColor: series.color }}
                    />
                    {series.product}
                  </span>
                ))}
              </div>
              <div className="mt-1 h-[180px]">
                <svg
                  viewBox={`0 0 ${chartWidth} ${chartHeight}`}
                  preserveAspectRatio="none"
                  className="h-full w-full overflow-visible"
                >
                  {[0, 1, 2, 3].map((tick) => {
                    const value = (maxValue * (3 - tick)) / 3;
                    const py = top + (tick * (chartHeight - top - bottom)) / 3;
                    return (
                      <g key={tick}>
                        <line
                          x1={left}
                          y1={py}
                          x2={chartWidth - right}
                          y2={py}
                          stroke="#E2E8F0"
                          strokeDasharray="3 3"
                        />
                        <text x="2" y={py + 3} fill="#94A3B8" fontSize="9">
                          {(value / 24).toFixed(0)}天
                        </text>
                      </g>
                    );
                  })}
                  {productSeries.map((series) => {
                    const points = series.values
                      .map((value, index) =>
                        value === null ? null : `${x(index)},${y(value)}`,
                      )
                      .filter(Boolean)
                      .join(" ");
                    return (
                      <g key={series.product}>
                        {points && (
                          <polyline
                            points={points}
                            fill="none"
                            stroke={series.color}
                            strokeWidth="2.4"
                            strokeLinejoin="round"
                            strokeLinecap="round"
                          />
                        )}
                        {series.values.map(
                          (value, index) =>
                            value !== null && (
                              <circle
                                key={`${series.product}-${buckets[index].key}`}
                                cx={x(index)}
                                cy={y(value)}
                                r={
                                  chartFilter?.periodKey ===
                                    buckets[index].key &&
                                  chartFilter.product === series.product
                                    ? 6
                                    : 4
                                }
                                fill={series.color}
                                stroke={
                                  chartFilter?.periodKey ===
                                    buckets[index].key &&
                                  chartFilter.product === series.product
                                    ? "#9ABBF0"
                                    : "white"
                                }
                                strokeWidth={
                                  chartFilter?.periodKey ===
                                    buckets[index].key &&
                                  chartFilter.product === series.product
                                    ? 4
                                    : 2
                                }
                                className="cursor-pointer"
                                data-product-point={series.product}
                                onClick={() =>
                                  setChartFilter((current) =>
                                    current?.periodKey === buckets[index].key &&
                                    current.product === series.product
                                      ? current.department
                                        ? { department: current.department }
                                        : null
                                      : {
                                          ...(current || {}),
                                          periodKey: buckets[index].key,
                                          periodLabel: buckets[index].label,
                                          product: series.product,
                                        },
                                  )
                                }
                              />
                            ),
                        )}
                      </g>
                    );
                  })}
                  {buckets.map(
                    (bucket, index) =>
                      (index % labelStep === 0 ||
                        index === buckets.length - 1) && (
                        <text
                          key={`l-${bucket.key}`}
                          x={x(index)}
                          y={chartHeight - 6}
                          textAnchor="middle"
                          fill="#64748B"
                          fontSize="9"
                        >
                          {bucket.label}
                        </text>
                      ),
                  )}
                </svg>
              </div>
              <div className="mt-4 border-t border-slate-100 pt-4">
                <div className="text-sm font-semibold text-slate-800">
                  部门任务耗时占比
                </div>
                <div className="mt-1 text-[10.5px] text-slate-400">
                  点击环状图或图例联动右侧结果
                </div>
                <div className="relative mx-auto mt-3 h-[280px] w-[280px]">
                  <svg viewBox="0 0 128 128" className="h-full w-full">
                    <circle
                      cx="64"
                      cy="64"
                      r="46"
                      fill="none"
                      stroke="#EEF2F6"
                      strokeWidth="18"
                    />
                    {departments.map((department, index) => {
                      const sweep = (department.percentage / 100) * 359.5;
                      const begin = angle;
                      const finish = angle + sweep;
                      angle = finish;
                      return (
                        <path
                          key={department.name}
                          d={arcPath(begin, finish)}
                          fill="none"
                          stroke={COLORS[index % COLORS.length]}
                          strokeWidth={
                            chartFilter?.department === department.name
                              ? 22
                              : 18
                          }
                          opacity={
                            chartFilter?.department &&
                            chartFilter.department !== department.name
                              ? 0.35
                              : 1
                          }
                          className="cursor-pointer"
                          onClick={() => toggleDepartment(department.name)}
                        />
                      );
                    })}
                  </svg>
                  <div className="pointer-events-none absolute inset-0 grid place-items-center text-center">
                    <div>
                      <div className="text-[11px] text-slate-400">
                        产品平均结案耗时
                      </div>
                      <div className="mt-1 text-3xl font-bold text-slate-900">
                        {averageText.hours}
                      </div>
                      <div className="text-xs text-slate-400">
                        {averageText.days}
                      </div>
                      <div className="mt-1 text-[10px] text-slate-400">
                        {title}
                      </div>
                    </div>
                  </div>
                </div>
                <div className="mt-2 flex flex-wrap justify-center gap-x-3 gap-y-1.5">
                  {departments.map((department, index) => (
                    <button
                      key={department.name}
                      onClick={() => toggleDepartment(department.name)}
                      className={`inline-flex items-center gap-1 text-[9.5px] ${chartFilter?.department === department.name ? "font-medium text-[#0052D9]" : "text-slate-500"}`}
                    >
                      <span
                        className="h-2 w-2 rounded-sm"
                        style={{
                          backgroundColor: COLORS[index % COLORS.length],
                        }}
                      />
                      {department.name} {department.percentage.toFixed(0)}%
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex min-h-0 min-w-0 flex-col px-5 py-4">
              <div className="flex min-w-0 items-center border-b border-slate-100 pb-3">
                <div className="inline-flex shrink-0 rounded-lg bg-slate-100 p-0.5">
                  <button
                    onClick={() => setTab("cases")}
                    className={`h-7 rounded-md px-3 text-[11px] ${tab === "cases" ? "bg-white font-medium text-[#0052D9] shadow-sm" : "text-slate-500"}`}
                  >
                    高耗时 Case
                  </button>
                  <button
                    onClick={() => setTab("members")}
                    className={`h-7 rounded-md px-3 text-[11px] ${tab === "members" ? "bg-white font-medium text-[#0052D9] shadow-sm" : "text-slate-500"}`}
                  >
                    成员平均耗时
                  </button>
                </div>
                {chartFilter && (
                  <button
                    onClick={() => setChartFilter(null)}
                    title="清除图表筛选"
                    className="ml-2 inline-flex h-7 max-w-[150px] items-center gap-1 rounded-md border border-[#0052D9]/20 bg-[#0052D9]/5 px-2 text-[10px] text-[#0052D9]"
                  >
                    <span className="truncate">{filterLabel}</span>
                    <X size={10} />
                  </button>
                )}
                <div className="relative ml-auto min-w-[80px] flex-1 max-w-[190px]">
                  <Search
                    size={12}
                    className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400"
                  />
                  <input
                    value={query}
                    onChange={(event) => setQuery(event.target.value)}
                    placeholder="搜索 Case / 工程师 / 任务"
                    className="h-7 w-full rounded-md border border-slate-200 bg-white pl-7 pr-2 text-[10.5px] outline-none focus:border-[#0052D9]"
                  />
                </div>
                <span className="ml-3 shrink-0 text-[10.5px] text-slate-400">
                  {tab === "cases"
                    ? `${visibleCases.length} Case`
                    : `${visibleMembers.length} 人`}
                </span>
              </div>
              <div className="min-h-0 flex-1 overflow-y-auto">
                {tab === "cases"
                  ? visibleCases.map((record, index) => {
                      const value = formatHours(record.hours);
                      const expanded = expandedCase === record.caseItem.id;
                      const caseTasks = filteredTasks.filter(
                        (item) => item.caseItem.id === record.caseItem.id,
                      );
                      return (
                        <div
                          key={record.caseItem.id}
                          className="border-b border-slate-100"
                        >
                          <button
                            onClick={() =>
                              setExpandedCase(
                                expanded ? "" : record.caseItem.id,
                              )
                            }
                            className="flex min-h-[64px] w-full items-center gap-3 px-3 py-2.5 text-left hover:bg-slate-50/70"
                          >
                            <span
                              className={`grid h-5 w-5 shrink-0 place-items-center rounded-md text-[12px] font-bold ${index < 3 ? "bg-[#0052D9]/8 text-[#0052D9]" : "bg-slate-100 text-slate-400"}`}
                            >
                              {index + 1}
                            </span>
                            <span className="min-w-0 flex-1">
                              <span className="flex min-w-0 items-center gap-2">
                                <span
                                  className={`shrink-0 rounded border px-1 py-0.5 text-[9px] ${levelColors[record.caseItem.level]}`}
                                >
                                  {record.caseItem.level}
                                </span>
                                <span className="font-mono text-[10.5px] text-slate-400">
                                  {record.caseItem.code}
                                </span>
                                <span className="truncate text-[11px] text-slate-400">
                                  {record.caseItem.owner}
                                </span>
                              </span>
                              <span className="mt-1 block truncate text-[13px] font-medium text-slate-700">
                                {record.caseItem.name}
                              </span>
                            </span>
                            <span className="w-20 shrink-0 text-right">
                              <span className="block text-sm font-semibold text-slate-900">
                                {value.hours}
                              </span>
                              <span className="text-[10px] text-slate-400">
                                {value.days}
                              </span>
                            </span>
                          </button>
                          {expanded && (
                            <div className="mb-3 ml-11 mr-3 rounded-lg border border-slate-100 bg-slate-50/70 p-2.5">
                              {caseTasks.length ? (
                                caseTasks.map((item) => {
                                  const taskValue = formatHours(item.hours);
                                  return (
                                    <div
                                      key={item.task.id}
                                      className="flex items-center gap-3 border-b border-slate-100 py-2 last:border-b-0"
                                    >
                                      <span className="min-w-0 flex-1">
                                        <span className="block truncate text-[11px] font-medium text-slate-700">
                                          {item.task.owner} ·{" "}
                                          {item.task.department}
                                        </span>
                                        <span className="block truncate text-[10px] text-slate-400">
                                          {item.task.title}
                                        </span>
                                      </span>
                                      <span className="text-right text-[10px] text-slate-600">
                                        {taskValue.hours}
                                        <br />
                                        <small className="text-slate-400">
                                          {taskValue.days}
                                        </small>
                                      </span>
                                    </div>
                                  );
                                })
                              ) : (
                                <div className="py-3 text-center text-[11px] text-slate-400">
                                  暂无任务数据
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      );
                    })
                  : visibleMembers.map((member) => {
                      const value = formatHours(member.averageHours);
                      const showTasks = expandedMember === member.name;
                      const taskGroups = groupTasksByCase(
                        member.tasks,
                        member.cases,
                      );
                      return (
                        <div
                          key={member.name}
                          className="border-b border-slate-100"
                        >
                          <div className="flex items-center gap-3 px-1 py-3">
                            <span className="grid h-7 w-7 place-items-center rounded-full bg-[#0052D9]/10 text-[10px] text-[#0052D9]">
                              {member.name.slice(-2)}
                            </span>
                            <span className="min-w-0 flex-1 text-[12px] font-medium text-slate-700">
                              {member.name}
                            </span>
                            <button
                              onClick={() =>
                                setExpandedMember(showTasks ? null : member.name)
                              }
                              className={`h-7 rounded-md border px-2 text-[10px] ${showTasks ? "border-[#0052D9]/30 bg-[#0052D9]/5 text-[#0052D9]" : "border-slate-200 text-slate-500"}`}
                            >
                              {member.taskCount} 任务
                            </button>
                            <span className="w-16 text-right">
                              <span className="block text-sm font-semibold text-slate-900">
                                {value.hours}
                              </span>
                              <span className="text-[10px] text-slate-400">
                                {value.days}
                              </span>
                            </span>
                          </div>
                          {showTasks && (
                            <div className="mb-3 ml-10 space-y-2">
                              {taskGroups.map(({ caseRecord, tasks }) => {
                                const caseValue = formatHours(caseRecord.hours);
                                return (
                                  <div
                                    key={caseRecord.caseItem.id}
                                    className="overflow-hidden rounded-lg border border-slate-100 bg-slate-50/70"
                                  >
                                    <button
                                      type="button"
                                      onClick={() =>
                                        onOpenCase(caseRecord.caseItem.id)
                                      }
                                      className="flex w-full items-center gap-3 border-b border-slate-100 bg-white/80 px-3 py-2 text-left hover:bg-white"
                                    >
                                      <span className="min-w-0 flex-1">
                                        <span className="block truncate font-mono text-[10px] text-slate-400">
                                          {caseRecord.caseItem.code}
                                        </span>
                                        <span className="mt-0.5 block truncate text-[11px] font-medium text-slate-700">
                                          {caseRecord.caseItem.name}
                                        </span>
                                      </span>
                                      <span className="shrink-0 text-right">
                                        <span className="block text-[11px] font-semibold text-slate-700">
                                          {caseValue.hours}
                                        </span>
                                        <span className="text-[9px] text-slate-400">
                                          实际耗时 · {caseValue.days}
                                        </span>
                                      </span>
                                    </button>
                                    <div className="px-2">
                                      {tasks.map((item) => (
                                        <div
                                          key={`${item.caseItem.id}-${item.task.id}`}
                                          className="flex items-center gap-3 border-b border-slate-100 px-2 py-2 last:border-b-0"
                                        >
                                          <span className="min-w-0 flex-1">
                                            <span className="block truncate font-mono text-[10.5px] text-slate-500">
                                              {item.task.code || item.task.id}
                                            </span>
                                            <span className="block truncate text-[10px] text-slate-400">
                                              {item.task.title}
                                            </span>
                                          </span>
                                          <span className="text-[10px] text-slate-600">
                                            {formatHours(item.hours).hours}
                                          </span>
                                        </div>
                                      ))}
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          )}
                        </div>
                      );
                    })}
                {tab === "cases" && !visibleCases.length && (
                  <div className="grid h-56 place-items-center text-sm text-slate-400">
                    无匹配 Case
                  </div>
                )}
                {tab === "members" && !visibleMembers.length && (
                  <div className="grid h-56 place-items-center text-sm text-slate-400">
                    <span className="inline-flex items-center gap-2">
                      <Users size={16} />
                      无匹配成员
                    </span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </section>
      </div>
    </>
  );
}
