import { flattenTasks, type CaseItem, type Product, type TaskNode } from "./data";
import type { ClosureRecord } from "./closures";
import { taskRemainingDays, type BusinessReference } from "./taskWorkbenchModel";
import { activeCustomRules, customSelectionRules, matchesCustomRules, type CustomFilterRecord, type CustomFilterRule } from "./caseCustomFilters";
import type { CustomFieldDefinition } from "./caseCustomFilterFields";

export const CASE_WORKBENCH_STATUSES = ["进行中", "验证中", "已结案"] as const;
export type CaseWorkbenchStatus = typeof CASE_WORKBENCH_STATUSES[number];
export type CaseWorkbenchSource = "all" | "fanout";
export type CaseWorkbenchScope = "mine" | "participating" | "created" | "department" | "subscribed";
export type CaseWorkbenchSort = "urgency" | "level" | "progress" | "updated";
export const CASE_WORKBENCH_SORT_OPTIONS = [
  { value: "urgency", label: "紧迫度" },
  { value: "level", label: "层级" },
  { value: "progress", label: "进度(低→高)" },
  { value: "updated", label: "最近更新" },
] as const satisfies readonly { value: CaseWorkbenchSort; label: string }[];
export const CASE_SCOPE_LABELS: Record<CaseWorkbenchScope, string> = {
  mine: "我负责", participating: "我参与", created: "我分派", department: "我部门", subscribed: "我订阅",
};
export interface CaseWorkbenchRow {
  id: string;
  record: CaseItem;
  status: CaseWorkbenchStatus;
  fanout: boolean;
  sourceCase?: CaseItem;
  subscribed: boolean;
  business: BusinessReference[];
  taskCount: number;
  creators?: string[];
  progress?: number;
  updatedAt: string;
  closedAt?: string;
  recovery?: ClosureRecord["recovery"];
}
export interface CaseWorkbenchFilters {
  level?: string;
  urgency?: string;
  product?: string;
  department?: string;
  creator: string;
  // 旧组合业务筛选只作快照兼容，当前工作台不读取这些字段。
  businessKind: "all" | "none" | "产品" | "Project";
  businessKey: string;
}
export interface CaseWorkbenchView {
  source: CaseWorkbenchSource;
  scope: CaseWorkbenchScope;
  filters: CaseWorkbenchFilters;
  expanded: boolean;
  page: number;
  customRules?: CustomFilterRule[];
  statusFilter?: CaseWorkbenchStatus | "全部";
  // 未选择时保留旧默认排序；已结案仍优先实际结案时间。
  // 显式 updated 始终按最新真实活动 updatedAt，不使用 closedAt 优先规则。
  sortBy?: CaseWorkbenchSort;
}
export interface CaseWorkbenchState {
  status: CaseWorkbenchStatus;
  views: Record<CaseWorkbenchStatus, CaseWorkbenchView>;
  fanout?: boolean;
  fanoutView?: CaseWorkbenchView;
}
export type CaseWorkbenchAction =
  | { type: "status"; status: CaseWorkbenchStatus }
  | { type: "status-linked"; status: CaseWorkbenchStatus }
  | { type: "fanout" }
  | { type: "fanout-linked" }
  | { type: "fanout-status"; status: CaseWorkbenchStatus | "全部" }
  | { type: "custom-rules"; rules: CustomFilterRule[] }
  | { type: "source"; source: CaseWorkbenchSource }
  | { type: "scope"; scope: CaseWorkbenchScope }
  | { type: "filters"; patch: Partial<CaseWorkbenchFilters> }
  | { type: "expanded" }
  | { type: "sort"; sortBy: string }
  | { type: "page"; page: number }
  | { type: "reset" };
export const DEFAULT_CASE_FILTERS: CaseWorkbenchFilters = { level: "全部", urgency: "全部", product: "全部", department: "全部", businessKind: "all", businessKey: "", creator: "全部" };
export const CASE_DIMENSION_FILTERS = [{ key: "level", label: "层级" }, { key: "urgency", label: "紧急程度" }, { key: "product", label: "产品" }, { key: "department", label: "部门" }, { key: "creator", label: "创建 / 分派人" }] as const;
export function normalizeCaseWorkbenchFilters(filters: CaseWorkbenchFilters): CaseWorkbenchFilters {
  return { ...DEFAULT_CASE_FILTERS, level: filters.level || "全部", urgency: filters.urgency || "全部", product: filters.product || "全部", department: filters.department || "全部", creator: filters.creator || "全部" };
}
export function caseWorkbenchFilterCount(filters: CaseWorkbenchFilters) {
  const normalized = normalizeCaseWorkbenchFilters(filters);
  return CASE_DIMENSION_FILTERS.filter(field => normalized[field.key] !== "全部").length;
}

// 调用方传入本次读取的当前任务树；仅真实创建人和有编码执行任务的显式分派人。
// 保留原始人员值作精确匹配，绝不以 Case/任务负责人或思路节点补齐。
export function caseCreators(c: Partial<Pick<CaseItem, "createdBy" | "tasks">>): string[] {
  return [...new Set([c.createdBy, ...flattenTasks(c.tasks ?? [])
    .filter(({ task }) => Boolean(task.code)).map(({ task }) => task.supervisor)]
    .filter((name): name is string => typeof name === "string" && Boolean(name.trim())))];
}

export function caseWorkbenchStatus(c: Pick<CaseItem, "status">, closure?: Pick<ClosureRecord, "state">): CaseWorkbenchStatus {
  if (closure?.state === "closed" || ["已关闭", "已结案", "已归档"].includes(c.status)) return "已结案";
  if (closure?.state === "rootcause" || c.status === "验证中") return "验证中";
  // 旧演示值只作为历史兼容归入进行中；Case 工作台不存在第四种状态。
  return "进行中";
}
function dateTime(value: string | undefined): number | undefined {
  if (!value) return undefined;
  // Date.parse 会把 2 月 31 日滚到 3 月；与截止日期一样校验真实日历。
  if (/^\d{4}-\d{2}-\d{2}/.test(value) && taskRemainingDays({ dueDate: value }) === undefined) return undefined;
  const time = Date.parse(value);
  return Number.isFinite(time) ? time : undefined;
}
function latestDate(values: (string | undefined)[]) {
  return values.filter((v): v is string => dateTime(v) !== undefined)
    .sort((a, b) => dateTime(b)! - dateTime(a)!)[0] ?? "";
}
export function buildCaseWorkbenchRows(cases: CaseItem[], options: {
  products: Pick<Product, "id" | "code" | "name">[];
  closure: (id: string) => ClosureRecord | undefined;
  isSubscribed: (id: string) => boolean;
  loadTree: (c: CaseItem) => TaskNode[];
}): CaseWorkbenchRow[] {
  const byId = new Map(cases.map(c => [c.id, c]));
  return cases.map(c => {
    const closure = options.closure(c.id);
    const productIds = new Set([...(c.productIds ?? []), ...(c.productId ? [c.productId] : [])]);
    if (!productIds.size) {
      const exact = options.products.find(p => p.id === c.product || p.code === c.product);
      if (exact) productIds.add(exact.id);
    }
    const business: BusinessReference[] = [...productIds].map(id => {
      const product = options.products.find(p => p.id === id);
      return { key: `产品:${id}`, kind: "产品", name: product ? `${product.code} · ${product.name}` : id, origin: "case" };
    });
    if (c.projectName?.trim()) business.push({ key: `Project:name:${c.projectName.trim()}`, kind: "Project", name: c.projectName.trim(), origin: "case", nameOnly: true });
    const closedAt = dateTime(closure?.closedAt) !== undefined ? closure?.closedAt : undefined;
    const tasks = options.loadTree(c);
    const actions = flattenTasks(tasks).filter(({ task }) => Boolean(task.code));
    const progresses = actions.map(({ task }) => task.progress).filter(value => typeof value === "number" && Number.isFinite(value));
    const progress = progresses.length ? progresses.reduce((sum, value) => sum + Math.max(0, Math.min(100, value)), 0) / progresses.length : undefined;
    return {
      id: c.id, record: c, status: caseWorkbenchStatus(c, closure),
      fanout: Boolean(c.fanoutSourceCaseId) || c.source === "fanout验证",
      sourceCase: c.fanoutSourceCaseId && c.fanoutSourceCaseId !== c.id ? byId.get(c.fanoutSourceCaseId) : undefined,
      subscribed: options.isSubscribed(c.id), business, creators: caseCreators({ createdBy: c.createdBy, tasks }),
      taskCount: actions.length, ...(progress !== undefined ? { progress } : {}),
      updatedAt: latestDate([c.updatedAt, closure?.rootCauseAt, closedAt]), closedAt, recovery: closure?.recovery,
    };
  });
}
export function caseBelongsTo(row: CaseWorkbenchRow, scope: CaseWorkbenchScope, actor: { name: string; department: string }, departments: Record<string, string>) {
  const c = row.record;
  if (scope === "mine") return c.owner === actor.name;
  if (scope === "participating") return c.owner !== actor.name && Boolean(c.participants?.some(p => p.name === actor.name));
  if (scope === "created") return c.createdBy === actor.name && c.owner !== actor.name;
  if (scope === "department") return Boolean(actor.department) && (Boolean(c.departments?.includes(actor.department)) || departments[c.owner] === actor.department);
  return row.subscribed;
}
export function createCaseWorkbenchState(scope: CaseWorkbenchScope = "mine"): CaseWorkbenchState {
  const view = (): CaseWorkbenchView => ({ source: "all", scope, filters: { ...DEFAULT_CASE_FILTERS }, expanded: false, page: 1 });
  return { status: "进行中", views: { 进行中: view(), 验证中: view(), 已结案: view() }, fanout: false, fanoutView: createFanoutView() };
}
function createFanoutView(): CaseWorkbenchView {
  return { source: "fanout", scope: "mine", filters: { ...DEFAULT_CASE_FILTERS }, expanded: false, page: 1, statusFilter: "全部" };
}
export function currentCaseWorkbenchView(state: CaseWorkbenchState): CaseWorkbenchView {
  return state.fanout ? state.fanoutView ?? createFanoutView() : state.views[state.status];
}
function isCaseWorkbenchSort(value: unknown): value is CaseWorkbenchSort {
  return CASE_WORKBENCH_SORT_OPTIONS.some(option => option.value === value);
}
export function caseWorkbenchSortBy(state: CaseWorkbenchState): CaseWorkbenchSort {
  const value = currentCaseWorkbenchView(state).sortBy;
  return isCaseWorkbenchSort(value) ? value : !state.fanout && state.status === "已结案" ? "updated" : "urgency";
}
export function updateCaseWorkbenchState(state: CaseWorkbenchState, action: CaseWorkbenchAction): CaseWorkbenchState {
  if (action.type === "status") return state.status === action.status && !state.fanout ? state : { ...state, status: action.status, fanout: false };
  if (action.type === "status-linked") {
    if (state.status === action.status && !state.fanout) return state;
    const current = currentCaseWorkbenchView(state), target = state.views[action.status];
    return { ...state, status: action.status, fanout: false, views: { ...state.views, [action.status]: { ...target, scope: current.scope, filters: { ...current.filters }, customRules: current.customRules ? [...current.customRules] : undefined, page: 1 } } };
  }
  if (action.type === "fanout") return state.fanout ? state : { ...state, fanout: true, fanoutView: state.fanoutView ?? createFanoutView() };
  if (action.type === "fanout-linked") {
    if (state.fanout) return state;
    const current = currentCaseWorkbenchView(state), target = state.fanoutView ?? createFanoutView();
    return { ...state, fanout: true, fanoutView: { ...target, scope: current.scope, filters: { ...current.filters }, customRules: current.customRules ? [...current.customRules] : undefined, page: 1 } };
  }
  const current = currentCaseWorkbenchView(state);
  let next: CaseWorkbenchView;
  switch (action.type) {
    case "fanout-status":
      if (!state.fanout || (action.status !== "全部" && !CASE_WORKBENCH_STATUSES.includes(action.status))) return state;
      next = { ...current, statusFilter: action.status, page: 1 }; break;
    case "custom-rules": next = { ...current, customRules: customSelectionRules(action.rules), page: 1 }; break;
    case "source": if (action.source === current.source) return state; next = { ...current, source: action.source, page: 1 }; break;
    case "scope": if (action.scope === current.scope) return state; next = { ...current, scope: action.scope, page: 1 }; break;
    case "filters": next = { ...current, filters: normalizeCaseWorkbenchFilters({ ...current.filters, ...action.patch }), page: 1 }; break;
    case "expanded": next = { ...current, expanded: !current.expanded }; break;
    case "sort":
      if (!isCaseWorkbenchSort(action.sortBy) || action.sortBy === current.sortBy) return state;
      if (action.sortBy === caseWorkbenchSortBy(state) && (state.fanout || state.status !== "已结案")) return state;
      // 首次显式选择 updated 也须记录，区分历史结案默认排序；重复选择才是 no-op。
      next = { ...current, sortBy: action.sortBy, page: 1 }; break;
    case "page": next = { ...current, page: Number.isFinite(action.page) ? Math.max(1, Math.floor(action.page)) : 1 }; break;
    case "reset": next = { ...current, filters: { ...DEFAULT_CASE_FILTERS }, page: 1, ...(current.customRules ? { customRules: [] } : {}), ...(state.fanout ? { statusFilter: "全部" as const } : {}) }; break;
  }
  return state.fanout ? { ...state, fanoutView: next } : { ...state, views: { ...state.views, [state.status]: next } };
}
function matchesFilters(row: CaseWorkbenchRow, filters: CaseWorkbenchFilters) {
  if (filters.level !== "全部" && row.record.level !== filters.level) return false;
  if (filters.urgency !== "全部" && row.record.urgency !== filters.urgency) return false;
  if (filters.product !== "全部" && row.record.product !== filters.product) return false;
  if (filters.creator !== "全部" && !(row.creators ?? caseCreators(row.record)).includes(filters.creator)) return false;
  return filters.department === "全部" || Boolean(row.record.departments?.includes(filters.department!));
}
const PRIORITY: Record<string, number> = { 非常紧急: 0, 紧急: 1, 一般: 2, 不紧急: 3 };
const LEVEL: Record<string, number> = { L0: 0, L1: 1, L2: 2, L3: 3 };
const compare = (a: number, b: number) => a === b ? 0 : a < b ? -1 : 1;
const rank = (ranks: Record<string, number>, value: string) => Object.prototype.hasOwnProperty.call(ranks, value) ? ranks[value] : Infinity;
const stableKey = (a: CaseWorkbenchRow, b: CaseWorkbenchRow) => a.id && b.id ? a.id.localeCompare(b.id) : a.id ? -1 : b.id ? 1 : 0;
export function selectCaseWorkbench(rows: CaseWorkbenchRow[], state: CaseWorkbenchState, actor: { name: string; department: string }, departments: Record<string, string>, now = new Date(), custom?: { records: CustomFilterRecord[]; fields: readonly CustomFieldDefinition[] }) {
  const view = currentCaseWorkbenchView(state);
  const filters = normalizeCaseWorkbenchFilters(view.filters);
  const counts = Object.fromEntries(CASE_WORKBENCH_STATUSES.map(status => [status, rows.filter(r => !r.fanout && r.status === status && caseBelongsTo(r, "mine", actor, departments)).length])) as Record<CaseWorkbenchStatus, number>;
  const fanoutCount = rows.filter(r => r.fanout && caseBelongsTo(r, "mine", actor, departments)).length;
  const appliedCustomRules = custom ? activeCustomRules(customSelectionRules(view.customRules ?? []), custom.fields) : [];
  const customById = new Map(custom?.records.map(record => [record.caseData.id, record]));
  const matchesCurrentConditions = (row: CaseWorkbenchRow) => matchesFilters(row, filters) && caseBelongsTo(row, view.scope, actor, departments) && (!appliedCustomRules.length || Boolean(customById.has(row.id) && matchesCustomRules(customById.get(row.id)!, appliedCustomRules, custom!.fields)));
  const viewCounts = Object.fromEntries(CASE_WORKBENCH_STATUSES.map(status => [status, rows.filter(r => !r.fanout && r.status === status && matchesCurrentConditions(r)).length])) as Record<CaseWorkbenchStatus, number>;
  const viewFanoutCount = rows.filter(r => r.fanout && matchesCurrentConditions(r)).length;
  // Fanout 仅在顶部独立视图出现；普通三状态下所有人员视角、候选与计数均排除它。
  // 旧 source 快照仍不形成隐藏条件，也不更改原始记录或历史。
  const inSource = rows.filter(r => state.fanout ? r.fanout && (!view.statusFilter || view.statusFilter === "全部" || r.status === view.statusFilter) : !r.fanout && r.status === state.status);
  const common = inSource.filter(r => matchesFilters(r, filters) && (!appliedCustomRules.length || Boolean(customById.has(r.id) && matchesCustomRules(customById.get(r.id)!, appliedCustomRules, custom!.fields))));
  const scopeCounts = Object.fromEntries((Object.keys(CASE_SCOPE_LABELS) as CaseWorkbenchScope[]).map(scope => [scope, common.filter(r => caseBelongsTo(r, scope, actor, departments)).length])) as Record<CaseWorkbenchScope, number>;
  const candidates = inSource.filter(r => caseBelongsTo(r, view.scope, actor, departments));
  const selected = common.filter(r => caseBelongsTo(r, view.scope, actor, departments));
  const sortBy = caseWorkbenchSortBy(state);
  const legacyDefault = !isCaseWorkbenchSort(view.sortBy);
  const time = (r: CaseWorkbenchRow) => dateTime(legacyDefault && !state.fanout ? r.closedAt || r.updatedAt : r.updatedAt) ?? -Infinity;
  selected.sort((a, b) => {
    const urgency = compare(rank(PRIORITY, a.record.urgency), rank(PRIORITY, b.record.urgency));
    const due = compare(taskRemainingDays(a.record, now) ?? Infinity, taskRemainingDays(b.record, now) ?? Infinity);
    const updated = compare(time(b), time(a));
    if (legacyDefault && !state.fanout && state.status === "已结案") return updated || urgency || stableKey(a, b);
    switch (sortBy) {
      case "level": return compare(rank(LEVEL, a.record.level), rank(LEVEL, b.record.level)) || stableKey(a, b);
      case "progress": return compare(Number.isFinite(a.progress) ? a.progress! : Infinity, Number.isFinite(b.progress) ? b.progress! : Infinity) || stableKey(a, b);
      case "updated": return updated || stableKey(a, b);
      default: return urgency || due || updated || stableKey(a, b);
    }
  });
  const total = selected.length, pages = Math.max(1, Math.ceil(total / 8)), page = Math.min(view.page, pages);
  return { counts, fanoutCount, viewCounts, viewFanoutCount, scopeCounts, candidates, filters, appliedCustomRules, sortBy, rows: selected.slice((page - 1) * 8, page * 8), total, page, pages };
}