import { useRef, useState } from "react";
import { CheckCircle2 } from "lucide-react";
import { TaskDialog } from "./TaskDialog";

export function StandaloneTaskWorkspace({ title, description, canEdit, initialConclusion, initialProcess, onClose, onSave }: {
  title: string;
  description: string;
  canEdit: boolean;
  initialConclusion: string;
  initialProcess: string;
  onClose: () => void;
  onSave: (document: { conclusion: string; analysisProcess: string }) => void;
}) {
  const [conclusion, setConclusion] = useState(initialConclusion);
  const [analysisProcess, setAnalysisProcess] = useState(initialProcess);
  const [error, setError] = useState("");
  const [confirmDiscard, setConfirmDiscard] = useState(false);
  const saving = useRef(false);
  const dirty = conclusion !== initialConclusion || analysisProcess !== initialProcess;
  const close = () => { if (canEdit && dirty) setConfirmDiscard(true); else onClose(); };

  return <TaskDialog wide title="Workspace 文档" description={`${title} · ${canEdit ? "编辑后点击保存并回写；保存文档不会完成任务。" : "只读查看，当前任务不可编辑。"}`} onClose={close} footer={<>
    <button type="button" onClick={close} className="h-9 rounded-md border border-slate-200 bg-white px-4 text-xs text-slate-600 hover:bg-slate-50">{canEdit ? "取消" : "关闭"}</button>
    {canEdit && <button type="button" onClick={() => {
      if (saving.current) return;
      saving.current = true;
      try { onSave({ conclusion, analysisProcess }); onClose(); }
      catch (reason) { setError(reason instanceof Error ? reason.message : "文档保存失败，请重试。"); }
      finally { saving.current = false; }
    }} className="inline-flex h-9 items-center gap-1.5 rounded-md bg-[#0052D9] px-4 text-xs font-medium text-white hover:bg-[#003FA8]"><CheckCircle2 size={14} />保存并回写</button>}
  </>}>
    <div className="space-y-5">
      <section><h3 className="mb-1.5 text-xs text-slate-500">任务说明</h3><p className="whitespace-pre-wrap break-words rounded-md border border-slate-200 bg-slate-50/60 p-3 text-sm leading-relaxed text-slate-600">{description || "—"}</p></section>
      <label className="block text-xs text-slate-600">任务结论 <span className="ml-1 text-[11px] text-slate-400">完成任务时必填，可先保存过程</span><textarea aria-label="Workspace 任务结论" readOnly={!canEdit} value={conclusion} onChange={(event) => { setConclusion(event.target.value); setError(""); setConfirmDiscard(false); }} placeholder="用一句话概括处理结果与结论…" className="mt-2 min-h-[80px] w-full resize-y rounded-md border border-slate-200 p-3 text-sm leading-relaxed outline-none focus:border-[#0052D9] read-only:bg-slate-50" /></label>
      <label className="block text-xs text-slate-600">分析过程 <span className="ml-1 text-[11px] text-slate-400">记录处理步骤、对照数据与判断依据</span><textarea aria-label="Workspace 分析过程" readOnly={!canEdit} value={analysisProcess} onChange={(event) => { setAnalysisProcess(event.target.value); setError(""); setConfirmDiscard(false); }} placeholder="记录任务执行过程、检查结果、遇到的问题与处理方式…" className="mt-2 min-h-[260px] w-full resize-y rounded-md border border-slate-200 p-3 text-sm leading-7 outline-none focus:border-[#0052D9] read-only:bg-slate-50" /></label>
      {error && <p role="alert" className="rounded-md bg-red-50 px-3 py-2 text-xs text-red-600">{error}</p>}
      {confirmDiscard && <div role="alert" className="flex items-center gap-3 rounded-lg border border-amber-200 bg-amber-50 px-3 py-3 text-xs text-amber-800"><span className="mr-auto">有未保存的文档修改，是否放弃？</span><button type="button" onClick={() => setConfirmDiscard(false)} className="shrink-0 rounded border border-amber-200 bg-white px-2 py-1">继续编辑</button><button type="button" onClick={onClose} className="shrink-0 rounded border border-amber-200 bg-white px-2 py-1">放弃修改</button></div>}
    </div>
  </TaskDialog>;
}