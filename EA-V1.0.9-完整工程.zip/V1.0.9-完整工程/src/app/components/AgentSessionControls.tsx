import { useId, useState } from "react";
import * as Popover from "@radix-ui/react-popover";
import * as Dialog from "@radix-ui/react-dialog";
import { ChevronDown, Folder, FolderOpen, History, Layers3, MessageSquarePlus, MoreHorizontal, PanelLeftClose, PanelLeftOpen, Pencil, Plus, Trash2, X } from "lucide-react";
import type { AgentConversation } from "./useAgentConversation";

export function agentSessionTimeGroup(updatedAt: string, now = new Date()): string {
  const updated = new Date(updatedAt);
  if (Number.isNaN(updated.getTime())) return "更早";
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const sessionDay = new Date(updated.getFullYear(), updated.getMonth(), updated.getDate()).getTime();
  const elapsedDays = Math.floor((today - sessionDay) / 86400000);
  if (elapsedDays <= 0) return "今天";
  if (elapsedDays === 1) return "昨天";
  if (elapsedDays <= 7) return "过去 7 天";
  if (elapsedDays <= 30) return "过去 30 天";
  if (updated.getFullYear() === now.getFullYear()) return `${updated.getMonth() + 1} 月`;
  return `${updated.getFullYear()} 年`;
}

export function AgentSessionControls({ conversation, compact = false, sidebar = false, onNavigate, onExpandedChange }: { conversation: AgentConversation; compact?: boolean; sidebar?: boolean; onNavigate?: () => void; onExpandedChange?: (open: boolean) => void }) {
  const [open, setOpen] = useState(false);
  const [collapsedGroups, setCollapsedGroups] = useState<string[]>([]);
  const [draggingSessionId, setDraggingSessionId] = useState<string | null>(null);
  const [dropGroup, setDropGroup] = useState<string | null>(null);
  const [editing, setEditing] = useState<{ id: string; title: string; action: "rename" | "delete" } | null>(null);
  const [groupDialog, setGroupDialog] = useState<{ action: "create" | "rename" | "delete"; previous?: string; value: string } | null>(null);
  const historyId = useId();
  const sessions = [...conversation.sessions].sort((left, right) => right.updatedAt.localeCompare(left.updatedAt));
  const recentSessions = sessions.filter(item => !item.group);
  const timeGroups = [...recentSessions.reduce((groups, item) => { const label = agentSessionTimeGroup(item.updatedAt); groups.set(label, [...(groups.get(label) ?? []), item]); return groups; }, new Map<string, typeof sessions>())].map(([label, items]) => ({ label, sessions: items }));
  const buttonClass = "inline-flex h-8 shrink-0 items-center justify-center gap-1.5 rounded-md border border-slate-200 bg-white px-2 text-xs text-slate-600 hover:bg-slate-50 focus-visible:outline-2 focus-visible:outline-[#0052D9]";
  const openSession = (id: string) => { conversation.openSession(id); if (!sidebar) setOpen(false); onNavigate?.(); };
  const toggleGroup = (group: string) => setCollapsedGroups(current => current.includes(group) ? current.filter(item => item !== group) : [...current, group]);
  const sessionRow = (item: typeof sessions[number]) => <div key={item.id} draggable={!item.group} onDragStart={event => { if (item.group) return; event.dataTransfer.setData("text/plain", item.id); event.dataTransfer.effectAllowed = "move"; setDraggingSessionId(item.id); }} onDragEnd={() => { setDraggingSessionId(null); setDropGroup(null); }} className={`ea-agent-sidebar-session${item.id === conversation.activeSessionId ? " is-active" : ""}${!item.group ? " is-draggable" : ""}${draggingSessionId === item.id ? " is-dragging" : ""}`}>
    <button type="button" aria-current={item.id === conversation.activeSessionId ? "page" : undefined} onClick={() => openSession(item.id)} className="ea-agent-sidebar-session-title"><span title={item.title}>{item.title}</span></button>
    <button type="button" aria-label={`重命名 ${item.title}`} title="重命名" className="ea-agent-sidebar-rename" onClick={() => setEditing({ id: item.id, title: item.title, action: "rename" })}><Pencil size={12} /></button>
    <Popover.Root><Popover.Trigger asChild><button type="button" aria-label={`更多操作 ${item.title}`} title="更多操作" className="ea-agent-sidebar-more"><MoreHorizontal size={15} /></button></Popover.Trigger>
      <Popover.Portal><Popover.Content align="end" side="bottom" sideOffset={4} className="ea-agent-sidebar-menu is-wide">
        <div className="ea-agent-sidebar-menu-label">移动到分组</div>
        {conversation.groups.map(group => <Popover.Close asChild key={group}><button type="button" className="ea-agent-sidebar-menu-item" disabled={item.group === group} onClick={() => conversation.moveSessionToGroup(item.id, group)}>{group}</button></Popover.Close>)}
        {item.group && <Popover.Close asChild><button type="button" className="ea-agent-sidebar-menu-item" onClick={() => conversation.moveSessionToGroup(item.id)}><Layers3 size={14} />移至最近对话</button></Popover.Close>}
        <Popover.Close asChild><button type="button" className="ea-agent-sidebar-menu-item is-danger" onClick={() => setEditing({ id: item.id, title: item.title, action: "delete" })}><Trash2 size={14} />删除</button></Popover.Close>
      </Popover.Content></Popover.Portal>
    </Popover.Root>
  </div>;
  const groupedSection = (label: string, items: typeof sessions, editable = false, collapseKey = label) => {
    const collapsed = collapsedGroups.includes(collapseKey);
    return <section key={collapseKey} aria-label={label} onDragOver={event => { if (!editable || !draggingSessionId) return; event.preventDefault(); event.dataTransfer.dropEffect = "move"; setDropGroup(label); }} onDragLeave={event => { if (!event.currentTarget.contains(event.relatedTarget as Node)) setDropGroup(current => current === label ? null : current); }} onDrop={event => { if (!editable) return; event.preventDefault(); const id = event.dataTransfer.getData("text/plain") || draggingSessionId; if (id) conversation.moveSessionToGroup(id, label); setDraggingSessionId(null); setDropGroup(null); }} className={`ea-agent-sidebar-group ${editable ? "is-dialog-group" : "is-time-group"}${dropGroup === label ? " is-drop-target" : ""}`}>
      <div className="ea-agent-sidebar-group-heading"><button type="button" aria-label={`${collapsed ? "展开" : "收起"}分组 ${label}`} aria-expanded={!collapsed} onClick={() => toggleGroup(collapseKey)}>{editable ? (collapsed ? <Folder size={12} /> : <FolderOpen size={12} />) : <ChevronDown size={12} className={collapsed ? "is-collapsed" : ""} />}<span>{label}</span></button>
        {editable && <Popover.Root><Popover.Trigger asChild><button type="button" aria-label={`管理分组 ${label}`} className="ea-agent-sidebar-group-more"><MoreHorizontal size={12} /></button></Popover.Trigger><Popover.Portal><Popover.Content align="end" sideOffset={4} className="ea-agent-sidebar-menu"><Popover.Close asChild><button type="button" className="ea-agent-sidebar-menu-item" onClick={() => { conversation.newSession(label); onNavigate?.(); }}><MessageSquarePlus size={13} />新建对话</button></Popover.Close><Popover.Close asChild><button type="button" className="ea-agent-sidebar-menu-item" onClick={() => setGroupDialog({ action: "rename", previous: label, value: label })}><Pencil size={13} />重命名</button></Popover.Close><Popover.Close asChild><button type="button" className="ea-agent-sidebar-menu-item is-danger" onClick={() => setGroupDialog({ action: "delete", previous: label, value: label })}><Trash2 size={13} />删除分组</button></Popover.Close></Popover.Content></Popover.Portal></Popover.Root>}
      </div>
      {!collapsed && <div className="ea-agent-sidebar-group-items">{items.map(sessionRow)}</div>}
    </section>;
  };
  const sidebarHistory = <>
    <div className="ea-agent-sidebar-history">
      <div className="ea-agent-sidebar-section-heading"><span>对话组</span><button type="button" aria-label="新建分组" title="新建分组" className="ea-agent-sidebar-group-add" onClick={() => setGroupDialog({ action: "create", value: "" })}><Plus size={13} /></button></div>
      {conversation.groups.map(group => groupedSection(group, sessions.filter(item => item.group === group), true, `group:${group}`))}
      <div className="ea-agent-sidebar-section-heading is-recent"><span>最近对话</span></div>
      {timeGroups.map(group => groupedSection(group.label, group.sessions, false, `time:${group.label}`))}
      {!sessions.length && <p className="ea-agent-sidebar-empty">暂无历史对话</p>}
    </div>
  </>;
  const popoverHistory = <>
    <div className="max-h-[360px] space-y-1 overflow-y-auto">{sessions.map(item => <div key={item.id} className={`flex items-center gap-1 rounded-md px-2 ${item.id === conversation.activeSessionId ? "bg-blue-50" : "hover:bg-slate-50"}`}>
      <button type="button" aria-current={item.id === conversation.activeSessionId ? "true" : undefined} onClick={() => openSession(item.id)} className="min-w-0 flex-1 py-2 text-left"><span title={item.title} className="block truncate text-xs text-slate-700">{item.title}</span><span className="mt-1 block text-[10px] text-slate-400">{item.updatedAt.slice(0, 10)} · {item.messages.filter(message => message.role === "user").length} 轮</span></button>
      <button type="button" aria-label={`重命名 ${item.title}`} title="重命名" className="p-1.5 text-slate-500 hover:text-[#0052D9]" onClick={() => setEditing({ id: item.id, title: item.title, action: "rename" })}><Pencil size={13} /></button>
      <button type="button" aria-label={`删除 ${item.title}`} title="删除对话" className="p-1.5 text-slate-500 hover:text-red-600" onClick={() => setEditing({ id: item.id, title: item.title, action: "delete" })}><Trash2 size={13} /></button>
    </div>)}{!sessions.length && <p className="py-8 text-center text-xs text-slate-400">暂无历史对话</p>}</div>
  </>;
  return <div className={sidebar ? "ea-agent-sidebar-controls" : "flex items-center gap-2"}>
    {sidebar ? <>
      <div className={`ea-agent-sidebar-actions${open ? " is-expanded" : ""}`}>
        <button type="button" aria-label={open ? "收起" : "展开"} title={open ? "收起" : "展开"} aria-expanded={open} aria-controls={historyId} className="ea-agent-sidebar-toggle" onClick={() => { setOpen(!open); onExpandedChange?.(!open); }}>{open ? <PanelLeftClose size={15} /> : <PanelLeftOpen size={15} />}</button>
        <button type="button" aria-label="新建对话" title="新建对话" className={`ea-agent-sidebar-new${open ? " is-expanded" : ""}`} onClick={() => { conversation.newSession(); onNavigate?.(); }}><MessageSquarePlus size={14} />{open && <span>新建对话</span>}</button>
      </div>
      <div id={historyId} aria-label="历史对话列表" hidden={!open} className={open ? "flex min-h-0 flex-1 flex-col" : "hidden"}>{sidebarHistory}</div>
    </> : <><button type="button" aria-label="新建对话" title="新建对话" className={`${buttonClass} w-8`} onClick={() => { conversation.newSession(); onNavigate?.(); }}><MessageSquarePlus size={15} /></button><Popover.Root open={open} onOpenChange={setOpen}><Popover.Trigger asChild><button type="button" aria-label="历史对话" title="历史对话" className={`${buttonClass} w-8`}><History size={15} /></button></Popover.Trigger><Popover.Portal><Popover.Content aria-label="历史对话" align="end" sideOffset={8} className="z-[120] w-[340px] rounded-lg border border-slate-200 bg-white p-3 shadow-lg">
      <div className="mb-3 flex items-center justify-between"><h2 className="text-sm font-medium text-slate-800">历史对话</h2><Popover.Close aria-label="关闭历史对话" className="p-1 text-slate-500"><X size={15} /></Popover.Close></div>
      {popoverHistory}
    </Popover.Content></Popover.Portal></Popover.Root></>}
    <Dialog.Root open={Boolean(editing)} onOpenChange={value => { if (!value) setEditing(null); }}><Dialog.Portal><Dialog.Overlay className="fixed inset-0 z-[130] bg-black/25" /><Dialog.Content className="fixed left-1/2 top-1/2 z-[131] w-[360px] -translate-x-1/2 -translate-y-1/2 rounded-lg border border-slate-200 bg-white p-5 shadow-xl">
      <Dialog.Title className="text-sm font-semibold text-slate-800">{editing?.action === "rename" ? "重命名对话" : "删除对话"}</Dialog.Title>
      <Dialog.Description className="mt-2 text-xs text-slate-500">{editing?.action === "delete" ? `删除“${editing.title}”及其消息？此操作无法撤销。` : "对话名称"}</Dialog.Description>
      <form onSubmit={event => { event.preventDefault(); if (!editing) return; if (editing.action === "rename") conversation.renameSession(editing.id, editing.title); else { conversation.deleteSession(editing.id); onNavigate?.(); } setEditing(null); }}>
        {editing?.action === "rename" && <input autoFocus aria-label="对话名称" maxLength={80} required value={editing.title} onChange={event => setEditing({ ...editing, title: event.target.value })} className="mt-3 h-9 w-full rounded-md border border-slate-200 px-3 text-sm" />}
        <div className="mt-5 flex justify-end gap-2"><Dialog.Close type="button" className={buttonClass}>取消</Dialog.Close><button type="submit" disabled={!editing?.title.trim()} className={`${buttonClass} ${editing?.action === "delete" ? "text-red-600" : "text-[#0052D9]"}`}>{editing?.action === "delete" ? "确认删除" : "保存"}</button></div>
      </form>
    </Dialog.Content></Dialog.Portal></Dialog.Root>
    <Dialog.Root open={Boolean(groupDialog)} onOpenChange={value => { if (!value) setGroupDialog(null); }}><Dialog.Portal><Dialog.Overlay className="fixed inset-0 z-[130] bg-black/25" /><Dialog.Content className="fixed left-1/2 top-1/2 z-[131] w-[360px] -translate-x-1/2 -translate-y-1/2 rounded-lg border border-slate-200 bg-white p-5 shadow-xl">
      <Dialog.Title className="text-sm font-semibold text-slate-800">{groupDialog?.action === "create" ? "新建分组" : groupDialog?.action === "rename" ? "重命名分组" : "删除分组"}</Dialog.Title>
      <Dialog.Description className="mt-2 text-xs text-slate-500">{groupDialog?.action === "delete" ? `删除“${groupDialog.previous}”分组？其中的对话会移至最近对话。` : "分组名称"}</Dialog.Description>
      <form onSubmit={event => { event.preventDefault(); if (!groupDialog) return; if (groupDialog.action === "create") conversation.createGroup(groupDialog.value); else if (groupDialog.action === "rename") conversation.renameGroup(groupDialog.previous!, groupDialog.value); else conversation.deleteGroup(groupDialog.previous!); setGroupDialog(null); }}>
        {groupDialog?.action !== "delete" && <input autoFocus aria-label="分组名称" maxLength={40} required value={groupDialog?.value ?? ""} onChange={event => setGroupDialog({ ...groupDialog!, value: event.target.value })} className="mt-3 h-9 w-full rounded-md border border-slate-200 px-3 text-sm" />}
        <div className="mt-5 flex justify-end gap-2"><Dialog.Close type="button" className={buttonClass}>取消</Dialog.Close><button type="submit" disabled={groupDialog?.action !== "delete" && !groupDialog?.value.trim()} className={`${buttonClass} ${groupDialog?.action === "delete" ? "text-red-600" : "text-[#0052D9]"}`}>{groupDialog?.action === "delete" ? "确认删除" : "保存"}</button></div>
      </form>
    </Dialog.Content></Dialog.Portal></Dialog.Root>
  </div>;
}