import { useEffect, useRef, useState, type ReactNode } from "react";
import { Check } from "lucide-react";
import { AttachmentInput, type Att } from "./AttachmentInput";
import { currentUser, departments, productById, PROBLEM_DOMAINS, PROBLEM_TYPES, type ProblemDomain, type ProblemType, type Urgency } from "./data";
import { PersonInput } from "./PersonInput";
import { CreationCollaboratorInput } from "./CreationCollaboratorInput";
import { ProductPicker } from "./ProductPicker";
import { resolveStandaloneAssignment, taskTypeHasKR, type TaskAssignmentMethod } from "./standaloneTaskConfig";
import { createStandaloneTask, editStandaloneTask, type CreateStandaloneTaskInput, type StandaloneTask } from "./standaloneTasks";
import { VoiceRecorder } from "./VoiceNote";

// 仅收窄新建页面；历史 Project / TF 引用及存储兼容能力保持不变。
const URGENCIES: Urgency[] = ["非常紧急", "紧急", "一般", "不紧急"];
const fieldClass = "h-10 w-full min-w-0 rounded-md border border-slate-200 bg-slate-50/60 px-3 text-[13px] text-slate-700 outline-none transition-colors focus:bg-white focus:border-[#0052D9] disabled:text-slate-500 disabled:cursor-not-allowed";
const sectionClass = "min-w-0 rounded-xl border border-slate-200/80 bg-white p-5 shadow-[0_1px_2px_0_rgba(15,23,42,0.04)]";

function PanelHeading({ id, number, children }: { id: string; number: number; children: ReactNode }) {
  return <h2 id={id} className="mb-4 flex items-center gap-2 text-[13px] font-medium text-slate-800"><span className="grid h-5 w-5 place-items-center rounded-md bg-[#0052D9]/8 text-[10px] text-[#0052D9]">{number}</span>{children}</h2>;
}

function Field({ label, required, htmlFor, children }: { label: string; required?: boolean; htmlFor?: string; children: ReactNode }) {
  return <div className="min-w-0"><label htmlFor={htmlFor} className="mb-1.5 flex items-center gap-1 text-xs tracking-wide text-slate-600">{label}{required && <span className="text-red-500">*</span>}</label>{children}</div>;
}

export function CreateStandaloneTask({ onCancel, onCreated, initialTask }: {
  onCancel: () => void;
  onCreated: (task: StandaloneTask) => void;
  initialTask?: StandaloneTask;
}) {
  const [title, setTitle] = useState(initialTask?.title ?? "");
  const [description, setDescription] = useState(initialTask?.description ?? "");
  const [advanced, setAdvanced] = useState(initialTask?.creationMode === "advanced");
  const [assignmentMethod, setAssignmentMethod] = useState<TaskAssignmentMethod>(initialTask?.assignmentMethod ?? "department");
  const [simpleForOther, setSimpleForOther] = useState(Boolean(initialTask && initialTask.owner !== currentUser.name));
  const [simpleOtherOwner, setSimpleOtherOwner] = useState(initialTask?.owner ?? "");
  const [handlingDepartment, setHandlingDepartment] = useState(initialTask?.handlingDepartment ?? "");
  const [problemDomain, setProblemDomain] = useState<ProblemDomain | "">(initialTask?.problemDomain ?? "");
  const [problemType, setProblemType] = useState<ProblemType | "">(initialTask?.problemType ?? "");
  const [involvementId, setInvolvementId] = useState(initialTask?.involvement && initialTask.involvement.kind !== "无" ? initialTask.involvement.id : "");
  const needsProduct = advanced && assignmentMethod === "domain-type";
  const originalAssignment = initialTask && advanced === (initialTask.creationMode === "advanced") && assignmentMethod === (initialTask.assignmentMethod ?? "department") && handlingDepartment === (initialTask.handlingDepartment ?? "") && problemDomain === (initialTask.problemDomain ?? "") && problemType === (initialTask.problemType ?? "");
  const assignment = !advanced ? null : originalAssignment ? { owner: initialTask.owner, department: initialTask.handlingDepartment ?? "" } : assignmentMethod === "department"
    ? resolveStandaloneAssignment("", "", handlingDepartment)
    : problemDomain && problemType && involvementId ? resolveStandaloneAssignment(problemDomain, problemType, "", involvementId) : null;
  const owner = advanced ? assignment?.owner ?? "" : simpleForOther ? simpleOtherOwner.trim() : currentUser.name;
  const actualDepartment = assignment?.department ?? handlingDepartment;
  const [collaborators, setCollaborators] = useState<string[]>(initialTask?.collaborators.map(person => person.name) ?? []);
  // 排除当前执行模式的负责人，但不因切换模式破坏另一模式的协作者草稿。
  const visibleCollaborators = collaborators.filter((person) => person !== owner);
  const [urgency, setUrgency] = useState<Urgency>(initialTask?.urgency ?? "一般");
  const [dueDate, setDueDate] = useState(initialTask?.dueDate ?? "");
  const [attachments, setAttachments] = useState<Att[]>(initialTask?.attachments.map(attachment => ({ ...attachment })) ?? []);
  const [uploading, setUploading] = useState(false);
  const [voiceNote, setVoiceNote] = useState<string | undefined>(initialTask?.voiceNote);
  const [voiceBusy, setVoiceBusy] = useState(false);
  const [error, setError] = useState("");
  const submitting = useRef(false);
  const titleInput = useRef<HTMLInputElement>(null);
  // 仅首次打开聚焦，切换模式时保持开关焦点和所有共用字段的 DOM。
  useEffect(() => { titleInput.current?.focus(); }, []);
  const validReference = !needsProduct || Boolean(productById(involvementId));
  const canSubmit = Boolean(title.trim() && description.trim() && owner && dueDate && !Number.isNaN(Date.parse(dueDate)) && validReference && (!advanced || assignment) && !uploading && !voiceBusy);
  const submit = () => {
    if (!canSubmit || submitting.current) return;
    submitting.current = true;
    try {
      const payload: CreateStandaloneTaskInput = {
        title, description, owner, createdForOther: owner !== currentUser.name,
        creationMode: advanced ? "advanced" : "simple",
        ...(originalAssignment && owner === initialTask?.owner ? { assignmentMethod: initialTask.assignmentMethod, handlingDepartment: initialTask.handlingDepartment, problemDomain: initialTask.problemDomain, problemType: initialTask.problemType } : advanced ? { assignmentMethod, ...(assignmentMethod === "department" ? { handlingDepartment } : { problemDomain, problemType }) } : {}),
        involvement: needsProduct ? "产品" : initialTask?.involvement?.kind ?? "无",
        involvementId: needsProduct ? involvementId : initialTask?.involvement && initialTask.involvement.kind !== "无" ? initialTask.involvement.id : "",
        productByAssignment: !initialTask, visibilityType: initialTask?.visibility?.type ?? "all", visiblePeople: initialTask?.visibility?.people ?? [],
        collaborators: initialTask ? visibleCollaborators : [], urgency, dueDate, attachments, voiceNote,
      };
      const task = initialTask ? editStandaloneTask(initialTask.id, payload, initialTask) : createStandaloneTask(payload);
      onCreated(task);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "任务保存失败，请重试。");
      submitting.current = false;
    }
  };

  const titleField = <Field label="任务名称" required htmlFor="task-title"><input ref={titleInput} id="task-title" required value={title} onChange={(event) => setTitle(event.target.value)} placeholder="例如：完成本周发布前检查" className={fieldClass} /></Field>;
  const collaboratorField = <Field label="协作者"><CreationCollaboratorInput value={visibleCollaborators.map((name) => ({ name }))} onChange={setCollaborators} exclude={owner ? [owner] : []} selectedInside /></Field>;

  return <div className="relative flex min-h-full flex-col">
    <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_80%_50%_at_0%_0%,rgba(0,82,217,0.05),transparent_60%)]" />
    <div className="relative mx-auto w-full max-w-[1200px] flex-1 space-y-6 p-8 pb-28">
      <header className="flex items-start justify-between gap-6">
        <h1 className="text-xl font-semibold text-slate-900">{initialTask ? "编辑自由任务" : "新建自由任务"}</h1>
      </header>

      <div className="grid grid-cols-2 items-start gap-4">
        <section aria-labelledby="task-content-heading" className={sectionClass}>
          <PanelHeading id="task-content-heading" number={1}>基础</PanelHeading>
          <div className="space-y-4">
            {titleField}
            <div className="grid grid-cols-2 gap-4">
              <Field label="紧急程度" required><div role="group" aria-label="紧急程度" className="flex gap-1">{URGENCIES.map((item) => <button type="button" key={item} aria-pressed={urgency === item} onClick={() => setUrgency(item)} className={`h-10 min-w-0 flex-1 rounded-md border text-[11px] transition-colors ${urgency === item ? "border-[#0052D9] bg-[#0052D9] text-white" : "border-slate-200 text-slate-600 hover:bg-slate-50"}`}>{item}</button>)}</div></Field>
              <Field label="截止日期" required htmlFor="task-due-date"><input id="task-due-date" type="date" required value={dueDate} onChange={(event) => setDueDate(event.target.value)} className={fieldClass} /></Field>
            </div>
          <div id="task-assignment-settings" className="flex items-center justify-end border-t border-slate-100 pt-3">
            <button type="button" role="switch" aria-checked={advanced} aria-label="条件选人" aria-controls="task-owner-settings" onClick={() => { setAdvanced((value) => !value); setError(""); }} className="inline-flex h-6 shrink-0 items-center gap-1.5 rounded-md text-[11px] text-slate-500 outline-none focus-visible:ring-2 focus-visible:ring-[#0052D9]/40"><span>条件选人</span><span aria-hidden="true" className={`inline-flex h-4 w-7 shrink-0 items-center rounded-full p-0.5 transition-colors ${advanced ? "bg-[#0052D9]" : "bg-slate-300"}`}><span className={`h-3 w-3 rounded-full bg-white shadow-sm transition-transform ${advanced ? "translate-x-3" : "translate-x-0"}`} /></span></button>
          </div>
            <div id="task-owner-settings" className="space-y-4">
            {advanced && <>
              <fieldset className="flex items-center gap-4"><legend className="sr-only">负责人确定方式</legend>{([{ value: "department", label: "按部门" }, { value: "domain-type", label: "按 Domain + 类型" }] as const).map((method) => <label key={method.value} className="inline-flex cursor-pointer items-center gap-1.5 whitespace-nowrap text-xs text-slate-600"><input type="radio" name="task-assignment-method" value={method.value} checked={assignmentMethod === method.value} onChange={() => { setAssignmentMethod(method.value); setError(""); }} className="h-3.5 w-3.5 accent-[#0052D9]" />{method.label}</label>)}</fieldset>
              {assignmentMethod === "department" ? <Field label="处理部门" required htmlFor="task-handling-department"><select id="task-handling-department" required value={handlingDepartment} onChange={(event) => { setHandlingDepartment(event.target.value); setError(""); }} className={fieldClass}><option value="">请选择处理部门</option>{departments.map((item) => <option key={item}>{item}</option>)}</select></Field> : <div className="grid grid-cols-3 items-end gap-2">
                <Field label="关联产品" required><ProductPicker value={involvementId} onChange={(value) => { setInvolvementId(value); setProblemDomain(""); setProblemType(""); setError(""); }} placeholder="请选择产品" triggerClassName="h-10" /></Field>
                <Field label="Domain" required htmlFor="task-domain"><select id="task-domain" required disabled={!involvementId} value={problemDomain} onChange={(event) => { setProblemDomain(event.target.value as ProblemDomain | ""); setProblemType(""); setError(""); }} className={fieldClass}><option value="">{involvementId ? "请选择 Domain" : "先选产品"}</option>{PROBLEM_DOMAINS.map((item) => <option key={item}>{item}</option>)}</select></Field>
                <Field label="类型" required htmlFor="task-problem-type"><select id="task-problem-type" required disabled={!involvementId || !problemDomain} value={problemType} onChange={(event) => { setProblemType(event.target.value as ProblemType | ""); setError(""); }} className={fieldClass}><option value="">{problemDomain ? "请选择类型" : "先选 Domain"}</option>{PROBLEM_TYPES.map((item) => { const hasKR = taskTypeHasKR(problemDomain, item); return <option key={item} value={item} disabled={!hasKR}>{item}{hasKR ? "" : "（暂无 KR）"}</option>; })}</select></Field>
              </div>}
              <Field label="任务负责人" htmlFor="task-owner"><input id="task-owner" readOnly value={assignment ? `${owner} · ${actualDepartment}` : ""} placeholder={assignmentMethod === "department" ? "选择部门后自动确定" : "选择 Domain 和类型后自动确定"} className={`${fieldClass} text-slate-500`} /></Field>
            </>}
            {!advanced && <Field label="任务负责人" required htmlFor={simpleForOther ? "task-simple-owner" : undefined}>
              <div role="group" aria-label="负责人选择" className="grid grid-cols-2 gap-1 rounded-lg border border-slate-200 bg-slate-50/70 p-1">
                <button type="button" aria-pressed={!simpleForOther} onClick={() => setSimpleForOther(false)} className={`h-8 rounded-md text-xs transition-colors ${!simpleForOther ? "bg-white font-medium text-[#0052D9] shadow-sm ring-1 ring-slate-200/70" : "text-slate-500 hover:text-slate-700"}`}>我（{currentUser.name}）</button>
                <button type="button" aria-pressed={simpleForOther} onClick={() => setSimpleForOther(true)} className={`h-8 rounded-md text-xs transition-colors ${simpleForOther ? "bg-white font-medium text-[#0052D9] shadow-sm ring-1 ring-slate-200/70" : "text-slate-500 hover:text-slate-700"}`}>为他人创建</button>
              </div>
              {simpleForOther && <div className="mt-2"><PersonInput id="task-simple-owner" value={simpleOtherOwner} onChange={setSimpleOtherOwner} placeholder="@ 选择任务负责人" className={fieldClass} /></div>}
            </Field>}
            </div>
            {initialTask && collaboratorField}
          </div>
        </section>

        <section aria-labelledby="task-background-heading" className={sectionClass}>
          <PanelHeading id="task-background-heading" number={2}>背景</PanelHeading>
          <div className="space-y-4">
            <div>
              <label htmlFor="task-description" className="mb-1.5 flex items-center gap-1 text-xs tracking-wide text-slate-600">任务说明<span className="text-red-500">*</span></label>
              <div className="relative">
                <textarea id="task-description" required value={description} onChange={(event) => setDescription(event.target.value)} placeholder="描述要做什么，以及完成标准…" className="block h-[101px] min-h-[80px] w-full resize-y rounded-lg border border-slate-200 bg-slate-50/60 p-3 pr-20 text-[13px] leading-relaxed text-slate-700 outline-none transition-colors focus:border-[#0052D9] focus:bg-white" />
                <div aria-label="任务说明语音备注" className="absolute right-2 top-2"><VoiceRecorder value={voiceNote} onChange={setVoiceNote} iconOnly onBusyChange={setVoiceBusy} /></div>
              </div>
            </div>
            <div aria-labelledby="new-task-materials">
              <h3 id="new-task-materials" className="mb-1.5 text-xs text-slate-600">附件</h3>
              <AttachmentInput value={attachments} onChange={setAttachments} onUploadingChange={setUploading} variant="dropzone" />
            </div>
          </div>
        </section>
      </div>
      {error && <p role="alert" className="rounded-lg bg-red-50 px-3 py-2 text-xs text-red-600">{error}</p>}
    </div>

    <footer className="sticky bottom-0 z-30 border-t border-slate-200 bg-white/95 shadow-[0_-2px_8px_rgba(15,23,42,0.04)] backdrop-blur supports-[backdrop-filter]:bg-white/80">
      <div className="mx-auto flex max-w-[1200px] items-center justify-end gap-2 px-8 py-3">
        <button type="button" onClick={onCancel} className="h-9 rounded-md border border-slate-200 px-4 text-sm text-slate-700 hover:bg-slate-50">取消</button>
        <button type="button" onClick={submit} disabled={!canSubmit} className="inline-flex h-9 items-center gap-1.5 rounded-md bg-gradient-to-r from-[#0052D9] to-[#003FA8] px-4 text-sm text-white hover:shadow-md disabled:cursor-not-allowed disabled:opacity-40"><Check size={14} />{initialTask ? "保存修改" : "创建自由任务"}</button>
      </div>
    </footer>
  </div>;
}