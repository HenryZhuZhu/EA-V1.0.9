import { CASE_WORKBENCH_STATUSES, type CaseWorkbenchStatus } from "./caseWorkbenchModel";

const PRESENTATION = {
  进行中: { accent: "#0052D9", bg: "#f5f8ff", hint: "分析与推进" },
  验证中: { accent: "#0891b2", bg: "#f0fafc", hint: "验证与闭环" },
  已结案: { accent: "#64748b", bg: "#f6f8fb", hint: "成果与记录" },
  Fanout: { accent: "#0052D9", bg: "#f5f8ff", hint: "分发验证" },
};
export function CaseStatusSummary({ counts, status, onChange, fanout = false, fanoutCount = 0, onFanout }: {
  counts: Record<CaseWorkbenchStatus, number>;
  status: CaseWorkbenchStatus;
  onChange: (status: CaseWorkbenchStatus) => void;
  fanout?: boolean;
  fanoutCount?: number;
  onFanout?: () => void;
}) {
  return <section aria-label="Case 状态汇总" className="grid grid-cols-[minmax(0,2fr)_minmax(0,2fr)_minmax(0,1fr)_minmax(0,1fr)] gap-3">
    {[...CASE_WORKBENCH_STATUSES, "Fanout" as const].map(value => {
      const isFanout = value === "Fanout";
      const { accent, bg, hint } = PRESENTATION[value], pressed = isFanout ? fanout : !fanout && status === value;
      const count = isFanout ? fanoutCount : counts[value];
      return <button key={value} type="button" aria-label={`${value} ${count} 个 Case`} aria-pressed={pressed} aria-controls="case-status-content" title={`${value} · 当前人员视角与筛选条件下共 ${count} 个 Case`} onClick={() => isFanout ? onFanout?.() : onChange(value)}
        className={`relative overflow-hidden rounded-xl border bg-white px-[18px] pb-[14px] pt-[15px] text-left transition-all focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0052D9]/40 ${pressed ? "" : "border-slate-200 hover:border-slate-300"}`}
        style={pressed ? { borderColor: accent, background: bg, boxShadow: `0 8px 20px -14px ${accent}` } : undefined}>
        <span aria-hidden="true" className="absolute inset-x-0 top-0 h-[3px] origin-left transition-transform" style={{ background: accent, transform: pressed ? "scaleX(1)" : "scaleX(0)" }} />
        <div className="text-xs tracking-wide" style={{ color: pressed ? accent : "#64748b", fontWeight: pressed ? 600 : 400 }}>{value}</div>
        <div className="mt-2.5 text-[32px] font-bold leading-none tabular-nums" style={{ color: pressed ? accent : "#0f172a" }}>{count}<span className="ml-1 text-xs font-normal text-slate-400">个</span></div>
        <div className="mt-2 flex items-center gap-1.5 text-[11px] text-slate-400"><span aria-hidden="true" className="h-[5px] w-[5px] rounded-full" style={{ background: accent, opacity: pressed ? 1 : .55 }} />{hint}</div>
      </button>;
    })}
  </section>;
}