import { CaseItem, Level, mockCases, mockProducts, Product, TaskNode, Urgency } from "./data";

const PTE_TEAMS = ["FT1", "FT2", "CP1", "CP2", "EFA"] as const;
const TEAM_MEMBERS: Record<(typeof PTE_TEAMS)[number], readonly string[]> = {
  FT1: ["赵一鸣", "韩子轩", "周睿", "蒋明远", "唐浩", "冯嘉佑", "谢承泽", "彭宇航"],
  FT2: ["林浩然", "许嘉诚", "沈亦航", "顾文博", "罗俊熙", "曹景行", "袁泽宇", "潘昊"],
  CP1: ["陈思远", "王启明", "何俊杰", "梁子墨", "宋知远", "邱彦博", "杜晨阳", "邵文轩"],
  CP2: ["刘博文", "张景程", "邓宇辰", "郭奕凡", "苏泽楷", "方明哲", "魏子安", "叶嘉树"],
  EFA: ["李晨曦", "孙若川", "郑凯", "吴思齐", "马嘉宁", "程昱", "陆星河", "高远"],
};
const CASE_TOPICS = [
  "客户样品失效复现",
  "边缘条件复测",
  "批次差异定位",
  "量产良率异常分析",
  "高低温窗口确认",
  "测试站点差异排查",
  "电压边界异常定位",
  "良率波动根因分析",
  "可靠性验证异常",
  "客户平台兼容性确认",
  "程式版本差异验证",
  "改善方案量产验证",
] as const;
const LEVELS: Level[] = ["L1", "L2", "L2", "L3"];
const URGENCIES: Urgency[] = ["紧急", "一般", "紧急", "一般"];
export const EXTRA_ANALYSIS_PRODUCTS: Product[] = [
  { id: "DDR5-X-8400", code: "DDR5-X-8400", name: "DDR5 X-die 8400", objectType: "Die", family: "DDR5", platform: "V1", owner: "赵一鸣", currentStageId: "ES", stageStatus: { DKO: "已完成", AR: "已完成", FVR: "已完成", DBR: "已完成", FSO: "已完成", ES: "进行中", CS: "未开始", MP: "未开始" } },
  { id: "DDR5-X-7600", code: "DDR5-X-7600", name: "DDR5 X-die 7600", objectType: "Die", family: "DDR5", platform: "G5", owner: "林浩然", currentStageId: "CS", stageStatus: { DKO: "已完成", AR: "已完成", FVR: "已完成", DBR: "已完成", FSO: "已完成", ES: "已完成", CS: "进行中", MP: "未开始" } },
  { id: "LPDDR5-8533", code: "LPDDR5-8533", name: "LPDDR5 8533", objectType: "IC", family: "LPDDR5", platform: "V1", owner: "陈思远", currentStageId: "DBR", stageStatus: { DKO: "已完成", AR: "已完成", FVR: "已完成", DBR: "进行中", FSO: "未开始", ES: "未开始", CS: "未开始", MP: "未开始" } },
  { id: "LPDDR4-3733", code: "LPDDR4-3733", name: "LPDDR4 3733", objectType: "IC", family: "LPDDR4", platform: "G4", owner: "刘博文", currentStageId: "MP", stageStatus: { DKO: "已完成", AR: "已完成", FVR: "已完成", DBR: "已完成", FSO: "已完成", ES: "已完成", CS: "已完成", MP: "进行中" } },
  { id: "DMJFE", code: "DMJFE", name: "DMJFE 内存模组", objectType: "DIMM", family: "DDR5", platform: "V1", owner: "李晨曦", currentStageId: "CS", stageStatus: { DKO: "已完成", AR: "已完成", FVR: "已完成", DBR: "已完成", FSO: "已完成", ES: "已完成", CS: "进行中", MP: "未开始" } },
  { id: "DMJFF", code: "DMJFF", name: "DMJFF 内存模组", objectType: "DIMM", family: "LPDDR5", platform: "G5", owner: "顾文博", currentStageId: "FSO", stageStatus: { DKO: "已完成", AR: "已完成", FVR: "已完成", DBR: "已完成", FSO: "进行中", ES: "未开始", CS: "未开始", MP: "未开始" } },
];
export const CLOSURE_ANALYSIS_PRODUCTS = [...mockProducts, ...EXTRA_ANALYSIS_PRODUCTS];
const TASK_TITLES = [
  "客户环境信息确认", "失效样品复测", "测试日志收集",
  "边界条件扫描", "失效位置定位", "历史 Case 对比",
  "根因假设验证", "交叉实验确认", "改善方案设计",
  "改善样品复测", "量产条件验证", "结论与报告归档",
] as const;

const pad = (value: number, size = 2) => String(value).padStart(size, "0");
const dateText = (date: Date, withTime = false) => {
  const datePart = `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
  return withTime ? `${datePart} ${pad(date.getHours())}:${pad(date.getMinutes())}` : datePart;
};

function buildTasks(productIndex: number, caseIndex: number, caseCode: string, closedAt: Date): TaskNode[] {
  return Array.from({ length: TASK_TITLES.length }, (_, taskIndex) => {
    const engineerIndex = taskIndex % 4;
    const team = PTE_TEAMS[(productIndex + caseIndex + engineerIndex) % PTE_TEAMS.length];
    const teamMembers = TEAM_MEMBERS[team];
    const owner = teamMembers[(productIndex * 4 + caseIndex + engineerIndex) % teamMembers.length];
    const taskHours = 6 + ((productIndex * 7 + caseIndex * 5 + taskIndex * 3) % 19);
    const completedAt = new Date(closedAt.getTime() - (TASK_TITLES.length - taskIndex - 1) * 2 * 3600000);
    const startedAt = new Date(completedAt.getTime() - taskHours * 3600000);
    const waitingAt = new Date(startedAt.getTime() - 2 * 3600000);
    return {
      id: `analytics-task-${productIndex}-${caseIndex}-${taskIndex}`,
      code: `${caseCode}.${pad(taskIndex + 1, 3)}`,
      title: TASK_TITLES[taskIndex],
      owner,
      department: team,
      urgency: URGENCIES[caseIndex % URGENCIES.length],
      progress: 100,
      status: "已完成",
      dueDate: dateText(completedAt),
      statusHistory: [
        { status: "待接受", at: dateText(waitingAt, true) },
        { status: "进行中", at: dateText(startedAt, true) },
        { status: "已完成", at: dateText(completedAt, true) },
      ],
    };
  });
}

function buildCase(productIndex: number, caseIndex: number): CaseItem {
  const product = CLOSURE_ANALYSIS_PRODUCTS[productIndex];
  const closedAt = new Date(2026, 7, 10 - productIndex * 2 - caseIndex, 16, 0);
  const durationHours = 96 + productIndex * 19 + caseIndex * 31;
  const createdAt = new Date(closedAt.getTime() - durationHours * 3600000);
  const code = `EA-AN-${pad(productIndex + 1)}${pad(caseIndex + 1, 3)}`;
  const tasks = buildTasks(productIndex, caseIndex, code, closedAt);
  const teams = Array.from(new Set(tasks.map((task) => task.department)));
  const participants = Array.from(new Map(tasks.map((task) => [task.owner, { name: task.owner, department: task.department }])).values());
  return {
    id: `analytics-case-${product.id}-${caseIndex + 1}`,
    code,
    name: CASE_TOPICS[caseIndex],
    owner: tasks[0].owner,
    participants: participants.filter((participant) => participant.name !== tasks[0].owner),
    level: LEVELS[caseIndex % LEVELS.length],
    urgency: URGENCIES[caseIndex % URGENCIES.length],
    status: "已关闭",
    reason: "产品分析演示数据",
    background: `${product.code} 产品结案效率分析样例。`,
    impact: "用于展示产品、Case、团队与任务层级的结案耗时。",
    levelReason: "",
    product: product.code,
    productId: product.id,
    productIds: [product.id],
    material: product.objectType,
    density: "—",
    ioType: "—",
    failStage: "—",
    customer: "演示客户",
    failPlatform: product.platform ?? "—",
    failMode: CASE_TOPICS[caseIndex],
    ppm: "—",
    pdId: "—",
    createdAt: dateText(createdAt),
    updatedAt: dateText(closedAt, true),
    dueDate: dateText(closedAt),
    dueIn: 0,
    departments: teams,
    tasks,
    aiSummary: { progress: "已结案", method: "团队协作分析", conclusion: "已完成根因定位与验证", solution: "改善方案已验证", risk: "" },
    timeline: [
      { time: `${dateText(createdAt)} 09:00`, user: tasks[0].owner, content: "创建 Case" },
      { time: dateText(closedAt, true), user: tasks[0].owner, content: "提交结案" },
    ],
  };
}

export function ensureClosureTimeMockCases() {
  const generated = CLOSURE_ANALYSIS_PRODUCTS.flatMap((_, productIndex) =>
    Array.from({ length: CASE_TOPICS.length }, (_, caseIndex) => buildCase(productIndex, caseIndex)),
  );
  const existingIds = new Set(mockCases.map((caseItem) => caseItem.id));
  generated.forEach((caseItem) => {
    if (!existingIds.has(caseItem.id)) mockCases.push(caseItem);
  });
}
