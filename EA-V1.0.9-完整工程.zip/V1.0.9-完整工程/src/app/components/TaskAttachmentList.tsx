import { useRef, useState } from "react";
import * as Dialog from "@radix-ui/react-dialog";
import { ArrowUpRight, FileImage, FileSpreadsheet, FileText, Paperclip } from "lucide-react";
import type { Att } from "./AttachmentInput";
import { AttachmentPreview } from "./AttachmentPreview";

// Read-only task inputs. Result attachments remain in their own result panel.
export function TaskAttachmentList({ attachments = [], label = "任务附件", modalPreview = false }: { attachments?: Att[]; label?: string; modalPreview?: boolean }) {
  const [preview, setPreview] = useState<{ attachment: Att; index: number } | null>(null);
  const triggerRef = useRef<HTMLButtonElement | null>(null);

  return <section aria-label={label} className="mt-4 border-t border-slate-100 pt-4">
    <div className="flex items-center gap-2"><Paperclip size={14} className="text-slate-400" /><h2 className="text-xs font-medium text-slate-700">{label}</h2><span className="text-[11px] text-slate-400">{attachments.length} 个</span></div>
    {attachments.length ? <ul className="mt-3 grid grid-cols-2 gap-2">
      {attachments.map((attachment, index) => {
        const Icon = attachment.kind === "image" ? FileImage : attachment.kind === "sheet" ? FileSpreadsheet : FileText;
        const available = Boolean(attachment.url);
        return <li key={`${attachment.name}-${index}`} className="min-w-0">
          <button type="button" aria-label={`预览${label} ${attachment.name}`} title={attachment.name} disabled={!available} onClick={event => { triggerRef.current = event.currentTarget; setPreview({ attachment, index }); }} className="group flex w-full min-w-0 items-center gap-3 rounded-lg border border-slate-200 bg-slate-50/40 px-3 py-3 text-left transition-colors enabled:hover:border-[#0052D9]/40 enabled:hover:bg-blue-50/30 disabled:cursor-default">
            <span className="grid h-8 w-8 shrink-0 place-items-center rounded-md border border-slate-100 bg-white text-[#0052D9]"><Icon size={16} /></span>
            <span className="min-w-0 flex-1"><span className="block break-all text-xs leading-relaxed text-slate-700">{attachment.name}</span><span className="mt-0.5 block text-[10px] text-slate-400">{available ? "点击预览 / 下载" : "仅保留文件名，暂无文件内容"}</span></span>
            {available && <ArrowUpRight size={13} className="shrink-0 text-slate-400 group-hover:text-[#0052D9]" />}
          </button>
        </li>;
      })}
    </ul> : <p className="mt-2 text-xs text-slate-400">新建任务时未上传附件</p>}
    {preview && (modalPreview ? <Dialog.Root open onOpenChange={open => { if (!open) setPreview(null); }}><Dialog.Portal><Dialog.Content onCloseAutoFocus={event => { event.preventDefault(); triggerRef.current?.focus(); }} className="fixed inset-0 z-[151] outline-none"><Dialog.Title className="sr-only">附件预览</Dialog.Title><Dialog.Description className="sr-only">{preview.attachment.name}</Dialog.Description><AttachmentPreview key={`${preview.index}-${preview.attachment.name}`} attachment={preview.attachment} onClose={() => setPreview(null)} /></Dialog.Content></Dialog.Portal></Dialog.Root> : <AttachmentPreview key={`${preview.index}-${preview.attachment.name}`} attachment={preview.attachment} onClose={() => setPreview(null)} />)}
  </section>;
}