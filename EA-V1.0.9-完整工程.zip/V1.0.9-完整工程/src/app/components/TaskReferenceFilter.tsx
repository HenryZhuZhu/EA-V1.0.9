import { useState } from "react";
import { Check, ChevronDown } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "./ui/command";
import type { BusinessKind, BusinessReference } from "./taskWorkbenchModel";

const fullLabel = (ref: BusinessReference) => `${ref.name}${ref.nameOnly ? "（名称记录）" : ""}`;
export function taskReferenceOptions(options: BusinessReference[], kind: BusinessKind, query = "") {
  const terms = query.trim().toLocaleLowerCase().split(/\s+/).filter(Boolean);
  return options.filter(ref => ref.kind === kind && terms.every(term => fullLabel(ref).toLocaleLowerCase().includes(term)));
}

// 一个固定业务类型对应一个筛选字段；不包含类型切换或“无涉及”条件。
export function TaskReferenceFilter({ kind, value, options, onChange }: {
  kind: BusinessKind; value: string; options: BusinessReference[]; onChange: (key: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const selected = options.find(ref => ref.kind === kind && ref.key === value);
  const text = value ? selected ? kind === "产品" ? selected.name.split(" · ")[0] : fullLabel(selected) : "已选对象" : "全部";
  const title = value ? selected ? fullLabel(selected) : "已选对象（当前范围无任务）" : `全部${kind}`;
  const matches = taskReferenceOptions(options, kind, query);
  const choose = (key: string) => {
    if (key && !options.some(ref => ref.kind === kind && ref.key === key)) return;
    onChange(key); setOpen(false); setQuery("");
  };
  return <Popover open={open} onOpenChange={value => { setOpen(value); setQuery(""); }}>
    <PopoverTrigger asChild>
      <button type="button" aria-label={`${kind}筛选`} title={title} className={`inline-flex h-8 min-w-0 items-center gap-1 rounded-lg border px-2.5 text-xs transition-colors focus-visible:outline-2 focus-visible:outline-[#0052D9]/40 ${value ? "border-[#0052D9]/40 bg-[#0052D9]/5" : "border-slate-200 bg-white"}`}>
        <span className={`shrink-0 ${value ? "text-[#0052D9]/70" : "text-slate-400"}`}>{kind}</span>
        <span className={`min-w-0 flex-1 truncate text-left ${value ? "font-medium text-[#0052D9]" : "text-slate-700"}`}>{text}</span><ChevronDown size={12} className="shrink-0 text-slate-400" />
      </button>
    </PopoverTrigger>
    <PopoverContent align="start" aria-label={`选择${kind}`} className="z-50 w-[300px] max-w-[88vw] rounded-lg p-0">
      <Command label={`搜索${kind}`} shouldFilter={false} defaultValue={value || "all-references"}>
        <CommandInput placeholder="搜索" value={query} onValueChange={setQuery} className="text-xs" />
        <CommandList label={`${kind}候选`} className="max-h-60">
          <CommandEmpty>无匹配</CommandEmpty>
          <CommandGroup>
            {!query.trim() && <CommandItem value="all-references" onSelect={() => choose("")} className="text-xs data-[selected=true]:bg-blue-50 data-[selected=true]:text-[#0052D9]"><Check className={value ? "opacity-0" : "opacity-100"} />全部</CommandItem>}
            {matches.map(ref => <CommandItem key={ref.key} value={ref.key} title={fullLabel(ref)} onSelect={() => choose(ref.key)} className="text-xs data-[selected=true]:bg-blue-50 data-[selected=true]:text-[#0052D9]"><Check className={value === ref.key ? "opacity-100" : "opacity-0"} /><span className="min-w-0 break-words">{fullLabel(ref)}</span></CommandItem>)}
          </CommandGroup>
          {!query.trim() && !matches.length && <p className="px-3 py-3 text-center text-xs text-slate-400">暂无可选{kind}</p>}
        </CommandList>
      </Command>
    </PopoverContent>
  </Popover>;
}