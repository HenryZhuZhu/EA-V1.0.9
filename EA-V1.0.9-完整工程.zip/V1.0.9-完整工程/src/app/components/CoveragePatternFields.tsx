import { BALL_TYPES, COVERAGE_QGS, COVERAGE_SPEEDS, COVERAGE_STATIONS, COVERAGE_TESTERS, PACKAGE_TYPES } from "./data";
import { PersonInput } from "./PersonInput";

export type CoveragePatternValue = {
  coverageSpeed?: string;
  coverageTester?: string;
  coverageQG?: string;
  coverageActionStage?: string;
  coveragePackage?: string;
  coverageBallType?: string;
  coverageReleaseType?: "Reject" | "Monitor";
  coverageTeOwner?: string;
  coveragePeOwner?: string;
};

function selectedValues(value: string | undefined, options: readonly string[]) {
  const values = (value || "").split(/[,，、;；|]+/).map((item) => item.trim()).filter(Boolean);
  return options.filter((option) => values.includes(option));
}

function MultiSelectField({ label, options, value, onChange, compact }: {
  label: string;
  options: readonly string[];
  value?: string;
  onChange: (value: string) => void;
  compact: boolean;
}) {
  const selected = selectedValues(value, options);
  const toggle = (option: string) => {
    const next = selected.includes(option) ? selected.filter((item) => item !== option) : [...selected, option];
    onChange(next.join("、"));
  };
  return (
    <div className="min-w-0 text-[11px] text-slate-500">
      <div className="flex items-center gap-1">
        <span>{label} <span className="text-red-500">*</span></span>
        <span className="ml-auto text-[9px] text-slate-400">{selected.length}/{options.length}</span>
        <button type="button" onClick={() => onChange(options.join("、"))} className="nodrag nopan text-[9px] text-cyan-700 hover:underline">全选</button>
        <button type="button" onClick={() => onChange("")} disabled={!selected.length} className="nodrag nopan text-[9px] text-slate-400 hover:text-slate-600 disabled:opacity-40">清空</button>
      </div>
      <details className="nodrag nopan nowheel mt-1 rounded border border-slate-200 bg-white open:border-cyan-400">
        <summary className={`flex cursor-pointer list-none items-center gap-1 px-2 ${compact ? "h-8 text-xs" : "h-9 text-sm"}`}>
          <span className={`min-w-0 flex-1 truncate ${selected.length ? "text-slate-700" : "text-slate-400"}`}>
            {selected.length === options.length ? "已选择全部" : selected.length ? selected.join("、") : "请选择"}
          </span>
          <span className="text-[9px] text-slate-400">▼</span>
        </summary>
        <div className="max-h-36 space-y-0.5 overflow-y-auto border-t border-slate-100 p-1.5">
          {options.map((option) => (
            <label key={option} className="flex cursor-pointer items-center gap-2 rounded px-1.5 py-1 text-[10.5px] text-slate-600 hover:bg-cyan-50">
              <input type="checkbox" checked={selected.includes(option)} onChange={() => toggle(option)} className="accent-cyan-600" />
              <span>{option}</span>
            </label>
          ))}
        </div>
      </details>
    </div>
  );
}

export function CoveragePatternFields({ value, onChange, compact = false }: {
  value: CoveragePatternValue;
  onChange: (next: CoveragePatternValue) => void;
  compact?: boolean;
}) {
  const height = compact ? "h-8 text-xs" : "h-9 text-sm";
  const selectClass = `mt-1 w-full ${height} px-2 rounded border border-slate-200 bg-white outline-none focus:border-cyan-500`;
  const patch = (next: Partial<CoveragePatternValue>) => onChange({ ...value, ...next });
  return (
    <div className="grid grid-cols-2 gap-2.5">
      <MultiSelectField label="Speed" options={COVERAGE_SPEEDS} value={value.coverageSpeed} onChange={(coverageSpeed) => patch({ coverageSpeed })} compact={compact} />
      <label className="text-[11px] text-slate-500">Tester <span className="text-red-500">*</span><select value={value.coverageTester || ""} onChange={(event) => patch({ coverageTester: event.target.value })} className={selectClass}><option value="">请选择</option>{COVERAGE_TESTERS.map((item) => <option key={item}>{item}</option>)}</select></label>
      <MultiSelectField label="测试站点" options={COVERAGE_STATIONS} value={value.coverageActionStage} onChange={(coverageActionStage) => patch({ coverageActionStage })} compact={compact} />
      <MultiSelectField label="Quality Grade" options={COVERAGE_QGS} value={value.coverageQG} onChange={(coverageQG) => patch({ coverageQG })} compact={compact} />
      <MultiSelectField label="Package" options={PACKAGE_TYPES} value={value.coveragePackage} onChange={(coveragePackage) => patch({ coveragePackage })} compact={compact} />
      <label className="text-[11px] text-slate-500">Ball type <span className="text-red-500">*</span><select value={value.coverageBallType || ""} onChange={(event) => patch({ coverageBallType: event.target.value })} className={selectClass}><option value="">请选择</option>{BALL_TYPES.map((item) => <option key={item}>{item}</option>)}</select></label>
      <label className="text-[11px] text-slate-500">Release type <span className="text-red-500">*</span><select value={value.coverageReleaseType || ""} onChange={(event) => patch({ coverageReleaseType: (event.target.value || undefined) as CoveragePatternValue["coverageReleaseType"] })} className={selectClass}><option value="">请选择</option><option value="Reject">Reject</option><option value="Monitor">Monitor</option></select></label>
    </div>
  );
}

export function CoverageOwnerFields({ value, onChange, compact = false }: {
  value: CoveragePatternValue;
  onChange: (next: CoveragePatternValue) => void;
  compact?: boolean;
}) {
  const height = compact ? "h-8 text-xs" : "h-9 text-sm";
  const patch = (next: Partial<CoveragePatternValue>) => onChange({ ...value, ...next });
  return (
    <div className="grid grid-cols-2 gap-2.5">
      <label className="text-[11px] text-slate-500">TE 负责人 <span className="text-red-500">*</span><div className="mt-1"><PersonInput value={value.coverageTeOwner || ""} onChange={(coverageTeOwner) => patch({ coverageTeOwner })} placeholder="@ 选择 TE 负责人" className={`w-full ${height} px-2 rounded border border-slate-200 bg-white outline-none focus:border-cyan-500`} /></div></label>
      <label className="text-[11px] text-slate-500">PE 负责人 <span className="text-red-500">*</span><div className="mt-1"><PersonInput value={value.coveragePeOwner || ""} onChange={(coveragePeOwner) => patch({ coveragePeOwner })} placeholder="@ 选择 PE 负责人" className={`w-full ${height} px-2 rounded border border-slate-200 bg-white outline-none focus:border-cyan-500`} /></div></label>
    </div>
  );
}