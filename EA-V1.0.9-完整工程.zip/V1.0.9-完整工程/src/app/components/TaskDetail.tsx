import {
  ArrowLeft,
  Upload,
  CheckCircle2,
  FileSpreadsheet,
  Sparkles,
  Plus,
  Circle,
  ListChecks,
  ListTree,
  Network,
  X,
  ChevronRight,
  Paperclip,
  Clock,
  Timer,
  ChevronDown,
  FlaskConical,
  RefreshCw,
  ExternalLink,
  Bell,
  BellRing,
} from "lucide-react";
import { useState, useMemo, useEffect, useRef } from "react";
import {
  mockCases,
  levelColors,
  urgencyColors,
  statusColors,
  validityColors,
  myTasksInCase,
  flattenTasks,
  currentUser,
  TaskNode,
  Urgency,
  Validity,
  TaskType,
  TASK_TYPES,
  departments,
  departmentSupervisors,
  efaTicketStatusColors,
} from "./data";
import { AddTaskModal, AddTaskPayload } from "./AddTaskModal";
import { VoiceInputButton } from "./VoiceInputButton";
import { MindMapFlow } from "./MindMapFlow";
import { CreateCaseWbsTable } from "./CreateCaseWbsTable";
import type { ThoughtGroup, ActionCard } from "./CreateCase";
import { PersonInput } from "./PersonInput";
import { VoicePlayer } from "./VoiceNote";
import { CaseProductPill } from "./CaseProductPill";
import { submitEfaTicket, useEfaTickets } from "./efaTickets";
import { useTaskSubscriptions } from "./taskSubscriptions";
import { caseTaskReadOnlyReason, commentOnCaseTask, loadCaseTaskTree, respondToCaseTask, saveCaseTaskTree, updateCaseTask, useCaseTaskRevision } from "./caseTaskTrees";
import { RejectTaskModal } from "./RejectTaskModal";
import { TaskAttachmentList } from "./TaskAttachmentList";
import { AttachmentInput } from "./AttachmentInput";
import { TaskActivityPanel } from "./TaskActivityPanel";
import { TerminateTaskModal } from "./TerminateTaskModal";
import { TaskDetailActions } from "./TaskDetailActions";
import { recoverCaseTask } from "./caseTaskTrees";
import { useClosures } from "./closures";
import { RecoveryActions, RecoveryBadge, RecoveryHistory } from "./RecoveryControls";

const URGENCY_OPTIONS: Urgency[] = ["非常紧急", "紧急", "一般", "不紧急"];

interface Props {
  caseId: string;
  taskId: string;
  onBack: () => void;
  onOpenCase: (id: string) => void;
  onSelectTask?: (taskId: string) => void;
}

// Find parent of a task within a case's task tree (top-level parent = the dept task)
function findParentChain(nodes: TaskNode[], targetId: string, chain: TaskNode[] = []): TaskNode[] | null {
  for (const n of nodes) {
    if (n.id === targetId) return chain;
    if (n.children) {
      const r = findParentChain(n.children, targetId, [...chain, n]);
      if (r) return r;
    }
  }
  return null;
}

export function TaskDetail({ caseId, taskId, onBack, onOpenCase, onSelectTask }: Props) {
  const c = mockCases.find((x) => x.id === caseId)!;
  const taskSubscriptions = useTaskSubscriptions();
  const caseTaskRevision = useCaseTaskRevision();
  useClosures();
  const caseTasks = useMemo(() => loadCaseTaskTree(c.id, c.tasks), [c, caseTaskRevision]);
  const [rejectingTask, setRejectingTask] = useState<TaskNode | null>(null);
  const [responseError, setResponseError] = useState("");
  const [terminating, setTerminating] = useState(false);
  // All tasks owned by the current engineer (flat, may include sub-tasks)
  const myFlat = useMemo(() => {
    const mine = myTasksInCase({ ...c, tasks: caseTasks }, currentUser.name);
    const target = flattenTasks(caseTasks).find((entry) => entry.task.id === taskId);
    return target && !mine.some((entry) => entry.task.id === target.task.id) ? [...mine, target] : mine;
  }, [c, caseTasks, taskId]);

  // Build per-root groups: only direct parent + my task + direct children
  type RootGroup = {
    directParent: TaskNode | null;
    myTask: TaskNode;
    subs: TaskNode[];
  };
  const rootGroups: RootGroup[] = useMemo(() => {
    return myFlat.map(({ task }) => {
      const chain = findParentChain(caseTasks, task.id) ?? [];
      const directParent = chain.length > 0 ? chain[chain.length - 1] : null;
      return {
        directParent,
        myTask: task,
        subs: task.children ?? [],
      };
    });
  }, [caseTasks, myFlat]);

  const [selectedId, setSelectedId] = useState<string>(taskId || myFlat[0]?.task.id);
  const [focusMine, setFocusMine] = useState(false);
  const [showUrgency, setShowUrgency] = useState(true);
  const [mmTab, setMmTab] = useState<"mindmap" | "data">("mindmap");

  // Update selectedId when taskId changes (e.g., clicking from CaseDetail)
  useEffect(() => {
    if (taskId) {
      setSelectedId(taskId);
    }
  }, [taskId]);

  // Track subtasks locally (mirror + mutations)
  const [subsMap, setSubsMap] = useState<Record<string, TaskNode[]>>(() => {
    const m: Record<string, TaskNode[]> = {};
    rootGroups.forEach((g) => (m[g.myTask.id] = g.subs));
    return m;
  });
  // New-subtask modal state
  const [addingFor, setAddingFor] = useState<string | null>(null);
  const [addingKind, setAddingKind] = useState<"怀疑目标" | "执行任务">("执行任务");
  // Local patches to "my task" top-level nodes (engineer self-editing priority/owner/dueDate)
  const [myPatch, setMyPatch] = useState<Record<string, Partial<TaskNode>>>({});
  // Per-task manual todo lists (keyed by task id)
  type TodoItem = { id: string; label: string; done: boolean };
  const [todosMap, setTodosMap] = useState<Record<string, TodoItem[]>>({});
  const getTodos = (taskId: string): TodoItem[] =>
    todosMap[taskId] ?? [
      { id: "m1", label: "对比基线数据", done: false },
      { id: "m2", label: "整理中间结论", done: false },
    ];
  const setTodos = (taskId: string, next: TodoItem[]) =>
    setTodosMap({ ...todosMap, [taskId]: next });

  const selected = useMemo(() => {
    // Look up in rootGroups first (my tasks), then their subs
    for (const g of rootGroups) {
      if (g.myTask.id === selectedId) return { ...g.myTask, ...myPatch[g.myTask.id] };
      const sub = (subsMap[g.myTask.id] ?? []).find((s) => s.id === selectedId);
      if (sub) return sub;
    }
    const first = rootGroups[0]?.myTask;
    return first ? { ...first, ...myPatch[first.id] } : first;
  }, [selectedId, rootGroups, subsMap, myPatch]);

  if (rootGroups.length === 0 || !selected) {
    return (
      <div className="p-6 text-sm text-slate-500">此 Case 下暂无分配给你的任务。</div>
    );
  }

  const openAddSub = (myTaskId: string, kind: "怀疑目标" | "执行任务" = "执行任务") => {
    setAddingFor(myTaskId);
    setAddingKind(kind);
  };

  const submitNewSub = (payload: AddTaskPayload) => {
    if (!addingFor) return;

    // Use addSubTask which handles preserving existing children
    addSubTask(addingFor, payload);
    setAddingFor(null);
  };

  const addSubTask = (parentId: string, payload: AddTaskPayload) => {
    const now = new Date();
    const dateStr = now.toISOString().slice(2, 10).replace(/-/g, '').slice(0, 6);
    const taskCounter = String(Date.now()).slice(-6);
    const code = payload.kind === "执行任务" ? `EA-${dateStr}${taskCounter}.001` : undefined;

    const newSub: TaskNode = {
      id: `s${Date.now()}`,
      code,
      title: payload.title,
      owner: payload.assignee.trim() || "待指派",
      department: payload.department,
      urgency: payload.urgency,
      dueDate: payload.dueDate || undefined,
      type: payload.type,
      note: payload.note,
      attachments: payload.attachments?.map((attachment) => ({ ...attachment })),
      voiceNote: payload.voiceNote,
      supervisor: payload.supervisor,
      site: payload.site,
      progress: 0,
      status: "待接受",
    };

    if (payload.efaRequest) {
      submitEfaTicket({
        caseId,
        taskId: newSub.id,
        taskTitle: newSub.title,
        submittedBy: currentUser.name,
        ...payload.efaRequest,
      });
    }

    const append = (nodes: TaskNode[]): TaskNode[] => nodes.map((node) => node.id === parentId ? { ...node, children: [...(node.children ?? []), newSub] } : { ...node, children: node.children ? append(node.children) : node.children });
    const saved = saveCaseTaskTree(caseId, append(loadCaseTaskTree(caseId, c.tasks)), true);
    const parent = flattenTasks(saved).find(({ task }) => task.id === parentId)?.task;
    if (parent) setSubsMap((previous) => ({ ...previous, [parentId]: parent.children ?? [] }));
  };

  // Let a department manager update assignee/urgency/dueDate for a subtask.
  const updateSub = (parentId: string, subId: string, patch: Partial<TaskNode>) => {
    setSubsMap({
      ...subsMap,
      [parentId]: (subsMap[parentId] ?? []).map((s) => (s.id === subId ? { ...s, ...patch } : s)),
    });
  };
  const findParentOfSub = (subId: string): string | null => {
    for (const pid of Object.keys(subsMap)) {
      if (subsMap[pid].some((s) => s.id === subId)) return pid;
    }
    return null;
  };

  const pick = (id: string) => {
    setSelectedId(id);
    onSelectTask?.(id);
  };

  // Build merged tasks tree with subsMap updates
  const mergedTasks = useMemo(() => {
    const mergeTasks = (tasks: TaskNode[]): TaskNode[] => {
      return tasks.map((task) => {
        const mergedTask = { ...task };
        if (subsMap[task.id]) {
          mergedTask.children = subsMap[task.id];
        } else if (task.children) {
          mergedTask.children = mergeTasks(task.children);
        }
        return mergedTask;
      });
    };
    return mergeTasks(caseTasks);
  }, [caseTasks, subsMap]);

  // 任务视图（表格）：与 Case 详情页复用同一套结构 TaskNode[] -> ThoughtGroup[]（只读展示 + 点击定位）
  const taskTreeToThoughtGroups = (nodes: TaskNode[] | undefined): ThoughtGroup[] =>
    (nodes ?? []).map((group) => ({
      id: group.id,
      thought: group.title,
      category: group.category,
      actions: (group.children ?? []).map((action): ActionCard => ({
        id: action.id,
        title: action.title,
        expectation: action.expectation,
        urgency: action.urgency,
        department: action.department,
        supervisor: action.supervisor,
        assignee: action.owner === "待指派" ? "" : action.owner,
        dueDate: action.dueDate ?? "",
        note: action.note,
        voiceNote: action.voiceNote,
        attachments: action.attachments,
        type: action.type,
        efaAnalysis: action.efaAnalysis,
        childGroups: taskTreeToThoughtGroups(action.children),
      })),
    }));
  const detailThoughtGroups = useMemo(() => taskTreeToThoughtGroups(mergedTasks), [mergedTasks]);

  const caseReadOnlyReason = caseTaskReadOnlyReason(caseId);
  const canEdit = selected.owner === currentUser.name && !caseReadOnlyReason && ["待接受", "进行中"].includes(selected.status);
  const canManage =
    !caseReadOnlyReason && ["待接受", "进行中"].includes(selected.status) && !!findParentOfSub(selected.id) &&
    rootGroups.some((g) => g.myTask.id === findParentOfSub(selected.id));
  const applySaved = (saved: TaskNode) => {
    const pid = findParentOfSub(saved.id);
    if (pid) {
      updateSub(pid, saved.id, saved);
    } else {
      setMyPatch((previous) => ({ ...previous, [saved.id]: { ...previous[saved.id], ...saved } }));
    }
  };
  const handleManage = (patch: Partial<TaskNode>) => {
    let saved: TaskNode;
    try { saved = updateCaseTask(caseId, selected.id, patch); setResponseError(""); }
    catch (reason) { setResponseError(reason instanceof Error ? reason.message : "保存失败，请重试。"); return false; }
    applySaved(saved);
    return true;
  };

  const respond = (id: string, response: "accept" | "reject", reason?: string) => {
    const updated = respondToCaseTask(caseId, id, response, reason);
    const patch = { status: updated.status, rejectReason: updated.rejectReason, statusHistory: updated.statusHistory };
    setMyPatch((previous) => ({ ...previous, [id]: { ...previous[id], ...patch } }));
    const updateNodes = (nodes: TaskNode[]): TaskNode[] => nodes.map((node) => ({
      ...node,
      ...(node.id === id ? patch : {}),
      children: node.children ? updateNodes(node.children) : node.children,
    }));
    setSubsMap((previous) => Object.fromEntries(Object.entries(previous).map(([parentId, nodes]) => [parentId, updateNodes(nodes)])));
    setResponseError("");
  };
  const handleAdvance = (patch: Partial<TaskNode>) => {
    if (selected.status === "待接受" && patch.status === "已拒绝") { setRejectingTask(selected); return; }
    if (selected.status === "待接受" && patch.status === "进行中") {
      try { respond(selected.id, "accept"); }
      catch (error) { setResponseError(error instanceof Error ? error.message : "操作失败，请重试。"); }
      return;
    }
    handleManage(patch);
  };

  return (
    <div className="p-6 space-y-4">
      <div>
        <button
          onClick={onBack}
          className="text-sm text-slate-500 hover:text-[#0052D9] flex items-center gap-1"
        >
          <ArrowLeft size={14} /> 返回
        </button>
      </div>

      {/* 行动卡（R14）· 方案 11 两级标题：Case 弱（上下文行）+ 任务强 */}
      {responseError && <p role="alert" className="rounded-lg bg-red-50 px-3 py-2 text-xs text-red-600">{responseError}</p>}
      <ActionCard
        task={selected}
        recoveryTools={<RecoveryActions record={selected} owner={selected.owner} title={selected.title} completed={selected.status === "已完成"} active={selected.status === "进行中"} parentClosed={Boolean(caseReadOnlyReason)} blocked={!selected.code ? "思路节点不支持此操作" : undefined} onAction={(action, text, files, dueDate) => applySaved(recoverCaseTask(caseId, selected.id, action, text, files, dueDate))} />}
        caseItem={c}
        taskCount={rootGroups.length}
        canEdit={canEdit}
        followed={taskSubscriptions.isFollowed(caseId, selected.id)}
        onToggleFollow={() => taskSubscriptions.toggle(caseId, selected.id)}
        onAdvance={handleAdvance}
        onOpenCase={() => onOpenCase(caseId)}
      />
      <RecoveryHistory record={selected} />
      {rejectingTask && <RejectTaskModal title={rejectingTask.title} onClose={() => setRejectingTask(null)} onConfirm={(reason) => respond(rejectingTask.id, "reject", reason)} />}

      <div className="space-y-4">
          {/* 分析过程与结论 —— 置于任务思维导图上方，与 Case 详情页保持一致 */}
          <InlinePanel
            key={`panel-${selected.id}`}
            caseId={caseId}
            task={selected}
            canEdit={canEdit}
            canManage={canManage}
            onManage={handleManage}
          />

          <div className="bg-white border border-slate-200 rounded-lg">
            <div className="px-4 py-3 border-b border-slate-100 flex items-center gap-2">
              <h3 className="text-slate-900 text-sm">分析任务</h3>
              <div className="ml-auto inline-flex items-center rounded-lg border border-slate-200 bg-slate-50 p-0.5">
                <button
                  onClick={() => setMmTab("mindmap")}
                  className={`h-7 px-2.5 rounded-md text-[12px] font-medium inline-flex items-center gap-1.5 transition-colors ${mmTab === "mindmap" ? "bg-white text-[#0052D9] shadow-sm" : "text-slate-500 hover:text-slate-700"}`}
                >
                  <Network size={13} /> 思维导图
                </button>
                <button
                  onClick={() => setMmTab("data")}
                  className={`h-7 px-2.5 rounded-md text-[12px] font-medium inline-flex items-center gap-1.5 transition-colors ${mmTab === "data" ? "bg-white text-[#0052D9] shadow-sm" : "text-slate-500 hover:text-slate-700"}`}
                >
                  <ListTree size={13} /> 任务视图
                </button>
              </div>
            </div>
            <div className="p-4 min-h-[360px]">
              {mmTab === "mindmap" ? (
                <MindMapFlow
                  caseItem={c}
                  tasks={mergedTasks}
                  focusMine={focusMine}
                  showUrgency={showUrgency}
                  onTaskClick={(tid) => pick(tid)}
                  onAddChild={(parentId, payload) => {
                    if (parentId) {
                      addSubTask(parentId, payload);
                    }
                  }}
                  onEditTask={(taskId, payload) => {
                    // Handle edit task
                  }}
                  onDelete={(taskId) => {
                    // Handle delete task
                  }}
                />
              ) : (
                <CreateCaseWbsTable
                  caseData={c}
                  thoughtGroups={detailThoughtGroups}
                  onGroupsChange={() => { /* 任务详情页导航视图：编辑不回写（与导图一致） */ }}
                  onTaskOpen={(tid) => pick(tid)}
                />
              )}
            </div>
          </div>

          {/* 状态时间线：响应时长 / 各阶段停留（置于任务思维导图下方） */}
          {selected.statusHistory && selected.statusHistory.length > 0 && <StatusTimeline history={selected.statusHistory} />}

          {/* 流转日志与评论始终作为详情内容的最后一个模块，底部操作栏在其后。 */}
          <TaskActivityPanel key={`activity-${caseId}-${selected.id}`} activities={flattenTasks(caseTasks).find(({ task }) => task.id === selected.id)?.task.activityLog} comments={flattenTasks(caseTasks).find(({ task }) => task.id === selected.id)?.task.comments} statusHistory={flattenTasks(caseTasks).find(({ task }) => task.id === selected.id)?.task.statusHistory} onComment={(content, replyTo) => { commentOnCaseTask(caseId, selected.id, content, replyTo); }} />

          {addingFor && (
            <AddTaskModal
              defaultDepartment={currentUser.department}
              titleLabel={addingKind === "执行任务" ? "新增执行任务" : "新增思路/怀疑方向"}
              initial={{ kind: addingKind }}
              onCancel={() => setAddingFor(null)}
              onSubmit={submitNewSub}
            />
          )}
      </div>

      {selected.code && <TaskDetailActions onCancel={onBack} onTerminate={() => setTerminating(true)} onComplete={() => { handleManage({ status: "已完成", progress: 100 }); }}
        terminateReason={caseReadOnlyReason || (!canEdit ? "仅任务负责人可以中止。" : !["待接受", "进行中"].includes(selected.status) ? "仅待接受或进行中的任务可以中止。" : undefined)}
        completeReason={caseReadOnlyReason || (!canEdit ? "仅任务负责人可以完成。" : selected.status !== "进行中" ? "仅进行中的任务可以完成。" : undefined)}
        hint={caseReadOnlyReason || "取消仅返回；完成前请在 Workspace 保存结论"} />}

      {terminating && <TerminateTaskModal title={selected.title} onClose={() => setTerminating(false)} onConfirm={(reason) => { if (!handleManage({ status: "已中止", terminateReason: reason })) throw new Error("中止保存失败，请检查任务状态或浏览器存储后重试。"); }} />}

    </div>
  );
}

// ---------- 状态时间线（响应时长 / 阶段停留，来自 statusHistory） ----------
const SLA_RESPONSE_HOURS = 24; // 派单响应 SLA 目标：24h 内接受

function StatusTimeline({ history }: { history: NonNullable<TaskNode["statusHistory"]> }) {
  const parse = (s: string) => new Date(s.replace(" ", "T")).getTime();
  const fmtDur = (ms: number) => {
    if (ms < 0) return "—";
    const h = ms / 3600000;
    if (h < 1) return `${Math.max(1, Math.round(ms / 60000))} 分钟`;
    if (h < 48) return `${h.toFixed(1)} 小时`;
    return `${(h / 24).toFixed(1)} 天`;
  };
  const STC: Record<string, string> = {
    待接受: "#64748b", 进行中: "#0052D9",
    已完成: "#16a34a", 已中止: "#ef4444", 已拒绝: "#e11d48",
  };
  const sorted = [...history];
  const accept = sorted.find((h) => h.status === "待接受");
  const start = sorted.find((h) => h.status === "进行中");
  const responseMs = accept && start ? parse(start.at) - parse(accept.at) : null;
  const overSLA = responseMs != null && responseMs > SLA_RESPONSE_HOURS * 3600000;
  const totalMs = sorted.length >= 2 ? parse(sorted[sorted.length - 1].at) - parse(sorted[0].at) : null;
  const terminal = ["已完成", "已中止", "已拒绝"];
  const isOngoing = !terminal.includes(sorted[sorted.length - 1].status);
  const [open, setOpen] = useState(false);

  return (
    <div className="rounded-lg border border-slate-200 bg-white px-3 py-2">
      {/* 折叠态：一行 = 标题 + 响应/总时长药丸 + 展开 */}
      <button onClick={() => setOpen((o) => !o)} className="w-full flex items-center gap-2 text-left">
        <Clock size={13} className="text-[#0052D9] shrink-0" />
        <span className="text-[11.5px] font-medium text-slate-600 shrink-0">状态时间线</span>
        <span className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10.5px] ${overSLA ? "bg-rose-50 text-rose-600" : responseMs != null ? "bg-emerald-50 text-emerald-700" : "bg-slate-100 text-slate-500"}`}>
          <Timer size={11} /> 响应 <b className="tabular-nums">{responseMs != null ? fmtDur(responseMs) : "待接受"}</b>
          {responseMs != null && <span className="opacity-70">· {overSLA ? "超 SLA" : "达标"}</span>}
        </span>
        <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10.5px] bg-slate-100 text-slate-500">
          {isOngoing ? "已历时" : "总时长"} <b className="tabular-nums">{totalMs != null ? fmtDur(totalMs) : "—"}</b>
        </span>
        <span className="ml-auto flex items-center gap-1 text-[10.5px] text-slate-400 shrink-0">
          {open ? "收起" : "展开"} <ChevronDown size={13} className={`transition-transform ${open ? "rotate-180" : ""}`} />
        </span>
      </button>

      {/* 展开态：完整时间轴 */}
      {open && (
      <div className="relative pl-1 mt-3 pt-3 border-t border-slate-100">
        <div className="text-[10.5px] text-slate-400 mb-2">派单响应 = 待接受 → 进行中（SLA 目标 {SLA_RESPONSE_HOURS}h）</div>
        {sorted.map((h, i) => {
          const next = sorted[i + 1];
          const stayMs = next ? parse(next.at) - parse(h.at) : null;
          const color = STC[h.status] || "#94a3b8";
          const isLast = i === sorted.length - 1;
          return (
            <div key={i} className="relative flex gap-3 pb-3 last:pb-0">
              {/* 连接线 */}
              {!isLast && <span className="absolute left-[5px] top-3.5 bottom-0 w-px bg-slate-200" />}
              <span className="relative z-10 mt-1 w-2.5 h-2.5 rounded-full shrink-0" style={{ background: color, boxShadow: `0 0 0 3px ${color}1a` }} />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-[12px] font-medium" style={{ color }}>{h.status}</span>
                  <span className="text-[11px] text-slate-400 tabular-nums">{h.at}</span>
                  {h.by && <span className="text-[11px] text-slate-400">· {h.by}</span>}
                  {stayMs != null && (
                    <span className="text-[10px] text-slate-500 bg-slate-100 rounded px-1.5 py-0.5">停留 {fmtDur(stayMs)}</span>
                  )}
                </div>
              </div>
            </div>
          );
        })}
        {isOngoing && (
          <div className="flex gap-3 text-[11px] text-slate-400">
            <span className="mt-1 w-2.5 h-2.5 rounded-full border-2 border-dashed border-slate-300 shrink-0" />
            <span className="mt-0.5">进行中…（尚未进入终态）</span>
          </div>
        )}
      </div>
      )}
    </div>
  );
}

// ---------- Inline edit panel ----------
function InlinePanel({
  caseId,
  task,
  canEdit,
  canManage,
  onManage,
}: {
  caseId: string;
  task: TaskNode;
  canEdit: boolean;
  canManage?: boolean;
  onManage?: (patch: Partial<TaskNode>) => boolean;
}) {
  const [docOpen, setDocOpen] = useState(false);
  const [process, setProcess] = useState(task.analysisProcess ?? "");
  const [saveError, setSaveError] = useState("");

  const conclusion = task.conclusion ?? "";

  return (
    <div className="bg-white border border-slate-200 rounded-lg p-5">
      {/* 分析过程与结论 —— 与 Case 详情页保持统一的卡片样式 */}
      <div
        onClick={() => setDocOpen(true)}
        className="group cursor-pointer rounded-xl border border-slate-200 p-4 hover:border-[#0052D9]/40 hover:shadow-sm transition-all"
      >
        <div className="flex items-center gap-2.5">
          <span className="w-8 h-8 rounded-lg bg-[#0052D9]/8 text-[#0052D9] flex items-center justify-center shrink-0">
            <FileSpreadsheet size={16} />
          </span>
          <div className="min-w-0">
            <div className="text-sm text-slate-800 font-medium">分析过程与结论</div>
            <div className="text-[11px] text-slate-400">现象 → 假设 → 验证 → 结论 · 支持富文本 / 图表 / 附件</div>
          </div>
          <span className="ml-auto shrink-0 text-[11px] text-slate-400 group-hover:text-[#0052D9] inline-flex items-center gap-0.5">
            {canEdit ? "进入 Workspace 编辑" : "查看 Workspace 文档"} <ChevronRight size={13} />
          </span>
        </div>
        <div className="mt-2.5 rounded-lg bg-slate-50/70 border border-slate-100 px-3 py-2.5">
          <div className="text-xs text-slate-600 leading-relaxed line-clamp-2">
            {conclusion || (
              <span className="text-slate-400">暂无结论，点击撰写分析过程与结论。</span>
            )}
          </div>
        </div>
        {/* 结论有效性 */}
        <div className="mt-2.5 flex items-center gap-2 justify-end" onClick={(e) => e.stopPropagation()}>
          <span className="text-xs text-slate-500">结论有效性</span>
          <div className="flex gap-1">
            {(["有效", "部分有效", "无效"] as Validity[]).map((v) => {
              const active = task.validity === v;
              const tone =
                v === "有效"
                  ? active ? "bg-emerald-500 text-white border-emerald-500" : "border-emerald-200 text-emerald-700 hover:bg-emerald-50"
                  : v === "无效"
                  ? active ? "bg-red-500 text-white border-red-500" : "border-red-200 text-red-600 hover:bg-red-50"
                  : active ? "bg-amber-500 text-white border-amber-500" : "border-amber-200 text-amber-700 hover:bg-amber-50";
              return (
                <button
                  key={v}
                  disabled={!(canEdit || canManage)}
                  onClick={() => onManage?.({ validity: active ? undefined : v })}
                  className={`h-6 px-2 text-[11px] rounded border transition-all disabled:opacity-50 ${tone}`}
                >
                  {v}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {docOpen && (
        <CloudDocModal
          task={task}
          canEdit={canEdit}
          initialConclusion={conclusion}
          initialProcess={process}
          onClose={() => setDocOpen(false)}
          onSave={(payload) => {
            if (!onManage?.({ conclusion: payload.conclusion, analysisProcess: payload.process })) { setSaveError("保存失败，请检查任务权限、状态或浏览器存储后重试；草稿已保留。"); return; }
            setSaveError("");
            setProcess(payload.process);
            setDocOpen(false);
          }}
          saveError={saveError}
        />
      )}

      <div>
        <div className="text-xs text-slate-600 mb-1">过程数据 / 附件</div>
        {canEdit ? <div className="rounded-md border border-dashed border-slate-300 p-4"><AttachmentInput value={task.attachments ?? []} onChange={(attachments) => { if (!onManage?.({ attachments })) throw new Error("附件保存失败，请重试。"); }} /><p className="mt-2 text-[11px] text-slate-400">上传或移除后保存到任务，并记录修改日志。</p></div> : <p className="mt-2 text-xs text-slate-400">任务附件见上方附件列表。</p>}
      </div>

      <div className="flex items-center gap-2 pt-2 border-t border-slate-100">
        <Sparkles size={12} className="text-[#7A3DFF]" />
        <span className="text-[11px] text-slate-500">EA 会基于你填写的结论与过程自动汇总至 Case · 「完成 / 中止」见页面底部操作栏</span>
      </div>
    </div>
  );
}

function EfaRequestModal({
  task,
  onClose,
  onSubmit,
}: {
  task: TaskNode;
  onClose: () => void;
  onSubmit: (payload: { sample: string; failMode: string; request: string }) => void;
}) {
  const [sample, setSample] = useState("");
  const [failMode, setFailMode] = useState("");
  const [request, setRequest] = useState(`请针对「${task.title}」进行失效定位，输出物理失效位置、失效机理与支撑图片。`);
  const ready = sample.trim() && failMode.trim() && request.trim();
  return (
    <div className="fixed inset-0 z-[120] bg-slate-950/55 backdrop-blur-sm flex items-center justify-center p-8" onClick={onClose}>
      <div className="w-[620px] bg-white rounded-2xl shadow-2xl overflow-hidden" onClick={(e) => e.stopPropagation()}>
        <div className="px-5 py-4 bg-gradient-to-r from-violet-600 to-[#0052D9] text-white flex items-center gap-3">
          <span className="w-9 h-9 rounded-xl bg-white/15 flex items-center justify-center"><FlaskConical size={18} /></span>
          <div>
            <div className="font-semibold">提 EFA 分析单</div>
            <div className="text-[11px] text-white/75 mt-0.5">提交后将在 QMS 自动建立 EFA 单，并持续同步分析状态与结果</div>
          </div>
          <button onClick={onClose} className="ml-auto w-7 h-7 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center"><X size={14} /></button>
        </div>
        <div className="p-5 space-y-4">
          <div className="rounded-lg border border-slate-100 bg-slate-50 px-3 py-2 text-xs text-slate-600">
            来源任务：<b className="text-slate-800">{task.title}</b>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <label className="text-xs text-slate-600">送分析样品 / 颗粒 <span className="text-red-500">*</span>
              <input value={sample} onChange={(e) => setSample(e.target.value)} placeholder="如：IC-03 / SN-DMJFC-003" className="mt-1.5 w-full h-9 px-3 rounded-lg border border-slate-200 outline-none focus:border-[#0052D9] text-sm" autoFocus />
            </label>
            <label className="text-xs text-slate-600">失效模式 <span className="text-red-500">*</span>
              <input value={failMode} onChange={(e) => setFailMode(e.target.value)} placeholder="如：Leakage / Bit Fail / Open" className="mt-1.5 w-full h-9 px-3 rounded-lg border border-slate-200 outline-none focus:border-[#0052D9] text-sm" />
            </label>
          </div>
          <label className="block text-xs text-slate-600">分析诉求 <span className="text-red-500">*</span>
            <textarea value={request} onChange={(e) => setRequest(e.target.value)} rows={4} className="mt-1.5 w-full p-3 rounded-lg border border-slate-200 outline-none focus:border-[#0052D9] text-sm leading-relaxed resize-none" />
          </label>
          <div className="rounded-lg bg-blue-50 border border-blue-100 px-3 py-2.5 text-[11px] text-blue-700 leading-relaxed">
            提交后：EA 保存映射关系 → QMS 自动生成 EFA 单号 → EFA 同事在 QMS 接单分析 → 结论及附件自动回同步到当前任务。
          </div>
        </div>
        <div className="px-5 py-3.5 border-t border-slate-100 flex justify-end gap-2">
          <button onClick={onClose} className="h-8 px-4 rounded-lg border border-slate-200 text-xs text-slate-600 hover:bg-slate-50">取消</button>
          <button disabled={!ready} onClick={() => onSubmit({ sample: sample.trim(), failMode: failMode.trim(), request: request.trim() })} className="h-8 px-4 rounded-lg bg-[#0052D9] text-white text-xs font-medium hover:bg-[#003FA8] disabled:bg-slate-300 inline-flex items-center gap-1.5">
            <ExternalLink size={12} /> 提交并在 QMS 建单
          </button>
        </div>
      </div>
    </div>
  );
}

function EfaSyncModal({ ticketCode, onClose, onSync }: { ticketCode: string; onClose: () => void; onSync: (value: string) => void }) {
  const [value, setValue] = useState("EMMI 定位到 IC 边缘电源网络异常发光点；切片确认 Metal 层存在局部桥连，判断为制程残留导致的 Leakage。建议追加同批次样品抽检并检查清洗参数。");
  return (
    <div className="fixed inset-0 z-[120] bg-slate-950/55 backdrop-blur-sm flex items-center justify-center p-8" onClick={onClose}>
      <div className="w-[600px] bg-white rounded-2xl shadow-2xl overflow-hidden" onClick={(e) => e.stopPropagation()}>
        <div className="px-5 py-4 border-b border-slate-100 flex items-center gap-3">
          <span className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center"><RefreshCw size={17} /></span>
          <div><div className="font-semibold text-slate-900">模拟 QMS 结果回同步</div><div className="text-[11px] text-slate-400 mt-0.5">{ticketCode} · 结论和 2 个附件将写回 EA 当前任务</div></div>
          <button onClick={onClose} className="ml-auto w-7 h-7 rounded-lg hover:bg-slate-100 flex items-center justify-center text-slate-400"><X size={14} /></button>
        </div>
        <div className="p-5">
          <label className="block text-xs text-slate-600">EFA 分析结论
            <textarea value={value} onChange={(e) => setValue(e.target.value)} rows={6} className="mt-1.5 w-full p-3 rounded-lg border border-slate-200 outline-none focus:border-emerald-500 text-sm leading-relaxed resize-none" autoFocus />
          </label>
          <div className="mt-3 flex gap-2 text-[11px] text-slate-500">
            <span className="px-2 py-1 rounded border border-slate-200 bg-slate-50">EFA分析报告.pdf</span>
            <span className="px-2 py-1 rounded border border-slate-200 bg-slate-50">定位图片.png</span>
          </div>
        </div>
        <div className="px-5 py-3.5 border-t border-slate-100 flex justify-end gap-2">
          <button onClick={onClose} className="h-8 px-4 rounded-lg border border-slate-200 text-xs text-slate-600">取消</button>
          <button disabled={!value.trim()} onClick={() => onSync(value.trim())} className="h-8 px-4 rounded-lg bg-emerald-600 text-white text-xs font-medium hover:bg-emerald-700 disabled:bg-slate-300 inline-flex items-center gap-1.5"><RefreshCw size={12} /> 同步回 EA</button>
        </div>
      </div>
    </div>
  );
}

// ---------- Side rail ----------
function ManualTodo({
  canEdit,
  items,
  onChange,
  taskTitle,
}: {
  canEdit: boolean;
  items: { id: string; label: string; done: boolean }[];
  onChange: (next: { id: string; label: string; done: boolean }[]) => void;
  taskTitle?: string;
}) {
  const [draft, setDraft] = useState("");
  const add = () => {
    if (!draft.trim()) return;
    onChange([...items, { id: `m${Date.now()}`, label: draft.trim(), done: false }]);
    setDraft("");
  };
  const toggle = (id: string) =>
    onChange(items.map((x) => (x.id === id ? { ...x, done: !x.done } : x)));
  return (
    <div className="bg-white border border-slate-200 rounded-lg overflow-hidden">
      <div className="px-4 py-2.5 border-b border-slate-100">
        <div className="flex items-center gap-2">
          <ListChecks size={13} className="text-[#0052D9]" />
          <h4 className="text-slate-900">待办清单</h4>
          <span className="text-[11px] text-slate-400 ml-auto">随任务切换</span>
        </div>
        {taskTitle && (
          <div className="mt-1 text-[11px] text-slate-500 leading-snug line-clamp-2">
            当前任务：{taskTitle}
          </div>
        )}
      </div>
      <div className="p-3 space-y-1.5">
        {items.map((t) => (
          <div
            key={t.id}
            onClick={() => canEdit && toggle(t.id)}
            className={`flex items-center gap-2 px-2 py-2 rounded-md cursor-pointer ${
              t.done ? "text-slate-500" : "hover:bg-slate-50"
            }`}
          >
            {t.done ? (
              <CheckCircle2 size={14} className="text-[#00B578] shrink-0" />
            ) : (
              <Circle size={14} className="text-slate-300 shrink-0" />
            )}
            <span className={`text-sm flex-1 ${t.done ? "line-through" : "text-slate-800"}`}>
              {t.label}
            </span>
          </div>
        ))}
        <div className="flex items-center gap-1.5 pt-2 border-t border-slate-100">
          <input
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && add()}
            disabled={!canEdit}
            placeholder="手动添加一条待办 · Enter 提交"
            className="flex-1 h-8 px-2 text-xs rounded border border-slate-200 bg-white outline-none focus:border-[#0052D9] disabled:bg-slate-50"
          />
          <button
            onClick={add}
            disabled={!canEdit || !draft.trim()}
            className="h-8 px-2 text-xs rounded bg-[#0052D9] text-white hover:bg-[#003FA8] disabled:opacity-40 flex items-center gap-1"
          >
            <Plus size={11} /> 添加
          </button>
        </div>
      </div>
    </div>
  );
}

function AiLiveFeed({ timeline }: { timeline: any[] }) {
  const tagPalette: Record<string, string> = {
    风险: "bg-red-50 text-red-600 border-red-100",
    进展: "bg-emerald-50 text-emerald-600 border-emerald-100",
    数据: "bg-amber-50 text-amber-600 border-amber-100",
    协作: "bg-blue-50 text-blue-600 border-blue-100",
    决策: "bg-purple-50 text-purple-600 border-purple-100",
    结论: "bg-slate-100 text-slate-700 border-slate-200",
  };

  const feed = [
    {
      time: "11:08",
      user: "EA 助手",
      isAi: true,
      content:
        "检测到 Lot B 的 VDDmin 偏移与 Lot A 一致，建议合并分析；已自动关联 CASE-0821。",
      tags: ["风险", "数据"],
      important: true,
    },
    {
      time: "10:42",
      user: "李娜",
      content: "Shmoo 重测数据已上传，见 shmoo_vddmin_v2.xlsx。",
      tags: ["数据", "进展"],
    },
    {
      time: "10:15",
      user: "EA 助手",
      isAi: true,
      content: "基于最新 shmoo 数据，置信度 78%：probe card 接触压力不是主因。",
      tags: ["结论"],
    },
    {
      time: "09:30",
      user: "张伟",
      content: "已升级至 L3，邀请 DA/PE 介入。",
      tags: ["协作", "决策"],
    },
    ...timeline.slice(0, 2).map((x: any) => ({
      time: x.time,
      user: x.user,
      content: x.content,
      tags: ["协作"],
    })),
  ];

  return (
    <div className="bg-white border border-slate-200 rounded-lg overflow-hidden">
      <div className="px-4 py-2.5 border-b border-slate-100 flex items-center gap-2">
        <div className="relative">
          <div className="w-6 h-6 rounded-md bg-gradient-to-br from-[#0052D9] to-[#7A3DFF] text-white flex items-center justify-center">
            <Sparkles size={11} />
          </div>
          <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-emerald-500 ring-2 ring-white animate-pulse" />
        </div>
        <div>
          <h4 className="text-slate-900">AI 实时动态</h4>
          <div className="text-[10px] text-slate-400 leading-tight">
            AI + 参与人
          </div>
        </div>
        <span className="ml-auto text-[10px] text-emerald-600 flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" /> LIVE
        </span>
      </div>

      <div className="max-h-[360px] overflow-y-auto">
        {feed.map((item, i) => (
          <div
            key={i}
            className={`relative px-4 py-2.5 border-b border-slate-50 last:border-b-0 ${
              item.important ? "bg-gradient-to-r from-[#0052D9]/4 to-transparent" : ""
            }`}
          >
            {item.important && (
              <div className="absolute left-0 top-2 bottom-2 w-0.5 bg-gradient-to-b from-[#0052D9] to-[#7A3DFF] rounded-r" />
            )}
            <div className="flex items-center gap-1.5 mb-1">
              {item.isAi ? (
                <span className="px-1.5 py-0.5 rounded text-[9px] bg-gradient-to-r from-[#0052D9] to-[#7A3DFF] text-white flex items-center gap-0.5">
                  <Sparkles size={8} /> AI
                </span>
              ) : (
                <span className="w-4 h-4 rounded-full bg-slate-200 text-slate-600 text-[9px] flex items-center justify-center">
                  {item.user[0]}
                </span>
              )}
              <span className={`text-[11px] ${item.isAi ? "text-[#7A3DFF]" : "text-slate-700"}`}>
                {item.user}
              </span>
              <span className="text-[10px] text-slate-400">· {item.time}</span>
            </div>
            <div className="text-xs text-slate-700 leading-relaxed pl-0.5">{item.content}</div>
            <div className="mt-1.5 flex flex-wrap gap-1">
              {item.tags.map((t) => (
                <span
                  key={t}
                  className={`px-1.5 py-0.5 rounded text-[10px] border ${
                    tagPalette[t] || "bg-slate-50 text-slate-500 border-slate-200"
                  }`}
                >
                  #{t}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ---------- New-subtask modal ----------
function AddSubtaskModal({
  defaultDepartment,
  onCancel,
  onSubmit,
}: {
  defaultDepartment: string;
  onCancel: () => void;
  onSubmit: (payload: { title: string; department: string; dueDate: string; urgency: Urgency; assignee: string; type?: TaskType }) => void;
}) {
  const [title, setTitle] = useState("");
  const [department, setDepartment] = useState(defaultDepartment);
  const [dueDate, setDueDate] = useState("");
  const [urgency, setUrgency] = useState<Urgency>("一般");
  const [assignee, setAssignee] = useState("");
  const [type, setType] = useState<TaskType | "">("");

  const canSubmit = title.trim().length > 0 && department.trim().length > 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40" onClick={onCancel}>
      <div
        className="w-[440px] bg-white rounded-lg shadow-xl border border-slate-200 p-5 space-y-4"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-2">
          <Plus size={14} className="text-[#0052D9]" />
          <h3 className="text-slate-900">新增卡片</h3>
          <button onClick={onCancel} className="ml-auto text-slate-400 hover:text-slate-600">
            <X size={16} />
          </button>
        </div>

        <label className="block text-xs text-slate-600">
          任务名称
          <input
            autoFocus
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="简要描述子任务"
            className="mt-1 w-full h-9 px-2.5 text-sm rounded border border-slate-200 outline-none focus:border-[#0052D9]"
          />
        </label>

        <div className="grid grid-cols-2 gap-3">
          <label className="block text-xs text-slate-600">
            分派部门
            <select
              value={department}
              onChange={(e) => setDepartment(e.target.value)}
              className="mt-1 w-full h-9 px-2.5 text-sm rounded border border-slate-200 outline-none focus:border-[#0052D9] bg-white"
            >
              {departments.map((d) => (
                <option key={d} value={d}>{d}</option>
              ))}
            </select>
          </label>
          <label className="block text-xs text-slate-600">
            紧急程度
            <select
              value={urgency}
              onChange={(e) => setUrgency(e.target.value as Urgency)}
              className="mt-1 w-full h-9 px-2.5 text-sm rounded border border-slate-200 outline-none focus:border-[#0052D9] bg-white"
            >
              {URGENCY_OPTIONS.map((u) => (
                <option key={u} value={u}>{u}</option>
              ))}
            </select>
          </label>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <label className="block text-xs text-slate-600">
            希望完成日期
            <input
              type="date"
              value={dueDate}
              onChange={(e) => setDueDate(e.target.value)}
              className="mt-1 w-full h-9 px-2.5 text-sm rounded border border-slate-200 outline-none focus:border-[#0052D9]"
            />
          </label>
          <label className="block text-xs text-slate-600">
            任务负责人 <span className="text-slate-400">（可选）</span>
            <input
              value={assignee}
              onChange={(e) => setAssignee(e.target.value)}
              placeholder="留空则由部门经理指派"
              className="mt-1 w-full h-9 px-2.5 text-sm rounded border border-slate-200 outline-none focus:border-[#0052D9]"
            />
          </label>
        </div>

        <div className="text-[11px] text-slate-500 leading-relaxed pt-1">
          提交后将进入该部门经理的收件箱，由其指派工程师并可调整紧急程度与完成日期。
        </div>
        <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
          <button
            onClick={onCancel}
            className="h-8 px-3 text-sm rounded-md border border-slate-200 text-slate-600 hover:bg-slate-50"
          >
            取消
          </button>
          <button
            disabled={!canSubmit}
            onClick={() => onSubmit({ title: title.trim(), department, dueDate, urgency, assignee, type: type || undefined })}
            className="h-8 px-3.5 text-sm rounded-md bg-[#0052D9] text-white hover:bg-[#003FA8] disabled:opacity-40 inline-flex items-center gap-1"
          >
            <CheckCircle2 size={13} /> 创建
          </button>
        </div>
      </div>
    </div>
  );
}

// ---------- Cloud doc modal (大画板) ----------
function CloudDocModal({
  task,
  canEdit,
  initialConclusion,
  initialProcess,
  onClose,
  onSave,
  saveError,
}: {
  task: TaskNode;
  canEdit: boolean;
  initialConclusion: string;
  initialProcess: string;
  onClose: () => void;
  onSave: (payload: { conclusion: string; process: string }) => void;
  saveError?: string;
}) {
  const [conclusion, setConclusion] = useState(initialConclusion);
  const [process, setProcess] = useState(initialProcess);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50" onClick={onClose}>
      <div
        className="w-[860px] max-h-[88vh] bg-white rounded-xl shadow-2xl border border-slate-200 flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="px-5 py-3 border-b border-slate-100 flex items-center gap-2">
          <FileSpreadsheet size={14} className="text-[#0052D9]" />
          <h3 className="text-slate-900">{task.title} · 分析过程与结论</h3>
          <span className="text-[11px] text-slate-400">点击保存并回写后生效</span>
          <button onClick={onClose} className="ml-auto text-slate-400 hover:text-slate-600">
            <X size={16} />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          <section>
            <div className="text-xs text-slate-600 mb-1.5">结论（一句话写清）</div>
            <textarea
              value={conclusion}
              onChange={(e) => setConclusion(e.target.value)}
              disabled={!canEdit}
              placeholder="如：Pattern P_ICC2_07 在低压下过激，叠加 wafer 边缘工艺偏移。"
              className="w-full min-h-[80px] p-3 text-sm rounded-md border border-slate-200 outline-none focus:border-[#0052D9] disabled:bg-slate-50"
            />
          </section>
          <section>
            <div className="text-xs text-slate-600 mb-1.5">分析过程（现象 → 假设 → 验证 → 结论）</div>
            <textarea
              value={process}
              onChange={(e) => setProcess(e.target.value)}
              disabled={!canEdit}
              placeholder="详细记录分析步骤、对照数据、决策依据..."
              className="w-full min-h-[300px] p-3 text-sm rounded-md border border-slate-200 outline-none focus:border-[#0052D9] leading-relaxed disabled:bg-slate-50"
            />
          </section>
        </div>
        <div className="px-5 py-3 border-t border-slate-100 flex items-center justify-end gap-2">
          <button
            onClick={onClose}
            className="h-8 px-3 text-sm rounded-md border border-slate-200 text-slate-600 hover:bg-slate-50"
          >
            关闭
          </button>
          <button
            disabled={!canEdit}
            onClick={() => onSave({ conclusion: conclusion.trim(), process })}
            className="h-8 px-3.5 text-sm rounded-md bg-[#0052D9] text-white hover:bg-[#003FA8] disabled:opacity-40 inline-flex items-center gap-1"
          >
            <CheckCircle2 size={13} /> 保存并回写
          </button>
          {saveError && <p role="alert" className="max-w-md text-xs text-red-600">{saveError}</p>}
        </div>
      </div>
    </div>
  );
}

// ---- 行动卡（R14 + R15）：进来就知道要做什么、做完看到结果 ----
function ActionCard({
  task,
  recoveryTools,
  caseItem,
  taskCount,
  canEdit,
  followed,
  onToggleFollow,
  onAdvance,
  onOpenCase,
}: {
  task: TaskNode;
  recoveryTools?: import("react").ReactNode;
  caseItem: any;
  taskCount: number;
  canEdit: boolean;
  followed: boolean;
  onToggleFollow: () => void;
  onAdvance: (patch: Partial<TaskNode>) => void;
  onOpenCase: () => void;
}) {
  const status = task.status;
  const isMine = task.owner === currentUser.name;
  // 分派人：任务自带 supervisor，否则按分派部门回退到该部门主管
  const dispatcher = task.supervisor?.trim() || departmentSupervisors[task.department] || "—";
  const dueColor =
    (task.dueIn ?? 99) <= 1
      ? "text-red-600"
      : (task.dueIn ?? 99) <= 3
      ? "text-amber-600"
      : "text-slate-500";

  const nextHint: Record<string, string> = {
    待接受: "下一步：接受任务后开始执行，或拒绝并说明理由",
    进行中: "下一步：在下方「分析过程与结论」填写结论并点击「完成」",
    已完成: "任务已完成，结论见下方",
    已中止: "任务已中止",
    已拒绝: "任务已拒绝",
  };

  return (
    <section aria-label="任务信息" className="bg-white border border-slate-200 rounded-xl p-5 shadow-[0_1px_2px_0_rgba(15,23,42,0.04)]">
      {/* 弱：Case 上下文行（方案 11 两级标题 · Case 弱） */}
      <div className="flex items-center gap-2 flex-wrap text-xs text-slate-500 pb-3 mb-3.5 border-b border-slate-100">
        <span className={`px-1.5 py-0.5 rounded text-[10px] font-medium border ${levelColors[caseItem.level]}`}>{caseItem.level}</span>
        <CaseProductPill caseItem={caseItem} compact />
        <span className="text-slate-500 truncate max-w-[420px]">{caseItem.name}</span>
        <span className="font-mono text-[11px] text-slate-400 tracking-wide">{caseItem.code}</span>
        <span className="text-slate-400">· 我有 {taskCount} 个任务</span>
        <div className="ml-auto flex items-center gap-2 shrink-0">
          {recoveryTools}
          <button
            type="button"
            onClick={onToggleFollow}
            title={followed ? "取消关注任务" : "关注后每天通过 HEMS 接收任务更新"}
            className={`h-7 px-2.5 rounded-md border text-[11px] font-medium inline-flex items-center gap-1.5 transition-colors ${followed ? "border-[#0052D9]/30 bg-[#0052D9]/[0.07] text-[#0052D9]" : "border-slate-200 bg-white text-slate-500 hover:border-[#0052D9]/30 hover:text-[#0052D9]"}`}
          >
            {followed ? <BellRing size={12} /> : <Bell size={12} />}
            {followed ? "已关注 · HEMS 每日通知" : "关注任务"}
          </button>
          <button onClick={onOpenCase} className="text-[#0052D9] hover:underline">
            查看 Case 全貌 →
          </button>
        </div>
      </div>

      {/* 方案14：状态行 —— 状态降为文字，仅保留紧急度单 chip，截止安静显示 */}
      <div className="flex items-center gap-2 flex-wrap text-sm">
        <span className="text-slate-500">{status}</span>
        <span className={`px-2 py-0.5 rounded text-[11px] ${urgencyColors[task.urgency]}`}>{task.urgency}</span>
        {isMine && <span className="text-xs text-slate-400">· 我的任务</span>}
        {task.dueDate && (
          <span className="ml-auto text-xs text-red-600">截止 {task.dueDate}{typeof task.dueIn === "number" ? ` · 剩 ${task.dueIn} 天` : ""}</span>
        )}
      </div>

      {/* 强：任务标题 */}
      <h2 className="mt-3 flex items-baseline gap-2 text-lg font-semibold leading-snug text-slate-900">
        <span>{task.title}</span>
        <RecoveryBadge record={task} />
        <span className="shrink-0 font-mono text-xs font-normal text-slate-400">{task.code ?? task.id}</span>
      </h2>

      {/* 方案14：预期 —— 引用样式（去盒子） */}
      {task.expectation && (
        <div className="mt-3 border-l-[3px] border-slate-200 pl-3 text-sm text-slate-600 leading-relaxed">
          <span className="text-[11px] text-slate-400 mr-1.5">预期</span>
          {task.expectation}
        </div>
      )}

      {/* 方案14：元信息 —— 2 列属性网格，分派人并入其中 */}
      <div className="mt-3.5 grid grid-cols-2 gap-x-6 gap-y-2 text-xs">
        <div className="flex gap-2">
          <span className="text-slate-400 w-14 shrink-0">分派人</span>
          <span className="text-slate-700 font-medium">{dispatcher} · {task.supervisor?.trim() ? "你的主管" : `${task.department} 主管`}</span>
        </div>
        <div className="flex gap-2">
          <span className="text-slate-400 w-14 shrink-0">分派部门</span>
          <span className="text-slate-700 font-medium">{task.department}</span>
        </div>
        <div className="flex gap-2">
          <span className="text-slate-400 w-14 shrink-0">执行人</span>
          <span className="text-slate-700 font-medium">{task.owner}</span>
        </div>
        {task.site && (
          <div className="flex gap-2">
            <span className="text-slate-400 w-14 shrink-0">站点</span>
            <span className="text-slate-700 font-medium">{task.site}</span>
          </div>
        )}
        <div className="flex gap-2">
          <span className="text-slate-400 w-14 shrink-0">EFA单号</span>
          <a
            href="https://qms.internal/efa/A1-26FA-005775"
            target="_blank"
            rel="noreferrer"
            onClick={(e) => e.stopPropagation()}
            className="font-mono font-medium text-[#0052D9] inline-flex items-center gap-1 hover:underline"
          >
            A1-26FA-005775 <ExternalLink size={11} />
          </a>
        </div>
        {task.type && (
          <div className="flex gap-2">
            <span className="text-slate-400 w-14 shrink-0">类型</span>
            <span className="text-slate-700 font-medium">{task.type}</span>
          </div>
        )}
      </div>

      {/* 任务输入材料紧随基本信息，不被结论或状态原因隔开。 */}
      <TaskAttachmentList key={task.id} attachments={task.attachments} />
      {task.voiceNote && <div className="mt-3"><VoicePlayer src={task.voiceNote} label="语音备注" /></div>}

      {task.assigneeType === "skill" && task.skillRun && (
        <div className="mt-4 rounded-lg border border-violet-200 bg-violet-50/70 p-3.5">
          <div className="flex items-center gap-2 text-xs font-semibold text-violet-700"><Sparkles size={14} />Skill 执行结果</div>
          <div className="mt-2 text-sm text-slate-700 leading-relaxed">{task.skillRun.result || "Skill 正在执行，请稍候查看结果。"}</div>
          <div className="mt-2 flex items-center justify-between text-[11px] text-slate-500">
            <span>状态：{task.skillRun.status}</span>
            {task.skillRun.completedAt && <span>完成于 {task.skillRun.completedAt}</span>}
          </div>
          {task.skillRun.status === "待确认" && (
            <button onClick={() => onAdvance({ status: "已完成", progress: 100, conclusion: task.skillRun?.result, skillRun: { ...task.skillRun!, status: "已采用" } })} className="mt-3 h-8 px-3 rounded-md bg-violet-600 text-white text-xs inline-flex items-center gap-1.5 hover:bg-violet-700"><CheckCircle2 size={13} />采用结果并完成任务</button>
          )}
          {task.skillRun.status === "已采用" && <div className="mt-2 text-xs text-emerald-700 inline-flex items-center gap-1"><CheckCircle2 size={13} />结果已由人工确认采用</div>}
        </div>
      )}

      {/* R15：已完成结果 / 中止·拒绝理由直显 */}
      {status === "已完成" && (task.conclusion || task.validity) && (
        <div className="mt-3 p-3 rounded-lg bg-emerald-50/60 border border-emerald-200">
          <div className="text-[11px] text-emerald-700 mb-1 flex items-center gap-2">
            任务结论
            {task.validity && (
              <span className={`px-1.5 py-0.5 rounded text-[10px] border ${validityColors[task.validity]}`}>结论{task.validity}</span>
            )}
          </div>
          <div className="text-sm text-slate-700 leading-relaxed">{task.conclusion || "—"}</div>
        </div>
      )}
      {status === "已中止" && task.terminateReason && (
        <div className="mt-3 p-3 rounded-lg bg-slate-50 border border-slate-200">
          <div className="text-[11px] text-slate-500 mb-1">中止理由</div>
          <div className="text-sm text-slate-600 leading-relaxed">{task.terminateReason}</div>
        </div>
      )}
      {status === "已拒绝" && task.rejectReason && (
        <div className="mt-3 p-3 rounded-lg bg-rose-50/60 border border-rose-200">
          <div className="text-[11px] text-rose-600 mb-1">拒绝理由</div>
          <div className="text-sm text-rose-700/90 leading-relaxed">{task.rejectReason}</div>
        </div>
      )}

      {/* 下一步主操作 */}
      <div className="mt-4 flex items-center gap-2">
        {canEdit && status === "待接受" && (
          <>
            <button onClick={() => onAdvance({ status: "进行中" })} className="h-9 px-4 rounded-md text-sm font-medium bg-[#0052D9] text-white hover:bg-[#003FA8]">接受并开始 →</button>
            <button onClick={() => onAdvance({ status: "已拒绝" })} className="h-9 px-3 rounded-md text-sm border border-slate-200 text-slate-600 hover:bg-slate-50">拒绝</button>
          </>
        )}
        <span className="text-xs text-slate-400">{nextHint[status]}</span>
      </div>
    </section>
  );
}
