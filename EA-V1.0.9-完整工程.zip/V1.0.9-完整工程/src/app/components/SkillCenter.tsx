import { useEffect, useMemo, useRef, useState } from "react";
import { ArrowLeft, ArrowRight, Blocks, Bot, MessageSquareText, Search, Send, Sparkles, Star, UserRound, Wand2 } from "lucide-react";
import { Skill, SKILL_CATEGORIES, useSkills } from "./skills";
import { DailyReportSkill } from "./DailyReportSkill";
import { AgentMark } from "./AgentMark";
import { agentDemoReply } from "./eaAgentModel";

type ChatMessage = { role: "skill" | "user"; text: string };

const SKILL_PROMPTS: Record<string, string[]> = {
  失效分析: ["帮我判断这组 bitmap 的失效模式", "给出下一步验证路径"],
  测试自动化: ["检查 timing set 的风险项", "生成一份修正建议"],
  报告生成: ["基于当前 Case 生成 8D 初稿", "整理结论与改善措施"],
  数据处理: ["分析最近一周良率波动", "找出异常站点和批次"],
  知识问答: ["查询相似历史 Case", "解释这条 SOP 的执行步骤"],
};

function responseFor(skill: Skill, question: string) {
  return agentDemoReply(question, skill);
}

function SkillWorkspace({ skill, onBack, embedded = false }: { skill: Skill; onBack: () => void; embedded?: boolean }) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: "skill", text: `你好，我是「${skill.name}」。${skill.description}\n\n直接描述你的问题或粘贴需要处理的内容即可。` },
  ]);
  const [draft, setDraft] = useState("");
  const messagesRef = useRef<HTMLDivElement>(null);
  const prompts = SKILL_PROMPTS[skill.category] ?? ["帮我处理当前问题", "给出下一步建议"];

  useEffect(() => {
    if (messagesRef.current) messagesRef.current.scrollTop = messagesRef.current.scrollHeight;
  }, [messages]);

  const send = (input = draft) => {
    const question = input.trim();
    if (!question) return;
    setMessages((current) => [...current, { role: "user", text: question }, { role: "skill", text: responseFor(skill, question) }]);
    setDraft("");
  };

  return (
      <div className={`mx-auto flex max-w-[1280px] flex-col overflow-hidden rounded-lg border border-slate-200 bg-white shadow-[0_4px_18px_-12px_rgba(15,23,42,0.25)] ${embedded ? "h-[min(620px,70vh)] min-h-[360px] w-full" : "h-[calc(100vh-158px)] min-h-[620px]"}`}>
        <div className="flex items-center gap-3 border-b border-slate-200 px-5 py-4">
          <button type="button" onClick={onBack} className="inline-flex h-8 shrink-0 items-center gap-1 rounded-md border border-slate-200 px-2.5 text-[11px] text-slate-600 hover:border-[#0052D9]/30 hover:text-[#0052D9]"><ArrowLeft size={13} />{embedded ? "返回 Skill 列表" : "返回技能市场"}</button>
          <span className="h-6 w-px bg-slate-200" />
          <span className="grid h-9 w-9 place-items-center rounded-lg bg-[#0052D9] text-white"><MessageSquareText size={17} /></span>
          <div className="min-w-0"><h2 className="truncate text-sm font-semibold text-slate-900">{skill.name}</h2><p className="mt-0.5 text-[10.5px] text-slate-400">{skill.category} · 由 {skill.author} 发布</p></div>
          <span className="ml-auto rounded-full border border-emerald-200 bg-emerald-50 px-2 py-1 text-[10px] font-medium text-emerald-700">已上线 · 直接使用</span>
        </div>

        <div ref={messagesRef} className="min-h-0 flex-1 space-y-4 overflow-y-auto bg-slate-50/50 p-5">
          {messages.map((message, index) => (
            <div key={index} className={`flex gap-3 ${message.role === "user" ? "flex-row-reverse" : ""}`}>
              <span className={`grid h-7 w-7 shrink-0 place-items-center rounded-md text-[10px] ${message.role === "skill" ? "bg-[#0052D9] text-white" : "bg-slate-200 text-slate-600"}`}>{message.role === "skill" ? "AI" : "我"}</span>
              <div className={`max-w-[75%] whitespace-pre-wrap rounded-lg px-3 py-2.5 text-[12px] leading-relaxed ${message.role === "skill" ? "border border-slate-200 bg-white text-slate-700" : "bg-[#0052D9] text-white"}`}>{message.text}</div>
            </div>
          ))}
        </div>

        {messages.length === 1 && <div className="flex flex-wrap gap-2 border-t border-slate-100 px-4 pt-3">{prompts.map((prompt) => <button key={prompt} type="button" onClick={() => send(prompt)} className="rounded-md border border-slate-200 bg-white px-2.5 py-1.5 text-[10.5px] text-slate-600 hover:border-[#0052D9]/30 hover:text-[#0052D9]">{prompt}</button>)}</div>}
        <div className="p-4 pt-3">
          <div className="flex items-center gap-2 rounded-md border border-slate-200 bg-white px-3 py-2 focus-within:border-[#0052D9]">
            <Wand2 size={14} className="shrink-0 text-slate-400" />
            <input value={draft} onChange={(event) => setDraft(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter" && !event.shiftKey) send(); }} placeholder={`输入内容，直接调用「${skill.name}」`} className="min-w-0 flex-1 bg-transparent text-sm text-slate-700 outline-none placeholder:text-slate-400" />
            <button type="button" onClick={() => send()} disabled={!draft.trim()} className="inline-flex h-8 items-center gap-1 rounded-md bg-[#0052D9] px-3 text-xs text-white hover:bg-[#003FA8] disabled:cursor-not-allowed disabled:opacity-40"><Send size={12} />发送</button>
          </div>
        </div>
      </div>
  );
}

export function SkillCenter({ embedded = false, onSelectSkill, onBackToAgent }: { embedded?: boolean; onSelectSkill?: (skill: Skill) => void; onBackToAgent?: () => void }) {
  const { skills } = useSkills();
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("全部");
  const [activeSkill, setActiveSkill] = useState<Skill | null>(null);
  const managementTitle = useRef<HTMLHeadingElement>(null);
  const managementPage = Boolean(onBackToAgent);
  useEffect(() => { if (managementPage) managementTitle.current?.focus({ preventScroll: true }); }, [managementPage, activeSkill?.id]);

  const publishedSkills = useMemo(() => skills.filter((skill) => skill.status === "已发布"), [skills]);
  const visibleSkills = useMemo(() => {
    const keyword = query.trim().toLowerCase();
    return publishedSkills
      .filter((skill) => category === "全部" || skill.category === category)
      .filter((skill) => !keyword || [skill.name, skill.category, skill.description, skill.author, ...skill.tags].join(" ").toLowerCase().includes(keyword))
      .sort((left, right) => right.installs - left.installs || right.rating - left.rating);
  }, [category, publishedSkills, query]);

  const managementHeader = onBackToAgent && <header className="mx-auto mb-5 flex max-w-[1280px] items-center gap-4">
    <button type="button" onClick={onBackToAgent} className="inline-flex h-8 items-center gap-1.5 rounded-lg px-2 text-xs text-slate-500 hover:bg-slate-100 hover:text-[#0052D9] focus-visible:outline-2 focus-visible:outline-[#0052D9]/40"><ArrowLeft size={15} />返回 EA Agent</button>
    <h1 tabIndex={-1} ref={managementTitle} className="text-xl font-semibold text-slate-900 outline-none">管理 Skill</h1>
  </header>;

  if (activeSkill) {
    return (
      <div className={embedded ? "flex h-full min-h-0 flex-col p-5" : "min-h-full bg-[#F6F8FB] px-7 py-6"}>
        {managementHeader}
        {activeSkill.id === "sk-003"
          ? <DailyReportSkill key={activeSkill.id} skill={activeSkill} embedded={embedded} onBack={() => setActiveSkill(null)} />
          : <SkillWorkspace key={activeSkill.id} skill={activeSkill} embedded={embedded} onBack={() => setActiveSkill(null)} />}
      </div>
    );
  }

  return (
    <div className={embedded ? "p-5" : "min-h-full bg-[#F6F8FB] px-7 py-6"}>
      {managementHeader}
      <div className="mx-auto max-w-[1280px]">
        {!embedded && !onBackToAgent && <div className="flex items-center gap-4 border-b border-slate-200 pb-5">
          <AgentMark className="ea-agent-header-logo" />
          <div><h1 className="text-xl font-semibold text-slate-900">EA Agent</h1></div>
          <div className="ml-auto text-right"><div className="text-lg font-semibold tabular-nums text-[#0052D9]">{publishedSkills.length}</div><div className="text-[10px] text-slate-400">已上线技能</div></div>
        </div>}

        <div className={`flex items-center gap-3 ${embedded || onBackToAgent ? "" : "mt-5"}`}>
          <div className="relative w-[320px]"><Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" /><input aria-label="搜索 Skill" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="搜索技能名称、作者或标签" className="h-9 w-full rounded-md border border-slate-200 bg-white pl-9 pr-3 text-xs text-slate-700 outline-none placeholder:text-slate-400 focus:border-[#0052D9]" /></div>
          {(embedded || onBackToAgent) && <span className="shrink-0 rounded-full bg-slate-100 px-2 py-1 text-[10px] tabular-nums text-slate-500">已上线技能 {publishedSkills.length}</span>}
          <div role="group" aria-label="技能分类" className="flex min-w-0 items-center gap-1 overflow-x-auto">{["全部", ...SKILL_CATEGORIES].map((item) => <button key={item} type="button" aria-pressed={category === item} onClick={() => setCategory(item)} className={`h-8 shrink-0 rounded-md px-3 text-[11px] transition-colors ${category === item ? "bg-[#0052D9] text-white" : "border border-slate-200 bg-white text-slate-500 hover:border-[#0052D9]/30 hover:text-[#0052D9]"}`}>{item}</button>)}</div>
        </div>

        <div className="mt-5 grid grid-cols-1 items-start gap-4">
          <div className="grid min-w-0 grid-cols-1 gap-4 lg:grid-cols-2 xl:grid-cols-3">
            {visibleSkills.map((skill, index) => (
            <article
              key={skill.id}
              role="button"
              tabIndex={0}
              onClick={() => onSelectSkill ? onSelectSkill(skill) : setActiveSkill(skill)}
              onKeyDown={(event) => { if (event.target !== event.currentTarget) return; if (event.key === "Enter" || event.key === " ") { event.preventDefault(); if (onSelectSkill) onSelectSkill(skill); else setActiveSkill(skill); } }}
              className="flex min-h-[220px] cursor-pointer flex-col rounded-lg border border-slate-200 bg-white p-4 shadow-[0_1px_2px_rgba(15,23,42,0.04)] outline-none transition-all hover:border-[#0052D9]/25 hover:shadow-[0_8px_24px_-14px_rgba(15,23,42,0.3)] focus:border-[#0052D9]"
            >
              <div className="flex items-start gap-3"><span className={`grid h-10 w-10 shrink-0 place-items-center rounded-lg ${index % 3 === 0 ? "bg-blue-50 text-blue-600" : index % 3 === 1 ? "bg-emerald-50 text-emerald-600" : "bg-amber-50 text-amber-600"}`}>{skill.category === "知识问答" ? <Bot size={18} /> : skill.category === "报告生成" ? <Sparkles size={18} /> : <Blocks size={18} />}</span><div className="min-w-0 flex-1"><h2 className="truncate text-sm font-semibold text-slate-800">{skill.name}</h2><div className="mt-1 flex items-center gap-2 text-[10px] text-slate-400"><span>{skill.category}</span><span>·</span><span className="inline-flex items-center gap-1"><UserRound size={10} />{skill.author}</span></div></div></div>
              <p className="mt-4 line-clamp-3 text-[11.5px] leading-relaxed text-slate-600">{skill.description}</p>
              <div className="mt-3 flex flex-wrap gap-1.5">{skill.tags.map((tag) => <span key={tag} className="rounded border border-slate-200 bg-slate-50 px-1.5 py-0.5 text-[9.5px] text-slate-500">{tag}</span>)}</div>
              <div className="mt-auto flex items-center gap-2 border-t border-slate-100 pt-3">
                <span className="inline-flex items-center gap-1 text-[10px] text-slate-400"><MessageSquareText size={11} />{skill.installs} 次使用</span>
                <span className="inline-flex items-center gap-1 text-[10px] text-slate-400"><Star size={11} className="fill-amber-400 text-amber-400" />{skill.rating}.0</span>
                <button type="button" onClick={(event) => { event.stopPropagation(); setActiveSkill(skill); }} className={`ml-auto inline-flex h-8 items-center gap-1.5 rounded-md px-3 text-[11px] font-medium ${onSelectSkill ? "border border-slate-200 text-slate-600 hover:text-[#0052D9]" : "bg-[#0052D9] text-white hover:bg-[#003FA8]"}`}>{onSelectSkill ? "打开工作区" : "打开使用"}{!onSelectSkill && <ArrowRight size={12} />}</button>
                {onSelectSkill && <button type="button" onClick={(event) => { event.stopPropagation(); onSelectSkill(skill); }} className="inline-flex h-8 items-center gap-1.5 rounded-md bg-[#0052D9] px-3 text-[11px] font-medium text-white hover:bg-[#003FA8]">调用<ArrowRight size={12} /></button>}
              </div>
            </article>
            ))}
            {!visibleSkills.length && <div className="grid min-h-[260px] place-items-center rounded-lg border border-dashed border-slate-200 bg-white text-sm text-slate-400">没有匹配的已上线技能</div>}
          </div>
        </div>
      </div>
    </div>
  );
}