import { useId, useMemo, useRef, useState } from "react";
import { Check, ChevronDown, Plus, X } from "lucide-react";
import type { CustomFieldDefinition, CustomFieldEntity } from "./caseCustomFilterFields";
import {
  customRuleError,
  customSelectionRules,
  customValueLabel,
  type CustomFilterRule,
} from "./caseCustomFilters";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "./ui/command";

export interface CaseCustomFilterEditorProps {
  fields: readonly CustomFieldDefinition[];
  rules: CustomFilterRule[];
  optionsFor: (field: CustomFieldDefinition) => string[];
  onChange: (rules: CustomFilterRule[]) => void;
}

const focusClass = "focus-visible:outline-2 focus-visible:outline-[#0052D9]/40";
const itemClass = "min-w-0 text-xs data-[selected=true]:bg-blue-50 data-[selected=true]:text-[#0052D9]";
const popupClass = "z-50 flex w-[400px] max-w-[calc(100vw-32px)] max-h-[var(--radix-popover-content-available-height)] flex-col overflow-hidden rounded-lg border-slate-200 bg-white p-0";
const entityLabel = (entity: CustomFieldEntity) => entity === "task" ? "任务" : "Case";
const fieldTitle = (field: CustomFieldDefinition) => `${entityLabel(field.entity)} · ${field.label} · ${field.group} · ${field.path.join(".")}`;
const searchTerms = (query: string) => query.trim().toLocaleLowerCase().split(/\s+/).filter(Boolean);
const matchesTerms = (text: string, terms: string[]) => terms.every(term => text.toLocaleLowerCase().includes(term));

let fallbackIdCounter = 0;
function newRuleId(rules: CustomFilterRule[]): string {
  const existing = new Set(rules.map(rule => rule.id));
  try {
    const id = globalThis.crypto?.randomUUID?.();
    if (id && !existing.has(id)) return id;
  } catch {
    // file://、受限环境或重复 UUID 均使用带单调计数的后备 ID。
  }
  let id: string;
  do { id = `custom-filter-${Date.now()}-${++fallbackIdCounter}`; } while (existing.has(id));
  return id;
}

type ValuePickerProps = Pick<CaseCustomFilterEditorProps, "optionsFor"> & {
  field: CustomFieldDefinition;
  values: string[];
  onChange: (values: string[]) => void;
};

// 只在子浮层打开时挂载，关闭即丢弃候选缓存；绝不预读整个字段目录的值。
function OpenValueChoices({ field, values, optionsFor, onChange, onDone }: ValuePickerProps & { onDone: () => void }) {
  const [query, setQuery] = useState("");
  const catalog = useMemo(() => {
    const actual = optionsFor(field);
    return [...new Set(field.type === "boolean" ? [...actual, "true", "false"] : actual)];
  }, [field, optionsFor]);
  const selected = new Set(values);
  const available = new Set(catalog);
  const terms = searchTerms(query);
  // 原始值用于精确比较，标签只用于呈现；保留已离开候选目录的选中值。
  // 目录项不因勾选而重排或换组，确保 cmdk 的键盘高亮仍指向同一个值。
  const choices = [...new Set([...catalog, ...values])].map((value, index) => ({
    value, index, label: customValueLabel(value, field), checked: selected.has(value), available: available.has(value),
  })).filter(choice => matchesTerms(`${choice.label} ${choice.value}`, terms));
  const context = `${entityLabel(field.entity)}·${field.label}`;
  const toggle = (value: string) => onChange(selected.has(value)
    ? values.filter(item => item !== value)
    : [...values, value]);
  const renderChoices = (inCatalog: boolean) => choices.filter(choice => choice.available === inCatalog).map(choice => (
    <CommandItem
      key={choice.value}
      // cmdk 会 trim value；使用内部标识，避免改变有首尾空格的原始候选值。
      value={`custom-value-${choice.index}`}
      title={choice.label}
      aria-label={`${choice.label}${choice.checked ? "（已选）" : ""}`}
      onSelect={() => toggle(choice.value)}
      className={itemClass}
    >
      <span aria-hidden="true" className={`inline-flex size-3.5 shrink-0 items-center justify-center rounded-sm border ${choice.checked ? "border-[#0052D9] bg-[#0052D9]" : "border-slate-300 bg-white"}`}>
        <Check className={`size-3 text-white ${choice.checked ? "opacity-100" : "opacity-0"}`} />
      </span>
      <span className="min-w-0 flex-1 truncate whitespace-pre">{choice.label}</span>
    </CommandItem>
  ));

  return <>
    <Command label={`${context}搜索筛选值`} shouldFilter={false} className="h-auto min-h-0 flex-1">
      <CommandInput autoFocus placeholder="搜索筛选值" value={query} onValueChange={setQuery} className="text-xs" />
      <CommandList label={`${context}候选值`} className="max-h-[240px] min-h-0 overscroll-contain">
        <CommandEmpty>{catalog.length || values.length ? "无匹配值" : "暂无候选"}</CommandEmpty>
        {choices.some(choice => !choice.available) && <CommandGroup heading="已选值">{renderChoices(false)}</CommandGroup>}
        {choices.some(choice => choice.available) && <CommandGroup heading="可选值">{renderChoices(true)}</CommandGroup>}
      </CommandList>
    </Command>
    <div className="flex shrink-0 items-center justify-between gap-2 border-t border-slate-100 px-3 py-2">
      <button type="button" onClick={() => onChange([])} disabled={!values.length} className={`h-7 rounded-md px-2 text-xs text-[#0052D9] hover:bg-blue-50 disabled:opacity-40 ${focusClass}`}>全部清空</button>
      <span className="text-[11px] text-slate-400" aria-live="polite">已选 {selected.size} 项</span>
      <button type="button" onClick={onDone} className={`h-7 rounded-md bg-[#0052D9] px-3 text-xs text-white hover:bg-[#003FA8] ${focusClass}`}>完成</button>
    </div>
  </>;
}

function RuleValuePicker({ field, values, optionsFor, onChange, errorId, invalid }: ValuePickerProps & { errorId: string; invalid: boolean }) {
  const [open, setOpen] = useState(false);
  const labels = [...new Set(values)].map(value => customValueLabel(value, field));
  const summary = labels.length > 1 ? `已选 ${labels.length} 项 · ${labels[0]}` : labels[0] || "请选择筛选值";
  const context = `${entityLabel(field.entity)}·${field.label}`;
  return <Popover open={open} onOpenChange={setOpen}>
    <PopoverTrigger asChild>
      <button type="button" aria-label={`${context}筛选值`} aria-invalid={invalid || undefined} aria-describedby={invalid ? errorId : undefined} title={labels.length ? labels.join("、") : "请选择筛选值"} className={`inline-flex h-8 w-full min-w-0 items-center gap-2 rounded-lg border border-slate-200 bg-white px-2 text-xs ${focusClass}`}>
        <span className={`min-w-0 flex-1 truncate whitespace-pre text-left ${values.length ? "text-slate-700" : "text-slate-400"}`}>{summary}</span>
        <ChevronDown size={12} aria-hidden="true" className="shrink-0 text-slate-400" />
      </button>
    </PopoverTrigger>
    <PopoverContent align="start" aria-label={`${context}选择筛选值`} className={popupClass} onEscapeKeyDown={event => event.stopPropagation()}>
      {open && <OpenValueChoices field={field} values={values} optionsFor={optionsFor} onChange={onChange} onDone={() => setOpen(false)} />}
    </PopoverContent>
  </Popover>;
}

function CustomRuleRow({ field, rule, optionsFor, onChange, onRemove }: Pick<CaseCustomFilterEditorProps, "optionsFor"> & {
  field?: CustomFieldDefinition;
  rule: CustomFilterRule;
  onChange: (patch: Pick<CustomFilterRule, "values">) => void;
  onRemove: () => void;
}) {
  const errorId = useId();
  const error = customRuleError(rule, field);
  const entity = field?.entity ?? (rule.fieldId.startsWith("task:") ? "task" : "case");
  const label = field?.label ?? rule.fieldId;
  const context = `${entityLabel(entity)}·${label}`;

  return <div role="group" aria-label={context} className={`min-w-0 space-y-2 rounded-lg border border-slate-100 bg-slate-50/70 p-2 ${error ? "opacity-70" : ""}`}>
    <div className="flex min-w-0 items-center gap-1.5">
      <span className="shrink-0 rounded bg-slate-200/70 px-1 py-0.5 text-[10px] leading-3 text-slate-500">{entityLabel(entity)}</span>
      <span title={field ? fieldTitle(field) : rule.fieldId} className="min-w-0 flex-1 truncate text-xs font-medium text-slate-700">{label}</span>
      {error && <span className="shrink-0 text-[10px] text-slate-500">未生效</span>}
      <button type="button" aria-label={`删除${context}条件`} title={`删除${context}条件`} onClick={onRemove} className={`inline-flex size-7 shrink-0 items-center justify-center rounded-md text-slate-400 hover:bg-white hover:text-[#0052D9] ${focusClass}`}><X size={13} aria-hidden="true" /></button>
    </div>
    {field && <div className="w-full min-w-0">
      <RuleValuePicker field={field} values={rule.values} optionsFor={optionsFor} onChange={values => onChange({ values })} errorId={errorId} invalid={!!error} />
    </div>}
    <p id={errorId} aria-live="polite" className="sr-only">{error}</p>
  </div>;
}

export function CaseCustomFilterEditor({ fields, rules: ruleDrafts, optionsFor, onChange }: CaseCustomFilterEditorProps) {
  const rules = customSelectionRules(ruleDrafts);
  const [addOpen, setAddOpen] = useState(false);
  const [entity, setEntity] = useState<CustomFieldEntity>("case");
  const [query, setQuery] = useState("");
  const addButtonRef = useRef<HTMLButtonElement>(null);
  const rulesRef = useRef(rules);
  rulesRef.current = rules;
  const fieldsById = useMemo(() => new Map(fields.map(field => [field.id, field])), [fields]);
  const chosenIds = new Set(rules.map(rule => rule.fieldId));
  const available = fields.filter(field => field.entity === entity && !chosenIds.has(field.id));
  const terms = searchTerms(query);
  const grouped = new Map<string, CustomFieldDefinition[]>();
  for (const field of available) {
    if (!matchesTerms(`${field.label} ${field.group} ${field.path.join(".")} ${field.id} ${entityLabel(field.entity)}`, terms)) continue;
    const group = grouped.get(field.group) ?? [];
    group.push(field);
    grouped.set(field.group, group);
  }
  const changeAddOpen = (open: boolean) => { setAddOpen(open); setQuery(""); };
  const commit = (next: CustomFilterRule[]) => {
    // 草稿原样回传；是否生效及计数由引擎决定，不丢弃或自动修正无效条件。
    rulesRef.current = next;
    onChange(next);
  };
  const addField = (field: CustomFieldDefinition) => {
    const current = rulesRef.current;
    if (current.some(rule => rule.fieldId === field.id)) return;
    commit([...current, { id: newRuleId(current), fieldId: field.id, operator: "in", values: [] }]);
    changeAddOpen(false);
  };
  const removeRule = (id: string) => {
    commit(rulesRef.current.filter(rule => rule.id !== id));
    // 添加按钮始终存在，避免删除最后一行后焦点落到 body 或父浮层之外。
    addButtonRef.current?.focus({ preventScroll: true });
  };

  return <section role="group" aria-label="自定义筛选条件" className="mt-3 min-w-0 space-y-2 border-t border-slate-100 pt-3">
    <div className="flex items-center justify-between gap-2">
      <h3 className="text-xs font-medium text-slate-600">自定义维度</h3>
      <Popover open={addOpen} onOpenChange={changeAddOpen}>
        <PopoverTrigger asChild>
          <button ref={addButtonRef} type="button" className={`inline-flex h-7 items-center gap-1 rounded-md border border-dashed border-[#0052D9]/40 px-2 text-xs text-[#0052D9] hover:bg-blue-50 ${focusClass}`}><Plus size={12} aria-hidden="true" />添加维度</button>
        </PopoverTrigger>
        <PopoverContent
          align="end"
          aria-label="添加自定义维度"
          className={popupClass}
          onEscapeKeyDown={event => event.stopPropagation()}
        >
          <div role="group" aria-label="维度分类" className="flex shrink-0 gap-1 border-b border-slate-100 p-2">
            {(["case", "task"] as const).map(category => <button key={category} type="button" aria-pressed={entity === category} onClick={() => setEntity(category)} className={`h-7 rounded-md px-4 text-xs ${focusClass} ${entity === category ? "bg-blue-50 font-medium text-[#0052D9]" : "text-slate-500 hover:bg-slate-50"}`}>{entityLabel(category)}</button>)}
          </div>
          <Command label="搜索自定义维度" shouldFilter={false} className="h-auto min-h-0 flex-1">
            <CommandInput autoFocus placeholder="搜索名称、分组或字段路径" value={query} onValueChange={setQuery} className="text-xs" />
            <CommandList label={`${entityLabel(entity)}自定义维度候选`} className="max-h-[240px] min-h-0 overscroll-contain">
              <CommandEmpty>{available.length ? "无匹配维度" : `暂无可添加的${entityLabel(entity)}维度（已有条件不会重复添加）`}</CommandEmpty>
              {[...grouped].map(([group, definitions]) => <CommandGroup key={group} heading={group}>
                {definitions.map(field => <CommandItem key={field.id} value={field.id} title={fieldTitle(field)} onSelect={() => addField(field)} className={itemClass}>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate">{field.label}</span>
                  </span>
                </CommandItem>)}
              </CommandGroup>)}
            </CommandList>
          </Command>
        </PopoverContent>
      </Popover>
    </div>
    {rules.length > 0 && <div className="max-h-[240px] space-y-2 overflow-y-auto overscroll-contain pr-1">
      {rules.map(rule => <CustomRuleRow
        key={rule.id}
        field={fieldsById.get(rule.fieldId)}
        rule={rule}
        optionsFor={optionsFor}
        onChange={patch => commit(rulesRef.current.map(current => current.id === rule.id ? { ...current, ...patch } : current))}
        onRemove={() => removeRule(rule.id)}
      />)}
    </div>}
  </section>;
}