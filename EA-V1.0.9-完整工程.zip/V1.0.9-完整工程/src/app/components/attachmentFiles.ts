import type { Att } from "./AttachmentInput";

export function attachmentKind(file: Pick<File, "type" | "name">): Att["kind"] {
  const type = file.type;
  const name = file.name.toLowerCase();
  if (type.startsWith("image/") || /\.(png|jpe?g|gif|webp|bmp|svg)$/.test(name)) return "image";
  if (type === "application/pdf" || name.endsWith(".pdf")) return "pdf";
  if (/\.(csv|xlsx?|numbers)$/.test(name) || type.includes("sheet") || type.includes("excel")) return "sheet";
  return "file";
}

// 点击选择与拖放共用同一读取路径，一批全部读取成功后才提交。
export async function readAttachmentFiles(files: File[]): Promise<Att[]> {
  return Promise.all(files.map((file) => new Promise<Att>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result !== "string") { reject(new Error(`无法读取附件「${file.name}」，请重新上传。`)); return; }
      resolve({ name: file.name, kind: attachmentKind(file), url: reader.result });
    };
    reader.onerror = reader.onabort = () => reject(new Error(`无法读取附件「${file.name}」，请重新上传。`));
    reader.readAsDataURL(file);
  })));
}