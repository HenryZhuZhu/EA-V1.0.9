import { useState } from "react";
import { CreateStandaloneTask } from "./CreateStandaloneTask";
import { standaloneTaskById, standaloneTaskEditDisabledReason, useStandaloneTasks, type StandaloneTask } from "./standaloneTasks";

export function EditStandaloneTask({ taskId, onCancel, onSaved }: {
  taskId: string; onCancel: () => void; onSaved: (task: StandaloneTask) => void;
}) {
  useStandaloneTasks();
  const [snapshot] = useState(() => {
    const task = standaloneTaskById(taskId);
    return task ? JSON.parse(JSON.stringify(task)) as StandaloneTask : undefined;
  });
  const blocked = standaloneTaskEditDisabledReason(standaloneTaskById(taskId));
  if (blocked || !snapshot) return <div className="space-y-3 p-8"><p role="alert" className="text-sm text-slate-500">{blocked || "任务不存在。"}</p><button type="button" onClick={onCancel} className="text-sm text-[#0052D9]">返回任务详情</button></div>;
  return <CreateStandaloneTask initialTask={snapshot} onCancel={onCancel} onCreated={onSaved} />;
}