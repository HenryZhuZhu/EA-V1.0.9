import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowDown,
  ArrowDownUp,
  ArrowUp,
  Calendar,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  Edit2,
  FlaskConical,
  Lightbulb,
  ListChecks,
  Paperclip,
  Plus,
  Radar,
  TableProperties,
  Trash2,
  Upload,
  X,
} from "lucide-react";
import {
  CaseItem,
  EfaAnalysisCard,
  PROBLEM_DOMAINS,
  TASK_TYPES,
  TaskType,
  BALL_TYPES,
  Urgency,
  ownerToDepartment,
} from "./data";
import { AttachmentInput, Att } from "./AttachmentInput";
import { VoiceRecorder } from "./VoiceNote";
import type { ActionCard, ThoughtGroup } from "./CreateCase";
import { TaskAssigneeField } from "./TaskAssigneeField";
import { CoverageOwnerFields, CoveragePatternFields } from "./CoveragePatternFields";
import { StatusBadge } from "./StatusBadge";
import { formatCaseTime } from "./caseTiming";

interface Props {
  caseData: CaseItem;
  thoughtGroups: ThoughtGroup[];
  onGroupsChange: (groups: ThoughtGroup[]) => void;
  readOnly?: boolean;
  onTaskOpen?: (taskId: string) => void;
  showExecutionMetrics?: boolean;
  compact?: boolean;
  taskCreatedTimes?: Record<string, string | undefined>;
}

type GroupRow = { group: ThoughtGroup; depth: number; wbs: string };
type TaskRow = { action: ActionCard; group: ThoughtGroup; depth: number; wbs: string };

const DEPARTMENTS = ["PTE", "CP", "FT", "DA", "PE", "QA", "EFA", "RD", "PM"];
const URGENCIES: Urgency[] = ["非常紧急", "紧急", "一般", "不紧急"];
const urgencyStyle: Record<Urgency, string> = {
  非常紧急: "bg-red-50 text-red-600 border-red-200",
  紧急: "bg-orange-50 text-orange-600 border-orange-200",
  一般: "bg-sky-50 text-sky-600 border-sky-200",
  不紧急: "bg-slate-50 text-slate-500 border-slate-200",
};

const uid = (prefix: string) => `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;

// 与思维导图一致：思路标签 + 因为__原理说明__所以__ 结构，“Other” 为自由工作思路
const THOUGHT_CATEGORIES = [...PROBLEM_DOMAINS, "Other"];
function composeThought(parts: [string, string, string]): string {
  const [a, b, c] = parts.map((s) => (s || "").trim());
  if (!a && !b && !c) return "";
  return `因为${a}，原理说明${b}，所以${c}。`;
}
function parseThought(title: string): [string, string, string] {
  if (!title) return ["", "", ""];
  const normalized = title.endsWith("。") ? title.slice(0, -1) : title;
  const m = normalized.match(/^因为([\s\S]*)，原理说明([\s\S]*)，所以([\s\S]*)$/);
  if (m) return [m[1], m[2], m[3]];
  return [title, "", ""];
}

function defaultEfa(caseData: CaseItem): EfaAnalysisCard {
  return {
    stage: caseData.failStage && caseData.failStage !== "—" ? caseData.failStage : "",
    package: caseData.failPackage && caseData.failPackage !== "—" ? caseData.failPackage : "",
    quality: caseData.ppm && caseData.ppm !== "—" ? `${caseData.ppm}${/ppm/i.test(caseData.ppm) ? "" : " PPM"}` : "",
    failRate: caseData.failRatio && caseData.failRatio !== "—" ? caseData.failRatio : "",
    chipList: [{ fsa: "", map: "", failMode: caseData.failMode === "—" ? "" : caseData.failMode, waferNo: "", chipNo: "", markCode: "" }],
  };
}

function updateGroups(
  groups: ThoughtGroup[],
  groupId: string,
  updater: (group: ThoughtGroup) => ThoughtGroup,
): ThoughtGroup[] {
  return groups.map((group) => {
    if (group.id === groupId) return updater(group);
    return {
      ...group,
      actions: group.actions.map((action) => ({
        ...action,
        childGroups: action.childGroups ? updateGroups(action.childGroups, groupId, updater) : action.childGroups,
      })),
    };
  });
}

function removeGroup(groups: ThoughtGroup[], groupId: string): ThoughtGroup[] {
  return groups
    .filter((group) => group.id !== groupId)
    .map((group) => ({
      ...group,
      actions: group.actions.map((action) => ({
        ...action,
        childGroups: action.childGroups ? removeGroup(action.childGroups, groupId) : action.childGroups,
      })),
    }));
}

function updateAction(
  groups: ThoughtGroup[],
  actionId: string,
  updater: (action: ActionCard) => ActionCard,
): ThoughtGroup[] {
  return groups.map((group) => ({
    ...group,
    actions: group.actions.map((action) => {
      if (action.id === actionId) return updater(action);
      return { ...action, childGroups: action.childGroups ? updateAction(action.childGroups, actionId, updater) : action.childGroups };
    }),
  }));
}

function flattenRows(groups: ThoughtGroup[], collapsed: Set<string>, depth = 0, prefix = ""): Array<GroupRow | TaskRow> {
  const rows: Array<GroupRow | TaskRow> = [];
  groups.forEach((group, groupIndex) => {
    const groupWbs = prefix ? `${prefix}.${groupIndex + 1}` : `${groupIndex + 1}`;
    rows.push({ group, depth, wbs: groupWbs });
    if (collapsed.has(group.id)) return;
    group.actions.forEach((action, taskIndex) => {
      const taskWbs = `${groupWbs}.${taskIndex + 1}`;
      rows.push({ action, group, depth: depth + 1, wbs: taskWbs });
      if (action.childGroups?.length) rows.push(...flattenRows(action.childGroups, collapsed, depth + 2, taskWbs));
    });
  });
  return rows;
}

export function CreateCaseWbsTable({ caseData, thoughtGroups, onGroupsChange, readOnly = false, onTaskOpen, showExecutionMetrics = false, compact = false, taskCreatedTimes = {} }: Props) {
  const [collapsed, setCollapsed] = useState<Set<string>>(new Set());
  const [durationSort, setDurationSort] = useState<"none" | "desc" | "asc">("none");
  const [editingGroup, setEditingGroup] = useState<ThoughtGroup | null>(null);
  const [editingTask, setEditingTask] = useState<{ groupId: string; draft: ActionCard } | null>(null);
  const [efaTaskId, setEfaTaskId] = useState<string | null>(null);
  const [batchOpen, setBatchOpen] = useState(false);
  const tableScrollerRef = useRef<HTMLDivElement>(null);
  const stickyScrollerRef = useRef<HTMLDivElement>(null);
  const [showScrollHint, setShowScrollHint] = useState(true);
  const [scrollUi, setScrollUi] = useState({
    overflowing: false,
    atStart: true,
    atEnd: true,
    hiddenColumns: 0,
    contentWidth: 0,
    barMode: "hidden" as "hidden" | "fixed" | "absolute",
    barLeft: 0,
    barWidth: 0,
  });
  const rows = useMemo(() => {
    if (durationSort === "none") return flattenRows(thoughtGroups, collapsed);
    return flattenRows(thoughtGroups, new Set())
      .filter((row): row is TaskRow => "action" in row)
      .sort((left, right) => {
        const leftHours = left.action.actualDurationHours;
        const rightHours = right.action.actualDurationHours;
        if (typeof leftHours !== "number") return typeof rightHours === "number" ? 1 : left.wbs.localeCompare(right.wbs, undefined, { numeric: true });
        if (typeof rightHours !== "number") return -1;
        const difference = durationSort === "desc" ? rightHours - leftHours : leftHours - rightHours;
        return difference || left.wbs.localeCompare(right.wbs, undefined, { numeric: true });
      });
  }, [thoughtGroups, collapsed, durationSort]);
  const allRows = useMemo(() => flattenRows(thoughtGroups, new Set()), [thoughtGroups]);
  const taskCount = allRows.filter((row): row is TaskRow => "action" in row).length;
  const thoughtCount = allRows.length - taskCount;
  const durationRanks = useMemo(() => {
    const ranked = flattenRows(thoughtGroups, new Set())
      .filter((row): row is TaskRow => "action" in row && typeof row.action.actualDurationHours === "number")
      .sort((left, right) => (right.action.actualDurationHours ?? 0) - (left.action.actualDurationHours ?? 0));
    return new Map(ranked.map((row, index) => [row.action.id, index + 1]));
  }, [thoughtGroups]);
  const scrollHintVisible = scrollUi.overflowing && showScrollHint && scrollUi.atStart;

  const updateScrollUi = useCallback(() => {
    const scroller = tableScrollerRef.current;
    if (!scroller) return;
    const maxScroll = Math.max(0, scroller.scrollWidth - scroller.clientWidth);
    const overflowing = maxScroll > 2;
    const atStart = scroller.scrollLeft <= 2;
    const atEnd = scroller.scrollLeft >= maxScroll - 2;
    const rect = scroller.getBoundingClientRect();
    const visible = rect.bottom > 0 && rect.top < window.innerHeight;
    const barMode = !overflowing || !visible
      ? "hidden"
      : rect.bottom > window.innerHeight - 8
        ? "fixed"
        : "absolute";
    const hiddenColumns = overflowing
      ? Array.from(scroller.querySelectorAll("thead th")).filter((cell) => cell.getBoundingClientRect().right > rect.right + 2).length
      : 0;

    setScrollUi((previous) => {
      const next = {
        overflowing,
        atStart,
        atEnd,
        hiddenColumns,
        contentWidth: scroller.scrollWidth,
        barMode,
        barLeft: rect.left,
        barWidth: rect.width,
      };
      return previous.overflowing === next.overflowing
        && previous.atStart === next.atStart
        && previous.atEnd === next.atEnd
        && previous.hiddenColumns === next.hiddenColumns
        && previous.contentWidth === next.contentWidth
        && previous.barMode === next.barMode
        && Math.abs(previous.barLeft - next.barLeft) < 0.5
        && Math.abs(previous.barWidth - next.barWidth) < 0.5
        ? previous
        : next;
    });
  }, []);

  useEffect(() => {
    const scroller = tableScrollerRef.current;
    if (!scroller) return;
    updateScrollUi();
    const resizeObserver = new ResizeObserver(updateScrollUi);
    resizeObserver.observe(scroller);
    const table = scroller.querySelector("table");
    if (table) resizeObserver.observe(table);
    window.addEventListener("resize", updateScrollUi);
    window.addEventListener("scroll", updateScrollUi, { capture: true, passive: true });
    return () => {
      resizeObserver.disconnect();
      window.removeEventListener("resize", updateScrollUi);
      window.removeEventListener("scroll", updateScrollUi, true);
    };
  }, [rows.length, updateScrollUi]);

  useEffect(() => {
    if (stickyScrollerRef.current && tableScrollerRef.current) {
      stickyScrollerRef.current.scrollLeft = tableScrollerRef.current.scrollLeft;
    }
  }, [scrollUi.barMode, scrollUi.contentWidth]);

  const handleTableScroll = () => {
    const scroller = tableScrollerRef.current;
    if (!scroller) return;
    if (stickyScrollerRef.current) stickyScrollerRef.current.scrollLeft = scroller.scrollLeft;
    if (scroller.scrollLeft > 6) setShowScrollHint(false);
    updateScrollUi();
  };

  const handleStickyScroll = () => {
    const stickyScroller = stickyScrollerRef.current;
    const tableScroller = tableScrollerRef.current;
    if (!stickyScroller || !tableScroller) return;
    tableScroller.scrollLeft = stickyScroller.scrollLeft;
    if (stickyScroller.scrollLeft > 6) setShowScrollHint(false);
    updateScrollUi();
  };

  const revealMoreColumns = () => {
    const scroller = tableScrollerRef.current;
    if (!scroller) return;
    setShowScrollHint(false);
    scroller.scrollLeft = Math.min(scroller.scrollWidth - scroller.clientWidth, scroller.scrollLeft + scroller.clientWidth * 0.65);
    if (stickyScrollerRef.current) stickyScrollerRef.current.scrollLeft = scroller.scrollLeft;
    updateScrollUi();
  };

  const addPhase = () => {
    const next: ThoughtGroup = { id: uid("wbs-group"), thought: "", category: "Testing", actions: [] };
    onGroupsChange([...thoughtGroups, next]);
    setEditingGroup(next);
  };

  // 在某个任务下新增思路（childGroups）
  const addThoughtUnderTask = (action: ActionCard) => {
    const next: ThoughtGroup = { id: uid("wbs-group"), thought: "", category: "Testing", actions: [] };
    onGroupsChange(updateAction(thoughtGroups, action.id, (target) => ({ ...target, childGroups: [...(target.childGroups ?? []), next] })));
    setEditingGroup(next);
  };

  // 批量导入：顶格 = 思路，缩进 / 以 - 开头 = 其上方思路的任务
  const runBatchImport = (text: string) => {
    const lines = text.split("\n").filter((line) => line.trim());
    if (!lines.length) return;
    const groups: ThoughtGroup[] = [];
    let current: ThoughtGroup | null = null;
    lines.forEach((raw) => {
      const isTask = /^\s+/.test(raw) || /^[-*·•]/.test(raw.trim());
      const clean = raw.trim().replace(/^[-*·•]\s*/, "").replace(/^\d+[.)、]\s*/, "").trim();
      if (!clean) return;
      if (isTask && current) {
        current.actions.push({ id: uid("wbs-task"), title: clean, expectation: "", urgency: "一般", department: "PTE", assignee: "", dueDate: "", note: "" });
      } else {
        current = { id: uid("wbs-group"), thought: clean, category: "Testing", actions: [] };
        groups.push(current);
      }
    });
    if (groups.length) onGroupsChange([...thoughtGroups, ...groups]);
  };

  const addTask = (group: ThoughtGroup) => {
    const task: ActionCard = {
      id: uid("wbs-task"),
      title: "新执行任务",
      expectation: "",
      urgency: "一般",
      department: "PTE",
      assignee: "",
      dueDate: "",
      note: "",
    };
    onGroupsChange(updateGroups(thoughtGroups, group.id, (target) => ({ ...target, actions: [...target.actions, task] })));
    setEditingTask({ groupId: group.id, draft: task });
  };

  const saveGroup = () => {
    if (!editingGroup?.thought.trim()) return;
    onGroupsChange(updateGroups(thoughtGroups, editingGroup.id, () => ({ ...editingGroup, thought: editingGroup.thought.trim() })));
    setEditingGroup(null);
  };

  const saveTask = () => {
    if (!editingTask?.draft.title.trim()) return;
    const { groupId, draft } = editingTask;
    const normalized: ActionCard = {
      ...draft,
      title: draft.title.trim(),
      type: draft.type || undefined,
      // EFA分析任务保存时同步提交结构化 EFA 单
      efaAnalysis: draft.type === "EFA分析" ? { ...(draft.efaAnalysis || defaultEfa(caseData)), submitted: draft.efaAnalysis?.mode ? true : draft.efaAnalysis?.submitted } : undefined,
      coverageTestName: draft.type === "Coverage上线" ? draft.coverageTestName : undefined,
      coverageTestTime: draft.type === "Coverage上线" ? draft.coverageTestTime : undefined,
      coverageActionStage: draft.type === "Coverage上线" ? draft.coverageActionStage : undefined,
      coverageBallType: draft.type === "Coverage上线" ? draft.coverageBallType : undefined,
      coveragePackage: draft.type === "Coverage上线" ? draft.coveragePackage : undefined,
      coverageSpeed: draft.type === "Coverage上线" ? draft.coverageSpeed : undefined,
      coverageTester: draft.type === "Coverage上线" ? draft.coverageTester : undefined,
      coverageQG: draft.type === "Coverage上线" ? draft.coverageQG : undefined,
      coverageReleaseType: draft.type === "Coverage上线" ? draft.coverageReleaseType : undefined,
      coverageTeOwner: draft.type === "Coverage上线" ? draft.coverageTeOwner : undefined,
      coveragePeOwner: draft.type === "Coverage上线" ? draft.coveragePeOwner : undefined,
      coverageNtc: draft.type === "Coverage上线" ? draft.coverageNtc : undefined,
    };
    onGroupsChange(updateGroups(thoughtGroups, groupId, (group) => ({
      ...group,
      actions: group.actions.map((action) => action.id === normalized.id ? normalized : action),
    })));
    setEditingTask(null);
  };

  const removeTask = (groupId: string, taskId: string) => {
    onGroupsChange(updateGroups(thoughtGroups, groupId, (group) => ({
      ...group,
      actions: group.actions.filter((action) => action.id !== taskId),
    })));
  };

  const saveEfa = (groupId: string, taskId: string, value: EfaAnalysisCard) => {
    onGroupsChange(updateGroups(thoughtGroups, groupId, (group) => ({
      ...group,
      actions: group.actions.map((action) => action.id === taskId ? { ...action, efaAnalysis: value } : action),
    })));
  };

  const remainingText = (action: ActionCard): { text: string; className: string } => {
    if (action.status === "已完成" || action.status === "已拒绝" || action.status === "已中止") {
      return { text: action.status, className: "text-slate-400" };
    }
    if (!action.dueDate) return { text: "未设置", className: "text-slate-300" };
    const due = new Date(`${action.dueDate}T00:00:00`).getTime();
    if (Number.isNaN(due)) return { text: "未设置", className: "text-slate-300" };
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const days = Math.ceil((due - today.getTime()) / 86400000);
    if (days < 0) return { text: `已逾期 ${Math.abs(days)} 天`, className: "text-red-500" };
    if (days === 0) return { text: "今日到期", className: "text-red-500" };
    return { text: `剩余 ${days} 天`, className: days <= 3 ? "text-amber-600" : "text-slate-400" };
  };

  const compactView = compact ? (
    <div className="overflow-hidden rounded-lg border border-slate-200 bg-white">
      <div className="flex h-12 items-center gap-2 border-b border-slate-200 px-4">
        <span className="inline-flex items-center gap-2 text-sm font-semibold text-slate-800"><ListChecks size={15} className="text-[#0052D9]" />任务分解</span>
        <span className="text-[10.5px] text-slate-400">{thoughtCount} 个思路 · {taskCount} 个任务</span>
        {!readOnly && <button type="button" onClick={addPhase} className="ml-auto inline-flex h-7 items-center gap-1 rounded-md bg-[#0052D9] px-2.5 text-[10.5px] text-white hover:bg-[#003FA8]"><Plus size={11} />新增根思路</button>}
      </div>
      <div className="grid h-10 grid-cols-[minmax(180px,1fr)_76px_112px_132px_124px_88px_88px] items-center gap-2 border-b border-slate-200 bg-slate-50 px-4 text-[10.5px] font-semibold text-slate-500">
        <div className="min-w-0">思路 / 任务</div>
        <div>状态</div>
        <div>负责人</div>
        <div>创建时间</div>
        <div className="text-right">期望完成 / 剩余</div>
        <div className="text-right">
          <button type="button" onClick={() => setDurationSort((current) => current === "none" ? "desc" : current === "desc" ? "asc" : "none")} title={durationSort === "none" ? "点击按耗时从高到低排序" : durationSort === "desc" ? "当前从高到低，点击改为从低到高" : "当前从低到高，点击恢复任务顺序"} className="ml-auto inline-flex items-center gap-1 text-[10.5px] font-semibold text-slate-500">
            耗时排行
            {durationSort === "desc" ? <ArrowDown size={11} /> : durationSort === "asc" ? <ArrowUp size={11} /> : <ArrowDownUp size={11} />}
          </button>
        </div>
        <div className="text-right">操作</div>
      </div>
      <div className="divide-y divide-slate-100/70">
        {rows.map((row) => {
          if ("group" in row && !("action" in row)) {
            const group = row.group;
            const isCollapsed = collapsed.has(group.id);
            return (
              <div key={`compact-group-${group.id}`} className="grid min-h-[50px] grid-cols-[minmax(180px,1fr)_76px_112px_132px_124px_88px_88px] items-center gap-2 bg-[#0052D9]/[0.035] px-4 py-2">
                <div className="min-w-0" style={{ paddingLeft: row.depth * 22 }}>
                  <button type="button" onClick={() => setCollapsed((previous) => { const next = new Set(previous); next.has(group.id) ? next.delete(group.id) : next.add(group.id); return next; })} className="flex max-w-full items-center gap-2 text-left text-[12.5px] font-semibold text-slate-800 hover:text-[#0052D9]">
                    {row.depth > 0 && <span className="text-slate-300">└</span>}
                    {isCollapsed ? <ChevronRight size={12} className="shrink-0 text-slate-400" /> : <ChevronDown size={12} className="shrink-0 text-slate-400" />}
                    <span className="inline-flex shrink-0 items-center gap-1 rounded border border-amber-200 bg-amber-50 px-1.5 py-0.5 text-[9.5px] font-normal text-amber-700"><Lightbulb size={10} />思路</span>
                    <span className="truncate">{group.thought}</span>
                    <span className="shrink-0 text-[10px] font-normal text-slate-400">{group.actions.length} 个任务</span>
                  </button>
                </div>
                <div aria-hidden="true" /><div aria-hidden="true" /><div aria-hidden="true" /><div aria-hidden="true" /><div aria-hidden="true" />
                <div className="flex justify-end gap-1">
                  {!readOnly && <>
                    <button type="button" onClick={() => addTask(group)} title="新增任务" aria-label="新增任务" className="grid h-7 w-7 place-items-center rounded-md border border-[#0052D9]/20 bg-white text-[#0052D9] hover:bg-[#0052D9]/5"><span className="relative grid h-4 w-4 place-items-center"><ListChecks size={13} /><span className="absolute -right-1 -top-1 grid h-2.5 w-2.5 place-items-center rounded-full bg-[#0052D9] text-white ring-1 ring-white"><Plus size={7} strokeWidth={3} /></span></span></button>
                    <button type="button" onClick={() => setEditingGroup({ ...group })} title="编辑思路" className="grid h-7 w-7 place-items-center rounded-md border border-slate-200 bg-white text-slate-500 hover:text-[#0052D9]"><Edit2 size={11} /></button>
                    <button type="button" onClick={() => { if (confirm(`删除思路「${group.thought}」及其全部任务？`)) onGroupsChange(removeGroup(thoughtGroups, group.id)); }} title="删除思路" className="grid h-7 w-7 place-items-center rounded-md border border-slate-200 bg-white text-slate-400 hover:text-red-500"><Trash2 size={11} /></button>
                  </>}
                </div>
              </div>
            );
          }

          const { action, group, depth, wbs } = row as TaskRow;
          const remaining = remainingText(action);
          const rank = durationRanks.get(action.id);
          return (
            <div key={`compact-task-${action.id}`} data-task-row={action.id} title={`紧急度：${action.urgency}`} className="group grid min-h-[62px] grid-cols-[minmax(180px,1fr)_76px_112px_132px_124px_88px_88px] items-center gap-2 px-4 py-2.5 transition-colors hover:bg-slate-50/60">
              <div className="min-w-0" style={{ paddingLeft: depth * 22 }}>
                <div className="flex min-w-0 items-stretch gap-2">
                  <span className={`w-[3px] shrink-0 rounded-full ${action.urgency === "非常紧急" ? "bg-red-500" : action.urgency === "紧急" ? "bg-orange-500" : action.urgency === "一般" ? "bg-sky-500" : "bg-slate-300"}`} aria-hidden="true" />
                  <div className="min-w-0 flex-1">
                    <button type="button" onClick={onTaskOpen ? () => onTaskOpen(action.id) : undefined} className={`block max-w-full truncate text-left text-sm text-slate-800 transition-colors ${onTaskOpen ? "hover:text-[#0052D9]" : "cursor-default"}`}><span className="mr-1 text-slate-300">└</span>{action.title}</button>
                    <div className="mt-0.5 flex min-w-0 items-center gap-1.5 text-[10.5px] text-slate-400"><span className="shrink-0 font-mono">{wbs}</span><span>·</span><span className="truncate">{group.thought}</span></div>
                  </div>
                </div>
              </div>
              <div><span className="inline-flex items-center gap-1.5 text-[11px] text-slate-500"><StatusBadge status={action.status ?? "待接受"} size={16} />{action.status ?? "待接受"}</span></div>
              <div className="flex min-w-0 items-center gap-1.5 text-xs text-slate-600"><span className={`grid h-5 w-5 shrink-0 place-items-center rounded-full text-[10px] font-medium ${action.assignee ? "bg-[#0052D9]/8 text-[#0052D9]" : "bg-slate-100 text-slate-400"}`}>{action.assignee?.[0] ?? "—"}</span><span className="truncate">{action.department} · {action.assignee || "待指派"}</span></div>
              <span data-task-created-at title={taskCreatedTimes[action.id] ?? "创建时间未记录"} className="text-[10.5px] tabular-nums text-slate-500">{formatCaseTime(taskCreatedTimes[action.id])}</span>
              <span className="text-right"><span className="block text-xs tabular-nums text-slate-500">{action.dueDate || "—"}</span><span className={`mt-0.5 block text-[9.5px] ${remaining.className}`}>{remaining.text}</span></span>
              <span className="flex items-center justify-end gap-2 whitespace-nowrap">{typeof action.actualDurationHours === "number" ? <><span className="rounded bg-[#0052D9]/8 px-1.5 py-0.5 text-[9.5px] font-semibold tabular-nums text-[#0052D9]">#{rank}</span><span className="text-[11px] font-medium tabular-nums text-slate-700">{action.actualDurationHours}h</span></> : <span className="text-[10.5px] text-slate-300">—</span>}</span>
              <div className="flex justify-end gap-1">
                {!readOnly && <>
                  <button type="button" onClick={() => addThoughtUnderTask(action)} title="新增思路" aria-label="新增思路" className="grid h-7 w-7 place-items-center rounded-md border border-slate-200 text-slate-500 hover:border-[#0052D9]/30 hover:text-[#0052D9]"><span className="relative grid h-4 w-4 place-items-center"><Lightbulb size={13} /><span className="absolute -right-1 -top-1 grid h-2.5 w-2.5 place-items-center rounded-full bg-[#0052D9] text-white ring-1 ring-white"><Plus size={7} strokeWidth={3} /></span></span></button>
                  <button type="button" onClick={() => setEditingTask({ groupId: group.id, draft: { ...action } })} title="编辑" className="grid h-7 w-7 place-items-center rounded-md border border-slate-200 text-slate-600 hover:text-[#0052D9]"><Edit2 size={11} /></button>
                  <button type="button" onClick={() => { if (confirm(`删除任务「${action.title}」？`)) removeTask(group.id, action.id); }} title="删除任务" className="grid h-7 w-7 place-items-center rounded-md border border-slate-200 text-slate-400 hover:text-red-500"><Trash2 size={11} /></button>
                </>}
              </div>
            </div>
          );
        })}
        {!rows.length && <div className="grid min-h-[220px] place-items-center text-sm text-slate-400"><span className="inline-flex items-center gap-2"><ListChecks size={16} />暂无思路和任务</span></div>}
      </div>
    </div>
  ) : null;

  return (
    <>
    {compactView ?? (
    <div className="rounded-xl border border-slate-200 bg-white overflow-hidden shadow-[0_1px_2px_rgba(15,23,42,0.04)]">
      <div className="h-14 px-4 flex items-center gap-3 border-b border-slate-200 bg-slate-50/70">
        <span className="w-8 h-8 rounded-lg bg-[#0052D9]/10 text-[#0052D9] grid place-items-center"><TableProperties size={16} /></span>
        <div>
          <div className="text-[13px] font-bold text-slate-800">任务分解</div>
          <div className="text-[10.5px] text-slate-400">{thoughtGroups.length} 个思路 · {taskCount} 个任务{readOnly ? "" : " · 与思维导图共享同一份数据"}</div>
        </div>
        {scrollHintVisible && (
          <button type="button" onClick={revealMoreColumns} className="ml-auto h-7 px-2.5 rounded-full border border-[#0052D9]/20 bg-[#0052D9]/5 text-[#0052D9] text-[10.5px] font-medium inline-flex items-center gap-1 hover:bg-[#0052D9]/10 transition-colors whitespace-nowrap">
            还有 {scrollUi.hiddenColumns || "更多"} 列，向右滚动查看 <ChevronRight size={12} />
          </button>
        )}
        {!readOnly && (
          <div className={`${scrollHintVisible ? "" : "ml-auto"} flex items-center gap-2`}>
            <button type="button" onClick={addPhase} className="h-8 px-3 rounded-lg bg-[#0052D9] text-white text-[12px] font-medium hover:bg-[#003FA8] inline-flex items-center gap-1.5 whitespace-nowrap"><Plus size={13} /> 新增思路</button>
          </div>
        )}
      </div>

      <div className="relative">
        <div ref={tableScrollerRef} onScroll={handleTableScroll} className="wbs-main-scroll overflow-x-auto pb-4">
          <table className={`w-full ${showExecutionMetrics ? "min-w-[1460px]" : "min-w-[1240px]"} border-collapse text-left`}>
          <thead>
            <tr className="h-10 bg-slate-50 text-[10.5px] font-semibold text-slate-500 border-b border-slate-200">
              <th className="w-[76px] px-3">序号</th>
              <th className="w-[72px] px-2">类型</th>
              <th className="px-3">思路 / 任务与预期</th>
              {showExecutionMetrics && <th className="w-[110px] px-3">状态</th>}
              <th className="w-[88px] px-3">负责人</th>
              <th className="w-[96px] px-3">部门</th>
              <th className="w-[90px] px-3">紧急度</th>
              <th className="w-[112px] px-3">期望完成</th>
              {showExecutionMetrics && (
                <th className="w-[120px] px-3">
                  <button
                    type="button"
                    onClick={() => setDurationSort((current) => current === "none" ? "desc" : current === "desc" ? "asc" : "none")}
                    title={durationSort === "none" ? "点击按耗时从高到低排序" : durationSort === "desc" ? "当前从高到低，点击改为从低到高" : "当前从低到高，点击恢复 WBS 顺序"}
                    className="inline-flex items-center gap-1 whitespace-nowrap text-[10.5px] font-bold text-slate-500"
                  >
                    耗时排行
                    {durationSort === "desc" ? <ArrowDown size={11} /> : durationSort === "asc" ? <ArrowUp size={11} /> : <ArrowDownUp size={11} />}
                  </button>
                </th>
              )}
              <th className="w-[128px] px-3">任务标签</th>
              <th className="w-[150px] px-3">附件</th>
              <th className="w-[126px] px-3 text-right">操作</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => {
              if ("group" in row && !("action" in row)) {
                const group = row.group;
                const isCollapsed = collapsed.has(group.id);
                return (
                  <tr key={`group-${group.id}`} className="h-11 bg-[#0052D9]/[0.035] border-b border-[#0052D9]/10">
                    <td className="px-3 text-[11px] font-bold text-[#0052D9] tabular-nums">{row.wbs}</td>
                    <td className="px-2"><span className="text-[9.5px] px-1.5 py-0.5 rounded bg-amber-50 text-amber-700 border border-amber-200">思路</span></td>
                    <td className="px-3" colSpan={showExecutionMetrics ? 9 : 7}>
                      <button type="button" onClick={() => setCollapsed((previous) => { const next = new Set(previous); next.has(group.id) ? next.delete(group.id) : next.add(group.id); return next; })} className="inline-flex items-center gap-2 text-[12.5px] font-bold text-slate-800 hover:text-[#0052D9]">
                        {isCollapsed ? <ChevronRight size={13} /> : <ChevronDown size={13} />}
                        <span style={{ paddingLeft: row.depth * 14 }}>{group.thought}</span>
                        <span className="text-[10px] font-normal text-slate-400">{group.actions.length} 个任务</span>
                      </button>
                    </td>
                    <td className="px-3">
                      {readOnly ? (
                        <div className="flex justify-end">
                          <span className="text-[10.5px] text-slate-400">查看任务</span>
                        </div>
                      ) : (
                        <div className="flex flex-nowrap justify-end gap-1">
                          <button type="button" onClick={() => addTask(group)} title="新增任务" className="h-7 px-2 rounded-md border border-[#0052D9]/20 text-[#0052D9] bg-white hover:bg-[#0052D9]/5 inline-flex items-center gap-1 text-[10.5px] whitespace-nowrap shrink-0"><Plus size={11} /> 任务</button>
                          <button type="button" onClick={() => setEditingGroup({ ...group })} title="编辑思路" className="w-7 h-7 rounded-md border border-slate-200 bg-white text-slate-500 hover:text-[#0052D9] grid place-items-center shrink-0"><Edit2 size={11} /></button>
                          <button type="button" onClick={() => { if (confirm(`删除思路「${group.thought}」及其全部任务？`)) onGroupsChange(removeGroup(thoughtGroups, group.id)); }} title="删除思路" className="w-7 h-7 rounded-md border border-slate-200 bg-white text-slate-400 hover:text-red-500 grid place-items-center shrink-0"><Trash2 size={11} /></button>
                        </div>
                      )}
                    </td>
                  </tr>
                );
              }

              const { action, group, depth, wbs } = row as TaskRow;
              const efaOpen = efaTaskId === action.id;
              const hasLinkedData = !!(action.voiceNote || action.note || action.efaAnalysis);
              return [
                <tr key={`task-${action.id}`} className="h-[58px] border-b border-slate-100 hover:bg-slate-50/70 transition-colors">
                  <td className="px-3 text-[10.5px] text-slate-400 tabular-nums">{wbs}</td>
                  <td className="px-2"><span className="text-[9.5px] px-1.5 py-0.5 rounded bg-blue-50 text-blue-600 border border-blue-200">任务</span></td>
                  <td className="px-3">
                    <div style={{ paddingLeft: depth * 14 }}>
                      <div className={`text-[12px] font-semibold ${onTaskOpen ? "text-[#0052D9] hover:text-[#003FA8] cursor-pointer" : "text-slate-800"}`} onClick={onTaskOpen ? () => onTaskOpen(action.id) : undefined}>{action.title}</div>
                      <div className="mt-0.5 text-[10.5px] text-slate-400 line-clamp-1">{action.expectation || "暂未填写预期"}</div>
                    </div>
                  </td>
                  {showExecutionMetrics && (
                    <td className="px-3">
                      <span className="inline-flex items-center gap-1.5 text-[10.5px] text-slate-600">
                        <StatusBadge status={action.status ?? "待接受"} size={16} />
                        {action.status ?? "待接受"}
                      </span>
                    </td>
                  )}
                  <td className="px-3 text-[11px] text-slate-600">{action.assignee || "待指派"}</td>
                  <td className="px-3 text-[11px] text-slate-600">{action.department}</td>
                  <td className="px-3"><span className={`text-[9.5px] px-1.5 py-0.5 rounded border ${urgencyStyle[action.urgency]}`}>{action.urgency}</span></td>
                  <td className="px-3 text-[10.5px] text-slate-500">{action.dueDate ? <span className="inline-flex items-center gap-1"><Calendar size={10} />{action.dueDate}</span> : "—"}</td>
                  {showExecutionMetrics && (
                    <td className="px-3">
                      {typeof action.actualDurationHours === "number" ? (
                        <span className="inline-flex items-center gap-2 whitespace-nowrap" title={`实际耗时 ${action.actualDurationHours} 小时`}>
                          <span className="rounded bg-[#0052D9]/8 px-1.5 py-0.5 text-[9.5px] font-semibold tabular-nums text-[#0052D9]">#{durationRanks.get(action.id)}</span>
                          <span className="text-[11px] font-medium tabular-nums text-slate-700">{action.actualDurationHours}h</span>
                        </span>
                      ) : <span className="text-[10.5px] text-slate-300">—</span>}
                    </td>
                  )}
                  <td className="px-3">
                    <div className="flex flex-wrap gap-1">
                      {action.type && <span className={`text-[9.5px] px-1.5 py-0.5 rounded border ${action.type === "Coverage上线" ? "bg-cyan-50 text-cyan-700 border-cyan-200" : "bg-slate-50 text-slate-600 border-slate-200"}`}>{action.type}</span>}
                      {action.efaAnalysis && <button type="button" onClick={() => setEfaTaskId(efaOpen ? null : action.id)} className={`text-[9.5px] px-1.5 py-0.5 rounded border inline-flex items-center gap-0.5 ${action.efaAnalysis.submitted ? "bg-emerald-50 text-emerald-700 border-emerald-200" : "bg-violet-50 text-violet-600 border-violet-200"}`}>{action.efaAnalysis.submitted ? <CheckCircle2 size={9} /> : <FlaskConical size={9} />} {action.efaAnalysis.submitted ? "EFA 已提交" : "EFA"}</button>}
                    </div>
                  </td>
                  <td className="px-3">
                    {action.attachments && action.attachments.length > 0 ? (
                      <div className="flex flex-wrap gap-1">
                        {action.attachments.map((att, idx) => (
                          <span key={`${action.id}-att-${idx}`} className="inline-flex items-center gap-1 rounded border border-slate-200 bg-white px-1.5 py-0.5 text-[10px] text-slate-600 max-w-[136px]" title={att.name}>
                            <Paperclip size={9} className="text-slate-400 shrink-0" /> <span className="truncate">{att.name}</span>
                          </span>
                        ))}
                      </div>
                    ) : (
                      <span className="text-[10.5px] text-slate-300">—</span>
                    )}
                  </td>
                  <td className="px-3">
                    {readOnly ? (
                      <div className="flex justify-end gap-1">
                        <button type="button" onClick={onTaskOpen ? () => onTaskOpen(action.id) : undefined} className="h-7 px-2 rounded-md text-[10.5px] border border-slate-200 text-slate-600 hover:text-[#0052D9] inline-flex items-center gap-1"><ChevronRight size={11} /> 查看</button>
                      </div>
                    ) : (
                      <div className="flex justify-end gap-1">
                        <button type="button" onClick={() => addThoughtUnderTask(action)} title="在此任务下添加思路" className="h-7 px-2 rounded-md text-[10.5px] border border-amber-200 text-amber-700 bg-white hover:bg-amber-50 inline-flex items-center gap-1"><Plus size={11} /> 思路</button>
                        <button type="button" onClick={() => setEditingTask({ groupId: group.id, draft: { ...action } })} title="编辑" className="w-7 h-7 rounded-md border border-slate-200 text-slate-600 hover:text-[#0052D9] grid place-items-center"><Edit2 size={11} /></button>
                        <button type="button" onClick={() => { if (confirm(`删除任务「${action.title}」？`)) removeTask(group.id, action.id); }} className="w-7 h-7 rounded-md border border-slate-200 text-slate-400 hover:text-red-500 grid place-items-center"><Trash2 size={11} /></button>
                      </div>
                    )}
                  </td>
                </tr>,
                readOnly && hasLinkedData ? (
                  <tr key={`task-data-${action.id}`} className="border-b border-slate-100 bg-slate-50/50">
                    <td colSpan={showExecutionMetrics ? 12 : 10} className="px-6 py-2.5">
                      <div className="flex items-start gap-3">
                        <span className="shrink-0 mt-0.5 text-[10px] px-1.5 py-0.5 rounded bg-[#0052D9]/8 text-[#0052D9] border border-[#0052D9]/15">关联数据</span>
                        <div className="min-w-0 flex-1 space-y-1.5">
                          {(action.note || action.voiceNote || action.efaAnalysis) && (
                            <div className="flex flex-wrap gap-1.5">
                              {action.note && <span className="inline-flex items-center gap-1 rounded border border-amber-200 bg-amber-50 px-2 py-0.5 text-[10.5px] text-amber-700">附言：{action.note}</span>}
                              {action.voiceNote && <span className="inline-flex items-center gap-1 rounded border border-violet-200 bg-violet-50 px-2 py-0.5 text-[10.5px] text-violet-700">语音备注</span>}
                              {action.efaAnalysis && <span className={`inline-flex items-center gap-1 rounded border px-2 py-0.5 text-[10.5px] ${action.efaAnalysis.submitted ? "border-emerald-200 bg-emerald-50 text-emerald-700" : "border-violet-200 bg-violet-50 text-violet-700"}`}>EFA {action.efaAnalysis.submitted ? "已提交" : "待提交"}</span>}
                            </div>
                          )}
                        </div>
                      </div>
                    </td>
                  </tr>
                ) : null,
                action.efaAnalysis && efaOpen && !readOnly ? (
                  <tr key={`efa-${action.id}`} className="border-b border-violet-100 bg-violet-50/25">
                    <td colSpan={showExecutionMetrics ? 12 : 10} className="px-8 py-3">
                      <EfaWbsEditor value={action.efaAnalysis} onSave={(value) => saveEfa(group.id, action.id, value)} />
                    </td>
                  </tr>
                ) : null,
              ];
            })}
            {!rows.length && (
              <tr><td colSpan={showExecutionMetrics ? 12 : 10} className="py-16 text-center text-[12px] text-slate-400">暂无任务分解内容，点击“新增思路”开始拆解。</td></tr>
            )}
          </tbody>
          </table>
        </div>

        {scrollUi.overflowing && !scrollUi.atEnd && (
          <div aria-hidden="true" className="pointer-events-none absolute inset-y-0 right-0 z-20 w-6 bg-gradient-to-l from-white/90 to-transparent" />
        )}
        {scrollUi.overflowing && !scrollUi.atStart && (
          <div aria-hidden="true" className="pointer-events-none absolute inset-y-0 left-0 z-20 w-6 bg-gradient-to-r from-white/90 to-transparent" />
        )}
        {scrollUi.overflowing && scrollUi.barMode !== "hidden" && (
          <div
            className="z-40 rounded-md bg-white/95 py-1 shadow-[0_0_0_1px_rgba(148,163,184,0.28),0_3px_10px_rgba(15,23,42,0.16)] backdrop-blur-sm"
            style={scrollUi.barMode === "fixed"
              ? { position: "fixed", left: scrollUi.barLeft, width: scrollUi.barWidth, bottom: 8 }
              : { position: "absolute", left: 0, right: 0, bottom: 4 }}
          >
            <div ref={stickyScrollerRef} onScroll={handleStickyScroll} className="wbs-sticky-scroll h-[12px] overflow-x-scroll">
              <div aria-hidden="true" style={{ width: scrollUi.contentWidth, height: 1 }} />
            </div>
          </div>
        )}
      </div>
    </div>
    )}

      {!readOnly && editingGroup && (
        <ThoughtGroupEditor
          group={editingGroup}
          onChange={setEditingGroup}
          onCancel={() => setEditingGroup(null)}
          onSave={saveGroup}
        />
      )}

      {!readOnly && batchOpen && (
        <BatchImportModal
          onCancel={() => setBatchOpen(false)}
          onImport={(text) => { runBatchImport(text); setBatchOpen(false); }}
        />
      )}

      {!readOnly && editingTask && (
        <TaskEditor
          caseData={caseData}
          draft={editingTask.draft}
          onChange={(draft) => setEditingTask({ ...editingTask, draft })}
          onCancel={() => setEditingTask(null)}
          onSave={saveTask}
        />
      )}
    </>
  );
}

function TaskEditor({ caseData, draft, onChange, onCancel, onSave }: { caseData: CaseItem; draft: ActionCard; onChange: (draft: ActionCard) => void; onCancel: () => void; onSave: () => void }) {
  const patch = (value: Partial<ActionCard>) => onChange({ ...draft, ...value });
  const efa = draft.efaAnalysis;
  const efaInput = "mt-1 w-full h-8 px-2 rounded border border-slate-200 bg-white outline-none focus:border-violet-500 text-[11px]";
  const patchEfa = (next: Partial<EfaAnalysisCard>) => patch({ efaAnalysis: { ...(efa as EfaAnalysisCard), ...next } });
  const efaReady = draft.type !== "EFA分析" || !!efa?.mode;
  return (
    <div className="fixed inset-0 z-[80] bg-slate-900/40 flex items-center justify-center" onClick={onCancel}>
      <div className="w-[620px] max-h-[88vh] overflow-y-auto bg-white rounded-xl border border-slate-200 shadow-2xl p-5" onClick={(event) => event.stopPropagation()}>
        <div className="flex items-center gap-2"><Edit2 size={15} className="text-[#0052D9]" /><h3 className="text-sm font-bold text-slate-900">编辑任务</h3><button onClick={onCancel} className="ml-auto text-slate-400 hover:text-slate-600"><X size={16} /></button></div>
        <div className="mt-4 grid grid-cols-2 gap-3">
          <label className="col-span-2 text-xs text-slate-600">任务名称 <span className="text-red-500">*</span><input autoFocus value={draft.title} onChange={(event) => patch({ title: event.target.value })} className="mt-1 w-full h-9 px-2.5 rounded border border-slate-200 outline-none focus:border-[#0052D9] text-sm" /></label>
          <label className="col-span-2 text-xs text-slate-600">预期<input value={draft.expectation || ""} onChange={(event) => patch({ expectation: event.target.value })} placeholder="本任务希望验证或达成什么" className="mt-1 w-full h-9 px-2.5 rounded border border-slate-200 outline-none focus:border-[#0052D9] text-sm" /></label>
          <label className="text-xs text-slate-600">负责人<div className="mt-1"><TaskAssigneeField value={{ assignee: draft.assignee, department: draft.department, assigneeType: draft.assigneeType, skillId: draft.skillId, skillRun: draft.skillRun }} onChange={(next) => patch(next)} /></div></label>
          <label className="text-xs text-slate-600">部门<select value={draft.department} onChange={(event) => patch({ department: event.target.value })} className="mt-1 w-full h-9 px-2.5 rounded border border-slate-200 outline-none focus:border-[#0052D9] text-sm bg-white">{DEPARTMENTS.map((item) => <option key={item}>{item}</option>)}</select></label>
          <label className="text-xs text-slate-600">紧急程度<select value={draft.urgency} onChange={(event) => patch({ urgency: event.target.value as Urgency })} className="mt-1 w-full h-9 px-2.5 rounded border border-slate-200 outline-none focus:border-[#0052D9] text-sm bg-white">{URGENCIES.map((item) => <option key={item}>{item}</option>)}</select></label>
          <label className="text-xs text-slate-600">期望完成<input type="date" value={draft.dueDate} onChange={(event) => patch({ dueDate: event.target.value })} className="mt-1 w-full h-9 px-2.5 rounded border border-slate-200 outline-none focus:border-[#0052D9] text-sm" /></label>
          <label className="col-span-2 text-xs text-slate-600">任务标签<select value={draft.type || ""} onChange={(event) => { const type = (event.target.value || undefined) as TaskType | undefined; patch({ type, efaAnalysis: type === "EFA分析" ? (efa || defaultEfa(caseData)) : undefined }); }} className="mt-1 w-full h-9 px-2.5 rounded border border-slate-200 outline-none focus:border-[#0052D9] text-sm bg-white"><option value="">通用</option>{TASK_TYPES.map((item) => <option key={item}>{item}</option>)}</select></label>
        </div>

        {draft.type === "Coverage上线" && (
          <div className="mt-4 rounded-xl border border-cyan-200 bg-cyan-50/60 p-3">
            <div className="text-xs font-bold text-cyan-800 inline-flex items-center gap-1.5"><Radar size={13} /> Coverage 上线信息</div>
            <div className="mt-2.5"><CoveragePatternFields value={draft} onChange={(next) => patch(next)} /></div>
            <div className="mt-2.5 grid grid-cols-2 gap-3">
              <label className="col-span-2 text-xs text-slate-600">程式版本 <span className="text-red-500">*</span><input value={draft.coverageProgramVersion || ""} onChange={(event) => patch({ coverageProgramVersion: event.target.value })} placeholder="请输入程式版本" className="mt-1 w-full h-9 px-2.5 rounded border border-slate-200 bg-white outline-none focus:border-cyan-500 text-sm" /></label>
              <label className="col-span-2 text-xs text-slate-600">测试项名称 <span className="text-red-500">*</span><input value={draft.coverageTestName || ""} onChange={(event) => patch({ coverageTestName: event.target.value })} placeholder="请输入测试项名称" className="mt-1 w-full h-9 px-2.5 rounded border border-slate-200 bg-white outline-none focus:border-cyan-500 text-sm" /></label>
              <label className="text-xs text-slate-600">测试时长 <span className="text-red-500">*</span><input value={draft.coverageTestTime || ""} onChange={(event) => patch({ coverageTestTime: event.target.value })} placeholder="请输入测试时长" className="mt-1 w-full h-9 px-2.5 rounded border border-slate-200 bg-white outline-none focus:border-cyan-500 text-sm" /></label>
            </div>
            <div className="mt-3"><CoverageOwnerFields value={draft} onChange={(next) => patch(next)} /></div>
          </div>
        )}

        <div className="mt-4 grid grid-cols-2 gap-3">
          <label className="block text-xs text-slate-600 min-w-0">
            附件 <span className="text-slate-400">（可选）</span>
            <div className="mt-1">
              <AttachmentInput value={(draft.attachments as Att[]) || []} onChange={(value) => patch({ attachments: value.length ? value : undefined })} compact />
            </div>
          </label>
          <label className="block text-xs text-slate-600 min-w-0">
            语音备注 <span className="text-slate-400">（可选）</span>
            <div className="mt-1">
              <VoiceRecorder value={draft.voiceNote} onChange={(value) => patch({ voiceNote: value })} compact />
            </div>
          </label>
        </div>

        {draft.type === "EFA分析" && (
          <div className="mt-4 rounded-xl border border-violet-300 bg-violet-50/60">
            <div className="flex items-center gap-3 p-3"><FlaskConical size={15} className="text-violet-600" /><span className="block text-xs font-semibold text-slate-700">EFA 分析信息</span></div>
            {efa && (
            <div className="border-t border-violet-100 p-3">
              <div className="flex items-center gap-2 mb-2.5">
                <span className="text-[10.5px] text-slate-500">类型</span>
                {(["component", "wafer"] as const).map((m) => (
                  <button key={m} type="button" onClick={() => patchEfa({ mode: m })} className={`h-6 px-3 rounded border text-[10px] ${efa.mode === m ? "bg-violet-600 border-violet-600 text-white" : "bg-white border-violet-200 text-violet-600"}`}>{m}</button>
                ))}
                {!efa.mode && <span className="text-[10px] text-violet-500">请选择 component 或 wafer</span>}
              </div>
              {efa.mode === "component" && (
                <>
                  <div className="grid grid-cols-5 gap-2">
                    {(["standard", "stage", "package", "quality", "failRate"] as const).map((key) => (
                      <label key={key} className="text-[10px] text-slate-500">{key === "failRate" ? "fail rate" : key}<input value={String(efa[key] || "")} onChange={(event) => patchEfa({ [key]: event.target.value })} className={efaInput} /></label>
                    ))}
                  </div>
                  <div className="mt-3">
                    <div className="text-[10px] font-semibold text-slate-600 mb-1.5">chiplist</div>
                    <div className="grid grid-cols-6 gap-2">
                      {(["fsa", "map", "failMode", "waferNo", "chipNo", "markCode"] as const).map((key) => (
                        <label key={key} className="text-[9px] text-slate-400">{key}<input value={String(efa.chipList?.[0]?.[key] || "")} onChange={(event) => patchEfa({ chipList: [{ ...(efa.chipList?.[0] || {}), [key]: event.target.value }] })} className={efaInput} /></label>
                      ))}
                    </div>
                  </div>
                </>
              )}
              {efa.mode === "wafer" && (
                <div className="grid grid-cols-5 gap-2">
                  {(["stage", "bin", "fsa", "map", "chipNo"] as const).map((key) => (
                    <label key={key} className="text-[10px] text-slate-500">{key === "chipNo" ? "chipno" : key}<input value={String(efa[key] || "")} onChange={(event) => patchEfa({ [key]: event.target.value })} className={efaInput} /></label>
                  ))}
                </div>
              )}
            </div>
            )}
          </div>
        )}

        <div className="mt-5 flex items-center justify-end gap-2">
          {draft.type === "EFA分析" && !efa?.mode && <span className="mr-auto text-[10.5px] text-violet-500">EFA 分析请先选择 component / wafer</span>}
          <button onClick={onCancel} className="h-8 px-3 rounded border border-slate-200 text-xs text-slate-600">取消</button>
          <button disabled={!draft.title.trim() || !efaReady} onClick={onSave} className="h-8 px-3 rounded bg-[#0052D9] text-white text-xs disabled:opacity-40 inline-flex items-center gap-1"><Check size={12} /> 保存任务</button>
        </div>
      </div>
    </div>
  );
}

function EfaWbsEditor({ value, onSave }: { value: EfaAnalysisCard; onSave: (value: EfaAnalysisCard) => void }) {
  const clone = (source: EfaAnalysisCard): EfaAnalysisCard => ({
    ...source,
    chipList: (source.chipList || []).map((chip) => ({ ...chip })),
  });
  const [draft, setDraft] = useState<EfaAnalysisCard>(() => clone(value));
  const [editing, setEditing] = useState(() => !value.submitted);
  useEffect(() => {
    setDraft(clone(value));
    setEditing(!value.submitted);
  }, [value]);
  const patch = (next: Partial<EfaAnalysisCard>) => setDraft((previous) => ({ ...previous, ...next }));
  const submitted = !!draft.submitted && !editing;
  const inputClass = "mt-1 w-full h-8 px-2 rounded border border-slate-200 bg-white outline-none focus:border-violet-500 text-[11px] disabled:bg-slate-50 disabled:text-slate-500";
  const submit = () => {
    const submittedValue = { ...draft, submitted: true };
    setDraft(submittedValue);
    setEditing(false);
    onSave(submittedValue);
  };

  return (
    <div className={`rounded-xl border bg-white overflow-hidden ${submitted ? "border-emerald-200" : "border-violet-200"}`}>
      <div className={`h-10 px-3 flex items-center gap-2 border-b ${submitted ? "bg-emerald-50 border-emerald-100" : "bg-violet-50 border-violet-100"}`}>
        {submitted ? <CheckCircle2 size={13} className="text-emerald-600" /> : <FlaskConical size={13} className="text-violet-600" />}
        <span className="text-[12px] font-bold text-slate-800">新增EFA分析单</span>
        {submitted && <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-emerald-100 text-emerald-700 border border-emerald-200">已提交</span>}
        <div className="ml-auto grid grid-cols-2 gap-1">
          {(["component", "wafer"] as const).map((mode) => <button key={mode} type="button" disabled={submitted} onClick={() => patch({ mode })} className={`h-6 px-3 rounded border text-[10px] disabled:cursor-default ${draft.mode === mode ? submitted ? "bg-emerald-600 border-emerald-600 text-white" : "bg-violet-600 border-violet-600 text-white" : "bg-white border-violet-200 text-violet-600"}`}>{mode}</button>)}
        </div>
      </div>
      <div className="p-3">
        {!draft.mode && <div className="py-3 text-center text-[11px] text-violet-600">请选择 component 或 wafer</div>}
        {draft.mode === "component" && <div className="grid grid-cols-5 gap-2">{(["standard", "stage", "package", "quality", "failRate"] as const).map((key) => <label key={key} className="text-[10px] text-slate-500">{key === "failRate" ? "fail rate" : key}<input disabled={submitted} value={String(draft[key] || "")} onChange={(event) => patch({ [key]: event.target.value })} className={inputClass} /></label>)}</div>}
        {draft.mode === "wafer" && <div className="grid grid-cols-5 gap-2">{(["stage", "bin", "fsa", "map", "chipNo"] as const).map((key) => <label key={key} className="text-[10px] text-slate-500">{key === "chipNo" ? "chipno" : key}<input disabled={submitted} value={String(draft[key] || "")} onChange={(event) => patch({ [key]: event.target.value })} className={inputClass} /></label>)}</div>}
        {draft.mode === "component" && <div className="mt-3"><div className="text-[10px] font-semibold text-slate-600 mb-1.5">chiplist</div><div className="grid grid-cols-6 gap-2">{(["fsa", "map", "failMode", "waferNo", "chipNo", "markCode"] as const).map((key) => <label key={key} className="text-[9px] text-slate-400">{key}<input disabled={submitted} value={String(draft.chipList?.[0]?.[key] || "")} onChange={(event) => patch({ chipList: [{ ...(draft.chipList?.[0] || {}), [key]: event.target.value }] })} className={inputClass} /></label>)}</div></div>}
        {draft.mode && !submitted && <div className="mt-3 flex justify-end"><button type="button" onClick={submit} className="h-7 px-3 rounded bg-violet-600 text-white text-[10.5px] inline-flex items-center gap-1"><Check size={11} /> 提交 EFA 单</button></div>}
        {submitted && <div className="mt-3 rounded-lg border border-emerald-200 bg-emerald-50 px-2.5 py-2 flex items-center gap-2"><CheckCircle2 size={13} className="text-emerald-600" /><span className="text-[10.5px] font-semibold text-emerald-700">EFA 单已提交，字段已保存并锁定</span><button type="button" onClick={() => setEditing(true)} className="ml-auto h-7 px-2 rounded-md bg-white border border-emerald-200 text-[10px] text-emerald-700 hover:bg-emerald-100 inline-flex items-center gap-1"><Edit2 size={10} /> 编辑</button></div>}
      </div>
    </div>
  );
}

// 添加/编辑分析思路 —— 字段与思维导图「添加分析思路 / 怀疑方向」一致
function ThoughtGroupEditor({ group, onChange, onCancel, onSave }: { group: ThoughtGroup; onChange: (group: ThoughtGroup) => void; onCancel: () => void; onSave: () => void }) {
  const isOther = group.category === "Other" || group.category === "其他";
  const parts = parseThought(group.thought);
  const setPart = (idx: number, value: string) => {
    const next = [...parts] as [string, string, string];
    next[idx] = value;
    onChange({ ...group, thought: composeThought(next) });
  };
  const saveable = isOther ? !!group.thought.trim() : !!(parts[0].trim() && parts[2].trim());
  return (
    <div className="fixed inset-0 z-[80] bg-slate-900/40 flex items-center justify-center" onClick={onCancel}>
      <div className="w-[480px] bg-white rounded-xl border border-slate-200 shadow-2xl p-5" onClick={(event) => event.stopPropagation()}>
        <div className="flex items-center gap-2">
          <Lightbulb size={15} className="text-amber-500" />
          <h3 className="text-sm font-bold text-slate-900">添加分析思路 / 怀疑方向</h3>
          <div className="ml-auto flex items-center gap-2">
            <select value={group.category || "Testing"} onChange={(event) => onChange({ ...group, category: event.target.value })} className="h-7 rounded-full border border-amber-300 bg-amber-50 px-2 text-[11px] text-amber-700 outline-none">
              {THOUGHT_CATEGORIES.map((item) => <option key={item} value={item}>{item}</option>)}
            </select>
            <button onClick={onCancel} className="text-slate-400 hover:text-slate-600"><X size={16} /></button>
          </div>
        </div>
        {isOther ? (
          <div className="mt-4">
            <div className="text-xs font-semibold text-slate-600 mb-1">工作思路 <span className="text-red-500">*</span></div>
            <textarea autoFocus value={group.thought} onChange={(event) => onChange({ ...group, thought: event.target.value })} placeholder="请填写工作思路" className="w-full min-h-[96px] p-2.5 rounded border border-slate-200 outline-none focus:border-amber-500 text-sm resize-y" />
          </div>
        ) : (
          <div className="mt-4 space-y-2.5">
            <div>
              <div className="text-xs font-semibold text-slate-600 mb-1">因为 <span className="text-red-500">*</span></div>
              <input autoFocus value={parts[0]} onChange={(event) => setPart(0, event.target.value)} placeholder="看到什么失效现象，关联以往什么 case" className="w-full h-9 px-2.5 rounded border border-slate-200 outline-none focus:border-amber-500 text-sm" />
            </div>
            <div>
              <div className="text-xs font-semibold text-slate-600 mb-1 inline-flex items-center gap-1.5">原理说明 <span className="text-[10px] font-normal text-slate-400 border border-slate-200 rounded-full px-1.5 leading-4">选填</span></div>
              <input value={parts[1]} onChange={(event) => setPart(1, event.target.value)} placeholder="补充原理内容，可增加 Case 评分" className="w-full h-9 px-2.5 rounded border border-dashed border-slate-300 bg-slate-50 outline-none focus:border-slate-400 focus:bg-white text-sm" />
            </div>
            <div>
              <div className="text-xs font-semibold text-slate-600 mb-1">所以 <span className="text-red-500">*</span></div>
              <input value={parts[2]} onChange={(event) => setPart(2, event.target.value)} placeholder="怀疑和什么有关" className="w-full h-9 px-2.5 rounded border border-slate-200 outline-none focus:border-amber-500 text-sm" />
            </div>
            <div className="text-[10px] text-amber-600/80">「因为」和「所以」必填，原理说明选填</div>
          </div>
        )}
        <div className="mt-5 flex justify-end gap-2">
          <button onClick={onCancel} className="h-8 px-3 rounded border border-slate-200 text-xs text-slate-600">取消</button>
          <button disabled={!saveable} onClick={onSave} className="h-8 px-3 rounded bg-[#0052D9] text-white text-xs disabled:opacity-40 inline-flex items-center gap-1"><Check size={12} /> 保存</button>
        </div>
      </div>
    </div>
  );
}

// 批量导入：顶格为思路，缩进 / 以 - 开头为其上方思路的任务
function BatchImportModal({ onCancel, onImport }: { onCancel: () => void; onImport: (text: string) => void }) {
  const [text, setText] = useState("");
  return (
    <div className="fixed inset-0 z-[80] bg-slate-900/40 flex items-center justify-center" onClick={onCancel}>
      <div className="w-[560px] bg-white rounded-xl border border-slate-200 shadow-2xl p-5" onClick={(event) => event.stopPropagation()}>
        <div className="flex items-center gap-2"><Upload size={15} className="text-[#0052D9]" /><h3 className="text-sm font-bold text-slate-900">批量导入思路与任务</h3><button onClick={onCancel} className="ml-auto text-slate-400 hover:text-slate-600"><X size={16} /></button></div>
        <div className="mt-3 rounded-lg bg-slate-50 border border-slate-200 px-3 py-2 text-[11px] text-slate-500 leading-relaxed">
          每行一条：<b className="text-slate-700">顶格</b>为思路，<b className="text-slate-700">缩进或以 - 开头</b>为其上方思路的任务。示例：
          <div className="mt-1 font-mono text-[10.5px] text-slate-600">CP1 良率异常定位<br />&nbsp;&nbsp;- 复测确认 Pattern 漂移<br />&nbsp;&nbsp;- 边缘 die Shmoo 对比</div>
        </div>
        <textarea autoFocus value={text} onChange={(event) => setText(event.target.value)} placeholder="粘贴或输入多行内容…" className="mt-3 w-full min-h-[180px] p-2.5 rounded border border-slate-200 outline-none focus:border-[#0052D9] text-sm resize-y font-mono" />
        <div className="mt-4 flex justify-end gap-2">
          <button onClick={onCancel} className="h-8 px-3 rounded border border-slate-200 text-xs text-slate-600">取消</button>
          <button disabled={!text.trim()} onClick={() => onImport(text)} className="h-8 px-3 rounded bg-[#0052D9] text-white text-xs disabled:opacity-40 inline-flex items-center gap-1"><Check size={12} /> 导入</button>
        </div>
      </div>
    </div>
  );
}
