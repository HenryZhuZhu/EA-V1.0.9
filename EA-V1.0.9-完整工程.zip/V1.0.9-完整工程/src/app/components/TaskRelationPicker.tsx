import { useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { Check, ChevronDown, Link2, Search, X } from "lucide-react";

export type RelationTask = {
  id: string;
  title: string;
  groupTitle: string;
  owner?: string;
  status?: string;
  conclusion?: string;
  expectation?: string;
  isPatternFanout?: boolean;
  speed?: string;
  tester?: string;
  ballType?: string;
  qg?: string;
  role?: string;
};

type Tab = "recommended" | "grouped" | "selected";

export function TaskRelationPicker({ tasks, value, onChange }: {
  tasks: RelationTask[];
  value: string[];
  onChange: (ids: string[]) => void;
}) {
  const [open, setOpen] = useState(false);
  const [tab, setTab] = useState<Tab>("recommended");
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState("全部");
  const [owner, setOwner] = useState("全部");
  const [draft, setDraft] = useState<string[]>(value);
  const [expandedGroups, setExpandedGroups] = useState<Set<string>>(new Set());
  const [position, setPosition] = useState({ left: 12, top: 12 });
  const buttonRef = useRef<HTMLButtonElement | null>(null);
  const popupRef = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    if (!open) return;
    const closeOnOutside = (event: MouseEvent) => {
      const target = event.target as Node;
      if (!popupRef.current?.contains(target) && !buttonRef.current?.contains(target)) setOpen(false);
    };
    document.addEventListener("mousedown", closeOnOutside);
    return () => document.removeEventListener("mousedown", closeOnOutside);
  }, [open]);
  const owners = useMemo(() => Array.from(new Set(tasks.map((task) => task.owner).filter(Boolean))).sort() as string[], [tasks]);
  const statuses = useMemo(() => Array.from(new Set(tasks.map((task) => task.status).filter(Boolean))) as string[], [tasks]);
  const filtered = useMemo(() => tasks.filter((task) => {
    const haystack = `${task.title} ${task.groupTitle} ${task.owner || ""} ${task.conclusion || ""} ${task.expectation || ""}`.toLowerCase();
    return (!query.trim() || haystack.includes(query.trim().toLowerCase())) && (status === "全部" || task.status === status) && (owner === "全部" || task.owner === owner);
  }), [tasks, query, status, owner]);
  const recommended = useMemo(() => [...filtered].sort((left, right) => {
    const score = (task: RelationTask) => (task.conclusion ? 4 : 0) + (task.status === "已完成" ? 2 : 0) + (task.expectation ? 1 : 0);
    return score(right) - score(left);
  }), [filtered]);
  const grouped = useMemo(() => filtered.reduce<Record<string, RelationTask[]>>((groups, task) => {
    (groups[task.groupTitle || "未分组"] ||= []).push(task);
    return groups;
  }, {}), [filtered]);
  const selectedTasks = tasks.filter((task) => draft.includes(task.id));
  const toggle = (id: string) => setDraft((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);
  const showGroup = (group: string, items: RelationTask[]) => {
    const patternGroup = items.some((task) => task.isPatternFanout);
    const expanded = expandedGroups.has(group) || (!patternGroup && Object.keys(grouped)[0] === group);
    const selectedCount = items.filter((task) => draft.includes(task.id)).length;
    return <div key={group} className="border-b border-slate-100 last:border-0"><button type="button" onClick={() => setExpandedGroups((current) => { const next = new Set(current); next.has(group) ? next.delete(group) : next.add(group); return next; })} className="w-full h-9 px-3 flex items-center gap-2 bg-slate-50 text-left"><ChevronDown size={12} className={`text-slate-400 transition-transform ${expanded ? "" : "-rotate-90"}`} /><span className="min-w-0 flex-1 truncate text-[11px] font-medium text-slate-600">{group}</span><span className="text-[10px] text-slate-400">{selectedCount}/{items.length}</span></button>{expanded && <div>{items.map(renderTask)}</div>}</div>;
  };
  const renderTask = (task: RelationTask) => {
    const checked = draft.includes(task.id);
    const detail = task.conclusion || task.expectation || "暂无预期或结论";
    return <button key={task.id} type="button" onClick={() => toggle(task.id)} className={`w-full px-3 py-2.5 flex items-start gap-2 text-left border-t border-slate-100 first:border-t-0 ${checked ? "bg-blue-50/70" : "bg-white hover:bg-slate-50"}`}><span className={`mt-0.5 w-4 h-4 rounded border grid place-items-center shrink-0 ${checked ? "bg-[#0052D9] border-[#0052D9] text-white" : "border-slate-300"}`}>{checked && <Check size={11} />}</span><span className="min-w-0 flex-1"><span className="flex items-center gap-2"><span className="truncate text-xs font-medium text-slate-800">{task.title}</span><span className="shrink-0 text-[10px] text-slate-400">{task.status || "待创建"} · {task.owner || "待指派"}</span></span><span className="mt-1 block truncate text-[10.5px] text-slate-500">{task.conclusion ? "结论" : "预期"}：{detail}</span></span></button>;
  };

  const openPicker = () => {
    if (open) { setOpen(false); return; }
    setDraft(value);
    const rect = buttonRef.current?.getBoundingClientRect();
    if (rect) {
      const width = 500, height = 440, gap = 6, margin = 12;
      const left = Math.max(margin, Math.min(rect.left, window.innerWidth - width - margin));
      const below = rect.bottom + gap;
      const top = below + height <= window.innerHeight - margin ? below : Math.max(margin, rect.top - height - gap);
      setPosition({ left, top });
    }
    setOpen(true);
  };
  const popup = open && typeof document !== "undefined" ? createPortal(<div ref={popupRef} className="fixed z-[220] w-[500px] h-[440px] rounded-lg border border-slate-200 bg-white shadow-2xl flex flex-col overflow-hidden nodrag nopan nowheel" style={position} onClick={(event) => event.stopPropagation()}>
      <div className="h-11 px-3 border-b border-slate-100 flex items-center"><div className="text-xs font-semibold text-slate-800">关联任务</div><div className="ml-2 text-[10px] text-slate-400">选填 · 可关联 1 个或多个</div><button type="button" onClick={() => setOpen(false)} className="ml-auto w-7 h-7 rounded grid place-items-center text-slate-400 hover:bg-slate-100"><X size={14} /></button></div>
      <div className="p-2.5 border-b border-slate-100 space-y-2">
        <div className="relative"><Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="搜索任务名称、负责人、预期或结论" className="w-full h-8 pl-8 pr-2 rounded border border-slate-200 text-xs outline-none focus:border-[#0052D9]" /></div>
        <div className="flex items-center gap-2"><div className="inline-flex rounded border border-slate-200 bg-slate-50 p-0.5">{([['recommended','推荐'],['grouped','按思路'],['selected',`已选择 ${draft.length}`]] as [Tab,string][]).map(([key,label]) => <button key={key} type="button" onClick={() => setTab(key)} className={`h-6 px-2.5 rounded text-[10.5px] ${tab === key ? "bg-white text-[#0052D9] shadow-sm" : "text-slate-500"}`}>{label}</button>)}</div><select value={status} onChange={(event) => setStatus(event.target.value)} className="ml-auto h-7 px-2 rounded border border-slate-200 bg-white text-[10.5px]"><option value="全部">状态：全部</option>{statuses.map((item) => <option key={item}>{item}</option>)}</select><select value={owner} onChange={(event) => setOwner(event.target.value)} className="h-7 max-w-28 px-2 rounded border border-slate-200 bg-white text-[10.5px]"><option value="全部">负责人：全部</option>{owners.map((item) => <option key={item}>{item}</option>)}</select></div>
      </div>
      <div className="flex-1 min-h-0 overflow-y-auto">{tab === "recommended" ? recommended.map(renderTask) : tab === "grouped" ? Object.entries(grouped).map(([group, items]) => showGroup(group, items)) : selectedTasks.length ? selectedTasks.map(renderTask) : <div className="h-full grid place-items-center text-xs text-slate-400">尚未选择任务</div>}{filtered.length === 0 && tab !== "selected" && <div className="h-full grid place-items-center text-xs text-slate-400">没有符合条件的任务</div>}</div>
      <div className="h-12 px-3 border-t border-slate-100 bg-slate-50 flex items-center"><span className="text-[11px] text-slate-500">已选择 {draft.length} 个任务</span>{draft.length > 0 && <button type="button" onClick={() => setDraft([])} className="ml-2 text-[10.5px] text-slate-400 hover:text-red-500">清空</button>}<button type="button" onClick={() => setOpen(false)} className="ml-auto h-7 px-3 rounded text-xs text-slate-500">取消</button><button type="button" onClick={() => { onChange(draft); setOpen(false); }} className="h-7 px-3 rounded bg-[#0052D9] text-white text-xs">确认关联{draft.length ? ` ${draft.length} 个` : ""}</button></div>
    </div>, document.body) : null;

  return <div className="relative nodrag nopan nowheel">
    <button ref={buttonRef} type="button" onClick={openPicker} className="h-7 px-2 rounded border border-dashed border-[#0052D9]/40 bg-blue-50/50 text-[11px] text-[#0052D9] inline-flex items-center gap-1.5"><Link2 size={12} />关联任务{value.length ? ` · ${value.length}` : ""}</button>
    {popup}
  </div>;
}