import type { ComponentProps } from "react";
import { MyTaskWorkbench } from "./MyTaskWorkbench";
import { RecoveryWorkbench } from "./RecoveryWorkbench";
import { canViewMyReturns, useRecoveryFeedback } from "./recoveryFeedback";

export function MyTaskHub(props: ComponentProps<typeof MyTaskWorkbench>) {
  const { myReturns } = useRecoveryFeedback();
  if (!canViewMyReturns()) return <MyTaskWorkbench {...props} />;
  return <MyTaskWorkbench {...props} recoveryCount={myReturns.length} recoveryPanel={<RecoveryWorkbench embedded onOpen={target => {
    if (target.kind === "case") props.onOpenCase(target.caseId);
    else if (target.kind === "task") props.onOpenTask(target.caseId, target.taskId);
    else props.onOpenStandaloneTask(target.taskId);
  }} />} />;
}