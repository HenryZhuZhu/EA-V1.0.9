import { useState } from "react";
import {
  CheckCircle2,
  XCircle,
  ShieldCheck,
  Clock,
  FileCheck,
  MessageSquare,
  ArrowUpRight,
  Sparkles,
  User,
  AlertTriangle,
} from "lucide-react";
import { levelColors, urgencyColors, Level, Urgency } from "./data";
import { CaseProductPill } from "./CaseProductPill";

type ApprovalKind = "新建 Case" | "升级申请" | "合并 Case";
type ApprovalStatus = "待我审批" | "已通过" | "已驳回" | "已撤回";

interface Approval {
  id: string;
  kind: ApprovalKind;
  status: ApprovalStatus;
  caseCode: string;
  caseName: string;
  product: string;
  level: Level;
  urgency: Urgency;
  applicant: string;
  applicantRole: string;
  department: string;
  submittedAt: string;
  waitHours: number;
  reason: string;
  background: string;
  levelReason: string;
  aiRisk?: string;
  aiSuggestion?: string;
  nextApprover?: string;
  decidedAt?: string;
  decideNote?: string;
}

const mockApprovals: Approval[] = [
  {
    id: "ap1",
    kind: "新建 Case",
    status: "待我审批",
    caseCode: "EA-2604-118",
    caseName: "BX2507 Shmoo VDDmin 异常 · 客户侧量产回溯",
    product: "BX2507",
    level: "L1",
    urgency: "非常紧急",
    applicant: "陈磊",
    applicantRole: "PTE 工程师",
    department: "PTE",
    submittedAt: "2026-04-22 09:12",
    waitHours: 2,
    reason: "客户侧 BX2507 在高温量产端出现 VDDmin 偏移 ≥ 30mV，影响 12 万颗出货",
    background:
      "客户来信反馈 BX2507 产品在终测站点 VDDmin 偏移超规，初步怀疑 PVT 覆盖不足或探针接触。",
    levelReason:
      "影响量产出货 + 客户高优先级 → 按 L1 申请；若 24h 内未定位根因建议升 L0。",
    aiRisk: "历史 3 个月内同产品有 2 起类似 Case（EA-2601-072 / EA-2603-094），存在重复根因可能",
    aiSuggestion: "建议批准。同时提示申请人先与 EA-2601-072 owner 对齐方法论，避免重复建 Case。",
    nextApprover: "钱磊 (PEL)",
  },
  {
    id: "ap2",
    kind: "升级申请",
    status: "待我审批",
    caseCode: "EA-2604-097",
    caseName: "AX5612 Fmax 漂移 · 合封批次追溯",
    product: "AX5612",
    level: "L2",
    urgency: "紧急",
    applicant: "李娜",
    applicantRole: "PTE 工程师",
    department: "PTE",
    submittedAt: "2026-04-22 08:40",
    waitHours: 3,
    reason: "连续 3 个批次 Fmax 下移 > 50MHz，已超出 SPC 上限，影响客户交付节奏",
    background:
      "在 SLT 阶段发现 Fmax 持续下移趋势；初步排查 CP/FT 平台，未见测试站点差异。",
    levelReason: "波及范围从 1 条 line 扩展到 3 条 line → 申请从 L2 升级 L1。",
    aiRisk: "若升级 L1 将锁定 PE / DA / RD 三方 owner，资源成本较高",
    aiSuggestion: "建议批准。SPC 已连续越界 72h，符合 L1 定义。",
  },
  {
    id: "ap3",
    kind: "新建 Case",
    status: "待我审批",
    caseCode: "EA-2604-119",
    caseName: "CY3301 PPM 持续偏高 · 疑似 wafer 空间分布",
    product: "CY3301",
    level: "L2",
    urgency: "一般",
    applicant: "张伟",
    applicantRole: "CP 工程师",
    department: "CP",
    submittedAt: "2026-04-21 16:25",
    waitHours: 19,
    reason: "最近 5 个 lot 平均 PPM 从 120 上升至 360，单 wafer edge die 失效率偏高",
    background:
      "CP 数据显示 edge die yield 下降明显，center 区域稳定；需要 Wafer Map 协同分析。",
    levelReason: "未造成客户退货，但 PPM 超内控红线 → L2。",
    aiSuggestion: "建议批准，并推荐合并到类似 Case EA-2603-088（同产品 edge yield 问题）。",
  },
  {
    id: "ap5",
    kind: "升级申请",
    status: "已驳回",
    caseCode: "EA-2604-056",
    caseName: "EX7721 Bin3 异常 · 单 lot",
    product: "EX7721",
    level: "L3",
    urgency: "一般",
    applicant: "刘洋",
    applicantRole: "PTE 工程师",
    department: "PTE",
    submittedAt: "2026-04-19 11:30",
    waitHours: 0,
    reason: "建议升 L2 获得更多资源",
    background: "当前仅 1 个 lot 出现，未形成趋势。",
    levelReason: "—",
    decidedAt: "2026-04-19 15:20",
    decideNote: "驳回。单 lot 尚未构成 L2 条件，请先完成基础数据收集再申请。",
  },
];

const kindColors: Record<ApprovalKind, string> = {
  "新建 Case": "bg-blue-50 text-blue-600 border-blue-200",
  升级申请: "bg-purple-50 text-purple-600 border-purple-200",
  "合并 Case": "bg-amber-50 text-amber-600 border-amber-200",
};

type Tab = "pending" | "history";

export function MyApprovals({
  onOpenCase,
  onApprove,
}: {
  onOpenCase: (caseCode: string) => void;
  onApprove?: (caseCode: string) => void;
}) {
  const [tab, setTab] = useState<Tab>("pending");
  const [selectedId, setSelectedId] = useState<string | null>(mockApprovals[0].id);
  const [approvals, setApprovals] = useState(mockApprovals);
  const [note, setNote] = useState("");

  const allApprovals = approvals;
  const pending = allApprovals.filter((a) => a.status === "待我审批");
  const history = allApprovals.filter((a) => a.status !== "待我审批");
  const list = tab === "pending" ? pending : history;
  const selected = allApprovals.find((a) => a.id === selectedId) ?? list[0];

  const decide = (decision: "pass" | "reject") => {
    if (!selected) return;
    setApprovals((prev) =>
      prev.map((a) =>
        a.id === selected.id
          ? {
              ...a,
              status: decision === "pass" ? "已通过" : "已驳回",
              decidedAt: "2026-04-22 10:30",
              decideNote: note.trim() || (decision === "pass" ? "同意" : "驳回"),
            }
          : a
      )
    );
    setNote("");
    const nextPending = pending.find((a) => a.id !== selected.id);
    setSelectedId(nextPending?.id ?? null);
  };

  return (
    <div className="relative">
      <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(ellipse_80%_50%_at_0%_0%,rgba(122,61,255,0.05),transparent_60%)]" />

      <div className="relative p-8 space-y-6 max-w-[1400px] mx-auto">
        <header className="flex items-end justify-between">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-xs text-slate-500 tracking-wider uppercase">
              <ShieldCheck size={12} className="text-[#7A3DFF]" />
              Approval Center · 管理者审批台
            </div>
            <h1 className="text-slate-900 tracking-tight">我的审批</h1>
            <p className="text-sm text-slate-500 max-w-xl leading-relaxed">
              Case 建立、升级、关闭、合并均需经对应层级 Manager 审批；AI 提供风险提示与建议。
            </p>
          </div>

          <div className="flex items-center gap-3 bg-white border border-slate-200/80 rounded-xl px-5 py-3 shadow-[0_1px_2px_0_rgba(15,23,42,0.04)]">
            <Stat label="待我审批" value={pending.length} color="#E54545" />
            <span className="w-px h-8 bg-slate-200" />
            <Stat label="本月通过" value={12} color="#00B578" />
            <span className="w-px h-8 bg-slate-200" />
            <Stat label="本月驳回" value={3} color="#64748B" />
            <span className="w-px h-8 bg-slate-200" />
            <Stat label="平均响应" value="1.4h" color="#0052D9" />
          </div>
        </header>

        <div className="grid grid-cols-[380px_1fr] gap-4">
          {/* Left: list */}
          <div className="bg-white border border-slate-200/80 rounded-xl overflow-hidden shadow-[0_1px_2px_0_rgba(15,23,42,0.04)]">
            <div className="flex items-center border-b border-slate-100">
              {[
                { k: "pending" as Tab, label: "待我审批", count: pending.length },
                { k: "history" as Tab, label: "历史记录", count: history.length },
              ].map((t) => {
                const active = tab === t.k;
                return (
                  <button
                    key={t.k}
                    onClick={() => {
                      setTab(t.k);
                      const first =
                        t.k === "pending"
                          ? pending[0]?.id
                          : history[0]?.id;
                      setSelectedId(first ?? null);
                    }}
                    className={`flex-1 py-2.5 text-sm flex items-center justify-center gap-1.5 border-b-2 transition-colors ${
                      active
                        ? "border-[#0052D9] text-[#0052D9]"
                        : "border-transparent text-slate-600 hover:text-slate-900"
                    }`}
                  >
                    {t.label}
                    <span
                      className={`text-[10px] px-1.5 py-0.5 rounded-full ${
                        active ? "bg-[#0052D9] text-white" : "bg-slate-100 text-slate-500"
                      }`}
                    >
                      {t.count}
                    </span>
                  </button>
                );
              })}
            </div>

            <div className="divide-y divide-slate-100 max-h-[640px] overflow-y-auto">
              {list.map((a) => {
                const active = a.id === selected?.id;
                return (
                  <button
                    key={a.id}
                    onClick={() => setSelectedId(a.id)}
                    className={`w-full text-left px-4 py-3 hover:bg-slate-50/80 transition-colors ${
                      active ? "bg-[#0052D9]/5 shadow-[inset_2px_0_0_0_#0052D9]" : ""
                    }`}
                  >
                    <div className="flex items-center gap-1.5 mb-1.5">
                      <span
                        className={`px-1.5 py-0.5 rounded text-[10px] border ${kindColors[a.kind]}`}
                      >
                        {a.kind}
                      </span>
                      <span
                        className={`px-1.5 py-0.5 rounded text-[10px] border ${levelColors[a.level]}`}
                      >
                        {a.level}
                      </span>
                      <CaseProductPill caseItem={a} compact />
                      <span
                        className={`px-1.5 py-0.5 rounded text-[10px] ${urgencyColors[a.urgency]}`}
                      >
                        {a.urgency}
                      </span>
                      <span className="ml-auto text-[10px] text-slate-400 font-mono">
                        {a.caseCode}
                      </span>
                    </div>
                    <div className="text-sm text-slate-800 line-clamp-1">{a.caseName}</div>
                    <div className="mt-1.5 flex items-center gap-2 text-[11px] text-slate-500">
                      <User size={10} />
                      <span>
                        {a.applicant} · {a.department}
                      </span>
                      <span className="ml-auto flex items-center gap-0.5">
                        {a.status === "待我审批" ? (
                          <>
                            <Clock size={10} className={a.waitHours > 6 ? "text-red-500" : ""} />
                            <span className={a.waitHours > 6 ? "text-red-500" : ""}>
                              已等待 {a.waitHours}h
                            </span>
                          </>
                        ) : (
                          <span
                            className={
                              a.status === "已通过" ? "text-emerald-600" : "text-slate-400"
                            }
                          >
                            {a.status}
                          </span>
                        )}
                      </span>
                    </div>
                  </button>
                );
              })}
              {list.length === 0 && (
                <div className="py-16 text-center">
                  <FileCheck size={28} className="mx-auto text-slate-300 mb-2" />
                  <div className="text-sm text-slate-500">暂无{tab === "pending" ? "待审批" : "历史"}记录</div>
                </div>
              )}
            </div>
          </div>

          {/* Right: detail */}
          <div className="bg-white border border-slate-200/80 rounded-xl shadow-[0_1px_2px_0_rgba(15,23,42,0.04)]">
            {selected ? (
              <div className="p-6 space-y-5">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <span
                      className={`px-2 py-0.5 rounded text-xs border ${kindColors[selected.kind]}`}
                    >
                      {selected.kind}
                    </span>
                    <span
                      className={`px-2 py-0.5 rounded text-xs border ${levelColors[selected.level]}`}
                    >
                      {selected.level}
                    </span>
                    <CaseProductPill caseItem={selected} />
                    <span
                      className={`px-2 py-0.5 rounded text-xs ${urgencyColors[selected.urgency]}`}
                    >
                      {selected.urgency}
                    </span>
                    <span className="text-xs text-slate-400 font-mono ml-auto">
                      {selected.caseCode}
                    </span>
                  </div>
                  <h2 className="text-slate-900 leading-snug">{selected.caseName}</h2>
                  <div className="mt-2 flex items-center gap-3 text-xs text-slate-500">
                    <span className="flex items-center gap-1">
                      <User size={11} />
                      {selected.applicant} · {selected.applicantRole}
                    </span>
                    <span>·</span>
                    <span>提交 {selected.submittedAt}</span>
                    {selected.nextApprover && (
                      <>
                        <span>·</span>
                        <span className="text-[#0052D9]">下一审批人：{selected.nextApprover}</span>
                      </>
                    )}
                  </div>
                </div>

                {/* AI assist */}
                {(selected.aiRisk || selected.aiSuggestion) && selected.status === "待我审批" && (
                  <div className="bg-gradient-to-br from-[#0052D9]/5 to-[#7A3DFF]/5 border border-[#7A3DFF]/20 rounded-lg p-3 space-y-2">
                    <div className="flex items-center gap-2">
                      <Sparkles size={12} className="text-[#7A3DFF]" />
                      <span className="text-xs text-slate-700">AI 审批助手</span>
                    </div>
                    {selected.aiRisk && (
                      <div className="flex gap-2 text-xs">
                        <AlertTriangle size={12} className="text-amber-500 mt-0.5 shrink-0" />
                        <div className="text-slate-700 leading-relaxed">
                          <span className="text-amber-600">风险提示：</span>
                          {selected.aiRisk}
                        </div>
                      </div>
                    )}
                    {selected.aiSuggestion && (
                      <div className="flex gap-2 text-xs">
                        <CheckCircle2 size={12} className="text-[#0052D9] mt-0.5 shrink-0" />
                        <div className="text-slate-700 leading-relaxed">
                          <span className="text-[#0052D9]">建议：</span>
                          {selected.aiSuggestion}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Fields */}
                <div className="grid grid-cols-1 gap-3">
                  <Field label="发起事由" value={selected.reason} />
                  <Field label="背景（What & Why）" value={selected.background} />
                  {selected.levelReason !== "—" && (
                    <Field label="级别定义理由" value={selected.levelReason} />
                  )}
                </div>

                {selected.status !== "待我审批" ? (
                  <div
                    className={`rounded-lg p-3 border ${
                      selected.status === "已通过"
                        ? "bg-emerald-50 border-emerald-200"
                        : "bg-slate-50 border-slate-200"
                    }`}
                  >
                    <div className="flex items-center gap-2 text-sm">
                      {selected.status === "已通过" ? (
                        <CheckCircle2 size={14} className="text-emerald-600" />
                      ) : (
                        <XCircle size={14} className="text-slate-500" />
                      )}
                      <span
                        className={
                          selected.status === "已通过"
                            ? "text-emerald-700"
                            : "text-slate-700"
                        }
                      >
                        {selected.status}
                      </span>
                      <span className="text-xs text-slate-500 ml-auto">
                        {selected.decidedAt}
                      </span>
                    </div>
                    {selected.decideNote && (
                      <div className="mt-2 text-xs text-slate-600 leading-relaxed">
                        {selected.decideNote}
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="border-t border-slate-100 pt-4 space-y-3">
                    <div className="relative">
                      <MessageSquare
                        size={12}
                        className="absolute left-3 top-3 text-slate-400"
                      />
                      <textarea
                        value={note}
                        onChange={(e) => setNote(e.target.value)}
                        rows={2}
                        placeholder="审批意见（驳回时必填，通过时可选）"
                        className="w-full pl-8 pr-3 py-2.5 text-sm rounded-md bg-slate-50 border border-slate-200 outline-none focus:bg-white focus:border-[#0052D9] resize-none"
                      />
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => decide("pass")}
                        className="flex-1 h-10 rounded-md bg-gradient-to-r from-[#00B578] to-[#00916A] text-white text-sm hover:shadow-md flex items-center justify-center gap-1.5"
                      >
                        <CheckCircle2 size={14} /> 通过
                      </button>
                      <button
                        onClick={() => decide("reject")}
                        disabled={!note.trim()}
                        className="flex-1 h-10 rounded-md bg-white border border-slate-300 text-slate-700 text-sm hover:border-red-300 hover:text-red-600 disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-1.5"
                      >
                        <XCircle size={14} /> 驳回
                      </button>
                      {onApprove && (
                        <button
                          onClick={() => onApprove(selected.caseCode)}
                          className="h-10 px-3 rounded-md border border-[#7A3DFF]/40 text-[#7A3DFF] text-sm hover:bg-[#7A3DFF]/5 flex items-center gap-1"
                        >
                          复核修改
                        </button>
                      )}
                      <button
                        onClick={() => onOpenCase(selected.caseCode)}
                        className="h-10 px-3 rounded-md border border-slate-200 text-slate-600 text-sm hover:border-[#0052D9] hover:text-[#0052D9] flex items-center gap-1"
                      >
                        查看 Case <ArrowUpRight size={12} />
                      </button>
                    </div>
                    <div className="text-[11px] text-slate-400">
                      · 审批记录将同步至 Case 时间线并通知申请人
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="h-full flex items-center justify-center text-sm text-slate-400">
                选择左侧条目查看详情
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value, color }: { label: string; value: number | string; color: string }) {
  return (
    <div className="flex flex-col items-start">
      <span className="text-[11px] text-slate-500">{label}</span>
      <span className="text-lg tabular-nums" style={{ color }}>
        {value}
      </span>
    </div>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div className="p-3 rounded-md bg-slate-50/60 border border-slate-100">
      <div className="text-xs text-slate-400 mb-1">{label}</div>
      <div className="text-sm text-slate-700 leading-relaxed">{value}</div>
    </div>
  );
}
