import type { TaskNode } from "./data";
import type { ClosureRecord } from "./closures";

const validTimestamp = (value?: string | null) => value && Number.isFinite(Date.parse(value)) ? value : undefined;

export function taskCreationTime(task?: Pick<TaskNode, "createdAt" | "activityLog">) {
  return validTimestamp(task?.createdAt) ?? task?.activityLog?.filter(entry => entry.kind === "create" && validTimestamp(entry.at)).sort((left, right) => Date.parse(left.at) - Date.parse(right.at))[0]?.at;
}

export function formatCaseTime(value?: string) {
  return validTimestamp(value) ? new Date(value!).toLocaleString("zh-CN", { year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hour12: false }) : "未记录";
}

export function taskLifecycleTimes(task: TaskNode, now = new Date()) {
  const createdAt = taskCreationTime(task);
  const history = (task.statusHistory ?? []).filter(entry => validTimestamp(entry.at) && (!createdAt || Date.parse(entry.at) >= Date.parse(createdAt)))
    .slice().sort((left, right) => Date.parse(left.at) - Date.parse(right.at));
  const acceptedAt = history.find(entry => entry.status === "进行中")?.at;
  const latestStart = [...history].reverse().find(entry => entry.status === "进行中")?.at;
  const latestRecovery = task.recovery?.filter(entry => entry.kind !== "supplement" && validTimestamp(entry.at))
    .slice().sort((left, right) => Date.parse(right.at) - Date.parse(left.at))[0]?.at;
  const cycleStart = Math.max(Date.parse(latestStart ?? "") || 0, Date.parse(latestRecovery ?? "") || 0);
  const terminal = ["已完成", "已拒绝", "已中止"].includes(task.status);
  const endedAt = terminal ? [...history].reverse().find(entry => entry.status === task.status && Date.parse(entry.at) >= cycleStart)?.at : undefined;
  const completedAt = task.status === "已完成" ? endedAt : undefined;
  const start = createdAt ?? acceptedAt ?? endedAt;
  const end = terminal ? endedAt ?? latestStart ?? createdAt : now.toISOString();
  const due = task.dueDate || task.requestedDueDate;
  const deadline = due ? new Date(/^\d{4}-\d{2}-\d{2}$/.test(due) ? `${due}T00:00:00` : due) : undefined;
  if (deadline && due?.length === 10) deadline.setDate(deadline.getDate() + 1);
  const overdue = !terminal && Boolean(deadline && Number.isFinite(deadline.getTime()) && now.getTime() >= deadline.getTime());
  const state: "completed" | "overdue" | "active" | "inactive" = task.status === "已完成" ? "completed" : overdue ? "overdue" : task.status === "进行中" ? "active" : "inactive";
  return { createdAt, acceptedAt, completedAt, endedAt, start, end, overdue, state };
}

export function caseVerificationTimes(record?: ClosureRecord) {
  const cycle = [...(record?.recovery ?? [])].reverse().find(entry => entry.kind !== "supplement");
  const legacyStart = validTimestamp(record?.rootCauseAt);
  const start = record?.verificationStartedAt !== undefined ? validTimestamp(record.verificationStartedAt)
    : legacyStart && (!cycle || Date.parse(legacyStart) >= Date.parse(cycle.at)) ? legacyStart : undefined;
  const end = record?.state === "closed" ? validTimestamp(record.verificationEndedAt ?? record.closedAt) : undefined;
  return { start, end };
}