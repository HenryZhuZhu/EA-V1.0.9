import type { TaskNode } from "./data";
import type { ClosureRecord } from "./closures";

const validTimestamp = (value?: string | null) => value && Number.isFinite(Date.parse(value)) ? value : undefined;

export function taskCreationTime(task?: Pick<TaskNode, "createdAt" | "activityLog">) {
  return validTimestamp(task?.createdAt) ?? task?.activityLog?.filter(entry => entry.kind === "create" && validTimestamp(entry.at)).sort((left, right) => Date.parse(left.at) - Date.parse(right.at))[0]?.at;
}

export function formatCaseTime(value?: string) {
  return validTimestamp(value) ? new Date(value!).toLocaleString("zh-CN", { year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hour12: false }) : "未记录";
}

export function caseVerificationTimes(record?: ClosureRecord) {
  const cycle = [...(record?.recovery ?? [])].reverse().find(entry => entry.kind !== "supplement");
  const legacyStart = validTimestamp(record?.rootCauseAt);
  const start = record?.verificationStartedAt !== undefined ? validTimestamp(record.verificationStartedAt)
    : legacyStart && (!cycle || Date.parse(legacyStart) >= Date.parse(cycle.at)) ? legacyStart : undefined;
  const end = record?.state === "closed" ? validTimestamp(record.verificationEndedAt ?? record.closedAt) : undefined;
  return { start, end };
}