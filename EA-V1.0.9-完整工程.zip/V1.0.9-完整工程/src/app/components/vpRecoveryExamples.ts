import type { CaseItem, TaskNode } from "./data";
import type { ClosureRecord } from "./closures";
import type { RecoveryEntry } from "./recordRecovery";

const definitions = [
  { name: "DDR5 低压读写异常验证", owner: "张伟", department: "PTE", collaborator: "周杰", due: "2026-09-25", at: "2026-09-21T09:00:00+08:00", reason: "补齐低压与常压的同批次对照，明确异常可复现的电压边界，并在原文档中说明排除测试环境影响的依据。", before: "异常可能与低压测试条件有关，需进一步确认。" },
  { name: "FT 高温测试误报排查", owner: "赵敏", department: "FT", collaborator: "张伟", due: "2026-09-24", at: "2026-09-19T10:30:00+08:00", started: "2026-09-20T14:20:00+08:00", reason: "区分真实器件失效与测试项误报，补充复测覆盖率、温度稳定时间和治具交叉验证记录。", before: "初步怀疑温度尚未稳定导致误报。", after: "已完成两套治具交叉复测，误报与温度稳定时间有关；剩余批次正在验证。", process: "已比对两套治具，补充稳定等待时间为 30 秒与 60 秒的对照，正在扩展样本批次。" },
  { name: "客户退货批次影响范围复核", owner: "孙楠", department: "QA", collaborator: "赵敏", due: "2026-09-19", at: "2026-09-15T11:00:00+08:00", reason: "不能仅凭单一退货样品判断批次风险。请补充批次追溯、出货范围及在库筛查方案，并明确受影响与不受影响的边界。", before: "已对单个退货样品完成分析，批次影响范围尚不完整。" },
  { name: "EFA 失效位置与电性关联验证", owner: "陈磊", department: "EFA", collaborator: "李娜", due: "2026-09-20", at: "2026-09-16T15:00:00+08:00", started: "2026-09-18T16:10:00+08:00", reason: "补充物理失效位置与电性现象之间的证据链，不能仅以截面图片作为根因结论。明确对照样品及尚未解释的差异。", before: "截面可见异常结构，暂推测与漏电有关。", after: "已定位异常区域并完成两组电性对照，第三组对照样品待补测。", process: "已补录异常点坐标、漏电曲线及正常样品对比，第三组样品仍在准备中。" },
  { name: "CP 漏检条件补充验证", owner: "王芳", department: "CP", collaborator: "周杰", due: "2026-09-22", at: "2026-09-17T09:20:00+08:00", started: "2026-09-19T13:00:00+08:00", submitted: "2026-09-21T10:00:00+08:00", reason: "补齐新增筛查条件的有效性及误杀评估，列出修改前后测试条件，并把结论回写原 Case。", before: "拟增加筛查测试项，尚未验证误杀风险。", after: "已完成正常与异常样品对照：新增条件能够识别目标异常，本组正常对照未出现误杀。适用范围及后续批次观察项已记录。", process: "比较原条件和新增条件，分别复测正常与异常样品；记录各条件结果、例外样品及覆盖边界。" },
  { name: "DA 根因分析与改善方案复核", owner: "李娜", department: "DA", collaborator: "陈磊", due: "2026-09-21", at: "2026-09-16T10:00:00+08:00", started: "2026-09-18T09:00:00+08:00", submitted: "2026-09-20T17:30:00+08:00", reason: "原改善方案缺少验证依据。请补齐方案作用机理、验证结果和适用产品边界，避免把相关性直接当作根因。", before: "方案与失效现象相关，尚缺验证闭环。", after: "已补充机理分析和改善前后对照，确认本示例样品中方案有效；适用产品边界和待扩展条件已写明。", process: "先验证候选根因，再进行改善前后对照；保留未覆盖条件，不对未验证产品做效果推断。" },
];

const collaboratorDepartments: Record<string, string> = { 周杰: "PTE", 张伟: "PTE", 赵敏: "FT", 李娜: "DA", 陈磊: "EFA" };

export const vpRecoveryExamples: { caseItem: CaseItem; closure: ClosureRecord }[] = definitions.map((example, index) => {
  const id = `vp-recovery-example-${index + 1}`;
  const code = `DEMO-VP-260921-${String(index + 1).padStart(2, "0")}`;
  const conclusion = example.after ?? example.before;
  const process = example.process ?? "已有初步排查记录，等待按整改要求补充验证。";
  const completed = Boolean(example.submitted);
  const task: TaskNode = {
    id: `${id}-verify`, code: `${code}.001`, title: "补充对照验证与结论复核", owner: example.owner, supervisor: "林副总", department: example.department,
    urgency: "一般", status: completed ? "已完成" : "进行中", progress: completed ? 100 : example.started ? 50 : 0,
    dueDate: example.due, expectation: example.reason, analysisProcess: example.process ?? "", conclusion: example.after ?? "", attachments: [],
  };
  const caseItem: CaseItem = {
    id, code, name: `${example.name}（整改示例）`, owner: example.owner, createdBy: example.owner,
    participants: [{ name: example.collaborator, department: collaboratorDepartments[example.collaborator] }], level: "L3", urgency: "一般", status: completed ? "已关闭" : "进行中",
    reason: "整改跟进演示案例", background: example.before, impact: "演示验证覆盖边界、证据完整性与原文档回写流程。", levelReason: "本地整改演示",
    product: "演示产品", material: "Die/IC", density: "—", ioType: "—", failStage: "验证", customer: "演示客户", failPlatform: "演示平台", failMode: example.name,
    ppm: "—", pdId: "—", createdAt: "2026-09-14", updatedAt: (example.submitted ?? example.started ?? example.at).slice(0, 10), dueDate: example.due,
    departments: [...new Set([example.department, collaboratorDepartments[example.collaborator]])], tasks: [task], source: "手动", dueIn: Number(example.due.slice(-2)) - 21,
    aiSummary: { progress: completed ? "验证结果已提交" : example.started ? "正在补充验证" : "等待补充验证", method: process, conclusion, solution: "详见原 Case 文档", risk: "仅用于本地流程演示" },
    timeline: [{ time: "2026-09-14 09:00", user: example.owner, content: "创建整改演示案例" }],
  };
  const before = { caseId: id, state: "closed", conclusion: example.before, closedAt: "2026-09-14T17:00:00+08:00", workspace: { conclusion: example.before, process: "原始初步排查，未完成补充验证。", attachments: [] } };
  const after = { caseId: id, state: "closed", conclusion, closedAt: example.submitted, workspace: { conclusion, process, attachments: [] } };
  const entry: RecoveryEntry = {
    id: `${id}-return-1`, kind: "return", by: "林副总", at: example.at, reason: example.reason, recipients: [example.owner], dueDate: example.due, before,
    ...(example.started ? { startedAt: example.started, lastEditedAt: example.started } : {}),
    ...(example.submitted ? { submittedAt: example.submitted, submittedBy: example.owner, completedAt: example.submitted, lastEditedAt: example.submitted, after } : {}),
  };
  return { caseItem, closure: { caseId: id, state: completed ? "closed" : "reopened", conclusion, workspace: { conclusion, process, attachments: [] }, recovery: [entry], ...(example.submitted ? { closedAt: example.submitted, submittedBy: example.owner } : {}) } };
});