import { currentUser, type TaskComment } from "./data";

export interface TaskActivity {
  id: string;
  kind: "create" | "status" | "edit" | "upgrade" | "comment";
  at: string;
  by: string;
  summary: string;
  detail?: string;
  changes: { field: string; before: string; after: string }[];
}

const FIELD_LABELS: Record<string, string> = {
  title: "任务名称", description: "任务说明", expectation: "预期", status: "状态",
  owner: "负责人", supervisor: "分派人", department: "处理部门", handlingDepartment: "处理部门",
  urgency: "紧急程度", dueDate: "完成时间", requestedDueDate: "期望完成时间",
  conclusion: "任务结论", analysisProcess: "分析过程", validity: "结论有效性",
  attachments: "任务附件", resultAttachments: "结果附件", voiceNote: "语音备注",
  rejectReason: "拒绝理由", terminateReason: "中止原因", reworkReason: "退回重做原因", collaborators: "参与人",
  problemDomain: "Domain", problemType: "类型", type: "执行任务类型", involvement: "任务涉及",
  convertedCaseId: "关联 Case", note: "分派附言", site: "站点", skillRun: "Skill 执行结果",
  visibility: "可见范围", creationMode: "分派模式", assignmentMethod: "负责人确定方式",
};

function display(value: unknown, field: string): string {
  if (value == null || value === "") return "未填写";
  if (field === "voiceNote") return "已添加语音";
  if (field === "attachments" || field === "resultAttachments") {
    const files = value as { name: string }[];
    return files.length ? files.map((file) => file.name).join("、") : "无附件";
  }
  if (field === "collaborators") return (value as { name: string; department?: string }[]).map((person) => `${person.name}${person.department ? ` · ${person.department}` : ""}`).join("、") || "无";
  if (field === "involvement") { const ref = value as { kind: string; name?: string }; return ref.kind === "无" ? "无" : `${ref.kind} · ${ref.name ?? ""}`; }
  if (field === "visibility") { const scope = value as { type: string; people: string[] }; return scope.type === "all" ? "全员可见" : `部分人可见 · ${scope.people.join("、")}`; }
  if (field === "creationMode") return value === "advanced" ? "高级查找" : "直接选择";
  if (field === "assignmentMethod") return value === "department" ? "按部门" : "按 Domain + 类型";
  if (field === "skillRun") return (value as { status?: string }).status ?? "执行信息更新";
  return String(value);
}

export function taskChanges(before: object, after: object): TaskActivity["changes"] {
  const old = before as Record<string, unknown>, next = after as Record<string, unknown>;
  return Object.entries(FIELD_LABELS).flatMap(([key, field]) => {
    const normalize = (value: unknown) => value == null || value === "" ? null : Array.isArray(value) && !value.length ? null : value;
    if (JSON.stringify(normalize(old[key])) === JSON.stringify(normalize(next[key]))) return [];
    const from = display(old[key], key), to = display(next[key], key);
    // 比较内容变化，但日志只保存附件名称/语音存在状态，不复制大体积 data URL。
    return [{ field, before: from, after: from === to ? `${to}（内容已更新）` : to }];
  });
}

export function taskActivity(kind: TaskActivity["kind"], summary: string, changes: TaskActivity["changes"] = [], detail?: string, at = new Date().toISOString()): TaskActivity {
  return { id: `activity-${crypto.randomUUID()}`, kind, summary, changes, detail, at, by: currentUser.name };
}

export function mergeTaskActivities(...groups: (TaskActivity[] | undefined)[]): TaskActivity[] {
  return [...new Map(groups.flatMap((group) => group ?? []).map((entry) => [entry.id, entry])).values()];
}

export function recordTaskChange<T extends { activityLog?: TaskActivity[] }>(before: T, after: T, kind?: TaskActivity["kind"], summary?: string, detail?: string): T {
  const changes = taskChanges(before, after);
  if (!changes.length) return before;
  const rework = changes.some((change) => change.field === "状态" && change.before === "已完成" && change.after === "进行中");
  const event = taskActivity(kind ?? (changes.some((change) => change.field === "状态") ? "status" : "edit"), summary ?? (rework ? "退回重做" : changes.some((change) => change.field === "状态") ? "任务状态变更" : "修改任务信息"), changes, detail ?? (rework ? (after as { reworkReason?: string }).reworkReason : undefined));
  return { ...after, activityLog: [...mergeTaskActivities(before.activityLog, after.activityLog), event] };
}

export const TASK_COMMENT_LIMIT = 2000;
export function addTaskComment(comments: TaskComment[] | undefined, content: string, replyTo?: string): TaskComment[] {
  const text = content.trim();
  if (!text) throw new Error("请输入评论内容。");
  if (text.length > TASK_COMMENT_LIMIT) throw new Error(`评论最多 ${TASK_COMMENT_LIMIT} 字。`);
  const message = { id: `comment-${crypto.randomUUID()}`, user: currentUser.name, time: new Date().toISOString(), content: text };
  const previous = comments ?? [];
  if (!replyTo) return [...previous, { ...message, replies: [] }];
  if (!previous.some((comment) => comment.id === replyTo)) throw new Error("回复的评论不存在，请刷新后重试。");
  return previous.map((comment) => comment.id === replyTo ? { ...comment, replies: [...(comment.replies ?? []), message] } : comment);
}

export function cloneTaskComments(comments: TaskComment[] | undefined): TaskComment[] {
  return (comments ?? []).map((comment) => ({ ...comment, replies: comment.replies?.map((reply) => ({ ...reply })) }));
}

export function mergeTaskComments(previous: TaskComment[] | undefined, incoming: TaskComment[] | undefined): TaskComment[] {
  const merged = new Map((previous ?? []).map((comment) => [comment.id, comment]));
  for (const comment of incoming ?? []) {
    const old = merged.get(comment.id);
    merged.set(comment.id, old ? { ...old, replies: [...new Map([...(old.replies ?? []), ...(comment.replies ?? [])].map((reply) => [reply.id, reply])).values()] } : comment);
  }
  return cloneTaskComments([...merged.values()]);
}

export function cloneTaskActivities(activities: TaskActivity[] | undefined): TaskActivity[] {
  return (activities ?? []).map((entry) => ({ ...entry, changes: entry.changes.map((change) => ({ ...change })) }));
}