import { ChevronDown, Filter, X } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";
import { TaskReferenceFilter } from "./TaskReferenceFilter";
import type { CaseItem } from "./data";
import type { BusinessReference } from "./taskWorkbenchModel";
import { TASK_REFERENCE_FIELDS, taskColumnFilterCount, type TaskColumnFilters } from "./taskWorkbenchState";

type FilterPatch = Partial<Pick<TaskColumnFilters, "productKey" | "caseId" | "creator">>;
const chevron = { backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%2394a3b8' stroke-width='2'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E\")", backgroundRepeat: "no-repeat", backgroundPosition: "right 6px center" };

function SelectFilter({ label, ariaLabel, value, options, onChange }: { label: string; ariaLabel: string; value: string; options: { value: string; label: string }[]; onChange: (value: string) => void }) {
  return <label className={`inline-flex h-8 min-w-0 items-center gap-1 rounded-lg border pl-2.5 pr-0.5 text-xs transition-colors ${value ? "border-[#0052D9]/40 bg-[#0052D9]/5" : "border-slate-200 bg-white"}`}>
    <span className={`shrink-0 ${value ? "text-[#0052D9]/70" : "text-slate-400"}`}>{label}</span>
    <select aria-label={ariaLabel} value={value} onChange={event => onChange(event.target.value)} className={`h-7 min-w-0 flex-1 cursor-pointer appearance-none bg-transparent pl-1 pr-5 text-xs outline-none ${value ? "font-medium text-[#0052D9]" : "text-slate-700"}`} style={chevron}>
      <option value="">全部</option>{value && !options.some(o => o.value === value) && <option value={value}>已选值（当前范围无任务）</option>}
      {options.map(option => <option key={option.value} value={option.value}>{option.label}</option>)}
      {!options.length && <option value="__empty" disabled>暂无可选项</option>}
    </select>
  </label>;
}

// 复用分析中心全部 Case 的白底筛选浮层视觉；仅保留任务自身的筛选维度。
export function TaskWorkbenchFilters({ filters, businessOptions, caseOptions, creators, open, onOpenChange, onChange, onReset }: {
  filters: TaskColumnFilters; businessOptions: BusinessReference[]; caseOptions: CaseItem[]; creators: string[];
  open: boolean; onOpenChange: (value: boolean) => void; onChange: (patch: FilterPatch) => void; onReset: () => void;
}) {
  const count = taskColumnFilterCount(filters);
  return <Popover open={open} onOpenChange={onOpenChange}>
    <PopoverTrigger asChild>
      <button type="button" aria-label={count ? `筛选 ${count}` : "筛选"} className={`inline-flex h-9 items-center gap-1.5 rounded-lg border px-3 text-sm transition-colors focus-visible:outline-2 focus-visible:outline-[#0052D9]/40 ${open || count ? "border-[#0052D9]/40 bg-[#0052D9]/5 text-[#0052D9]" : "border-slate-200 bg-white text-slate-600 hover:border-slate-300"}`}>
        <Filter size={13} />筛选{count > 0 && <span className="inline-flex h-4 min-w-[16px] items-center justify-center rounded-full bg-[#0052D9] px-1 text-[10px] tabular-nums text-white">{count}</span>}<ChevronDown size={13} className={open ? "rotate-180" : ""} />
      </button>
    </PopoverTrigger>
    <PopoverContent align="end" sideOffset={8} aria-label="任务筛选条件" className="z-40 w-[480px] max-w-[88vw] rounded-xl border-slate-200 bg-white p-4 shadow-[0_16px_40px_-12px_rgba(15,23,42,0.25)]">
      <p className="mb-2 text-[11px] text-slate-400">筛选维度</p>
      <div className="space-y-3.5">
        <div className="grid grid-cols-2 gap-2">
          {TASK_REFERENCE_FIELDS.map(field => <TaskReferenceFilter key={field.key} kind={field.kind} value={filters[field.key] || ""} options={businessOptions} onChange={value => onChange({ [field.key]: value })} />)}
          <SelectFilter label="所属 Case" ariaLabel="所属 Case（仅左栏）" value={filters.caseId} options={caseOptions.map(c => ({ value: c.id, label: `${c.code} · ${c.name}` }))} onChange={caseId => onChange({ caseId })} />
          <SelectFilter label="创建 / 分派人" ariaLabel="创建或分派人" value={filters.creator} options={creators.map(name => ({ value: name, label: name }))} onChange={creator => onChange({ creator })} />
        </div>
        <p className="text-[11px] text-slate-400">所属 Case 仅筛选左栏，其他条件同时作用于两栏。</p>
      </div>
      <div className="mt-4 flex items-center justify-between border-t border-slate-100 pt-3">
        <button type="button" onClick={onReset} className="inline-flex h-8 items-center gap-1 rounded-lg px-3 text-xs text-slate-500 hover:text-[#0052D9]"><X size={12} />重置全部</button>
        <button type="button" onClick={() => onOpenChange(false)} className="h-8 rounded-lg bg-[#0052D9] px-4 text-xs text-white hover:bg-[#003FA8]">完成</button>
      </div>
    </PopoverContent>
  </Popover>;
}