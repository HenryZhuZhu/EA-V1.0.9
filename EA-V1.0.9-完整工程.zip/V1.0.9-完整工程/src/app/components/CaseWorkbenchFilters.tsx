import { ChevronDown, Filter } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";
import { caseFilterOptions } from "./CaseFilterFields";
import { CaseFilterPanel, CASE_FILTER_PANEL_CLASS_NAME } from "./CaseFilterPanel";
import type { CaseCustomFilterEditorProps } from "./CaseCustomFilterEditor";
import { activeCustomRules, customSelectionRules } from "./caseCustomFilters";
import type { CaseItem } from "./data";
import { CASE_WORKBENCH_STATUSES, caseWorkbenchFilterCount, type CaseWorkbenchFilters as Filters, type CaseWorkbenchStatus } from "./caseWorkbenchModel";

export function CaseWorkbenchFilters({ cases, filters, status, fanout = false, showStatus = true, customEditor, open, onOpenChange, onChange, onStatusChange, onReset }: {
  cases: CaseItem[]; filters: Filters; status: CaseWorkbenchStatus | "全部"; open: boolean;
  fanout?: boolean; customEditor?: CaseCustomFilterEditorProps;
  showStatus?: boolean;
  onOpenChange: (open: boolean) => void; onChange: (patch: Partial<Filters>) => void;
  onStatusChange: (status: CaseWorkbenchStatus | "全部") => void; onReset: () => void;
}) {
  const count = caseWorkbenchFilterCount(filters) + (customEditor ? activeCustomRules(customSelectionRules(customEditor.rules), customEditor.fields).length : 0) + Number(fanout && status !== "全部");
  const options = caseFilterOptions(cases);
  return <Popover open={open} onOpenChange={onOpenChange}>
    <PopoverTrigger asChild>
      <button type="button" aria-label={count ? `筛选 ${count}` : "筛选"} className={`inline-flex h-8 shrink-0 items-center gap-1 rounded-lg border px-2.5 text-xs transition-colors focus-visible:outline-2 focus-visible:outline-[#0052D9]/40 ${open || count ? "border-[#0052D9]/40 bg-[#0052D9]/5 text-[#0052D9]" : "border-slate-200 bg-white text-slate-600 hover:border-slate-300"}`}>
        <Filter size={12} />筛选{count > 0 && <span className="inline-flex h-4 min-w-[16px] items-center justify-center rounded-full bg-[#0052D9] px-1 text-[10px] tabular-nums text-white">{count}</span>}<ChevronDown size={12} className={`transition-transform ${open ? "rotate-180" : ""}`} />
      </button>
    </PopoverTrigger>
    <PopoverContent align="end" sideOffset={8} aria-label="Case 筛选条件" className={CASE_FILTER_PANEL_CLASS_NAME}>
      <CaseFilterPanel values={{ level: filters.level || "全部", urgency: filters.urgency || "全部", product: filters.product || "全部", department: filters.department || "全部", creator: filters.creator || "全部", status }} products={options.products} departments={options.departments} creators={options.creators} statusOptions={fanout ? ["全部", ...CASE_WORKBENCH_STATUSES] : CASE_WORKBENCH_STATUSES} showStatus={showStatus} onChange={(field, value) => {
        if (field === "status") {
          if (fanout && value === "全部") onStatusChange("全部");
          else if (CASE_WORKBENCH_STATUSES.includes(value as CaseWorkbenchStatus)) onStatusChange(value as CaseWorkbenchStatus);
        } else onChange({ [field]: value });
      }} customEditor={customEditor} onReset={onReset} onDone={() => onOpenChange(false)} />
    </PopoverContent>
  </Popover>;
}