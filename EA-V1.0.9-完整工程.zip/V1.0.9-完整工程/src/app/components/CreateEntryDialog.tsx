import { useRef, useState } from "react";
import * as Dialog from "@radix-ui/react-dialog";
import { GitBranch, ListTodo, Plus, X } from "lucide-react";

export function CreateEntryDialog({ onCreateCase, onCreateTask, onOpen }: {
  onCreateCase: () => void;
  onCreateTask: () => void;
  onOpen?: () => void;
}) {
  const [open, setOpen] = useState(false);
  const navigating = useRef(false);
  const choose = (action: () => void) => {
    if (navigating.current) return;
    navigating.current = true;
    setOpen(false);
    action();
  };

  return <Dialog.Root open={open} onOpenChange={(next) => {
    if (next) { navigating.current = false; onOpen?.(); }
    setOpen(next);
  }}>
    <Dialog.Trigger asChild>
      <button type="button" className="inline-flex h-8 shrink-0 items-center gap-1.5 rounded-md bg-gradient-to-r from-[#0052D9] to-[#003FA8] px-3 text-sm text-white hover:shadow-md focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0052D9]/40">
        <Plus size={14} />新建
      </button>
    </Dialog.Trigger>
    <Dialog.Portal>
      <Dialog.Overlay className="fixed inset-0 z-[100] bg-slate-900/35 backdrop-blur-[2px]" />
      <Dialog.Content aria-describedby={undefined} onCloseAutoFocus={(event) => {
        // 进入创建页时保留其初始字段焦点；仅取消弹窗时由 Radix 恢复触发按钮焦点。
        if (navigating.current) event.preventDefault();
      }} className="fixed left-1/2 top-1/2 z-[101] w-[800px] max-h-[90vh] -translate-x-1/2 -translate-y-1/2 overflow-y-auto rounded-2xl border border-slate-200 bg-white p-7 shadow-[0_24px_80px_-20px_rgba(15,23,42,0.3)] outline-none">
        <div className="mb-6 pr-10">
          <Dialog.Title className="text-xl font-semibold text-slate-900">新建</Dialog.Title>
        </div>
        <div className="grid grid-cols-2 gap-4">
          {[
            { label: "Case", description: "需要找根因，弄清问题出在哪", guidance: ["不只看结果，还要和团队一起拆分方向、逐一验证，弄清为什么。", "沉淀根因和改善方案，并 Fanout 到其他产品。"], examples: ["排查某产品测试良率下降原因", "分析客户反馈的功能失效问题", "定位兼容性问题并验证改善方案"], Icon: GitBranch, action: onCreateCase },
            { label: "自由任务", description: "按流程或要求，把事做完", guidance: ["要做什么、怎么做都比较明确", "可以独立处理日常维护、更新或具体待办。"], examples: ["快速简单的日常任务", "有清晰流程的固定任务", "会议后的待办 Todo"], Icon: ListTodo, action: onCreateTask },
          ].map(({ label, description, guidance, examples, Icon, action }) => <button key={label} type="button" aria-label={label} aria-describedby={Icon === GitBranch ? "create-case-examples" : "create-task-examples"} onClick={() => choose(action)} className="group flex min-w-0 flex-col items-start rounded-lg border border-slate-200 bg-white p-5 text-left transition-[border-color,box-shadow,background-color] hover:border-[#0052D9]/40 hover:bg-blue-50/30 hover:shadow-[0_8px_24px_-12px_rgba(0,82,217,0.25)] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0052D9]/40">
            <span className="mb-2 flex items-center gap-3"><span className="grid h-11 w-11 place-items-center rounded-lg bg-[#0052D9]/8 text-[#0052D9]"><Icon size={24} /></span><span className="text-2xl font-semibold text-slate-800 group-hover:text-[#0052D9]">{label}</span></span>
            <span className="mt-2 text-[13px] font-medium leading-relaxed text-slate-700">{description}</span>
            <span role="list" aria-label={`${label}适用情况`} className="mb-5 mt-3 block flex-1 space-y-2">
              {guidance.map(item => <span key={item} role="listitem" className="flex items-start gap-2 text-xs font-normal leading-relaxed text-slate-500"><span aria-hidden="true" className="mt-[7px] h-1 w-1 shrink-0 rounded-full bg-slate-300" />{item}</span>)}
            </span>
            <span id={Icon === GitBranch ? "create-case-examples" : "create-task-examples"} className="block w-full border-t border-slate-100 pt-3 text-left font-normal">
              <span className="mb-2 block text-[10px] text-slate-400">例如</span>
              <span role="list" className="block space-y-2">
                {examples.map((example, index) => <span key={example} role="listitem" className="flex items-start gap-2 text-xs leading-relaxed text-slate-600"><span aria-hidden="true" className="shrink-0 text-slate-400">{index + 1}.</span>{example}</span>)}
              </span>
            </span>
          </button>)}
        </div>
        <Dialog.Close aria-label="关闭新建弹窗" className="absolute right-5 top-5 grid h-8 w-8 place-items-center rounded-lg text-slate-400 hover:bg-slate-100 hover:text-slate-600 focus-visible:outline-2 focus-visible:outline-[#0052D9]/40"><X size={18} /></Dialog.Close>
      </Dialog.Content>
    </Dialog.Portal>
  </Dialog.Root>;
}