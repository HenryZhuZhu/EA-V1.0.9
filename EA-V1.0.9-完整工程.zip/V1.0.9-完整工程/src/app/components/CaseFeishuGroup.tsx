import { useState } from "react";
import { MessageSquarePlus, UsersRound, LogIn, RefreshCw } from "lucide-react";
import { currentUser } from "./data";
import { caseGroupCandidates, updateDemoCaseGroup, useCaseGroup } from "./caseFeishuGroups";
import { TaskDialog } from "./TaskDialog";

export function CaseFeishuGroup({ caseId, owner, code }: { caseId: string; owner: string; code: string }) {
  const group = useCaseGroup(caseId);
  const [open, setOpen] = useState(false); const [error, setError] = useState(""); const [failName, setFailName] = useState("");
  const people = caseGroupCandidates(caseId);
  const isOwner = currentUser.name === owner;
  const isParticipant = people.some(person => person.name === currentUser.name);
  const joined = group?.members.includes(currentUser.name);
  const missing = people.filter(person => !group?.members.includes(person.name));
  const label = !group ? "创建飞书群" : joined ? "打开群聊" : "加入群聊";
  const disabled = !group ? !isOwner : !joined && !isParticipant;
  const apply = (action: "create" | "join" | "sync") => {
    try { updateDemoCaseGroup(caseId, action, failName ? [failName] : []); setError(""); }
    catch (cause) { setError(cause instanceof Error ? cause.message : "操作失败，请重试"); }
  };
  return <section aria-label="Case 飞书群" className="flex flex-wrap items-center justify-between gap-2 py-1">
    <span className="text-slate-400">飞书群</span><div className="flex flex-wrap justify-end gap-1"><button type="button" disabled={disabled} title={disabled ? !group ? "请由 Case Owner 创建群" : "仅当前参与者可以加入" : "飞书群交互演示"} className="inline-flex h-7 items-center gap-1 rounded-md border border-blue-200 bg-blue-50/50 px-2 text-[11px] text-[#0052D9] disabled:opacity-40" onClick={() => { setOpen(true); setError(""); setFailName(""); }}><MessageSquarePlus size={12} />{label}</button>{group && isOwner && missing.length > 0 && <button className="inline-flex h-7 items-center gap-1 rounded-md border border-slate-200 px-2 text-[11px] text-slate-500" onClick={() => { setOpen(true); setError(""); setFailName(""); }}><UsersRound size={12} />同步参与人</button>}</div>
    {open && <TaskDialog title="飞书群 · 本地演示" description="尚未连接飞书，以下仅保存原型群组及成员状态，不会实际建群或发送邀请。" onClose={() => setOpen(false)} footer={<><button className="h-8 rounded border border-slate-200 px-3 text-xs" onClick={() => setOpen(false)}>关闭</button>{!group && isOwner && <button className="inline-flex h-8 items-center gap-1 rounded bg-[#0052D9] px-3 text-xs text-white" onClick={() => apply("create")}><MessageSquarePlus size={13} />模拟创建群组</button>}{group && isParticipant && !joined && <button className="inline-flex h-8 items-center gap-1 rounded bg-[#0052D9] px-3 text-xs text-white" onClick={() => apply("join")}><LogIn size={13} />模拟加入群聊</button>}{group && isOwner && missing.length > 0 && <button className="inline-flex h-8 items-center gap-1 rounded bg-[#0052D9] px-3 text-xs text-white" onClick={() => apply("sync")}><RefreshCw size={13} />{group.failed.length ? "重试未加入人员" : "模拟同步参与人"}</button>}</>}>
      <h3 className="text-sm font-semibold text-slate-800">{group?.name ?? `${code} · Case 协作群`}</h3><p className="mt-1 text-[11px] text-slate-400">{group ? `演示群组 · 已加入 ${group.members.length} 人 · 当前参与人 ${people.length} 人` : `拟邀请 ${people.length} 人`}</p>
      {group && joined && <div role="status" className="mt-3 border-l-2 border-blue-300 pl-3 text-xs text-slate-500">你已加入该演示群组。原 Case 文档仍是结果保存位置。</div>}
      <ul className="mt-4 max-h-[300px] divide-y divide-slate-100 overflow-y-auto">{[...new Set([...people.map(person => person.name), ...(group?.members ?? [])])].map(name => {
        const person = people.find(person => person.name === name); const failed = group?.failed.includes(name);
        return <li key={name} className="flex items-center gap-3 py-2 text-xs"><span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-blue-50 text-[10px] text-blue-600">{name.slice(-2)}</span><span className="flex-1 text-slate-700">{name}<small className="ml-2 text-[10px] text-slate-400">{name === owner ? "Owner" : person?.department ?? "原群成员"}</small></span><span className={failed ? "text-red-600" : "text-slate-400"}>{group?.members.includes(name) ? "已加入（演示）" : failed ? "邀请失败（演示）" : "待加入"}</span></li>;
      })}</ul>
      {group?.failed.length ? <p role="status" className="mt-3 text-xs text-amber-700">{group.failed.length} 人未加入：{group.failed.join("、")}。未映射账号需先在正式系统补齐映射。</p> : null}
      <details className="mt-4 border-t border-slate-100 pt-3 text-xs text-slate-400"><summary className="cursor-pointer">演示失败情形</summary><label className="mt-2 flex items-center gap-2">模拟邀请失败<select aria-label="模拟邀请失败人员" value={failName} onChange={event => setFailName(event.target.value)} className="h-8 rounded border border-slate-200 bg-white px-2 text-xs text-slate-600"><option value="">无</option>{people.filter(person => person.name !== owner && !group?.members.includes(person.name)).map(person => <option key={person.name}>{person.name}</option>)}</select></label></details>
      {error && <p role="alert" className="mt-3 text-xs text-red-600">{error}</p>}
    </TaskDialog>}
  </section>;
}