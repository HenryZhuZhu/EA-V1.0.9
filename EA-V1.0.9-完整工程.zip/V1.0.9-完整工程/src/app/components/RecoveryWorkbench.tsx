import { useEffect, useRef, useState } from "react";
import { CalendarClock, CircleCheck, Layers, Search, Settings2 } from "lucide-react";
import { canViewMyReturns, feedbackSummary, feedbackToken, markFeedbackRead, recoveryAlerts, recoveryOverview, recoveryProgress, setReminderPolicy, useRecoveryFeedback, type FeedbackRow, type RecoveryTarget } from "./recoveryFeedback";
import { recoverCase, getClosure } from "./closures";
import { recoverCaseTask, caseTaskReadOnlyReason } from "./caseTaskTrees";
import { RecoveryActions } from "./RecoveryControls";
import { TaskDialog } from "./TaskDialog";

export function RecoveryWorkbench({ onOpen, embedded = false }: { onOpen: (target: RecoveryTarget) => void; embedded?: boolean }) {
  const { myReturns, policy } = useRecoveryFeedback();
  const [filter, setFilter] = useState("all"); const [query, setQuery] = useState("");
  const [settings, setSettings] = useState(false); const [draft, setDraft] = useState(policy); const [error, setError] = useState("");
  const scroller = useRef<HTMLDivElement>(null);
  useEffect(() => { if (scroller.current) scroller.current.scrollTop = 0; }, [filter, query]);
  if (!canViewMyReturns()) return <div className="p-8 text-sm text-slate-500">当前身份无监管权限。</div>;
  const { rows, groups, counts } = recoveryOverview(myReturns, policy, query);
  const ordered = filter === "following" ? groups.following : filter === "feedback" ? groups.feedback : filter === "overdue" ? groups.overdue : rows;
  const choose = (value: string) => setFilter(previous => previous === value ? "all" : value);
  const openRecord = (row: FeedbackRow) => { try { markFeedbackRead(row); setError(""); onOpen(row.target); } catch (cause) { setError(cause instanceof Error ? cause.message : "打开失败，请重试。"); } };
  return <div className={`flex h-full min-h-0 flex-col gap-5 ${embedded ? "" : "mx-auto max-w-[1400px] px-8 py-6"}`}>
    {!embedded && <h1 className="shrink-0 text-xl font-semibold text-slate-900">我发起的整改</h1>}
    <section aria-label="整改概览" className="grid shrink-0 grid-cols-3 gap-3">
      {[
        { key: "following", label: "跟进中", count: counts.following, hint: "未超期，等待反馈", accent: "#0D9488", bg: "#f1faf8" },
        { key: "feedback", label: "已提交反馈", count: counts.feedback, hint: "包含已读与未读反馈", accent: "#0052D9", bg: "#f5f8ff" },
        { key: "overdue", label: "超期未反馈", count: counts.overdue, hint: "已过期望日期", accent: "#D97706", bg: "#fffbeb" },
      ].map(item => {
        const pressed = filter === item.key;
        return <button key={item.key} type="button" aria-label={`${item.label} ${item.count} 件`} aria-pressed={pressed} aria-controls="recovery-results" onClick={() => choose(item.key)}
          className={`relative overflow-hidden rounded-xl border bg-white px-[18px] pt-[15px] pb-[14px] text-left transition-all focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0052D9]/40 ${pressed ? "" : "border-slate-200 hover:border-slate-300"}`}
          style={pressed ? { borderColor: item.accent, background: item.bg, boxShadow: `0 8px 20px -14px ${item.accent}` } : undefined}>
          <span aria-hidden="true" className="absolute left-0 right-0 top-0 h-[3px] origin-left transition-transform" style={{ background: item.accent, transform: pressed ? "scaleX(1)" : "scaleX(0)" }} />
          <div className="text-xs tracking-wide" style={{ color: pressed ? item.accent : "#64748b", fontWeight: pressed ? 600 : 400 }}>{item.label}</div>
          <div className="mt-2.5 text-[32px] font-bold leading-none tabular-nums" style={{ color: pressed ? item.accent : "#0f172a" }}>{item.count}<span className="ml-1 text-xs font-normal text-slate-400">件</span></div>
          <div className="mt-2 flex items-center gap-1.5 text-[11px] text-slate-400"><span aria-hidden="true" className="h-[5px] w-[5px] rounded-full" style={{ background: item.accent, opacity: pressed ? 1 : 0.55 }} />{item.hint}</div>
        </button>;
      })}
    </section>
    <div className="flex shrink-0 flex-wrap items-center gap-3">
      <span className="text-[11px] text-slate-400">共 {ordered.length} 条</span>
      <label className="ml-auto flex h-8 w-[260px] items-center gap-2 rounded-md border border-slate-200 bg-white px-2"><Search size={13} className="text-slate-400" /><input aria-label="搜索整改记录" placeholder="名称、负责人、修改要求" value={query} onChange={event => setQuery(event.target.value)} className="min-w-0 flex-1 text-xs outline-none" /></label>
      <button title="提醒设置" aria-label="提醒设置" className="grid h-8 w-8 shrink-0 place-items-center rounded-md border border-slate-200 bg-white text-slate-500 hover:text-[#0052D9]" onClick={() => { setDraft(policy); setSettings(true); setError(""); }}><Settings2 size={14} /></button>
    </div>
    {error && !settings && <p role="alert" className="shrink-0 text-xs text-red-600">{error}</p>}
    <section id="recovery-results" aria-label="我发起的整改清单" className="flex min-h-0 flex-1 flex-col">
        <section aria-label="整改列表" className="flex min-h-0 min-w-0 flex-1 flex-col overflow-hidden rounded-xl border border-slate-200/80 bg-slate-50/60">
          <header className="flex h-12 shrink-0 items-center gap-2 border-b border-slate-200/70 bg-white px-4"><Layers size={15} className="text-slate-500" /><h2 className="text-[13px] font-semibold text-slate-700">整改列表</h2><span className="rounded-full bg-slate-100 px-2 py-0.5 text-[10px] tabular-nums text-slate-500">{ordered.length}</span></header>
          <div ref={scroller} role="region" aria-label="整改列表滚动列表" tabIndex={0} className="min-h-0 flex-1 overflow-y-auto overscroll-contain p-3 outline-none [scrollbar-gutter:stable] focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-[#0052D9]/30">
            <div className="grid grid-cols-2 gap-3">{ordered.map(row => <article key={row.key} aria-label={row.title} className="flex h-[224px] min-w-0 flex-col gap-1 rounded-lg border border-slate-200 bg-white px-3 py-2.5 text-xs">
              <div className="flex h-8 shrink-0 items-start gap-2"><button title={row.title} onClick={() => openRecord(row)} className="line-clamp-2 min-w-0 flex-1 break-words text-left font-medium leading-4 text-slate-800 hover:text-[#0052D9]">{row.title}</button><span className={`shrink-0 text-[10px] leading-4 ${feedbackToken(row) ? "text-blue-600" : "text-slate-500"}`}>{recoveryProgress(row)}</span></div>
              <div className="flex h-4 shrink-0 items-center gap-2 text-[10px] text-slate-400"><span className="shrink-0">{row.target.kind === "case" ? "Case" : "Case 任务"}</span><span title={row.code} className="min-w-0 truncate font-mono">{row.code}</span><span title={row.owner} className="ml-auto max-w-[40%] truncate text-slate-500">{row.owner}</span></div>
              <div className="h-8 shrink-0 border-l-2 border-slate-200 pl-2"><p className="line-clamp-2 whitespace-pre-wrap break-words leading-4 text-slate-600">{row.entry.reason}</p></div>
              <div className="flex h-4 shrink-0 items-center gap-3 text-[10px] text-slate-400"><span className="shrink-0">退回于 {new Date(row.entry.at).toLocaleDateString("zh-CN")}</span><span title={new Date(row.entry.lastEditedAt ?? row.entry.at).toLocaleString("zh-CN")} className="min-w-0 truncate">最近更新 {new Date(row.entry.lastEditedAt ?? row.entry.at).toLocaleString("zh-CN")}</span></div>
              <div className="h-8 shrink-0 text-[10px] leading-4"><div className="flex flex-wrap items-center gap-x-3"><span className="inline-flex items-center gap-1 text-slate-500"><CalendarClock size={11} />{row.entry.dueDate ? `期望反馈 ${row.entry.dueDate}` : "未设置反馈日期"}</span>{recoveryAlerts(row, policy).map(alert => <span key={alert.label} className={alert.level === "warning" ? "text-red-600" : "text-amber-700"}>{alert.label}</span>)}</div></div>
              <p title={feedbackToken(row) ? feedbackSummary(row) : undefined} className="h-4 shrink-0 truncate text-[11px] leading-4 text-slate-500">{feedbackToken(row) ? feedbackSummary(row) : ""}</p>
              <div data-recovery-actions className="mt-auto flex h-7 shrink-0 items-center justify-end gap-2">
                <RecoveryActions record={row.record} owner={row.owner} title={row.title} completed={row.target.kind === "case" ? row.status === "已关闭" || row.status === "已结案" : row.status === "已完成"} active={row.status === "进行中" || row.status === "验证中"} parentClosed={row.target.kind === "task" && Boolean(caseTaskReadOnlyReason(row.target.caseId))} blocked={row.target.kind === "case" && getClosure(row.target.caseId)?.approval && !getClosure(row.target.caseId)?.approval?.decision ? "结案审批处理中" : undefined} onAction={(action, text, files, dueDate) => { if (row.target.kind === "case") recoverCase(row.target.caseId, action, text, files, dueDate); else if (row.target.kind === "task") recoverCaseTask(row.target.caseId, row.target.taskId, action, text, files, dueDate); }} />
              </div>
            </article>)}</div>
            {!ordered.length && <div className="flex min-h-[180px] flex-col items-center justify-center gap-3 text-center"><CircleCheck size={25} className="text-slate-300" /><p className="text-xs text-slate-400">暂无符合条件的整改记录</p></div>}
          </div>
        </section>
    </section>
    {settings && <TaskDialog title="整改提醒设置" description="日期按本地自然日计算，仅影响当前身份的提醒，不修改业务状态。" onClose={() => setSettings(false)} footer={<button className="rounded-md bg-[#0052D9] px-4 py-2 text-xs text-white" onClick={() => { try { setReminderPolicy(draft); setSettings(false); } catch (cause) { setError(cause instanceof Error ? cause.message : "保存失败"); } }}>保存设置</button>}><div className="space-y-4">{[{ key: "dueSoonDays" as const, label: "提前提醒（天）", min: 0 }, { key: "inactiveDays" as const, label: "无实质更新提醒（天）", min: 1 }, { key: "repeatCount" as const, label: "反复退回提示（次）", min: 1 }].map(field => <label key={field.key} className="flex items-center justify-between text-sm text-slate-600">{field.label}<input type="number" min={field.min} max={90} value={draft[field.key]} onChange={event => setDraft({ ...draft, [field.key]: Number(event.target.value) })} className="h-8 w-24 rounded border border-slate-200 px-2 text-xs" /></label>)}</div>{error && <p role="alert" className="mt-3 text-xs text-red-600">{error}</p>}</TaskDialog>}
  </div>;
}