import { Search, Bell, HelpCircle, ChevronRight } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { mockCases, notifications as allNotifs, levelColors, ownerToDepartment, TaskNode, currentUser, productById } from "./data";
import { useTaskSubscriptions } from "./taskSubscriptions";
import { useIssues, isIssueRelevantTo, issueRoleFor } from "./domainStore";
import { caseDisplayStatus } from "./CaseStatusBadge";
import { standaloneTaskDisplayStatus, useStandaloneTasks } from "./standaloneTasks";
import { loadCaseTaskTree, useCaseTaskRevision } from "./caseTaskTrees";
import { CreateEntryDialog } from "./CreateEntryDialog";
import { RecoveryCenter } from "./RecoveryCenter";
import { useRecoveryFeedback, recoveryNotification, markRecoveryNotificationsRead, feedbackSummary } from "./recoveryFeedback";
import { allClosureRecords, pendingCaseRecoveries } from "./closures";
import * as Tabs from "@radix-ui/react-tabs";

const READ_NOTIFICATIONS_KEY = "ea_read_notifications_v1";

interface NotificationItem {
  id: string;
  type: "update" | "mention" | "escalate" | "spc" | "hems" | "issue";
  user: string;
  content: string;
  caseId: string;
  taskId?: string;
  issueId?: string;
  time: string;
  read: boolean;
}

function loadReadNotificationIds() {
  try {
    const raw = localStorage.getItem(READ_NOTIFICATIONS_KEY);
    return new Set<string>(raw ? JSON.parse(raw) : []);
  } catch {
    return new Set<string>();
  }
}

interface Crumb {
  label: string;
  onClick?: () => void;
}

interface Props {
  breadcrumb: Crumb[];
  onFeedback: () => void;
  onGuide?: () => void;
  onWhatsNew?: () => void;
  onOpenCase: (id: string) => void;
  onOpenTask?: (caseId: string, taskId: string) => void;
  onOpenStandaloneTask?: (taskId: string) => void;
  onOpenIssue?: (id: string) => void;
  onCreateCase: () => void;
  onCreateTask: () => void;
}

type SearchTab = "all" | "user" | "case" | "task" | "standalone";
type Kind = "user" | "case" | "task";
interface Hit {
  id: string;
  kind: Kind;
  title: string;
  meta: string;
  code?: string;
  status?: string;
  caseId?: string;
  taskId?: string;
  standaloneTaskId?: string;
  userName?: string;
  hits: string[]; // 命中的关键词（多关键词分组用）
}

export function TopBar({ breadcrumb, onFeedback, onGuide, onWhatsNew, onOpenCase, onOpenTask, onOpenStandaloneTask, onOpenIssue, onCreateCase, onCreateTask }: Props) {
  const recovery = useRecoveryFeedback();
  const recoveryApprovals = pendingCaseRecoveries().filter(record => record.approval?.reviewer === currentUser.name || record.approval?.requestedBy === currentUser.name);
  const recoveryDecisions = allClosureRecords().flatMap(record => [...(record.approvalHistory ?? []), ...(record.approval ? [record.approval] : [])].filter(request => request.kind === "closure" && request.decision && (request.reviewer === currentUser.name || request.requestedBy === currentUser.name)).map(request => ({ caseId: record.caseId, request })));
  const recoveryNotices = recovery.rows.map(row => recoveryNotification(row, recovery.policy)).filter((notice): notice is NonNullable<typeof notice> => Boolean(notice)).sort((left, right) => Number(left.read) - Number(right.read) || (right.row.entry.submittedAt ?? right.row.entry.at).localeCompare(left.row.entry.submittedAt ?? left.row.entry.at));
  const recoveryUnread = recoveryNotices.filter(notice => !notice.read).length;
  const [recoveryError, setRecoveryError] = useState("");
  const taskSubscriptions = useTaskSubscriptions();
  const standaloneTasks = useStandaloneTasks();
  const caseTaskRevision = useCaseTaskRevision();
  const issues = useIssues();
  const [q, setQ] = useState("");
  const [searchOpen, setSearchOpen] = useState(false);
  const [showFanoutSearch, setShowFanoutSearch] = useState(false);
  const [tab, setTab] = useState<SearchTab>("all");
  const [notifOpen, setNotifOpen] = useState(false);
  const [showAll, setShowAll] = useState(false);
  const [readNotificationIds, setReadNotificationIds] = useState<Set<string>>(loadReadNotificationIds);
  const searchInputRef = useRef<HTMLInputElement>(null);

  // 打开大窗口后自动聚焦
  useEffect(() => {
    if (!searchOpen) return;
    const t = setTimeout(() => searchInputRef.current?.focus(), 30);
    return () => clearTimeout(t);
  }, [searchOpen]);

  // ESC 关闭大窗口
  useEffect(() => {
    if (!searchOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setSearchOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [searchOpen]);

  // 递归展开任务树（含 children），保留所属 caseId
  const allTasks = useMemo(() => {
    const out: { task: TaskNode; caseId: string }[] = [];
    const walk = (nodes: TaskNode[] | undefined, caseId: string) => {
      for (const t of nodes ?? []) {
        out.push({ task: t, caseId });
        if (t.children) walk(t.children, caseId);
      }
    };
    mockCases.forEach((c) => walk(loadCaseTaskTree(c.id, c.tasks), c.id));
    return out;
  }, [caseTaskRevision, standaloneTasks, searchOpen]);

  const today = useMemo(() => {
    const now = new Date();
    const pad = (value: number) => String(value).padStart(2, "0");
    return `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`;
  }, []);
  const followedKeys = taskSubscriptions.keys.join("|");
  const notifs = useMemo<NotificationItem[]>(() => {
    const hems: NotificationItem[] = taskSubscriptions.refs.flatMap(({ caseId, taskId }) => {
      const found = allTasks.find((item) => item.caseId === caseId && item.task.id === taskId);
      const caseItem = mockCases.find((item) => item.id === caseId);
      if (!found || !caseItem) return [];
      const { task } = found;
      const lastStatusAt = task.statusHistory?.[task.statusHistory.length - 1]?.at;
      const updateAt = lastStatusAt || caseItem.updatedAt || today;
      const id = `hems-${today}-${caseId}-${taskId}`;
      return [{
        id,
        type: "hems",
        user: "HEMS",
        content: `${caseItem.code} · ${task.title}｜负责人 ${task.owner}｜${task.status} · 进度 ${task.progress}%｜更新 ${updateAt}`,
        caseId,
        taskId,
        time: `${today} 每日跟踪`,
        read: readNotificationIds.has(id),
      }];
    });
    const standard: NotificationItem[] = allNotifs.map((notification) => ({
      ...notification,
      read: notification.read || readNotificationIds.has(notification.id),
    }));
    // V1.0.4：取消 Issue 概念 —— 不再生成 Issue 通知
    return [...hems, ...standard];
  }, [allTasks, followedKeys, readNotificationIds, taskSubscriptions.refs, today]);
  const unread = notifs.filter((notification) => !notification.read).length;
  const searchableCases = useMemo(
    () => showFanoutSearch ? mockCases : mockCases.filter((caseItem) => !caseItem.fanoutSourceCaseId && caseItem.source !== "fanout验证"),
    [showFanoutSearch],
  );
  const searchableCaseIds = useMemo(() => new Set(searchableCases.map((caseItem) => caseItem.id)), [searchableCases]);
  const searchableTasks = useMemo(() => allTasks.filter((item) => searchableCaseIds.has(item.caseId)), [allTasks, searchableCaseIds]);

  const markNotificationsRead = (ids: string[]) => {
    setReadNotificationIds((current) => {
      const next = new Set(current);
      ids.forEach((id) => next.add(id));
      try {
        localStorage.setItem(READ_NOTIFICATIONS_KEY, JSON.stringify([...next]));
      } catch {}
      return next;
    });
  };

  // 用户目录：从 Case Owner / 参与人 / 任务负责人聚合
  const userDirectory = useMemo(() => {
    const map = new Map<string, { name: string; dept: string; caseCount: number; taskCount: number }>();
    const ensure = (name?: string) => {
      if (!name || name === "待指派" || name === "待分派") return null;
      if (!map.has(name)) map.set(name, { name, dept: ownerToDepartment[name] ?? "—", caseCount: 0, taskCount: 0 });
      return map.get(name)!;
    };
    searchableCases.forEach((c) => {
      const u = ensure(c.owner);
      if (u) u.caseCount += 1;
      (c.participants ?? []).forEach((p) => ensure(p.name));
    });
    searchableTasks.forEach(({ task }) => {
      const u = ensure(task.owner);
      if (u) u.taskCount += 1;
    });
    return Array.from(map.values());
  }, [searchableCases, searchableTasks]);

  const tokens = useMemo(() => q.trim().toLowerCase().split(/\s+/).filter(Boolean), [q]);

  // 三类实体的命中结果（空查询时返回全部，渲染时再按热门截断）
  const matched = useMemo(() => {
    const hitTokens = (text: string) => tokens.filter((tk) => text.includes(tk));

    const users: Hit[] = [];
    for (const u of userDirectory) {
      const text = `${u.name} ${u.dept}`.toLowerCase();
      const hs = tokens.length ? hitTokens(text) : [];
      if (tokens.length && hs.length === 0) continue;
      users.push({
        id: `user-${u.name}`,
        kind: "user",
        title: u.name,
        meta: `${u.dept} · 负责 ${u.caseCount} 个 Case / ${u.taskCount} 个任务`,
        userName: u.name,
        hits: hs,
      });
    }

    const cases: Hit[] = [];
    for (const c of searchableCases) {
      const fields = [
        c.code, c.name, c.owner, c.product, c.customer, c.failMode, c.level, c.urgency, c.status,
        c.failStage, c.material, c.materialSubtype, c.density, c.ioType, c.failPlatform,
        c.failPackage, c.failRatio, c.maskVersion, c.program, c.ppm, c.pdId,
        (c.departments ?? []).join(" "),
        (c.participants ?? []).map((p) => `${p.name} ${p.department}`).join(" "),
        (c.granules ?? []).map((g) => g.markCode).filter(Boolean).join(" "),
        c.splitGranule?.markCode,
      ].filter(Boolean).join(" ").toLowerCase();
      const hs = tokens.length ? hitTokens(fields) : [];
      if (tokens.length && hs.length === 0) continue;
      cases.push({
        id: `case-${c.id}`,
        kind: "case",
        title: c.name,
        code: c.code,
        meta: `Owner：${c.owner}`,
        status: caseDisplayStatus(c),
        caseId: c.id,
        hits: hs,
      });
    }

    const tasks: Hit[] = [];
    for (const { task, caseId } of searchableTasks) {
      if (!task.code) continue; // 仅可检索执行任务（思路节点无编号）
      const fields = [
        task.code, task.title, task.owner, task.type, task.status, task.department, task.site,
        task.supervisor, task.siteOwner, task.urgency, task.validity,
        (task.efaAnalysis?.chipList ?? []).map((ch) => ch.markCode).filter(Boolean).join(" "),
      ].filter(Boolean).join(" ").toLowerCase();
      const hs = tokens.length ? hitTokens(fields) : [];
      if (tokens.length && hs.length === 0) continue;
      tasks.push({
        id: `task-${caseId}-${task.id}`,
        kind: "task",
        title: task.title,
        code: task.code,
        meta: `负责人：${task.owner} · ${task.department}`,
        status: task.status,
        caseId,
        taskId: task.id,
        hits: hs,
      });
    }
    for (const task of standaloneTasks) {
      const fields = [task.code, task.title, task.description, task.owner, task.createdBy, task.urgency, standaloneTaskDisplayStatus(task), ...task.collaborators.map((participant) => `${participant.name} ${participant.department}`)].join(" ").toLowerCase();
      const hs = tokens.length ? hitTokens(fields) : [];
      if (tokens.length && hs.length === 0) continue;
      tasks.push({
        id: `standalone-task-${task.id}`,
        kind: "task",
        title: task.title,
        code: task.code,
        meta: `自由任务 · 负责人：${task.owner}`,
        status: standaloneTaskDisplayStatus(task),
        standaloneTaskId: task.id,
        hits: hs,
      });
    }

    return { users, cases, tasks };
  }, [tokens, userDirectory, searchableCases, searchableTasks, standaloneTasks]);

  const counts = {
    all: matched.users.length + matched.cases.length + matched.tasks.length,
    user: matched.users.length,
    case: matched.cases.length,
    task: matched.tasks.filter(item => Boolean(item.caseId)).length,
    standalone: matched.tasks.filter(item => Boolean(item.standaloneTaskId)).length,
  };

  const kindLabel = (k: Kind) => (k === "user" ? "用户" : k === "case" ? "Case" : "任务");
  const badgeClass = (k: Kind) =>
    k === "user" ? "bg-purple-50 text-purple-600" : k === "case" ? "bg-blue-50 text-blue-600" : "bg-cyan-50 text-cyan-600";
  const statusPill = (s: string) =>
    s === "进行中" ? "bg-blue-50 text-blue-600"
    : s === "验证中" ? "bg-cyan-50 text-cyan-700"
    : s === "已完成" ? "bg-emerald-50 text-emerald-600"
    : s === "已结案" ? "bg-emerald-50 text-emerald-700"
    : s === "已升级" ? "bg-red-50 text-red-600"
    : (s === "待接受" || s === "待处理" || s === "Pending") ? "bg-amber-50 text-amber-600"
    : "bg-slate-100 text-slate-500";

  const escapeHtml = (s: string) =>
    s.replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c] as string));
  const escapeReg = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const highlight = (s: string) => {
    let out = escapeHtml(s);
    tokens.forEach((tk) => {
      if (tk) out = out.replace(new RegExp(escapeReg(tk), "gi"), (m) => `<em class="not-italic text-[#0052D9] font-semibold bg-[#0052D9]/10 rounded px-0.5">${m}</em>`);
    });
    return out;
  };

  // 分组：单关键词按实体分组；多关键词先「多词同时命中」，再按「主命中关键词」
  const buildGroups = (pool: Hit[], entity?: Kind): { key: string; title: string; tag: string; items: Hit[] }[] => {
    if (tokens.length <= 1) {
      const empty = tokens.length === 0;
      const cap = (arr: Hit[]) => (empty && tab !== "task" && tab !== "standalone" ? arr.slice(0, 6) : arr);
      if (entity) return pool.length ? [{ key: entity, title: tab === "task" ? "Case任务" : tab === "standalone" ? "自由任务" : kindLabel(entity), tag: empty ? "推荐" : "按实体", items: cap(pool) }] : [];
      const g: { key: string; title: string; tag: string; items: Hit[] }[] = [];
      const us = cap(pool.filter((x) => x.kind === "user"));
      const cs = cap(pool.filter((x) => x.kind === "case"));
      const ts = cap(pool.filter((x) => x.kind === "task"));
      if (us.length) g.push({ key: "user", title: "用户", tag: empty ? "常用" : "人员", items: us });
      if (cs.length) g.push({ key: "case", title: "Case", tag: empty ? "热门" : "案件", items: cs });
      if (ts.length) g.push({ key: "task", title: "任务", tag: empty ? "最近" : "执行", items: ts });
      return g;
    }
    const groups: { key: string; title: string; tag: string; items: Hit[] }[] = [];
    const multi = pool.filter((x) => x.hits.length > 1);
    const singles = pool.filter((x) => x.hits.length === 1);
    if (multi.length) groups.push({ key: "multi", title: "多关键词同时命中", tag: "交叉命中", items: multi });
    tokens.forEach((tk) => {
      const arr = singles.filter((x) => x.hits[0] === tk);
      if (arr.length) groups.push({ key: `tk-${tk}`, title: `关键词：${tk}`, tag: "主命中", items: arr });
    });
    return groups;
  };

  const currentPool = (): Hit[] => {
    if (tab === "user") return matched.users;
    if (tab === "case") return matched.cases;
    if (tab === "task") return matched.tasks.filter(item => Boolean(item.caseId));
    if (tab === "standalone") return matched.tasks.filter(item => Boolean(item.standaloneTaskId));
    return [...matched.users, ...matched.cases, ...matched.tasks];
  };

  const groups = tab === "all" ? buildGroups(currentPool()) : buildGroups(currentPool(), tab === "standalone" ? "task" : tab);

  const handlePick = (it: Hit) => {
    if (it.kind === "user" && it.userName) {
      // 点击用户：以其姓名重新检索，查看相关 Case / 任务
      setQ(it.userName);
      setTab("all");
      return;
    }
    if (it.kind === "task" && it.standaloneTaskId) {
      onOpenStandaloneTask?.(it.standaloneTaskId);
    } else if (it.kind === "task" && it.caseId) {
      if (onOpenTask) onOpenTask(it.caseId, it.taskId!);
      else onOpenCase(it.caseId);
    } else if (it.caseId) {
      onOpenCase(it.caseId);
    }
    setSearchOpen(false);
    setQ("");
  };

  return (
    <header className="h-14 bg-white border-b border-slate-200 flex items-center px-5 gap-4 relative z-10">
      {/* Breadcrumb —— 取色逻辑：上级 slate-400 可点(悬停蓝) / 当前页 slate-700 加重 / 分隔符 slate-300 */}
      <div className="flex items-center gap-1.5 min-w-0">
        {breadcrumb.map((b, i) => {
          const isLast = i === breadcrumb.length - 1;
          return (
            <span key={i} className="flex items-center gap-1.5 min-w-0">
              {i > 0 && <ChevronRight size={14} className="text-slate-300 shrink-0" />}
              {b.onClick && !isLast ? (
                <button onClick={b.onClick} className="text-sm font-normal text-slate-400 hover:text-[#0052D9] truncate transition-colors">
                  {b.label}
                </button>
              ) : (
                <span className={`text-sm truncate ${isLast ? "text-slate-700 font-medium" : "text-slate-400 font-normal"}`}>
                  {b.label}
                </span>
              )}
            </span>
          );
        })}
      </div>

      {/* 全局搜索（点击展开大窗口） */}
      <div className="flex-1 flex justify-center px-4 min-w-0">
        <button
          onClick={() => setSearchOpen(true)}
          className="relative w-full max-w-[440px] h-9 pl-9 pr-3 rounded-lg bg-slate-50 border border-slate-200 text-sm text-slate-400 text-left hover:bg-white hover:border-[#0052D9]/40 transition-all"
        >
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
          搜索 Case、任务、用户…
        </button>
      </div>

      {/* Quick actions */}
      <RecoveryCenter onOpenCase={onOpenCase} onOpenTask={onOpenTask} onOpenStandaloneTask={onOpenStandaloneTask} />
      <CreateEntryDialog onCreateCase={onCreateCase} onCreateTask={onCreateTask} onOpen={() => { setSearchOpen(false); setNotifOpen(false); }} />
      <div className="relative group">
        <button
          className="h-8 px-3 rounded-md text-sm text-[#0052D9] border border-[#0052D9]/30 hover:bg-[#0052D9]/5 flex items-center gap-1.5"
        >
          <HelpCircle size={14} /> 系统建议
        </button>
        <div className="absolute right-0 top-full pt-1 hidden group-hover:block z-20">
          <div className="w-32 bg-white border border-slate-200 rounded-md shadow-lg overflow-hidden">
            <button
              onClick={onGuide}
              className="w-full px-3 py-2 text-sm text-slate-700 hover:bg-slate-50 text-left"
            >
              新手引导
            </button>
            <button
              onClick={onWhatsNew}
              className="w-full px-3 py-2 text-sm text-slate-700 hover:bg-slate-50 text-left border-t border-slate-100"
            >
              更新说明
            </button>
            <button
              onClick={onFeedback}
              className="w-full px-3 py-2 text-sm text-slate-700 hover:bg-slate-50 text-left border-t border-slate-100"
            >
              提交反馈
            </button>
            <button
              onClick={() => {}}
              className="w-full px-3 py-2 text-sm text-slate-700 hover:bg-slate-50 text-left border-t border-slate-100"
            >
              一键入群
            </button>
          </div>
        </div>
      </div>

      {/* Notifications */}
      <div className="relative">
        <button
          aria-label="通知"
          onClick={() => {
            setNotifOpen(!notifOpen);
            if (notifOpen) setShowAll(false);
          }}
          className="relative w-8 h-8 rounded-md hover:bg-slate-100 flex items-center justify-center text-slate-600"
        >
          <Bell size={16} />
          {unread + recoveryUnread + recoveryApprovals.length > 0 && (
            <span className="absolute -top-0.5 -right-0.5 min-w-[16px] h-4 px-1 rounded-full bg-red-500 text-white text-[10px] flex items-center justify-center">
              {unread + recoveryUnread + recoveryApprovals.length}
            </span>
          )}
        </button>
        {notifOpen && (
          <div className={`absolute right-0 top-full mt-1 w-[380px] bg-white border border-slate-200 rounded-md shadow-lg overflow-hidden transition-all duration-300 ${
            showAll ? "max-h-[calc(100vh-80px)]" : ""
          }`}>
            <div className="px-4 py-2.5 border-b border-slate-100 flex items-center">
              <span className="text-sm text-slate-900">通知</span>
              <span className="text-xs text-slate-400 ml-2">{unread + recoveryUnread} 条未读{recoveryApprovals.length ? ` · ${recoveryApprovals.length} 条审批中` : ""}</span>
              <button
                onClick={() => { try { markRecoveryNotificationsRead(recoveryNotices); markNotificationsRead(notifs.map((notification) => notification.id)); setRecoveryError(""); } catch (cause) { setRecoveryError(cause instanceof Error ? cause.message : "标记失败"); } }}
                className="ml-auto text-xs text-[#0052D9] hover:underline"
              >
                全部标为已读
              </button>
            </div>
            <div className={`overflow-y-auto divide-y divide-slate-100 ${
              showAll ? "max-h-[calc(100vh-180px)]" : "max-h-[420px]"
            }`}>
              {recoveryError && <p role="alert" className="p-3 text-xs text-red-600">{recoveryError}</p>}
              {recoveryApprovals.map(record => <button key={record.approval!.id} className="block w-full px-4 py-3 text-left text-xs hover:bg-slate-50" onClick={() => { setNotifOpen(false); onOpenCase(record.caseId); }}><span className="block text-[#0052D9]">再次结案申请 · {record.approval!.reviewer === currentUser.name ? "待我审核" : "等待审核"}</span><span className="mt-1 block text-slate-700">{mockCases.find(item => item.id === record.caseId)?.name ?? record.caseId}</span></button>)}
              {recoveryDecisions.map(({ caseId, request }) => <button key={request.id} className="block w-full px-4 py-3 text-left text-xs hover:bg-slate-50" onClick={() => { setNotifOpen(false); onOpenCase(caseId); }}><span className="block text-slate-500">再次结案{request.decision === "approved" ? "已通过" : "已驳回"} · {request.reviewer}</span><span className="mt-1 block text-slate-700">{mockCases.find(item => item.id === caseId)?.name ?? caseId}</span></button>)}
              {recoveryNotices.map(notice => <button key={notice.key} type="button" className={`block w-full px-4 py-3 text-left hover:bg-slate-50 ${notice.read ? "" : "bg-blue-50/50"}`} onClick={() => {
                try { markRecoveryNotificationsRead([notice]); setRecoveryError(""); } catch (cause) { setRecoveryError(cause instanceof Error ? cause.message : "标记失败"); return; }
                const target = notice.row.target;
                if (target.kind === "case") onOpenCase(target.caseId); else if (target.kind === "task") onOpenTask?.(target.caseId, target.taskId); else onOpenStandaloneTask?.(target.taskId);
                setNotifOpen(false);
              }}><span className="block text-[11px] text-[#0052D9]">{notice.label} · {notice.row.owner}</span><span className="mt-1 block text-xs text-slate-800">{notice.row.title}</span><span className="mt-1 block line-clamp-2 text-[11px] leading-5 text-slate-500">{feedbackSummary(notice.row)}</span></button>)}
              {notifs.map((n) => (
                <button
                  key={n.id}
                  onMouseDown={() => {
                    if (n.issueId && onOpenIssue) onOpenIssue(n.issueId);
                    else if (n.taskId && onOpenTask) onOpenTask(n.caseId, n.taskId);
                    else onOpenCase(n.caseId);
                    setNotifOpen(false);
                    setShowAll(false);
                    markNotificationsRead([n.id]);
                  }}
                  className={`w-full text-left px-4 py-2.5 hover:bg-slate-50 flex gap-3 ${
                    !n.read ? "bg-[#0052D9]/4" : ""
                  }`}
                >
                  <div
                    className={`w-1.5 h-1.5 rounded-full mt-1.5 shrink-0 ${
                      n.type === "mention"
                        ? "bg-red-500"
                        : n.type === "issue"
                        ? "bg-[#7A3DFF]"
                        : n.type === "hems"
                        ? "bg-cyan-500"
                        : n.type === "escalate"
                        ? "bg-amber-500"
                        : n.type === "spc"
                        ? "bg-purple-500"
                        : "bg-[#0052D9]"
                    }`}
                  />
                  <div className="flex-1 min-w-0">
                    <div className="text-xs text-slate-500">
                      <span className="text-slate-800">{n.user}</span>
                      {n.type === "hems" && <span className="ml-1.5 px-1.5 py-0.5 rounded bg-cyan-50 text-cyan-700 border border-cyan-100 text-[9px] font-semibold">任务关注</span>}
                      {n.type === "issue" && <span className="ml-1.5 px-1.5 py-0.5 rounded bg-[#7A3DFF]/8 text-[#7A3DFF] border border-[#7A3DFF]/20 text-[9px] font-semibold">Issue</span>}
                      <span> · {n.time}</span>
                    </div>
                    <div className="text-sm text-slate-700 mt-0.5">{n.content}</div>
                  </div>
                </button>
              ))}
            </div>
            <div className="px-4 py-2 border-t border-slate-100 text-center">
              <button
                onClick={() => setShowAll(!showAll)}
                className="text-xs text-[#0052D9] hover:underline"
              >
                {showAll ? "收起" : "查看全部通知"}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* 全局搜索大窗口（样式2·四页签·单/多关键词分组） */}
      {searchOpen && (
        <div
          className="fixed inset-0 z-50 flex items-start justify-center bg-slate-900/40 backdrop-blur-sm pt-[8vh] px-6"
          onMouseDown={() => setSearchOpen(false)}
        >
          <Tabs.Root value={tab} onValueChange={value => { if (["all", "user", "case", "task", "standalone"].includes(value)) setTab(value as SearchTab); }} asChild><div
            className="w-full max-w-[1040px] h-[70vh] bg-white rounded-2xl border border-slate-200/70 shadow-2xl flex flex-col overflow-hidden"
            onMouseDown={(e) => e.stopPropagation()}
          >
            {/* 头部搜索条 */}
            <div className="flex items-center gap-3 px-5 py-4 border-b border-slate-200">
              <Search size={20} className="text-[#0052D9]" />
              <input
                ref={searchInputRef}
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="搜索 Case、任务、用户…（多个关键词用空格分隔）"
                className="flex-1 text-lg text-slate-800 placeholder:text-slate-300 outline-none bg-transparent"
              />
              <label className={`inline-flex h-8 shrink-0 cursor-pointer items-center gap-1.5 rounded-md border px-2.5 text-[11px] transition-colors ${showFanoutSearch ? "border-[#0052D9]/35 bg-[#0052D9]/5 text-[#0052D9]" : "border-slate-200 bg-white text-slate-500 hover:border-slate-300"}`}>
                <input type="checkbox" checked={showFanoutSearch} onChange={(event) => setShowFanoutSearch(event.target.checked)} className="accent-[#0052D9]" />
                查看 Fanout
              </label>
              <span className="text-xs text-slate-400 whitespace-nowrap">共 {counts[tab]} 条</span>
              <button
                onClick={() => setSearchOpen(false)}
                className="text-[11px] text-slate-400 border border-slate-200 rounded-md px-2 py-1 hover:bg-slate-50"
              >
                ESC 关闭
              </button>
            </div>

            {/* 页签 */}
            <Tabs.List aria-label="全局搜索分类" className="flex gap-1 px-5 pt-2 border-b border-slate-200">
              {(
                [
                  ["all", "全部"],
                  ["user", "用户"],
                  ["case", "Case"],
                  ["task", "Case任务"],
                  ["standalone", "自由任务"],
                ] as [SearchTab, string][]
              ).map(([k, label]) => (
                <Tabs.Trigger
                  key={k}
                  value={k}
                  className={`text-sm px-3.5 py-2.5 -mb-px border-b-2 transition-colors ${
                    tab === k ? "text-[#0052D9] border-[#0052D9] font-semibold" : "text-slate-500 border-transparent hover:text-slate-700"
                  }`}
                >
                  {label}
                  <span className={`ml-1 text-[11px] ${tab === k ? "text-[#0052D9]" : "text-slate-400"}`}>{counts[k]}</span>
                </Tabs.Trigger>
              ))}
            </Tabs.List>

            {/* 分组策略提示 */}
            {tokens.length > 0 && (
              <div className="flex items-center flex-wrap gap-2 px-5 py-2.5 border-b border-slate-100 bg-slate-50/60 text-xs text-slate-500">
                <span className="text-slate-600 font-medium">分组规则：</span>
                <span>
                  {tokens.length > 1 ? "先显示多词同时命中，再按主命中关键词分组" : "单关键词按实体分组（用户 / Case / 任务）"}
                </span>
                {tokens.map((tk) => (
                  <span
                    key={tk}
                    className="inline-flex items-center h-[22px] px-2 rounded-full border border-blue-200 bg-blue-50 text-[#2957b8] text-[11px] font-semibold"
                  >
                    {tk}
                  </span>
                ))}
              </div>
            )}

            {/* 结果列表 */}
            <Tabs.Content value={tab} asChild>
            <div id="global-task-results" aria-label="搜索结果" className="flex-1 min-h-0 overflow-y-auto">
              {groups.length === 0 ? (
                <div className="text-center text-slate-400 text-sm py-16">未找到匹配结果</div>
              ) : (
                groups.map((g) => (
                  <section key={g.key} className="border-b border-slate-100 last:border-b-0">
                    <div className="flex items-center gap-2 px-5 pt-2.5 pb-1.5">
                      <span className="text-xs font-bold text-slate-700">{g.title}</span>
                      <span className="text-[10px] text-slate-400 bg-slate-100 rounded px-1.5 py-0.5">{g.tag}</span>
                      <span className="ml-auto text-[11px] text-slate-400">{g.items.length} 条</span>
                    </div>
                    {(tab === "task" || tab === "standalone" || tokens.length ? g.items : g.items.slice(0, 8)).map((it) => (
                      <button
                        key={it.id}
                        onClick={() => handlePick(it)}
                        className="w-full flex items-center gap-3 px-5 py-2.5 text-left hover:bg-slate-50 border-l-[3px] border-transparent hover:border-[#0052D9]/40 transition-colors"
                      >
                        <span className={`shrink-0 text-[10px] font-bold px-2 py-0.5 rounded-md ${badgeClass(it.kind)}`}>
                          {it.kind === "task" ? it.standaloneTaskId ? "自由任务" : "Case任务" : kindLabel(it.kind)}
                        </span>
                        <div className="min-w-0 flex-1">
                          <div className="text-sm text-slate-800 truncate" dangerouslySetInnerHTML={{ __html: highlight(it.title) }} />
                          <div className="text-xs text-slate-500 mt-0.5 truncate">
                            {it.code && <span className="font-mono text-[11px] text-slate-400">{it.code}</span>}
                            {it.code && " · "}
                            <span dangerouslySetInnerHTML={{ __html: highlight(it.meta) }} />
                          </div>
                        </div>
                        {it.hits.length > 1 && (
                          <span className="shrink-0 text-[10px] text-slate-500 bg-slate-100 rounded px-1.5 py-0.5">
                            命中：{it.hits.join(" + ")}
                          </span>
                        )}
                        {it.status && (
                          <span className={`shrink-0 text-[11px] px-2 py-0.5 rounded-full ${statusPill(it.status)}`}>{it.status}</span>
                        )}
                      </button>
                    ))}
                  </section>
                ))
              )}
            </div>

            </Tabs.Content>
            <div className="border-t border-slate-100 bg-slate-50 px-4 py-2.5 flex justify-end text-[11px] text-slate-400">
              点击用户可查看其相关 Case / 任务
            </div>
          </div></Tabs.Root>
        </div>
      )}
    </header>
  );
}
