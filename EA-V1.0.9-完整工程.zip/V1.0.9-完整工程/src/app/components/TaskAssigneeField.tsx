import { useEffect } from "react";
import { Bot, CheckCircle2, LoaderCircle, User } from "lucide-react";
import { ownerToDepartment, TaskNode } from "./data";
import { listSkills } from "./skills";
import { PersonInput } from "./PersonInput";

export type TaskAssigneeValue = {
  assignee: string;
  department: string;
  assigneeType?: "person" | "skill";
  skillId?: string;
  skillRun?: TaskNode["skillRun"];
};

const RESULT_BY_SKILL: Record<string, string> = {
  "sk-001": "已识别 Top Bin：BIN12（42.8%）、BIN7（18.6%）。疑似 Pattern timing margin 不足，建议优先执行低压 Shmoo 与 Pattern bisect。",
  "sk-002": "已扫描 36 组 timing set，发现 3 组 setup margin 低于 120 ps。建议将 P_ICC2_07 的 strobe 延后 80 ps 后复测。",
  "sk-003": "已生成 8D 报告草稿，包含问题描述、临时遏制、根因分析、永久对策与验证结果，共 6 页。",
  "sk-004": "检测到 CP1 良率连续 4 批低于控制下限，异常集中于 wafer edge，建议创建边缘 die 对照组。",
  "sk-005": "检索到 7 个相似历史 Case，其中 2 个根因为 Pattern 电压窗口不足；建议复用对应验证路径。",
};

export function TaskAssigneeField({ value, onChange, compact = false }: {
  value: TaskAssigneeValue;
  onChange: (value: TaskAssigneeValue) => void;
  compact?: boolean;
}) {
  const skills = listSkills().filter((skill) => skill.status === "已发布");
  const mode = value.assigneeType ?? "person";

  useEffect(() => {
    if (mode !== "skill" || !value.skillId || value.skillRun?.status !== "执行中") return;
    const timer = window.setTimeout(() => {
      onChange({
        ...value,
        skillRun: {
          ...value.skillRun,
          status: "待确认",
          result: RESULT_BY_SKILL[value.skillId!] ?? "Skill 已完成分析并输出结构化结果，请人工确认。",
          completedAt: new Date().toLocaleString("zh-CN", { hour12: false }),
        },
      });
    }, 1200);
    return () => window.clearTimeout(timer);
  }, [mode, value.skillId, value.skillRun?.status]);

  const selectSkill = (skillId: string) => {
    const skill = skills.find((item) => item.id === skillId);
    onChange({
      assignee: skill?.name ?? "",
      department: "AI Skill",
      assigneeType: "skill",
      skillId,
      skillRun: skillId ? { status: "执行中", startedAt: new Date().toLocaleString("zh-CN", { hour12: false }) } : undefined,
    });
  };

  return (
    <div className="space-y-2">
      <div className="inline-flex rounded-md border border-slate-200 bg-slate-50 p-0.5">
        <button type="button" onClick={() => onChange({ assignee: "", department: value.department === "AI Skill" ? "PTE" : value.department, assigneeType: "person" })} className={`h-6 px-2 rounded text-[11px] inline-flex items-center gap-1 ${mode === "person" ? "bg-white text-[#0052D9] shadow-sm" : "text-slate-500"}`}><User size={11} />人员</button>
        <button type="button" onClick={() => onChange({ assignee: "", department: "AI Skill", assigneeType: "skill" })} className={`h-6 px-2 rounded text-[11px] inline-flex items-center gap-1 ${mode === "skill" ? "bg-violet-600 text-white shadow-sm" : "text-slate-500"}`}><Bot size={11} />Skill</button>
      </div>
      {mode === "person" ? (
        <PersonInput
          value={value.assignee}
          onChange={(assignee) => onChange({ ...value, assignee, department: ownerToDepartment[assignee] || value.department, assigneeType: "person", skillId: undefined, skillRun: undefined })}
          placeholder="@ 选择负责人"
          className={`${compact ? "h-8" : "h-9"} w-full px-2 text-sm rounded border border-slate-200 bg-white outline-none focus:border-[#0052D9]`}
        />
      ) : (
        <>
          <select value={value.skillId || ""} onChange={(event) => selectSkill(event.target.value)} className={`${compact ? "h-8" : "h-9"} w-full px-2 text-sm rounded border border-violet-200 bg-white outline-none focus:border-violet-500 text-violet-700`}>
            <option value="">选择 Skill</option>
            {skills.map((skill) => <option key={skill.id} value={skill.id}>{skill.name} · {skill.category}</option>)}
          </select>
          {value.skillRun && (
            <div className="rounded-md border border-violet-200 bg-violet-50/70 p-2 text-[11px] text-slate-600">
              {value.skillRun.status === "执行中" && <div className="flex items-center gap-1.5 text-violet-700"><LoaderCircle size={12} className="animate-spin" />Skill 正在执行...</div>}
              {(value.skillRun.status === "待确认" || value.skillRun.status === "已采用") && (
                <>
                  <div className="leading-relaxed">{value.skillRun.result}</div>
                  {value.skillRun.status === "待确认" ? <button type="button" onClick={() => onChange({ ...value, skillRun: { ...value.skillRun!, status: "已采用" } })} className="mt-2 h-7 px-2.5 rounded bg-violet-600 text-white inline-flex items-center gap-1"><CheckCircle2 size={12} />采用结果并完成任务</button> : <div className="mt-1.5 text-emerald-700 inline-flex items-center gap-1"><CheckCircle2 size={12} />结果已由人工确认采用</div>}
                </>
              )}
            </div>
          )}
        </>
      )}
    </div>
  );
}