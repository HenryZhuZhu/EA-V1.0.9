import { useRef, useState } from "react";
import { ArrowLeft, ArrowUpRight, CheckCircle2, ClipboardList, FileText, FolderUp, Pencil, MessageSquare } from "lucide-react";
import { CommentDrawer } from "./CommentDrawer";
import { currentUser, mockCases, urgencyColors } from "./data";
import { canUpgradeStandaloneTask, commentOnStandaloneTask, standaloneTaskById, standaloneTaskDisplayStatus, standaloneTaskEditDisabledReason, updateStandaloneTaskStatus, useStandaloneTasks } from "./standaloneTasks";
import { VoicePlayer } from "./VoiceNote";
import { AttachmentPreview } from "./AttachmentPreview";
import type { Att } from "./AttachmentInput";
import { TaskDialog } from "./TaskDialog";
import { RejectTaskModal } from "./RejectTaskModal";
import { StandaloneTaskResult } from "./StandaloneTaskResult";
import { TaskAttachmentList } from "./TaskAttachmentList";
import { TaskActivityPanel } from "./TaskActivityPanel";
import { recoverStandaloneTask } from "./standaloneTasks";
import { RecoveryActions, RecoveryBadge, RecoveryHistory } from "./RecoveryControls";

const STATUS_STYLE: Record<string, string> = {
  待接受: "border-amber-200 bg-amber-50 text-amber-700",
  进行中: "border-blue-200 bg-blue-50 text-blue-700",
  已完成: "border-emerald-200 bg-emerald-50 text-emerald-700",
  已中止: "border-slate-200 bg-slate-100 text-slate-500",
  已拒绝: "border-rose-200 bg-rose-50 text-rose-700",
};

export function StandaloneTaskDetail({ taskId, onBack, onOpenCase, onEdit, onUpgrade }: {
  taskId: string;
  onBack: () => void;
  onOpenCase: (caseId: string) => void;
  onEdit?: (taskId: string) => void;
  onUpgrade?: (taskIds: string[]) => void;
}) {
  const allTasks = useStandaloneTasks();
  const [confirmUpgrade, setConfirmUpgrade] = useState(false);
  const [additionalTaskIds, setAdditionalTaskIds] = useState<string[]>([]);
  const [rejecting, setRejecting] = useState(false);
  const [preview, setPreview] = useState<Att | null>(null);
  const [commentOpen, setCommentOpen] = useState(false);
  const [error, setError] = useState("");
  const upgrading = useRef(false);
  const task = standaloneTaskById(taskId);
  if (!task) return <div className="grid min-h-[400px] place-items-center text-sm text-slate-400"><div>未找到这条任务<button type="button" onClick={onBack} className="mt-3 block text-[#0052D9]">返回我的任务</button></div></div>;

  const upgrade = () => {
    if (upgrading.current) return;
    upgrading.current = true;
    try {
      const ids = [task.id, ...additionalTaskIds];
      if (ids.some(id => { const selected = standaloneTaskById(id); return !selected || !canUpgradeStandaloneTask(selected); })) throw new Error("请选择自己负责且未中止、未升级的任务。");
      if (!onUpgrade) throw new Error("新建 Case 入口暂不可用。");
      onUpgrade(ids);
      setConfirmUpgrade(false);
    } catch (reason) { setError(reason instanceof Error ? reason.message : "升级失败，请重试。"); }
    finally { upgrading.current = false; }
  };
  const setStatus = (status: "进行中") => {
    try { updateStandaloneTaskStatus(task.id, status); setError(""); }
    catch (reason) { setError(reason instanceof Error ? reason.message : "操作失败，请重试。"); }
  };
  const linkedCase = mockCases.find((item) => item.id === task.convertedCaseId);
  const upgradeCandidates = allTasks.filter((item) => item.id !== task.id && canUpgradeStandaloneTask(item));
  const selectedCount = additionalTaskIds.length + 1;
  const isOwner = task.owner === currentUser.name;
  const canAct = isOwner && !task.convertedCaseId;
  const editBlocked = standaloneTaskEditDisabledReason(task);
  const timeLabel = (value: string) => new Date(value).toLocaleString("zh-CN", { hour12: false, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" });
  const nextHint = task.convertedCaseId ? "" : !isOwner ? "仅任务负责人可接受、拒绝及提交任务结果" : {
    待接受: "下一步：接受任务后开始执行，或拒绝并说明理由",
    进行中: "下一步：在 Workspace 记录处理过程，填写并保存任务结论后点击「完成」",
    已完成: "任务已完成，可在下方 Workspace 查看结论与处理过程",
    已拒绝: "任务已拒绝",
    已中止: "任务已中止",
  }[task.status];

  return (
    <div className="space-y-4 p-6">
      <div><button type="button" aria-label="返回我的任务" onClick={onBack} className="flex items-center gap-1 text-sm text-slate-500 hover:text-[#0052D9]"><ArrowLeft size={14} />返回</button></div>
      {error && !confirmUpgrade && <p role="alert" className="rounded-lg bg-red-50 px-3 py-2 text-xs text-red-600">{error}</p>}

      <section aria-label="任务信息" className="rounded-xl border border-slate-200 bg-white p-5 shadow-[0_1px_2px_0_rgba(15,23,42,0.04)]">
        <div className="mb-3.5 flex min-h-7 flex-wrap items-center gap-2 border-b border-slate-100 pb-3 text-xs text-slate-500">
          <ClipboardList size={13} /><span>自由任务</span><span className="text-slate-400">· 日常事务 / Checklist / Todo</span>
          <div className="ml-auto flex shrink-0 items-center gap-2">
            <RecoveryActions record={task} owner={task.owner} title={task.title} completed={task.status === "已完成"} active={task.status === "进行中"} blocked={task.convertedCaseId ? "已升级任务请在关联 Case 中处理" : undefined} onAction={(action, text, files, dueDate) => { recoverStandaloneTask(task.id, action, text, files, dueDate); }} />
            {canUpgradeStandaloneTask(task) && <button type="button" onClick={() => { setError(""); setAdditionalTaskIds([]); setConfirmUpgrade(true); }} className="inline-flex h-7 shrink-0 items-center gap-1.5 rounded-md border border-slate-200 bg-white px-2.5 text-[11px] font-medium text-slate-500 transition-colors hover:border-[#0052D9]/30 hover:text-[#0052D9]"><FolderUp size={12} />升级为 Case</button>}
            {onEdit && <button type="button" onClick={() => { if (!editBlocked) onEdit(task.id); }} disabled={Boolean(editBlocked)} title={editBlocked || "编辑自由任务"} className="inline-flex h-7 shrink-0 items-center gap-1.5 rounded-md border border-slate-200 bg-white px-2.5 text-[11px] font-medium text-slate-500 transition-colors hover:border-[#0052D9]/30 hover:text-[#0052D9] disabled:cursor-not-allowed disabled:opacity-40"><Pencil size={12} />编辑</button>}
            <button type="button" onClick={() => setCommentOpen(true)} title="任务评论" aria-label="任务评论" className="flex h-7 w-7 items-center justify-center rounded-md border border-slate-200 bg-white text-slate-700 transition-colors hover:border-[#0052D9]/40 hover:text-[#0052D9]"><MessageSquare size={15} /></button>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2 text-sm">
          <span className="text-slate-500">{standaloneTaskDisplayStatus(task)}</span>
          <RecoveryBadge record={task} />
          <span className={`rounded px-2 py-0.5 text-[11px] ${urgencyColors[task.urgency]}`}>{task.urgency}</span>
          {isOwner && <span className="text-xs text-slate-400">· 我的任务</span>}
          {task.dueDate && <span className="ml-auto text-xs text-slate-500">截止 {task.dueDate}</span>}
        </div>
        <h1 className="mt-3 flex flex-wrap items-baseline gap-2 text-lg font-semibold leading-snug text-slate-900"><span className="min-w-0 break-words">{task.title}</span><span className="shrink-0 font-mono text-xs font-normal text-slate-400">{task.code}</span></h1>
        <div className="mt-3 border-l-[3px] border-slate-200 pl-3 text-sm leading-relaxed text-slate-600"><span className="mr-1.5 text-[11px] text-slate-400">任务说明</span><span className="whitespace-pre-wrap break-words">{task.description}</span></div>
        <dl className="mt-3.5 grid grid-cols-2 gap-x-6 gap-y-2 text-xs">
          <div className="flex gap-2"><dt className="w-16 shrink-0 text-slate-400">创建人</dt><dd className="min-w-0 break-words font-medium text-slate-700">{task.createdBy}</dd></div>
          <div className="flex gap-2"><dt className="w-16 shrink-0 text-slate-400">负责人</dt><dd className="min-w-0 break-words font-medium text-slate-700">{task.owner}</dd></div>
          <div className="flex gap-2"><dt className="w-16 shrink-0 text-slate-400">创建时间</dt><dd className="text-slate-500">{timeLabel(task.createdAt)}</dd></div>
          <div className="flex gap-2"><dt className="w-16 shrink-0 text-slate-400">最近更新</dt><dd className="text-slate-500">{timeLabel(task.updatedAt)}</dd></div>
        </dl>
        <TaskAttachmentList key={task.id} attachments={task.attachments} />
        {task.voiceNote && <div className="mt-3"><VoicePlayer src={task.voiceNote} label="语音备注" /></div>}
        {task.status === "已中止" && task.terminateReason && <section className="mt-3 rounded-lg border border-slate-200 bg-slate-50 p-3"><h2 className="mb-1 text-[11px] text-slate-500">中止原因</h2><p className="whitespace-pre-wrap break-words text-sm leading-relaxed text-slate-600">{task.terminateReason}</p></section>}
        {task.status === "已拒绝" && task.rejectReason && <section className="mt-3 rounded-lg border border-rose-200 bg-rose-50/60 p-3"><h2 className="mb-1 text-[11px] text-rose-600">拒绝理由</h2><p className="whitespace-pre-wrap break-words text-sm leading-relaxed text-rose-700/90">{task.rejectReason}</p></section>}
        {task.convertedCaseId && <section aria-label="任务升级信息" className="mt-3 rounded-lg border border-blue-100 bg-[#F5F8FF] px-3 py-2.5">
          <div className="flex min-w-0 items-center gap-2">
            <CheckCircle2 size={14} className="shrink-0 text-[#0052D9]" />
            <span className="shrink-0 text-[11px] font-medium text-[#0052D9]">已升级为 Case</span>
            <span aria-hidden="true" className="h-3 w-px shrink-0 bg-blue-200" />
            <button type="button" onClick={() => onOpenCase(task.convertedCaseId!)} aria-label={linkedCase?.name ? `查看关联 Case ${linkedCase.name}` : "查看关联 Case"} title={[linkedCase?.name || "查看关联 Case", linkedCase?.code].filter(Boolean).join(" · ")} className="flex min-w-0 flex-1 items-center gap-1.5 rounded text-left text-xs text-[#0052D9] hover:underline focus-visible:outline-2 focus-visible:outline-[#0052D9]/40">
              <FileText size={12} className="shrink-0" /><span className="min-w-0 truncate">{linkedCase?.name || "查看关联 Case"}</span>
              {linkedCase?.code && <span className="shrink-0 font-mono text-[10px] text-slate-400">{linkedCase.code}</span>}
              <ArrowUpRight size={12} className="shrink-0" />
            </button>
          </div>
          <p className="mt-1 pl-[22px] text-[11px] leading-4 text-slate-500">原任务保留供追溯，后续在关联 Case 中处理。</p>
        </section>}
        {nextHint && <div className="mt-4 flex flex-wrap items-center gap-2">
          {canAct && task.status === "待接受" && <><button type="button" onClick={() => setStatus("进行中")} className="h-9 rounded-md bg-[#0052D9] px-4 text-sm font-medium text-white hover:bg-[#003FA8]">接受并开始 →</button><button type="button" onClick={() => setRejecting(true)} className="h-9 rounded-md border border-slate-200 px-3 text-sm text-slate-600 hover:bg-slate-50">拒绝</button></>}
          <span className="text-xs text-slate-400">{nextHint}</span>
        </div>}
      </section>

      <RecoveryHistory record={task} />
      <StandaloneTaskResult key={task.id} task={task} onPreview={setPreview} onCancel={onBack}>
        <TaskActivityPanel key={`activity-${task.id}`} view="log" activities={task.activityLog} onComment={() => {}} />
      </StandaloneTaskResult>
      {commentOpen && <CommentDrawer caseName={task.title} caseCode={task.code} title="任务评论" count={(task.comments ?? []).reduce((total, item) => total + 1 + (item.replies?.length ?? 0), 0)} onClose={() => setCommentOpen(false)}><TaskActivityPanel view="comments" compact comments={task.comments} onComment={(content, replyTo) => { commentOnStandaloneTask(task.id, content, replyTo); }} readOnlyReason={task.convertedCaseId ? "任务已升级为 Case，原评论保留供追溯；请在关联 Case 的对应任务中继续讨论。" : undefined} /></CommentDrawer>}
      {preview && <AttachmentPreview attachment={preview} onClose={() => setPreview(null)} />}
      {rejecting && <RejectTaskModal title={task.title} onClose={() => setRejecting(false)} onConfirm={(reason) => updateStandaloneTaskStatus(task.id, "已拒绝", reason)} />}
      {confirmUpgrade && <TaskDialog title="升级为 Case" description="将当前任务带入新 Case，也可选择其他自由任务一起带入。" onClose={() => setConfirmUpgrade(false)} footer={<>
        <button type="button" onClick={() => setConfirmUpgrade(false)} className="h-9 rounded-lg border border-slate-200 bg-white px-4 text-[12px] text-slate-600">暂不升级</button>
        <button type="button" onClick={upgrade} className="inline-flex h-9 items-center gap-1.5 rounded-lg bg-[#0052D9] px-5 text-[12px] font-medium text-white hover:bg-[#003FA8]"><FolderUp size={14} />下一步：新建 Case（{selectedCount} 个任务）</button>
      </>}>
        <div className="rounded-xl border border-slate-200 bg-slate-50/50 p-4"><div className="text-[11px] text-slate-400">新 Case · 沿用当前任务的名称与基础信息</div><div className="mt-1 text-sm font-medium text-slate-800">{task.title}</div><div className="mt-2 text-[11px] text-slate-500">负责人 {task.owner} · {task.urgency} · 截止日期 {task.dueDate}</div></div>
        <fieldset className="mt-5"><legend className="mb-2 text-[12px] font-medium text-slate-700">带入新 Case 的自由任务 · 已选 {selectedCount} 条</legend>
          <div className="max-h-[260px] overflow-y-auto rounded-lg border border-slate-200 divide-y divide-slate-100">
            {[task, ...upgradeCandidates].map((item) => {
              const isCurrent = item.id === task.id;
              const checked = isCurrent || additionalTaskIds.includes(item.id);
              return <label key={item.id} className={`flex items-start gap-3 px-3 py-3 ${checked ? "bg-blue-50/40" : "hover:bg-slate-50"} ${isCurrent ? "cursor-default" : "cursor-pointer"}`}>
                <input type="checkbox" aria-label={`带入任务 ${item.title}`} checked={checked} disabled={isCurrent} onChange={(event) => setAdditionalTaskIds((ids) => event.target.checked ? [...new Set([...ids, item.id])] : ids.filter((id) => id !== item.id))} className="mt-0.5 h-3.5 w-3.5 shrink-0 accent-[#0052D9]" />
                <span className="min-w-0 flex-1"><span className="flex items-center gap-2"><span className="truncate text-[12px] font-medium text-slate-700">{item.title}</span>{isCurrent && <span className="shrink-0 text-[10px] text-[#0052D9]">当前任务</span>}<span className={`ml-auto shrink-0 rounded border px-1.5 py-0.5 text-[10px] ${STATUS_STYLE[item.status]}`}>{item.status}</span></span><span className="mt-1.5 block text-[10px] text-slate-400">{item.code} · {item.owner} · {item.dueDate}</span></span>
              </label>;
            })}
          </div>
          {!upgradeCandidates.length && <p className="mt-2 text-[11px] text-slate-400">暂无其他可带入的自由任务。</p>}
        </fieldset>
        <p className="mt-4 rounded-lg border border-amber-100 bg-amber-50/70 px-3 py-2.5 text-xs text-amber-800">在新建 Case 页面提交后完成升级。原任务及历史记录保留，执行状态不变。</p>
        {error && <p role="alert" className="mt-3 text-xs text-red-600">{error}</p>}
      </TaskDialog>}
    </div>
  );
}