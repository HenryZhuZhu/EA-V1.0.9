import { AlertTriangle, ArrowUp, ArrowUpRight, Check, ClipboardList, Copy, Download, FileSpreadsheet, FileText, ListPlus, LoaderCircle, ThumbsDown, ThumbsUp } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import type { ReactNode, RefObject } from "react";
import { AGENT_DEMO_FILES, AGENT_MAX_MESSAGE } from "./eaAgentModel";
import type { AgentMessage } from "./eaAgentModel";
import { AgentMark } from "./AgentMark";

const PROMPTS = [
  { icon: ClipboardList, question: "帮我统计我的部门当前的Case状态与风险情况" },
  { icon: AlertTriangle, question: "G5平台当前有什么问题？" },
  { icon: FileText, question: "DDJOC产品有多少case，什么进展？" },
  { icon: ListPlus, question: "Fail stage在FT阶段的问题有哪些？" },
];

function formatMessageTime(value?: string) {
  if (!value || !Number.isFinite(Date.parse(value))) return "";
  return new Intl.DateTimeFormat("zh-CN", { hour: "2-digit", minute: "2-digit", hour12: false }).format(new Date(value)).replace(/^24:/, "00:");
}

async function copyMessage(text: string) {
  if (navigator.clipboard?.writeText) {
    try { await navigator.clipboard.writeText(text); return true; } catch { /* Fall through for local-file previews. */ }
  }
  const input = document.createElement("textarea");
  input.value = text; input.setAttribute("readonly", ""); input.style.position = "fixed"; input.style.opacity = "0";
  document.body.appendChild(input); input.select();
  const copied = document.execCommand("copy"); input.remove();
  return copied;
}

export function AiAssistant({ messages, draft, onDraftChange, onSend, inputRef, expanded, composerTools, showPrompts = true, isRunning = false }: {
  messages: AgentMessage[];
  draft: string;
  onDraftChange: (value: string) => void;
  onSend: (text: string) => void;
  inputRef: RefObject<HTMLTextAreaElement>;
  expanded: boolean;
  composerTools?: ReactNode;
  showPrompts?: boolean;
  isRunning?: boolean;
}) {
  const messagesRef = useRef<HTMLDivElement>(null);
  const composing = useRef(false);
  const [copiedMessageId, setCopiedMessageId] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<Partial<Record<number, "up" | "down">>>({});
  const [downloadedFiles, setDownloadedFiles] = useState<Record<string, boolean>>({});
  useEffect(() => {
    const container = messagesRef.current;
    if (container) container.scrollTop = container.scrollHeight;
  }, [messages, expanded]);

  return <div className={`ea-agent-chat${messages.length ? " has-messages" : ""}`}>
    <div ref={messagesRef} className="ea-agent-scroll">
      <div className="ea-agent-conversation">
        {!messages.length && <div className="ea-agent-welcome">
          <AgentMark className="ea-agent-welcome-orb" />
          <h2>Hi，EA有什么可以帮您？</h2>
          {showPrompts && <section aria-label="常用问题" className="ea-agent-prompts"><div className="ea-agent-prompt-grid">{PROMPTS.map(({ icon: Icon, question }) => <button type="button" key={question} aria-label={`发送常用问题：${question}`} onClick={() => onSend(question)}><span><Icon size={15} />{question}</span><ArrowUpRight size={13} /></button>)}</div></section>}
        </div>}
        <div role="log" aria-label="EA Agent 对话记录" aria-live="polite" aria-relevant="additions" className="ea-agent-messages">
          {messages.map((message) => <article key={message.id} className={`ea-agent-message ${message.role === "user" ? "is-user" : "is-ai"}`} aria-label={message.role === "user" ? "我的消息" : "EA Agent 回复"}>
            {message.role === "ai" && <div className="ea-agent-message-label"><AgentMark className="ea-agent-message-orb" />EA Agent</div>}
            <p>{message.text}</p>
            {message.role === "ai" && !!message.generatedFileIds?.length && <ul className="ea-agent-files" aria-label="生成的文件">
              {AGENT_DEMO_FILES.filter(file => message.generatedFileIds?.includes(file.id)).map(file => {
                const downloadKey = `${message.createdAt}:${message.id}:${file.id}`;
                const content = `\uFEFF${file.content}`;
                return <li key={file.id} className="ea-agent-file">
                  <span className={`ea-agent-file-icon${file.format === "CSV" ? " is-sheet" : ""}`} aria-hidden="true">{file.format === "CSV" ? <FileSpreadsheet size={21} /> : <FileText size={21} />}</span>
                  <div className="ea-agent-file-info"><strong title={file.name}>{file.name}</strong><span>{file.format} · {(new Blob([content]).size / 1024).toFixed(1)} KB{downloadedFiles[downloadKey] && <span className="ea-agent-file-status" role="status">已发起下载</span>}</span></div>
                  <a className="ea-agent-file-download" href={`data:${file.mime};charset=utf-8,${encodeURIComponent(content)}`} download={file.name} aria-label={`下载 ${file.name}`} title={`下载 ${file.name}`} onClick={() => setDownloadedFiles(current => ({ ...current, [downloadKey]: true }))}><Download size={17} /></a>
                </li>;
              })}
            </ul>}
            {message.role === "ai" && <div className="ea-agent-message-actions" aria-label="回复操作">
              <time dateTime={message.createdAt}>{formatMessageTime(message.createdAt)}</time>
              <button type="button" aria-label={copiedMessageId === message.id ? "已复制回复" : "复制回复"} title={copiedMessageId === message.id ? "已复制" : "复制"} onClick={async () => { if (await copyMessage(message.text)) setCopiedMessageId(message.id); }}>{copiedMessageId === message.id ? <Check size={14} /> : <Copy size={14} />}</button>
              <button type="button" aria-label="赞同此回复" title="赞同" aria-pressed={feedback[message.id] === "up"} onClick={() => setFeedback(current => ({ ...current, [message.id]: current[message.id] === "up" ? undefined : "up" }))}><ThumbsUp size={14} /></button>
              <button type="button" aria-label="不赞同此回复" title="不赞同" aria-pressed={feedback[message.id] === "down"} onClick={() => setFeedback(current => ({ ...current, [message.id]: current[message.id] === "down" ? undefined : "down" }))}><ThumbsDown size={14} /></button>
            </div>}
          </article>)}
        </div>
      </div>
    </div>
    <form className="ea-agent-compose" onSubmit={(event) => { event.preventDefault(); if (!composing.current && !isRunning) onSend(draft); }}>
      <div className={`ea-agent-composer${isRunning ? " is-running" : ""}`} aria-busy={isRunning}>
        <span role="status" className="sr-only">{isRunning ? "EA Agent 正在运行" : ""}</span>
        {composerTools && <div className="ea-agent-composer-skills">{composerTools}</div>}
        <textarea ref={inputRef} aria-label="发送给 EA Agent 的消息" placeholder="请输入..." value={draft} rows={3} maxLength={AGENT_MAX_MESSAGE}
          onChange={(event) => onDraftChange(event.target.value)} onCompositionStart={() => { composing.current = true; }} onCompositionEnd={() => { composing.current = false; }}
          onKeyDown={(event) => { if (event.key === "Enter" && !event.shiftKey && !composing.current && !event.nativeEvent.isComposing && event.keyCode !== 229) { event.preventDefault(); if (!isRunning) onSend(draft); } }} />
        <div className="ea-agent-composer-tools"><button type="submit" aria-label="发送消息" title={isRunning ? "正在运行" : "发送消息"} disabled={isRunning || !draft.trim()}>{isRunning ? <LoaderCircle size={17} className="ea-agent-running-icon" /> : <ArrowUp size={17} />}</button></div>
      </div>
    </form>
  </div>;
}
