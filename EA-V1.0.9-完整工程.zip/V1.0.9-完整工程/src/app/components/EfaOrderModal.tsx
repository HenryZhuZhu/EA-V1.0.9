import { useState } from "react";
import { FlaskConical, Plus, X, Check } from "lucide-react";
import { EfaAnalysisCard, genEfaCode } from "./data";

// EFA 分析单弹框：从 EFA分析任务打开，填写字段并确认后回到任务卡片。
// 未点击任务卡片确认前，可再次打开本弹框重新编辑。确认时若无单号则生成一个 EFA 工单号。

// 可复用的 EFA 表单主体（分析对象 + component/wafer 字段 + chiplist）——供弹框与思维导图节点内联复用。
export function EfaInlineFields({ value, onChange }: { value: EfaAnalysisCard; onChange: (v: EfaAnalysisCard) => void }) {
  const draft = value;
  const setField = (key: keyof EfaAnalysisCard, next: any) => onChange({ ...draft, [key]: next });
  const fields = draft.chipList ?? [];
  const updateChip = (index: number, key: string, next: string) =>
    onChange({ ...draft, chipList: fields.map((chip, i) => (i === index ? { ...chip, [key]: next } : chip)) });
  const inputClass = "w-full h-8 px-2 text-[11px] bg-white border border-slate-200 rounded outline-none focus:border-violet-500";
  return (
    <div className="space-y-3">
      <div>
        <div className="text-[10px] text-slate-500 mb-1.5">分析对象</div>
        <div className="grid grid-cols-2 gap-2">
          {(["component", "wafer"] as const).map((mode) => (
            <button
              key={mode}
              type="button"
              onClick={() => setField("mode", mode)}
              className={`h-9 rounded-lg border text-[12px] font-semibold transition-colors ${draft.mode === mode ? "border-violet-500 bg-violet-600 text-white" : "border-slate-200 bg-white text-slate-600 hover:border-violet-300"}`}
            >
              {mode}
            </button>
          ))}
        </div>
      </div>

      {!draft.mode && (
        <div className="rounded-lg border border-dashed border-violet-200 bg-violet-50/50 px-3 py-5 text-center text-[11px] text-violet-700">请先选择 component 或 wafer</div>
      )}

      {draft.mode === "component" && (
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-2.5">
            {([
              ["standard", "standard"],
              ["stage", "stage"],
              ["package", "package"],
              ["quality", "quality"],
              ["failRate", "fail rate"],
            ] as [keyof EfaAnalysisCard, string][]).map(([key, label]) => (
              <label key={String(key)} className="text-[10.5px] text-slate-500">
                {label}
                <input value={String(draft[key] ?? "")} onChange={(e) => setField(key, e.target.value)} placeholder={`请输入 ${label}`} className={`mt-1 ${inputClass}`} />
              </label>
            ))}
          </div>
          <div className="pt-2 border-t border-slate-100">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10.5px] font-semibold text-slate-600">chiplist</span>
              <button
                type="button"
                onClick={() => setField("chipList", [...fields, { fsa: "", map: "", failMode: "", waferNo: "", chipNo: "", markCode: "" }])}
                className="text-[10.5px] text-violet-600 hover:text-violet-800 inline-flex items-center gap-0.5"
              >
                <Plus size={11} /> 添加颗粒
              </button>
            </div>
            <div className="space-y-2">
              {fields.map((chip, index) => (
                <div key={index} className="rounded-lg bg-slate-50 border border-slate-100 p-2">
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-[9.5px] text-slate-400">#{index + 1}</span>
                    {fields.length > 1 && (
                      <button type="button" onClick={() => setField("chipList", fields.filter((_, i) => i !== index))} className="text-slate-300 hover:text-red-500"><X size={12} /></button>
                    )}
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    {([
                      ["fsa", "fsa"], ["map", "map"], ["failMode", "fail mode"],
                      ["waferNo", "waferno"], ["chipNo", "chipno"], ["markCode", "markcode"],
                    ] as const).map(([key, label]) => (
                      <label key={key} className="text-[9.5px] text-slate-400">
                        {label}
                        <input value={chip[key] || ""} onChange={(e) => updateChip(index, key, e.target.value)} className={`mt-0.5 ${inputClass}`} />
                      </label>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {draft.mode === "wafer" && (
        <div className="grid grid-cols-2 gap-2.5">
          {([
            ["stage", "stage"], ["bin", "bin"], ["fsa", "fsa"], ["map", "map"], ["chipNo", "chipno"],
          ] as [keyof EfaAnalysisCard, string][]).map(([key, label]) => (
            <label key={String(key)} className="text-[10.5px] text-slate-500">
              {label}
              <input value={String(draft[key] ?? "")} onChange={(e) => setField(key, e.target.value)} className={`mt-1 ${inputClass}`} />
            </label>
          ))}
        </div>
      )}
    </div>
  );
}

export function EfaOrderModal({
  taskTitle,
  value,
  onConfirm,
  onCancel,
}: {
  taskTitle?: string;
  value?: EfaAnalysisCard;
  onConfirm: (value: EfaAnalysisCard) => void;
  onCancel: () => void;
}) {
  const clone = (v?: EfaAnalysisCard): EfaAnalysisCard => ({
    ...(v || {}),
    chipList: (v?.chipList?.length ? v.chipList : [{ fsa: "", map: "", failMode: "", waferNo: "", chipNo: "", markCode: "" }]).map((x) => ({ ...x })),
  });
  const [draft, setDraft] = useState<EfaAnalysisCard>(() => clone(value));
  const setField = (key: keyof EfaAnalysisCard, next: any) => setDraft((prev) => ({ ...prev, [key]: next }));
  const updateChip = (index: number, key: string, next: string) =>
    setDraft((prev) => ({ ...prev, chipList: (prev.chipList ?? []).map((chip, i) => (i === index ? { ...chip, [key]: next } : chip)) }));
  const fields = draft.chipList ?? [];
  const inputClass = "w-full h-8 px-2 text-[11px] bg-white border border-slate-200 rounded outline-none focus:border-violet-500";
  const confirm = () => onConfirm({ ...draft, code: draft.code || genEfaCode() });

  return (
    <div className="fixed inset-0 z-[90] bg-slate-900/45 flex items-center justify-center p-6" onClick={onCancel}>
      <div className="w-[540px] max-h-[86vh] overflow-y-auto bg-white rounded-xl border border-slate-200 shadow-2xl" onClick={(e) => e.stopPropagation()}>
        <div className="px-4 py-3 border-b border-violet-100 bg-gradient-to-r from-violet-50 to-fuchsia-50 flex items-center gap-2.5">
          <span className="w-8 h-8 rounded-lg bg-violet-600 text-white grid place-items-center shrink-0"><FlaskConical size={15} /></span>
          <div className="min-w-0">
            <div className="text-[13px] font-bold text-slate-800">提 EFA 分析单</div>
            {taskTitle && <div className="text-[10.5px] text-slate-500 truncate">来源：{taskTitle}</div>}
          </div>
          {draft.code && <span className="ml-auto font-mono text-[11px] text-violet-600 bg-white/70 border border-violet-200 rounded px-2 py-0.5">{draft.code}</span>}
          <button onClick={onCancel} className="ml-1 text-slate-400 hover:text-slate-600 shrink-0"><X size={16} /></button>
        </div>

        <div className="p-4">
          <EfaInlineFields value={draft} onChange={setDraft} />
        </div>

        <div className="px-4 py-3 border-t border-slate-100 flex justify-end gap-2">
          <button onClick={onCancel} className="h-8 px-3 rounded-md border border-slate-200 text-xs text-slate-600 hover:bg-slate-50">取消</button>
          <button disabled={!draft.mode} onClick={confirm} className="h-8 px-3.5 rounded-md bg-violet-600 text-white text-xs font-medium hover:bg-violet-700 disabled:opacity-40 inline-flex items-center gap-1.5">
            <Check size={13} /> 确认
          </button>
        </div>
      </div>
    </div>
  );
}
