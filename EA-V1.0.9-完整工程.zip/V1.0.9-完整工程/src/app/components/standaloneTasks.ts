import { useEffect, useState } from "react";
import { CaseItem, currentUser, departments, flattenTasks, ownerToDepartment, Participant, productById, PROBLEM_DOMAINS, PROBLEM_TYPES, type ProblemDomain, type ProblemType, type TaskComment, TaskNode, Urgency } from "./data";
import { allProjects, caseByStandaloneTask, createManualCase } from "./domainStore";
import { DEMO_TASK_FORCES, resolveStandaloneAssignment, taskTypeHasKR, TASK_INVOLVEMENT_KINDS, type TaskAssignmentMethod, type TaskInvolvement, type TaskInvolvementKind } from "./standaloneTaskConfig";
import { addTaskComment, cloneTaskActivities, cloneTaskComments, recordTaskChange, taskActivity, type TaskActivity } from "./taskActivity";
import { normalizeTaskVisibility, type TaskVisibility } from "./taskVisibility";
import { activeRecovery, validateRecoveryAction, finishRecovery, trackRecoveryEdit, startRecovery, supplementRecord, type RecoveryAction, type RecoveryEntry, type RecoveryFile } from "./recordRecovery";

export type StandaloneTaskStatus = TaskNode["status"];
export type TaskCreationMode = "simple" | "advanced";

export interface StandaloneTask {
  id: string;
  recovery?: RecoveryEntry[];
  code: string;
  title: string;
  description: string;
  owner: string;
  createdBy: string;
  creationMode?: TaskCreationMode;
  assignmentMethod?: TaskAssignmentMethod;
  visibility?: TaskVisibility; // 仅持久化范围设置，访问控制待与 Case 统一完善。
  initiatingDepartment?: string; // 旧任务无此字段时按原创建人显示，不重分派历史任务。
  handlingDepartment?: string;
  involvement?: TaskInvolvement;
  problemDomain?: ProblemDomain;
  problemType?: ProblemType;
  createdForOther: boolean;
  collaborators: Participant[];
  urgency: Urgency;
  dueDate: string;
  attachments: NonNullable<CaseItem["caseAttachments"]>;
  voiceNote?: string;
  status: StandaloneTaskStatus;
  rejectReason?: string;
  terminateReason?: string;
  reworkReason?: string;
  conclusion?: string;
  analysisProcess?: string;
  resultAttachments?: StandaloneTask["attachments"];
  createdAt: string;
  updatedAt: string;
  convertedCaseId?: string;
  activityLog?: TaskActivity[];
  comments?: TaskComment[];
}

export interface CreateStandaloneTaskInput {
  productByAssignment?: boolean;
  title: string;
  description: string;
  owner: string;
  creationMode?: TaskCreationMode;
  assignmentMethod?: TaskAssignmentMethod;
  handlingDepartment?: string; // 按部门找负责人时要求；按分类找人时自动推导。
  visibilityType?: TaskVisibility["type"];
  visiblePeople?: string[];
  involvement?: TaskInvolvementKind;
  involvementId?: string;
  problemDomain?: ProblemDomain | "";
  problemType?: ProblemType | "";
  createdForOther: boolean;
  collaborators: string[];
  urgency: Urgency;
  dueDate: string;
  attachments: StandaloneTask["attachments"];
  voiceNote?: string;
}

const KEY = "ea_standalone_tasks_v1";
let cache: StandaloneTask[] | null = null;
const listeners = new Set<() => void>();
const TASK_STATUSES = new Set<string>(["待接受", "进行中", "已拒绝", "已完成", "已中止"]);

export function standaloneTaskDisplayStatus(task: StandaloneTask) {
  return task.convertedCaseId ? "已升级为 Case" : task.status;
}

export function hasAdvancedTaskInformation(task: StandaloneTask) {
  return task.creationMode === "advanced" || (!task.creationMode && Boolean(task.handlingDepartment || task.involvement || task.problemDomain || task.problemType));
}

function normalizeSavedTask(task: Omit<StandaloneTask, "status"> & { status: string }): StandaloneTask {
  if (TASK_STATUSES.has(task.status)) return task as StandaloneTask;
  if (task.status === "待处理" || task.status === "待开始") return { ...task, status: "待接受" };
  // 兼容旧版升级时写入的“已关闭”；关联标记独立于执行状态。
  const linkedCase = task.convertedCaseId ? caseByStandaloneTask(task.id) : undefined;
  const imported = linkedCase ? flattenTasks(linkedCase.tasks).find(({ task: node }) => node.sourceStandaloneTaskId === task.id)?.task : undefined;
  const status = imported?.status && TASK_STATUSES.has(imported.status) ? imported.status : task.conclusion?.trim() ? "已完成" : "已中止";
  return { ...task, status };
}

function exampleTasks(): StandaloneTask[] {
  const now = new Date();
  const localDate = (date: Date) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
  const codeDate = localDate(now).slice(2).replace(/-/g, "");
  const examples: { title: string; description: string; createdBy: string; collaborators: string[]; urgency: Urgency; days: number; status: "待接受" | "进行中" }[] = [
    {
      title: "周例会材料整理",
      description: "汇总本周任务进展、待协调事项和下周计划，整理为一份周例会材料，并与刘洋确认内容完整。",
      createdBy: "刘洋", collaborators: ["李娜"], urgency: "紧急", days: 1, status: "待接受",
    },
    {
      title: "下周样品复测排期确认",
      description: "核对待复测样品清单、机台空闲时段和参与人员，确认下周排期后同步给相关同事。",
      createdBy: "李娜", collaborators: ["周杰"], urgency: "一般", days: 2, status: "待接受",
    },
    {
      title: "测试机台点检 Checklist 更新",
      description: "检查现有点检清单中的校准日期、维护联系人及记录项，补齐遗漏内容并整理最新版 Checklist。",
      createdBy: "周杰", collaborators: [], urgency: "一般", days: 3, status: "待接受",
    },
    {
      title: "实验室耗材库存核对",
      description: "核对样品标签、防静电袋和清洁耗材的剩余数量，整理需要补充的品项及数量，提交采购需求。",
      createdBy: currentUser.name, collaborators: ["李娜"], urgency: "一般", days: 2, status: "进行中",
    },
    {
      title: "本周工作记录归档",
      description: "整理本周会议纪要、测试记录和交接说明，统一文件命名并归档到对应共享目录。",
      createdBy: currentUser.name, collaborators: [], urgency: "不紧急", days: 4, status: "进行中",
    },
    // 仅在末尾追加，保留既有范例 ID 与用户已处理的状态。
    {
      title: "跨部门评审会议资料收集",
      description: "收集 PTE、DA 同事的评审材料，核对版本、负责人及待确认问题，整理完整资料包供会议使用。",
      createdBy: "刘洋", collaborators: ["李娜"], urgency: "紧急", days: 1, status: "待接受",
    },
    {
      title: "样品借用与归还清单确认",
      description: "核对本周借出样品的编号、借用人和预计归还日期，与相关同事确认缺失信息并更新清单。",
      createdBy: "李娜", collaborators: ["周杰"], urgency: "一般", days: 2, status: "待接受",
    },
    {
      title: "新人实验室入场准备",
      description: "确认新人培训时间、实验室门禁及防静电用品，汇总待办理事项并同步入场安排。",
      createdBy: "周杰", collaborators: [], urgency: "一般", days: 3, status: "待接受",
    },
    {
      title: "测试数据共享目录整理",
      description: "检查近期测试数据的文件命名和目录归属，整理重复文件与待补充说明，完成后同步目录索引。",
      createdBy: currentUser.name, collaborators: ["周杰"], urgency: "紧急", days: 1, status: "进行中",
    },
    {
      title: "常用测试脚本使用说明更新",
      description: "补充常用测试脚本的输入参数、运行步骤和常见问题，与李娜核对示例后保存最新版使用说明。",
      createdBy: currentUser.name, collaborators: ["李娜"], urgency: "一般", days: 3, status: "进行中",
    },
    {
      title: "下周设备维护窗口协调",
      description: "汇总设备维护需求和测试排期，确认可用维护窗口及联系人，将协调结果同步给相关人员。",
      createdBy: currentUser.name, collaborators: ["周杰"], urgency: "一般", days: 4, status: "进行中",
    },
  ];
  return examples.map((example, index) => {
    const due = new Date(now);
    due.setDate(due.getDate() + example.days);
    return {
      id: `standalone-example-v108-${index + 1}`,
      code: `TASK-${codeDate}-DEMO${String(index + 1).padStart(4, "0")}`,
      title: example.title, description: example.description,
      owner: currentUser.name, createdBy: example.createdBy,
      createdForOther: example.createdBy !== currentUser.name,
      collaborators: example.collaborators.filter((name) => name !== currentUser.name).map((name) => ({ name, department: ownerToDepartment[name] ?? "—" })),
      urgency: example.urgency, dueDate: localDate(due), attachments: [], status: example.status,
      createdAt: now.toISOString(), updatedAt: now.toISOString(),
    };
  });
}

function load(): StandaloneTask[] {
  if (cache) return cache;
  try {
    const raw = typeof localStorage !== "undefined" ? localStorage.getItem(KEY) : null;
    const saved = raw ? JSON.parse(raw) : [];
    cache = Array.isArray(saved) ? saved.map(normalizeSavedTask) : [];
    const migrated = Array.isArray(saved) && cache!.some((task, index) => task.status !== saved[index].status);
    // 按固定 ID 补充范例，已有用户任务和已操作过的范例保持原样。
    const existingIds = new Set(cache!.map((task) => task.id));
    const missing = exampleTasks().filter((task) => !existingIds.has(task.id));
    if (missing.length || migrated) {
      cache = [...cache!, ...missing];
      try {
        if (Array.isArray(saved) && typeof localStorage !== "undefined") localStorage.setItem(KEY, JSON.stringify(cache));
      } catch { /* 存储不可用时仍展示范例；后续操作沿用显式保存错误提示。 */ }
    }
  } catch {
    cache = [];
  }
  return cache!;
}

function commit(next: StandaloneTask[]) {
  try {
    localStorage.setItem(KEY, JSON.stringify(next));
  } catch {
    throw new Error("未能保存任务，请检查浏览器存储空间或减小附件后重试。");
  }
  cache = next;
  listeners.forEach((listener) => listener());
}

function taskCode() {
  const date = new Date().toISOString().slice(2, 10).replace(/-/g, "");
  const sequence = crypto.randomUUID().replace(/-/g, "").slice(0, 8).toUpperCase();
  return `TASK-${date}-${sequence}`;
}

function saveTaskChange(task: StandaloneTask, next: StandaloneTask, kind: TaskActivity["kind"], summary: string, detail?: string) {
  next = trackRecoveryEdit(task, next);
  const recorded = recordTaskChange(task, next, kind, summary, detail);
  if (recorded === task) return task; // 未改动的显式保存不制造日志，也不修改更新时间。
  const saved = { ...recorded, updatedAt: recorded.activityLog!.at(-1)!.at };
  commit(load().map((item) => item.id === task.id ? saved : item));
  return saved;
}

function normalizeStandaloneTaskInput(input: CreateStandaloneTaskInput, existing?: StandaloneTask) {
  if (!input.title.trim() || !input.description.trim() || !input.dueDate || Number.isNaN(Date.parse(input.dueDate))) {
    throw new Error("请填写任务名称、任务说明、负责人和有效的截止日期。");
  }
  // 兼容上一版直接传部门的调用；新表单始终显式提交模式。
  const creationMode = input.creationMode ?? (input.handlingDepartment === undefined ? "simple" : "advanced");
  if (creationMode !== "simple" && creationMode !== "advanced") throw new Error("请选择有效的任务创建模式。");
  let owner = input.owner.trim();
  let handlingDepartment = ownerToDepartment[owner];
  let assignmentMethod: TaskAssignmentMethod | undefined;
  let problemDomain: ProblemDomain | undefined;
  let problemType: ProblemType | undefined;
  const conditionalProduct = creationMode === "advanced" && input.assignmentMethod === "domain-type";
  if (input.productByAssignment && conditionalProduct && (input.involvement !== "产品" || !productById(input.involvementId))) throw new Error("按 Domain + 类型选人时必须选择关联产品。");
  const sameAssignment = existing && creationMode === (existing.creationMode ?? "simple") && input.assignmentMethod === existing.assignmentMethod && input.handlingDepartment === existing.handlingDepartment && (input.problemDomain || undefined) === existing.problemDomain && (input.problemType || undefined) === existing.problemType && owner === existing.owner;
  if (sameAssignment) {
    handlingDepartment = existing.handlingDepartment;
    assignmentMethod = existing.assignmentMethod;
    problemDomain = existing.problemDomain;
    problemType = existing.problemType;
  } else if (creationMode === "advanced") {
    if (input.assignmentMethod !== undefined && !["department", "domain-type"].includes(input.assignmentMethod)) throw new Error("请选择有效的负责人确定方式。");
    const byDepartment = input.assignmentMethod === "department";
    const byClassification = input.assignmentMethod === "domain-type";
    if (!byClassification && (!input.handlingDepartment || !departments.includes(input.handlingDepartment))) throw new Error("请选择处理部门。");
    if (!byDepartment) {
      if (input.problemDomain && !PROBLEM_DOMAINS.includes(input.problemDomain)) throw new Error("请选择有效的 Domain。");
      if (input.problemType && !PROBLEM_TYPES.includes(input.problemType)) throw new Error("请选择有效的类型。");
      if (byClassification && (!input.problemDomain || !input.problemType)) throw new Error("请同时选择 Domain 与类型以确定负责人。");
      if (input.productByAssignment && byClassification && !taskTypeHasKR(input.problemDomain || "", input.problemType || "")) throw new Error("所选类型暂无 KR 信息，请选择其他类型。");
      problemDomain = input.problemDomain || undefined; problemType = input.problemType || undefined;
    }
    const assignment = resolveStandaloneAssignment(problemDomain || "", problemType || "", input.handlingDepartment || "", input.productByAssignment && byClassification ? input.involvementId : "");
    if (!assignment) throw new Error("未找到对应的负责人配置，请检查部门或 Domain 与类型。");
    // 新表单高级模式只按条件找人，忽略简单模式残留的负责人；兼容旧调用的手动覆盖。
    owner = input.assignmentMethod ? assignment.owner : owner || assignment.owner;
    handlingDepartment = assignment.department;
    if (ownerToDepartment[owner] !== handlingDepartment) throw new Error("请选择处理部门内的任务负责人。");
    assignmentMethod = input.assignmentMethod ?? (assignment.source === "domain-type" ? "domain-type" : "department");
  }
  // 任务涉及和可见范围属于共有信息，与找负责人的方式无关。
  const kind = input.productByAssignment && !conditionalProduct ? "无" : input.involvement ?? "无";
  if (!TASK_INVOLVEMENT_KINDS.includes(kind)) throw new Error("请选择有效的任务涉及范围。");
  let involvement: TaskInvolvement = { kind: "无" };
  if (existing?.involvement?.kind === kind && (kind === "无" || (existing.involvement.kind !== "无" && existing.involvement.id === input.involvementId))) {
    involvement = { ...existing.involvement };
  } else if (kind !== "无") {
    const reference = kind === "产品" ? productById(input.involvementId) : kind === "Project" ? allProjects().find((item) => item.id === input.involvementId) : DEMO_TASK_FORCES.find((item) => item.id === input.involvementId);
    if (!reference) throw new Error(`请选择任务涉及的${kind}。`);
    involvement = { kind, id: reference.id, name: "code" in reference ? `${reference.code} · ${reference.name}` : reference.name };
  }
  const visibility = normalizeTaskVisibility(input.visibilityType, input.visiblePeople);
  // 简单模式只认直接选择的负责人，不执行隐藏的分派条件。
  if (!owner) throw new Error("请填写任务负责人。");
  return {
    title: input.title.trim(), description: input.description.trim(), owner,
    creationMode: sameAssignment ? existing.creationMode : creationMode,
    assignmentMethod, handlingDepartment, problemDomain, problemType,
    involvement: existing && !existing.involvement && kind === "无" ? undefined : involvement,
    visibility: existing && !existing.visibility && visibility.type === "all" ? undefined : visibility,
    collaborators: input.productByAssignment ? [] : [...new Set(input.collaborators.map((name) => name.trim()))].filter((name) => name && name !== owner).map((name) => existing?.collaborators.find(person => person.name === name) ?? ({ name, department: ownerToDepartment[name] ?? "—" })),
    urgency: input.urgency, dueDate: input.dueDate,
    attachments: input.attachments.map(attachment => ({ ...attachment })), voiceNote: input.voiceNote,
  };
}

export function createStandaloneTask(input: CreateStandaloneTaskInput) {
  const normalized = normalizeStandaloneTaskInput(input);
  const owner = normalized.owner;
  const now = new Date().toISOString();
  const task: StandaloneTask = {
    ...normalized,
    id: `standalone-${crypto.randomUUID()}`,
    code: taskCode(),
    createdBy: currentUser.name,
    initiatingDepartment: currentUser.department || ownerToDepartment[currentUser.name] || "—",
    createdForOther: owner !== currentUser.name,
    status: owner === currentUser.name ? "进行中" : "待接受",
    createdAt: now,
    updatedAt: now,
    activityLog: [taskActivity("create", "创建任务", [
      { field: "负责人", before: "未分派", after: owner },
      { field: "状态", before: "未创建", after: owner === currentUser.name ? "进行中" : "待接受" },
    ], undefined, now)],
    comments: [],
  };
  commit([task, ...load()]);
  return task;
}

export function standaloneTaskById(id: string) {
  return load().find((task) => task.id === id);
}

export function standaloneTaskEditDisabledReason(task?: StandaloneTask) {
  if (!task) return "任务不存在。";
  if (task.convertedCaseId || caseByStandaloneTask(task.id)) return "任务已升级为 Case，请在关联 Case 中处理。";
  if (!["待接受", "进行中"].includes(task.status)) return "仅待接受或进行中的自由任务可以编辑。";
  if (task.owner !== currentUser.name && task.createdBy !== currentUser.name) return "仅任务负责人或创建人可以编辑。";
  return "";
}

export function editStandaloneTask(id: string, input: CreateStandaloneTaskInput, expected: StandaloneTask) {
  const task = standaloneTaskById(id);
  const blocked = standaloneTaskEditDisabledReason(task);
  if (blocked) throw new Error(blocked);
  if (!expected || JSON.stringify(task) !== JSON.stringify(expected)) throw new Error("任务已更新，请返回详情后重新编辑。");
  if (!["非常紧急", "紧急", "一般", "不紧急"].includes(input.urgency)) throw new Error("请选择有效的紧急程度。");
  const deadline = new Date(`${input.dueDate}T00:00:00Z`);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(input.dueDate) || !Number.isFinite(deadline.getTime()) || deadline.toISOString().slice(0, 10) !== input.dueDate) throw new Error("请选择有效的截止日期。");
  const normalized = normalizeStandaloneTaskInput(input, task!);
  const reassigned = normalized.owner !== task!.owner;
  return saveTaskChange(task!, {
    ...task!, ...normalized,
    createdForOther: reassigned ? normalized.owner !== task!.createdBy : task!.createdForOther,
    status: reassigned ? "待接受" : task!.status,
  }, "edit", "编辑自由任务");
}

export function updateStandaloneTaskStatus(id: string, status: StandaloneTaskStatus, rejectReason?: string) {
  const task = standaloneTaskById(id);
  if (!task || task.convertedCaseId) throw new Error("该任务已升级为 Case 或不存在，无法继续操作。");
  if (task.owner !== currentUser.name) throw new Error("仅任务负责人可以更新任务状态。");
  if (status === "已完成") throw new Error("请填写任务结论并提交结果后完成任务。");
  if (!(task.status === "待接受" && (status === "进行中" || status === "已拒绝"))) throw new Error("当前任务不支持此状态操作。");
  if (status === "已拒绝" && !rejectReason?.trim()) throw new Error("请填写拒绝理由。");
  saveTaskChange(task, { ...task, status, rejectReason: status === "已拒绝" ? rejectReason!.trim() : undefined }, "status", status === "进行中" ? "接受并开始任务" : "拒绝任务");
}

export function commentOnStandaloneTask(id: string, content: string, replyTo?: string) {
  const task = standaloneTaskById(id);
  if (!task) throw new Error("任务不存在。");
  if (task.convertedCaseId || caseByStandaloneTask(id)) throw new Error("任务已升级为 Case，请在关联 Case 任务中继续讨论。");
  const comments = addTaskComment(task.comments, content, replyTo);
  const event = taskActivity("comment", replyTo ? "回复评论" : "发表评论");
  const saved = { ...task, comments, activityLog: [...(task.activityLog ?? []), event], updatedAt: event.at };
  commit(load().map((item) => item.id === id ? saved : item));
  return saved;
}

export interface StandaloneTaskWorkspaceInput {
  conclusion: string;
  analysisProcess: string;
  resultAttachments?: StandaloneTask["attachments"];
}

export function saveStandaloneTaskWorkspace(id: string, workspace: StandaloneTaskWorkspaceInput) {
  const task = standaloneTaskById(id);
  if (!task || task.convertedCaseId || task.status !== "进行中") throw new Error("仅进行中的自由任务可以编辑 Workspace 文档。");
  if (task.owner !== currentUser.name) throw new Error("仅任务负责人可以保存 Workspace 文档。");
  if (caseByStandaloneTask(id)) throw new Error("任务已带入 Case，请先重试升级以完成来源关联。");
  const next: StandaloneTask = {
    ...task, conclusion: workspace.conclusion.trim(), analysisProcess: workspace.analysisProcess,
    resultAttachments: (workspace.resultAttachments ?? task.resultAttachments ?? []).map((attachment) => ({ ...attachment })),
    updatedAt: new Date().toISOString(),
  };
  return saveTaskChange(task, next, "edit", "保存 Workspace 文档");
}

export function completeStandaloneTask(id: string, result: { conclusion: string; resultAttachments?: StandaloneTask["attachments"] }) {
  const task = standaloneTaskById(id);
  if (!task || task.convertedCaseId || task.status !== "进行中") throw new Error("仅进行中的自由任务可以提交结果。");
  if (task.owner !== currentUser.name) throw new Error("仅任务负责人可以提交任务结果。");
  if (!result.conclusion.trim()) throw new Error("请填写任务结论。");
  if (caseByStandaloneTask(id)) throw new Error("任务已带入 Case，请先重试升级以完成来源关联。");
  // 结论、结果附件和完成状态在同一次写入中保存，失败时保留原状态。
  saveTaskChange(task, finishRecovery({
    ...task, conclusion: result.conclusion.trim(),
    resultAttachments: (result.resultAttachments ?? task.resultAttachments ?? []).map((attachment) => ({ ...attachment })),
    status: "已完成" as const, updatedAt: new Date().toISOString(),
  }), "status", "完成任务");
}

export function canUpgradeStandaloneTask(task: StandaloneTask) {
  return task.status !== "已中止" && !task.convertedCaseId && task.owner === currentUser.name && !activeRecovery(task);
}

export function recoverStandaloneTask(id: string, action: RecoveryAction, text: string, files: RecoveryFile[] = [], dueDate?: string) {
  const task = standaloneTaskById(id);
  if (!task || task.convertedCaseId || caseByStandaloneTask(id)) throw new Error("该任务不存在或已升级，请在关联 Case 中处理。");
  validateRecoveryAction(task.owner, action);
  if ((action === "reopen" || action === "supplement") && task.status !== "已完成") throw new Error("仅已完成任务支持此操作。");
  if (action === "return" && !["进行中", "已完成"].includes(task.status)) throw new Error("当前任务不支持此操作。");
  const next = action === "supplement" ? supplementRecord(task, text, files) : { ...startRecovery(task, action, text, [task.owner, task.createdBy], dueDate), status: "进行中" as const };
  const summary = { reopen: "主管确认重新处理", return: "退回整改", supplement: "补充记录" }[action];
  const event = taskActivity(action === "reopen" || action === "return" ? "status" : "edit", summary, [], text.trim());
  const saved = { ...next, activityLog: [...(task.activityLog ?? []), event], updatedAt: event.at };
  commit(load().map(item => item.id === id ? saved : item));
  return saved;
}

export function standaloneReworkDisabledReason(task: StandaloneTask) {
  return "退回重做已取消。";
}

export function returnStandaloneTaskForRework(id: string, reason: string) {
  throw new Error("退回重做已取消。");
}

export function terminateStandaloneTask(id: string, reason: string, resultAttachments?: StandaloneTask["attachments"]) {
  const task = standaloneTaskById(id);
  if (!task || task.convertedCaseId || !["待接受", "进行中"].includes(task.status)) throw new Error("仅待接受或进行中的自由任务可以中止。");
  if (task.owner !== currentUser.name) throw new Error("仅任务负责人可以中止任务。");
  if (!reason.trim()) throw new Error("请填写中止原因。");
  if (caseByStandaloneTask(id)) throw new Error("任务已带入 Case，请先重试升级以完成来源关联。");
  saveTaskChange(task, {
    ...task, status: "已中止", terminateReason: reason.trim(),
    resultAttachments: (resultAttachments ?? task.resultAttachments ?? []).map((attachment) => ({ ...attachment })),
  }, "status", "中止任务");
}

export function upgradeStandaloneTaskToCase(id: string) {
  return upgradeStandaloneTasksToCase([id]);
}

export function prepareStandaloneTaskUpgrade(ids: string[]) {
  const selected = [...new Set(ids)].map(id => standaloneTaskById(id));
  if (!selected.length || selected.some(task => !task || !canUpgradeStandaloneTask(task))) throw new Error("请选择自己负责且未中止、未升级的自由任务。");
  const primary = selected[0]!;
  const description = selected.map(task => `${task!.title}（${task!.code}）\n${task!.description}`).join("\n\n");
  return {
    sourceStandaloneTaskIds: selected.map(task => task!.id),
    name: primary.title, reason: description, background: description,
    urgency: primary.urgency, dueDate: primary.dueDate,
    problemDomain: primary.problemDomain, problemType: primary.problemType,
    productIds: [...new Set(selected.flatMap(task => task!.involvement?.kind === "产品" ? [task!.involvement.id] : []))],
  };
}

type UpgradeCaseInput = Omit<Parameters<typeof createManualCase>[0], "tasks" | "sourceStandaloneTaskId" | "sourceStandaloneTaskIds"> & { tasks?: TaskNode[] };

export function upgradeStandaloneTasksToCase(ids: string[], details?: UpgradeCaseInput): CaseItem {
  const selectedIds = Array.from(new Set(ids));
  if (!selectedIds.length) throw new Error("请至少选择一条自由任务。");
  const selected = selectedIds.map((id) => {
    const task = standaloneTaskById(id);
    if (!task) throw new Error("所选任务不存在，请重新选择。");
    if (task.owner !== currentUser.name) throw new Error("只能选择自己负责的任务升级为 Case。");
    return task;
  });
  const existingCases = selected.map((task) => caseByStandaloneTask(task.id));
  const existingCase = existingCases.find(Boolean);
  if (existingCase) {
    const sourceIds = existingCase.sourceStandaloneTaskIds ?? [existingCase.sourceStandaloneTaskId!];
    if (selected.some((task, index) => !sourceIds.includes(task.id) || (existingCases[index] && existingCases[index]!.id !== existingCase.id) || (task.convertedCaseId && task.convertedCaseId !== existingCase.id))) {
      throw new Error("所选任务已关联其他 Case，请移除已升级的任务后重试。");
    }
    // 上次 Case 已保存但关联来源失败：必须恢复同一批次，不能另建 Case。
    const sources = sourceIds.map((id) => standaloneTaskById(id));
    if (sources.some((task) => !task || (task.convertedCaseId && task.convertedCaseId !== existingCase.id))) throw new Error("来源任务关联不一致，请检查原任务记录。");
    if (sources.every((task) => task!.convertedCaseId === existingCase.id)) return existingCase;
    if (sources.some((task) => task!.owner !== currentUser.name)) throw new Error("只能关联自己负责的任务，请由任务负责人重试。");
    linkSources(sourceIds, existingCase.id);
    return existingCase;
  }
  if (selected.some((task) => !canUpgradeStandaloneTask(task))) throw new Error("所选任务已中止或已升级，请重新选择。");

  const primary = selected[0];
  const now = new Date().toISOString();
  const participants = new Map<string, Participant>();
  selected.forEach((task) => {
    [{ name: task.owner, department: task.handlingDepartment ?? ownerToDepartment[task.owner] ?? "—" }, ...task.collaborators].forEach((person) => {
      if (person.name !== primary.owner) participants.set(person.name, { ...person });
    });
  });
  const description = selected.length === 1 ? primary.description : selected.map((task) => `${task.title}（${task.code}）\n${task.description}`).join("\n\n");
  const caseItem = createManualCase({
    name: primary.title, owner: primary.owner, createdBy: currentUser.name,
    createdForOther: primary.owner !== currentUser.name,
    participants: [...participants.values()],
    level: primary.urgency === "非常紧急" ? "L1" : primary.urgency === "紧急" ? "L2" : "L3",
    urgency: primary.urgency, dueDate: primary.dueDate,
    problemDomain: primary.problemDomain, problemType: primary.problemType,
    product: primary.involvement?.kind === "产品" ? primary.involvement.id : undefined,
    projectName: primary.involvement?.kind === "Project" ? primary.involvement.name : undefined,
    reason: description, background: description, source: "手动", material: "不适用",
    ...details,
    tasks: (caseCode) => [{
      id: `thought-${crypto.randomUUID()}`, title: "带入的自由任务", owner: "待指派",
      department: primary.handlingDepartment ?? ownerToDepartment[primary.owner] ?? "—", urgency: primary.urgency, progress: 0, status: "待接受",
      children: selected.map((task, index): TaskNode => ({
        id: `task-${crypto.randomUUID()}`, code: `${caseCode}.${String(index + 1).padStart(3, "0")}`,
        sourceStandaloneTaskId: task.id, title: task.title, expectation: task.description, conclusion: task.conclusion,
        analysisProcess: task.analysisProcess,
        recovery: task.recovery ? JSON.parse(JSON.stringify(task.recovery)) : undefined,
        reworkReason: task.reworkReason,
        comments: cloneTaskComments(task.comments),
        activityLog: [...cloneTaskActivities(task.activityLog), taskActivity("upgrade", "从自由任务带入 Case", [], `来源任务：${task.code}`, now)],
        owner: task.owner, supervisor: task.createdBy, department: task.handlingDepartment ?? ownerToDepartment[task.owner] ?? "—",
        standaloneTaskContext: { initiatingDepartment: task.initiatingDepartment ?? ownerToDepartment[task.createdBy], involvement: task.involvement ? { ...task.involvement } : undefined, problemDomain: task.problemDomain, problemType: task.problemType, visibility: task.visibility ? { ...task.visibility, people: [...task.visibility.people] } : undefined },
        collaborators: task.collaborators.map((person) => ({ ...person })),
        urgency: task.urgency, dueDate: task.dueDate, requestedDueDate: task.dueDate,
        status: task.status as TaskNode["status"], progress: task.status === "已完成" ? 100 : 0,
        rejectReason: task.rejectReason, attachments: [...task.attachments, ...(task.resultAttachments ?? [])].map((attachment) => ({ ...attachment })), voiceNote: task.voiceNote,
        // 来源没有真实状态历史时不根据 updatedAt 推造流转时间。
        statusHistory: (task.activityLog ?? []).flatMap((entry) => entry.changes.filter((change) => change.field === "状态" && TASK_STATUSES.has(change.after)).map((change) => ({ status: change.after as TaskNode["status"], at: entry.at, by: entry.by }))),
      })),
    }, ...(details?.tasks ?? [])],
    caseAttachments: [...(details?.caseAttachments ?? []), ...selected.flatMap((task) => [
      ...[...task.attachments, ...(task.resultAttachments ?? [])].map((attachment) => ({ ...attachment })),
      ...(task.voiceNote ? [{ name: `${task.code}-语音备注`, kind: "file" as const, url: task.voiceNote }] : []),
    ])],
    sourceStandaloneTaskIds: selectedIds,
  }, { strict: true });
  linkSources(selectedIds, caseItem.id, now);
  return caseItem;
}

function linkSources(ids: string[], caseId: string, at = new Date().toISOString()) {
  const selected = new Set(ids);
  commit(load().map((task) => selected.has(task.id) && task.convertedCaseId !== caseId ? {
    ...task, convertedCaseId: caseId, updatedAt: at,
    activityLog: [...(task.activityLog ?? []), taskActivity("upgrade", "升级为 Case", [{ field: "关联 Case", before: "未关联", after: caseId }], undefined, at)],
  } : task));
}

export function useStandaloneTasks() {
  const [, setTick] = useState(0);
  useEffect(() => {
    const listener = () => setTick((tick) => tick + 1);
    listeners.add(listener);
    return () => {
      listeners.delete(listener);
    };
  }, []);
  return load();
}