import {
  AlertTriangle,
  CheckCircle2,
  Clock,
  TrendingUp,
  Flame,
  Layers,
  ArrowUpRight,
} from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  CartesianGrid,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import { mockCases, levelColors, Level } from "./data";
import { CaseProductPill } from "./CaseProductPill";
import { CaseMarkCodePill } from "./CaseMarkCodePill";

interface Props {
  onOpenCase: (id: string) => void;
}

const trend = [
  { d: "04-16", n: 3 },
  { d: "04-17", n: 4 },
  { d: "04-18", n: 6 },
  { d: "04-19", n: 5 },
  { d: "04-20", n: 8 },
  { d: "04-21", n: 7 },
  { d: "04-22", n: 9 },
];

const matrix = [
  { name: "重要紧急", value: 4, color: "#E54545" },
  { name: "重要不紧急", value: 6, color: "#F7A000" },
  { name: "紧急不重要", value: 3, color: "#0052D9" },
  { name: "一般", value: 8, color: "#94A3B8" },
];

export function Dashboard({ onOpenCase }: Props) {
  const counts: Record<Level, number> = { L0: 0, L1: 0, L2: 0, L3: 0 };
  mockCases.forEach((c) => (counts[c.level] += 1));
  const priorityLabels: { key: Level; label: string; desc: string }[] = [
    { key: "L0", label: "L0 · 客户/生产中断", desc: "重大影响 / Gating" },
    { key: "L1", label: "L1 · 关键节点受影响", desc: "基本功能较大影响" },
    { key: "L2", label: "L2 · 基本功能失效", desc: "暂不影响关键节点" },
    { key: "L3", label: "L3 · 次要 / 优化改进", desc: "暂不影响关键节点" },
  ];

  return (
    <div className="p-6 space-y-5">
      <div className="flex items-end justify-between">
        <div>
          <h2 className="text-slate-900">工程师每日看板</h2>
          <p className="text-sm text-slate-500 mt-1">
            了解今天要推进的 Case、进度与风险；聚焦关键判断与决策。
          </p>
        </div>
        <div className="flex items-center gap-2 text-xs text-slate-500">
          <Clock size={14} /> 数据刷新于 2026-04-22 11:05
        </div>
      </div>

      {/* Priority counters */}
      <div className="grid grid-cols-5 gap-3">
        {priorityLabels.map((p) => (
          <div
            key={p.key}
            className="bg-white border border-slate-200 rounded-lg p-4 relative overflow-hidden group hover:shadow-sm hover:border-[#0052D9]/30 transition-all"
          >
            <div className="flex items-start justify-between">
              <div>
                <div className={`inline-flex items-center px-2 py-0.5 rounded border text-xs ${levelColors[p.key]}`}>
                  {p.label}
                </div>
                <div className="text-[11px] text-slate-400 mt-1.5">{p.desc}</div>
              </div>
              <ArrowUpRight size={14} className="text-slate-300 group-hover:text-[#0052D9]" />
            </div>
            <div className="mt-3 flex items-baseline gap-1.5">
              <span className="text-[28px] leading-none text-slate-900">{counts[p.key]}</span>
              <span className="text-xs text-slate-500">个 Case</span>
            </div>
            <div className="absolute -right-6 -bottom-6 w-20 h-20 rounded-full bg-gradient-to-br from-[#00A4FF]/5 to-[#0052D9]/10"></div>
          </div>
        ))}
      </div>

      {/* KPI row */}
      <div className="grid grid-cols-4 gap-3">
        <KpiCard icon={<Flame size={16} />} label="非常紧急" value="2" delta="+1" color="#E54545" />
        <KpiCard icon={<AlertTriangle size={16} />} label="临近到期 (≤3d)" value="3" delta="持平" color="#F7A000" />
        <KpiCard icon={<CheckCircle2 size={16} />} label="本周已闭环" value="12" delta="+4" color="#00B578" />
        <KpiCard icon={<TrendingUp size={16} />} label="平均闭环时长" value="3.8d" delta="-0.5d" color="#0052D9" />
      </div>

      <div className="grid grid-cols-3 gap-3">
        <div className="col-span-2 bg-white border border-slate-200 rounded-lg p-4">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h4 className="text-slate-900">Case 趋势 · 近 7 日</h4>
              <div className="text-xs text-slate-500 mt-0.5">新建 vs 闭环</div>
            </div>
            <div className="flex gap-3 text-xs">
              <span className="flex items-center gap-1.5"><i className="w-2 h-2 rounded-sm bg-[#0052D9]"/> 新建</span>
              <span className="flex items-center gap-1.5"><i className="w-2 h-2 rounded-sm bg-[#00B578]"/> 闭环</span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={trend}>
              <CartesianGrid strokeDasharray="3 3" stroke="#EEF0F3" vertical={false} />
              <XAxis dataKey="d" tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: "#94A3B8" }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ border: "1px solid #E2E8F0", borderRadius: 6, fontSize: 12 }} />
              <Line type="monotone" dataKey="n" stroke="#0052D9" strokeWidth={2} dot={{ r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white border border-slate-200 rounded-lg p-4">
          <h4 className="text-slate-900">重要-紧急矩阵</h4>
          <div className="text-xs text-slate-500 mt-0.5 mb-3">Case 数量分布</div>
          <ResponsiveContainer width="100%" height={180}>
            <PieChart>
              <Pie data={matrix} dataKey="value" innerRadius={45} outerRadius={70} paddingAngle={2}>
                {matrix.map((m, i) => <Cell key={i} fill={m.color} />)}
              </Pie>
              <Tooltip contentStyle={{ border: "1px solid #E2E8F0", borderRadius: 6, fontSize: 12 }} />
            </PieChart>
          </ResponsiveContainer>
          <div className="mt-2 space-y-1.5">
            {matrix.map((m) => (
              <div key={m.name} className="flex items-center justify-between text-xs">
                <span className="flex items-center gap-1.5 text-slate-600">
                  <i className="w-2 h-2 rounded-sm" style={{ background: m.color }} /> {m.name}
                </span>
                <span className="text-slate-500">{m.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* By due date */}
      <div className="bg-white border border-slate-200 rounded-lg">
        <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Layers size={16} className="text-[#0052D9]" />
            <h4 className="text-slate-900">按到期时间</h4>
          </div>
          <div className="flex gap-1.5 text-xs">
            {["今日到期", "3 日内", "5 日内", "一周内"].map((t, i) => (
              <button
                key={t}
                className={`px-2.5 py-1 rounded border ${i === 1 ? "bg-[#0052D9] text-white border-[#0052D9]" : "border-slate-200 text-slate-600 hover:bg-slate-50"}`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>
        <div className="divide-y divide-slate-100">
          {mockCases.slice(0, 4).map((c) => (
            <div
              key={c.id}
              onClick={() => onOpenCase(c.id)}
              className="px-4 py-3 flex items-center gap-3 hover:bg-slate-50 cursor-pointer"
            >
              <div className={`px-2 py-0.5 rounded text-xs border ${levelColors[c.level]}`}>{c.level}</div>
              <CaseProductPill caseItem={c} compact />
              <CaseMarkCodePill caseItem={c} compact />
              <div className="text-xs text-slate-400 font-mono">{c.code}</div>
              <div className="flex-1 text-sm text-slate-800 truncate">{c.name}</div>
              <div className="text-xs text-slate-500">Owner · {c.owner}</div>
              <div className={`text-xs px-2 py-0.5 rounded ${c.dueIn <= 2 ? "bg-red-50 text-red-600" : "bg-slate-100 text-slate-600"}`}>
                {c.dueIn} 天到期
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function KpiCard({ icon, label, value, delta, color }: any) {
  return (
    <div className="bg-white border border-slate-200 rounded-lg p-4 flex items-center gap-3">
      <div className="w-10 h-10 rounded-md flex items-center justify-center" style={{ background: `${color}15`, color }}>
        {icon}
      </div>
      <div>
        <div className="text-xs text-slate-500">{label}</div>
        <div className="flex items-baseline gap-1.5 mt-0.5">
          <span className="text-xl text-slate-900">{value}</span>
          <span className="text-xs" style={{ color }}>{delta}</span>
        </div>
      </div>
    </div>
  );
}
