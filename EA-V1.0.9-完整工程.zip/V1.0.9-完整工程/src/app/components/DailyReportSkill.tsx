import { useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowLeft,
  Ban,
  CalendarDays,
  CheckCircle2,
  Clock3,
  Download,
  FileText,
  LoaderCircle,
  Plus,
  Radio,
  RotateCcw,
  Search,
  Send,
  Settings2,
  StickyNote,
  X,
  XCircle,
} from "lucide-react";
import { currentUser, departments } from "./data";
import type { Skill } from "./skills";

type GenerationStatus =
  | "排队中"
  | "已停止"
  | "生成中"
  | "生成失败"
  | "生成成功";

interface DailySession {
  id: string;
  department: string;
  date: string;
  title: string;
  status: GenerationStatus;
  notes: DailyNote[];
  output?: string;
  hemsPushed?: boolean;
}

interface DailyNote {
  text: string;
  userName: string;
  sentAt: string;
}

interface HemsGroup {
  id: string;
  name: string;
  description: string;
}

interface DepartmentBranch {
  name: string;
  departments: Array<{ id: string; name: string }>;
}

const HEMS_SETTINGS_KEY = "ea_daily_report_hems_groups_v1";
const HEMS_GROUPS: HemsGroup[] = [
  {
    id: "HEMS-GRP-EA-001",
    name: "EA 工程日报群",
    description: "工程分析日报统一同步群",
  },
  {
    id: "HEMS-GRP-PTE-001",
    name: "PTE 每日进展群",
    description: "PTE 团队工作进展与风险同步",
  },
  {
    id: "HEMS-GRP-EFA-001",
    name: "EFA 分析协作群",
    description: "EFA 进度、结果与异常同步",
  },
  {
    id: "HEMS-GRP-QA-001",
    name: "质量问题日报群",
    description: "QA 与跨部门质量问题跟踪",
  },
  {
    id: "HEMS-GRP-MGT-001",
    name: "管理层日报汇总群",
    description: "各部门日报摘要与关键风险",
  },
];

const DEPARTMENT_ROOT = "工程分析中心";
const DEPARTMENT_TREE: DepartmentBranch[] = [
  {
    name: "测试工程部",
    departments: [
      { id: "PTE", name: "产品测试工程" },
      { id: "CP", name: "晶圆测试" },
      { id: "FT", name: "成品测试" },
    ],
  },
  {
    name: "分析研发部",
    departments: [
      { id: "DA", name: "设计分析" },
      { id: "EFA", name: "失效分析" },
      { id: "RD", name: "研发支持" },
    ],
  },
  {
    name: "质量与产品部",
    departments: [
      { id: "QA", name: "质量保证" },
      { id: "PE", name: "产品工程" },
      { id: "PM", name: "项目管理" },
    ],
  },
];

type HemsSettings = Record<string, string[]>;

const DEFAULT_HEMS_GROUPS: HemsSettings = {
  PTE: ["HEMS-GRP-PTE-001"],
  EFA: ["HEMS-GRP-EFA-001"],
  QA: ["HEMS-GRP-QA-001"],
};

const LEGACY_HEMS_GROUP_IDS: Record<string, string> = {
  "hems-ea-daily": "HEMS-GRP-EA-001",
  "hems-pte-daily": "HEMS-GRP-PTE-001",
  "hems-efa-analysis": "HEMS-GRP-EFA-001",
  "hems-quality-daily": "HEMS-GRP-QA-001",
  "hems-management": "HEMS-GRP-MGT-001",
};

function loadHemsSettings() {
  try {
    const saved = JSON.parse(
      localStorage.getItem(HEMS_SETTINGS_KEY) || "{}",
    ) as Record<string, string | string[]>;
    const migrated = Object.fromEntries(
      Object.entries(saved).map(([department, value]) => {
        const groupIds = (Array.isArray(value) ? value : [value]).map(
          (groupId) => LEGACY_HEMS_GROUP_IDS[groupId] ?? groupId,
        );
        return [department, Array.from(new Set(groupIds))];
      }),
    );
    return { ...DEFAULT_HEMS_GROUPS, ...migrated };
  } catch {
    return { ...DEFAULT_HEMS_GROUPS };
  }
}

function saveHemsSettings(settings: HemsSettings) {
  try {
    localStorage.setItem(HEMS_SETTINGS_KEY, JSON.stringify(settings));
  } catch {}
}

const STATUS_META: Record<
  GenerationStatus,
  { icon: typeof Clock3; card: string; badge: string; description: string }
> = {
  排队中: {
    icon: Clock3,
    card: "border-amber-200 bg-amber-50/70",
    badge: "bg-amber-100 text-amber-700",
    description: "任务正在等待生成资源。",
  },
  已停止: {
    icon: Ban,
    card: "border-slate-200 bg-slate-50",
    badge: "bg-slate-200 text-slate-600",
    description: "本次生成已停止，可重新发起。",
  },
  生成中: {
    icon: LoaderCircle,
    card: "border-blue-200 bg-blue-50/60",
    badge: "bg-blue-100 text-blue-700",
    description: "正在提取当天会话与工作笔记并组织日报。",
  },
  生成失败: {
    icon: XCircle,
    card: "border-red-200 bg-red-50/60",
    badge: "bg-red-100 text-red-600",
    description: "生成过程中出现异常，请检查笔记后重试。",
  },
  生成成功: {
    icon: CheckCircle2,
    card: "border-[#8BC9A8] bg-[#EAF7F0]",
    badge: "bg-[#CFEADB] text-[#176B47]",
    description: "日报已生成，可下载或推送至 HEMS。",
  },
};

const INITIAL_SESSIONS: DailySession[] = [
  {
    id: "daily-1",
    department: "PTE",
    date: "2026-08-17",
    title: "今日工作日报",
    status: "生成成功",
    notes: [
      {
        text: "完成 DDR5 复杂层级 Case 的任务视图验证。",
        userName: "张伟",
        sentAt: "09:42",
      },
      {
        text: "跟进 CP1 高耗时 Case，补充 Pattern 与 EFA 结论。",
        userName: "张伟",
        sentAt: "14:18",
      },
    ],
    output:
      "今日完成 DDR5 Case 任务视图与甘特图验证；推进 CP1 高耗时问题定位，已补充 Pattern 与 EFA 分析结论。明日计划完成改善样品复测并同步客户。",
  },
  {
    id: "daily-2",
    department: "EFA",
    date: "2026-08-17",
    title: "EFA 进展补充",
    status: "生成中",
    notes: [
      {
        text: "EFA 切片已排队，预计下午返回初步结果。",
        userName: "张伟",
        sentAt: "10:26",
      },
    ],
  },
  {
    id: "daily-3",
    department: "PTE",
    date: "2026-08-17",
    title: "下午工作汇总",
    status: "排队中",
    notes: [
      { text: "整理客户会议纪要与待办。", userName: "张伟", sentAt: "15:05" },
    ],
  },
  {
    id: "daily-4",
    department: "QA",
    date: "2026-08-16",
    title: "客户问题日报",
    status: "生成失败",
    notes: [
      {
        text: "客户平台复现日志缺失，等待补充附件。",
        userName: "张伟",
        sentAt: "16:32",
      },
    ],
  },
  {
    id: "daily-5",
    department: "PTE",
    date: "2026-08-16",
    title: "临时工作笔记",
    status: "已停止",
    notes: [
      { text: "该会话由用户手动停止。", userName: "张伟", sentAt: "17:10" },
    ],
  },
];

const dateLabel = (value: string) => {
  const date = new Date(`${value}T00:00:00`);
  return `${date.getMonth() + 1}月${date.getDate()}日`;
};

function StatusCard({
  session,
  onStatus,
  onDownload,
  onPush,
}: {
  session: DailySession;
  onStatus: (status: GenerationStatus) => void;
  onDownload: () => void;
  onPush: () => void;
}) {
  const meta = STATUS_META[session.status];
  const Icon = meta.icon;
  return (
    <div className={`rounded-lg border p-4 ${meta.card}`}>
      <div className="flex items-center gap-2">
        <Icon
          size={15}
          className={
            session.status === "生成中"
              ? "animate-spin text-blue-600"
              : session.status === "生成成功"
                ? "text-[#2D8A5C]"
                : "text-slate-500"
          }
        />
        <span
          className={`rounded-full px-2 py-0.5 text-[10px] font-medium ${meta.badge}`}
        >
          {session.status}
        </span>
        <span className="text-[10.5px] text-slate-500">{meta.description}</span>
      </div>
      {session.status === "生成成功" && session.output && (
        <div className="mt-3 whitespace-pre-wrap rounded-md border border-[#B8DDC8] bg-white/90 px-3 py-2.5 text-[12px] leading-relaxed text-slate-700">
          {session.output}
        </div>
      )}
      <div className="mt-3 flex items-center gap-2">
        {session.status === "排队中" && (
          <button
            type="button"
            onClick={() => onStatus("已停止")}
            className="h-7 rounded-md border border-amber-300 bg-white px-2.5 text-[10.5px] text-amber-700 hover:bg-amber-50"
          >
            取消排队
          </button>
        )}
        {session.status === "生成中" && (
          <button
            type="button"
            onClick={() => onStatus("已停止")}
            className="h-7 rounded-md border border-slate-300 bg-white px-2.5 text-[10.5px] text-slate-600 hover:bg-slate-50"
          >
            停止生成
          </button>
        )}
        {(session.status === "生成失败" || session.status === "已停止") && (
          <button
            type="button"
            onClick={() => onStatus("排队中")}
            className="inline-flex h-7 items-center gap-1 rounded-md bg-[#0052D9] px-2.5 text-[10.5px] text-white hover:bg-[#003FA8]"
          >
            <RotateCcw size={11} />
            重新生成
          </button>
        )}
        {session.status === "生成成功" && (
          <>
            <button
              type="button"
              onClick={onDownload}
              className="inline-flex h-7 items-center gap-1 rounded-md border border-slate-200 bg-white px-2.5 text-[10.5px] text-slate-600 hover:border-[#0052D9]/30 hover:text-[#0052D9]"
            >
              <Download size={11} />
              下载日报
            </button>
            <button
              type="button"
              onClick={onPush}
              disabled={session.hemsPushed}
              className="inline-flex h-7 items-center gap-1 rounded-md bg-[#0052D9] px-2.5 text-[10.5px] text-white hover:bg-[#003FA8] disabled:bg-emerald-600"
            >
              <Radio size={11} />
              {session.hemsPushed ? "已推送 HEMS" : "推送 HEMS"}
            </button>
          </>
        )}
      </div>
    </div>
  );
}

export function DailyReportSkill({
  skill,
  onBack,
  embedded = false,
}: {
  skill: Skill;
  onBack: () => void;
  embedded?: boolean;
}) {
  const [sessions, setSessions] = useState<DailySession[]>(INITIAL_SESSIONS);
  const [selectedDepartment, setSelectedDepartment] = useState(
    currentUser.department,
  );
  const [hemsSettings, setHemsSettings] =
    useState<HemsSettings>(loadHemsSettings);
  const [settingsDraft, setSettingsDraft] =
    useState<HemsSettings>(loadHemsSettings);
  const [settingsDepartment, setSettingsDepartment] = useState(
    currentUser.department,
  );
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [groupIdInput, setGroupIdInput] = useState("");
  const [groupLookupResult, setGroupLookupResult] = useState<HemsGroup | null>(
    null,
  );
  const [groupLookupError, setGroupLookupError] = useState("");
  const [settingsPrompt, setSettingsPrompt] = useState("");
  const [selectedDate, setSelectedDate] = useState("2026-08-17");
  const [activeId, setActiveId] = useState("daily-1");
  const [draft, setDraft] = useState("");
  const [notice, setNotice] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const generationTimers = useRef<number[]>([]);
  const activeSession = sessions.find((session) => session.id === activeId);
  const selectedDateSessions = useMemo(
    () =>
      sessions.filter(
        (session) =>
          session.department === selectedDepartment &&
          session.date === selectedDate,
      ),
    [selectedDate, selectedDepartment, sessions],
  );
  const selectedHemsGroups = (hemsSettings[selectedDepartment] || [])
    .map((groupId) => HEMS_GROUPS.find((group) => group.id === groupId))
    .filter((group): group is HemsGroup => Boolean(group));
  const settingsHemsGroups = (settingsDraft[settingsDepartment] || [])
    .map((groupId) => HEMS_GROUPS.find((group) => group.id === groupId))
    .filter((group): group is HemsGroup => Boolean(group));

  useEffect(
    () => () =>
      generationTimers.current.forEach((timer) => window.clearTimeout(timer)),
    [],
  );

  const patchActive = (patch: Partial<DailySession>) => {
    if (!activeSession) return;
    setSessions((current) =>
      current.map((session) =>
        session.id === activeSession.id ? { ...session, ...patch } : session,
      ),
    );
  };
  const selectDate = (date: string) => {
    setSelectedDate(date);
    const first = sessions.find(
      (session) =>
        session.department === selectedDepartment && session.date === date,
    );
    setActiveId(first?.id ?? "");
  };
  const selectDepartment = (department: string) => {
    setSelectedDepartment(department);
    const first = sessions.find(
      (session) =>
        session.department === department && session.date === selectedDate,
    );
    setActiveId(first?.id ?? "");
    setNotice("");
  };
  const createSession = () => {
    const id = `daily-${Date.now()}`;
    const count =
      sessions.filter(
        (session) =>
          session.department === selectedDepartment &&
          session.date === selectedDate,
      ).length + 1;
    setSessions((current) => [
      ...current,
      {
        id,
        department: selectedDepartment,
        date: selectedDate,
        title: `日报会话 ${count}`,
        status: "已停止",
        notes: [],
      },
    ]);
    setActiveId(id);
    setNotice("");
    window.setTimeout(() => inputRef.current?.focus(), 0);
  };
  const sendNote = (text = draft) => {
    const note = text.trim();
    if (!note || !activeSession) return;
    patchActive({
      notes: [
        ...activeSession.notes,
        {
          text: note,
          userName: currentUser.name,
          sentAt: new Date().toLocaleTimeString("zh-CN", {
            hour: "2-digit",
            minute: "2-digit",
            hour12: false,
          }),
        },
      ],
    });
    setDraft("");
  };
  const startGeneration = (sessionId = activeSession?.id ?? "") => {
    if (!sessionId) return;
    setNotice("");
    setSessions((current) =>
      current.map((session) =>
        session.id === sessionId
          ? {
              ...session,
              status: "排队中",
              output: undefined,
              hemsPushed: false,
            }
          : session,
      ),
    );
    const queueTimer = window.setTimeout(() => {
      setSessions((current) =>
        current.map((session) =>
          session.id === sessionId && session.status === "排队中"
            ? { ...session, status: "生成中" }
            : session,
        ),
      );
      const generationTimer = window.setTimeout(() => {
        setSessions((current) =>
          current.map((session) => {
            if (session.id !== sessionId || session.status !== "生成中")
              return session;
            const summary = session.notes.length
              ? session.notes.map((note) => note.text).join("；")
              : "今日暂无工作笔记。";
            return {
              ...session,
              status: "生成成功",
              output: `【${dateLabel(session.date)}日报】\n${summary}\n\n明日计划：继续跟进未完成事项，并同步关键进展。`,
            };
          }),
        );
      }, 1200);
      generationTimers.current.push(generationTimer);
    }, 900);
    generationTimers.current.push(queueTimer);
  };
  const runAction = (action: "generate" | "merge") => {
    if (!activeSession) return;
    if (action === "merge") {
      const merged = activeSession.notes.length
        ? activeSession.notes.map((note) => note.text).join("；")
        : "当前会话暂无笔记，请先输入工作内容。";
      patchActive({
        notes: [
          ...activeSession.notes,
          {
            text: `合并笔记：${merged}`,
            userName: currentUser.name,
            sentAt: new Date().toLocaleTimeString("zh-CN", {
              hour: "2-digit",
              minute: "2-digit",
              hour12: false,
            }),
          },
        ],
      });
      return;
    }
    startGeneration();
  };
  const download = () => {
    if (!activeSession) return;
    const blob = new Blob([activeSession.output ?? ""], {
      type: "text/plain;charset=utf-8",
    });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `${activeSession.date}-${activeSession.title}.txt`;
    anchor.click();
    URL.revokeObjectURL(url);
    setNotice("日报文件已下载");
  };
  const openSettings = (department = selectedDepartment, prompt = "") => {
    setSettingsDepartment(department);
    setSettingsDraft({ ...hemsSettings });
    setGroupIdInput("");
    setGroupLookupResult(null);
    setGroupLookupError("");
    setSettingsPrompt(prompt);
    setSettingsOpen(true);
  };
  const selectSettingsDepartment = (department: string) => {
    setSettingsDepartment(department);
    setGroupIdInput("");
    setGroupLookupResult(null);
    setGroupLookupError("");
    setSettingsPrompt("");
  };
  const updateGroupIdInput = (value: string) => {
    setGroupIdInput(value.toUpperCase());
    setGroupLookupResult(null);
    setGroupLookupError("");
  };
  const lookupGroup = () => {
    const groupId = groupIdInput.trim().toUpperCase();
    const group = HEMS_GROUPS.find((item) => item.id.toUpperCase() === groupId);
    if (!group) {
      setGroupLookupResult(null);
      setGroupLookupError("未查询到该群组 ID，请检查后重试。");
      return;
    }
    setGroupIdInput(group.id);
    setGroupLookupResult(group);
    setGroupLookupError("");
  };
  const addGroup = () => {
    if (!groupLookupResult) return;
    setSettingsDraft((current) => ({
      ...current,
      [settingsDepartment]: Array.from(
        new Set([...(current[settingsDepartment] || []), groupLookupResult.id]),
      ),
    }));
    setGroupIdInput("");
    setGroupLookupResult(null);
  };
  const removeGroup = (groupId: string) => {
    setSettingsDraft((current) => ({
      ...current,
      [settingsDepartment]: (current[settingsDepartment] || []).filter(
        (id) => id !== groupId,
      ),
    }));
  };
  const saveSettings = () => {
    setHemsSettings(settingsDraft);
    saveHemsSettings(settingsDraft);
    setSettingsOpen(false);
    setNotice(`${settingsDepartment} 的 HEMS 推送群组已保存`);
  };
  const pushToHems = () => {
    if (!activeSession) return;
    const groups = (hemsSettings[activeSession.department] || [])
      .map((groupId) => HEMS_GROUPS.find((group) => group.id === groupId))
      .filter((group): group is HemsGroup => Boolean(group));
    if (!groups.length) {
      setNotice("请配置需要推送的群组");
      openSettings(activeSession.department, "请配置需要推送的群组");
      return;
    }
    patchActive({ hemsPushed: true });
    setNotice(`日报已推送至 ${groups.map((group) => group.name).join("、")}`);
  };

  return (
    <div className={`mx-auto flex max-w-[1280px] flex-col overflow-hidden rounded-lg border border-slate-200 bg-white shadow-[0_4px_18px_-12px_rgba(15,23,42,0.25)] ${embedded ? "h-[min(660px,70vh)] min-h-[360px] w-full" : "h-[calc(100vh-158px)] min-h-[650px]"}`}>
      <div className="flex items-center gap-3 border-b border-slate-200 px-5 py-4">
        <button
          type="button"
          onClick={onBack}
          className="inline-flex h-8 items-center gap-1 rounded-md border border-slate-200 px-2.5 text-[11px] text-slate-600 hover:border-[#0052D9]/30 hover:text-[#0052D9]"
        >
          <ArrowLeft size={13} />
          {embedded ? "返回 Skill 列表" : "返回技能市场"}
        </button>
        <span className="h-6 w-px bg-slate-200" />
        <span className="grid h-9 w-9 place-items-center rounded-lg bg-[#0052D9] text-white">
          <CalendarDays size={17} />
        </span>
        <div>
          <h2 className="text-sm font-semibold text-slate-900">{skill.name}</h2>
          <p className="mt-0.5 text-[10.5px] text-slate-400">
            按日期管理会话、笔记与日报生成任务
          </p>
        </div>
      </div>

      <div className="grid min-h-0 flex-1 grid-cols-[270px_minmax(0,1fr)]">
        <aside className="min-h-0 overflow-y-auto border-r border-slate-200 bg-slate-50/70 p-3">
          <label className="block text-[10.5px] text-slate-500">
            选择部门
            <select
              value={selectedDepartment}
              onChange={(event) => selectDepartment(event.target.value)}
              className="mt-1 h-9 w-full rounded-md border border-slate-200 bg-white px-2 text-xs text-slate-700 outline-none focus:border-[#0052D9]"
            >
              {departments.map((department) => (
                <option key={department} value={department}>
                  {department}
                </option>
              ))}
            </select>
          </label>
          <button
            type="button"
            onClick={() => openSettings()}
            title={selectedHemsGroups.map((group) => group.name).join("、")}
            className="mt-2 flex w-full items-center gap-2 rounded-md border border-slate-200 bg-white px-2.5 py-2 text-left hover:border-[#0052D9]/30"
          >
            <Radio
              size={12}
              className={
                selectedHemsGroups.length ? "text-[#2D8A5C]" : "text-slate-300"
              }
            />
            <span className="min-w-0 flex-1">
              <span className="block text-[9.5px] text-slate-400">
                HEMS 推送群组
              </span>
              <span
                className={`mt-0.5 block truncate text-[10.5px] ${selectedHemsGroups.length ? "font-medium text-slate-700" : "text-amber-600"}`}
              >
                {selectedHemsGroups.length === 1
                  ? selectedHemsGroups[0].name
                  : selectedHemsGroups.length > 1
                    ? `${selectedHemsGroups.length} 个群组`
                    : "暂未设置"}
              </span>
            </span>
            <Settings2 size={11} className="text-slate-300" />
          </button>
          <label className="mt-3 block text-[10.5px] text-slate-500">
            选择日期
            <input
              type="date"
              value={selectedDate}
              onChange={(event) => selectDate(event.target.value)}
              className="mt-1 h-9 w-full rounded-md border border-slate-200 bg-white px-2 text-xs text-slate-700 outline-none focus:border-[#0052D9]"
            />
          </label>
          <button
            type="button"
            onClick={createSession}
            className="mt-2 inline-flex h-8 w-full items-center justify-center gap-1 rounded-md bg-[#0052D9] text-[11px] text-white hover:bg-[#003FA8]"
          >
            <Plus size={12} />
            新建会话
          </button>
          <div className="mt-4">
            <div className="mb-1.5 flex items-center justify-between text-[10.5px] font-medium text-[#0052D9]">
              <span>{dateLabel(selectedDate)}</span>
              <span>{selectedDateSessions.length}</span>
            </div>
            <div className="space-y-1">
              {selectedDateSessions.map((session) => (
                <button
                  key={session.id}
                  type="button"
                  onClick={() => {
                    setActiveId(session.id);
                    setNotice("");
                  }}
                  className={`w-full rounded-md border px-2.5 py-2 text-left ${activeId === session.id ? "border-[#0052D9]/30 bg-white shadow-sm" : "border-transparent hover:bg-white"}`}
                >
                  <span className="block truncate text-[11px] font-medium text-slate-700">
                    {session.title}
                  </span>
                </button>
              ))}
            </div>
            {!selectedDateSessions.length && (
              <div className="rounded-md border border-dashed border-slate-200 bg-white px-3 py-5 text-center text-[10.5px] text-slate-400">
                该日期暂无会话
                <br />
                点击上方“新建会话”开始记录
              </div>
            )}
          </div>
        </aside>

        <main className="flex min-h-0 min-w-0 flex-col">
          {activeSession ? (
            <>
              <div className="flex items-center gap-3 border-b border-slate-100 px-5 py-3">
                <div>
                  <h3 className="text-sm font-semibold text-slate-800">
                    {activeSession.title}
                  </h3>
                  <p className="mt-0.5 text-[10px] text-slate-400">
                    {activeSession.date} · {activeSession.notes.length} 条笔记
                  </p>
                </div>
              </div>
              <div className="min-h-0 flex-1 overflow-y-auto bg-slate-50/40 p-5 space-y-4">
                <div className="flex gap-3">
                  <span className="grid h-7 w-7 shrink-0 place-items-center rounded-md bg-[#0052D9] text-[9px] text-white">
                    AI
                  </span>
                  <div className="max-w-[76%] rounded-lg border border-slate-200 bg-white px-3 py-2.5 text-[12px] leading-relaxed text-slate-700">
                    这是 {dateLabel(activeSession.date)}{" "}
                    的日报会话。输入工作记录后，可以合并笔记或生成日报。
                  </div>
                </div>
                {activeSession.notes.map((note, index) => (
                  <div key={index} className="flex flex-row-reverse gap-3">
                    <span className="grid h-7 w-7 shrink-0 place-items-center rounded-md bg-slate-200 text-[9px] text-slate-600">
                      我
                    </span>
                    <div className="max-w-[76%]">
                      <div className="mb-1 flex items-center justify-end gap-1.5 text-[9.5px] text-slate-400">
                        <span>{note.userName}</span>
                        <span>·</span>
                        <time>{note.sentAt}</time>
                      </div>
                      <div className="whitespace-pre-wrap rounded-lg bg-[#0052D9] px-3 py-2.5 text-[12px] leading-relaxed text-white">
                        {note.text}
                      </div>
                    </div>
                  </div>
                ))}
                <StatusCard
                  session={activeSession}
                  onStatus={(status) =>
                    status === "排队中"
                      ? startGeneration()
                      : patchActive({ status })
                  }
                  onDownload={download}
                  onPush={pushToHems}
                />
                {notice && (
                  <div className="text-center text-[10.5px] text-emerald-600">
                    {notice}
                  </div>
                )}
              </div>
              <div className="border-t border-slate-100 bg-white p-4">
                <div className="mb-2 flex gap-2">
                  <button
                    type="button"
                    onClick={() => runAction("generate")}
                    className="inline-flex h-8 items-center gap-1 rounded-md bg-[#0052D9] px-3 text-[11px] text-white hover:bg-[#003FA8]"
                  >
                    <FileText size={12} />
                    生成日报
                  </button>
                  <button
                    type="button"
                    onClick={() => runAction("merge")}
                    className="inline-flex h-8 items-center gap-1 rounded-md border border-slate-200 bg-white px-3 text-[11px] text-slate-600 hover:border-[#0052D9]/30 hover:text-[#0052D9]"
                  >
                    <StickyNote size={12} />
                    合并笔记
                  </button>
                </div>
                <div className="flex items-center gap-2 rounded-md border border-slate-200 px-3 py-2 focus-within:border-[#0052D9]">
                  <input
                    ref={inputRef}
                    value={draft}
                    onChange={(event) => setDraft(event.target.value)}
                    onKeyDown={(event) => {
                      if (event.key === "Enter") sendNote();
                    }}
                    placeholder="记录今天完成的工作、进展或待办..."
                    className="min-w-0 flex-1 bg-transparent text-sm text-slate-700 outline-none placeholder:text-slate-400"
                  />
                  <button
                    type="button"
                    onClick={() => sendNote()}
                    disabled={!draft.trim()}
                    className="inline-flex h-8 items-center gap-1 rounded-md bg-[#0052D9] px-3 text-xs text-white disabled:opacity-40"
                  >
                    <Send size={12} />
                    发送
                  </button>
                </div>
              </div>
            </>
          ) : (
            <div className="grid flex-1 place-items-center bg-slate-50/40">
              <div className="text-center">
                <CalendarDays size={28} className="mx-auto text-slate-300" />
                <div className="mt-3 text-sm font-medium text-slate-600">
                  {dateLabel(selectedDate)} 暂无会话
                </div>
                <div className="mt-1 text-[11px] text-slate-400">
                  新建会话后即可记录笔记并生成日报
                </div>
                <button
                  type="button"
                  onClick={createSession}
                  className="mt-4 inline-flex h-8 items-center gap-1 rounded-md bg-[#0052D9] px-3 text-[11px] text-white hover:bg-[#003FA8]"
                >
                  <Plus size={12} />
                  新建会话
                </button>
              </div>
            </div>
          )}
        </main>
      </div>
      {settingsOpen && (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/40 p-6"
          onMouseDown={() => setSettingsOpen(false)}
        >
          <div
            role="dialog"
            aria-modal="true"
            aria-labelledby="hems-settings-title"
            className="w-[620px] max-w-[95vw] overflow-hidden rounded-xl border border-slate-200 bg-white shadow-2xl"
            onMouseDown={(event) => event.stopPropagation()}
          >
            <div className="flex items-center gap-3 border-b border-slate-100 px-5 py-4">
              <span className="grid h-8 w-8 place-items-center rounded-md bg-[#0052D9]/8 text-[#0052D9]">
                <Settings2 size={15} />
              </span>
              <div>
                <h3
                  id="hems-settings-title"
                  className="text-sm font-semibold text-slate-900"
                >
                  HEMS 推送设置
                </h3>
                <p className="mt-0.5 text-[10px] text-slate-400">
                  按组织层级选择部门，并通过群组 ID 独立配置推送目标
                </p>
              </div>
              <button
                type="button"
                title="关闭"
                onClick={() => setSettingsOpen(false)}
                className="ml-auto grid h-7 w-7 place-items-center rounded-md text-slate-400 hover:bg-slate-100 hover:text-slate-600"
              >
                <X size={14} />
              </button>
            </div>
            <div className="grid grid-cols-[230px_minmax(0,1fr)]">
              <div className="max-h-[460px] overflow-y-auto border-r border-slate-100 bg-slate-50/70 p-3">
                <div className="mb-2 px-2 text-[10px] font-medium text-slate-400">
                  配置部门
                </div>
                <div className="rounded-md px-2 py-1.5 text-[11px] font-semibold text-slate-700">
                  <span className="mr-2 inline-block h-2 w-2 rounded-sm bg-[#0052D9]" />
                  {DEPARTMENT_ROOT}
                  <span className="ml-2 text-[9px] font-normal text-slate-400">
                    一级
                  </span>
                </div>
                <div className="ml-3 border-l border-slate-200 pl-2">
                  {DEPARTMENT_TREE.map((branch) => (
                    <div key={branch.name} className="relative mb-2 last:mb-0">
                      <div className="before:absolute before:-left-2 before:top-3 before:h-px before:w-2 before:bg-slate-200 flex items-center px-2 py-1.5 text-[10.5px] font-medium text-slate-600">
                        {branch.name}
                        <span className="ml-2 text-[9px] font-normal text-slate-400">
                          二级
                        </span>
                      </div>
                      <div className="ml-3 space-y-1 border-l border-slate-200 pl-2">
                        {branch.departments.map((department) => {
                          const groupCount =
                            settingsDraft[department.id]?.length || 0;
                          return (
                            <button
                              key={department.id}
                              type="button"
                              onClick={() =>
                                selectSettingsDepartment(department.id)
                              }
                              className={`relative flex w-full items-center gap-2 rounded-md px-2 py-2 text-left before:absolute before:-left-2 before:top-1/2 before:h-px before:w-2 before:bg-slate-200 ${settingsDepartment === department.id ? "bg-white text-[#0052D9] shadow-sm ring-1 ring-[#0052D9]/15" : "text-slate-600 hover:bg-white"}`}
                            >
                              <span className="w-8 shrink-0 text-[10.5px] font-semibold">
                                {department.id}
                              </span>
                              <span className="min-w-0 flex-1">
                                <span className="block truncate text-[9.5px]">
                                  {department.name}
                                </span>
                                <span className="mt-0.5 block truncate text-[8.5px] text-slate-400">
                                  {groupCount ? `${groupCount} 个群组` : "未设置"}
                                </span>
                              </span>
                              <span
                                className={`h-1.5 w-1.5 shrink-0 rounded-full ${groupCount ? "bg-[#2D8A5C]" : "bg-slate-300"}`}
                              />
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <div className="max-h-[460px] overflow-y-auto p-5">
                <div className="text-xs font-medium text-slate-700">
                  {settingsDepartment} 的推送群组
                </div>
                <div className="mt-1 text-[10px] text-slate-400">
                  可配置多个 HEMS 群组。每个具体部门的配置互不影响。
                </div>
                {settingsPrompt && (
                  <div className="mt-3 rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-[10.5px] font-medium text-amber-700">
                    {settingsPrompt}
                  </div>
                )}
                <div className="mt-4">
                  <div className="flex items-center justify-between">
                    <span className="text-[10.5px] font-medium text-slate-600">
                      已配置群组
                    </span>
                    <span className="text-[9.5px] text-slate-400">
                      {settingsHemsGroups.length} 个
                    </span>
                  </div>
                  {settingsHemsGroups.length ? (
                    <div className="mt-2 space-y-1.5">
                      {settingsHemsGroups.map((group) => (
                        <div
                          key={group.id}
                          className="flex items-center gap-2 rounded-md border border-slate-200 bg-slate-50/70 px-3 py-2"
                        >
                          <Radio
                            size={11}
                            className="shrink-0 text-[#2D8A5C]"
                          />
                          <span className="min-w-0 flex-1">
                            <span className="block truncate text-[10.5px] font-medium text-slate-700">
                              {group.name}
                            </span>
                            <span className="block truncate font-mono text-[8.5px] text-slate-400">
                              {group.id}
                            </span>
                          </span>
                          <button
                            type="button"
                            onClick={() => removeGroup(group.id)}
                            title={`移除 ${group.name}`}
                            className="grid h-6 w-6 shrink-0 place-items-center rounded text-slate-400 hover:bg-red-50 hover:text-red-500"
                          >
                            <X size={11} />
                          </button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="mt-2 rounded-md border border-dashed border-slate-200 px-3 py-3 text-center text-[10px] text-slate-400">
                      暂未配置群组
                    </div>
                  )}
                </div>
                <label className="mt-4 block text-[10.5px] text-slate-500">
                  添加 HEMS 群组 ID
                  <div className="mt-1.5 flex gap-2">
                    <input
                      autoFocus
                      value={groupIdInput}
                      onChange={(event) =>
                        updateGroupIdInput(event.target.value)
                      }
                      onKeyDown={(event) => {
                        if (event.key === "Enter") {
                          event.preventDefault();
                          lookupGroup();
                        }
                      }}
                      placeholder="例如：HEMS-GRP-PTE-001"
                      className="h-9 min-w-0 flex-1 rounded-md border border-slate-200 bg-white px-3 font-mono text-xs uppercase text-slate-700 outline-none focus:border-[#0052D9]"
                    />
                    <button
                      type="button"
                      onClick={lookupGroup}
                      disabled={!groupIdInput.trim()}
                      className="inline-flex h-9 items-center gap-1.5 rounded-md bg-[#0052D9] px-3 text-xs text-white hover:bg-[#003FA8] disabled:opacity-40"
                    >
                      <Search size={12} />
                      查询
                    </button>
                  </div>
                </label>
                {groupLookupError && (
                  <div className="mt-2 rounded-md border border-red-100 bg-red-50 px-3 py-2 text-[10px] text-red-600">
                    {groupLookupError}
                  </div>
                )}
                {groupLookupResult && (
                  <div className="mt-3 rounded-lg border border-[#8BC9A8] bg-[#EAF7F0] p-3">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 size={14} className="text-[#2D8A5C]" />
                      <span className="text-[11.5px] font-semibold text-[#176B47]">
                        已查询到群组
                      </span>
                    </div>
                    <div className="mt-2 text-[12px] font-medium text-slate-800">
                      {groupLookupResult.name}
                    </div>
                    <div className="mt-1 font-mono text-[10px] text-slate-500">
                      {groupLookupResult.id}
                    </div>
                    <div className="mt-1 text-[10px] text-slate-500">
                      {groupLookupResult.description}
                    </div>
                    <button
                      type="button"
                      onClick={addGroup}
                      disabled={(settingsDraft[settingsDepartment] || []).includes(
                        groupLookupResult.id,
                      )}
                      className="mt-3 h-8 w-full rounded-md bg-[#176B47] text-[10.5px] font-medium text-white hover:bg-[#12583A] disabled:bg-slate-300"
                    >
                      {(settingsDraft[settingsDepartment] || []).includes(
                        groupLookupResult.id,
                      )
                        ? "该群组已添加"
                        : "添加此群组"}
                    </button>
                  </div>
                )}
                <div className="mt-5 rounded-md bg-slate-50 px-3 py-2.5 text-[9.5px] leading-relaxed text-slate-400">
                  逐个输入群组 ID，查询后添加。保存设置后，日报会同时推送至该部门配置的全部群组。
                </div>
              </div>
            </div>
            <div className="flex items-center justify-between border-t border-slate-100 bg-slate-50/60 px-5 py-3">
              <span className="text-[10px] text-slate-400">
                已配置 {Object.values(settingsDraft).filter((groupIds) => groupIds.length > 0).length} / {departments.length} 个部门 · {Object.values(settingsDraft).reduce((total, groupIds) => total + groupIds.length, 0)} 个群组
              </span>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setSettingsOpen(false)}
                  className="h-8 rounded-md border border-slate-200 bg-white px-3 text-xs text-slate-600 hover:bg-slate-50"
                >
                  取消
                </button>
                <button
                  type="button"
                  onClick={saveSettings}
                  className="h-8 rounded-md bg-[#0052D9] px-3 text-xs text-white hover:bg-[#003FA8]"
                >
                  保存设置
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
