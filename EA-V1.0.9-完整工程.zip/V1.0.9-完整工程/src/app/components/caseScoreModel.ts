import { flattenTasks, type CaseItem, type TaskNode } from "./data";
import type { ClosureRecord } from "./closures";

export interface CaseScoreDimension {
  label: string;
  value: number;
  weight: number;
  basis: string;
}

const hasText = (value?: string) => Boolean(value?.trim() && !["—", "-", "待填写", "待补充"].includes(value.trim()));
const hasFiles = (files?: { name: string }[]) => Boolean(files?.some(file => hasText(file.name)));
const percentage = (filled: number, total: number) => total ? Math.round(filled / total * 100) : 0;

export function calculateCaseScore(record: CaseItem, tasks: TaskNode[] = record.tasks, closure?: ClosureRecord) {
  const actions = flattenTasks(tasks).map(item => item.task).filter(task => task.code && !["已拒绝", "已中止"].includes(task.status));
  const background = [record.reason, record.background, record.impact].filter(hasText).length;
  const process = Number(hasText(closure?.workspace?.process)) + actions.filter(task => hasText(task.analysisProcess)).length;
  const evidence = Number(hasFiles(record.caseAttachments) || hasFiles(closure?.workspace?.attachments) || hasFiles(closure?.files))
    + actions.filter(task => hasFiles(task.attachments) || hasFiles(task.efaTicket?.attachments)).length;
  const conclusion = Number(hasText(closure?.workspace?.conclusion ?? closure?.conclusion ?? record.aiSummary?.conclusion))
    + actions.filter(task => hasText(task.conclusion)).length;
  const completed = actions.filter(task => task.status === "已完成").length;
  const assigned = actions.filter(task => task.assigneeType === "skill" ? hasText(task.skillId) : hasText(task.owner) && !["待指派", "待分派", "系统"].includes(task.owner)).length;
  const documents = actions.length + 1;
  const dimensions: CaseScoreDimension[] = [
    { label: "案件背景", value: percentage(background, 3), weight: 20, basis: `发起事由、背景、影响已填 ${background}/3 项` },
    { label: "分析过程", value: percentage(process, documents), weight: 20, basis: `Case 与有效任务的分析过程已记录 ${process}/${documents} 份` },
    { label: "证据记录", value: percentage(evidence, documents), weight: 15, basis: `Case 与有效任务中有具名附件 ${evidence}/${documents} 项` },
    { label: "结论沉淀", value: percentage(conclusion, documents), weight: 20, basis: `Case 与有效任务的结论已记录 ${conclusion}/${documents} 份` },
    { label: "任务闭环", value: percentage(completed, actions.length), weight: 15, basis: actions.length ? `有效执行任务已完成 ${completed}/${actions.length} 项` : "暂无有效执行任务" },
    { label: "分工明确", value: percentage(assigned, actions.length), weight: 10, basis: actions.length ? `有效执行任务已指定负责人或 Skill ${assigned}/${actions.length} 项` : "暂无有效执行任务" },
  ];
  return { total: Math.round(dimensions.reduce((sum, dimension) => sum + dimension.value * dimension.weight / 100, 0)), dimensions };
}