import { CheckCircle2, CircleDot, FlaskConical, PauseCircle } from "lucide-react";

export type CaseDisplayStatus = "进行中" | "验证中" | "暂存" | "已结案";

export function caseDisplayStatus(caseItem: { status?: string }, options?: { closed?: boolean; rootCaused?: boolean }): CaseDisplayStatus {
  if (options?.closed || ["已关闭", "已结案", "已归档"].includes(caseItem.status || "")) return "已结案";
  if (options?.rootCaused || caseItem.status === "验证中") return "验证中";
  if (caseItem.status === "Pending") return "暂存";
  return "进行中";
}

const tone: Record<CaseDisplayStatus, string> = {
  进行中: "border-blue-200 bg-blue-50 text-blue-600",
  验证中: "border-cyan-200 bg-cyan-50 text-cyan-700",
  暂存: "border-slate-200 bg-slate-100 text-slate-500",
  已结案: "border-emerald-200 bg-emerald-50 text-emerald-700",
};

const icons = { 进行中: CircleDot, 验证中: FlaskConical, 暂存: PauseCircle, 已结案: CheckCircle2 } as const;

export function CaseStatusBadge({ status }: { status: CaseDisplayStatus }) {
  const Icon = icons[status];
  return <span className={`inline-flex h-6 items-center gap-1 rounded border px-1.5 text-[10px] font-medium ${tone[status]}`}><Icon size={11} />{status}</span>;
}