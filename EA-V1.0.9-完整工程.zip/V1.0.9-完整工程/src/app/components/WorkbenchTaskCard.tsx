import { ArrowUpRight, CalendarClock, Mic, Package, Paperclip } from "lucide-react";
import { currentUser, levelColors, ownerToDepartment, reportsTo, urgencyBar } from "./data";
import { StatusBadge } from "./StatusBadge";
import { RecoveryBadge } from "./RecoveryControls";
import { needsCorrection } from "./recordRecovery";
import { businessLabel, taskCanAct, taskRemainingDays, type WorkbenchTask } from "./taskWorkbenchModel";

// 沿用 V1.0.7：待接受用派单气泡，其余状态用紧凑横向任务行。
// 仅复用展示样式，数据、权限及事件仍来自当前工作台。
export function WorkbenchTaskCard({ row, businessKey, onShowTask, onOpenCase, onTakeAction, onReject, columnLayout = false }: {
  row: WorkbenchTask;
  businessKey: string;
  onShowTask: () => void;
  onOpenCase: (id: string) => void;
  onTakeAction: () => void;
  onReject: () => void;
  columnLayout?: boolean;
}) {
  const pending = row.status === "待接受" && !row.convertedCaseId;
  const active = ["待接受", "进行中"].includes(row.status) && !row.caseClosed && !row.convertedCaseId;
  const canAct = taskCanAct(row, currentUser.name);
  const days = taskRemainingDays(row);
  const dueText = days === undefined ? "未设置截止日期" : days < 0 ? `已逾期 ${Math.abs(days)} 天` : days === 0 ? "今日到期" : `${days} 天到期`;
  const business = row.business.find(ref => ref.key === businessKey) ?? row.business[0];
  const businessTitle = row.business.map(businessLabel).join("；");
  const preview = row.status === "已拒绝" && row.rejectReason ? `拒绝理由：${row.rejectReason}` : row.status === "已完成" && row.conclusion ? row.conclusion : row.description;
  const taskTitle = [row.title, row.code, preview, row.creator ? `${row.creator} 分派` : "", businessTitle].filter(Boolean).join("\n");
  const relation = row.creator && row.creator !== row.owner
    ? row.caseItem?.owner === row.creator ? "Case Owner"
      : ownerToDepartment[row.owner] && reportsTo(row.owner) === row.creator ? row.owner === currentUser.name ? "你的主管" : "负责人主管"
      : ownerToDepartment[row.creator] && ownerToDepartment[row.owner] && ownerToDepartment[row.creator] !== ownerToDepartment[row.owner] ? "跨部门" : ""
    : "";
  const date = <span className="inline-flex shrink-0 items-center gap-1 text-[11px] text-slate-500" title={active ? row.dueDate : row.updatedAt}>
    <CalendarClock size={12} className="text-slate-400" />{active ? dueText : row.updatedAt ? `更新 ${row.updatedAt.slice(0, 10)}` : "更新时间未记录"}
  </span>;
  const materials = <>{row.attachmentCount > 0 && <span title={`${row.attachmentCount} 个附件`} className="inline-flex items-center gap-0.5 text-[10px] text-slate-400"><Paperclip size={11} />{row.attachmentCount}</span>}{row.hasVoice && <Mic size={11} className="text-slate-400" aria-label="有语音备注" />}</>;
  const showCaseName = columnLayout && !pending;
  const context = row.caseItem ? <button type="button" onClick={() => onOpenCase(row.caseItem!.id)} aria-label={`查看关联 Case ${row.caseItem.name}`} title={[row.caseItem.name, businessTitle].filter(Boolean).join("\n")} className={`inline-flex min-w-0 gap-1.5 font-normal transition-colors hover:text-[#0052D9] ${showCaseName ? "flex-1 items-start text-left" : "max-w-[210px] items-center"} ${pending ? "rounded-md border border-slate-200 bg-slate-100 px-2 py-0.5 text-[10.5px] text-slate-500" : "text-[11px] text-slate-500"}`}>
    <span className={`shrink-0 rounded border px-1 text-[9px] ${levelColors[row.caseItem.level]}`}>{row.caseItem.level}</span>
    {business && <span className={`inline-flex shrink-0 items-center gap-0.5 whitespace-nowrap rounded-full border border-blue-200 bg-blue-50 px-1.5 py-0.5 text-[9px] font-medium leading-none text-blue-700 ${showCaseName ? "max-w-[76px]" : "max-w-[110px]"}`} title={businessTitle}>{business.kind === "产品" && <Package size={9} className="shrink-0" />}<span className="truncate">{business.name}</span></span>}
    {showCaseName && <span data-slot="task-case-name" className="min-w-0 flex-1 whitespace-normal break-words leading-4">{row.caseItem.name}</span>}
    {!showCaseName && <span className="truncate">{row.caseItem.name}</span>}
  </button> : row.convertedCaseId ? <button type="button" onClick={() => onOpenCase(row.convertedCaseId!)} title={row.convertedCaseName || "查看升级后的 Case"} className="inline-flex max-w-[210px] min-w-0 items-center gap-1 text-[11px] font-normal text-[#0052D9] hover:underline"><span className="truncate">{row.convertedCaseName || "查看升级后的 Case"}</span><ArrowUpRight size={12} className="shrink-0" /></button>
    : business ? <span title={businessTitle} className="max-w-[210px] truncate rounded-md border border-slate-200 bg-slate-100 px-2 py-0.5 text-[10.5px] text-slate-500">{business.kind} · {business.name}{row.business.length > 1 ? ` 等 ${row.business.length} 项` : ""}</span> : null;
  const closed = row.caseClosed && <span className="text-[10px] text-slate-400" title="所属 Case 已结案，当前不可执行">Case 已结案</span>;

  if (pending) return <article aria-label={row.title} className="relative flex min-w-0 overflow-hidden rounded-xl border border-slate-200 bg-white p-4 pl-5">
    {active && <div className={`absolute bottom-3 left-0 top-3 w-[3px] rounded-r ${urgencyBar[row.urgency]}`} title={`紧急程度：${row.urgency}`} />}
    <div className="flex min-w-0 flex-1 flex-col">
      <div className="flex flex-wrap items-center gap-1.5 text-[11.5px] text-slate-500">
        {row.creator && <b className="text-slate-900">{row.creator}</b>}
        <span className="font-semibold text-[#0052D9]">@{row.owner === currentUser.name ? "你" : row.owner}</span>
        <span>· {row.caseClosed ? "待接受" : row.owner === currentUser.name ? "请处理这个任务" : "等待接受任务"}</span>
        {relation && <span className="rounded border border-slate-200 bg-slate-100 px-1.5 py-px text-[10px] font-semibold text-slate-500">{relation}</span>}{closed}
      </div>
      <div className="mt-1.5 rounded-xl rounded-tl-[3px] border border-slate-100 bg-[#f7f9fc] px-3 py-2.5">
        <button type="button" onClick={onShowTask} aria-label={`查看任务 ${row.title}`} title={taskTitle} className="text-left text-sm font-semibold leading-snug text-slate-800 transition-colors hover:text-[#0052D9] focus-visible:outline-2 focus-visible:outline-[#0052D9]/40">{row.title}</button>
        <div className="mt-2 flex flex-wrap items-center gap-2">{date}{context}{materials}</div>
      </div>
      {canAct && <div className="mt-2.5 flex gap-2">
        <button type="button" onClick={onTakeAction} className="rounded-lg bg-[#0052D9] px-4 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-[#003FA8]">接受并开始</button>
        <button type="button" onClick={onReject} className="rounded-lg border border-slate-200 bg-white px-3.5 py-1.5 text-xs text-slate-500 transition-colors hover:bg-slate-50">拒绝</button>
      </div>}
    </div>
  </article>;

  if (columnLayout) return <article aria-label={row.title} data-layout="compact-task" className="relative min-w-0 rounded-lg border border-slate-200 bg-white px-3 py-2 transition-shadow hover:shadow-[0_6px_18px_-12px_rgba(15,23,42,0.2)]">
    {active && <div className={`absolute bottom-2 left-0 top-2 w-[3px] rounded-r ${urgencyBar[row.urgency]}`} title={`紧急程度：${row.urgency}`} />}
    <div className="flex items-start gap-2">
      <span className="mt-0.5 shrink-0" title={row.status}><StatusBadge status={row.status} size={14} /></span>
      <button type="button" onClick={onShowTask} aria-label={`查看任务 ${row.title}`} title={taskTitle} className="min-w-0 flex-1 break-words text-left text-[13px] font-medium leading-snug text-slate-800 hover:text-[#0052D9] focus-visible:outline-2 focus-visible:outline-[#0052D9]/40">{row.title}</button>
      {row.source === "case" && needsCorrection(row.record) && <RecoveryBadge record={row.record} />}
      {date}
    </div>
    <div className="mt-1.5 flex min-w-0 items-start gap-2 pl-[22px]">
      {context}
      {materials}{closed}
      <span data-slot="task-owner" className="ml-auto inline-flex w-[72px] shrink-0 items-center gap-1 text-[11px] text-slate-500" title={row.creator ? `${row.owner} · ${row.creator} 分派` : row.owner}><span className="grid h-4 w-4 shrink-0 place-items-center rounded-full bg-[#0052D9]/8 text-[9px] text-[#0052D9]">{row.owner[0]}</span><span className="min-w-0 truncate">{row.owner}</span></span>
    </div>
  </article>;

  return <article aria-label={row.title} className="relative col-span-2 flex min-w-0 items-center gap-3 rounded-xl border border-slate-200 bg-white px-4 py-3 transition-shadow hover:shadow-[0_6px_18px_-12px_rgba(15,23,42,0.2)]">
    {active && <div className={`absolute bottom-2 left-0 top-2 w-[3px] rounded-r ${urgencyBar[row.urgency]}`} title={`紧急程度：${row.urgency}`} />}
    <div className={`${row.convertedCaseId ? "w-[100px]" : "w-[74px]"} flex shrink-0 items-center gap-1.5 text-[11px] text-slate-500`}>
      <StatusBadge status={row.status} size={14} />{row.convertedCaseId ? "已升级为 Case" : row.status}
    </div>
    <button type="button" onClick={onShowTask} aria-label={`查看任务 ${row.title}`} title={taskTitle} className="min-w-0 flex-1 truncate text-left text-[13px] font-normal text-slate-800 transition-colors hover:text-[#0052D9] focus-visible:outline-2 focus-visible:outline-[#0052D9]/40">{row.title}</button>
    {context}{closed}
    <div className="flex w-[96px] shrink-0 items-center gap-1.5 text-xs text-slate-500" title={row.creator ? `${row.owner} · ${row.creator} 分派` : row.owner}>
      <span className="grid h-5 w-5 shrink-0 place-items-center rounded-full bg-[#0052D9]/8 text-[10px] font-medium text-[#0052D9]">{row.owner[0]}</span><span className="truncate">{row.owner}</span>
    </div>
    {materials}{date}
  </article>;
}