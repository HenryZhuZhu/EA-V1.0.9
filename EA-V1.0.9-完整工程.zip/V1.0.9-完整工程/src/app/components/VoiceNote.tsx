import { Mic, Square, Play, Pause, Trash2 } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";

// Synthesize a short WAV tone as a data URL — used as a fallback "recording"
// when a real microphone isn't available (e.g. opening the offline file://).
// This guarantees the prototype always has a playable clip to demonstrate.
function synthWavDataUrl(seconds = 2, sampleRate = 8000): string {
  const dur = Math.max(0.6, Math.min(seconds, 8));
  const n = Math.floor(dur * sampleRate);
  const dataSize = n * 2;
  const buffer = new ArrayBuffer(44 + dataSize);
  const view = new DataView(buffer);
  let p = 0;
  const wstr = (s: string) => { for (let i = 0; i < s.length; i++) view.setUint8(p++, s.charCodeAt(i)); };
  const u32 = (v: number) => { view.setUint32(p, v, true); p += 4; };
  const u16 = (v: number) => { view.setUint16(p, v, true); p += 2; };
  wstr("RIFF"); u32(36 + dataSize); wstr("WAVE");
  wstr("fmt "); u32(16); u16(1); u16(1); u32(sampleRate); u32(sampleRate * 2); u16(2); u16(16);
  wstr("data"); u32(dataSize);
  for (let i = 0; i < n; i++) {
    const t = i / sampleRate;
    const env = Math.min(1, t * 4, (dur - t) * 4);
    // wobble the frequency a bit so it reads as a "voice memo" rather than a flat beep
    const freq = 200 + 60 * Math.sin(2 * Math.PI * 1.5 * t);
    const sample = Math.sin(2 * Math.PI * freq * t) * 0.22 * env;
    view.setInt16(p, sample * 32767, true); p += 2;
  }
  let bin = "";
  const bytes = new Uint8Array(buffer);
  for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
  return "data:audio/wav;base64," + btoa(bin);
}

function fmt(sec: number) {
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
}

// ---- Recorder: records a clip and returns it as a data URL ----
export function VoiceRecorder({
  value,
  onChange,
  compact = false,
  idleLabel = "录制语音",
  iconOnly = false,
  onBusyChange,
}: {
  value?: string;
  onChange: (dataUrl: string | undefined) => void;
  compact?: boolean;
  idleLabel?: string;
  iconOnly?: boolean;
  onBusyChange?: (busy: boolean) => void;
}) {
  const [recording, setRecording] = useState(false);
  const [preparing, setPreparing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [controlsOpen, setControlsOpen] = useState(false);
  const [error, setError] = useState("");
  const [elapsed, setElapsed] = useState(0);
  const timer = useRef<number | null>(null);
  const recorder = useRef<MediaRecorder | null>(null);
  const chunks = useRef<Blob[]>([]);
  const stream = useRef<MediaStream | null>(null);
  const mounted = useRef(true);
  const starting = useRef(false);
  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
      const mr = recorder.current;
      if (mr) {
        mr.onstop = null;
        mr.ondataavailable = null;
        if (mr.state !== "inactive") mr.stop();
      }
      stream.current?.getTracks().forEach((track) => track.stop());
      stream.current = null;
    };
  }, []);
  useEffect(() => { onBusyChange?.(recording || preparing || saving); }, [recording, preparing, saving, onBusyChange]);

  useEffect(() => {
    if (recording) {
      timer.current = window.setInterval(() => setElapsed((e) => e + 1), 1000) as any;
    } else if (timer.current) {
      clearInterval(timer.current);
      timer.current = null;
    }
    return () => { if (timer.current) clearInterval(timer.current); };
  }, [recording]);

  const cleanupStream = () => {
    stream.current?.getTracks().forEach((t) => t.stop());
    stream.current = null;
  };

  const start = async () => {
    if (starting.current || recording || saving) return;
    starting.current = true;
    setPreparing(true);
    setControlsOpen(false);
    setError("");
    setElapsed(0);
    chunks.current = [];
    try {
      const s = await navigator.mediaDevices.getUserMedia({ audio: true });
      if (!mounted.current) { s.getTracks().forEach((track) => track.stop()); return; }
      stream.current = s;
      const mr = new MediaRecorder(s);
      recorder.current = mr;
      mr.ondataavailable = (e) => { if (e.data.size > 0) chunks.current.push(e.data); };
      mr.onstop = () => {
        const blob = new Blob(chunks.current, { type: mr.mimeType || "audio/webm" });
        cleanupStream();
        if (!mounted.current) return;
        if (!blob.size) { setSaving(false); setError("没有录到声音，请重试。"); return; }
        const reader = new FileReader();
        reader.onload = () => {
          if (!mounted.current) return;
          setSaving(false);
          onChange(reader.result as string);
        };
        reader.onerror = () => { if (mounted.current) { setSaving(false); setError("录音保存失败，请重试。"); } };
        reader.readAsDataURL(blob);
      };
      mr.start();
      setRecording(true);
    } catch {
      cleanupStream();
      recorder.current = null;
      if (!mounted.current) return;
      // 新建任务入口只保留真实录音，不将权限失败伪装成已录制语音。
      if (iconOnly) setError("无法使用麦克风，请检查权限或设备后重试。");
      else setRecording(true); // 保留其他历史演示入口的模拟录音行为。
    } finally {
      starting.current = false;
      if (mounted.current) setPreparing(false);
    }
  };

  const stop = () => {
    setRecording(false);
    if (recorder.current && recorder.current.state !== "inactive") {
      setSaving(true);
      recorder.current.stop();
    } else {
      // simulated fallback
      onChange(synthWavDataUrl(elapsed || 2));
    }
  };

  if (iconOnly) {
    const busy = preparing || saving;
    const caption = recording ? `停止录音（${fmt(elapsed)}）` : preparing ? "正在请求麦克风" : saving ? "正在保存录音" : value ? "查看语音备注" : "录制语音备注";
    return <div className="relative" role="group" aria-label="语音备注">
      <Popover open={controlsOpen && Boolean(value) && !recording} onOpenChange={setControlsOpen}>
        <PopoverTrigger asChild>
          <button type="button" aria-label={caption} title={caption} disabled={busy} onClick={(event) => {
            if (recording) { event.preventDefault(); stop(); }
            else if (!value) { event.preventDefault(); void start(); }
          }} className={`relative flex h-7 w-7 items-center justify-center rounded-md outline-none transition-colors focus-visible:ring-2 focus-visible:ring-[#0052D9]/40 disabled:opacity-40 ${recording ? "bg-red-50 text-red-500" : value ? "bg-blue-50 text-[#0052D9]" : "text-slate-400 hover:bg-white hover:text-[#0052D9]"}`}>
            {recording ? <Square size={14} fill="currentColor" /> : <Mic size={15} />}
            {value && !recording && <span aria-hidden="true" className="absolute right-1 top-1 h-1 w-1 rounded-full bg-[#0052D9]" />}
          </button>
        </PopoverTrigger>
        <PopoverContent align="end" aria-label="语音备注操作" className="w-auto max-w-[320px] p-3">
          {value && <div className="flex items-center gap-2"><VoicePlayer src={value} /><button type="button" aria-label="删除录音" title="删除录音" onClick={() => { onChange(undefined); setControlsOpen(false); setError(""); }} className="grid h-7 w-7 place-items-center rounded text-slate-400 hover:text-red-500"><Trash2 size={13} /></button><button type="button" aria-label="重新录制" title="重新录制" onClick={() => void start()} className="grid h-7 w-7 place-items-center rounded text-slate-500 hover:text-[#0052D9]"><Mic size={14} /></button></div>}
        </PopoverContent>
      </Popover>
      {recording && <span role="status" className="absolute right-8 top-1 whitespace-nowrap rounded bg-white/95 px-1.5 py-0.5 text-[10px] tabular-nums text-red-500">{fmt(elapsed)}</span>}
      {error && <div role="alert" className="absolute right-0 top-9 z-10 w-60 rounded-md border border-red-100 bg-white p-2 text-[11px] text-red-600 shadow-sm">{error}<button type="button" onClick={() => setError("")} className="ml-2 text-slate-500">关闭</button></div>}
    </div>;
  }

  if (value && !recording) {
    return (
      <div className="flex items-center gap-2">
        <VoicePlayer src={value} />
        <button
          type="button"
          onClick={() => onChange(undefined)}
          title="删除录音"
          className="h-7 w-7 shrink-0 rounded-md border border-slate-200 text-slate-400 hover:text-red-500 hover:border-red-300 flex items-center justify-center"
        >
          <Trash2 size={12} />
        </button>
        <button
          type="button"
          onClick={start}
          title="重新录制"
          className="h-7 px-2 shrink-0 rounded-md border border-slate-200 text-slate-500 hover:text-[#0052D9] hover:border-[#0052D9]/40 inline-flex items-center gap-1 text-[11px]"
        >
          <Mic size={11} /> 重录
        </button>
      </div>
    );
  }

  return (
    <button
      type="button"
      disabled={preparing || saving}
      onClick={() => (recording ? stop() : start())}
      className={`inline-flex items-center justify-center gap-1.5 rounded-md border transition-all text-xs ${
        compact ? "h-7 px-2.5" : "h-8 px-3"
      } ${
        recording
          ? "bg-red-500 border-red-500 text-white animate-pulse"
          : "bg-white border-slate-200 text-slate-600 hover:border-[#0052D9]/40 hover:text-[#0052D9]"
      }`}
    >
      {recording ? <Square size={12} /> : <Mic size={12} />}
      {recording ? `录音中 ${fmt(elapsed)} · 点击停止` : idleLabel}
    </button>
  );
}

// ---- Player: plays a data URL clip ----
export function VoicePlayer({ src, label = "语音" }: { src: string; label?: string }) {
  const audio = useRef<HTMLAudioElement | null>(null);
  const [playing, setPlaying] = useState(false);
  const [dur, setDur] = useState(0);
  const [cur, setCur] = useState(0);

  useEffect(() => {
    const a = new Audio(src);
    audio.current = a;
    const onMeta = () => setDur(isFinite(a.duration) ? a.duration : 0);
    const onTime = () => setCur(a.currentTime);
    const onEnd = () => { setPlaying(false); setCur(0); };
    a.addEventListener("loadedmetadata", onMeta);
    a.addEventListener("timeupdate", onTime);
    a.addEventListener("ended", onEnd);
    return () => {
      a.pause();
      a.removeEventListener("loadedmetadata", onMeta);
      a.removeEventListener("timeupdate", onTime);
      a.removeEventListener("ended", onEnd);
    };
  }, [src]);

  const toggle = (e: any) => {
    e.stopPropagation();
    const a = audio.current;
    if (!a) return;
    if (playing) { a.pause(); setPlaying(false); }
    else { a.play(); setPlaying(true); }
  };

  const pct = dur > 0 ? Math.min(100, (cur / dur) * 100) : 0;

  return (
    <div className="inline-flex items-center gap-2 h-7 px-2 rounded-md bg-[#0052D9]/5 border border-[#0052D9]/20 text-[#0052D9] max-w-[180px]">
      <button type="button" onClick={toggle} className="shrink-0 hover:opacity-80" title={playing ? "暂停" : "播放"}>
        {playing ? <Pause size={13} /> : <Play size={13} />}
      </button>
      <div className="flex items-center gap-1.5 min-w-0">
        <Mic size={11} className="shrink-0 opacity-70" />
        <div className="h-1 w-16 bg-[#0052D9]/15 rounded overflow-hidden">
          <div className="h-full bg-[#0052D9] rounded" style={{ width: `${pct}%` }} />
        </div>
        <span className="text-[10px] tabular-nums shrink-0">{fmt(dur || 0)}</span>
      </div>
    </div>
  );
}
