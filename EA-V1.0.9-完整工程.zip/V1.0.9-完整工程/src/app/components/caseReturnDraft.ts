import { flattenTasks, mockCases } from "./data";
import { getClosure } from "./closures";
import { loadCaseTaskTree } from "./caseTaskTrees";

export function caseReturnDraft(caseId: string) {
  const item = mockCases.find(candidate => candidate.id === caseId);
  if (!item) throw new Error("Case 不存在。");
  const closure = getClosure(caseId);
  const excerpt = (value?: string, limit = 240) => {
    const text = value?.trim().replace(/\s+/g, " ") ?? "";
    return text.length > limit ? `${text.slice(0, limit)}...` : text;
  };
  const tasks = flattenTasks(loadCaseTaskTree(caseId, item.tasks)).map(({ task }) => task).filter(task => task.code);
  const unfinished = tasks.filter(task => !["已完成", "已拒绝", "已中止"].includes(task.status));
  const missingResults = tasks.filter(task => task.status === "已完成" && !task.conclusion?.trim());
  const conclusion = excerpt(closure?.conclusion || closure?.workspace?.conclusion || item.aiSummary?.conclusion);
  const background = excerpt(item.background || item.reason);
  return [
    `Case：${excerpt(item.name, 160)}`,
    background ? `问题背景：${background}` : "问题背景：现有记录未填写。",
    conclusion ? `现有结论：${conclusion}` : "现有结论：现有记录未填写。",
    `任务记录：共 ${tasks.length} 项，已完成 ${tasks.filter(task => task.status === "已完成").length} 项，未完成 ${unfinished.length} 项。`,
    "整改建议：",
    conclusion ? "1. 复核上述结论对应的根因、验证过程和证据，修订不一致或不充分之处。" : "1. 补齐结案结论、根因与验证依据。",
    unfinished.length ? `2. 核对未完成任务（${unfinished.slice(0, 3).map(task => excerpt(task.title, 60)).join("、")}${unfinished.length > 3 ? "等" : ""}），明确后续处理与结案依据。` : missingResults.length ? `2. 补齐 ${missingResults.length} 项已完成任务未记录的结论，并核对验证证据。` : "2. 核对任务结果与结案结论的一致性，并补充本次修订的验证记录。",
    "3. 在退回后 24 小时内完成原 Case 文档整改并提交整改结果。",
  ].join("\n");
}