import { Paperclip, UploadCloud, LoaderCircle, X, FileText, FileImage, FileSpreadsheet, File as FileIcon } from "lucide-react";
import { useRef, useState } from "react";
import { readAttachmentFiles } from "./attachmentFiles";

export type Att = { name: string; kind: "pdf" | "image" | "sheet" | "file"; url?: string };

function AttIcon({ kind }: { kind: Att["kind"] }) {
  if (kind === "pdf") return <FileText size={12} className="text-rose-500" />;
  if (kind === "image") return <FileImage size={12} className="text-sky-500" />;
  if (kind === "sheet") return <FileSpreadsheet size={12} className="text-emerald-500" />;
  return <FileIcon size={12} className="text-slate-400" />;
}

// 附件上传：支持图片/文件，图片读为 dataURL 以便预览（原型本地存储）
export function AttachmentInput({
  value = [],
  onChange,
  compact = false,
  variant = "full",
  onUploadingChange,
}: {
  value?: Att[];
  onChange: (next: Att[]) => void;
  compact?: boolean;
  variant?: "full" | "icon" | "chips" | "dropzone";
  onUploadingChange?: (uploading: boolean) => void;
}) {
  const inputRef = useRef<HTMLInputElement | null>(null);
  const pendingRef = useRef(false);
  const valueRef = useRef(value);
  valueRef.current = value;
  const dragDepth = useRef(0);
  const [dragging, setDragging] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState("");

  const addFiles = async (files: FileList | null) => {
    if (!files || files.length === 0 || pendingRef.current) return;
    pendingRef.current = true;
    setUploading(true);
    onUploadingChange?.(true);
    setUploadError("");
    const arr = Array.from(files);
    try {
      const atts = await readAttachmentFiles(arr);
      onChange([...valueRef.current, ...atts]);
    } catch (reason) { setUploadError(reason instanceof Error ? reason.message : "附件读取失败，请重试。"); }
    finally { pendingRef.current = false; setUploading(false); onUploadingChange?.(false); }
  };

  if (variant === "dropzone") {
    return <div role="group" aria-label="附件上传" aria-busy={uploading}>
      <input ref={inputRef} type="file" multiple disabled={uploading} className="hidden" onChange={(event) => { addFiles(event.target.files); event.currentTarget.value = ""; }} />
      <div
        onDragEnter={(event) => {
          if (!Array.from(event.dataTransfer.types).includes("Files")) return;
          event.preventDefault(); event.stopPropagation();
          if (pendingRef.current) return;
          dragDepth.current += 1; setDragging(true);
        }}
        onDragOver={(event) => {
          if (!Array.from(event.dataTransfer.types).includes("Files")) return;
          event.preventDefault(); event.stopPropagation();
          event.dataTransfer.dropEffect = pendingRef.current ? "none" : "copy";
        }}
        onDragLeave={(event) => {
          event.preventDefault(); event.stopPropagation();
          dragDepth.current = Math.max(0, dragDepth.current - 1);
          if (!dragDepth.current) setDragging(false);
        }}
        onDrop={(event) => {
          event.preventDefault(); event.stopPropagation();
          dragDepth.current = 0; setDragging(false);
          addFiles(event.dataTransfer.files);
        }}
      >
        <button type="button" aria-label="拖放或选择附件" aria-disabled={uploading} onClick={() => { if (!pendingRef.current) inputRef.current?.click(); }} className={`flex min-h-[112px] w-full flex-col items-center justify-center gap-2 rounded-lg border border-dashed px-5 py-4 text-center transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0052D9]/40 ${uploading ? "cursor-wait border-slate-200 bg-slate-50 text-slate-400" : dragging ? "border-[#0052D9] bg-blue-50 text-[#0052D9]" : "border-slate-300 bg-slate-50/50 text-slate-500 hover:border-[#0052D9]/50 hover:bg-blue-50/30"}`}>
          {uploading ? <LoaderCircle size={22} className="animate-spin text-[#0052D9]" /> : <UploadCloud size={24} className={dragging ? "text-[#0052D9]" : "text-slate-400"} />}
          <span role="status" className="text-xs">{uploading ? "正在读取附件，请稍候…" : dragging ? "松开即可添加附件" : <>将文件拖到这里，或<span className="ml-1 text-[#0052D9]">点击选择文件</span></>}</span>
          <span className="text-[11px] font-normal text-slate-400">支持多个文件，附件保存在当前浏览器</span>
        </button>
      </div>
      {value.length > 0 && <div className="mt-3">
        <p className="mb-2 text-[11px] text-slate-400">已添加 {value.length} 个附件</p>
        <ul className="grid grid-cols-2 gap-2">{value.map((attachment, index) => <li key={`${attachment.name}-${index}`} className="flex min-w-0 items-center gap-2 rounded-md border border-slate-200 bg-white px-3 py-2">
          <span className="shrink-0"><AttIcon kind={attachment.kind} /></span>
          <span title={attachment.name} className="min-w-0 flex-1 break-all text-xs leading-relaxed text-slate-600">{attachment.name}</span>
          <button type="button" aria-label={`移除附件 ${attachment.name}`} disabled={uploading} onClick={() => onChange(value.filter((_, i) => i !== index))} className="grid h-6 w-6 shrink-0 place-items-center rounded text-slate-400 hover:bg-red-50 hover:text-red-500 focus-visible:outline-2 focus-visible:outline-[#0052D9]/40 disabled:cursor-not-allowed disabled:opacity-40"><X size={13} /></button>
        </li>)}</ul>
      </div>}
      {uploadError && <p role="alert" className="mt-2 text-xs text-red-600">{uploadError}</p>}
    </div>;
  }

  if (variant === "icon") {
    return (
      <>
        <input
          ref={inputRef}
          type="file"
          multiple
          disabled={uploading}
          className="hidden"
          onChange={(e) => { addFiles(e.target.files); e.currentTarget.value = ""; }}
        />
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          disabled={uploading}
          title="上传附件"
          className="h-7 w-7 inline-flex items-center justify-center rounded-md border border-slate-200 bg-white text-slate-400 hover:text-[#0052D9] hover:border-[#0052D9]/50 transition-all shrink-0"
        >
          <Paperclip size={12} />
        </button>
        {uploadError && <span role="alert" className="text-xs text-red-600">{uploadError}</span>}
      </>
    );
  }

  if (variant === "chips") {
    if (value.length === 0) return null;
    return (
      <div className="mt-2 flex flex-wrap items-center gap-1.5">
        {value.map((a, i) => (
          <span
            key={i}
            title={a.name}
            className="inline-flex items-center gap-1 pl-1.5 pr-1 py-0.5 rounded bg-white border border-slate-200 text-[11px] text-slate-600 max-w-[160px]"
          >
            {a.url && a.kind === "image" ? (
              <img src={a.url} alt={a.name} className="w-4 h-4 rounded object-cover shrink-0" />
            ) : (
              <AttIcon kind={a.kind} />
            )}
            <span className="truncate">{a.name}</span>
            <button
              type="button"
              onClick={() => onChange(value.filter((_, j) => j !== i))}
              className="shrink-0 text-slate-300 hover:text-red-500"
            >
              <X size={11} />
            </button>
          </span>
        ))}
      </div>
    );
  }

  return (
    <div>
      <input
        ref={inputRef}
        type="file"
        multiple
        disabled={uploading}
        className="hidden"
        onChange={(e) => { addFiles(e.target.files); e.currentTarget.value = ""; }}
      />
      <div className="flex flex-wrap items-center gap-1.5">
        {value.map((a, i) => (
          <span
            key={i}
            title={a.name}
            className="inline-flex items-center gap-1 pl-1.5 pr-1 py-0.5 rounded bg-white border border-slate-200 text-[11px] text-slate-600 max-w-[160px]"
          >
            {a.url && a.kind === "image" ? (
              <img src={a.url} alt={a.name} className="w-4 h-4 rounded object-cover shrink-0" />
            ) : (
              <AttIcon kind={a.kind} />
            )}
            <span className="truncate">{a.name}</span>
            <button
              type="button"
              disabled={uploading}
              onClick={() => onChange(value.filter((_, j) => j !== i))}
              className="shrink-0 text-slate-300 hover:text-red-500"
            >
              <X size={11} />
            </button>
          </span>
        ))}
        <button
          type="button"
          disabled={uploading}
          onClick={() => inputRef.current?.click()}
          className={`inline-flex items-center gap-1 rounded-md border border-dashed border-slate-300 text-slate-500 hover:border-[#0052D9]/50 hover:text-[#0052D9] transition-colors ${
            compact ? "h-7 px-2 text-[11px]" : "h-8 px-2.5 text-xs"
          }`}
        >
          <Paperclip size={12} /> {uploading ? "正在读取…" : "上传附件"}
        </button>
      </div>
      {uploadError && <p role="alert" className="mt-2 text-xs text-red-600">{uploadError}</p>}
    </div>
  );
}
