import { useState } from "react";
import { Plus, Trash2, ThumbsUp, MessageCircle, Pin, PinOff, Pencil, User, Shield, Calendar } from "lucide-react";
import { CaseItem, TaskNode, urgencyColors, statusColors, levelColors, currentUser, TaskComment, ownerToDepartment } from "./data";
import { CaseProductPill } from "./CaseProductPill";
import { TaskCommentsPanel } from "./TaskCommentsPanel";
import { AddTaskModal, AddTaskPayload } from "./AddTaskModal";

// Patches stored locally for likes/comments per task
type TaskPatch = { likes?: number; likedByMe?: boolean; comments?: TaskComment[] };

interface Props {
  caseItem: CaseItem;
  tasks?: TaskNode[];
  focusMine?: boolean;
  showUrgency?: boolean;
  pinnedId?: string | null;
  onTogglePin?: (taskId: string) => void;
  onTaskClick?: (taskId: string) => void;
  onAddChild?: (parentId: string | null, payload: AddTaskPayload) => void;
  onEditTask?: (taskId: string, payload: AddTaskPayload) => void;
  onDelete?: (taskId: string) => void;
}

export function MindMap({
  caseItem,
  tasks,
  focusMine = false,
  showUrgency = false,
  pinnedId = null,
  onTogglePin,
  onTaskClick,
  onAddChild,
  onEditTask,
  onDelete,
}: Props) {
  const rootTasks = tasks ?? caseItem.tasks;
  const editable = !!(onAddChild && onDelete);
  const [editingThought, setEditingThought] = useState<string | null>(null);
  const [editingAction, setEditingAction] = useState<string | null>(null);
  const [thoughtText, setThoughtText] = useState("");
  const [actionForm, setActionForm] = useState<any>({});
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [openComments, setOpenComments] = useState<string | null>(null);
  const [patches, setPatches] = useState<Record<string, TaskPatch>>({});

  const merged = (t: TaskNode): TaskNode => {
    const p = patches[t.id];
    if (!p) return t;
    return {
      ...t,
      likes: p.likes ?? t.likes ?? 0,
      likedByMe: p.likedByMe ?? t.likedByMe ?? false,
      comments: p.comments ?? t.comments ?? [],
    };
  };

  const toggleLike = (id: string) => {
    setPatches((prev) => {
      const cur = prev[id] ?? {};
      const liked = !(cur.likedByMe ?? false);
      const base = (cur.likes ?? 0);
      return { ...prev, [id]: { ...cur, likedByMe: liked, likes: base + (liked ? 1 : -1) } };
    });
  };
  const addComment = (id: string, content: string) => {
    setPatches((prev) => {
      const cur = prev[id] ?? {};
      const list = cur.comments ?? [];
      const nc: TaskComment = {
        id: `c${Date.now()}`,
        user: currentUser.name,
        time: "刚刚",
        content,
      };
      return { ...prev, [id]: { ...cur, comments: [...list, nc] } };
    });
  };
  const replyComment = (taskId: string, commentId: string, content: string) => {
    setPatches((prev) => {
      const cur = prev[taskId] ?? {};
      const list = cur.comments ?? [];
      const nl = list.map((c) =>
        c.id === commentId
          ? {
              ...c,
              replies: [
                ...(c.replies ?? []),
                { id: `r${Date.now()}`, user: currentUser.name, time: "刚刚", content },
              ],
            }
          : c
      );
      return { ...prev, [taskId]: { ...cur, comments: nl } };
    });
  };

  // 添加顶层思路
  const addTopLevelThought = () => {
    const newTask: TaskNode = {
      id: `task-${Date.now()}`,
      title: "新的思路/怀疑方向",
      owner: "待指派",
      department: "PTE",
      urgency: "一般",
      progress: 0,
      status: "待接受",
    };
    onAddChild?.(null, {
      kind: "怀疑目标",
      title: newTask.title,
      department: newTask.department,
      urgency: newTask.urgency,
      assignee: "",
      dueDate: "",
      type: undefined,
      note: "",
      supervisor: "",
      site: undefined,
    });
  };

  // 更新思路文本
  const updateThoughtText = (taskId: string, newText: string) => {
    onEditTask?.(taskId, {
      kind: "怀疑目标",
      title: newText,
      department: "PTE",
      urgency: "一般",
      assignee: "",
      dueDate: "",
      type: undefined,
      note: "",
      supervisor: "",
      site: undefined,
    });
  };

  // Filter
  const filtered: TaskNode[] = focusMine
    ? rootTasks
        .map((d) => {
          if (d.owner === currentUser.name) return d;
          const myKids = (d.children ?? []).filter((c) => c.owner === currentUser.name);
          if (myKids.length > 0) return { ...d, children: myKids };
          return null;
        })
        .filter((x): x is TaskNode => x !== null)
    : rootTasks;

  // Find target task for comments panel
  const findInTree = (id: string, list: TaskNode[]): TaskNode | null => {
    for (const t of list) {
      if (t.id === id) return t;
      if (t.children) {
        const r = findInTree(id, t.children);
        if (r) return r;
      }
    }
    return null;
  };
  const commentTarget = openComments ? findInTree(openComments, filtered) : null;
  const commentTargetMerged = commentTarget ? merged(commentTarget) : null;

  return (
    <div className="relative bg-gradient-to-br from-slate-50 to-white border border-slate-200 rounded-lg overflow-hidden">
      <div className="relative overflow-x-auto">
        <NewStyleCanvas
          caseItem={caseItem}
          tasks={filtered}
          editable={editable}
          showUrgency={showUrgency}
          onAddTopLevel={addTopLevelThought}
          onTaskClick={onTaskClick}
          onDelete={onDelete}
          onAddChild={onAddChild}
          onEditTask={onEditTask}
          merged={merged}
          onToggleLike={toggleLike}
          onOpenComments={(id) => setOpenComments(id)}
          selectedId={selectedId}
          onSelect={(id: string) => setSelectedId(selectedId === id ? null : id)}
          pinnedId={pinnedId}
          onTogglePin={onTogglePin}
          editingThought={editingThought}
          setEditingThought={setEditingThought}
          thoughtText={thoughtText}
          setThoughtText={setThoughtText}
          editingAction={editingAction}
          setEditingAction={setEditingAction}
          actionForm={actionForm}
          setActionForm={setActionForm}
          updateThoughtText={updateThoughtText}
        />

        {commentTargetMerged && (
          <TaskCommentsPanel
            taskTitle={commentTargetMerged.title}
            comments={commentTargetMerged.comments ?? []}
            likes={commentTargetMerged.likes ?? 0}
            likedByMe={commentTargetMerged.likedByMe ?? false}
            onAddComment={(c) => addComment(commentTargetMerged.id, c)}
            onReply={(cid, c) => replyComment(commentTargetMerged.id, cid, c)}
            onToggleLike={() => toggleLike(commentTargetMerged.id)}
            onClose={() => setOpenComments(null)}
          />
        )}
      </div>

      {focusMine && (
        <div className="px-4 py-2 text-xs text-slate-500 border-t border-slate-100">
          · 已聚焦"我的任务"，仅显示我负责的任务及其直接父任务。
        </div>
      )}
    </div>
  );
}

// ---------------- New Style Canvas: 横向滚动的思维导图 ----------------
function NewStyleCanvas({
  caseItem,
  tasks,
  editable,
  showUrgency,
  onAddTopLevel,
  onTaskClick,
  onDelete,
  onAddChild,
  onEditTask,
  merged,
  onToggleLike,
  onOpenComments,
  selectedId,
  onSelect,
  pinnedId,
  onTogglePin,
  editingThought,
  setEditingThought,
  thoughtText,
  setThoughtText,
  editingAction,
  setEditingAction,
  actionForm,
  setActionForm,
  updateThoughtText,
}: any) {
  return (
    <div className="p-4">
      <div className="overflow-x-auto pb-4">
        <div className="inline-flex items-start gap-4 min-w-full">
          {/* Case Card */}
          <div className="inline-flex items-center gap-4 shrink-0">
            <div className="w-[280px]">
              <div className="bg-white border-2 border-slate-200 rounded-xl p-4 shadow-sm">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-1">
                    <div className={`px-2 py-0.5 rounded text-xs border ${levelColors[caseItem.level]}`}>
                      {caseItem.level}
                    </div>
                    <CaseProductPill caseItem={caseItem} compact />
                  </div>
                  <div className="text-xs text-slate-400 font-mono">{caseItem.code}</div>
                </div>
                <h4 className="text-sm font-medium text-slate-900 leading-snug mb-2 line-clamp-2">
                  {caseItem.name}
                </h4>
                <div className="space-y-1.5 text-xs text-slate-500">
                  <div className="flex items-center gap-1.5">
                    <User size={12} />
                    <span>Owner: {caseItem.owner}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Shield size={12} />
                    <span>{caseItem.urgency}</span>
                  </div>
                </div>
              </div>
            </div>

            {editable && (
              <button
                onClick={onAddTopLevel}
                className="w-10 h-10 shrink-0 rounded-full border-2 border-dashed border-slate-300 hover:border-[#0052D9] hover:bg-[#0052D9]/5 flex items-center justify-center text-slate-400 hover:text-[#0052D9] transition-all"
                title="添加顶层思路"
              >
                <Plus size={18} />
              </button>
            )}
          </div>

          {/* Thought Groups */}
          {tasks.length > 0 && (
            <div className="inline-flex items-start gap-4 shrink-0">
              <div className="shrink-0 self-start mt-[60px]">
                <div className="w-8 h-0.5 bg-slate-300" />
              </div>

              <div className="inline-flex flex-col gap-6 shrink-0">
                {tasks.map((thoughtTask: TaskNode) => (
                  <ThoughtGroupDisplay
                    key={thoughtTask.id}
                    thoughtTask={thoughtTask}
                    editable={editable}
                    showUrgency={showUrgency}
                    onTaskClick={onTaskClick}
                    onDelete={onDelete}
                    onAddChild={onAddChild}
                    onEditTask={onEditTask}
                    merged={merged}
                    onToggleLike={onToggleLike}
                    onOpenComments={onOpenComments}
                    selectedId={selectedId}
                    onSelect={onSelect}
                    pinnedId={pinnedId}
                    onTogglePin={onTogglePin}
                    editingThought={editingThought}
                    setEditingThought={setEditingThought}
                    thoughtText={thoughtText}
                    setThoughtText={setThoughtText}
                    editingAction={editingAction}
                    setEditingAction={setEditingAction}
                    actionForm={actionForm}
                    setActionForm={setActionForm}
                    updateThoughtText={updateThoughtText}
                  />
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// 思路组展示（递归组件）
function ThoughtGroupDisplay({
  thoughtTask,
  editable,
  showUrgency,
  onTaskClick,
  onDelete,
  onAddChild,
  onEditTask,
  merged,
  onToggleLike,
  onOpenComments,
  selectedId,
  onSelect,
  pinnedId,
  onTogglePin,
  editingThought,
  setEditingThought,
  thoughtText,
  setThoughtText,
  editingAction,
  setEditingAction,
  actionForm,
  setActionForm,
  updateThoughtText,
}: any) {
  const task = merged(thoughtTask);
  const actions = task.children || [];
  const isEditing = editingThought === task.id;

  return (
    <div className="inline-flex items-start gap-4 shrink-0">
      {/* Vertical Column for Thought + Actions */}
      <div className="inline-flex flex-col gap-3 shrink-0 w-[360px]">
        {/* Thought Card */}
        <div className="bg-amber-50/50 border border-amber-200 rounded-lg p-4 relative group/thought">
          {!isEditing ? (
            <>
              <div className="absolute right-2 top-2 flex gap-1 opacity-0 group-hover/thought:opacity-100 transition-opacity">
                {editable && (
                  <>
                    <button
                      onClick={() => {
                        setThoughtText(task.title);
                        setEditingThought(task.id);
                      }}
                      className="w-6 h-6 rounded hover:bg-white/80 flex items-center justify-center text-slate-500 hover:text-[#0052D9]"
                    >
                      <Pencil size={12} />
                    </button>
                    <button
                      onClick={() => {
                        if (confirm(`删除思路「${task.title}」及其所有执行任务？`)) {
                          onDelete?.(task.id);
                        }
                      }}
                      className="w-6 h-6 rounded hover:bg-white/80 flex items-center justify-center text-slate-500 hover:text-red-500"
                    >
                      <Trash2 size={12} />
                    </button>
                  </>
                )}
              </div>
              <div className="text-[11px] text-amber-700 mb-2 font-medium tracking-wide">思路 / 怀疑方向</div>
              <p className="text-[13px] text-slate-700 leading-relaxed font-medium mb-3">
                {task.title}
              </p>
              <div className="pt-2 border-t border-amber-200/50 flex items-center gap-1.5">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleLike?.(task.id);
                  }}
                  className={`h-5 px-1.5 text-[10px] rounded inline-flex items-center gap-0.5 transition-all ${
                    task.likedByMe
                      ? "bg-amber-100 text-amber-700"
                      : "text-slate-500 hover:bg-amber-50"
                  }`}
                >
                  <ThumbsUp size={10} /> {task.likes || 0}
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onOpenComments?.(task.id);
                  }}
                  className="h-5 px-1.5 text-[10px] rounded inline-flex items-center gap-0.5 text-slate-500 hover:bg-amber-50"
                >
                  <MessageCircle size={10} /> {(task.comments || []).length}
                </button>
              </div>
            </>
          ) : (
            <>
              <div className="text-xs text-amber-700 mb-1.5">编辑思路</div>
              <textarea
                value={thoughtText}
                onChange={(e) => setThoughtText(e.target.value)}
                className="w-full min-h-[80px] p-2 rounded border border-amber-300 bg-white text-sm outline-none focus:border-amber-500"
                autoFocus
              />
              <div className="flex gap-2 mt-2">
                <button
                  onClick={() => {
                    updateThoughtText(task.id, thoughtText);
                    setEditingThought(null);
                  }}
                  className="flex-1 h-7 rounded bg-[#0052D9] text-white text-xs hover:bg-[#003FA8]"
                >
                  确认
                </button>
                <button
                  onClick={() => setEditingThought(null)}
                  className="flex-1 h-7 rounded border border-slate-200 text-slate-600 text-xs hover:bg-slate-50"
                >
                  取消
                </button>
              </div>
            </>
          )}

        </div>

        {/* Vertical connecting line */}
        <div className="ml-8 h-4 w-0.5 bg-slate-300" />

        {/* Actions - Indented */}
        <div className="ml-8 space-y-3">
          {actions.map((action: TaskNode) => (
            <ActionDisplay
              key={action.id}
              action={action}
              parentId={task.id}
              editable={editable}
              showUrgency={showUrgency}
              onTaskClick={onTaskClick}
              onDelete={onDelete}
              onAddChild={onAddChild}
              onEditTask={onEditTask}
              merged={merged}
              onToggleLike={onToggleLike}
              onOpenComments={onOpenComments}
              selectedId={selectedId}
              onSelect={onSelect}
              pinnedId={pinnedId}
              onTogglePin={onTogglePin}
              editingThought={editingThought}
              setEditingThought={setEditingThought}
              thoughtText={thoughtText}
              setThoughtText={setThoughtText}
              editingAction={editingAction}
              setEditingAction={setEditingAction}
              actionForm={actionForm}
              setActionForm={setActionForm}
              updateThoughtText={updateThoughtText}
            />
          ))}
          {editable && (
            <button
              onClick={() => {
                const newAction: TaskNode = {
                  id: `action-${Date.now()}`,
                  title: "执行任务",
                  owner: "待指派",
                  department: "PTE",
                  urgency: "一般",
                  progress: 0,
                  status: "待接受",
                };
                onAddChild?.(task.id, {
                  kind: "执行任务",
                  title: newAction.title,
                  department: newAction.department,
                  urgency: newAction.urgency,
                  assignee: "",
                  dueDate: "",
                  type: undefined,
                  note: "",
                  supervisor: "",
                  site: undefined,
                });
              }}
              className="w-[280px] h-10 border-2 border-dashed border-slate-300 rounded-lg text-slate-400 hover:border-[#0052D9] hover:text-[#0052D9] hover:bg-[#0052D9]/5 flex items-center justify-center gap-1.5 text-xs transition-all"
            >
              <Plus size={14} /> 添加执行任务
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

// 执行任务展示（递归组件）
function ActionDisplay({
  action,
  parentId,
  editable,
  showUrgency,
  onTaskClick,
  onDelete,
  onAddChild,
  onEditTask,
  merged,
  onToggleLike,
  onOpenComments,
  selectedId,
  onSelect,
  pinnedId,
  onTogglePin,
  editingThought,
  setEditingThought,
  thoughtText,
  setThoughtText,
  editingAction,
  setEditingAction,
  actionForm,
  setActionForm,
  updateThoughtText,
}: any) {
  const task = merged(action);
  const childGroups = task.children || [];
  const isEditing = editingAction === task.id;

  const urgencyColorMap: Record<string, string> = {
    非常紧急: "bg-red-500 text-white",
    紧急: "bg-orange-500 text-white",
    一般: "bg-blue-500 text-white",
    不紧急: "bg-slate-400 text-white",
  };

  const isHighlighted = pinnedId === task.id;

  return (
    <div className="inline-flex items-start gap-4">
      {/* Action Card */}
      <div className="inline-flex items-start gap-4">
        {!isEditing ? (
          <div
            className={`w-[280px] bg-white rounded-lg p-3.5 relative group/action shadow-sm transition-all ${
              isHighlighted
                ? "border-2 border-[#0052D9] ring-2 ring-[#0052D9]/30"
                : "border border-slate-200"
            }`}
          >
            {editable && (
              <div className="absolute right-2 top-2 flex gap-1 opacity-0 group-hover/action:opacity-100 transition-opacity">
                <button
                  onClick={() => {
                    setActionForm({
                      title: task.title,
                      urgency: task.urgency,
                      department: task.department,
                      assignee: task.owner === "待指派" ? "" : task.owner,
                      dueDate: task.dueDate || "",
                      note: task.note || "",
                    });
                    setEditingAction(task.id);
                  }}
                  className="w-6 h-6 rounded hover:bg-slate-50 flex items-center justify-center text-slate-500 hover:text-[#0052D9]"
                >
                  <Pencil size={12} />
                </button>
                <button
                  onClick={() => {
                    if (confirm(`删除执行任务「${task.title}」及其所有子任务？`)) {
                      onDelete?.(task.id);
                    }
                  }}
                  className="w-6 h-6 rounded hover:bg-slate-50 flex items-center justify-center text-slate-500 hover:text-red-500"
                >
                  <Trash2 size={12} />
                </button>
              </div>
            )}
            <div className="flex items-center gap-2 mb-2.5">
              <div className="text-[10px] text-slate-400 font-medium">执行任务</div>
              {showUrgency && (
                <span className={`px-2 py-0.5 rounded text-[10px] font-medium ${urgencyColorMap[task.urgency]}`}>
                  {task.urgency}
                </span>
              )}
              <span className={`px-1.5 py-0.5 rounded text-[10px] border ${statusColors[task.status]}`}>
                {task.status}
              </span>
            </div>
            <button
              onClick={() => onTaskClick?.(task.id)}
              className="text-[13px] font-medium text-slate-900 mb-2.5 leading-snug hover:text-[#0052D9] text-left w-full cursor-pointer"
            >
              {task.title}
            </button>
            <div className="space-y-1.5 text-xs text-slate-500 mb-2.5">
              <div className="flex items-center gap-1.5">
                <User size={11} />
                {task.owner}
              </div>
              <div className="flex items-center gap-1.5">
                <span className="text-slate-400">部门:</span>
                {task.department}
              </div>
              {task.dueDate && (
                <div className="flex items-center gap-1.5">
                  <Calendar size={11} />
                  {task.dueDate}
                </div>
              )}
            </div>
            <div className="pt-2 border-t border-slate-100 flex items-center gap-1.5">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onToggleLike?.(task.id);
                }}
                className={`h-5 px-1.5 text-[10px] rounded inline-flex items-center gap-0.5 transition-all ${
                  task.likedByMe
                    ? "bg-[#0052D9]/10 text-[#0052D9]"
                    : "text-slate-500 hover:bg-slate-100"
                }`}
              >
                <ThumbsUp size={10} /> {task.likes || 0}
              </button>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onOpenComments?.(task.id);
                }}
                className="h-5 px-1.5 text-[10px] rounded inline-flex items-center gap-0.5 text-slate-500 hover:bg-slate-100"
              >
                <MessageCircle size={10} /> {(task.comments || []).length}
              </button>
            </div>
          </div>
        ) : (
          <div className="w-[280px] bg-white border-2 border-[#0052D9] rounded-lg p-3.5 shadow-md">
            <div className="space-y-2.5">
              <div>
                <label className="text-xs text-slate-500 block mb-1">任务名称</label>
                <input
                  value={actionForm.title || ""}
                  onChange={(e) => setActionForm({ ...actionForm, title: e.target.value })}
                  placeholder="任务名称"
                  className="w-full h-8 px-2 text-sm border border-slate-200 rounded outline-none focus:border-[#0052D9]"
                />
              </div>
              <div>
                <label className="text-xs text-slate-500 block mb-1">紧急程度</label>
                <select
                  value={actionForm.urgency || "一般"}
                  onChange={(e) => setActionForm({ ...actionForm, urgency: e.target.value })}
                  className="w-full h-8 px-2 text-sm border border-slate-200 rounded outline-none focus:border-[#0052D9]"
                >
                  <option value="非常紧急">非常紧急</option>
                  <option value="紧急">紧急</option>
                  <option value="一般">一般</option>
                  <option value="不紧急">不紧急</option>
                </select>
              </div>
              <div>
                <label className="text-xs text-slate-500 block mb-1">负责人</label>
                <input
                  value={actionForm.assignee || ""}
                  onChange={(e) => {
                    const newAssignee = e.target.value;
                    const newDepartment = ownerToDepartment[newAssignee] || actionForm.department || "PTE";
                    setActionForm({ ...actionForm, assignee: newAssignee, department: newDepartment });
                  }}
                  placeholder="负责人"
                  className="w-full h-8 px-2 text-sm border border-slate-200 rounded outline-none focus:border-[#0052D9]"
                />
              </div>
              <div>
                <label className="text-xs text-slate-500 block mb-1">分派部门</label>
                <input
                  value={actionForm.department || "PTE"}
                  disabled
                  className="w-full h-8 px-2 text-sm border border-slate-200 rounded outline-none bg-slate-50 text-slate-600 cursor-not-allowed"
                />
              </div>
              <div>
                <label className="text-xs text-slate-500 block mb-1">期望完成时间</label>
                <input
                  type="date"
                  value={actionForm.dueDate || ""}
                  onChange={(e) => setActionForm({ ...actionForm, dueDate: e.target.value })}
                  className="w-full h-8 px-2 text-sm border border-slate-200 rounded outline-none focus:border-[#0052D9]"
                />
              </div>
              <div className="flex gap-2 pt-1">
                <button
                  onClick={() => {
                    onEditTask?.(task.id, {
                      kind: "执行任务",
                      title: actionForm.title,
                      department: actionForm.department,
                      urgency: actionForm.urgency,
                      assignee: actionForm.assignee,
                      dueDate: actionForm.dueDate,
                      type: undefined,
                      supervisor: "",
                      site: undefined,
                    });
                    setEditingAction(null);
                  }}
                  className="flex-1 h-7 rounded bg-[#0052D9] text-white text-xs hover:bg-[#003FA8]"
                >
                  确认
                </button>
                <button
                  onClick={() => setEditingAction(null)}
                  className="flex-1 h-7 rounded border border-slate-200 text-slate-600 text-xs hover:bg-slate-50"
                >
                  取消
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Add child group button */}
        {editable && (
          <button
            onClick={() => onAddChild?.(task.id, {
              kind: "思路",
              title: "",
              department: "PTE",
              urgency: "一般",
              assignee: "",
              dueDate: "",
              type: undefined,
              note: "",
              supervisor: "",
              site: undefined,
            })}
            className="w-8 h-8 shrink-0 mt-2 rounded-full border-2 border-dashed border-slate-300 hover:border-[#0052D9] hover:bg-[#0052D9]/5 flex items-center justify-center text-slate-400 hover:text-[#0052D9] transition-all"
            title="基于此动作添加新思路"
          >
            <Plus size={14} />
          </button>
        )}
      </div>

      {/* Child Groups (Recursive) - Right Side of Action */}
      {childGroups.length > 0 && (
        <div className="inline-flex items-start gap-4">
          <div className="shrink-0 mt-[60px]">
            <div className="w-12 h-0.5 bg-slate-300" />
          </div>
          <div className="inline-flex flex-col gap-6 shrink-0">
            {childGroups.map((childTask: TaskNode) => (
              <ThoughtGroupDisplay
                key={childTask.id}
                thoughtTask={childTask}
                editable={editable}
                showUrgency={showUrgency}
                onAddChild={onAddChild}
                onTaskClick={onTaskClick}
                onDelete={onDelete}
                onEditTask={onEditTask}
                merged={merged}
                onToggleLike={onToggleLike}
                onOpenComments={onOpenComments}
                selectedId={selectedId}
                onSelect={onSelect}
                pinnedId={pinnedId}
                onTogglePin={onTogglePin}
                editingThought={editingThought}
                setEditingThought={setEditingThought}
                thoughtText={thoughtText}
                setThoughtText={setThoughtText}
                editingAction={editingAction}
                setEditingAction={setEditingAction}
                actionForm={actionForm}
                setActionForm={setActionForm}
                updateThoughtText={updateThoughtText}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
