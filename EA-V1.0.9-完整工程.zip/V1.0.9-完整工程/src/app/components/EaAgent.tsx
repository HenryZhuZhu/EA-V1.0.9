import { useEffect, useId, useRef, useState } from "react";
import type { PointerEvent as ReactPointerEvent } from "react";
import * as Dialog from "@radix-ui/react-dialog";
import { Maximize2, Minus } from "lucide-react";
import { AiAssistant } from "./AiAssistant";
import { AgentMark } from "./AgentMark";
import { AGENT_POSITION_KEY, agentPanelBounds, clampAgentPosition, initialAgentPosition } from "./eaAgentModel";
import type { AgentPoint } from "./eaAgentModel";
import type { AgentConversation } from "./useAgentConversation";
import "./eaAgent.css";

function viewportSize() { return { width: window.innerWidth, height: window.innerHeight }; }

export function EaAgent({ suspended = false, conversation, onOpenPage, openRequest = 0 }: { suspended?: boolean; conversation: AgentConversation; onOpenPage: () => void; openRequest?: number }) {
  const [viewport, setViewport] = useState(viewportSize);
  const [position, setPosition] = useState(() => {
    let raw = null;
    try { raw = localStorage.getItem(AGENT_POSITION_KEY); } catch { /* Optional preference. */ }
    return initialAgentPosition(raw, viewportSize());
  });
  const [open, setOpen] = useState(false);
  const [dragging, setDragging] = useState(false);
  const { messages, draft, setDraft } = conversation;
  const launcher = useRef<HTMLButtonElement>(null);
  const input = useRef<HTMLTextAreaElement>(null);
  const positionRef = useRef(position);
  const openRequestRef = useRef(openRequest);
  const skipClick = useRef(false);
  const drag = useRef<{ id: number; x: number; y: number; origin: AgentPoint; moved: boolean } | null>(null);
  const panelId = useId();

  const moveTo = (next: AgentPoint) => { positionRef.current = next; setPosition(next); };
  const rememberPosition = (point: AgentPoint) => { try { localStorage.setItem(AGENT_POSITION_KEY, JSON.stringify(point)); } catch { /* Dragging still works without storage. */ } };
  useEffect(() => {
    const resize = () => {
      const size = viewportSize(); setViewport(size);
      const next = clampAgentPosition(positionRef.current, size);
      moveTo(next); rememberPosition(next);
    };
    window.addEventListener("resize", resize);
    return () => window.removeEventListener("resize", resize);
  }, []);
  useEffect(() => {
    if (openRequest === openRequestRef.current) return;
    openRequestRef.current = openRequest;
    setOpen(true);
  }, [openRequest]);

  const onPointerDown = (event: ReactPointerEvent<HTMLButtonElement>) => {
    if (event.button !== 0 || !event.isPrimary) return;
    skipClick.current = false;
    drag.current = { id: event.pointerId, x: event.clientX, y: event.clientY, origin: positionRef.current, moved: false };
    event.currentTarget.setPointerCapture(event.pointerId);
  };
  const onPointerMove = (event: ReactPointerEvent<HTMLButtonElement>) => {
    const session = drag.current;
    if (!session || session.id !== event.pointerId) return;
    const dx = event.clientX - session.x, dy = event.clientY - session.y;
    if (!session.moved && Math.hypot(dx, dy) < 5) return;
    session.moved = true; skipClick.current = true; setDragging(true);
    moveTo(clampAgentPosition({ x: session.origin.x + dx, y: session.origin.y + dy }, viewportSize()));
  };
  const endDrag = (event: ReactPointerEvent<HTMLButtonElement>, cancel = false) => {
    const session = drag.current;
    if (!session || session.id !== event.pointerId) return;
    drag.current = null; setDragging(false);
    if (cancel) { moveTo(clampAgentPosition(session.origin, viewportSize())); skipClick.current = true; }
    else if (session.moved) rememberPosition(positionRef.current);
    if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId);
  };
  const close = () => setOpen(false);
  const send = (text: string) => {
    conversation.send(text, { useSkill: false }); input.current?.focus();
  };
  const bounds = agentPanelBounds(position, viewport);

  return <>
    <button ref={launcher} type="button" className={`ea-agent-launcher ${dragging ? "is-dragging" : ""}`} style={{ left: position.x, top: position.y }} hidden={suspended || open}
      aria-label="打开 EA Agent 对话" aria-haspopup="dialog" aria-expanded={open} aria-controls={panelId}
      title="EA Agent · 点击对话，拖动调整位置；Alt + 方向键移动"
      onPointerDown={onPointerDown} onPointerMove={onPointerMove} onPointerUp={(event) => endDrag(event)} onPointerCancel={(event) => endDrag(event, true)}
      onLostPointerCapture={() => { drag.current = null; setDragging(false); }}
      onKeyDown={(event) => {
        if (event.key === "Enter" || event.key === " ") skipClick.current = false;
        if (!event.altKey || !["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown"].includes(event.key)) return;
        event.preventDefault();
        const next = clampAgentPosition({ x: positionRef.current.x + (event.key === "ArrowRight" ? 20 : event.key === "ArrowLeft" ? -20 : 0), y: positionRef.current.y + (event.key === "ArrowDown" ? 20 : event.key === "ArrowUp" ? -20 : 0) }, viewportSize());
        moveTo(next); rememberPosition(next);
      }}
      onClick={(event) => { if (skipClick.current) { skipClick.current = false; event.preventDefault(); return; } setOpen(true); }}>
      <AgentMark className="ea-agent-logo" />
    </button>

    <Dialog.Root open={open && !suspended} modal={false} onOpenChange={(value) => { if (!value) close(); }}>
      <Dialog.Portal>
        <Dialog.Content id={panelId} className="ea-agent-panel" style={bounds}
          onInteractOutside={(event) => event.preventDefault()} onOpenAutoFocus={(event) => { event.preventDefault(); input.current?.focus(); }}
          onCloseAutoFocus={(event) => { event.preventDefault(); if (!suspended) launcher.current?.focus(); }}>
          <Dialog.Title className="sr-only">EA Agent</Dialog.Title>
          <Dialog.Description className="sr-only">EA Agent 对话小窗</Dialog.Description>
          <div className="ea-agent-window-actions ea-agent-window-actions-overlay">
            <button type="button" aria-label="打开 EA Agent 页面" title="打开 EA Agent 页面" onClick={() => { close(); onOpenPage(); }}><Maximize2 size={15} /></button>
            <button type="button" aria-label="收起 EA Agent" title="收起 EA Agent（保留本次对话）" onClick={close}><Minus size={17} /></button>
          </div>
          {conversation.storageError && <p role="alert" className="px-4 py-2 text-xs text-amber-700">{conversation.storageError}<button type="button" onClick={conversation.retrySave} className="ml-2 underline">重试保存</button></p>}
          <AiAssistant key={conversation.activeSessionId} messages={messages} draft={draft} isRunning={conversation.isRunning} onDraftChange={setDraft} onSend={send} inputRef={input} expanded={false} showPrompts />
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  </>;
}