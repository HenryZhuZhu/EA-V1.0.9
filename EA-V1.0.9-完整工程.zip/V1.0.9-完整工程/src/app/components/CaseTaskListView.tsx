import { useMemo, useState } from "react";
import { ArrowDown, ArrowDownUp, ArrowUp, Lightbulb, ListChecks, Plus } from "lucide-react";
import { currentUser, TaskNode, urgencyBar } from "./data";
import { AddTaskModal, AddTaskPayload, TaskKind } from "./AddTaskModal";
import { StatusBadge } from "./StatusBadge";

interface Props {
  tasks: TaskNode[];
  onTaskClick: (taskId: string) => void;
  onAddTask: (parentId: string | null, payload: AddTaskPayload) => string;
}

interface TaskMetric {
  task: TaskNode;
  depth: number;
  path: string[];
  isThought: boolean;
  durationHours?: number;
}

function parseTime(value?: string): number | null {
  if (!value) return null;
  const time = new Date(value.replace(" ", "T")).getTime();
  return Number.isNaN(time) ? null : time;
}

function taskDurationHours(task: TaskNode): number | undefined {
  const startedAt = task.statusHistory?.find((entry) => entry.status === "进行中")?.at;
  const completedAt = [...(task.statusHistory ?? [])].reverse().find((entry) => entry.status === "已完成")?.at;
  const start = parseTime(startedAt);
  const end = parseTime(completedAt);
  if (start === null || end === null) return undefined;
  return Math.max(0, Math.round(((end - start) / 3600000) * 10) / 10);
}

function AddThoughtIcon() {
  return (
    <span className="relative grid h-4 w-4 place-items-center" aria-hidden="true">
      <Lightbulb size={13} />
      <span className="absolute -right-1 -top-1 grid h-2.5 w-2.5 place-items-center rounded-full bg-[#0052D9] text-white ring-1 ring-white">
        <Plus size={7} strokeWidth={3} />
      </span>
    </span>
  );
}

function AddTaskIcon() {
  return (
    <span className="relative grid h-4 w-4 place-items-center" aria-hidden="true">
      <ListChecks size={13} />
      <span className="absolute -right-1 -top-1 grid h-2.5 w-2.5 place-items-center rounded-full bg-[#0052D9] text-white ring-1 ring-white">
        <Plus size={7} strokeWidth={3} />
      </span>
    </span>
  );
}

function flattenTree(nodes: TaskNode[], durationSort: "none" | "desc" | "asc", depth = 0, path: string[] = []): TaskMetric[] {
  const sortable = durationSort !== "none" && nodes.length > 1 && nodes.every((node) => Boolean(node.code));
  const ordered = sortable ? [...nodes].sort((left, right) => {
    const leftHours = taskDurationHours(left);
    const rightHours = taskDurationHours(right);
    if (typeof leftHours !== "number") return typeof rightHours === "number" ? 1 : 0;
    if (typeof rightHours !== "number") return -1;
    return durationSort === "desc" ? rightHours - leftHours : leftHours - rightHours;
  }) : nodes;
  const result: TaskMetric[] = [];
  ordered.forEach((task) => {
    result.push({ task, depth, path, isThought: !task.code, durationHours: taskDurationHours(task) });
    if (task.children?.length) result.push(...flattenTree(task.children, durationSort, depth + 1, [...path, task.title]));
  });
  return result;
}

function remainingText(task: TaskNode): { text: string; className: string } {
  if (task.status === "已完成" || task.status === "已拒绝" || task.status === "已中止") return { text: task.status, className: "text-slate-400" };
  if (typeof task.dueIn === "number") {
    if (task.dueIn < 0) return { text: `已逾期 ${Math.abs(task.dueIn)} 天`, className: "text-red-500" };
    if (task.dueIn === 0) return { text: "今日到期", className: "text-red-500" };
    return { text: `剩余 ${task.dueIn} 天`, className: task.dueIn <= 3 ? "text-amber-600" : "text-slate-400" };
  }
  const due = parseTime(task.dueDate ?? task.requestedDueDate);
  if (due === null) return { text: "未设置", className: "text-slate-300" };
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const days = Math.ceil((due - today.getTime()) / 86400000);
  if (days < 0) return { text: `已逾期 ${Math.abs(days)} 天`, className: "text-red-500" };
  if (days === 0) return { text: "今日到期", className: "text-red-500" };
  return { text: `剩余 ${days} 天`, className: days <= 3 ? "text-amber-600" : "text-slate-400" };
}

export function CaseTaskListView({ tasks, onTaskClick, onAddTask }: Props) {
  const [durationSort, setDurationSort] = useState<"none" | "desc" | "asc">("none");
  const [adding, setAdding] = useState<{ parentId: string | null; kind: TaskKind; parentTitle?: string } | null>(null);

  const allMetrics = useMemo<TaskMetric[]>(() => flattenTree(tasks, "none"), [tasks]);
  const taskMetrics = useMemo(() => allMetrics.filter((metric) => !metric.isThought), [allMetrics]);
  const thoughtCount = allMetrics.length - taskMetrics.length;

  const durationRanks = useMemo(() => {
    const ranked = taskMetrics
      .filter((metric) => typeof metric.durationHours === "number")
      .sort((left, right) => (right.durationHours ?? 0) - (left.durationHours ?? 0));
    return new Map(ranked.map((metric, index) => [metric.task.id, index + 1]));
  }, [taskMetrics]);

  const visibleRows = useMemo(() => flattenTree(tasks, durationSort), [durationSort, tasks]);

  const cycleDurationSort = () => setDurationSort((current) => current === "none" ? "desc" : current === "desc" ? "asc" : "none");

  return (
    <div className="overflow-hidden rounded-lg border border-slate-200 bg-white">
      <div className="flex h-12 items-center gap-2 border-b border-slate-200 px-4">
        <span className="inline-flex items-center gap-2 text-sm font-semibold text-slate-800"><ListChecks size={15} className="text-[#0052D9]" />任务分解</span>
        <span className="text-[10.5px] text-slate-400">{thoughtCount} 个思路 · {taskMetrics.length} 个任务</span>
        <button type="button" onClick={() => setAdding({ parentId: null, kind: "怀疑目标" })} className="ml-auto inline-flex h-7 items-center gap-1 rounded-md bg-[#0052D9] px-2.5 text-[10.5px] text-white hover:bg-[#003FA8]"><Plus size={11} />新增根思路</button>
      </div>
      <div className="grid h-10 grid-cols-[minmax(280px,1fr)_96px_160px_144px_112px_96px] items-center gap-3 border-b border-slate-200 bg-slate-50 px-5 text-[10.5px] font-semibold text-slate-500">
        <div className="min-w-0">思路 / 任务</div>
        <div>状态</div>
        <div>负责人</div>
        <div className="text-right">期望完成 / 剩余</div>
        <div className="text-right">
          <button
            type="button"
            onClick={cycleDurationSort}
            title={durationSort === "none" ? "点击按耗时从高到低排序" : durationSort === "desc" ? "当前从高到低，点击改为从低到高" : "当前从低到高，点击恢复任务顺序"}
            className="ml-auto inline-flex items-center gap-1 text-[10.5px] font-semibold text-slate-500"
          >
            耗时排行
            {durationSort === "desc" ? <ArrowDown size={11} /> : durationSort === "asc" ? <ArrowUp size={11} /> : <ArrowDownUp size={11} />}
          </button>
        </div>
        <div className="text-right">操作</div>
      </div>

      <div className="divide-y divide-slate-100/70">
        {visibleRows.map(({ task, depth, path, isThought, durationHours }) => {
          if (isThought) {
            const directTasks = (task.children ?? []).filter((child) => Boolean(child.code)).length;
            return (
              <div key={task.id} className="grid min-h-[50px] grid-cols-[minmax(280px,1fr)_96px_160px_144px_112px_96px] items-center gap-3 bg-[#0052D9]/[0.035] px-5 py-2">
                <div className="min-w-0" style={{ paddingLeft: depth * 22 }}>
                  <div className="flex items-center gap-2 text-[12.5px] font-semibold text-slate-800">{depth > 0 && <span className="text-slate-300">└</span>}<span className="inline-flex shrink-0 items-center gap-1 rounded border border-amber-200 bg-amber-50 px-1.5 py-0.5 text-[9.5px] font-normal text-amber-700"><Lightbulb size={10} />思路</span><span className="truncate">{task.title}</span><span className="shrink-0 text-[10px] font-normal text-slate-400">{directTasks} 个任务</span></div>
                  {path.length > 0 && <div className="mt-0.5 truncate text-[10px] text-slate-400">上级：{path[path.length - 1]}</div>}
                </div>
                <div aria-hidden="true" />
                <div aria-hidden="true" />
                <div aria-hidden="true" />
                <div aria-hidden="true" />
                <div className="flex justify-end gap-1">
                  <button type="button" onClick={() => setAdding({ parentId: task.id, kind: "执行任务", parentTitle: task.title })} title="新增任务" aria-label="新增任务" className="grid h-7 w-7 place-items-center rounded-md border border-[#0052D9]/20 bg-white text-[#0052D9] hover:bg-[#0052D9]/5"><AddTaskIcon /></button>
                  <button type="button" onClick={() => setAdding({ parentId: task.id, kind: "怀疑目标", parentTitle: task.title })} title="新增思路" aria-label="新增思路" className="grid h-7 w-7 place-items-center rounded-md border border-slate-200 bg-white text-slate-500 hover:border-[#0052D9]/30 hover:text-[#0052D9]"><AddThoughtIcon /></button>
                </div>
              </div>
            );
          }
          const rank = durationRanks.get(task.id);
          const mine = task.owner === currentUser.name;
          const remaining = remainingText(task);
          return (
            <div key={task.id} title={`紧急度：${task.urgency}`} className="group grid min-h-[62px] grid-cols-[minmax(280px,1fr)_96px_160px_144px_112px_96px] items-center gap-3 px-5 py-2.5 transition-colors hover:bg-slate-50/60">
              <div className="min-w-0" style={{ paddingLeft: depth * 22 }}>
                <div className="flex min-w-0 items-stretch gap-2">
                  <span className={`w-[3px] shrink-0 rounded-full ${urgencyBar[task.urgency]}`} aria-hidden="true" />
                  <div className="min-w-0 flex-1">
                    <button type="button" onClick={() => onTaskClick(task.id)} className="block max-w-full truncate text-left text-sm text-slate-800 transition-colors hover:text-[#0052D9]">{depth > 0 && <span className="mr-1 text-slate-300">└</span>}{task.title}</button>
                    <div className="mt-0.5 flex min-w-0 items-center gap-1.5 text-[10.5px] text-slate-400">
                      {task.code && <span className="shrink-0 font-mono">{task.code}</span>}
                      {task.code && path.length > 0 && <span>·</span>}
                      {path.length > 0 && <span className="truncate">{path[path.length - 1]}</span>}
                    </div>
                  </div>
                </div>
              </div>
              <div>
                <span className="inline-flex items-center gap-1.5 text-[11px] text-slate-500"><StatusBadge status={task.status} size={16} />{task.status}</span>
              </div>
              <div className="flex min-w-0 items-center gap-1.5 text-xs text-slate-600">
                <span className={`grid h-5 w-5 shrink-0 place-items-center rounded-full text-[10px] font-medium ${task.owner === "待指派" ? "bg-slate-100 text-slate-400" : "bg-[#0052D9]/8 text-[#0052D9]"}`}>{task.owner === "待指派" ? "—" : task.owner[0]}</span>
                <span className="truncate">{task.department} · {task.owner}</span>
                {mine && <span className="shrink-0 rounded border border-slate-200 px-1 text-[10px] text-slate-400">我</span>}
              </div>
              <span className="text-right"><span className="block text-xs tabular-nums text-slate-500">{task.dueDate ?? task.requestedDueDate ?? "—"}</span><span className={`mt-0.5 block text-[9.5px] ${remaining.className}`}>{remaining.text}</span></span>
              <span className="flex items-center justify-end gap-2 whitespace-nowrap">
                {typeof durationHours === "number" ? <><span className="rounded bg-[#0052D9]/8 px-1.5 py-0.5 text-[9.5px] font-semibold tabular-nums text-[#0052D9]">#{rank}</span><span className="text-[11px] font-medium tabular-nums text-slate-700">{durationHours}h</span></> : <span className="text-[10.5px] text-slate-300">—</span>}
              </span>
              <div className="flex justify-end gap-1">
                <button type="button" onClick={() => setAdding({ parentId: task.id, kind: "怀疑目标", parentTitle: task.title })} title="新增思路" aria-label="新增思路" className="grid h-7 w-7 place-items-center rounded-md border border-slate-200 text-slate-500 hover:border-[#0052D9]/30 hover:text-[#0052D9]"><AddThoughtIcon /></button>
              </div>
            </div>
          );
        })}
        {!visibleRows.length && <div className="grid min-h-[220px] place-items-center text-sm text-slate-400"><span className="inline-flex items-center gap-2"><ListChecks size={16} />暂无思路和任务</span></div>}
      </div>
      {adding && (
        <AddTaskModal
          titleLabel={adding.kind === "执行任务" ? "新增任务" : "新增思路"}
          submitLabel="创建"
          hint={adding.parentTitle ? `添加到「${adding.parentTitle}」下` : adding.kind === "执行任务" ? "新增 Case 根级任务" : "新增 Case 分析思路"}
          initial={{ kind: adding.kind }}
          onCancel={() => setAdding(null)}
          onSubmit={(payload) => { onAddTask(adding.parentId, payload); setAdding(null); }}
        />
      )}
    </div>
  );
}