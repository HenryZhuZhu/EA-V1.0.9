// Case closure store — Case 根因与结案（两步：① 确认根因·提交 Fanout → 线下验证 → ② 提交结案信息）。
import { useEffect, useState } from "react";
import { currentUser, flattenTasks, mockCases, type CaseItem } from "./data";
import { activeRecovery, validateRecoveryAction, finishRecovery, submitRecovery, trackRecoveryEdit, recoveryText, startRecovery, supplementRecord, type RecoveryAction, type RecoveryEntry, type RecoveryFile } from "./recordRecovery";
import { vpRecoveryExamples } from "./vpRecoveryExamples";

export type ClosureState = "rootcause" | "closed" | "reopened";

export interface ClosureRecord {
  caseId: string;
  state: ClosureState;
  // —— 第一步：确认根因 · 提交 Fanout ——
  domain?: string;            // 根因归属 Domain
  problemType?: string;       // 根因类型
  krByProduct?: Record<string, string>; // 产品 id → KR（同一 Domain 下各产品负责人不同）
  followupNote?: string;      // 跟进说明
  fanoutTargets?: string[];   // 本次 Fanout 的目标产品 id
  fanoutSkipReason?: string;  // 手动取消 Fanout 时的理由
  rootCauseBy?: string;       // 提交根因的人
  rootCauseAt?: string;       // 提交根因时间
  verificationStartedAt?: string | null;
  verificationEndedAt?: string | null;
  // —— 第二步：提交结案信息 ——
  conclusion?: string;        // 结案结论
  files?: { name: string; kind: "pdf" | "image" | "sheet" | "file"; url?: string }[];
  solutionPath?: string[];    // 结案时确认的解题路径任务 id
  submittedBy?: string;
  closedAt?: string;
  approvedBy?: string;
  workspace?: { conclusion: string; process: string; attachments: RecoveryFile[] };
  caseEdits?: Partial<CaseItem>;
  recovery?: RecoveryEntry[];
  approval?: { id: string; kind: "reopen" | "closure"; requestedBy: string; requestedAt: string; reason: string; reviewer: string; decision?: "approved" | "rejected"; decidedAt?: string; note?: string; closure?: { conclusion: string; files?: RecoveryFile[]; solutionPath?: string[] } };
  approvalHistory?: NonNullable<ClosureRecord["approval"]>[];
}

const KEY = "ea_case_closures_v4";
let cache: Record<string, ClosureRecord> | null = null;
const listeners = new Set<() => void>();

function load(): Record<string, ClosureRecord> {
  if (cache) return cache;
  try {
    const raw = typeof localStorage !== "undefined" ? localStorage.getItem(KEY) : null;
    const examples = Object.fromEntries(vpRecoveryExamples.map(example => [example.caseItem.id, JSON.parse(JSON.stringify(example.closure))]));
    cache = { ...examples, ...(raw ? JSON.parse(raw) : {}) };
    for (const record of Object.values(cache!)) syncCaseStatus(record);
  } catch {
    cache = {};
  }
  return cache!;
}

function syncCaseStatus(record: ClosureRecord) {
  const item = mockCases.find(item => item.id === record.caseId);
  if (!item) return;
  if (record.caseEdits) Object.assign(item, record.caseEdits);
  if (record.recovery?.length) item.status = record.state === "closed" ? "已关闭" : record.state === "rootcause" ? "验证中" : "进行中";
}
function saveRecord(record: ClosureRecord) {
  const previous = load()[record.caseId];
  if (previous) record = trackRecoveryEdit(previous, record);
  const next = { ...load(), [record.caseId]: record };
  try { localStorage.setItem(KEY, JSON.stringify(next)); }
  catch { throw new Error("Case 保存失败，请检查浏览器存储后重试。"); }
  cache = next;
  syncCaseStatus(record);
  listeners.forEach((fn) => fn());
}

export function getClosure(caseId: string): ClosureRecord | undefined {
  const record = load()[caseId];
  if (record) syncCaseStatus(record);
  return record;
}

export function isCaseClosed(caseId: string): boolean {
  const record = getClosure(caseId);
  return record ? record.state === "closed" : ["已关闭", "已结案", "已归档"].includes(mockCases.find(item => item.id === caseId)?.status ?? "");
}

// 是否已完成第一步（确认根因 · 提交 Fanout），进入待验证结案阶段。
export function isRootCaused(caseId: string): boolean {
  const s = load()[caseId]?.state;
  return s === "rootcause" || s === "closed";
}

// 第一步：确认根因 · 提交 Fanout（进入待验证结案阶段，尚未关闭）。
export function submitRootCause(input: {
  caseId: string;
  domain: string;
  problemType: string;
  krByProduct: Record<string, string>;
  followupNote?: string;
  fanoutTargets?: string[];
  fanoutSkipReason?: string;
  by: string;
}) {
  const store = load();
  const prev = store[input.caseId];
  const item = mockCases.find(item => item.id === input.caseId);
  if (item && item.owner !== currentUser.name) throw new Error("仅 Case Owner 可以提交根因。");
  if (isCaseClosed(input.caseId)) throw new Error("Case 已结案，请先重新开启。");
  if (prev?.approval && !prev.approval.decision) throw new Error("当前有待处理审批，暂不能修改结案依据。");
  const verificationStartedAt = prev?.state === "rootcause" ? prev.verificationStartedAt ?? prev.rootCauseAt ?? new Date().toISOString() : new Date().toISOString();
  saveRecord({
    ...prev,
    caseId: input.caseId,
    state: "rootcause",
    domain: input.domain,
    problemType: input.problemType,
    krByProduct: input.krByProduct,
    followupNote: input.followupNote,
    fanoutTargets: input.fanoutTargets,
    fanoutSkipReason: input.fanoutSkipReason,
    rootCauseBy: input.by,
    rootCauseAt: new Date().toISOString().slice(0, 16).replace("T", " "),
    verificationStartedAt,
    verificationEndedAt: null,
  });
}

// 第二步：提交结案信息，完成结案（保留第一步的根因/Fanout 记录）。
export function submitClosure(input: {
  caseId: string;
  conclusion: string;
  submittedBy: string;
  files?: { name: string; kind: "pdf" | "image" | "sheet" | "file"; url?: string }[];
  solutionPath?: string[];
}) {
  const store = load();
  const prev = store[input.caseId];
  const item = mockCases.find(item => item.id === input.caseId);
  if (item && item.owner !== currentUser.name) throw new Error("仅 Case Owner 可以提交结案。");
  if (isCaseClosed(input.caseId)) throw new Error("Case 已结案，请勿重复提交。");
  recoveryText(input.conclusion, "结案结论");
  if (item && flattenTasks(item.tasks).some(({ task }) => activeRecovery(task))) throw new Error("请先完成 Case 内正在重新处理的任务。");
  const result: ClosureRecord = { ...(prev ?? { caseId: input.caseId, state: "rootcause" as const }), conclusion: input.conclusion, files: input.files, solutionPath: input.solutionPath };
  const submitted = submitRecovery(trackRecoveryEdit(prev ?? result, result));
  const completed = finishRecovery(submitted);
  if (prev?.approvedBy && prev.recovery?.length) {
    if (prev.approval && !prev.approval.decision) throw new Error("已有待处理的审批。");
    saveRecord({ ...submitted, approvalHistory: [...(prev.approvalHistory ?? []), ...(prev.approval ? [prev.approval] : [])], approval: { id: crypto.randomUUID(), kind: "closure", requestedBy: currentUser.name, requestedAt: new Date().toISOString(), reason: "重新提交结案", reviewer: prev.approvedBy, closure: { conclusion: input.conclusion, files: input.files, solutionPath: input.solutionPath } } });
    return;
  }
  saveRecord({
    ...completed,
    caseId: input.caseId,
    state: "closed",
    conclusion: input.conclusion,
    files: input.files,
    solutionPath: input.solutionPath,
    submittedBy: input.submittedBy,
    closedAt: new Date().toISOString().slice(0, 16).replace("T", " "),
    verificationEndedAt: new Date().toISOString(),
  });
}

export function recoverCase(caseId: string, action: RecoveryAction, text: string, files: RecoveryFile[] = [], dueDate?: string) {
  const item = mockCases.find(item => item.id === caseId);
  if (!item) throw new Error("Case 不存在。");
  const closed = isCaseClosed(caseId);
  const record: ClosureRecord = getClosure(caseId) ?? { caseId, state: closed ? "closed" : item.status === "验证中" ? "rootcause" : "reopened", conclusion: item.aiSummary?.conclusion };
  validateRecoveryAction(item.owner, action);
  if ((action === "reopen" || action === "supplement") && !closed) throw new Error("仅已结案 Case 支持此操作。");
  if (record.approval?.kind === "closure" && !record.approval.decision && action !== "supplement") throw new Error("当前有待处理的审批，请先完成审批。");
  if (action === "supplement") { saveRecord(supplementRecord(record, text, files)); return; }
  const next = startRecovery(record, action, text, [item.owner, item.createdBy ?? ""], dueDate);
  next.recovery![next.recovery!.length - 1].before = { ...next.recovery!.at(-1)!.before, caseInfo: JSON.parse(JSON.stringify(item)) };
  if (record.approval?.kind === "reopen") {
    next.approvalHistory = [...(record.approvalHistory ?? []), record.approval];
    next.approval = undefined;
  }
  saveRecord({ ...next, state: "reopened", verificationStartedAt: null, verificationEndedAt: null });
}

export function decideCaseRecovery(caseId: string, requestId: string, approve: boolean, note: string) {
  const record = getClosure(caseId);
  const request = record?.approval;
  if (!record || !request || request.id !== requestId || request.decision) throw new Error("审批已更新，请刷新。");
  if (request.kind === "reopen") throw new Error("重开申请已改为线下沟通，请由负责人直属主管点击重新处理。");
  if (request.reviewer !== currentUser.name) throw new Error("仅原结案审核人可以确认。");
  const explanation = approve ? note.trim() : recoveryText(note, "驳回原因");
  const decision = { ...request, decision: approve ? "approved" as const : "rejected" as const, note: explanation, decidedAt: new Date().toISOString() };
  if (!approve) { saveRecord({ ...record, approval: decision }); return; }
  const item = mockCases.find(item => item.id === caseId);
  if (!item || item.owner !== request.requestedBy) throw new Error("Case Owner 已变更，请重新申请。");
  if (flattenTasks(item.tasks).some(({ task }) => activeRecovery(task))) throw new Error("仍有任务正在重新处理，暂不能结案。");
  saveRecord({ ...finishRecovery(record), ...request.closure, state: "closed", closedAt: new Date().toISOString(), verificationEndedAt: new Date().toISOString(), submittedBy: request.requestedBy, approval: decision });
}
export function pendingCaseRecoveries() { return Object.values(load()).filter(record => record.approval?.kind === "closure" && !record.approval.decision); }
export function allClosureRecords() { return Object.values(load()); }
export function saveCaseWorkspace(caseId: string, workspace: NonNullable<ClosureRecord["workspace"]>) {
  const item = mockCases.find(item => item.id === caseId);
  const record = getClosure(caseId);
  if (!item || item.owner !== currentUser.name) throw new Error("仅 Case Owner 可以保存文档。");
  if (isCaseClosed(caseId) || (record?.approval && !record.approval.decision)) throw new Error("Case 已结案或待审核，请先完成重新处理流程。");
  saveRecord({ ...(record ?? { caseId, state: item.status === "验证中" ? "rootcause" : "reopened" }), workspace: JSON.parse(JSON.stringify(workspace)) });
}
export function saveCaseEdit(caseId: string, patch: Partial<CaseItem>) {
  const item = mockCases.find(item => item.id === caseId);
  const record = getClosure(caseId);
  if (!item || item.owner !== currentUser.name) throw new Error("仅 Case Owner 可以编辑。");
  if (isCaseClosed(caseId) || (record?.approval && !record.approval.decision)) throw new Error("Case 已结案或待审核，请先完成重新处理流程。");
  const allowed = ["name", "reason", "background", "impact", "urgency", "level", "levelReason", "remark", "dueDate", "problemDomain", "problemType", "caseAttachments", "product", "productId", "productIds", "material", "materialSubtype", "density", "ioType", "failStage", "customer", "failPlatform", "failMode", "failRatio", "failPackage", "maskVersion", "program", "ppm", "pdId", "caseAttribute", "productGeneration", "dimmCapacity", "bitWidth", "projectName", "platformModel", "productPartNumber"];
  const edits = Object.fromEntries(Object.entries(patch).filter(([key]) => allowed.includes(key)));
  saveRecord({ ...(record ?? { caseId, state: item.status === "验证中" ? "rootcause" : "reopened" }), caseEdits: { ...record?.caseEdits, ...edits, updatedAt: new Date().toISOString() } });
}
export function reopenCase(caseId: string) {
  throw new Error("请使用重新处理入口并填写原因，历史结案记录将保留。");
}

export function useClosures() {
  const [, setTick] = useState(0);
  useEffect(() => {
    const fn = () => setTick((t) => t + 1);
    listeners.add(fn);
    return () => {
      listeners.delete(fn);
    };
  }, []);
  return {
    get: getClosure,
    isClosed: isCaseClosed,
    isRootCaused,
    submitRootCause,
    submit: submitClosure,
    reopen: reopenCase,
  };
}
