import type { CaseItem } from "./data";
import { caseCreators } from "./caseWorkbenchModel";

export const CASE_LEVEL_OPTIONS = ["全部", "L0", "L1", "L2", "L3"] as const;
export const CASE_URGENCY_OPTIONS = ["全部", "非常紧急", "紧急", "一般", "不紧急"] as const;
export const CASE_ANALYSIS_STATUS_OPTIONS = ["全部", "进行中", "验证中", "暂存", "已结案"] as const;

// 与分析中心一致：产品按 Case.product 原值，部门按显式 departments，不推导关联。
export function caseFilterOptions(cases: (Pick<CaseItem, "product" | "departments"> & Partial<Pick<CaseItem, "createdBy" | "tasks">>)[]) {
  return {
    products: ["全部", ...new Set(cases.map(c => c.product).filter(Boolean))],
    departments: ["全部", ...new Set(cases.flatMap(c => c.departments || []))],
    creators: ["全部", ...new Set(cases.flatMap(caseCreators))],
  };
}

export interface CaseDimensionValues { level: string; urgency: string; status: string; product: string; department: string; creator?: string }
const fields = [
  { key: "level", label: "层级" }, { key: "urgency", label: "紧急程度" },
  { key: "status", label: "状态" }, { key: "product", label: "产品" },
  { key: "department", label: "部门" }, { key: "creator", label: "创建 / 分派人" },
] as const;
const chevron = { backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%2394a3b8' stroke-width='2'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E\")", backgroundRepeat: "no-repeat", backgroundPosition: "right 6px center" };

// 两处共用同一字段布局和选择样式；状态选项由各工作台的状态模型提供。
export function CaseFilterFields({ values, products, departments, creators = ["全部"], statusOptions = CASE_ANALYSIS_STATUS_OPTIONS, showStatus = true, onChange }: {
  values: CaseDimensionValues; products: string[]; departments: string[]; creators?: string[];
  statusOptions?: readonly string[];
  showStatus?: boolean;
  onChange: (field: keyof CaseDimensionValues, value: string) => void;
}) {
  const options = { level: CASE_LEVEL_OPTIONS, urgency: CASE_URGENCY_OPTIONS, status: statusOptions, product: products, department: departments, creator: creators };
  return <div className="grid grid-cols-2 gap-2">
    {fields.filter(field => showStatus || field.key !== "status").map(({ key, label }) => {
      const value = values[key] || "全部", active = value !== "全部", choices = options[key];
      return <label key={key} className={`inline-flex min-w-0 items-center gap-1 h-8 pl-2.5 pr-0.5 rounded-lg border text-xs transition-colors ${active ? "border-[#0052D9]/40 bg-[#0052D9]/5" : "border-slate-200 bg-white"}`}>
        <span className={`shrink-0 ${active ? "text-[#0052D9]/70" : "text-slate-400"}`}>{label}</span>
        <select aria-label={`Case ${label}`} value={value} title={value} onChange={event => onChange(key, event.target.value)} className={`min-w-0 h-7 pl-1 pr-5 bg-transparent outline-none appearance-none cursor-pointer text-xs max-w-[130px] ${active ? "text-[#0052D9] font-medium" : "text-slate-700"}`} style={chevron}>
          {!choices.includes(value) && <option value={value}>{value}（当前无可选项）</option>}
          {choices.map(option => <option key={option} value={option} className="text-slate-700 font-normal">{option}</option>)}
        </select>
      </label>;
    })}
  </div>;
}