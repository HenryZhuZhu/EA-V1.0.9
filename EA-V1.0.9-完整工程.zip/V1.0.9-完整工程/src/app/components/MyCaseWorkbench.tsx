import { useState } from "react";
import * as Tabs from "@radix-ui/react-tabs";
import { ChevronLeft, ChevronRight, Crown, FilePlus2, FolderOpen, Users, X } from "lucide-react";
import { currentUser, mockProducts, ownerToDepartment, type CaseItem } from "./data";
import { useClosures } from "./closures";
import { useSubscriptions } from "./subscriptions";
import { loadCaseTaskTree, useCaseTaskRevision } from "./caseTaskTrees";
import { CaseWorkbenchFilters } from "./CaseWorkbenchFilters";
import { CaseStatusSummary } from "./CaseStatusSummary";
import { WorkbenchCaseCard } from "./WorkbenchCaseCard";
import { WorkbenchSort } from "./WorkbenchSort";
import { buildCaseWorkbenchRows, CASE_SCOPE_LABELS, CASE_DIMENSION_FILTERS, CASE_WORKBENCH_SORT_OPTIONS, caseWorkbenchFilterCount, caseWorkbenchStatus, createCaseWorkbenchState, currentCaseWorkbenchView, selectCaseWorkbench, updateCaseWorkbenchState, type CaseWorkbenchAction, type CaseWorkbenchScope } from "./caseWorkbenchModel";
import { buildCustomFilterRecords, customFieldCatalog, customFilterOptions } from "./caseCustomFilters";

const SCOPES = [{ key: "mine", Icon: Crown }, { key: "participating", Icon: Users }, { key: "created", Icon: FilePlus2 }] as const;

export function MyCaseWorkbench({ cases, onOpenCase, initialScope = "mine" }: {
  cases: CaseItem[];
  onOpenCase: (id: string) => void;
  initialScope?: CaseWorkbenchScope;
}) {
  const closures = useClosures();
  const subscriptions = useSubscriptions();
  useCaseTaskRevision();
  const [state, setState] = useState(() => createCaseWorkbenchState(initialScope));
  const view = currentCaseWorkbenchView(state);
  const scope = view.scope === "participating" || view.scope === "created" ? view.scope : "mine";
  // 卡片、任务条件和候选值在同次渲染读取同一份持久化执行树与结案快照。
  const currentCases = cases.map(c => ({ ...c, tasks: loadCaseTaskTree(c.id, c.tasks) }));
  const closureById = new Map(cases.map(c => [c.id, closures.get(c.id)]));
  const closure = (id: string) => closureById.get(id);
  const rows = buildCaseWorkbenchRows(currentCases, { products: mockProducts, closure, isSubscribed: subscriptions.isSubscribed, loadTree: c => c.tasks });
  const customRecords = buildCustomFilterRecords(currentCases, { loadTree: c => c.tasks, status: c => caseWorkbenchStatus(c, closure(c.id)), closure });
  const customFields = customFieldCatalog(customRecords);
  const visibleState = state.fanout ? { ...state, fanoutView: { ...view, scope } } : { ...state, views: { ...state.views, [state.status]: { ...view, scope } } };
  const result = selectCaseWorkbench(rows, visibleState, currentUser, ownerToDepartment, undefined, { records: customRecords, fields: customFields });
  const filters = result.filters;
  const fanoutStatus = view.statusFilter || "全部";
  const filterCount = caseWorkbenchFilterCount(filters) + result.appliedCustomRules.length + Number(state.fanout && fanoutStatus !== "全部");
  const dispatch = (action: CaseWorkbenchAction) => setState(previous => updateCaseWorkbenchState(previous, action));

  return <Tabs.Root value={scope} onValueChange={value => { if (value === "mine" || value === "participating" || value === "created") dispatch({ type: "scope", scope: value }); }} asChild><div className="mx-auto w-full max-w-[1400px] space-y-5 px-8 py-6">
    <header className="flex items-center justify-between gap-4"><h1 className="text-xl font-semibold tracking-tight text-slate-900">我的 Case</h1>
      <Tabs.List aria-label="Case 人员视角" className="inline-flex shrink-0 gap-1 rounded-lg bg-slate-100 p-1">{SCOPES.map(({ key, Icon }) => <Tabs.Trigger key={key} value={key} className="inline-flex h-8 items-center gap-1.5 whitespace-nowrap rounded-md px-3 text-xs text-slate-500 data-[state=active]:bg-white data-[state=active]:font-medium data-[state=active]:text-[#0052D9] data-[state=active]:shadow-sm"><Icon size={12} />{CASE_SCOPE_LABELS[key]}</Tabs.Trigger>)}</Tabs.List>
    </header>
    <CaseStatusSummary status={state.status} counts={result.viewCounts} fanout={state.fanout} fanoutCount={result.fanoutCount} onFanout={() => dispatch({ type: "fanout" })} onChange={status => dispatch({ type: state.fanout ? "status" : "status-linked", status })} />
    <Tabs.Content value={scope} asChild>
      <section id="case-status-content" aria-label={`${state.fanout ? "Fanout" : state.status} Case 内容`} className="space-y-4">
        <section aria-label="Case 筛选" className="space-y-3">
          <div className="flex h-10 items-center gap-4 border-b border-slate-200">
            <div className="ml-auto flex shrink-0 items-center gap-2">
              <CaseWorkbenchFilters cases={currentCases} filters={filters} status={state.fanout ? fanoutStatus : state.status} fanout={state.fanout} showStatus={state.fanout} customEditor={{ fields: customFields, rules: view.customRules ?? [], optionsFor: field => customFilterOptions(customRecords, field), onChange: rules => dispatch({ type: "custom-rules", rules }) }} open={view.expanded} onOpenChange={open => { if (open !== view.expanded) dispatch({ type: "expanded" }); }} onChange={patch => dispatch({ type: "filters", patch })} onStatusChange={status => {
                if (state.fanout) dispatch({ type: "fanout-status", status });
                else if (status !== "全部") {
                  dispatch({ type: "status", status });
                  if (!state.views[status].expanded) dispatch({ type: "expanded" });
                }
              }} onReset={() => dispatch({ type: "reset" })} />
              <WorkbenchSort value={result.sortBy} options={CASE_WORKBENCH_SORT_OPTIONS} onChange={sortBy => dispatch({ type: "sort", sortBy })} ariaLabel="我的 Case 排序" />
            </div>
          </div>
          {filterCount > 0 && <div className="flex flex-wrap items-center gap-2 text-[11px]">
            {CASE_DIMENSION_FILTERS.filter(field => filters[field.key] !== "全部").map(field => <button key={field.key} type="button" aria-label={`清除 Case ${field.label}筛选`} title={`${field.label} · ${filters[field.key]}`} onClick={() => dispatch({ type: "filters", patch: { [field.key]: "全部" } })} className="inline-flex max-w-[280px] items-center gap-1 rounded bg-blue-50 px-2 py-1 text-[#0052D9]"><span className="truncate">{field.label} · {filters[field.key]}</span><X size={11} className="shrink-0" /></button>)}
            {state.fanout && fanoutStatus !== "全部" && <button type="button" aria-label="清除 Case 状态筛选" onClick={() => dispatch({ type: "fanout-status", status: "全部" })} className="inline-flex items-center gap-1 rounded bg-blue-50 px-2 py-1 text-[#0052D9]">状态 · {fanoutStatus}<X size={11} /></button>}
            <button type="button" onClick={() => dispatch({ type: "reset" })} className="text-[#0052D9] hover:underline">清除筛选</button>
          </div>}
        </section>
        <div className="space-y-4">
          <section aria-label="Case 列表" className="grid grid-cols-2 gap-4">{result.rows.map(row => <WorkbenchCaseCard key={row.id} row={row} onOpenCase={onOpenCase} />)}</section>
          {!result.total && <div className="grid min-h-[240px] place-items-center rounded-xl border border-dashed border-slate-200 bg-white text-center"><div><FolderOpen size={28} className="mx-auto text-slate-300" /><p className="mt-3 text-sm text-slate-500">当前视角暂无{state.fanout ? " Fanout" : ""} Case</p>{filterCount > 0 && <button type="button" onClick={() => dispatch({ type: "reset" })} className="mt-2 text-xs text-[#0052D9]">清除筛选</button>}</div></div>}
          {result.total > 0 && <div aria-label="Case 分页" className="flex items-center justify-end gap-3 text-xs text-slate-400">
            <span>第 {(result.page - 1) * 8 + 1}–{Math.min(result.page * 8, result.total)} 个 · {result.total} 个 Case</span>
            <div className="flex shrink-0 items-center gap-1 rounded-lg border border-slate-200 bg-white p-1">
              <button type="button" aria-label="上一页 Case" disabled={result.page === 1} onClick={() => dispatch({ type: "page", page: result.page - 1 })} className="grid h-7 w-7 place-items-center rounded hover:bg-slate-50 disabled:opacity-30"><ChevronLeft size={14} /></button>
              <span className="px-2 tabular-nums">{result.page} / {result.pages}</span>
              <button type="button" aria-label="下一页 Case" disabled={result.page === result.pages} onClick={() => dispatch({ type: "page", page: result.page + 1 })} className="grid h-7 w-7 place-items-center rounded hover:bg-slate-50 disabled:opacity-30"><ChevronRight size={14} /></button>
            </div>
          </div>}
        </div>
      </section>
    </Tabs.Content>
  </div></Tabs.Root>;
}