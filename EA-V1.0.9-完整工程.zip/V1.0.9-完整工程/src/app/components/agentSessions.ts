import { AGENT_DEMO_FILES, AGENT_MAX_MESSAGE, type AgentMessage, type AgentSkill } from "./eaAgentModel";

export const AGENT_SESSIONS_KEY = "ea_agent_sessions_v1";
export interface AgentSession {
  id: string;
  title: string;
  group?: string;
  renamed?: boolean;
  createdAt: string;
  updatedAt: string;
  messages: AgentMessage[];
  draft: string;
  activeSkill: AgentSkill | null;
}
export interface AgentSessionState { version: 1; activeId: string; sessions: AgentSession[]; groups: string[] }

export function newAgentSession(): AgentSession {
  const now = new Date().toISOString();
  return { id: globalThis.crypto?.randomUUID?.() ?? `chat-${Date.now()}-${Math.random().toString(36).slice(2)}`, title: "新对话", createdAt: now, updatedAt: now, messages: [], draft: "", activeSkill: null };
}
export function emptyAgentSessions(): AgentSessionState {
  const session = newAgentSession();
  const now = new Date();
  const example = (daysAgo: number, title: string, group?: string): AgentSession => {
    const updated = new Date(now); updated.setDate(updated.getDate() - daysAgo);
    const updatedAt = updated.toISOString();
    return { id: `demo-${now.getTime()}-${daysAgo}-${title}`, title, group, createdAt: updatedAt, updatedAt, messages: [{ id: 1, role: "user", text: title, createdAt: updatedAt }, { id: 2, role: "ai", text: "这是历史对话示例，用于展示对话组与最近对话的归纳方式。", createdAt: updatedAt }], draft: "", activeSkill: null };
  };
  const examples = [
    example(1, "部门 Case 状态与风险复盘", "部门 Case"),
    example(5, "G5 平台问题跟踪", "平台问题"),
    example(20, "DDJOC 产品 Case 进展", "产品 Case"),
    example(1, "昨日任务状态讨论"),
    example(5, "本周 Case 风险跟踪"),
    example(20, "本月问题闭环复盘"),
    example(45, "FT Fail stage 问题分析"),
    example(400, "历史 Case 年度回顾"),
  ];
  return { version: 1, activeId: session.id, sessions: [session, ...examples], groups: ["部门 Case", "平台问题", "产品 Case"] };
}
export function parseAgentSessions(raw: string | null): AgentSessionState {
  try {
    const data = JSON.parse(raw ?? "null");
    if (data?.version !== 1 || !Array.isArray(data.sessions)) return emptyAgentSessions();
    const ids = new Set<string>();
    const sessions: AgentSession[] = data.sessions.filter((item: AgentSession) => {
      if (!item || typeof item.id !== "string" || ids.has(item.id) || typeof item.title !== "string" || !Array.isArray(item.messages)) return false;
      ids.add(item.id); return true;
    }).map((item: AgentSession) => ({
      ...item, title: (item.title === "新会话" ? "新对话" : item.title).slice(0, 80) || "新对话",
      group: typeof item.group === "string" && item.group.trim() ? item.group.trim().slice(0, 40) : undefined,
      createdAt: typeof item.createdAt === "string" ? item.createdAt : "",
      updatedAt: typeof item.updatedAt === "string" ? item.updatedAt : "",
      draft: typeof item.draft === "string" ? item.draft.slice(0, AGENT_MAX_MESSAGE) : "",
      messages: item.messages.filter(message => message && Number.isFinite(message.id) && (message.role === "user" || message.role === "ai") && typeof message.text === "string").map(message => ({
        ...message,
        createdAt: typeof message.createdAt === "string" && Number.isFinite(Date.parse(message.createdAt)) ? message.createdAt : item.updatedAt || item.createdAt || undefined,
        generatedFileIds: message.role === "ai" && Array.isArray(message.generatedFileIds) ? AGENT_DEMO_FILES.filter(file => message.generatedFileIds!.includes(file.id)).map(file => file.id) : undefined,
      })),
      activeSkill: item.activeSkill && [item.activeSkill.id, item.activeSkill.name, item.activeSkill.category].every(value => typeof value === "string") ? item.activeSkill : null,
    }));
    const groups = [...new Set([...(Array.isArray(data.groups) ? data.groups : []), ...sessions.map(item => item.group)].filter((item): item is string => typeof item === "string" && Boolean(item.trim())).map(item => item.trim().slice(0, 40)))];
    return sessions.length ? { version: 1, activeId: sessions.some(item => item.id === data.activeId) ? data.activeId : sessions[0].id, sessions, groups } : emptyAgentSessions();
  } catch { return emptyAgentSessions(); }
}

export function updateAgentSession(state: AgentSessionState, id: string, patch: Partial<Pick<AgentSession, "title" | "group" | "renamed" | "messages" | "draft" | "activeSkill">>): AgentSessionState {
  return { ...state, sessions: state.sessions.map(item => item.id === id ? { ...item, ...patch, updatedAt: new Date().toISOString() } : item) };
}
export function deleteAgentSession(state: AgentSessionState, id: string): AgentSessionState {
  const sessions = state.sessions.filter(item => item.id !== id);
  if (!sessions.length) return emptyAgentSessions();
  return { ...state, sessions, activeId: state.activeId === id ? sessions[0].id : state.activeId };
}

export function createAgentSessionGroup(state: AgentSessionState, name: string): AgentSessionState {
  const group = name.trim().slice(0, 40);
  if (!group || state.groups.includes(group)) return state;
  return { ...state, groups: [...state.groups, group] };
}

export function renameAgentSessionGroup(state: AgentSessionState, previous: string, name: string): AgentSessionState {
  const group = name.trim().slice(0, 40);
  if (!group || group === previous || state.groups.includes(group)) return state;
  return { ...state, groups: state.groups.map(item => item === previous ? group : item), sessions: state.sessions.map(item => item.group === previous ? { ...item, group } : item) };
}

export function deleteAgentSessionGroup(state: AgentSessionState, group: string): AgentSessionState {
  return { ...state, groups: state.groups.filter(item => item !== group), sessions: state.sessions.map(item => item.group === group ? { ...item, group: undefined } : item) };
}