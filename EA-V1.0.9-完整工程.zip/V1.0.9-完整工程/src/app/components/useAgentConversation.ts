import { useEffect, useRef, useState } from "react";
import { AGENT_MAX_MESSAGE, agentDemoFileIds, agentDemoReply, type AgentMessage, type AgentSkill } from "./eaAgentModel";
import type { Skill } from "./skills";
import { AGENT_SESSIONS_KEY, createAgentSessionGroup, deleteAgentSession, deleteAgentSessionGroup, newAgentSession, parseAgentSessions, renameAgentSessionGroup, updateAgentSession, type AgentSessionState } from "./agentSessions";

// 页面与悬浮窗口共享同一次对话；不写入业务记录，不请求远端 AI。
export function useAgentConversation() {
  const [sessionState, setSessionState] = useState(() => {
    try { return parseAgentSessions(localStorage.getItem(AGENT_SESSIONS_KEY)); } catch { return parseAgentSessions(null); }
  });
  const current = sessionState.sessions.find(item => item.id === sessionState.activeId)!;
  const [messages, setMessages] = useState<AgentMessage[]>(current.messages);
  const [draft, setDraftValue] = useState(current.draft);
  const [activeSkill, setActiveSkill] = useState<AgentSkill | null>(current.activeSkill);
  const [storageError, setStorageError] = useState("");
  const [runningSessionIds, setRunningSessionIds] = useState<string[]>([]);
  const pendingReplies = useRef(new Map<string, ReturnType<typeof setTimeout>>());
  const messageId = useRef(Math.max(0, ...current.messages.map(item => item.id)));
  const selectedSkill = useRef<AgentSkill | null>(current.activeSkill);
  const stateRef = useRef(sessionState);
  useEffect(() => () => {
    for (const timer of pendingReplies.current.values()) clearTimeout(timer);
    pendingReplies.current.clear();
  }, []);
  const commit = (next: AgentSessionState) => {
    stateRef.current = next;
    setSessionState(next);
    const session = next.sessions.find(item => item.id === next.activeId)!;
    setMessages(session.messages); setDraftValue(session.draft); setActiveSkill(session.activeSkill);
    selectedSkill.current = session.activeSkill;
    messageId.current = Math.max(0, ...session.messages.map(item => item.id));
    try { localStorage.setItem(AGENT_SESSIONS_KEY, JSON.stringify(next)); setStorageError(""); }
    catch { setStorageError("对话暂存于当前页面，浏览器存储失败；刷新可能丢失，请重试保存。"); }
  };
  const setDraft = (value: string) => commit(updateAgentSession(stateRef.current, stateRef.current.activeId, { draft: value.slice(0, AGENT_MAX_MESSAGE) }));
  const selectSkill = (skill: Skill | null) => {
    if (skill && skill.status !== "已发布") return;
    const snapshot = skill ? { id: skill.id, name: skill.name, category: skill.category } : null;
    commit(updateAgentSession(stateRef.current, stateRef.current.activeId, { activeSkill: snapshot }));
  };
  const send = (text: string, options: { useSkill?: boolean } = {}) => {
    const question = text.trim();
    const state = stateRef.current;
    const session = state.sessions.find(item => item.id === state.activeId)!;
    if (!question || question.length > AGENT_MAX_MESSAGE || pendingReplies.current.has(session.id)) return;
    const skill = options.useSkill === false ? null : selectedSkill.current;
    const context = skill ? { skillName: skill.name } : {};
    const createdAt = new Date().toISOString();
    const user: AgentMessage = { id: ++messageId.current, role: "user", text: question, createdAt, ...context };
    const generatedFileIds = skill ? [] : agentDemoFileIds(question);
    const reply: AgentMessage = { id: ++messageId.current, role: "ai", text: agentDemoReply(question, skill), createdAt, ...context, ...(generatedFileIds.length ? { generatedFileIds } : {}) };
    const timer = setTimeout(() => {
      pendingReplies.current.delete(session.id);
      setRunningSessionIds([...pendingReplies.current.keys()]);
      const latest = stateRef.current;
      const target = latest.sessions.find(item => item.id === session.id);
      if (!target) return;
      commit(updateAgentSession(latest, target.id, { messages: [...target.messages, { ...reply, createdAt: new Date().toISOString() }] }));
    }, 1600);
    pendingReplies.current.set(session.id, timer);
    setRunningSessionIds([...pendingReplies.current.keys()]);
    commit(updateAgentSession(state, session.id, { messages: [...session.messages, user], draft: "", ...(!session.renamed && !session.messages.length ? { title: question.slice(0, 36) } : {}) }));
  };
  const newSession = (group?: string) => {
    const session = { ...newAgentSession(), ...(group && stateRef.current.groups.includes(group) ? { group } : {}) };
    commit({ ...stateRef.current, activeId: session.id, sessions: [session, ...stateRef.current.sessions] });
  };
  const openSession = (id: string) => { if (stateRef.current.sessions.some(item => item.id === id)) commit({ ...stateRef.current, activeId: id }); };
  const renameSession = (id: string, title: string) => { if (title.trim()) commit(updateAgentSession(stateRef.current, id, { title: title.trim().slice(0, 80), renamed: true })); };
  const deleteSession = (id: string) => {
    const timer = pendingReplies.current.get(id);
    if (timer !== undefined) {
      clearTimeout(timer);
      pendingReplies.current.delete(id);
      setRunningSessionIds([...pendingReplies.current.keys()]);
    }
    commit(deleteAgentSession(stateRef.current, id));
  };
  const createGroup = (name: string) => commit(createAgentSessionGroup(stateRef.current, name));
  const renameGroup = (previous: string, name: string) => commit(renameAgentSessionGroup(stateRef.current, previous, name));
  const deleteGroup = (group: string) => commit(deleteAgentSessionGroup(stateRef.current, group));
  const moveSessionToGroup = (id: string, group?: string) => commit(updateAgentSession(stateRef.current, id, { group }));
  return { messages, draft, setDraft, send, isRunning: runningSessionIds.includes(sessionState.activeId), activeSkill, selectSkill, sessions: sessionState.sessions, groups: sessionState.groups, activeSessionId: sessionState.activeId, newSession, openSession, renameSession, deleteSession, createGroup, renameGroup, deleteGroup, moveSessionToGroup, storageError, retrySave: () => commit(stateRef.current) };
}
export type AgentConversation = ReturnType<typeof useAgentConversation>;