import { useMemo, useState } from "react";
import {
  Trophy, Sparkles, Store, Search, Plus, Star, Download, Pencil, Trash2, X as XIcon, Bot, Award, Users, Rocket,
} from "lucide-react";
import { Skill, SKILL_CATEGORIES, useSkills } from "./skills";

const catColor: Record<string, string> = {
  失效分析: "bg-[#0052D9]/8 text-[#0052D9]",
  测试自动化: "bg-[#00A4FF]/12 text-[#0284c7]",
  数据处理: "bg-emerald-50 text-emerald-600",
  报告生成: "bg-amber-50 text-amber-600",
  知识问答: "bg-[#7A3DFF]/8 text-[#7A3DFF]",
  其他: "bg-slate-100 text-slate-500",
};

export function ContestView() {
  const { skills, upsert, remove, currentUser } = useSkills();
  const [q, setQ] = useState("");
  const [cat, setCat] = useState<string>("全部");
  const [editing, setEditing] = useState<null | Partial<Skill>>(null);

  const filtered = useMemo(() => {
    const kw = q.trim().toLowerCase();
    return skills.filter((s) => {
      if (cat !== "全部" && s.category !== cat) return false;
      if (!kw) return true;
      return [s.name, s.description, s.author, ...s.tags].join(" ").toLowerCase().includes(kw);
    });
  }, [skills, q, cat]);

  const totalInstalls = skills.reduce((a, s) => a + s.installs, 0);
  const authors = new Set(skills.map((s) => s.author)).size;

  return (
    <div className="relative">
      <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(ellipse_80%_50%_at_0%_0%,rgba(122,61,255,0.06),transparent_60%)]" />
      <div className="relative p-8 max-w-[1200px] mx-auto space-y-6">
        {/* Hero */}
        <div className="rounded-2xl border border-slate-200/80 bg-white shadow-[0_1px_2px_0_rgba(15,23,42,0.04)] overflow-hidden">
          <div className="h-1.5 bg-gradient-to-r from-[#7A3DFF] via-[#0052D9] to-[#00A4FF]" />
          <div className="p-6 flex items-start gap-4">
            <div className="w-12 h-12 rounded-xl grid place-items-center text-white shrink-0 bg-gradient-to-br from-[#7A3DFF] to-[#0052D9]">
              <Trophy size={24} />
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-[22px] font-bold text-slate-900 tracking-tight">AI 创新大赛</h1>
                <span className="text-[11px] px-2 py-0.5 rounded-full border border-[#7A3DFF]/40 text-[#7A3DFF] bg-[#7A3DFF]/5">2026 赛季进行中</span>
              </div>
              <p className="text-[13px] text-slate-500 mt-1.5 max-w-2xl leading-relaxed">
                面向 PTE 工程团队的 AI 应用共创大赛。将你在失效分析、测试自动化中的经验沉淀为可复用的 <b className="text-slate-700">Skill</b>，发布到开发市场供全员调用，并参与赛季评比。
              </p>
              <div className="flex items-center gap-5 mt-3 text-[12px] text-slate-500">
                <span className="flex items-center gap-1.5"><Rocket size={13} className="text-[#7A3DFF]" /> 参赛 Skill <b className="text-slate-800">{skills.length}</b></span>
                <span className="flex items-center gap-1.5"><Download size={13} className="text-[#0052D9]" /> 累计引用 <b className="text-slate-800">{totalInstalls}</b></span>
                <span className="flex items-center gap-1.5"><Users size={13} className="text-emerald-500" /> 参赛开发者 <b className="text-slate-800">{authors}</b></span>
              </div>
            </div>
            <button
              onClick={() => setEditing({ author: currentUser.name, category: "失效分析", status: "已发布", tags: [] })}
              className="h-10 px-4 rounded-lg bg-gradient-to-r from-[#7A3DFF] to-[#0052D9] text-white text-sm shadow-sm hover:shadow-md flex items-center gap-2 shrink-0"
            >
              <Plus size={16} /> 创建 Skill
            </button>
          </div>
        </div>

        {/* Skill 开发市场 */}
        <section className="bg-white rounded-xl border border-slate-200/80 shadow-[0_1px_2px_0_rgba(15,23,42,0.04)] overflow-hidden">
          <div className="px-5 py-3 border-b border-slate-100 flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-[#0052D9]/8 text-[#0052D9] grid place-items-center"><Store size={15} /></div>
            <h3 className="text-slate-900 font-semibold">Skill 开发市场</h3>
            <span className="text-[11px] text-slate-400">在 EA 内创建、编辑与复用 AI Skill</span>
            <div className="ml-auto relative">
              <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="搜索 Skill / 作者 / 标签"
                className="h-9 w-56 pl-8 pr-3 rounded-md border border-slate-200 bg-slate-50/60 focus:bg-white focus:border-[#0052D9] outline-none text-sm"
              />
            </div>
          </div>

          {/* 分类筛选 */}
          <div className="px-5 py-3 border-b border-slate-100 flex flex-wrap gap-2">
            {(["全部", ...SKILL_CATEGORIES] as string[]).map((c) => (
              <button
                key={c}
                onClick={() => setCat(c)}
                className={`text-[12.5px] px-3 py-1.5 rounded-full border transition-colors ${cat === c ? "bg-[#0052D9] text-white border-[#0052D9]" : "border-slate-200 text-slate-500 hover:bg-slate-50"}`}
              >
                {c}
              </button>
            ))}
          </div>

          {/* 卡片网格 */}
          <div className="p-5">
            {filtered.length === 0 ? (
              <div className="py-16 text-center text-slate-400">
                <Bot size={32} className="mx-auto mb-2 opacity-40" />
                <div className="text-sm">没有匹配的 Skill</div>
                <div className="text-xs mt-1">试试其他关键词，或创建一个新的 Skill</div>
              </div>
            ) : (
              <div className="grid grid-cols-3 gap-4">
                {filtered.map((s) => (
                  <div key={s.id} className="group relative rounded-xl border border-slate-200/80 bg-white p-4 hover:border-[#0052D9]/40 hover:shadow-[0_8px_24px_-12px_rgba(0,82,217,0.25)] transition-all">
                    <div className="flex items-center gap-2 mb-2">
                      <span className={`text-[10px] px-1.5 py-0.5 rounded ${catColor[s.category] || catColor["其他"]}`}>{s.category}</span>
                      {s.status === "草稿" && <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-50 text-amber-600">草稿</span>}
                      <div className="ml-auto flex items-center gap-0.5 text-amber-400">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <Star key={i} size={11} className={i < s.rating ? "fill-amber-400" : "text-slate-200"} />
                        ))}
                      </div>
                    </div>
                    <div className="text-[15px] font-medium text-slate-900 leading-snug line-clamp-1 group-hover:text-[#0052D9] transition-colors">{s.name}</div>
                    <p className="text-xs text-slate-500 mt-1.5 line-clamp-2 leading-relaxed min-h-[32px]">{s.description}</p>
                    <div className="flex flex-wrap gap-1 mt-2.5">
                      {s.tags.slice(0, 3).map((t) => (
                        <span key={t} className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-500">#{t}</span>
                      ))}
                    </div>
                    <div className="mt-3 pt-3 border-t border-dashed border-slate-200 flex items-center text-[11px] text-slate-500 gap-3">
                      <span className="flex items-center gap-1"><Bot size={11} /> {s.author}</span>
                      <span className="flex items-center gap-1"><Download size={11} /> {s.installs}</span>
                      <div className="ml-auto flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button onClick={() => setEditing(s)} title="编辑" className="w-6 h-6 rounded hover:bg-slate-100 grid place-items-center text-slate-400 hover:text-[#0052D9]"><Pencil size={12} /></button>
                        <button onClick={() => { if (confirm(`确认删除 Skill「${s.name}」？`)) remove(s.id); }} title="删除" className="w-6 h-6 rounded hover:bg-slate-100 grid place-items-center text-slate-400 hover:text-red-500"><Trash2 size={12} /></button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </section>
      </div>

      {editing && (
        <SkillEditor
          initial={editing}
          onCancel={() => setEditing(null)}
          onSave={(data) => { upsert(data); setEditing(null); }}
        />
      )}
    </div>
  );
}

// ---------- 创建 / 编辑 Skill ----------
function SkillEditor({
  initial,
  onCancel,
  onSave,
}: {
  initial: Partial<Skill>;
  onCancel: () => void;
  onSave: (data: Omit<Skill, "id" | "installs" | "rating" | "updatedAt"> & { id?: string }) => void;
}) {
  const [name, setName] = useState(initial.name ?? "");
  const [category, setCategory] = useState(initial.category ?? "失效分析");
  const [description, setDescription] = useState(initial.description ?? "");
  const [author, setAuthor] = useState(initial.author ?? "");
  const [status, setStatus] = useState<Skill["status"]>((initial.status as Skill["status"]) ?? "已发布");
  const [tagInput, setTagInput] = useState("");
  const [tags, setTags] = useState<string[]>(initial.tags ?? []);
  const isEdit = !!initial.id;

  const addTag = () => {
    const t = tagInput.trim();
    if (t && !tags.includes(t)) setTags((p) => [...p, t]);
    setTagInput("");
  };
  const canSave = name.trim() && description.trim() && author.trim();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-6" onMouseDown={onCancel}>
      <div className="w-[600px] max-w-[92vw] max-h-[88vh] bg-white rounded-2xl shadow-2xl border border-slate-200 flex flex-col overflow-hidden" onMouseDown={(e) => e.stopPropagation()}>
        <div className="px-5 py-4 border-b border-slate-100 flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#7A3DFF] to-[#0052D9] text-white grid place-items-center"><Award size={16} /></div>
          <div>
            <div className="text-slate-900 font-semibold text-[15px]">{isEdit ? "编辑 Skill" : "创建 Skill"}</div>
            <div className="text-[11.5px] text-slate-400">发布到 PTE AI 大赛 · Skill 开发市场</div>
          </div>
          <button onClick={onCancel} className="ml-auto w-8 h-8 rounded-md hover:bg-slate-100 grid place-items-center text-slate-400"><XIcon size={16} /></button>
        </div>

        <div className="p-5 space-y-4 overflow-y-auto">
          <div className="space-y-1">
            <label className="text-[11px] text-slate-500">Skill 名称 <span className="text-red-400">*</span></label>
            <input value={name} onChange={(e) => setName(e.target.value)} placeholder="如：FSA 失效模式自动归类" className="w-full h-10 px-3 rounded-md border border-slate-200 bg-slate-50/60 focus:bg-white focus:border-[#0052D9] outline-none text-sm" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-[11px] text-slate-500">分类 <span className="text-red-400">*</span></label>
              <select value={category} onChange={(e) => setCategory(e.target.value)} className="w-full h-10 px-3 rounded-md border border-slate-200 bg-white outline-none text-sm focus:border-[#0052D9]">
                {SKILL_CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div className="space-y-1">
              <label className="text-[11px] text-slate-500">作者 <span className="text-red-400">*</span></label>
              <input value={author} onChange={(e) => setAuthor(e.target.value)} placeholder="开发者姓名" className="w-full h-10 px-3 rounded-md border border-slate-200 bg-slate-50/60 focus:bg-white focus:border-[#0052D9] outline-none text-sm" />
            </div>
          </div>
          <div className="space-y-1">
            <label className="text-[11px] text-slate-500">功能描述 <span className="text-red-400">*</span></label>
            <textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="这个 Skill 解决什么问题、输入输出是什么……" className="w-full min-h-[90px] p-3 rounded-md border border-slate-200 bg-slate-50/60 text-sm outline-none focus:bg-white focus:border-[#0052D9]" />
          </div>
          <div className="space-y-1">
            <label className="text-[11px] text-slate-500">标签</label>
            <div className="flex gap-2">
              <input
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addTag(); } }}
                placeholder="输入标签后回车添加"
                className="flex-1 h-9 px-3 rounded-md border border-slate-200 bg-slate-50/60 focus:bg-white focus:border-[#0052D9] outline-none text-sm"
              />
              <button onClick={addTag} className="h-9 px-3 rounded-md border border-slate-200 text-sm text-slate-600 hover:bg-slate-50">添加</button>
            </div>
            {tags.length > 0 && (
              <div className="flex flex-wrap gap-1.5 pt-1.5">
                {tags.map((t) => (
                  <span key={t} className="inline-flex items-center gap-1 text-[11px] px-2 py-1 rounded bg-slate-100 text-slate-600">
                    #{t}
                    <button onClick={() => setTags((p) => p.filter((x) => x !== t))} className="text-slate-400 hover:text-red-500"><XIcon size={11} /></button>
                  </span>
                ))}
              </div>
            )}
          </div>
          <div className="space-y-1">
            <label className="text-[11px] text-slate-500">状态</label>
            <div className="flex gap-2">
              {(["已发布", "草稿"] as Skill["status"][]).map((s) => (
                <button key={s} onClick={() => setStatus(s)} className={`flex-1 h-9 rounded-md border text-sm transition-all ${status === s ? "bg-[#0052D9]/8 border-[#0052D9] text-[#0052D9]" : "border-slate-200 text-slate-600 hover:bg-slate-50"}`}>{s}</button>
              ))}
            </div>
          </div>
        </div>

        <div className="px-5 py-3 border-t border-slate-100 flex items-center justify-end gap-2">
          <button onClick={onCancel} className="h-9 px-4 rounded-md border border-slate-200 text-sm text-slate-600 hover:bg-slate-50">取消</button>
          <button
            onClick={() => onSave({ id: initial.id, name: name.trim(), category, description: description.trim(), author: author.trim(), status, tags })}
            disabled={!canSave}
            className="h-9 px-4 rounded-md bg-gradient-to-r from-[#7A3DFF] to-[#0052D9] text-white text-sm hover:shadow-md disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1.5"
          >
            <Sparkles size={14} /> {isEdit ? "保存修改" : "发布 Skill"}
          </button>
        </div>
      </div>
    </div>
  );
}
