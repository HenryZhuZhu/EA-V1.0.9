import { useState, useEffect, useMemo, useRef } from "react";
import {
  X, ChevronLeft, ChevronRight, ChevronDown,
  Lightbulb, CheckCircle2, Paperclip, Mic, MessageCircle, FileText, Image as ImageIcon, Sheet,
  Plus, Minus, Radar, Maximize2, Minimize2,
  Cpu, User, Layers, AlertTriangle, Building2, CalendarPlus, RefreshCw,
} from "lucide-react";
import { CaseItem, TaskNode, productById } from "./data";
import { CaseProductPill } from "./CaseProductPill";
import { CaseDailyNote } from "./CaseDailyNote";
import { CaseStatusBadge, caseDisplayStatus } from "./CaseStatusBadge";

/* ===== 方案 F · 双联视图（首页 + 导图 + 结论）演示模式 ===== */

// 自带 hex 配色（与收敛后的业务色板一致；演示需要内联色值而非 tailwind 类）
const STATUS_C: Record<string, string> = {
  待接受: "#d97706", 进行中: "#2563eb",
  已完成: "#16a34a", 已拒绝: "#94a3b8", 已中止: "#94a3b8",
};
const STATUS_BG: Record<string, string> = {
  待接受: "#fdf3e8", 进行中: "#eaf1fe",
  已完成: "#e9f7ed", 已拒绝: "#f1f5f9", 已中止: "#f1f5f9",
};
const URG_C: Record<string, string> = {
  非常紧急: "#FF3B30", 紧急: "#FF9500", 一般: "#38BDF8", 不紧急: "#94A3B8",
};
const VAL_C: Record<string, string> = { 有效: "#16a34a", 部分有效: "#d97706", 无效: "#64748b" };
const LVL_BG: Record<string, string> = {
  L0: "#fdeeec", L1: "#fdf3e8", L2: "#e9f2fb", L3: "#eef3fe",
};
const LVL_C: Record<string, string> = {
  L0: "#bf2d24", L1: "#a35a12", L2: "#256199", L3: "#0052D9",
};
// 产品关键信息字段 → 图标
const META_ICON: Record<string, any> = {
  产品: Cpu, 牵头人: User, 失效阶段: Layers, 失效模式: AlertTriangle,
  客户: Building2, 创建: CalendarPlus, 更新: RefreshCw,
};

type Step =
  | { type: "cover" }
  | { type: "summary" }
  | { type: "node"; node: TaskNode; depth: number; num: string };

const isThought = (n: TaskNode) => !n.code;

function buildSteps(tasks: TaskNode[]) {
  const steps: Step[] = [{ type: "cover" }];
  const nodeStep = new Map<string, number>();
  const walk = (list: TaskNode[], depth: number, prefix: string) => {
    list.forEach((n, i) => {
      const num = prefix ? `${prefix}.${i + 1}` : `${i + 1}`;
      nodeStep.set(n.id, steps.length);
      steps.push({ type: "node", node: n, depth, num });
      if (n.children && n.children.length) walk(n.children, depth + 1, num);
    });
  };
  walk(tasks, 0, "");
  steps.push({ type: "summary" });
  return { steps, nodeStep };
}

const NODE_W = 212, NODE_H = 92, BOX_W = 188, BOX_H = 56;
const CASE_ROOT_ID = "__caseRoot__"; // 演示导图的 Case 根节点（点击回首页，展示 Case 背景等关键信息）
const NOTE_MAP_W = 280; // 笔记模式下思维导图列宽（收窄到只显示当前节点）

function computeLayout(tasks: TaskNode[]) {
  const pos = new Map<string, { x: number; y: number }>();
  const edges: [string, string][] = [];
  let leaf = 0;
  const rec = (n: TaskNode, depth: number, parentId: string | null): number => {
    let y: number;
    const kids = n.children || [];
    if (kids.length) {
      const ys = kids.map((c) => rec(c, depth + 1, n.id));
      y = (Math.min(...ys) + Math.max(...ys)) / 2;
    } else {
      y = leaf * NODE_H + 24;
      leaf += 1;
    }
    pos.set(n.id, { x: depth * NODE_W + 20, y });
    if (parentId) edges.push([parentId, n.id]);
    return y;
  };
  tasks.forEach((t) => rec(t, 0, null));
  const xs = [...pos.values()].map((p) => p.x);
  return { pos, edges, w: (xs.length ? Math.max(...xs) : 0) + BOX_W + 40, h: Math.max(leaf, 1) * NODE_H + 30 };
}

function tasksUnder(n: TaskNode): TaskNode[] {
  const out: TaskNode[] = [];
  (function w(x: TaskNode) {
    (x.children || []).forEach((c) => { if (c.code) out.push(c); w(c); });
  })(n);
  return out;
}

function AttIcon({ kind }: { kind: string }) {
  if (kind === "image") return <ImageIcon size={12} className="text-sky-500" />;
  if (kind === "sheet") return <Sheet size={12} className="text-emerald-500" />;
  return <FileText size={12} className="text-rose-500" />;
}

export function DemoMode({ caseItem, tasks, onClose }: { caseItem: CaseItem; tasks: TaskNode[]; onClose: () => void }) {
  const { steps, nodeStep } = useMemo(() => buildSteps(tasks), [tasks]);
  // Case 根节点 = Case 本身（以它为根、各思路为子节点，点击回首页/封面）
  const rootNode = useMemo(() => ({ id: CASE_ROOT_ID, title: caseItem.name, children: tasks } as unknown as TaskNode), [tasks, caseItem.name]);
  const layout = useMemo(() => computeLayout([rootNode]), [rootNode]);
  const flatNodes = useMemo(() => {
    const out: TaskNode[] = [];
    (function w(list: TaskNode[]) { list.forEach((n) => { out.push(n); if (n.children) w(n.children); }); })(tasks);
    return out;
  }, [tasks]);
  const flatAll = useMemo(() => [rootNode, ...flatNodes], [rootNode, flatNodes]);

  const actionNodes = useMemo(() => flatNodes.filter((n) => n.code), [flatNodes]);

  const [view, setView] = useState<"updates" | "map">("updates");
  const [drawerNode, setDrawerNode] = useState<TaskNode | null>(null);
  const [focusId, setFocusId] = useState<string | null>(null); // 思维导图中高亮定位的节点
  const [infoOpen, setInfoOpen] = useState(false); // 封面 Case 信息（背景/影响/产品）默认收纳
  const [expanded, setExpanded] = useState(false); // 全屏：隐藏 Case 信息头，让当前视角铺满
  const lastNodeRef = useRef<TaskNode | null>(null);
  if (drawerNode) lastNodeRef.current = drawerNode;
  const [zoom, setZoom] = useState(1);
  const mapRef = useRef<HTMLDivElement>(null);

  const ZMIN = 0.3, ZMAX = 1.6;
  const zoomBy = (f: number) => setZoom((z) => Math.min(ZMAX, Math.max(ZMIN, +(z * f).toFixed(2))));
  const fitAll = () => {
    const el = mapRef.current;
    if (!el) return;
    const pad = 36;
    const s = Math.min((el.clientWidth - pad) / layout.w, (el.clientHeight - pad) / layout.h);
    setZoom(Math.min(1, Math.max(ZMIN, +s.toFixed(2))));
    el.scrollTo({ top: 0, left: 0 });
  };

  // 关闭演示（若处于浏览器全屏则一并退出）
  const closeDemo = () => { try { if (document.fullscreenElement) document.exitFullscreen?.(); } catch {} onClose(); };

  // 切换全屏：隐藏 Case 信息头 + 尽量进入浏览器全屏
  const toggleExpand = () => setExpanded((v) => {
    const next = !v;
    try {
      if (next) (document.documentElement as any).requestFullscreen?.()?.catch(() => {});
      else if (document.fullscreenElement) document.exitFullscreen?.();
    } catch {}
    return next;
  });

  const openNode = (n: TaskNode) => setDrawerNode(n);
  // 在思维导图中定位该任务（关抽屉 + 切到导图 + 高亮滚入）
  const locateInMap = (n: TaskNode) => { setFocusId(n.id); setDrawerNode(null); setView("map"); };
  // 每日更新卡片 → 抽屉展示对应执行任务详情（索引循环映射到真实任务节点）
  const openTaskFromCard = (i: number) => { if (actionNodes.length) setDrawerNode(actionNodes[i % actionNodes.length]); };

  // ← / → 在思维导图中逐节点翻页：移动高亮定位；抽屉打开时同步翻到相邻节点详情
  const pageMap = (dir: 1 | -1) => {
    const order = flatNodes;
    if (!order.length) return;
    const curId = drawerNode?.id ?? focusId ?? null;
    const idx = curId ? order.findIndex((n) => n.id === curId) : -1;
    const ni = idx < 0 ? (dir > 0 ? 0 : order.length - 1) : Math.min(order.length - 1, Math.max(0, idx + dir));
    const target = order[ni];
    setFocusId(target.id);
    if (drawerNode) setDrawerNode(target);
  };

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") { if (drawerNode) setDrawerNode(null); else closeDemo(); return; }
      if (e.key === "ArrowRight" || e.key === "ArrowLeft") {
        if (view !== "map" && !drawerNode) return; // 仅在思维导图 / 详情抽屉中翻页
        e.preventDefault();
        pageMap(e.key === "ArrowRight" ? 1 : -1);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [drawerNode, view, focusId, flatNodes, onClose]);

  // 进入思维导图视图时自动全览
  useEffect(() => { if (view === "map") { const t = setTimeout(fitAll, 60); return () => clearTimeout(t); } }, [view]);

  // 定位时把目标节点滚入视野
  useEffect(() => {
    if (view !== "map" || !focusId) return;
    const t = setTimeout(() => {
      const el = mapRef.current?.querySelector<HTMLElement>(`[data-node="${focusId}"]`);
      el?.scrollIntoView({ behavior: "smooth", block: "center", inline: "center" });
    }, 140);
    return () => clearTimeout(t);
  }, [view, focusId]);

  /* ---------- detail (右侧完整任务详情 / 全屏 slide 内容) ---------- */
  const Detail = ({ s, full }: { s: Step; full?: boolean }) => {
    if (s.type === "cover") {
      const info = ([
        ["产品", caseItem.product],
        ["牵头人", `${caseItem.owner}`],
        caseItem.failStage ? ["失效阶段", caseItem.failStage] : null,
        caseItem.failMode ? ["失效模式", caseItem.failMode] : null,
        caseItem.customer ? ["客户", caseItem.customer] : null,
        ["创建", caseItem.createdAt],
        ["更新", caseItem.updatedAt],
      ].filter(Boolean)) as [string, string][];
      return (
        <div className="w-full h-full flex flex-col py-8 pr-2">
          {!expanded && (
          <div className="shrink-0">
          {/* Case 信息带（全宽） */}
          <div className="font-mono text-sm text-slate-400 tracking-wide">{caseItem.code}</div>
          <h1 className="text-[34px] leading-tight font-bold text-slate-900 mt-2 tracking-tight">{caseItem.name}</h1>
          <div className="flex items-center gap-2.5 mt-4 flex-wrap">
            <span className="text-xs font-semibold px-2 py-1 rounded-md" style={{ background: LVL_BG[caseItem.level], color: LVL_C[caseItem.level] }}>{caseItem.level}</span>
            <CaseProductPill caseItem={caseItem} />
            <CaseStatusBadge status={caseDisplayStatus(caseItem)} />
            <span className="text-xs font-semibold px-2 py-1 rounded-md" style={{ color: URG_C[caseItem.urgency], background: (URG_C[caseItem.urgency] || "#999") + "14" }}>{caseItem.urgency}</span>
          </div>

          {/* Case 信息（背景 / 影响范围 / 产品信息）—— 默认收纳，点击展开，把空间还给每日更新 */}
          <button onClick={() => setInfoOpen((v) => !v)} className="mt-4 inline-flex items-center gap-1.5 text-[13px] font-medium text-slate-500 hover:text-[#0052D9] transition-colors">
            {infoOpen ? <ChevronDown size={15} /> : <ChevronRight size={15} />}
            {infoOpen ? "收起 Case 信息" : "展开 Case 信息 · 背景 / 影响范围 / 产品信息"}
          </button>
          {infoOpen && (
            <>
          {/* 背景 / 影响范围 —— 两栏 */}
          <div className="mt-4 grid grid-cols-1 lg:grid-cols-2 gap-x-16 gap-y-6">
            <div>
              <div className="text-[11px] text-slate-400 font-semibold tracking-wide mb-2">背景</div>
              <p className="text-[15px] text-slate-600 leading-[1.85]">
                {caseItem.background && caseItem.background.length > 40
                  ? caseItem.background
                  : "客户在整机端反馈 DDR4 模组批量 field failure，近两个月累计退货 2 个批次、约 1.8K 片，失效集中在高温长时运行场景，表现为读写偶发错误与 CRC 报错。初步排查指向 refresh timing margin 不足，叠加特定环境温度触发，需公司级评估根因并给出拦截方案。"}
              </p>
            </div>
            <div>
              <div className="text-[11px] text-slate-400 font-semibold tracking-wide mb-2">影响范围</div>
              <p className="text-[15px] text-slate-600 leading-[1.85]">
                {caseItem.impact && caseItem.impact !== "—" && caseItem.impact.length > 40
                  ? caseItem.impact
                  : "客户已退货 2 批次，波及出货约 1.2M 颗，涉及 3 家直供客户与 1 个重点平台；同世代同 pin-map 的 3 个在产料号存在相同设计风险，若不及时拦截预计月度受影响出货约 4.5M 颗。需扩样 2 个 Lot 复验，并同步评估 Coverage 拦截与客户 8D 回复。"}
              </p>
            </div>
          </div>

          {/* 产品关键信息 —— 与背景同宽，紧凑信息胶囊，该换行就换行 */}
          <div className="mt-5 flex flex-wrap gap-2 lg:w-[calc(50%-2rem)]">
            {info.map(([k, v]) => {
              const Icon = META_ICON[k] || Cpu;
              return (
                <div key={k} className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50/70 pl-2 pr-2.5 py-1.5 min-w-0">
                  <Icon size={14} className="text-slate-400 shrink-0" />
                  <span className="text-[11px] text-slate-400 shrink-0">{k}</span>
                  <span className="text-[12.5px] text-slate-700 font-medium truncate" title={v}>{v}</span>
                </div>
              );
            })}
          </div>
            </>
          )}

          {/* 分隔 */}
          <div className="h-px bg-slate-200 mt-6" />
          </div>
          )}

          {/* 每日更新 ⇄ 思维导图（切换在日历行右侧；导图占满下方整块区域） */}
          <div className={`flex-1 min-h-0 flex flex-col ${expanded ? "pt-2" : "pt-5"}`}>
          <CaseDailyNote
            caseItem={caseItem}
            tasks={tasks}
            onOpenTask={openTaskFromCard}
            fill
            leadRight={
              <button
                onClick={toggleExpand}
                title={expanded ? "退出全屏" : "全屏"}
                className="w-8 h-8 rounded-lg border border-slate-200 bg-white text-slate-500 hover:text-[#0052D9] hover:border-[#0052D9]/30 transition-colors shrink-0 flex items-center justify-center"
              >
                {expanded ? <Minimize2 size={15} /> : <Maximize2 size={15} />}
              </button>
            }
            headerRight={
              <div className="inline-flex items-center gap-1 p-0.5 rounded-lg bg-slate-100">
                <button onClick={() => setView("updates")} className={`h-7 px-3 rounded-md text-[12.5px] font-medium transition-colors ${view === "updates" ? "bg-white text-[#0052D9] shadow-sm" : "text-slate-500 hover:text-slate-700"}`}>每日更新</button>
                <button onClick={() => { setFocusId(null); setView("map"); }} className={`h-7 px-3 rounded-md text-[12.5px] font-medium transition-colors ${view === "map" ? "bg-white text-[#0052D9] shadow-sm" : "text-slate-500 hover:text-slate-700"}`}>思维导图</button>
              </div>
            }
            bodyOverride={view === "map" ? (
              <div className="h-full relative rounded-xl border border-slate-200 overflow-hidden bg-slate-50/40">
                <MindMap />
                <button
                  onClick={toggleExpand}
                  title={expanded ? "退出全屏" : "全屏"}
                  className="absolute top-3 right-3 z-10 w-8 h-8 rounded-md bg-white/90 border border-slate-200 shadow-sm hover:bg-white flex items-center justify-center text-slate-600 hover:text-[#0052D9]"
                >
                  {expanded ? <Minimize2 size={14} /> : <Maximize2 size={14} />}
                </button>
              </div>
            ) : undefined}
          />
          </div>
        </div>
      );
    }
    if (s.type === "summary") {
      // 进行中的 Case：末页补一张「任务进展汇总」结果板，按状态分组精简列出（不含已拒绝）
      const inProgress = caseItem.status === "进行中" || caseItem.status === "验证中";
      const actions = flatNodes.filter((n) => n.code);
      const ORDER = ["进行中", "待接受", "已完成", "已中止"]; // 不展示「已拒绝」
      const groups = ORDER
        .map((st) => ({ st, items: actions.filter((a) => a.status === st) }))
        .filter((g) => g.items.length);
      const shown = groups.reduce((s, g) => s + g.items.length, 0);
      const doneCnt = actions.filter((a) => a.status === "已完成").length;

      return (
        <div className="w-full max-w-[880px] max-h-[84vh] overflow-auto pr-2">
          <div className="inline-flex items-center gap-1.5 text-[13px] font-medium text-emerald-700"><CheckCircle2 size={15} /> 阶段汇总</div>
          <h1 className="text-[30px] leading-tight font-bold text-slate-900 mt-2 tracking-tight">本阶段进展汇总</h1>
          <p className="text-[15px] text-slate-600 leading-relaxed mt-5 max-w-[70ch]">
            以上沿各怀疑方向逐节点梳理了本 Case 的分析过程。下方按状态汇总当前各任务进展，供阶段性回顾与对齐；结论与下一步计划可在 Workspace 中持续沉淀。
          </p>

          {inProgress && groups.length > 0 && (
            <div className="mt-8">
              <div className="flex items-center gap-2.5">
                <div className="text-[13px] font-bold text-slate-700">任务进展汇总</div>
                <span className="text-[12px] text-slate-400">共 {shown} 项 · 已完成 {doneCnt}</span>
              </div>
              <div className="space-y-3.5 mt-4">
                {groups.map((g) => (
                  <div key={g.st} className="rounded-xl border border-slate-200 bg-white overflow-hidden">
                    <div className="flex items-center gap-2 px-4 py-2.5 border-b border-slate-100 bg-slate-50/60">
                      <span className="w-2 h-2 rounded-full" style={{ background: STATUS_C[g.st] }} />
                      <span className="text-[12.5px] font-semibold" style={{ color: STATUS_C[g.st] }}>{g.st}</span>
                      <span className="text-[11.5px] text-slate-400 tabular-nums">{g.items.length}</span>
                    </div>
                    <div className="grid grid-cols-2">
                      {g.items.map((n, i) => {
                        const lastRow = i >= g.items.length - (g.items.length % 2 === 0 ? 2 : 1);
                        return (
                          <div
                            key={n.id}
                            className={`flex items-center gap-3 px-4 py-2 ${!lastRow ? "border-b border-slate-100" : ""} ${i % 2 === 0 ? "border-r border-slate-100" : ""}`}
                          >
                            <span className="flex-1 min-w-0 truncate text-[13px] text-slate-700">{n.title}</span>
                            <span className="shrink-0 text-[11.5px] text-slate-400 tabular-nums">截止 {n.dueDate || "—"}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      );
    }
    const n = s.node;
    const thought = isThought(n);
    return (
      <div className="max-w-[640px]">
        <div className="flex items-center gap-1.5 text-[11px] text-slate-400 font-mono mb-3"><span>{caseItem.code}</span><span className="text-slate-300">/</span><span>{s.num}</span></div>
        {thought && <div className="inline-flex items-center gap-1.5 text-[12px] font-medium text-amber-600"><Lightbulb size={14} /> 怀疑方向</div>}
        <h1 className="text-[26px] leading-snug font-bold text-slate-900 mt-2 tracking-tight">{n.title}</h1>

        {thought ? (
          <>
            {n.suspicion && <p className="text-[14px] text-slate-600 leading-relaxed mt-4 max-w-[60ch]">{n.suspicion}</p>}
            {tasksUnder(n).length > 0 && (
              <div className="flex items-center gap-2 mt-6 text-[13px] text-slate-500">
                <span>含 {tasksUnder(n).length} 个任务</span>
                <span className="inline-flex gap-1.5 items-center">
                  {tasksUnder(n).map((t) => <span key={t.id} className="w-2 h-2 rounded-full" style={{ background: STATUS_C[t.status] }} />)}
                </span>
              </div>
            )}
          </>
        ) : (
          <>
            <div className="flex items-center gap-2.5 mt-3">
              <StatusBadge status={n.status} />
              {n.code && <span className="font-mono text-xs text-slate-400">{n.code}</span>}
              {n.type && (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-medium border" style={{ borderColor: "#e2e8f0", background: "#f8fafc", color: "#64748b" }}>
                  {n.type}
                </span>
              )}
            </div>
            {n.status === "已完成" && n.conclusion ? (
              <>
                <div className="text-[12px] text-slate-400 font-semibold tracking-wide mt-6 mb-1.5">结论</div>
                <p className="text-[14px] text-slate-700 leading-relaxed max-w-[58ch]">{n.conclusion}</p>
                {n.validity && <div className="inline-flex items-center gap-1.5 mt-3 text-[12px] font-medium px-2 py-1 rounded-md" style={{ color: VAL_C[n.validity], background: (VAL_C[n.validity] || "#999") + "14" }}><CheckCircle2 size={13} /> 结论{n.validity}</div>}
              </>
            ) : n.status === "已拒绝" && n.rejectReason ? (
              <>
                <div className="text-[12px] font-semibold tracking-wide mt-6 mb-1.5" style={{ color: STATUS_C["已拒绝"] }}>拒绝原因</div>
                <p className="text-[14px] leading-relaxed max-w-[58ch]" style={{ color: "#64748b" }}>{n.rejectReason}</p>
              </>
            ) : n.status === "已中止" && n.terminateReason ? (
              <>
                <div className="text-[12px] text-slate-400 font-semibold tracking-wide mt-6 mb-1.5">中止理由</div>
                <p className="text-[14px] text-slate-500 leading-relaxed max-w-[58ch]">{n.terminateReason}</p>
              </>
            ) : n.expectation ? (
              <>
                <div className="text-[12px] text-slate-400 font-semibold tracking-wide mt-6 mb-1.5">预期</div>
                <p className="text-[14px] text-slate-700 leading-relaxed max-w-[58ch]">{n.expectation}</p>
              </>
            ) : null}

            {full && (
              <>
                <div className="grid grid-cols-3 gap-4 mt-7 max-w-[480px]">
                  <InfoCell k="负责人" v={`${n.owner} · ${n.department}`} />
                  <InfoCell k="紧急程度" v={<span style={{ color: URG_C[n.urgency] || "#475569", fontWeight: 600 }}>{n.urgency || "—"}</span>} />
                  <InfoCell k="截止日期" v={n.dueDate || "—"} />
                </div>
                {n.attachments && n.attachments.length > 0 && (
                  <>
                    <div className="text-[12px] text-slate-400 font-semibold tracking-wide mt-6 mb-2">附件 ({n.attachments.length})</div>
                    <div className="flex flex-wrap gap-2">
                      {n.attachments.map((a, i) => (
                        <span key={i} className="inline-flex items-center gap-1.5 px-2 py-1 rounded-md border border-slate-200 bg-white text-[11px] text-slate-600"><AttIcon kind={a.kind} /> {a.name}</span>
                      ))}
                    </div>
                  </>
                )}
                {(n.voiceNote || (n.comments && n.comments.length > 0)) && (
                  <div className="flex items-center gap-2 mt-4">
                    {n.voiceNote && <span className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-slate-100 text-[11px] text-slate-500"><Mic size={12} /> 含语音备注</span>}
                    {n.comments && n.comments.length > 0 && <span className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-slate-100 text-[11px] text-slate-500"><MessageCircle size={12} /> {n.comments.length} 条评论</span>}
                  </div>
                )}
              </>
            )}
          </>
        )}
      </div>
    );
  };

  /* ---------- 左侧导图（支持缩放，便于全览） ---------- */
  const MindMap = () => (
    <div className="h-full w-full relative">
      <div ref={mapRef} className="absolute inset-0 overflow-auto bg-slate-50/60">
        <div style={{ width: layout.w * zoom, height: layout.h * zoom }}>
          <div className="relative" style={{ width: layout.w, height: layout.h, transform: `scale(${zoom})`, transformOrigin: "top left" }}>
        <svg className="absolute inset-0 pointer-events-none" style={{ width: layout.w, height: layout.h }}>
          {layout.edges.map(([aId, bId], i) => {
            const a = layout.pos.get(aId)!, b = layout.pos.get(bId)!;
            const cur = (!!drawerNode && (drawerNode.id === aId || drawerNode.id === bId)) || (!!focusId && (focusId === aId || focusId === bId));
            const x1 = a.x + BOX_W, y1 = a.y + BOX_H / 2, x2 = b.x, y2 = b.y + BOX_H / 2;
            return <path key={i} d={`M${x1} ${y1} C ${x1 + 50} ${y1} ${x2 - 50} ${y2} ${x2} ${y2}`} fill="none" stroke={cur ? "#0052D9" : "#cbd5e1"} strokeWidth={cur ? 2 : 1.2} />;
          })}
        </svg>
        {flatAll.map((n) => {
          const p = layout.pos.get(n.id)!;
          if (n.id === CASE_ROOT_ID) {
            const active = view === "updates";
            return (
              <button
                key={n.id}
                data-node={n.id}
                onClick={() => setView("updates")}
                title="回到每日更新"
                className="absolute text-left rounded-xl border transition-all"
                style={{
                  left: p.x, top: p.y, width: BOX_W, minHeight: BOX_H,
                  background: active ? "#eaf1fe" : "#fff",
                  borderColor: active ? "#0052D9" : "#bcd0f5",
                  boxShadow: active ? "0 0 0 3px rgba(0,82,217,.18), 0 6px 16px -6px rgba(0,82,217,.4)" : "0 1px 2px rgba(15,23,42,.05)",
                  padding: "8px 10px",
                  opacity: 1,
                }}
              >
                <div className="text-[9px] font-mono text-[#0052D9]">{caseItem.code}</div>
                <div className="text-[12px] font-semibold text-slate-800 leading-snug line-clamp-2">{caseItem.name}</div>
                <div className="flex items-center gap-1 mt-1 text-[10px] text-[#0052D9]">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#0052D9]" /> Case · 查看背景
                </div>
              </button>
            );
          }
          const active = drawerNode?.id === n.id || focusId === n.id;
          const th = isThought(n);
          return (
            <button
              key={n.id}
              data-node={n.id}
              onClick={() => openNode(n)}
              className="absolute text-left rounded-xl border transition-all"
              style={{
                left: p.x, top: p.y, width: BOX_W, minHeight: BOX_H,
                background: th ? "#fffdf5" : "#fff",
                borderColor: active ? "#0052D9" : th ? "#fde68a" : "#e5e9f0",
                boxShadow: active ? "0 0 0 3px rgba(0,82,217,.18), 0 6px 16px -6px rgba(0,82,217,.4)" : "0 1px 2px rgba(15,23,42,.05)",
                padding: "8px 10px",
                opacity: drawerNode && !active ? 0.6 : 1,
              }}
            >
              <div className="text-[12px] font-medium text-slate-800 leading-snug line-clamp-2">{n.title}</div>
              <div className="flex items-center gap-1 mt-1 text-[10px] text-slate-500">
                <span className="w-1.5 h-1.5 rounded-full" style={{ background: th ? "#f59e0b" : STATUS_C[n.status] }} />
                {th ? "怀疑方向" : n.status}
                {n.owner && (
                  <span className="flex items-center gap-1 ml-auto text-slate-600">
                    <span className="w-3.5 h-3.5 rounded-full bg-gradient-to-br from-[#00A4FF] to-[#0052D9] text-white flex items-center justify-center text-[7px] font-medium leading-none">{n.owner.slice(-2)}</span>
                    {n.owner}
                  </span>
                )}
              </div>
            </button>
          );
        })}
          </div>
        </div>
      </div>
      {/* 缩放控件 —— 演示者可缩放任务思维导图 */}
      <div className="absolute left-3 bottom-3 flex items-center gap-0.5 bg-white/95 backdrop-blur border border-slate-200 rounded-lg shadow-sm p-0.5">
        <button onClick={() => zoomBy(0.8)} title="缩小" className="w-7 h-7 rounded-md hover:bg-slate-100 flex items-center justify-center text-slate-600"><Minus size={15} /></button>
        <button onClick={() => setZoom(1)} title="实际大小 100%" className="px-1.5 h-7 rounded-md hover:bg-slate-100 text-[11px] tabular-nums text-slate-600 min-w-[44px]">{Math.round(zoom * 100)}%</button>
        <button onClick={() => zoomBy(1.25)} title="放大" className="w-7 h-7 rounded-md hover:bg-slate-100 flex items-center justify-center text-slate-600"><Plus size={15} /></button>
      </div>
    </div>
  );

  const drawerN = drawerNode || lastNodeRef.current;

  return (
    <div className="fixed inset-0 z-[100] bg-white overflow-hidden">
      {/* 内容：Case 信息（可收纳）+ 每日更新 / 思维导图 */}
      <div className="h-full w-full px-[6%]">
        <Detail s={{ type: "cover" } as Step} />
      </div>

      {/* 右上角：退出演示（全屏切换在思维导图内 / 每日更新计数行） */}
      <div className="absolute top-4 right-6 z-30 flex items-center gap-2">
        <button
          onClick={closeDemo}
          title="退出演示（Esc）"
          className="w-9 h-9 rounded-lg bg-white/90 border border-slate-200 shadow-sm hover:bg-white flex items-center justify-center text-slate-600 hover:text-rose-500"
        >
          <X size={16} />
        </button>
      </div>

      {/* 遮罩 */}
      <div
        onClick={() => setDrawerNode(null)}
        className={`absolute inset-0 z-40 bg-slate-900/25 transition-opacity duration-300 ${drawerNode ? "opacity-100" : "opacity-0 pointer-events-none"}`}
      />
      {/* 右侧抽屉：满高、占屏幕 2/3 */}
      <div className={`absolute top-0 right-0 bottom-0 w-[66.6667%] min-w-[560px] bg-white z-50 shadow-2xl border-l border-slate-200 flex flex-col transition-transform duration-300 ${drawerNode ? "translate-x-0" : "translate-x-full"}`}>
        <div className="shrink-0 flex items-center justify-between gap-3 px-6 py-4 border-b border-slate-100">
          <span className="text-[14px] font-semibold text-slate-700">任务详情</span>
          <div className="flex items-center gap-2">
            <button onClick={() => drawerN && locateInMap(drawerN)} title="在思维导图中定位该任务" className="inline-flex items-center gap-1.5 h-8 px-3 rounded-lg border border-[#0052D9]/30 bg-[#0052D9]/[0.05] text-[12.5px] font-medium text-[#0052D9] hover:bg-[#0052D9]/[0.1] transition-colors"><Radar size={14} /> 在思维导图中定位</button>
            <button onClick={() => setDrawerNode(null)} title="关闭（Esc）" className="w-8 h-8 rounded-lg hover:bg-slate-100 flex items-center justify-center text-slate-500"><X size={16} /></button>
          </div>
        </div>
        <div className="flex-1 min-h-0 overflow-auto px-6 py-6">
          {drawerN && <Detail s={{ type: "node", node: drawerN, depth: 0, num: "" } as Step} full />}
        </div>
      </div>
    </div>
  );
}

/* ---------- Workspace 笔记（云文档：文本 + 图片 + 附件） ---------- */
function WorkspaceNote({ node, caseCode, onBack }: { node: TaskNode; caseCode: string; onBack: () => void }) {
  const imgs = (node.attachments || []).filter((a) => a.kind === "image");
  const files = (node.attachments || []).filter((a) => a.kind !== "image");
  const phenomenon = node.expectation || node.suspicion ||
    "复现阶段观察到目标站点良率较基线显著下降，集中在特定 wafer 边缘区域，疑似与测试条件相关。";
  const conclusion = node.conclusion ||
    "暂未填写结论。Workspace 是一个云文档，可在此沉淀分析过程、贴入数据图表与图片，并写明最终结论。";

  return (
    <div className="w-full">
      {/* 工具条 */}
      <div className="flex items-center gap-2.5 mb-6">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-1.5 h-9 px-3 rounded-lg border border-slate-200 bg-white text-[13px] font-medium text-slate-600 hover:bg-slate-50 transition-colors"
        >
          <ChevronLeft size={16} /> 返回任务详情
        </button>
        <span className="inline-flex items-center gap-1.5 text-[12px] font-medium text-[#0052D9] bg-[#0052D9]/[0.06] border border-[#0052D9]/20 px-2.5 py-1 rounded-md">
          <FileText size={13} /> Workspace 云文档
        </span>
        <div className="flex-1" />
        <span className="text-[12px] text-slate-400">最近编辑：{node.owner} · {node.dueDate || "—"}</span>
      </div>

      {/* 文档主体（直接铺满，无嵌套卡片） */}
      <div>
        <div className="font-mono text-[11px] text-slate-400 tracking-wide">{caseCode} · 分析笔记</div>
        <h1 className="text-[26px] leading-snug font-bold text-slate-900 mt-2 tracking-tight">{node.title}</h1>
        <div className="flex items-center gap-3 mt-3 text-[12px] text-slate-500">
          <span className="inline-flex items-center gap-1.5">
            <span className="w-5 h-5 rounded-full bg-gradient-to-br from-[#00A4FF] to-[#0052D9] text-white flex items-center justify-center text-[9px] font-medium">{node.owner?.slice(-2)}</span>
            {node.owner} · {node.department}
          </span>
          {node.validity && (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-medium" style={{ color: VAL_C[node.validity], background: (VAL_C[node.validity] || "#999") + "14" }}>
              <CheckCircle2 size={12} /> 结论{node.validity}
            </span>
          )}
        </div>

        <div className="h-px bg-slate-100 my-6" />

        {/* 现象 / 背景 */}
        <h2 className="text-[15px] font-bold text-slate-800 mb-2">一、现象与背景</h2>
        <p className="text-[14px] text-slate-700 leading-[1.85]">{phenomenon}</p>

        {/* 分析过程 + 图片 */}
        <h2 className="text-[15px] font-bold text-slate-800 mt-7 mb-2">二、分析过程</h2>
        <p className="text-[14px] text-slate-700 leading-[1.85]">
          按「现象 → 假设 → 验证」推进：先对 datalog 做分布回归，定位异常 bin 的集中分布；再对照工艺与测试参数，缩小嫌疑范围；并通过下方数据图表交叉验证。
        </p>

        {/* 图片区：有图则展示，否则占位图框 */}
        {imgs.length > 0 ? (
          <div className="grid grid-cols-2 gap-3 mt-4">
            {imgs.map((a, i) => (
              <figure key={i} className="rounded-lg border border-slate-200 overflow-hidden bg-slate-50">
                {a.url
                  ? <img src={a.url} alt={a.name} className="w-full h-40 object-cover" />
                  : <div className="w-full h-40 flex items-center justify-center text-slate-300"><ImageIcon size={34} /></div>}
                <figcaption className="text-[11px] text-slate-500 px-3 py-2 border-t border-slate-100 truncate">{a.name}</figcaption>
              </figure>
            ))}
          </div>
        ) : (
          <figure className="mt-4 rounded-lg border border-dashed border-slate-200 bg-slate-50/70 h-44 flex flex-col items-center justify-center gap-2 text-slate-300">
            <ImageIcon size={36} />
            <figcaption className="text-[12px] text-slate-400">数据图表 / 截图（示意）— Shmoo、分布图等可直接贴入此处</figcaption>
          </figure>
        )}

        {/* 结论 */}
        <h2 className="text-[15px] font-bold text-slate-800 mt-7 mb-2">三、关键结论</h2>
        <div className="rounded-lg border border-emerald-200 bg-emerald-50/50 px-4 py-3.5">
          <p className="text-[14px] text-slate-700 leading-[1.85]">{conclusion}</p>
        </div>

        {/* 附件 */}
        {files.length > 0 && (
          <>
            <h2 className="text-[15px] font-bold text-slate-800 mt-7 mb-2">附件</h2>
            <div className="flex flex-wrap gap-2">
              {files.map((a, i) => (
                <span key={i} className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-md border border-slate-200 bg-white text-[12px] text-slate-600">
                  <AttIcon kind={a.kind} /> {a.name}
                </span>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

function InfoCell({ k, v }: { k: string; v: any }) {
  return <div><div className="text-[11px] text-slate-400 font-semibold tracking-wide">{k}</div><div className="text-sm text-slate-700 font-medium mt-1">{v}</div></div>;
}

function StatusBadge({ status }: { status: string }) {
  const c = STATUS_C[status] || "#64748b";
  const bg = STATUS_BG[status] || "#f1f5f9";
  return (
    <span className="inline-flex items-center gap-1.5 text-xs font-medium px-2 py-1 rounded-md" style={{ color: c, background: bg }}>
      <span className="w-1.5 h-1.5 rounded-full" style={{ background: c }} /> {status}
    </span>
  );
}
