import { useEffect, useRef } from "react";
import { CircleCheck, ClipboardList, Layers } from "lucide-react";
import { WorkbenchTaskCard } from "./WorkbenchTaskCard";
import type { TaskSortBy, WorkbenchTask } from "./taskWorkbenchModel";
import { WorkbenchSort } from "./WorkbenchSort";

export const TASK_COLUMN_SORT_OPTIONS = [{ value: "priority", label: "紧急程度" }, { value: "due", label: "截止日期" }, { value: "updated", label: "最近更新" }] as const;

export function TaskSourceColumn({ source, rows, resetKey, businessKey, sortBy, onSortChange, onShowTask, onOpenCase, onTakeAction, onReject }: {
  source: "case" | "standalone"; rows: WorkbenchTask[]; resetKey: string; businessKey: string;
  sortBy?: TaskSortBy; onSortChange?: (sortBy: TaskSortBy) => void;
  onShowTask: (row: WorkbenchTask) => void; onOpenCase: (id: string) => void;
  onTakeAction: (row: WorkbenchTask) => void; onReject: (row: WorkbenchTask) => void;
}) {
  const title = source === "case" ? "Case 任务" : "自由任务";
  const Icon = source === "case" ? Layers : ClipboardList;
  const scroller = useRef<HTMLDivElement>(null);
  useEffect(() => { if (scroller.current) scroller.current.scrollTop = 0; }, [resetKey]);
  return <section aria-label={title} className="flex min-h-0 min-w-0 flex-col overflow-hidden rounded-xl border border-slate-200/80 bg-slate-50/60">
    <header className="flex h-12 shrink-0 items-center gap-2 border-b border-slate-200/70 bg-white px-4">
      <Icon size={15} className="text-slate-500" /><h2 className="text-[13px] font-semibold text-slate-700">{title}</h2><span className="rounded-full bg-slate-100 px-2 py-0.5 text-[10px] tabular-nums text-slate-500">{rows.length}</span>
      {sortBy && onSortChange && <div className="ml-auto"><WorkbenchSort ariaLabel={`${title}排序`} value={sortBy} options={TASK_COLUMN_SORT_OPTIONS} onChange={value => onSortChange(value as TaskSortBy)} /></div>}
    </header>
    <div ref={scroller} role="region" aria-label={`${title}滚动列表`} tabIndex={0} className="min-h-0 flex-1 overflow-y-auto overscroll-contain p-3 outline-none [scrollbar-gutter:stable] focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-[#0052D9]/30">
      <div className={rows.some(row => row.status === "待接受") ? "space-y-3" : "space-y-2"}>{rows.map(row => <WorkbenchTaskCard key={row.key} row={row} businessKey={businessKey} columnLayout onShowTask={() => onShowTask(row)} onOpenCase={onOpenCase} onTakeAction={() => onTakeAction(row)} onReject={() => onReject(row)} />)}</div>
      {!rows.length && <div className="flex min-h-[180px] flex-col items-center justify-center gap-3 text-center"><CircleCheck size={25} className="text-slate-300" /><p className="text-xs text-slate-400">暂无符合条件的{title}</p></div>}
    </div>
  </section>;
}