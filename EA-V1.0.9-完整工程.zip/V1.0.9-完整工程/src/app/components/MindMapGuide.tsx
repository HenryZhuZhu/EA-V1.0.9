import { useState } from "react";
import { GitBranch, Plus, ListTree, PenLine, X, ArrowRight, ArrowLeft, Check, Radar } from "lucide-react";

export const MM_GUIDE_KEY = "ea_mindmap_guide_v2";

const STEPS = [
  {
    icon: GitBranch,
    tag: "第 1 步 · 从「思路」开始",
    title: "新建一个怀疑方向",
    desc: "点击画布上的「＋ 新建思路」按钮，写下「怀疑什么 + 为什么怀疑」。每一个怀疑方向独立建一个思路节点。",
    accent: "from-amber-500 to-orange-500",
  },
  {
    icon: Plus,
    tag: "第 2 步 · 挂上「执行任务」",
    title: "给思路添加要做的事",
    desc: "把鼠标移到思路卡上，点出现的 ＋，新建一个执行任务，并填写任务名称、负责人、截止日期。",
    accent: "from-[#0052D9] to-[#00A4FF]",
  },
  {
    icon: ListTree,
    tag: "第 3 步 · 层层深入",
    title: "派生子思路 / 子任务",
    desc: "在执行任务卡上继续点 ＋，可以再生出新的怀疑方向或子任务，形成一棵多级的怀疑树，把根因一层层查清。",
    accent: "from-violet-500 to-fuchsia-500",
  },
  {
    icon: PenLine,
    tag: "第 4 步 · 填写与整理",
    title: "把卡片填完整",
    desc: "进行中的任务填「预期」，完成后填「结论 + 有效性」。还可以标记重点路径、折叠已完成、拖动节点自由排布。",
    accent: "from-emerald-500 to-teal-500",
  },
  {
    icon: Radar,
    tag: "第 5 步 · 结案与 Fanout",
    title: "结案时可 Fanout 到其它产品",
    desc: "查清根因后点击「结案」，在结案弹窗填写结论并勾选解题路径。若该结论对其它产品也有借鉴意义，可在此可选开启 Fanout，选择要分发验证的目标产品。",
    accent: "from-cyan-500 to-sky-500",
  },
];

export function MindMapGuide({ open, onClose }: { open: boolean; onClose?: () => void }) {
  const [i, setI] = useState(0);
  if (!open) return null;
  const step = STEPS[i];
  const Icon = step.icon;
  const last = i === STEPS.length - 1;

  const finish = () => {
    try { localStorage.setItem(MM_GUIDE_KEY, "1"); } catch {}
    setI(0);
    onClose?.();
  };

  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center bg-slate-900/45 backdrop-blur-[2px]">
      <div className="w-[480px] bg-white rounded-2xl shadow-2xl overflow-hidden">
        <div className={`relative px-6 pt-6 pb-12 bg-gradient-to-br ${step.accent} text-white`}>
          <button onClick={finish} title="跳过引导" className="absolute top-3 right-3 w-7 h-7 rounded-lg bg-white/15 hover:bg-white/25 flex items-center justify-center">
            <X size={15} />
          </button>
          <div className="text-[11px] font-medium tracking-wide opacity-90">{step.tag}</div>
          <div className="mt-1.5 text-[20px] font-bold leading-snug pr-8">{step.title}</div>
        </div>
        <div className="px-6 -mt-8">
          <div className="w-14 h-14 rounded-2xl bg-white shadow-lg border border-slate-100 flex items-center justify-center">
            <span className={`w-10 h-10 rounded-xl bg-gradient-to-br ${step.accent} text-white flex items-center justify-center`}>
              <Icon size={22} />
            </span>
          </div>
        </div>
        <div className="px-6 pt-3.5 pb-1">
          <p className="text-[13.5px] text-slate-600 leading-relaxed">{step.desc}</p>
        </div>
        <div className="px-6 py-5 mt-1 flex items-center gap-3 border-t border-slate-100">
          <div className="flex items-center gap-1.5">
            {STEPS.map((_, k) => (
              <button key={k} onClick={() => setI(k)}
                className={`h-1.5 rounded-full transition-all ${k === i ? "w-5 bg-[#0052D9]" : "w-1.5 bg-slate-200 hover:bg-slate-300"}`} />
            ))}
          </div>
          <span className="text-xs text-slate-400 tabular-nums">{i + 1} / {STEPS.length}</span>
          <div className="flex-1" />
          {i > 0 && (
            <button onClick={() => setI((v) => v - 1)} className="h-9 px-3.5 rounded-lg border border-slate-200 text-sm text-slate-600 hover:border-slate-300 inline-flex items-center gap-1.5">
              <ArrowLeft size={14} /> 上一步
            </button>
          )}
          {!last ? (
            <button onClick={() => setI((v) => v + 1)} className="h-9 px-4 rounded-lg bg-gradient-to-r from-[#0052D9] to-[#003FA8] text-white text-sm inline-flex items-center gap-1.5 hover:shadow-md">
              下一步 <ArrowRight size={14} />
            </button>
          ) : (
            <button onClick={finish} className="h-9 px-4 rounded-lg bg-gradient-to-r from-emerald-500 to-teal-500 text-white text-sm inline-flex items-center gap-1.5 hover:shadow-md">
              <Check size={15} /> 开始创建
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
