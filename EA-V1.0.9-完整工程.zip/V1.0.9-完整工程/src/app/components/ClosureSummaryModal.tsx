import { CheckCircle2, Clock3, FileText, GitBranch, Paperclip, Route, ShieldCheck, UserRound, X } from "lucide-react";
import type { ClosureRecord } from "./closures";
import { CaseItem, flattenTasks, productById } from "./data";

interface Props {
  caseItem: CaseItem;
  closure: ClosureRecord;
  fallbackConclusion?: string;
  fallbackFiles?: { name: string; kind: "pdf" | "image" | "sheet" | "file"; url?: string }[];
  onClose: () => void;
}

function InfoField({ label, value }: { label: string; value?: string }) {
  return (
    <div>
      <div className="text-[10.5px] text-slate-400">{label}</div>
      <div className="mt-1 text-[12px] leading-relaxed text-slate-700">{value?.trim() || "未填写"}</div>
    </div>
  );
}

export function ClosureSummaryModal({ caseItem, closure, fallbackConclusion, fallbackFiles = [], onClose }: Props) {
  const krEntries = Object.entries(closure.krByProduct ?? {});
  const fanoutTargets = closure.fanoutTargets ?? caseItem.fanoutTargets ?? [];
  const solutionPath = closure.solutionPath ?? caseItem.solutionPath ?? [];
  const taskById = new Map(flattenTasks(caseItem.tasks).map(({ task }) => [task.id, task]));
  const files = closure.files?.length ? closure.files : fallbackFiles;
  const conclusion = closure.conclusion || fallbackConclusion || caseItem.aiSummary.conclusion;

  return (
    <div className="fixed inset-0 z-[160] flex items-center justify-center bg-slate-900/40 p-6" onClick={onClose}>
      <div className="flex max-h-[90vh] w-[780px] max-w-[96vw] flex-col overflow-hidden rounded-lg border border-slate-200 bg-white shadow-2xl" onClick={(event) => event.stopPropagation()}>
        <div className="flex items-center gap-3 border-b border-slate-200 px-5 py-4">
          <span className="grid h-8 w-8 place-items-center rounded-lg bg-emerald-50 text-emerald-600"><ShieldCheck size={17} /></span>
          <div className="min-w-0">
            <h3 className="text-sm font-semibold text-slate-900">结案信息</h3>
            <div className="mt-0.5 truncate text-[10.5px] text-slate-400"><span className="font-mono">{caseItem.code}</span> · {caseItem.name}</div>
          </div>
          <span className="ml-auto inline-flex items-center gap-1 rounded-full border border-emerald-200 bg-emerald-50 px-2 py-1 text-[10.5px] font-medium text-emerald-700"><CheckCircle2 size={11} />已结案</span>
          <button type="button" onClick={onClose} title="关闭" className="grid h-8 w-8 place-items-center rounded-md text-slate-400 hover:bg-slate-100 hover:text-slate-600"><X size={16} /></button>
        </div>

        <div className="overflow-y-auto p-5">
          <section className="grid grid-cols-2 gap-4 rounded-lg border border-slate-200 bg-slate-50/70 p-4">
            <div className="flex items-start gap-2"><UserRound size={14} className="mt-0.5 text-slate-400" /><InfoField label="结案人" value={closure.submittedBy} /></div>
            <div className="flex items-start gap-2"><Clock3 size={14} className="mt-0.5 text-slate-400" /><InfoField label="结案时间" value={closure.closedAt} /></div>
            <div className="flex items-start gap-2"><UserRound size={14} className="mt-0.5 text-slate-400" /><InfoField label="根因提交人" value={closure.rootCauseBy} /></div>
            <div className="flex items-start gap-2"><Clock3 size={14} className="mt-0.5 text-slate-400" /><InfoField label="根因提交时间" value={closure.rootCauseAt} /></div>
          </section>

          <section className="mt-4 rounded-lg border border-slate-200 p-4">
            <div className="flex items-center gap-2 text-[12px] font-semibold text-slate-800"><GitBranch size={14} className="text-[#0052D9]" />根因与 Fanout</div>
            <div className="mt-3 grid grid-cols-2 gap-4">
              <InfoField label="根因 Domain" value={closure.domain} />
              <InfoField label="类型" value={closure.problemType} />
              <InfoField label="跟进说明" value={closure.followupNote} />
            </div>
            <div className="mt-4">
              <div className="text-[10.5px] text-slate-400">产品 KR</div>
              <div className="mt-2 flex flex-wrap gap-2">
                {krEntries.length ? krEntries.map(([productId, kr]) => (
                  <span key={productId} className="inline-flex items-center gap-1.5 rounded-md border border-slate-200 bg-white px-2 py-1 text-[10.5px] text-slate-600"><span className="font-mono">{productById(productId)?.code ?? productId}</span><span className="text-slate-300">·</span><b className="font-medium text-[#0052D9]">KR {kr}</b></span>
                )) : <span className="text-[11px] text-slate-400">未填写</span>}
              </div>
            </div>
            <div className="mt-4">
              <div className="text-[10.5px] text-slate-400">Fanout</div>
              <div className="mt-2 flex flex-wrap gap-2">
                {fanoutTargets.length ? fanoutTargets.map((productId) => <span key={productId} className="rounded-md border border-[#0052D9]/20 bg-[#0052D9]/5 px-2 py-1 font-mono text-[10.5px] text-[#0052D9]">{productById(productId)?.code ?? productId}</span>) : <span className="text-[11px] text-slate-500">未 Fanout{closure.fanoutSkipReason ? ` · ${closure.fanoutSkipReason}` : ""}</span>}
              </div>
            </div>
          </section>

          <section className="mt-4 rounded-lg border border-slate-200 p-4">
            <div className="flex items-center gap-2 text-[12px] font-semibold text-slate-800"><FileText size={14} className="text-[#0052D9]" />结案结论</div>
            <div className="mt-3 whitespace-pre-wrap rounded-md bg-slate-50 px-3 py-2.5 text-[12px] leading-relaxed text-slate-700">{conclusion?.trim() || "未填写"}</div>
          </section>

          <section className="mt-4 grid grid-cols-2 gap-4">
            <div className="rounded-lg border border-slate-200 p-4">
              <div className="flex items-center gap-2 text-[12px] font-semibold text-slate-800"><Route size={14} className="text-[#0052D9]" />解题路径</div>
              <div className="mt-3 space-y-2">
                {solutionPath.length ? solutionPath.map((taskId, index) => {
                  const task = taskById.get(taskId);
                  return <div key={taskId} className="flex items-start gap-2 text-[11px]"><span className="grid h-5 w-5 shrink-0 place-items-center rounded bg-[#0052D9]/8 font-semibold text-[#0052D9]">{index + 1}</span><span className="min-w-0"><span className="block truncate text-slate-700">{task?.title ?? taskId}</span>{task?.code && <span className="mt-0.5 block font-mono text-[9.5px] text-slate-400">{task.code}</span>}</span></div>;
                }) : <div className="text-[11px] text-slate-400">未选择解题路径</div>}
              </div>
            </div>
            <div className="rounded-lg border border-slate-200 p-4">
              <div className="flex items-center gap-2 text-[12px] font-semibold text-slate-800"><Paperclip size={14} className="text-[#0052D9]" />结案文件</div>
              <div className="mt-3 space-y-2">
                {files.length ? files.map((file, index) => <div key={`${file.name}-${index}`} className="flex items-center gap-2 rounded-md border border-slate-100 bg-slate-50 px-2.5 py-2 text-[11px] text-slate-600"><Paperclip size={11} className="shrink-0 text-slate-400" /><span className="truncate">{file.name}</span><span className="ml-auto shrink-0 uppercase text-[9px] text-slate-400">{file.kind}</span></div>) : <div className="text-[11px] text-slate-400">未提交结案文件</div>}
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}