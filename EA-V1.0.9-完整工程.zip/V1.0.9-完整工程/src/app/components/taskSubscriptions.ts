import { useEffect, useState } from "react";

const KEY = "ea_followed_tasks_v1";
const SEP = "::";
let cache: Set<string> | null = null;
const listeners = new Set<() => void>();

export interface FollowedTaskRef {
  caseId: string;
  taskId: string;
}

const refKey = (caseId: string, taskId: string) => `${caseId}${SEP}${taskId}`;

function load(): Set<string> {
  if (cache) return cache;
  try {
    const raw = typeof localStorage !== "undefined" ? localStorage.getItem(KEY) : null;
    cache = new Set<string>(raw ? JSON.parse(raw) : []);
  } catch {
    cache = new Set<string>();
  }
  return cache;
}

function persist() {
  try {
    if (cache) localStorage.setItem(KEY, JSON.stringify([...cache]));
  } catch {}
}

export function isTaskFollowed(caseId: string, taskId: string) {
  return load().has(refKey(caseId, taskId));
}

export function toggleTaskFollow(caseId: string, taskId: string) {
  const items = load();
  const key = refKey(caseId, taskId);
  if (items.has(key)) items.delete(key);
  else items.add(key);
  persist();
  listeners.forEach((listener) => listener());
}

export function followedTaskRefs(): FollowedTaskRef[] {
  return [...load()].flatMap((key) => {
    const [caseId, taskId] = key.split(SEP);
    return caseId && taskId ? [{ caseId, taskId }] : [];
  });
}

export function useTaskSubscriptions() {
  const [, setTick] = useState(0);
  useEffect(() => {
    const listener = () => setTick((tick) => tick + 1);
    listeners.add(listener);
    return () => {
      listeners.delete(listener);
    };
  }, []);

  const refs = followedTaskRefs();
  return {
    isFollowed: isTaskFollowed,
    toggle: toggleTaskFollow,
    refs,
    keys: refs.map(({ caseId, taskId }) => refKey(caseId, taskId)),
  };
}
