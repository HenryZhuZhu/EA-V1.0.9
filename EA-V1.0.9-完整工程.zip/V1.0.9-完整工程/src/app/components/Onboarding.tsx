import { useState } from "react";
import {
  Sparkles, LayoutGrid, GitBranch, Users, BarChart3, X, ArrowRight, ArrowLeft, Check,
} from "lucide-react";

export const ONBOARDING_KEY = "ea_onboarding_v0_2";

interface Step {
  icon: any;
  tag: string;
  title: string;
  desc: string;
  points: string[];
  accent: string; // tailwind from-* to-*
}

const STEPS: Step[] = [
  {
    icon: Sparkles,
    tag: "欢迎",
    title: "欢迎来到 EA 工程分析平台",
    desc: "EA 把每一次失效 / 异常的排查，沉淀为一个可追溯、可协同的 Case —— 从立项、拆解怀疑方向、分派任务，到回填结论与结案，全程留痕。",
    points: ["以 Case 为中心组织调查", "怀疑树驱动的结构化排查", "团队协同 + 全程可追溯"],
    accent: "from-[#0052D9] to-[#00A4FF]",
  },
  {
    icon: LayoutGrid,
    tag: "第 1 站 · Case 中心",
    title: "快速找到你关心的 Case",
    desc: "「聚焦视图」按你最关心的维度智能分组（我的订阅 / 我牵头 / 临期 / 我的部门…）；「全部列表」支持层级、紧急度、状态、产品、部门多维筛选。",
    points: ["聚焦视图：一眼看到该处理什么", "全部列表：多维筛选 + 排序", "订阅 Case，动态进通知"],
    accent: "from-indigo-500 to-blue-500",
  },
  {
    icon: GitBranch,
    tag: "第 2 站 · 怀疑树思维导图",
    title: "用怀疑树层层拆解根因",
    desc: "每个 Case 是一棵树：「思路 / 怀疑方向」提出假设，下面挂「执行任务」去验证，可继续派生子怀疑。重点路径可整条标记高亮，右侧「节点目录」随时定位。",
    points: ["思路 → 任务 → 子思路，逐层深入", "标记重点怀疑路径", "节点目录默认展开两层，点击在导图定位"],
    accent: "from-amber-500 to-orange-500",
  },
  {
    icon: Users,
    tag: "第 3 站 · 任务协同",
    title: "分派、流转、回填结论",
    desc: "把任务分派给负责人，状态在「待接受 / 进行中 / 已完成…」间流转；完成后回填结论与有效性，附件、语音备注、评论一并留存。",
    points: ["@ 指定负责人，状态自动流转", "结论 + 有效性标签直接展示", "流转日志完整可查"],
    accent: "from-emerald-500 to-teal-500",
  },
  {
    icon: BarChart3,
    tag: "第 4 站 · 看板与汇报",
    title: "看板洞察 + 一键演示",
    desc: "管理者看板分析 Cycle Time、异常预警与积分排行；汇报时进入「演示模式」，把整个 Case 自动转成可翻页的讲解材料，开会不用再拖导图。",
    points: ["管理者看板：效率 / 异常 / 积分", "演示模式：一键生成汇报", "随时可在右上角重新打开本引导"],
    accent: "from-fuchsia-500 to-violet-500",
  },
];

export function Onboarding({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [i, setI] = useState(0);
  if (!open) return null;
  const step = STEPS[i];
  const Icon = step.icon;
  const last = i === STEPS.length - 1;

  const finish = () => {
    try { localStorage.setItem(ONBOARDING_KEY, "1"); } catch {}
    setI(0);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-6 bg-slate-900/55 backdrop-blur-sm">
      <div className="w-full max-w-[560px] bg-white rounded-2xl shadow-2xl overflow-hidden animate-[fadeUp_.3s_ease]">
        {/* Header band */}
        <div className={`relative px-7 pt-7 pb-16 bg-gradient-to-br ${step.accent} text-white`}>
          <button
            onClick={finish}
            title="跳过引导"
            className="absolute top-4 right-4 w-8 h-8 rounded-lg bg-white/15 hover:bg-white/25 flex items-center justify-center"
          >
            <X size={16} />
          </button>
          <div className="text-xs font-medium tracking-wide opacity-90">{step.tag}</div>
          <div className="mt-2 text-[22px] font-bold leading-snug pr-8">{step.title}</div>
        </div>

        {/* Floating icon —— relative z-10：盖在 relative 头图之上，否则会被头图遮住 */}
        <div className="px-7 -mt-9 relative z-10">
          <div className="w-[68px] h-[68px] rounded-2xl bg-white shadow-lg border border-slate-100 flex items-center justify-center">
            <span className={`w-12 h-12 rounded-xl bg-gradient-to-br ${step.accent} text-white flex items-center justify-center`}>
              <Icon size={26} />
            </span>
          </div>
        </div>

        {/* Body */}
        <div className="px-7 pt-4 pb-2">
          <p className="text-[14px] text-slate-600 leading-relaxed">{step.desc}</p>
          <ul className="mt-4 space-y-2">
            {step.points.map((p) => (
              <li key={p} className="flex items-start gap-2.5 text-[13px] text-slate-700">
                <span className="mt-0.5 w-4 h-4 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
                  <Check size={12} />
                </span>
                {p}
              </li>
            ))}
          </ul>
        </div>

        {/* Footer */}
        <div className="px-7 py-5 mt-2 flex items-center gap-3 border-t border-slate-100">
          {/* progress dots */}
          <div className="flex items-center gap-1.5">
            {STEPS.map((_, k) => (
              <button
                key={k}
                onClick={() => setI(k)}
                className={`h-1.5 rounded-full transition-all ${k === i ? "w-5 bg-[#0052D9]" : "w-1.5 bg-slate-200 hover:bg-slate-300"}`}
              />
            ))}
          </div>
          <span className="text-xs text-slate-400 tabular-nums">{i + 1} / {STEPS.length}</span>
          <div className="flex-1" />
          {i > 0 && (
            <button
              onClick={() => setI((v) => v - 1)}
              className="h-9 px-3.5 rounded-lg border border-slate-200 text-sm text-slate-600 hover:border-slate-300 inline-flex items-center gap-1.5"
            >
              <ArrowLeft size={14} /> 上一步
            </button>
          )}
          {!last ? (
            <button
              onClick={() => setI((v) => v + 1)}
              className="h-9 px-4 rounded-lg bg-gradient-to-r from-[#0052D9] to-[#003FA8] text-white text-sm inline-flex items-center gap-1.5 hover:shadow-md"
            >
              下一步 <ArrowRight size={14} />
            </button>
          ) : (
            <button
              onClick={finish}
              className="h-9 px-4 rounded-lg bg-gradient-to-r from-emerald-500 to-teal-500 text-white text-sm inline-flex items-center gap-1.5 hover:shadow-md"
            >
              <Check size={15} /> 开始使用
            </button>
          )}
        </div>
      </div>

      <style>{`@keyframes fadeUp{from{opacity:0;transform:translateY(12px) scale(.98)}to{opacity:1;transform:none}}`}</style>
    </div>
  );
}
