import { Plus, X, CheckCircle2, Target, Wrench, FlaskConical, ExternalLink } from "lucide-react";
import { useState } from "react";
import { EfaAnalysisCard, Urgency, TaskType, TASK_TYPES, departments, departmentSupervisors, Site, SITES, TaskNode, COVERAGE_SPEEDS, COVERAGE_TESTERS, COVERAGE_QGS, BALL_TYPES } from "./data";
import { AIPolishButton } from "./AIPolishButton";
import { VoiceInputButton } from "./VoiceInputButton";
import { VoiceRecorder } from "./VoiceNote";
import { AttachmentInput, Att } from "./AttachmentInput";
import { PersonInput } from "./PersonInput";
import { TaskAssigneeField } from "./TaskAssigneeField";

const URGENCY_OPTIONS: Urgency[] = ["非常紧急", "紧急", "一般", "不紧急"];

export type TaskKind = "怀疑目标" | "执行任务";

export interface AddTaskPayload {
  kind: TaskKind;
  title: string;
  expectation?: string;
  department: string;
  dueDate: string;
  urgency: Urgency;
  assignee: string;
  sourceTaskIds?: string[];
  assigneeType?: "person" | "skill";
  skillId?: string;
  skillRun?: TaskNode["skillRun"];
  type?: TaskType;
  coverageTestName?: string;
  coverageTestTime?: string;
  coverageActionStage?: string;
  coverageNtc?: "是" | "否";
  coverageSpeed?: string;
  coverageTester?: string;
  coverageQG?: string;
  coverageBallType?: string;
  coverageReleaseType?: "Reject" | "Monitor";
  coverageTeOwner?: string;
  coveragePeOwner?: string;
  efaAnalysis?: EfaAnalysisCard | null;
  category?: string;
  voiceNote?: string;
  attachments?: { name: string; kind: "pdf" | "image" | "sheet" | "file"; url?: string }[];
  note?: string;
  supervisor?: string;
  site?: Site;
  efaRequest?: {
    sample: string;
    failMode: string;
    request: string;
  };
}

interface Props {
  defaultDepartment?: string;
  titleLabel?: string;
  submitLabel?: string;
  hint?: string;
  initial?: Partial<AddTaskPayload>;
  onCancel: () => void;
  onSubmit: (payload: AddTaskPayload) => void;
}

export function AddTaskModal({
  defaultDepartment = "PTE",
  titleLabel = "新增卡片",
  submitLabel = "创建",
  hint,
  initial,
  onCancel,
  onSubmit,
}: Props) {
  const [kind, setKind] = useState<TaskKind>(initial?.kind ?? "怀疑目标");
  const [title, setTitle] = useState(initial?.title ?? "");
  const [department, setDepartment] = useState(initial?.department ?? defaultDepartment);
  const [supervisor, setSupervisor] = useState<string>(
    initial?.supervisor ??
      (initial?.department ?? defaultDepartment
        ? departmentSupervisors[initial?.department ?? defaultDepartment] ?? ""
        : "")
  );
  const [dueDate, setDueDate] = useState(initial?.dueDate ?? "");
  const [urgency, setUrgency] = useState<Urgency>(initial?.urgency ?? "一般");
  const [assignee, setAssignee] = useState(initial?.assignee ?? "");
  const [assigneeType, setAssigneeType] = useState<"person" | "skill">(initial?.assigneeType ?? "person");
  const [skillId, setSkillId] = useState(initial?.skillId);
  const [skillRun, setSkillRun] = useState<TaskNode["skillRun"]>(initial?.skillRun);
  const [type, setType] = useState<TaskType | "">(initial?.type ?? (initial?.efaRequest ? "EFA分析" : ""));
  const [coverageSpeed, setCoverageSpeed] = useState(initial?.coverageSpeed ?? "");
  const [coverageTester, setCoverageTester] = useState(initial?.coverageTester ?? "");
  const [coverageQG, setCoverageQG] = useState(initial?.coverageQG ?? "");
  const [coverageBallType, setCoverageBallType] = useState(initial?.coverageBallType ?? "");
  const [coverageTeOwner, setCoverageTeOwner] = useState(initial?.coverageTeOwner ?? "");
  const [coveragePeOwner, setCoveragePeOwner] = useState(initial?.coveragePeOwner ?? "");
  const [attachments, setAttachments] = useState<Att[]>(initial?.attachments ?? []);
  const [voiceNote, setVoiceNote] = useState<string | undefined>(initial?.voiceNote);
  const [site, setSite] = useState<Site | "">(initial?.site ?? "");
  const [efaSample, setEfaSample] = useState(initial?.efaRequest?.sample ?? "");
  const [efaFailMode, setEfaFailMode] = useState(initial?.efaRequest?.failMode ?? "");
  const [efaRequest, setEfaRequest] = useState(initial?.efaRequest?.request ?? "");

  const isAction = kind === "执行任务";
  const isEfaAnalysis = isAction && type === "EFA分析";
  const canSubmit =
    title.trim().length > 0 &&
    (!isAction || (department.trim().length > 0 && assignee.trim().length > 0)) &&
    (!isEfaAnalysis || (efaSample.trim().length > 0 && efaFailMode.trim().length > 0 && efaRequest.trim().length > 0));

  const computedHint =
    hint ??
    (isAction
      ? "执行任务将作为牌下发到所选部门与工程师，进入对方收件箱。"
      : "怀疑目标先记录方向，后续可在其下挂多个执行任务进行验证。");

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40"
      onClick={onCancel}
    >
      <div
        className="w-[520px] bg-white rounded-lg shadow-xl border border-slate-200 p-5 space-y-4 max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-2">
          <Plus size={14} className="text-[#0052D9]" />
          <h3 className="text-slate-900">{titleLabel}</h3>
          <button onClick={onCancel} className="ml-auto text-slate-400 hover:text-slate-600">
            <X size={16} />
          </button>
        </div>

        {/* Kind selector */}
        <div>
          <div className="text-xs text-slate-600 mb-1.5">任务类型</div>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => setKind("怀疑目标")}
              className={`p-2.5 rounded-md border text-left transition-all ${
                kind === "怀疑目标"
                  ? "border-[#0052D9] bg-[#0052D9]/5 ring-1 ring-[#0052D9]/30"
                  : "border-slate-200 hover:border-slate-300"
              }`}
            >
              <div className="flex items-center gap-1.5">
                <Target size={13} className="text-[#0052D9]" />
                <span className="text-sm text-slate-800">怀疑目标</span>
              </div>
              <div className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                先记录怀疑方向，部门 / 负责人可后续指派
              </div>
            </button>
            <button
              type="button"
              onClick={() => setKind("执行任务")}
              className={`p-2.5 rounded-md border text-left transition-all ${
                kind === "执行任务"
                  ? "border-[#0052D9] bg-[#0052D9]/5 ring-1 ring-[#0052D9]/30"
                  : "border-slate-200 hover:border-slate-300"
              }`}
            >
              <div className="flex items-center gap-1.5">
                <Wrench size={13} className="text-[#0052D9]" />
                <span className="text-sm text-slate-800">执行任务</span>
              </div>
              <div className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                立即下发，部门与工程师必填
              </div>
            </button>
          </div>
        </div>

        <label className="block text-xs text-slate-600">
          任务名称 <span className="text-red-500">*</span>
          <div className="mt-1 flex items-center gap-1">
            <input
              autoFocus
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder={
                isAction
                  ? "符合预期怎么做 + 不符合怎么做，例：margin 达标则放行，否则升级 EFA 切片"
                  : "怀疑什么 + 为什么怀疑（每个方向独立一个节点）"
              }
              className="flex-1 h-9 px-2.5 text-sm rounded border border-slate-200 outline-none focus:border-[#0052D9]"
            />
            <VoiceInputButton size="sm" onTranscript={(t) => setTitle((p) => (p ? p + " " + t : t))} />
            <AIPolishButton
              size="sm"
              getText={() => title}
              onPolished={(t) => setTitle(t)}
              hint="AI 润色任务名称"
            />
          </div>
          <div className="mt-1 text-[10px] text-slate-400">
            {isAction
              ? "建议：执行任务名称 = 符合预期怎么做 + 不符合怎么做"
              : "建议：怀疑方向 = 怀疑什么 + 为什么怀疑，每个方向建立一个独立节点"}
          </div>
        </label>

        <div className="grid grid-cols-2 gap-3">
          <label className="block text-xs text-slate-600">
            分派部门{" "}
            {isAction ? (
              <span className="text-red-500">*</span>
            ) : (
              <span className="text-slate-400">（可选）</span>
            )}
            <select
              value={department}
              onChange={(e) => {
                const d = e.target.value;
                setDepartment(d);
                setSupervisor(d ? departmentSupervisors[d] ?? "" : "");
              }}
              className="mt-1 w-full h-9 px-2.5 text-sm rounded border border-slate-200 outline-none focus:border-[#0052D9] bg-white"
            >
              {!isAction && <option value="">不指定</option>}
              {departments.map((d) => (
                <option key={d} value={d}>
                  {d}
                </option>
              ))}
            </select>
          </label>
          <label className="block text-xs text-slate-600">
            紧急程度
            <select
              value={urgency}
              onChange={(e) => setUrgency(e.target.value as Urgency)}
              className="mt-1 w-full h-9 px-2.5 text-sm rounded border border-slate-200 outline-none focus:border-[#0052D9] bg-white"
            >
              {URGENCY_OPTIONS.map((u) => (
                <option key={u} value={u}>
                  {u}
                </option>
              ))}
            </select>
          </label>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <label className="block text-xs text-slate-600">
            希望完成日期 {!isAction && <span className="text-slate-400">（可选）</span>}
            <input
              type="date"
              value={dueDate}
              onChange={(e) => setDueDate(e.target.value)}
              className="mt-1 w-full h-9 px-2.5 text-sm rounded border border-slate-200 outline-none focus:border-[#0052D9]"
            />
          </label>
          <label className="block text-xs text-slate-600">
            任务负责人{" "}
            {isAction ? (
              <span className="text-red-500">*</span>
            ) : (
              <span className="text-slate-400">（可选）</span>
            )}
            <div className="mt-1">
              <TaskAssigneeField value={{ assignee, department, assigneeType, skillId, skillRun }} onChange={(next) => { setAssignee(next.assignee); setDepartment(next.department); setAssigneeType(next.assigneeType ?? "person"); setSkillId(next.skillId); setSkillRun(next.skillRun); }} />
            </div>
          </label>
        </div>

        <label className="block text-xs text-slate-600">
          站点归属 <span className="text-slate-400">（可选 · 任务发生 / 验证的站点）</span>
          <select
            value={site}
            onChange={(e) => setSite(e.target.value as Site | "")}
            className="mt-1 w-full h-9 px-2.5 text-sm rounded border border-slate-200 outline-none focus:border-[#0052D9] bg-white"
          >
            <option value="">不指定</option>
            {SITES.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
        </label>

        <label className="block text-xs text-slate-600">
          部门主管 <span className="text-slate-400">（依据所选部门自动带出，可修改）</span>
          <input
            value={supervisor}
            onChange={(e) => setSupervisor(e.target.value)}
            placeholder={department ? `默认：${departmentSupervisors[department] ?? "—"}` : "请先选择部门"}
            className="mt-1 w-full h-9 px-2.5 text-sm rounded border border-slate-200 outline-none focus:border-[#0052D9] bg-white"
          />
        </label>

        {isAction && (
          <label className="block text-xs text-slate-600">
            动作类型 <span className="text-slate-400">（可选）</span>
            <select
              value={type}
              onChange={(e) => {
                const nextType = e.target.value as TaskType | "";
                setType(nextType);
                if (nextType === "EFA分析" && !efaRequest.trim()) setEfaRequest(`请针对「${title.trim() || "当前任务"}」进行失效定位，输出物理失效位置、失效机理与支撑图片。`);
              }}
              className="mt-1 w-full h-9 px-2.5 text-sm rounded border border-slate-200 outline-none focus:border-[#0052D9] bg-white"
            >
              <option value="">不指定</option>
              {TASK_TYPES.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </label>
        )}

        {isAction && type === "Coverage上线" && (
          <div className="rounded-lg border border-cyan-200 bg-cyan-50/60 p-3.5">
            <div className="text-xs font-semibold text-cyan-800">Coverage 参数与验证负责人</div>
            <div className="mt-3 grid grid-cols-2 gap-3">
              <label className="text-xs text-slate-600">Speed<select value={coverageSpeed} onChange={(event) => setCoverageSpeed(event.target.value)} className="mt-1 w-full h-9 px-2 rounded border border-slate-200 bg-white"><option value="">请选择</option>{COVERAGE_SPEEDS.map((item) => <option key={item}>{item}</option>)}</select></label>
              <label className="text-xs text-slate-600">Tester<select value={coverageTester} onChange={(event) => setCoverageTester(event.target.value)} className="mt-1 w-full h-9 px-2 rounded border border-slate-200 bg-white"><option value="">请选择</option>{COVERAGE_TESTERS.map((item) => <option key={item}>{item}</option>)}</select></label>
              <label className="text-xs text-slate-600">Quality Grade<select value={coverageQG} onChange={(event) => setCoverageQG(event.target.value)} className="mt-1 w-full h-9 px-2 rounded border border-slate-200 bg-white"><option value="">请选择</option>{COVERAGE_QGS.map((item) => <option key={item}>{item}</option>)}</select></label>
              <label className="text-xs text-slate-600">Ball type<select value={coverageBallType} onChange={(event) => setCoverageBallType(event.target.value)} className="mt-1 w-full h-9 px-2 rounded border border-slate-200 bg-white"><option value="">请选择</option>{BALL_TYPES.map((item) => <option key={item}>{item}</option>)}</select></label>
              <label className="text-xs text-slate-600">TE 负责人<PersonInput value={coverageTeOwner} onChange={setCoverageTeOwner} /></label>
              <label className="text-xs text-slate-600">PE 负责人<PersonInput value={coveragePeOwner} onChange={setCoveragePeOwner} /></label>
            </div>
          </div>
        )}

        {isEfaAnalysis && (
          <div className="rounded-lg border border-violet-300 bg-violet-50/60">
            <div className="flex items-center gap-3 px-3.5 py-3"><span className="w-8 h-8 rounded-lg bg-violet-100 text-violet-600 grid place-items-center shrink-0"><FlaskConical size={16} /></span><span className="min-w-0"><span className="block text-sm font-medium text-slate-800">EFA 分析信息</span><span className="block mt-0.5 text-[11px] text-slate-500">创建任务后在 QMS 自动建单，状态与分析结果回同步至该任务</span></span></div>
              <div className="px-3.5 pb-3.5 pt-1 border-t border-violet-100 space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <label className="text-xs text-slate-600">送分析样品 / 颗粒 <span className="text-red-500">*</span>
                    <input value={efaSample} onChange={(e) => setEfaSample(e.target.value)} placeholder="如：IC-03 / SN-DMJFC-003" className="mt-1 w-full h-9 px-2.5 text-sm rounded border border-slate-200 bg-white outline-none focus:border-violet-500" />
                  </label>
                  <label className="text-xs text-slate-600">失效模式 <span className="text-red-500">*</span>
                    <input value={efaFailMode} onChange={(e) => setEfaFailMode(e.target.value)} placeholder="如：Leakage / Bit Fail / Open" className="mt-1 w-full h-9 px-2.5 text-sm rounded border border-slate-200 bg-white outline-none focus:border-violet-500" />
                  </label>
                </div>
                <label className="block text-xs text-slate-600">分析诉求 <span className="text-red-500">*</span>
                  <textarea value={efaRequest} onChange={(e) => setEfaRequest(e.target.value)} rows={3} className="mt-1 w-full p-2.5 text-sm rounded border border-slate-200 bg-white outline-none focus:border-violet-500 leading-relaxed resize-none" />
                </label>
                <div className="text-[10.5px] text-violet-700 inline-flex items-center gap-1"><ExternalLink size={11} /> 提交任务时同步生成 QMS EFA 单号</div>
              </div>
          </div>
        )}

        <div className="grid grid-cols-2 gap-3">
          <label className="block text-xs text-slate-600 min-w-0">
            附件 <span className="text-slate-400">（可选）</span>
            <div className="mt-1">
              <AttachmentInput value={attachments} onChange={setAttachments} compact />
            </div>
          </label>
          <label className="block text-xs text-slate-600 min-w-0">
            语音备注 <span className="text-slate-400">（可选）</span>
            <div className="mt-1">
              <VoiceRecorder value={voiceNote} onChange={setVoiceNote} compact />
            </div>
          </label>
        </div>

        <div className="text-[11px] text-slate-500 leading-relaxed pt-1">{computedHint}</div>
        <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
          <button
            onClick={onCancel}
            className="h-8 px-3 text-sm rounded-md border border-slate-200 text-slate-600 hover:bg-slate-50"
          >
            取消
          </button>
          <button
            disabled={!canSubmit}
            onClick={() =>
              onSubmit({
                kind,
                title: title.trim(),
                department,
                dueDate,
                urgency,
                assignee,
                assigneeType,
                skillId,
                skillRun,
                type: type || undefined,
                coverageSpeed: type === "Coverage上线" ? coverageSpeed : undefined,
                coverageTester: type === "Coverage上线" ? coverageTester : undefined,
                coverageQG: type === "Coverage上线" ? coverageQG : undefined,
                coverageBallType: type === "Coverage上线" ? coverageBallType : undefined,
                coverageTeOwner: type === "Coverage上线" ? coverageTeOwner : undefined,
                coveragePeOwner: type === "Coverage上线" ? coveragePeOwner : undefined,
                attachments: attachments.length ? attachments : undefined,
                voiceNote,
                supervisor: supervisor.trim() || undefined,
                site: site || undefined,
                efaRequest: isEfaAnalysis ? {
                  sample: efaSample.trim(),
                  failMode: efaFailMode.trim(),
                  request: efaRequest.trim(),
                } : undefined,
              })
            }
            className="h-8 px-3.5 text-sm rounded-md bg-[#0052D9] text-white hover:bg-[#003FA8] disabled:opacity-40 inline-flex items-center gap-1"
          >
            <CheckCircle2 size={13} /> {submitLabel}
          </button>
        </div>
      </div>
    </div>
  );
}
