import { useEffect, useMemo, useRef, useState } from "react";
import { ZoomIn, ZoomOut, RotateCcw, Tag, ChevronDown, ChevronRight, Check, Package, Activity, Clock3, ArrowUpRight } from "lucide-react";
import { mockCases, levelColors, urgencyBar, flattenTasks, caseProductOf } from "./data";
import { CaseProductPill } from "./CaseProductPill";

const MIN_ZOOM = 1;
const MAX_ZOOM = 80;
const clamp = (v: number, a: number, b: number) => Math.min(Math.max(v, a), b);

export interface LifecycleStage {
  key: string;
  label: string;
  from: number; // 0~1 归一化位置
  to: number;
  color: string;
}

// 级联筛选节点：可两级（组 → 子项），match 决定该选项过滤哪些 Case
export interface CascadeNode {
  key: string;
  label: string;
  match: (c: any) => boolean;
  children?: CascadeNode[];
}

// 产品级 8 阶段生命周期主干（与 data.ts STAGE_DEFS 对齐）。
export const PRODUCT_STAGES: LifecycleStage[] = [
  { key: "DKO", label: "DKO 立项", from: 0.0,   to: 0.125, color: "#6366f1" },
  { key: "AR",  label: "AR 架构",  from: 0.125, to: 0.25,  color: "#4f46e5" },
  { key: "FVR", label: "FVR 验证", from: 0.25,  to: 0.375, color: "#0052D9" },
  { key: "DBR", label: "DBR 发布", from: 0.375, to: 0.5,   color: "#0891b2" },
  { key: "FSO", label: "FSO 首片", from: 0.5,   to: 0.625, color: "#0a9d63" },
  { key: "ES",  label: "ES 工程样",from: 0.625, to: 0.75,  color: "#16a34a" },
  { key: "CS",  label: "CS 客户样",from: 0.75,  to: 0.875, color: "#d97706" },
  { key: "MP",  label: "MP 量产",  from: 0.875, to: 1.0,   color: "#dc2626" },
];

// ⚠️ 占位：平台「从 0 到 1」全生命周期阶段。具体平台与阶段待用户提供后替换。
export const PLATFORM_STAGES: LifecycleStage[] = [
  { key: "plan", label: "平台规划", from: 0.0, to: 0.2, color: "#7c3aed" },
  { key: "build", label: "架构搭建", from: 0.2, to: 0.45, color: "#0052D9" },
  { key: "integrate", label: "集成验证", from: 0.45, to: 0.7, color: "#0891b2" },
  { key: "release", label: "发布上线", from: 0.7, to: 0.88, color: "#16a34a" },
  { key: "evolve", label: "迭代演进", from: 0.88, to: 1.0, color: "#d97706" },
];

// ⚠️ 占位：由产品派生「平台」。真实平台清单待用户提供后替换此映射。
export const platformOf = (c: any): string => {
  const p = String(c.product || "");
  if (/LPDDR/i.test(p)) return "LPDDR 平台";
  if (/DDR5/i.test(p)) return "DDR5 平台";
  if (/DDR4/i.test(p)) return "DDR4 平台";
  if (/Flash|NAND/i.test(p)) return "NAND 平台";
  return "通用平台";
};

// —— 级联下拉筛选（组 → 子项） ——
function CascadeFilter({
  tree,
  sel,
  onSelect,
  dimLabel,
}: {
  tree: CascadeNode[];
  sel: CascadeNode;
  onSelect: (n: CascadeNode) => void;
  dimLabel: string;
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const firstGroup = tree.find((n) => n.children && n.children.length)?.key ?? null;
  const [hover, setHover] = useState<string | null>(firstGroup);

  useEffect(() => {
    const h = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);

  const hoverNode = tree.find((t) => t.key === hover) || null;
  const selInChild = (n: CascadeNode) => n.key === sel.key || (n.children || []).some((c) => c.key === sel.key);

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => { setOpen((o) => !o); setHover(firstGroup); }}
        className={`h-8 pl-2.5 pr-2 rounded-lg border text-[13px] inline-flex items-center gap-1.5 transition-colors ${
          open ? "border-[#0052D9]/40 bg-[#0052D9]/5 text-[#0052D9]" : "border-slate-200 text-slate-700 hover:border-slate-300"
        }`}
      >
        <Tag size={13} className={open ? "text-[#0052D9]" : "text-slate-400"} />
        <span className="text-slate-400">{dimLabel}</span>
        <b className="font-medium max-w-[180px] truncate">{sel.label}</b>
        <ChevronDown size={13} className={`text-slate-400 transition-transform ${open ? "rotate-180" : ""}`} />
      </button>

      {open && (
        <div className="absolute left-0 top-full mt-2 z-40 flex bg-white border border-slate-200 rounded-xl shadow-[0_16px_40px_-12px_rgba(15,23,42,0.25)] overflow-hidden">
          {/* 一级：组 */}
          <div className="w-[190px] py-1.5 max-h-[340px] overflow-auto">
            {tree.map((node) => {
              const hasChildren = !!(node.children && node.children.length);
              const on = selInChild(node);
              return (
                <button
                  key={node.key}
                  onMouseEnter={() => setHover(node.key)}
                  onClick={() => { onSelect(node); setOpen(false); }}
                  className={`w-full flex items-center gap-2 px-3 h-8 text-left text-[13px] transition-colors ${
                    sel.key === node.key ? "text-[#0052D9] bg-[#0052D9]/[0.06] font-medium" : on ? "text-[#0052D9]" : "text-slate-700"
                  } ${hover === node.key ? "bg-slate-50" : "hover:bg-slate-50"}`}
                >
                  <span className="flex-1 truncate">{node.label}</span>
                  {sel.key === node.key && <Check size={13} className="text-[#0052D9] shrink-0" />}
                  {hasChildren && <ChevronRight size={13} className="text-slate-300 shrink-0" />}
                </button>
              );
            })}
          </div>
          {/* 二级：子项 */}
          {hoverNode && hoverNode.children && hoverNode.children.length > 0 && (
            <div className="w-[210px] py-1.5 border-l border-slate-100 max-h-[340px] overflow-auto">
              <div className="px-3 py-1 text-[11px] text-slate-400 truncate">{hoverNode.label}</div>
              {hoverNode.children.map((ch) => (
                <button
                  key={ch.key}
                  onClick={() => { onSelect(ch); setOpen(false); }}
                  className={`w-full flex items-center gap-2 px-3 h-8 text-left text-[13px] transition-colors ${
                    sel.key === ch.key ? "text-[#0052D9] bg-[#0052D9]/[0.06] font-medium" : "text-slate-700 hover:bg-slate-50"
                  }`}
                >
                  <span className="flex-1 truncate">{ch.label}</span>
                  {sel.key === ch.key && <Check size={13} className="text-[#0052D9] shrink-0" />}
                </button>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

interface Props {
  onOpenCase: (id: string) => void;
  tree: CascadeNode[]; // 级联筛选树，tree[0] 约定为「全部」
  stages: LifecycleStage[];
  dimLabel: string; // "产品" / "平台"
  title: string; // "产品全生命周期" / "平台全生命周期"
}

export function CategoryTimeline({ onOpenCase, tree, stages, dimLabel, title }: Props) {
  const [sel, setSel] = useState<CascadeNode>(tree[0]);
  const [zoom, setZoom] = useState(1);
  const [expandedSummaries, setExpandedSummaries] = useState<Set<string>>(new Set());
  const zoomRef = useRef(zoom);
  zoomRef.current = zoom;

  const scrollRef = useRef<HTMLDivElement>(null);
  const dragRef = useRef<{ x: number; left: number } | null>(null);

  const cases = useMemo(() => mockCases.filter(sel.match), [sel]);

  const productUpdates = useMemo(() => {
    const sortedCases = [...cases].sort((a, b) => (b.updatedAt || "").localeCompare(a.updatedAt || ""));
    const groups = new Map<string, {
      id: string;
      code: string;
      name: string;
      family?: string;
      cases: Array<(typeof mockCases)[number]>;
    }>();

    sortedCases.forEach((caseItem) => {
      const product = caseProductOf(caseItem);
      if (!product) return;
      const group = groups.get(product.id) ?? {
        id: product.id,
        code: product.code,
        name: product.name,
        family: product.family,
        cases: [],
      };
      group.cases.push(caseItem);
      groups.set(product.id, group);
    });

    return Array.from(groups.values()).map((group) => {
      const latestCase = group.cases[0];
      const caseUpdates = group.cases.map((caseItem) => {
        const timelineUpdates = [...(caseItem.timeline || [])]
          .reverse()
          .map((item) => item.content?.trim())
          .map((content) => content?.replace(/[。；;]+$/, ""))
          .filter((content): content is string => !!content);
        const fallbackUpdates = [caseItem.aiSummary?.progress, caseItem.aiSummary?.conclusion]
          .map((content) => content?.trim())
          .map((content) => content?.replace(/[。；;]+$/, ""))
          .filter((content): content is string => !!content);
        const updates = Array.from(new Set(timelineUpdates.length ? timelineUpdates : fallbackUpdates));
        return {
          caseItem,
          updates: updates.length ? updates : ["暂无新增说明"],
        };
      });
      const updateCount = caseUpdates.reduce((total, item) => total + item.updates.length, 0);
      const summary = caseUpdates
        .map(({ caseItem, updates }) => `${caseItem.code}「${caseItem.name}」：${updates.join("；")}`)
        .join("；");
      const active = group.cases.filter((caseItem) => !["已关闭", "已结案", "已归档"].includes(caseItem.status)).length;
      return {
        ...group,
        active,
        closed: group.cases.length - active,
        latestCase,
        updateCount,
        summary,
      };
    });
  }, [cases]);

  const prog = (c: any) => {
    const actions = flattenTasks(c.tasks).map((x) => x.task).filter((t) => t.code);
    const base = actions.length ? actions : c.tasks;
    return Math.round(base.reduce((s: number, t: any) => s + (t.progress || 0), 0) / Math.max(base.length, 1));
  };

  // 防重叠分行
  const placed = useMemo(() => {
    const items = cases.map((c) => ({ c, f: clamp(prog(c) / 100, 0, 1) })).sort((a, b) => a.f - b.f);
    const rowLastX: number[] = [];
    return items.map((it) => {
      let row = 0;
      while (row < rowLastX.length && it.f - rowLastX[row] < 0.08) row++;
      rowLastX[row] = it.f;
      return { ...it, row };
    });
  }, [cases]);
  const rowCount = Math.max(1, placed.reduce((m, p) => Math.max(m, p.row + 1), 0));

  const ROW_H = 46;
  const TOP = 70;
  const AXIS_PAD = 52;
  const trackHeight = Math.max(300, TOP + rowCount * ROW_H + AXIS_PAD);
  const axisY = trackHeight - AXIS_PAD + 6;

  const step = zoom < 3 ? 0.1 : zoom < 8 ? 0.05 : zoom < 22 ? 0.02 : 0.01;
  const ticks: number[] = [];
  for (let v = 0; v <= 1.0001; v += step) ticks.push(Math.round(v * 1000) / 1000);
  const isMajor = (v: number) => v % 0.1 < 1e-6 || Math.abs((v % 0.1) - 0.1) < 1e-6;

  // —— 无级缩放：滚轮缩放并锚定指针位置 ——
  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      const rect = el.getBoundingClientRect();
      const pointer = e.clientX - rect.left;
      const frac = (el.scrollLeft + pointer) / (rect.width * zoomRef.current);
      const next = clamp(zoomRef.current * Math.exp(-e.deltaY * 0.0015), MIN_ZOOM, MAX_ZOOM);
      zoomRef.current = next;
      setZoom(next);
      requestAnimationFrame(() => {
        el.scrollLeft = frac * (rect.width * next) - pointer;
      });
    };
    el.addEventListener("wheel", onWheel, { passive: false });
    return () => el.removeEventListener("wheel", onWheel);
  }, []);

  // 拖拽平移
  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const onMove = (e: MouseEvent) => {
      if (!dragRef.current) return;
      el.scrollLeft = dragRef.current.left - (e.clientX - dragRef.current.x);
    };
    const onUp = () => {
      dragRef.current = null;
      if (el) el.style.cursor = "grab";
    };
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
    return () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
    };
  }, []);
  const onDown = (e: React.MouseEvent) => {
    const el = scrollRef.current;
    if (!el) return;
    dragRef.current = { x: e.clientX, left: el.scrollLeft };
    el.style.cursor = "grabbing";
  };

  const bump = (factor: number) => {
    const el = scrollRef.current;
    if (!el) {
      setZoom((z) => clamp(z * factor, MIN_ZOOM, MAX_ZOOM));
      return;
    }
    const rect = el.getBoundingClientRect();
    const frac = (el.scrollLeft + rect.width / 2) / (rect.width * zoom);
    const next = clamp(zoom * factor, MIN_ZOOM, MAX_ZOOM);
    setZoom(next);
    requestAnimationFrame(() => {
      el.scrollLeft = frac * (rect.width * next) - rect.width / 2;
    });
  };
  const reset = () => {
    setZoom(1);
    requestAnimationFrame(() => {
      if (scrollRef.current) scrollRef.current.scrollLeft = 0;
    });
  };

  const pct = (v: number) => `${Math.round(v * 1000) / 10}%`;
  const isAll = sel.key === tree[0].key;

  return (
    <div className="space-y-4">
      {/* 级联筛选 + 缩放控制 */}
      <div className="bg-white border border-slate-200/80 rounded-xl px-3.5 py-3 shadow-[0_1px_2px_0_rgba(15,23,42,0.04)] flex items-center gap-2 flex-wrap">
        <CascadeFilter tree={tree} sel={sel} onSelect={setSel} dimLabel={dimLabel} />
        <div className="ml-auto flex items-center gap-1.5">
          <span className="text-[11px] text-slate-400 mr-1 hidden xl:inline">滚轮缩放 · 拖拽平移</span>
          <button onClick={() => bump(1 / 1.4)} title="缩小" className="w-8 h-8 grid place-items-center rounded-lg border border-slate-200 text-slate-500 hover:text-[#0052D9] hover:border-[#0052D9]/40 transition-colors">
            <ZoomOut size={15} />
          </button>
          <span className="text-[11px] text-slate-500 tabular-nums w-12 text-center">{Math.round(zoom * 100)}%</span>
          <button onClick={() => bump(1.4)} title="放大" className="w-8 h-8 grid place-items-center rounded-lg border border-slate-200 text-slate-500 hover:text-[#0052D9] hover:border-[#0052D9]/40 transition-colors">
            <ZoomIn size={15} />
          </button>
          <button onClick={reset} title="重置" className="w-8 h-8 grid place-items-center rounded-lg border border-slate-200 text-slate-500 hover:text-[#0052D9] hover:border-[#0052D9]/40 transition-colors">
            <RotateCcw size={14} />
          </button>
        </div>
      </div>

      {/* 产品分类专属：按产品聚合最新 Case Update */}
      {dimLabel === "产品" && (
        <section className="bg-white border border-violet-200/70 rounded-xl shadow-[0_1px_2px_0_rgba(15,23,42,0.04)] overflow-hidden">
          <div className="h-[62px] px-5 flex items-center gap-3 border-b border-violet-100 bg-gradient-to-r from-violet-50/80 via-white to-white">
            <span className="w-9 h-9 rounded-xl bg-violet-600 text-white grid place-items-center shadow-sm shadow-violet-200">
              <Package size={17} />
            </span>
            <div>
              <h3 className="text-[14px] font-bold text-slate-900">产品更新汇总</h3>
              <p className="text-[10.5px] text-slate-500 mt-0.5">汇总每个产品下全部 Case 的 Update 内容与推进状态</p>
            </div>
            <span className="ml-auto text-[10.5px] px-2.5 py-1 rounded-full bg-white text-violet-600 border border-violet-200">
              {isAll ? "全部产品" : sel.label} · {productUpdates.length} 个产品
            </span>
          </div>

          {productUpdates.length > 0 ? (
            <div className={`grid gap-3 p-4 ${productUpdates.length === 1 ? "grid-cols-1" : "grid-cols-2"}`}>
              {productUpdates.map((product) => {
                const expanded = expandedSummaries.has(product.id);
                const expandable = product.updateCount > 2 || product.summary.length > 160;
                return (
                <article key={product.id} className="rounded-xl border border-slate-200 bg-white p-4 hover:border-violet-300 hover:shadow-[0_8px_24px_-16px_rgba(124,58,237,0.35)] transition-all self-start">
                  <div className="flex items-start gap-3">
                    <span className="w-9 h-9 rounded-lg bg-violet-50 text-violet-600 grid place-items-center shrink-0">
                      <Package size={16} />
                    </span>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <h4 className="text-[13.5px] font-bold text-slate-900 truncate">{product.name}</h4>
                        {product.family && <span className="text-[9.5px] px-1.5 py-0.5 rounded bg-violet-50 text-violet-600 border border-violet-100 shrink-0">{product.family}</span>}
                      </div>
                      <div className="text-[10.5px] text-slate-400 mt-0.5">{product.code}</div>
                    </div>
                    <div className="ml-auto flex items-center gap-1.5 shrink-0">
                      <span className="inline-flex items-center gap-1 text-[10.5px] px-2 py-1 rounded-lg bg-slate-50 text-slate-500">
                        <Activity size={11} /> {product.cases.length} 个 Case
                      </span>
                      <span className="inline-flex items-center gap-1 text-[10.5px] px-2 py-1 rounded-lg bg-[#0052D9]/[0.06] text-[#0052D9]">
                        <span className="w-1.5 h-1.5 rounded-full bg-[#0052D9]" /> {product.active} 个进行中
                      </span>
                      {product.closed > 0 && <span className="text-[10.5px] px-2 py-1 rounded-lg bg-emerald-50 text-emerald-600">{product.closed} 个已结案</span>}
                    </div>
                  </div>

                  <div className="mt-3 rounded-lg border border-violet-100 bg-gradient-to-r from-violet-50/55 to-slate-50/40 px-3 py-2.5">
                    <div className="flex items-center gap-1.5 text-[10.5px] font-semibold text-violet-600">
                      <span className="w-1.5 h-1.5 rounded-full bg-violet-500" /> 全部 Case 更新总结
                      <span className="ml-auto text-[9.5px] font-normal text-violet-500">覆盖 {product.cases.length} 个 Case · {product.updateCount} 条 Update</span>
                    </div>
                    <p className={`mt-1.5 text-[12px] leading-relaxed text-slate-600 ${expanded ? "" : "line-clamp-4"}`}>{product.summary}</p>
                    {expandable && (
                      <button
                        type="button"
                        onClick={() => setExpandedSummaries((current) => {
                          const next = new Set(current);
                          next.has(product.id) ? next.delete(product.id) : next.add(product.id);
                          return next;
                        })}
                        className="mt-1.5 text-[10.5px] text-violet-600 hover:text-violet-800"
                      >
                        {expanded ? "收起总结" : "展开全部 Case 更新"}
                      </button>
                    )}
                  </div>

                  <div className="mt-2.5 flex items-center gap-2 min-w-0 text-[10.5px] text-slate-400">
                    <Clock3 size={11} className="shrink-0" />
                    <span className="shrink-0">{product.latestCase.updatedAt}</span>
                    <span className="text-slate-200">|</span>
                    <span className="truncate">{product.latestCase.owner} · {product.latestCase.code} · {product.latestCase.name}</span>
                    <button
                      type="button"
                      onClick={() => onOpenCase(product.latestCase.id)}
                      className="ml-auto inline-flex items-center gap-0.5 text-[#0052D9] hover:underline shrink-0"
                    >
                      查看 Case <ArrowUpRight size={11} />
                    </button>
                  </div>
                </article>
                );
              })}
            </div>
          ) : (
            <div className="py-10 text-center text-[12px] text-slate-400">当前分类下暂无产品更新</div>
          )}
        </section>
      )}

      {/* 全生命周期时间轴 */}
      <div className="bg-white border border-slate-200/80 rounded-xl shadow-[0_1px_2px_0_rgba(15,23,42,0.04)] overflow-hidden">
        <div className="px-5 py-3 border-b border-slate-100 flex items-center gap-2">
          <h3 className="text-[14px] font-bold text-slate-800">{title}</h3>
          <span className="text-[11px] text-slate-400">0 → 1 · {isAll ? `全部${dimLabel}` : sel.label} · {cases.length} 个 Case</span>
        </div>

        <div ref={scrollRef} onMouseDown={onDown} className="relative overflow-x-auto overflow-y-hidden cursor-grab select-none">
          <div className="relative" style={{ width: `${zoom * 100}%`, minWidth: "100%", height: trackHeight }}>
            {/* 阶段带 */}
            {stages.map((s) => (
              <div
                key={s.key}
                className="absolute top-3 rounded-md overflow-hidden"
                style={{ left: pct(s.from), width: pct(s.to - s.from), height: 40, background: `${s.color}14`, borderLeft: `2px solid ${s.color}` }}
              >
                <span className="absolute left-2 top-1.5 text-[11px] font-semibold whitespace-nowrap" style={{ color: s.color }}>{s.label}</span>
                <span className="absolute left-2 bottom-1 text-[10px] text-slate-400 tabular-nums whitespace-nowrap">{pct(s.from)} – {pct(s.to)}</span>
              </div>
            ))}

            {/* 阶段分界竖虚线 */}
            {stages.map((s) => (
              <div key={s.key + "-b"} className="absolute top-3 border-l border-dashed border-slate-200" style={{ left: pct(s.from), height: axisY - 12 }} />
            ))}
            <div className="absolute top-3 border-l border-dashed border-slate-200" style={{ left: "100%", height: axisY - 12 }} />

            {/* Case 标记 */}
            {placed.map(({ c, f, row }) => {
              const top = TOP + row * ROW_H;
              const flip = f > 0.82; // 靠右端的卡片改为向左展开，避免被右边缘裁切
              return (
                <div key={c.id} className="absolute" style={{ left: pct(f), top }}>
                  <div className="absolute left-0 top-7 border-l border-slate-200" style={{ height: axisY - top - 7 }} />
                  <button
                    onClick={() => onOpenCase(c.id)}
                    onMouseDown={(e) => e.stopPropagation()}
                    title={`${c.name} · 进度 ${prog(c)}%`}
                    className={`group absolute top-0 flex items-center gap-1.5 max-w-[230px] bg-white border border-slate-200 rounded-lg pl-1.5 pr-2.5 py-1 shadow-[0_2px_8px_-4px_rgba(15,23,42,0.2)] hover:border-[#0052D9]/40 hover:shadow-md transition-all ${flip ? "right-1.5" : "left-1.5"}`}
                  >
                    <span className={`w-[3px] self-stretch rounded ${urgencyBar[c.urgency] || "bg-slate-300"}`} />
                    <span className={`text-[9px] px-1 py-0.5 rounded border shrink-0 ${levelColors[c.level]}`}>{c.level}</span>
                    <CaseProductPill caseItem={c} compact />
                    <span className="text-[11.5px] text-slate-700 truncate group-hover:text-[#0052D9] transition-colors">{c.name}</span>
                  </button>
                  <div className="absolute -translate-x-1/2 w-2.5 h-2.5 rounded-full bg-white border-2 border-[#0052D9]" style={{ top: axisY - top - 5 }} />
                </div>
              );
            })}

            {/* 坐标轴 + 刻度 */}
            <div className="absolute left-0 right-0 border-t border-slate-300" style={{ top: axisY }} />
            {ticks.map((v, i) => (
              <div key={i} className="absolute" style={{ left: pct(v), top: axisY }}>
                <div className="absolute -translate-x-1/2 border-l border-slate-300" style={{ height: isMajor(v) ? 8 : 5 }} />
                {isMajor(v) && (
                  <div className="absolute -translate-x-1/2 top-2.5 text-[10px] text-slate-400 tabular-nums whitespace-nowrap">{pct(v)}</div>
                )}
              </div>
            ))}

            {placed.length === 0 && (
              <div className="absolute inset-0 grid place-items-center text-sm text-slate-400">该{dimLabel}下暂无 Case</div>
            )}
          </div>
        </div>

        {/* 阶段图例 */}
        <div className="px-5 py-2.5 border-t border-slate-100 flex items-center gap-4 flex-wrap text-[11px] text-slate-500">
          {stages.map((s) => (
            <span key={s.key} className="inline-flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-sm" style={{ background: s.color }} />
              {s.label}
            </span>
          ))}
          <span className="ml-auto text-slate-400">阶段为占位示意，最终生命周期阶段待定义后替换</span>
        </div>
      </div>
    </div>
  );
}
