import { useMemo, useState, useRef, useEffect } from "react";
import {
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  FileText,
  FileImage,
  FileSpreadsheet,
  File as FileIcon,
  Lightbulb,
} from "lucide-react";
import { CaseItem, TaskNode, statusDot } from "./data";

/* ===== 云笔记 · Case 每日更新（内嵌演示模式封面右栏）=====
 * 规则（Case 展开）：只列当天有更新的任务，每个任务给
 *   谁 + 现状态 + 当天最重要一句 + 状态流转 + 附件；区间则按天分组重复这套。
 * 数据为演示用假数据：从当前 Case 的执行任务派生「按天事件流」。
 */

type NoteKind = "accept" | "note" | "status" | "attach" | "conclusion";
interface NoteEvent {
  at: string; // yyyy-MM-dd HH:mm
  kind: NoteKind;
  from?: string;
  to?: string;
  text?: string;
  file?: string;
  validity?: string;
}
interface NoteTask {
  idx: number;
  code: string;
  name: string;
  thought: string;
  owner: string;
  role: string;
  status: string;
  events: NoteEvent[];
}

/* ── 日期工具 ─────────────────────────────────────────── */
const WD = ["周日", "周一", "周二", "周三", "周四", "周五", "周六"];
function weekdayOf(iso: string) {
  return WD[new Date(iso.replace(/-/g, "/") + " 00:00").getDay()];
}
function pad2(n: number) {
  return String(n).padStart(2, "0");
}
function toIso(d: Date) {
  return d.getFullYear() + "-" + pad2(d.getMonth() + 1) + "-" + pad2(d.getDate());
}
function isoAdd(iso: string, delta: number) {
  const d = new Date(iso.replace(/-/g, "/") + " 00:00");
  d.setDate(d.getDate() + delta);
  return toIso(d);
}

/* ── 演示假数据池：一批工程分析任务（按思路归类），用于展示看板 overflow ── */
const FAKE_POOL: { day: number; thought: string; name: string; owner: string; role: string; status: string; summary: string; files?: string[]; conclusion?: boolean }[] = [
  // ——— 思路：电压 margin 不足 ———
  { day: 0, thought: "电压 margin 不足", name: "低压 Shmoo / Pattern 验证", owner: "张伟", role: "PTE", status: "已完成", summary: "1.05V 以下高频段 Fail 面积扩大，与 Pattern P_ICC2_07 强相关，确认主因为电压 margin。", files: ["shmoo_vddmin.xlsx"], conclusion: true },
  { day: 0, thought: "电压 margin 不足", name: "Coverage 上线拦截评估", owner: "张伟", role: "PTE", status: "进行中", summary: "评估 P_ICC2_07 上线 Coverage 的测试时长与站点成本。" },
  { day: 0, thought: "电压 margin 不足", name: "Pattern P_ICC2_07 时序调整方案", owner: "赵敏", role: "PE", status: "待接受", summary: "待接手，拟对 P_ICC2_07 做 timing margin 调整评审稿。" },
  // ——— 思路：封装 / 物理缺陷（任务多，纵向 overflow）———
  { day: 0, thought: "封装 / 物理缺陷", name: "FIB / SEM 物理分析", owner: "陈磊", role: "FA", status: "进行中", summary: "FIB 截面未见裂纹、bonding 正常，基本排除封装/bonding。", files: ["wafermap_lotA.png", "fib_edge01.png", "fib_edge02.png", "sem_cross.png"] },
  { day: 0, thought: "封装 / 物理缺陷", name: "边缘 die 氧化层 SEM 复检", owner: "陈磊", role: "FA", status: "进行中", summary: "边缘 die 氧化层偏薄约 4nm，Bin7 在边缘聚集分布。", files: ["sem_edge_die.png"] },
  { day: 0, thought: "封装 / 物理缺陷", name: "封装应力 X-ray 无损检查", owner: "周杰", role: "FA", status: "进行中", summary: "X-ray 未见明显 void / 分层，封装应力方向暂无异常。", files: ["xray_scan.png"] },
  { day: 0, thought: "封装 / 物理缺陷", name: "EDS 成分分析", owner: "陈磊", role: "FA", status: "进行中", summary: "对边缘异常区做 EDS 成分分析，未见明显金属污染。", files: ["eds_spectrum.png", "eds_table.xlsx"] },
  { day: 0, thought: "封装 / 物理缺陷", name: "开封去层逐层观察", owner: "周杰", role: "FA", status: "进行中", summary: "逐层去层观察金属走线，M3 层局部偏薄，待复核。" },
  { day: 0, thought: "封装 / 物理缺陷", name: "bonding wire 拉力测试", owner: "陈磊", role: "FA", status: "已完成", summary: "抽样 20 pcs 拉力测试全部达标，排除 bonding 强度问题。", conclusion: true },
  // ——— 思路：产线换 target 工艺偏移 ———
  { day: 0, thought: "产线换 target 工艺偏移", name: "近 8 Lot 良率回溯", owner: "李娜", role: "PE", status: "进行中", summary: "L04–L06 良率从 94% 掉到 82%，掉点时间与产线换 target 吻合。", files: ["datalog_lotA.csv"] },
  { day: 0, thought: "产线换 target 工艺偏移", name: "炉温相关性回归分析", owner: "李娜", role: "PE", status: "进行中", summary: "良率与炉温做相关性回归，换 target 前后温区偏移约 6℃。", files: ["thermal_regression.xlsx"] },
  // ——— 思路：Refresh timing margin 不足 ———
  { day: 0, thought: "Refresh timing margin 不足", name: "Refresh timing margin 复测", owner: "孙楠", role: "PTE", status: "进行中", summary: "按新 refresh 参数复测两组样品，Fail rate 由 3.2% 降至 0.4%。" },
  { day: 0, thought: "Refresh timing margin 不足", name: "tREFI 扫描对比", owner: "孙楠", role: "PTE", status: "进行中", summary: "tREFI 扫描对比，缩短刷新周期后 Fail 明显收敛。", files: ["trefi_sweep.csv"] },
  // ——— 思路：站点 / 测试条件差异 ———
  { day: 0, thought: "站点 / 测试条件差异", name: "Retest rate 分站点拆解", owner: "孙楠", role: "PTE", status: "进行中", summary: "按站点拆解 Retest rate，Site A 明显高于 Site B / C。", files: ["retest_by_site.csv"] },
  // ——— 思路：电源完整性 (PI) ———
  { day: 0, thought: "电源完整性 (PI)", name: "VDDQ droop 波形捕捉", owner: "王芳", role: "TE", status: "进行中", summary: "捕捉高频写场景 VDDQ droop，压降约 45mV，接近规格上限。", files: ["vddq_droop.png"] },
  // ——— 思路：时钟 / DLL 抖动 ———
  { day: 0, thought: "时钟 / DLL 抖动", name: "DLL lock 时序 jitter 分析", owner: "张伟", role: "PTE", status: "进行中", summary: "分析 DLL lock 后 jitter，边界温度下 jitter 略增。" },
  // ——— 思路：温度相关性 ———
  { day: 0, thought: "温度相关性", name: "高低温循环复现", owner: "张伟", role: "PTE", status: "进行中", summary: "-40℃~85℃ 循环复现，低温段 Fail 更集中。" },
  // ——— 历史（前两日）———
  { day: 1, thought: "来料 / 样品确认", name: "客退样品来料确认", owner: "王芳", role: "TE", status: "已完成", summary: "客退 2 批次样品来料核对完成，SN 与失效清单一致。", conclusion: true },
  { day: 1, thought: "对标分析", name: "竞品对标失效率统计", owner: "周杰", role: "FA", status: "进行中", summary: "整理近三个季度竞品同规格失效率，用于对标定位。", files: ["benchmark.xlsx"] },
  { day: 1, thought: "产线换 target 工艺偏移", name: "SPC 触发点复盘", owner: "李娜", role: "PE", status: "进行中", summary: "复盘 WAT Vth 漂移的 SPC 触发点，锁定两个可疑批次。" },
  { day: 2, thought: "封装 / 物理缺陷", name: "EFA 切片诉求单跟进", owner: "陈磊", role: "FA", status: "进行中", summary: "EFA-260721-009 已提交，诉求定位失效层，等待 FA 排期。" },
  { day: 2, thought: "8D 系统性分析", name: "客户 8D 报告初稿", owner: "王芳", role: "TE", status: "待接受", summary: "待接受，确认后按 D0–D8 框架起草客户 8D 报告。" },
];

/* ── 生成「按天事件流」（演示假数据，铺满整屏并可滚动）───── */
function buildNoteTasks(caseItem: CaseItem, _tasks: TaskNode[]): NoteTask[] {
  const anchor = (caseItem.updatedAt || "").slice(0, 10) || toIso(new Date());
  // 三个连续更新日：anchor（最新）、anchor-1、anchor-2
  const days = [anchor, isoAdd(anchor, -1), isoAdd(anchor, -2)];

  return FAKE_POOL.map((p, i) => {
    const dayMain = days[p.day] || days[0];
    const dayAccept = days[Math.min(days.length - 1, p.day + 1)];
    const ev: NoteEvent[] = [];

    ev.push({ at: dayAccept + " 09:" + pad2(10 + (i % 40)), kind: "accept", text: "接手任务，开始 " + p.name });
    ev.push({ at: dayMain + " 10:" + pad2(5 + (i % 40)), kind: "note", text: p.summary });
    (p.files || []).forEach((f, k) => ev.push({ at: dayMain + " 10:" + pad2(38 + (i % 12) + k), kind: "attach", file: f, text: "上传分析数据" }));

    if (p.status !== "待接受") {
      const from = p.status === "进行中" ? "待接受" : "进行中";
      if (from !== p.status) ev.push({ at: dayMain + " 11:" + pad2(i % 60), kind: "status", from, to: p.status });
    }
    if (p.conclusion) ev.push({ at: dayMain + " 11:" + pad2(30 + (i % 29)), kind: "conclusion", validity: "有效", text: p.summary });

    ev.sort((a, b) => (a.at < b.at ? -1 : 1));
    return { idx: i, code: "EA-DEMO-" + pad2(i + 1), name: p.name, thought: p.thought, owner: p.owner, role: p.role, status: p.status, events: ev };
  });
}

/* 一组事件里最具代表性的一句（结论>笔记>状态>附件>接手）*/
function summaryFromEvents(evs: NoteEvent[]) {
  const w: Record<NoteKind, number> = { conclusion: 5, note: 4, status: 3, attach: 2, accept: 1 };
  let best: NoteEvent | null = null;
  let bw = -1;
  evs.forEach((e) => {
    const s = w[e.kind] || 0;
    if (s >= bw) {
      bw = s;
      best = e;
    }
  });
  if (!best) return "";
  const b = best as NoteEvent;
  if (b.kind === "status") return "状态更新为「" + b.to + "」";
  return b.text || "";
}

/* 附件类型推断 + 图标（与 Case 详情思维导图卡片一致）*/
function attachKind(name: string): "pdf" | "image" | "sheet" | "file" {
  const n = (name || "").toLowerCase();
  if (n.endsWith(".pdf")) return "pdf";
  if (/\.(png|jpe?g|gif|bmp|webp|svg)$/.test(n)) return "image";
  if (/\.(xlsx?|csv|numbers)$/.test(n)) return "sheet";
  return "file";
}
function AttIcon({ kind }: { kind: "pdf" | "image" | "sheet" | "file" }) {
  if (kind === "pdf") return <FileText size={12} className="text-rose-500" />;
  if (kind === "image") return <FileImage size={12} className="text-sky-500" />;
  if (kind === "sheet") return <FileSpreadsheet size={12} className="text-emerald-500" />;
  return <FileIcon size={12} className="text-slate-400" />;
}

export function CaseDailyNote({ caseItem, tasks, onOpenTask, headerRight, bodyOverride, fill, leadRight }: { caseItem: CaseItem; tasks: TaskNode[]; onOpenTask?: (idx: number) => void; headerRight?: React.ReactNode; bodyOverride?: React.ReactNode; fill?: boolean; leadRight?: React.ReactNode }) {
  const noteTasks = useMemo(() => buildNoteTasks(caseItem, tasks), [caseItem, tasks]);

  // 有更新的日期（新→旧）
  const dates = useMemo(() => {
    const set: Record<string, true> = {};
    noteTasks.forEach((t) => t.events.forEach((e) => (set[e.at.slice(0, 10)] = true)));
    return Object.keys(set).sort().reverse();
  }, [noteTasks]);

  const latestDay = dates[0] || (caseItem.updatedAt || "").slice(0, 10) || toIso(new Date());

  const [date, setDate] = useState(latestDay);
  const [dateEnd, setDateEnd] = useState<string | null>(null);
  const [calOpen, setCalOpen] = useState(false);
  const [picking, setPicking] = useState(false);
  const [cal, setCal] = useState(() => {
    const d = new Date(latestDay.replace(/-/g, "/") + " 00:00");
    return { y: d.getFullYear(), m: d.getMonth() };
  });
  const calRef = useRef<HTMLDivElement>(null);
  const calBtnRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!calOpen) return;
    const onDown = (e: MouseEvent) => {
      if (calRef.current?.contains(e.target as Node) || calBtnRef.current?.contains(e.target as Node)) return;
      // 只点了起始就关闭 → 视为单天
      if (picking) {
        setPicking(false);
        setDateEnd(null);
      }
      setCalOpen(false);
    };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, [calOpen, picking]);

  const range = useMemo(() => {
    const a = date;
    const b = dateEnd || date;
    return a <= b ? { start: a, end: b } : { start: b, end: a };
  }, [date, dateEnd]);
  const isRange = !!dateEnd && dateEnd !== date;

  const dayEvents = (t: NoteTask, day: string) => t.events.filter((e) => e.at.slice(0, 10) === day);
  const updatedOnDay = (t: NoteTask, day: string) => dayEvents(t, day).length > 0;
  const daysInRange = () => dates.filter((d) => d >= range.start && d <= range.end);

  const label = isRange
    ? range.start.slice(5) + " ~ " + range.end.slice(5)
    : (date === latestDay ? "最新 " : "") + date.slice(5) + " " + weekdayOf(date);
  const prefix = date === latestDay ? "今日" : "当日";

  /* ── 任务卡片 ───────────────────────────────── */
  const StatusBadge = ({ status }: { status: string }) => (
    <span className="inline-flex items-center gap-1.5 text-[12px] font-medium text-slate-500 shrink-0">
      <span className={`w-1.5 h-1.5 rounded-full ${statusDot[status as keyof typeof statusDot] || "bg-slate-400"}`} />
      {status}
    </span>
  );

  const TaskBlock = ({ t, day }: { t: NoteTask; day: string }) => {
    const evs = dayEvents(t, day);
    const attachEvs = evs.filter((e) => e.file);
    return (
      <div className="rounded-xl border border-slate-200/80 bg-white p-4 flex flex-col break-inside-avoid">
        <div className="flex items-start justify-between gap-3">
          {onOpenTask ? (
            <button
              type="button"
              onClick={() => onOpenTask(t.idx)}
              title="在演示中查看该任务"
              className="text-[14.5px] font-semibold text-slate-800 leading-snug text-left hover:text-[#0052D9] transition-colors"
            >
              {t.name}
            </button>
          ) : (
            <span className="text-[14.5px] font-semibold text-slate-800 leading-snug">{t.name}</span>
          )}
          <StatusBadge status={t.status} />
        </div>
        <p className="text-[13px] text-slate-500 leading-relaxed mt-2">{summaryFromEvents(evs)}</p>
        {attachEvs.length > 0 && (
          <div className="flex items-center gap-1 flex-wrap mt-2.5 text-[10px]">
            <span className="text-slate-400 shrink-0">附件：</span>
            {attachEvs.map((a, i) => (
              <span
                key={i}
                title={a.file}
                className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-white/70 border border-slate-200 text-slate-600 hover:border-[#0052D9] hover:text-[#0052D9] cursor-pointer transition-colors max-w-full"
              >
                <AttIcon kind={attachKind(a.file || "")} />
                <span className="truncate max-w-[150px]">{a.file}</span>
              </span>
            ))}
          </div>
        )}
        <div className="flex items-center gap-2 mt-3 pt-3 border-t border-slate-100">
          <span className="w-5 h-5 rounded-full bg-gradient-to-br from-[#00A4FF] to-[#0052D9] text-white flex items-center justify-center text-[9px] font-medium leading-none shrink-0">{t.owner.slice(-2)}</span>
          <span className="text-[12.5px] text-slate-600 font-medium">{t.owner}</span>
          {t.role && <span className="text-[11px] text-slate-400">{t.role}</span>}
        </div>
      </div>
    );
  };

  /* ── 正文 ─────────────────────────────────────────── */
  let body: React.ReactNode;
  if (isRange) {
    const days = daysInRange();
    const blocks = days
      .map((day) => {
        const picks = noteTasks.filter((t) => updatedOnDay(t, day));
        if (!picks.length) return null;
        return (
          <div key={day} className="space-y-2.5">
            <div className="text-[12px] font-semibold text-slate-400">{day.slice(5) + " " + weekdayOf(day)}</div>
            <div className="grid grid-cols-1 md:grid-cols-2 2xl:grid-cols-3 gap-4 items-start">
              {picks.map((t) => (
                <TaskBlock key={t.code} t={t} day={day} />
              ))}
            </div>
          </div>
        );
      })
      .filter(Boolean);
    body = blocks.length ? (
      <div className="h-full overflow-auto pr-1 space-y-5">{blocks}</div>
    ) : (
      <div className="text-[14px] text-slate-400 py-6">该区间没有任务更新</div>
    );
  } else {
    const picks = noteTasks.filter((t) => updatedOnDay(t, date));
    if (!picks.length) {
      body = <div className="text-[14px] text-slate-400 py-6">{prefix}没有任务更新</div>;
    } else {
      // 按思路分组（保持首次出现顺序）
      const order: string[] = [];
      const byThought: Record<string, NoteTask[]> = {};
      picks.forEach((t) => {
        const k = t.thought || "未归类";
        if (!byThought[k]) { byThought[k] = []; order.push(k); }
        byThought[k].push(t);
      });
      body = (
        <div className="h-full flex flex-col">
          <div className="flex items-center gap-2 mb-3 shrink-0">
            <div className="text-[13px] text-slate-500">
              {prefix}有更新的任务 <span className="font-semibold text-slate-700">{picks.length}</span> 个 · {order.length} 个思路
            </div>
            <div className="flex-1" />
            {leadRight}
          </div>
          {/* 看板：每个思路一栏（栏内纵向滚动，思路多则整排横向滚动） */}
          <div className="flex-1 min-h-0 relative">
            <div className="h-full overflow-x-auto overflow-y-hidden pb-1">
              <div className="flex gap-4 h-full pr-10">
                {order.map((th) => (
                  <div key={th} className="flex flex-col w-[300px] shrink-0 h-full rounded-xl bg-slate-50/60 border border-slate-200/70">
                    <div className="flex items-center gap-1.5 px-3 py-2.5 shrink-0 border-b border-slate-200/70">
                      <Lightbulb size={13} className="text-amber-500 shrink-0" />
                      <span className="text-[12.5px] font-semibold text-slate-700 truncate">{th}</span>
                      <span className="text-[11.5px] text-slate-400 ml-auto shrink-0">{byThought[th].length}</span>
                    </div>
                    <div className="flex-1 min-h-0 overflow-y-auto p-2.5 space-y-2.5 nowheel">
                      {byThought[th].map((t) => (
                        <TaskBlock key={t.code} t={t} day={date} />
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
            {/* 右侧渐隐：软化横向滚动的截断，并提示可继续左右滑动 */}
            <div className="pointer-events-none absolute top-0 right-0 bottom-2 w-16 bg-gradient-to-l from-white via-white/70 to-transparent" />
          </div>
        </div>
      );
    }
  }

  /* ── 日历 ─────────────────────────────────────────── */
  const Calendar = () => {
    const hasSet: Record<string, true> = {};
    dates.forEach((d) => (hasSet[d] = true));
    const first = new Date(cal.y, cal.m, 1);
    const lead = first.getDay();
    const dim = new Date(cal.y, cal.m + 1, 0).getDate();
    const cells: React.ReactNode[] = [];
    for (let b = 0; b < lead; b++) cells.push(<span key={"b" + b} />);
    for (let d = 1; d <= dim; d++) {
      const iso = cal.y + "-" + pad2(cal.m + 1) + "-" + pad2(d);
      const isActive = iso === range.start || iso === range.end;
      const inR = iso > range.start && iso < range.end;
      const hasData = !!hasSet[iso];
      const onClick = (e: React.MouseEvent) => {
        e.stopPropagation();
        if (!picking) {
          setDate(iso);
          setDateEnd(null);
          setPicking(true);
        } else {
          setDateEnd(iso === date ? null : iso);
          setPicking(false);
          setCalOpen(false);
        }
      };
      cells.push(
        <button
          key={d}
          onClick={onClick}
          className={`relative h-7 rounded text-[12px] flex items-center justify-center transition-colors ${
            isActive ? "bg-[#0052D9] text-white font-semibold" : inR ? "bg-[#0052D9]/10 text-[#0052D9]" : "text-slate-600 hover:bg-slate-100"
          }`}
        >
          {d}
          {hasData && !isActive && <span className="absolute bottom-0.5 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-[#0052D9]" />}
        </button>
      );
    }
    return (
      <div ref={calRef} className="absolute left-0 top-9 z-50 w-[248px] rounded-xl border border-slate-200 bg-white shadow-xl p-3">
        <div className="flex items-center justify-between mb-2">
          <button
            onClick={(e) => {
              e.stopPropagation();
              setCal((c) => (c.m === 0 ? { y: c.y - 1, m: 11 } : { y: c.y, m: c.m - 1 }));
            }}
            className="w-6 h-6 rounded hover:bg-slate-100 flex items-center justify-center text-slate-500"
          >
            <ChevronLeft size={14} />
          </button>
          <span className="text-[12.5px] font-semibold text-slate-700">
            {cal.y}年{cal.m + 1}月
          </span>
          <button
            onClick={(e) => {
              e.stopPropagation();
              setCal((c) => (c.m === 11 ? { y: c.y + 1, m: 0 } : { y: c.y, m: c.m + 1 }));
            }}
            className="w-6 h-6 rounded hover:bg-slate-100 flex items-center justify-center text-slate-500"
          >
            <ChevronRight size={14} />
          </button>
        </div>
        <div className="grid grid-cols-7 gap-0.5 mb-1">
          {["日", "一", "二", "三", "四", "五", "六"].map((w) => (
            <span key={w} className="h-6 flex items-center justify-center text-[10.5px] text-slate-400">
              {w}
            </span>
          ))}
        </div>
        <div className="grid grid-cols-7 gap-0.5">{cells}</div>
        <div className="text-[10.5px] text-slate-400 mt-2 leading-snug">
          {picking ? "已选起始 " + date.slice(5) + "，再点一天作为结束" : "点一天看当天；点两天选区间"}
        </div>
      </div>
    );
  };

  return (
    <div className={fill ? "w-full h-full flex flex-col" : "w-full"}>
      {/* 日期 + 日历 + 右侧视图切换 */}
      <div className="flex items-center gap-2 mb-4 shrink-0">
        <span className="text-[15px] font-semibold text-slate-700">{label}</span>
        <div className="relative">
          <button
            ref={calBtnRef}
            onClick={() => {
              if (!calOpen) {
                setPicking(false);
                const d = new Date(date.replace(/-/g, "/") + " 00:00");
                setCal({ y: d.getFullYear(), m: d.getMonth() });
              }
              setCalOpen((v) => !v);
            }}
            title="选择日期 / 区间"
            className={`w-7 h-7 rounded-lg flex items-center justify-center transition-colors ${calOpen ? "bg-[#0052D9]/10 text-[#0052D9]" : "text-slate-400 hover:bg-slate-100 hover:text-slate-600"}`}
          >
            <CalendarIcon size={14} />
          </button>
          {calOpen && <Calendar />}
        </div>
        <div className="flex-1" />
        {headerRight}
      </div>
      {/* 正文（或自定义替换内容，如思维导图）；fill 模式下由内容自管滚动 */}
      {fill
        ? <div className="flex-1 min-h-0">{bodyOverride ?? body}</div>
        : (bodyOverride ?? <div className="pr-1">{body}</div>)}
    </div>
  );
}
