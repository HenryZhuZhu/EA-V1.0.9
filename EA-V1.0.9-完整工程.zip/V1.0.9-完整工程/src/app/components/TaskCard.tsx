import { useState } from "react";
import {
  CalendarClock,
  Play,
  Upload,
  FileSpreadsheet,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
} from "lucide-react";
import { TaskNode, urgencyColors } from "./data";

interface Props {
  task: TaskNode;
  onOpen?: () => void;
  defaultExpanded?: boolean;
  compact?: boolean;
}

export function TaskCard({ task, onOpen, defaultExpanded = false, compact = false }: Props) {
  const [open, setOpen] = useState(defaultExpanded);
  const [analysis, setAnalysis] = useState("");
  const overdue = (task.dueIn ?? 99) <= 1;
  const actions = task.recommendedActions || [
    "拉取相关数据",
    "执行分析步骤",
    "输出结论",
  ];

  return (
    <div className="bg-white border border-slate-200 rounded-lg overflow-hidden hover:border-[#0052D9]/40 transition-colors">
      {/* Header */}
      <div className="p-4 flex items-start gap-3">
        <button
          onClick={() => setOpen(!open)}
          className="mt-0.5 w-5 h-5 rounded hover:bg-slate-100 flex items-center justify-center text-slate-500 shrink-0"
        >
          {open ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
        </button>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1.5">
            <span className={`px-1.5 py-0.5 rounded text-[10px] ${urgencyColors[task.urgency]}`}>
              {task.urgency}
            </span>
            <span className="text-[11px] text-slate-500">{task.department}</span>
            <span className="text-[11px] text-slate-400">· {task.owner}</span>
            <span className="text-[11px] text-slate-500 ml-auto flex items-center gap-1">
              <CalendarClock size={11} />
              到期 {task.dueDate || "—"}
              <span
                className={`ml-1 px-1.5 py-0.5 rounded text-[10px] ${
                  overdue
                    ? "bg-red-50 text-red-600 border border-red-200"
                    : (task.dueIn ?? 99) <= 3
                    ? "bg-amber-50 text-amber-600 border border-amber-200"
                    : "bg-slate-100 text-slate-600"
                }`}
              >
                {(task.dueIn ?? 99) === 0 ? "今日" : `${task.dueIn ?? "—"} 天`}
              </span>
            </span>
          </div>
          <div className="text-sm text-slate-900">{task.title}</div>
          {!compact && (
            <div className="text-xs text-slate-500 mt-1">状态 · {task.status}</div>
          )}
        </div>
        {onOpen && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              onOpen();
            }}
            className="h-7 px-2.5 text-xs rounded border border-slate-200 text-slate-600 hover:bg-slate-50 shrink-0"
          >
            详情
          </button>
        )}
      </div>

      {/* Expanded content */}
      {open && (
        <div className="border-t border-slate-100 bg-slate-50/40 p-4 space-y-4">
          {/* Actions */}
          <div>
            <div className="text-xs text-slate-500 mb-2">具体执行任务</div>
            <div className="space-y-1.5">
              {actions.map((a, i) => (
                <div
                  key={i}
                  className="flex items-center gap-2 p-2 rounded bg-white border border-slate-100"
                >
                  <div className="w-5 h-5 rounded-full bg-[#0052D9]/10 text-[#0052D9] flex items-center justify-center text-[10px]">
                    {i + 1}
                  </div>
                  <div className="flex-1 text-xs text-slate-700">{a}</div>
                  <button className="h-6 px-2 text-[11px] rounded border border-slate-200 text-slate-600 hover:bg-slate-50 flex items-center gap-1">
                    <Play size={10} /> 调用
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Upload */}
          <div>
            <div className="text-xs text-slate-500 mb-2">
              上传标准数据 <span className="text-red-500">*</span>
              <span className="text-slate-400"> · Excel / 图像 / 日志，永久关联到 Case</span>
            </div>
            <div className="border border-dashed border-slate-300 rounded-md p-3 text-center bg-white">
              <Upload size={16} className="mx-auto text-slate-400" />
              <div className="text-xs text-slate-500 mt-1">拖拽文件到此处，或点击上传</div>
            </div>
            <div className="mt-2 grid grid-cols-2 gap-2">
              {["datalog_lotA.csv", "shmoo_vddmin.xlsx"].map((f) => (
                <div
                  key={f}
                  className="flex items-center gap-1.5 p-1.5 rounded border border-slate-100 text-[11px] text-slate-600 bg-white"
                >
                  <FileSpreadsheet size={11} className="text-[#00B578]" />
                  <span className="truncate">{f}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Analysis */}
          <div>
            <div className="text-xs text-slate-500 mb-2">
              分析过程 / 结论 <span className="text-red-500">*</span>
            </div>
            <textarea
              value={analysis}
              onChange={(e) => setAnalysis(e.target.value)}
              placeholder="写下你的分析思路、关键判断与结论..."
              className="w-full min-h-[80px] p-2.5 text-xs rounded-md border border-slate-200 bg-white focus:border-[#0052D9] outline-none resize-y"
            />
            <div className="flex justify-end gap-1.5 mt-2">
              <button className="h-7 px-2.5 text-[11px] rounded border border-slate-200 text-slate-700 hover:bg-white">
                保存草稿
              </button>
              <button className="h-7 px-2.5 text-[11px] rounded bg-[#0052D9] text-white hover:bg-[#003FA8] flex items-center gap-1">
                <CheckCircle2 size={11} /> 提交
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
