import { flattenTasks, ownerToDepartment, type CaseItem, type TaskNode } from "./data";

export interface CasePerson { name: string; department: string; owner: boolean; taskCount: number; evidenceCount: number; explicit: boolean }
function validPerson(name: string) { return Boolean(name?.trim()) && !["待指派", "待分派", "系统", "—"].includes(name.trim()); }
export function caseParticipants(record: Pick<CaseItem, "owner" | "participants" | "tasks">): CasePerson[] {
  const people = new Map<string, CasePerson>();
  const add = (name: string, department: string, explicit = false) => {
    if (!validPerson(name)) return;
    const normalized = name.trim();
    if (!people.has(normalized)) people.set(normalized, { name: normalized, department: ownerToDepartment[normalized] || department || "—", owner: normalized === record.owner, taskCount: 0, evidenceCount: 0, explicit });
    else if (explicit) people.get(normalized)!.explicit = true;
    return people.get(normalized);
  };
  add(record.owner, ownerToDepartment[record.owner]);
  for (const person of record.participants ?? []) add(person.name, person.department, true);
  for (const { task } of flattenTasks(record.tasks ?? [])) {
    if (!task.code || task.assigneeType === "skill" || ["已拒绝", "已中止"].includes(task.status)) continue;
    const person = add(task.owner, task.department);
    if (person) { person.taskCount++; if (task.conclusion?.trim() || task.analysisProcess?.trim() || task.resultAttachments?.length) person.evidenceCount++; }
  }
  return [...people.values()];
}
export function coreCaseParticipants(record: Pick<CaseItem, "owner" | "participants" | "tasks">) {
  const candidates = caseParticipants(record).filter(person => !person.owner);
  const departmentTasks = new Map<string, number>();
  for (const person of candidates) departmentTasks.set(person.department, (departmentTasks.get(person.department) ?? 0) + person.taskCount);
  const order = new Map(candidates.map((person, index) => [person.name, index]));
  const sorted = [...candidates].sort((left, right) => right.taskCount - left.taskCount || right.evidenceCount - left.evidenceCount || (departmentTasks.get(right.department) ?? 0) - (departmentTasks.get(left.department) ?? 0) || order.get(left.name)! - order.get(right.name)! || left.name.localeCompare(right.name, "zh-CN"));
  const first = sorted[0];
  const second = first && (sorted.find(person => person.name !== first.name && person.department !== first.department && person.department !== "—" && person.taskCount > 0) ?? sorted.find(person => person.name !== first.name));
  return { selected: [first, second].filter((person): person is CasePerson => Boolean(person)), total: candidates.length };
}