import type { CaseItem, TaskNode, Urgency } from "./data";

const CASE_CODE = "EA-260813000015";

function task(
  sequence: number,
  title: string,
  owner: string,
  department: string,
  urgency: Urgency,
  status: TaskNode["status"],
  progress: number,
  dueDate: string,
  dueIn: number,
  acceptedAt: string,
  startedAt?: string,
  completedAt?: string,
  children?: TaskNode[],
): TaskNode {
  return {
    id: `complex-task-${sequence}`,
    code: `${CASE_CODE}.${String(sequence).padStart(3, "0")}`,
    title,
    owner,
    department,
    urgency,
    progress,
    status,
    dueDate,
    dueIn,
    type: sequence % 3 === 0 ? "测试代码分析" : sequence % 2 === 0 ? "测试程式分析" : "FSA分析",
    statusHistory: [
      { status: "待接受", at: acceptedAt, by: "张伟" },
      ...(startedAt ? [{ status: "进行中" as const, at: startedAt, by: owner }] : []),
      ...(completedAt ? [{ status: "已完成" as const, at: completedAt, by: owner }] : []),
    ],
    children,
  };
}

function thought(id: string, title: string, department: string, urgency: Urgency, children: TaskNode[]): TaskNode {
  return {
    id,
    title,
    owner: "待指派",
    department,
    urgency,
    progress: 0,
    status: "待接受",
    children,
  };
}

const voltageTemperatureCoupling = thought(
  "complex-thought-1-1-1",
  "电压与温度耦合放大边缘失效",
  "PTE",
  "紧急",
  [
    task(5, "低压 × 高温二维 Shmoo 扫描", "刘洋", "PTE", "紧急", "待接受", 0, "2026-08-20", 7, "2026-08-11 15:00"),
    task(6, "Corner lot 补充样品验证", "赵敏", "FT", "一般", "待接受", 0, "2026-08-22", 9, "2026-08-12 10:20"),
  ],
);

const highTemperatureWindow = thought(
  "complex-thought-1-1",
  "高温窗口触发 Pattern margin 收窄",
  "PTE",
  "非常紧急",
  [
    task(3, "85°C Pattern A/B 对照复测", "刘洋", "PTE", "紧急", "已完成", 100, "2026-08-08", 0, "2026-08-03 09:10", "2026-08-04 08:30", "2026-08-08 18:10"),
    task(4, "125°C 全 Pattern 集回归", "刘洋", "PTE", "非常紧急", "进行中", 65, "2026-08-17", 4, "2026-08-06 09:00", "2026-08-07 10:20", undefined, [voltageTemperatureCoupling]),
  ],
);

const waferEdgeMechanism = thought(
  "complex-thought-2-1",
  "Wafer edge 工艺偏移与测试边界叠加",
  "DA",
  "紧急",
  [
    task(10, "Edge/Center die 截面差异分析", "陈磊", "EFA", "紧急", "进行中", 45, "2026-08-18", 5, "2026-08-08 13:30", "2026-08-09 09:20"),
    task(11, "氧化层厚度与 Vth 相关性拟合", "李娜", "DA", "一般", "待接受", 0, "2026-08-21", 8, "2026-08-10 16:10"),
  ],
);

const customerPlatformDifference = thought(
  "complex-thought-3-1-1",
  "客户 BIOS 训练参数放大时序差异",
  "PTE",
  "一般",
  [
    task(15, "BIOS 训练参数逐项回退实验", "周杰", "PTE", "一般", "待接受", 0, "2026-08-23", 10, "2026-08-12 11:40"),
  ],
);

const systemCompatibility = thought(
  "complex-thought-3-1",
  "系统平台训练窗口与量产条件不一致",
  "FT",
  "紧急",
  [
    task(14, "客户平台与内部 SLT 平台交叉验证", "赵敏", "FT", "紧急", "进行中", 50, "2026-08-19", 6, "2026-08-09 14:00", "2026-08-10 09:10", undefined, [customerPlatformDifference]),
  ],
);

export const complexHierarchyDemoCase: CaseItem = {
  id: "c-complex-hierarchy-demo",
  code: CASE_CODE,
  name: "DDR5 量产边界失效 · 复杂任务层级演示",
  owner: "张伟",
  createdBy: "王芳",
  participants: [
    { name: "刘洋", department: "PTE" },
    { name: "赵敏", department: "FT" },
    { name: "李娜", department: "DA" },
    { name: "陈磊", department: "EFA" },
    { name: "王芳", department: "CP" },
    { name: "周杰", department: "PTE" },
  ],
  level: "L1",
  urgency: "非常紧急",
  status: "进行中",
  reason: "DDR5 新量产批次在低压、高温与客户平台组合条件下出现间歇性训练失败，需要并行拆解测试、工艺、封装与系统路径。",
  background: "量产前三周内部 CP/FT 数据正常，但客户平台在 85°C、低压及特定 BIOS 训练参数下出现 2.8% 间歇失效。为验证任务视图与甘特图，Case 内建立多层思路与任务嵌套。",
  impact: "涉及 36 个 Lot、约 18 万颗产品，并可能影响两家客户的量产导入窗口。",
  levelReason: "跨 PTE、CP、FT、DA、EFA 多部门并行分析，且影响量产交付，定级 L1。",
  product: "DDR5-X-7200",
  productId: "DDR5-X-7200",
  productIds: ["DDR5-X-7200"],
  material: "Die/IC",
  markCode: "81315",
  density: "24Gb",
  ioType: "x8",
  failStage: "FT",
  customer: "Customer-Z",
  failPlatform: "V93K / Customer Platform",
  failMode: "Training Fail / Margin Loss",
  failRatio: "2.8%",
  failPackage: "FBGA-102",
  ppm: "28000",
  pdId: "PD-2026-0813",
  createdAt: "2026-08-01",
  updatedAt: "2026-08-13 10:30",
  dueDate: "2026-08-24",
  dueIn: 11,
  departments: ["PTE", "CP", "FT", "DA", "EFA"],
  source: "手动",
  aiSummary: {
    progress: "测试程式与工艺路径已完成首轮收敛，系统兼容性和改善验证仍在推进。",
    method: "Pattern 回归、二维 Shmoo、wafer edge 对照、EFA 截面、客户平台交叉验证。",
    conclusion: "当前怀疑为高温低压条件下 Pattern margin 与 wafer edge 工艺偏移叠加。",
    solution: "短期扩大 guardband；中期调整 Pattern timing 并收紧 edge 工艺窗口。",
    risk: "系统平台差异尚未完全排除，改善条件需要完成量产批次验证。",
  },
  tasks: [
    thought("complex-thought-1", "测试程式边界与温度窗口", "PTE", "非常紧急", [
      task(1, "Fail Pattern 与量产版本差异比对", "张伟", "PTE", "非常紧急", "已完成", 100, "2026-08-04", 0, "2026-08-01 10:00", "2026-08-01 14:00", "2026-08-04 17:30"),
      task(2, "低压 Shmoo 基线重建", "张伟", "PTE", "紧急", "进行中", 80, "2026-08-15", 2, "2026-08-02 09:30", "2026-08-03 10:10", undefined, [highTemperatureWindow]),
      task(7, "量产 Pattern guardband 临时方案", "周杰", "PTE", "紧急", "待接受", 0, "2026-08-18", 5, "2026-08-10 09:00"),
    ]),
    thought("complex-thought-2", "晶圆批次与 edge 工艺偏移", "DA", "紧急", [
      task(8, "异常 Lot wafer map 聚类", "李娜", "DA", "紧急", "已完成", 100, "2026-08-07", 0, "2026-08-02 13:20", "2026-08-03 09:00", "2026-08-07 16:40"),
      task(9, "异常批次 WAT 参数回溯", "李娜", "DA", "紧急", "进行中", 70, "2026-08-16", 3, "2026-08-05 10:00", "2026-08-06 09:30", undefined, [waferEdgeMechanism]),
      task(12, "相邻正常 Lot 对照抽样", "王芳", "CP", "一般", "待接受", 0, "2026-08-19", 6, "2026-08-11 09:20"),
    ]),
    thought("complex-thought-3", "封装应力与系统兼容性", "FT", "紧急", [
      task(13, "封装翘曲与温循后 margin 对照", "陈磊", "EFA", "紧急", "进行中", 35, "2026-08-20", 7, "2026-08-07 11:10", "2026-08-08 08:50", undefined, [systemCompatibility]),
      task(16, "替代主板快速复现", "赵敏", "FT", "一般", "已中止", 20, "2026-08-14", 1, "2026-08-05 15:30", "2026-08-06 10:00"),
    ]),
    thought("complex-thought-4", "改善方案与量产验证", "PTE", "一般", [
      task(17, "Guardband 改善样品复测", "张伟", "PTE", "紧急", "待接受", 0, "2026-08-21", 8, "2026-08-12 14:30"),
      task(18, "三个量产 Lot 连续验证与结论归档", "王芳", "CP", "一般", "待接受", 0, "2026-08-24", 11, "2026-08-13 09:00"),
    ]),
  ],
  solutionPath: ["complex-task-1", "complex-task-3", "complex-task-8"],
  timeline: [
    { time: "2026-08-01 09:30", user: "王芳", content: "创建复杂任务层级演示 Case。" },
    { time: "2026-08-08 18:10", user: "刘洋", content: "完成 85°C Pattern A/B 对照复测。" },
    { time: "2026-08-13 10:30", user: "张伟", content: "新增系统兼容性与量产改善验证分支。" },
  ],
};