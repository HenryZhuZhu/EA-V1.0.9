import {
  Building2,
  Bookmark,
  Clock,
  Crown,
  ListChecks,
  CalendarClock,
  CalendarCheck,
  CheckCircle2,
  Sparkles,
  Copy,
  Check,
  NotebookPen,
  ChevronLeft,
  ChevronRight,
  CalendarDays,
  Pencil,
  RotateCcw,
  Trash2,
  X,
  Plus,
  Trophy,
  Activity,
  Zap,
  Users,
  SlidersHorizontal,
  GitMerge,
  GitBranch,
} from "lucide-react";
import { useState } from "react";
import * as Tabs from "@radix-ui/react-tabs";
import {
  mockCases,
  levelColors,
  urgencyBar,
  currentUser,
  ownerToDepartment,
  departmentSupervisors,
  myTasksInCase,
  flattenTasks,
  TaskNode,
  mockProducts,
  type CaseItem,
  productById,
} from "./data";
import { TodoTab } from "./Sidebar";
import { useClosures } from "./closures";
import { useSubscriptions } from "./subscriptions";
import { useIssues } from "./domainStore";
import { StatusBadge } from "./StatusBadge";
import { CaseStatusBadge, caseDisplayStatus } from "./CaseStatusBadge";
import { CaseProductPill } from "./CaseProductPill";
import { CaseMarkCodePill } from "./CaseMarkCodePill";
import { ProgressRing } from "./ProgressRing";
import { useStandaloneTasks } from "./standaloneTasks";
import { MyTaskHub } from "./MyTaskHub";
import { MyCaseWorkbench } from "./MyCaseWorkbench";
import { WorkbenchCaseCard } from "./WorkbenchCaseCard";
import { buildCaseWorkbenchRows } from "./caseWorkbenchModel";
import { loadCaseTaskTree, useCaseTaskRevision } from "./caseTaskTrees";

interface Props {
  tab: TodoTab;
  onOpenCase: (id: string) => void;
  onOpenTask: (caseId: string, taskId: string) => void;
  onOpenStandaloneTask: (taskId: string) => void;
  onOpenIssue?: (id: string) => void;
}

const urgencyHex = (u: string) =>
  u === "非常紧急" ? "#FF3B30" : u === "紧急" ? "#FF9500" : u === "一般" ? "#38BDF8" : "#94A3B8";

// 还剩几天 —— 统一用「我的 Case」的措辞：N 天到期 / 今日到期 / 已逾期 N 天
const dueLabel = (dueIn?: number) =>
  dueIn == null ? "—" : dueIn > 0 ? `${dueIn} 天到期` : dueIn === 0 ? "今日到期" : `已逾期 ${-dueIn} 天`;

const caseProgress = (c: any) => {
  const actions = flattenTasks(c.tasks || []).map((x) => x.task).filter((task) => task.code);
  const base = actions.length ? actions : (c.tasks || []);
  return Math.round(base.reduce((sum: number, task: TaskNode) => sum + (task.progress || 0), 0) / Math.max(base.length, 1));
};

export function MyTodo({ tab, onOpenCase, onOpenTask, onOpenStandaloneTask, onOpenIssue }: Props) {
  const subs = useSubscriptions();
  const standaloneTasks = useStandaloneTasks();

  // —— 各模块数据 ——
  // 我的 Issue 分段（复用我的 Case 管理模式：我牵头 / 我参与 / 我部门 / 我订阅）
  const allIssuesList = useIssues();
  const _me = currentUser.name;
  const affectedOwners = (i: any) => i.affectedProductIds.map((pid: string) => productById(pid)?.owner).filter(Boolean) as string[];
  const isOwnIssue = (i: any) => i.kr === _me || i.requester === _me || i.registeredBy === _me;
  const ownIssues = allIssuesList.filter(isOwnIssue);
  const joinIssues = allIssuesList.filter((i) => !isOwnIssue(i) && (affectedOwners(i).includes(_me) || i.fanouts.some((f: any) => f.targetOwner === _me)));
  const deptIssues = allIssuesList.filter((i) =>
    affectedOwners(i).some((o) => ownerToDepartment[o] === currentUser.department) ||
    i.caseIds.some((cid: string) => mockCases.find((c) => c.id === cid)?.departments?.includes(currentUser.department))
  );
  const subIssues = allIssuesList.filter((i) => subs.isSubscribed(i.id));
  // 最近浏览：按时间窗口过滤（近 7 天 / 近 30 天），再分页展示
  const [recentView, setRecentView] = useState<"case" | "task">("case");
  const [attentionTab, setAttentionTab] = useState<"subscribed" | "recent">("recent");
  const [recentDays, setRecentDays] = useState<7 | 30>(7);
  const [recentPage, setRecentPage] = useState(1);
  const RECENT_PAGE_SIZE = 6;
  const recentSorted = [...mockCases].sort((a, b) => (b.updatedAt || "").localeCompare(a.updatedAt || ""));
  // 时间窗口：以候选集合中最新一条更新时间为基准向前推 N 天（mock 数据时间偏早，锚定数据自身更直观）
  const withinWindow = (list: any[], days: number) => {
    const anchor = (list[0]?.updatedAt || "").slice(0, 10);
    if (!anchor) return list;
    const cut = new Date(anchor + "T00:00:00");
    cut.setDate(cut.getDate() - days);
    const cutStr = `${cut.getFullYear()}-${String(cut.getMonth() + 1).padStart(2, "0")}-${String(cut.getDate()).padStart(2, "0")}`;
    return list.filter((c) => (c.updatedAt || "").slice(0, 10) >= cutStr);
  };
  // 按 Case：最近浏览过的 Case
  const recentFiltered = withinWindow(recentSorted, recentDays);
  // 按任务：最近浏览过的执行任务 —— 仅取含执行任务的 Case，按其自身时间窗口锚定，避免列表为空
  const taskCasesSorted = recentSorted.filter((c) => flattenTasks(c.tasks).some((x) => !!x.task.code));
  const recentTaskAll: TaskItem[] = withinWindow(taskCasesSorted, recentDays)
    .flatMap((c) => flattenTasks(c.tasks).map((x) => ({ c, task: x.task, depth: x.depth, path: x.path })))
    .filter((x) => !!x.task.code);
  // 分页：按当前视图取当前页（页码越界时夹紧）
  const recentTotal = recentView === "case" ? recentFiltered.length : recentTaskAll.length;
  const recentPages = Math.max(1, Math.ceil(recentTotal / RECENT_PAGE_SIZE));
  const recentPageSafe = Math.min(recentPage, recentPages);
  const recentSlice = <T,>(arr: T[]) => arr.slice((recentPageSafe - 1) * RECENT_PAGE_SIZE, recentPageSafe * RECENT_PAGE_SIZE);
  const recentCases = recentSlice(recentFiltered);
  const recentTaskItems = recentSlice(recentTaskAll);

  if (tab === "task") {
    return <MyTaskHub cases={mockCases} tasks={standaloneTasks} onOpenTask={onOpenTask} onOpenCase={onOpenCase} onOpenStandaloneTask={onOpenStandaloneTask} />;
  }

  if (tab === "own" || tab === "dept") {
    return <MyCaseWorkbench key={tab} cases={mockCases} onOpenCase={onOpenCase} />;
  }

  return (
    <div className="relative">
      <div className="relative p-8 max-w-[1400px] mx-auto">
        {/* 内容（副导航已上移到主侧栏二级导航） */}
        <div className="mt-6 space-y-5">
          {/* —— 我的 Issue（复用「我的 Case」分段管理：我牵头/我参与/我部门/我订阅）—— */}
          {tab === "issue" && (
            <MyIssuePanel ownIssues={ownIssues} joinIssues={joinIssues} deptIssues={deptIssues} subIssues={subIssues} onOpenIssue={onOpenIssue} />
          )}

          {/* —— 最近浏览 —— */}
          {(tab === "recent" || tab === "sub") && (
            <Tabs.Root value={attentionTab} onValueChange={value => { if (value === "subscribed" || value === "recent") setAttentionTab(value); }} className="space-y-5">
              <header className="flex items-center justify-between gap-4"><h1 className="text-xl font-semibold text-slate-900">我的关注</h1><Tabs.List aria-label="关注内容" className="inline-flex gap-1 rounded-lg bg-slate-100 p-1"><Tabs.Trigger value="recent" className="h-8 rounded-md px-4 text-xs text-slate-500 data-[state=active]:bg-white data-[state=active]:text-[#0052D9]">最近浏览</Tabs.Trigger><Tabs.Trigger value="subscribed" className="h-8 rounded-md px-4 text-xs text-slate-500 data-[state=active]:bg-white data-[state=active]:text-[#0052D9]">我的订阅</Tabs.Trigger></Tabs.List></header>
              <Tabs.Content value="subscribed"><SubscribedCases cases={mockCases.filter(item => subs.isSubscribed(item.id))} onOpenCase={onOpenCase} /></Tabs.Content>
              <Tabs.Content value="recent" className="space-y-5">
              <div className="flex items-center gap-3">
                <SectionHead
                  icon={Clock}
                  tone="from-slate-400 to-slate-500"
                  title="最近浏览"
                  sub={recentView === "case" ? `你最近打开过的 Case · 共 ${recentFiltered.length} 个` : `你最近查看过的任务 · 共 ${recentTaskAll.length} 个`}
                />
                <div className="flex-1" />
                {/* 时间窗口：近 7 天 / 近 30 天 */}
                <span className="text-xs text-slate-400">时间</span>
                <div className="inline-flex bg-slate-100 border border-slate-200 rounded-lg p-0.5">
                  {([[7, "近 7 天"], [30, "近 30 天"]] as const).map(([n, lab]) => (
                    <button
                      key={n}
                      onClick={() => { setRecentDays(n); setRecentPage(1); }}
                      className={`text-[12.5px] px-3 py-1.5 rounded-md transition-all ${recentDays === n ? "bg-white text-slate-800 font-semibold shadow-sm" : "text-slate-500 hover:text-slate-700"}`}
                    >
                      {lab}
                    </button>
                  ))}
                </div>
                <span className="w-px h-5 bg-slate-200" />
                <span className="text-xs text-slate-400">视图</span>
                <div className="inline-flex bg-slate-100 border border-slate-200 rounded-lg p-0.5">
                  {([["task", "按任务"], ["case", "按 Case"]] as const).map(([key, lab]) => (
                    <button
                      key={key}
                      onClick={() => { setRecentView(key); setRecentPage(1); }}
                      className={`text-[12.5px] px-3 py-1.5 rounded-md transition-all ${recentView === key ? "bg-white text-slate-800 font-semibold shadow-sm" : "text-slate-500 hover:text-slate-700"}`}
                    >
                      {lab}
                    </button>
                  ))}
                </div>
              </div>
              {recentView === "case" ? (
                recentCases.length ? (
                  <CaseGrid cases={recentCases} onOpenCase={onOpenCase} empty="暂无浏览记录" />
                ) : (
                  <EmptyState text="该时间范围内暂无浏览记录" hint="切换到「近 30 天」试试" />
                )
              ) : recentTaskItems.length ? (
                <div className="space-y-2">
                  {recentTaskItems.map((x) => (
                    <TaskRow key={x.task.id} x={x} onOpenCase={onOpenCase} onOpenTask={onOpenTask} showDept />
                  ))}
                </div>
              ) : (
                <EmptyState text="该时间范围内暂无浏览记录" hint="切换到「近 30 天」试试" />
              )}
              {/* 分页 */}
              {recentTotal > RECENT_PAGE_SIZE && (
                <div className="flex items-center justify-end gap-3 pt-1">
                  <span className="text-xs text-slate-400">
                    第 {(recentPageSafe - 1) * RECENT_PAGE_SIZE + 1}–{Math.min(recentPageSafe * RECENT_PAGE_SIZE, recentTotal)} 条 · 共 {recentTotal} 条
                  </span>
                  <div className="inline-flex items-center bg-white border border-slate-200 rounded-lg overflow-hidden">
                    <button
                      onClick={() => setRecentPage((p) => Math.max(1, p - 1))}
                      disabled={recentPageSafe <= 1}
                      className="w-8 h-8 grid place-items-center text-slate-500 hover:bg-slate-50 hover:text-[#0052D9] disabled:opacity-30 disabled:hover:bg-transparent disabled:cursor-not-allowed transition-colors"
                    >
                      <ChevronLeft size={15} />
                    </button>
                    <div className="px-1 flex items-center gap-0.5 border-x border-slate-200">
                      {Array.from({ length: recentPages }, (_, i) => i + 1).map((p) => (
                        <button
                          key={p}
                          onClick={() => setRecentPage(p)}
                          className={`min-w-[26px] h-8 px-1.5 text-[12.5px] rounded-md transition-colors ${p === recentPageSafe ? "bg-[#0052D9]/8 text-[#0052D9] font-semibold" : "text-slate-500 hover:bg-slate-50"}`}
                        >
                          {p}
                        </button>
                      ))}
                    </div>
                    <button
                      onClick={() => setRecentPage((p) => Math.min(recentPages, p + 1))}
                      disabled={recentPageSafe >= recentPages}
                      className="w-8 h-8 grid place-items-center text-slate-500 hover:bg-slate-50 hover:text-[#0052D9] disabled:opacity-30 disabled:hover:bg-transparent disabled:cursor-not-allowed transition-colors"
                    >
                      <ChevronRight size={15} />
                    </button>
                  </div>
                </div>
              )}
              </Tabs.Content>
            </Tabs.Root>
          )}

          {/* —— 工作日志 —— */}
          {tab === "log" && <WorkLogPanel />}
        </div>
      </div>
    </div>
  );
}

function SectionHead({ icon: Icon, tone, title, sub }: { icon: any; tone: string; title: string; sub: string }) {
  return (
    <div className="flex items-center gap-2.5">
      <div className={`w-7 h-7 rounded-lg bg-gradient-to-br ${tone} text-white flex items-center justify-center shadow-sm`}>
        <Icon size={14} />
      </div>
      <div>
        <h3 className="text-slate-900">{title}</h3>
        <p className="text-xs text-slate-500 mt-0.5">{sub}</p>
      </div>
    </div>
  );
}

function SubscribedCases({ cases, onOpenCase }: { cases: CaseItem[]; onOpenCase: (id: string) => void }) {
  const closures = useClosures();
  useCaseTaskRevision();
  const [page, setPage] = useState(1);
  const rows = buildCaseWorkbenchRows(cases, { products: mockProducts, closure: closures.get, isSubscribed: () => true, loadTree: item => loadCaseTaskTree(item.id, item.tasks) });
  const pages = Math.max(1, Math.ceil(rows.length / 8));
  const currentPage = Math.min(page, pages);
  if (!rows.length) return <EmptyState text="暂无订阅的 Case" hint="" />;
  return <div className="space-y-4"><section aria-label="订阅 Case 列表" className="grid grid-cols-2 gap-4">{rows.slice((currentPage - 1) * 8, currentPage * 8).map(row => <WorkbenchCaseCard key={row.id} row={row} onOpenCase={onOpenCase} />)}</section>
    <div className="flex items-center justify-end gap-3 text-xs text-slate-500"><span>共 {rows.length} 个 Case</span><button type="button" aria-label="上一页订阅" disabled={currentPage === 1} onClick={() => setPage(currentPage - 1)} className="grid h-8 w-8 place-items-center rounded border border-slate-200 bg-white disabled:opacity-30"><ChevronLeft size={14} /></button><span>{currentPage} / {pages}</span><button type="button" aria-label="下一页订阅" disabled={currentPage === pages} onClick={() => setPage(currentPage + 1)} className="grid h-8 w-8 place-items-center rounded border border-slate-200 bg-white disabled:opacity-30"><ChevronRight size={14} /></button></div>
  </div>;
}

function CaseGrid({ cases, onOpenCase, empty, showStatus }: { cases: any[]; onOpenCase: (id: string) => void; empty: string; showStatus?: boolean }) {
  const closures = useClosures();
  if (cases.length === 0) return <EmptyState text={empty} hint="去分析中心浏览全部 Case" />;
  const isClosed = (c: any) => closures.isClosed(c.id) || c.status === "已关闭" || c.status === "已结案" || c.status === "已归档";
  return (
    <div className="grid grid-cols-2 gap-4">
      {cases.map((c) => (
        <button
          key={c.id}
          onClick={() => onOpenCase(c.id)}
          className="group relative text-left bg-white rounded-xl p-5 border border-slate-200/80 hover:border-[#0052D9]/40 hover:shadow-[0_8px_24px_-12px_rgba(0,82,217,0.25)] transition-all overflow-hidden"
        >
          <div className="absolute left-0 top-5 bottom-5 w-1 rounded-r" style={{ background: urgencyHex(c.urgency) }} />
          <div className="flex items-center gap-2 mb-3">
            <div className={`px-1.5 py-0.5 rounded text-[10px] border ${levelColors[c.level]}`}>{c.level}</div>
            <CaseProductPill caseItem={c} compact />
            <CaseMarkCodePill caseItem={c} compact />
            {(!!c.fanoutSourceCaseId || c.source === "fanout验证") && (
              <span title="Fanout 派生 Case" className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium bg-[#00A4FF]/10 text-[#0284c7] border border-[#00A4FF]/25">Fanout</span>
            )}
            {showStatus ? (
              <CaseStatusBadge status={caseDisplayStatus(c, { closed: isClosed(c), rootCaused: closures.isRootCaused(c.id) })} />
            ) : (
              <span className="text-[11px] text-slate-500">{c.urgency}</span>
            )}
            <span className="text-[11px] text-slate-400 font-mono ml-auto tracking-wide">{c.code}</span>
          </div>
          <div className="text-[15px] text-slate-900 leading-snug line-clamp-1 group-hover:text-[#0052D9] transition-colors">{c.name}</div>
          <div className="text-xs text-slate-500 mt-1.5 line-clamp-2 leading-relaxed">{c.reason || c.background || "—"}</div>
          <div className="mt-4 pt-3 border-t border-dashed border-slate-200 flex items-center text-[11px] text-slate-500 gap-4">
            <span className="flex items-center gap-1"><Crown size={11} /> {c.owner}</span>
            <span className="flex items-center gap-1"><ListChecks size={11} /> {c.tasks?.length ?? 0} 任务</span>
            <span className="flex items-center gap-1 ml-auto">{isClosed(c) ? <><CalendarCheck size={11} /> 结案 {(c.updatedAt || "").slice(0, 10)}</> : <><CalendarClock size={11} /> {dueLabel(c.dueIn)}</>}</span>
          </div>
        </button>
      ))}
    </div>
  );
}

// 我的 Issue：复用「我的 Case」的分段管理（我牵头 / 我参与 / 我部门 / 我订阅）
function MyIssuePanel({ ownIssues, joinIssues, deptIssues, subIssues, onOpenIssue }: {
  ownIssues: any[]; joinIssues: any[]; deptIssues: any[]; subIssues: any[]; onOpenIssue?: (id: string) => void;
}) {
  type Seg = "own" | "join" | "dept" | "sub";
  const [seg, setSeg] = useState<Seg>("own");
  const [page, setPage] = useState(1);
  const SIZE = 8;
  const META: Record<Seg, { label: string; icon: any; tone: string; issues: any[]; empty: string; desc: string }> = {
    own: { label: "我牵头", icon: Crown, tone: "text-amber-500", issues: ownIssues, empty: "你还没有牵头的 Issue", desc: "我作为负责 KR / 创建者的 Issue" },
    join: { label: "我参与", icon: Users, tone: "text-teal-500", issues: joinIssues, empty: "你尚未参与任何 Issue", desc: "我负责的产品被 Issue 影响 / Fanout 指派" },
    dept: { label: "我部门", icon: Building2, tone: "text-sky-500", issues: deptIssues, empty: "本部门暂无相关 Issue", desc: "我所在部门相关的 Issue" },
    sub: { label: "我订阅", icon: Bookmark, tone: "text-violet-500", issues: subIssues, empty: "你还没有订阅任何 Issue", desc: "我订阅的 Issue" },
  };
  const m = META[seg];
  const total = m.issues.length;
  const pages = Math.max(1, Math.ceil(total / SIZE));
  const pageSafe = Math.min(page, pages);
  const pageIssues = m.issues.slice((pageSafe - 1) * SIZE, pageSafe * SIZE);
  return (
    <>
      <div className="flex items-end justify-between gap-4 border-b border-slate-200">
        <div className="flex items-center gap-2.5 pb-3">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#7A3DFF] to-[#00A4FF] text-white flex items-center justify-center shadow-sm">
            <GitMerge size={15} />
          </div>
          <div>
            <h3 className="text-slate-900 leading-tight font-semibold">我的 Issue</h3>
            <p className="text-xs text-slate-500 mt-0.5">{m.desc}</p>
          </div>
        </div>
        <div className="flex gap-1">
          {(Object.keys(META) as Seg[]).map((k) => {
            const Icon = META[k].icon;
            const on = seg === k;
            return (
              <button
                key={k}
                onClick={() => { setSeg(k); setPage(1); }}
                className={`relative text-[13.5px] px-4 py-2.5 inline-flex items-center gap-1.5 font-medium transition-colors ${on ? "text-[#0052D9]" : "text-slate-500 hover:text-slate-700"}`}
              >
                <Icon size={14} className={on ? "text-[#0052D9]" : `${META[k].tone} opacity-70`} />
                {META[k].label}
                <span className={`tabular-nums text-[11px] rounded-full px-1.5 leading-[16px] ${on ? "bg-[#0052D9]/10 text-[#0052D9]" : "bg-slate-100 text-slate-400"}`}>{META[k].issues.length}</span>
                {on && <span className="absolute left-3 right-3 -bottom-px h-[2.5px] bg-[#0052D9] rounded" />}
              </button>
            );
          })}
        </div>
      </div>
      <div className="mt-4" />
      {pageIssues.length ? (
        <div className="grid grid-cols-2 gap-3">
          {pageIssues.map((iss) => <IssueCardMini key={iss.id} iss={iss} onOpenIssue={onOpenIssue} />)}
        </div>
      ) : (
        <EmptyState text={m.empty} hint="切换其它分组看看" />
      )}
      {total > SIZE && (
        <div className="flex items-center justify-end gap-3 pt-3">
          <span className="text-xs text-slate-400">
            第 {(pageSafe - 1) * SIZE + 1}–{Math.min(pageSafe * SIZE, total)} 个 · 共 {total} 个
          </span>
          <div className="inline-flex items-center bg-white border border-slate-200 rounded-lg overflow-hidden">
            <button onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={pageSafe <= 1}
              className="w-8 h-8 grid place-items-center text-slate-500 hover:bg-slate-50 hover:text-[#0052D9] disabled:opacity-30 disabled:cursor-not-allowed transition-colors">
              <ChevronLeft size={15} />
            </button>
            <div className="px-1 flex items-center gap-0.5 border-x border-slate-200">
              {Array.from({ length: pages }, (_, i) => i + 1).map((p) => (
                <button key={p} onClick={() => setPage(p)}
                  className={`min-w-[26px] h-8 px-1.5 text-[12.5px] rounded-md transition-colors ${p === pageSafe ? "bg-[#0052D9]/8 text-[#0052D9] font-semibold" : "text-slate-500 hover:bg-slate-50"}`}>
                  {p}
                </button>
              ))}
            </div>
            <button onClick={() => setPage((p) => Math.min(pages, p + 1))} disabled={pageSafe >= pages}
              className="w-8 h-8 grid place-items-center text-slate-500 hover:bg-slate-50 hover:text-[#0052D9] disabled:opacity-30 disabled:cursor-not-allowed transition-colors">
              <ChevronRight size={15} />
            </button>
          </div>
        </div>
      )}
    </>
  );
}

function IssueCardMini({ iss, onOpenIssue }: { iss: any; onOpenIssue?: (id: string) => void }) {
  const codes = iss.affectedProductIds.map((pid: string) => productById(pid)?.code).filter(Boolean) as string[];
  return (
    <button onClick={() => onOpenIssue?.(iss.id)}
      className="group text-left rounded-xl border border-slate-200/80 bg-white p-4 hover:border-[#7A3DFF]/40 hover:shadow-[0_8px_24px_-12px_rgba(122,61,255,0.25)] transition-all">
      <div className="flex items-center gap-2">
        <span className="font-mono text-[11px] text-slate-400 tracking-wide">{iss.code}</span>
        <span className="ml-auto text-[11px] px-1.5 py-0.5 rounded bg-slate-50 text-slate-500 border border-slate-200">{iss.status}</span>
      </div>
      <div className="text-[15px] text-slate-900 leading-snug line-clamp-1 mt-1.5 group-hover:text-[#7A3DFF] transition-colors">{iss.name}</div>
      <div className="text-xs text-slate-500 mt-1.5 line-clamp-2 leading-relaxed">{iss.desc || "—"}</div>
      <div className="mt-3 pt-3 border-t border-dashed border-slate-200 flex items-center gap-1.5 flex-wrap">
        {codes.length ? codes.map((code) => <span key={code} className="text-[11px] px-1.5 py-0.5 rounded bg-[#0052D9]/8 text-[#0052D9] border border-[#0052D9]/25">{code}</span>)
          : <span className="text-[11px] text-slate-400">暂无受影响产品</span>}
        <span className="ml-auto text-[11px] text-slate-400 inline-flex items-center gap-1"><ListChecks size={11} /> {iss.caseIds.length} Case</span>
      </div>
    </button>
  );
}

function EmptyState({ text, hint }: { text: string; hint: string }) {
  return (
    <div className="py-16 text-center bg-white border border-dashed border-slate-200 rounded-xl">
      <div className="w-12 h-12 mx-auto rounded-full bg-slate-50 border border-slate-100 flex items-center justify-center">
        <CheckCircle2 size={20} className="text-emerald-500" />
      </div>
      <div className="mt-3 text-sm text-slate-600">{text}</div>
      <div className="text-xs text-slate-400 mt-1">{hint}</div>
    </div>
  );
}

// 工作日志：日报 / 周报 / 月报 / 年报（默认样式，展现形式待从 30 版方案中选定后再细化）
function WorkLogPanel() {
  const [period, setPeriod] = useState<"day" | "week" | "month" | "year">("day");
  const [anchor, setAnchor] = useState<Date>(() => new Date("2026-06-22T00:00:00"));
  const [copied, setCopied] = useState(false);
  const [editing, setEditing] = useState(false);
  type Doc = { summary: string; sections: { k: string; items: string[] }[] };
  const [edits, setEdits] = useState<Record<string, Doc>>({});
  // 一键生成：记录每个周期/日期最近一次生成时间；定时任务每日 20:00 自动生成
  const [genAt, setGenAt] = useState<Record<string, string>>({});
  const [generating, setGenerating] = useState(false);
  const today = new Date("2026-06-22T00:00:00");
  const META: Record<string, { label: string; date: string; summary: string; sections: { k: string; items: string[] }[] }> = {
    day: {
      label: "日报", date: "2026-06-22",
      summary: "今日聚焦「DDR4 Lot 退货影响分析」，完成 8D D4 根因复盘，推进 2 项验证任务。",
      sections: [
        { k: "高光时刻", items: ["攻克 DDR4 退货 8D D4 根因，锁定 PKG 内引线偏移", "OM/SEM 形貌确认一次通过，省去一轮复测"] },
        { k: "今日完成", items: ["8D 围堵措施 D4 根因复盘", "退货样品 OM/SEM 形貌确认"] },
        { k: "进行中", items: ["输出 Pattern P_ICC2_07 调整方案评审稿（待接受）"] },
        { k: "明日计划", items: ["对齐 EFA 切片排程", "补齐 bin 统计数据"] },
        { k: "风险 / 阻塞", items: ["复测设备档期紧张，可能影响验证节奏"] },
      ],
    },
    week: {
      label: "周报", date: "2026-06-16 ~ 06-22",
      summary: "本周关闭 3 个 Case，DDR5 X-die CP1 yield drop 定位根因并提交改善方案。",
      sections: [
        { k: "本周高光", items: ["关闭 3 个 Case（含 1 个 L0）", "CP1 yield drop 根因定位并提交改善方案"] },
        { k: "本周成果", items: ["关闭 Case ×3", "CP1 yield drop 根因定位 + 改善方案提交"] },
        { k: "进行中", items: ["封装空洞率超标分析（验证阶段）", "LPDDR5 FT Retest Rate 偏高"] },
        { k: "下周计划", items: ["推进封装空洞 X-ray 抽检", "复盘退货批次 8D 闭环"] },
        { k: "风险 / 阻塞", items: ["跨部门数据回传延迟"] },
      ],
    },
    month: {
      label: "月报", date: "2026 年 6 月",
      summary: "本月主导 5 个失效调查，平均关闭周期较上月下降 18%。",
      sections: [
        { k: "本月高光", items: ["主导 5 个失效调查、关闭 4 个", "平均关闭周期较上月 ↓18%"] },
        { k: "关键成果", items: ["主导失效调查 ×5，关闭 ×4", "平均关闭周期 ↓18%"] },
        { k: "进行中", items: ["2 个 L1 Case 进入验证 / 改善阶段"] },
        { k: "下月计划", items: ["沉淀 DDR4 退货分析 SOP", "推动 SPC 自动建案覆盖率提升"] },
        { k: "风险 / 阻塞", items: ["EFA 资源排期偏紧"] },
      ],
    },
    year: {
      label: "年报", date: "2026 年",
      summary: "全年累计参与 62 个 Case，牵头 21 个，L0/L1 占比 35%，闭环率 92%。",
      sections: [
        { k: "年度高光", items: ["全年参与 62 个 Case、牵头 21 个", "闭环率 92%，L0/L1 占比 35%"] },
        { k: "全年概览", items: ["参与 Case ×62，牵头 ×21", "L0/L1 占比 35%，闭环率 92%"] },
        { k: "代表性工作", items: ["DDR5 X-die yield drop 专项", "退货失效分析体系化"] },
        { k: "明年规划", items: ["失效知识库建设", "缩短 L0 平均响应时长"] },
        { k: "待改进", items: ["跨部门协同效率"] },
      ],
    },
  };
  const m = META[period];

  // —— 日期选择：按当前周期（日/周/月/年）解析展示与翻页 ——
  const pad = (n: number) => String(n).padStart(2, "0");
  const iso = (d: Date) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const WD = ["日", "一", "二", "三", "四", "五", "六"];
  const weekStart = (d: Date) => { const x = new Date(d); x.setDate(d.getDate() - ((d.getDay() + 6) % 7)); return x; };
  const weekEnd = (d: Date) => { const s = weekStart(d); const e = new Date(s); e.setDate(s.getDate() + 6); return e; };

  const dateLabel =
    period === "day" ? `${iso(anchor)} · 周${WD[anchor.getDay()]}`
    : period === "week" ? `${iso(weekStart(anchor))} ~ ${iso(weekEnd(anchor))}`
    : period === "month" ? `${anchor.getFullYear()} 年 ${anchor.getMonth() + 1} 月`
    : `${anchor.getFullYear()} 年`;

  const step = (delta: number) => {
    const n = new Date(anchor);
    if (period === "day") n.setDate(anchor.getDate() + delta);
    else if (period === "week") n.setDate(anchor.getDate() + delta * 7);
    else if (period === "month") n.setMonth(anchor.getMonth() + delta);
    else n.setFullYear(anchor.getFullYear() + delta);
    setAnchor(n);
  };
  // 不允许查看「今天 / 本周期」之后的报告
  const atOrAfterToday =
    period === "day" ? iso(anchor) >= iso(today)
    : period === "week" ? iso(weekStart(anchor)) >= iso(weekStart(today))
    : period === "month" ? anchor.getFullYear() * 12 + anchor.getMonth() >= today.getFullYear() * 12 + today.getMonth()
    : anchor.getFullYear() >= today.getFullYear();
  const isToday =
    period === "day" ? iso(anchor) === iso(today)
    : period === "week" ? iso(weekStart(anchor)) === iso(weekStart(today))
    : period === "month" ? anchor.getFullYear() === today.getFullYear() && anchor.getMonth() === today.getMonth()
    : anchor.getFullYear() === today.getFullYear();

  // —— 可编辑内容：按「周期 + 所选日期」存储编辑副本，未编辑则用模板 ——
  const docKey =
    period === "day" ? `day:${iso(anchor)}`
    : period === "week" ? `week:${iso(weekStart(anchor))}`
    : period === "month" ? `month:${anchor.getFullYear()}-${anchor.getMonth() + 1}`
    : `year:${anchor.getFullYear()}`;
  const baseDoc = (): Doc => ({ summary: m.summary, sections: m.sections.map((s) => ({ k: s.k, items: [...s.items] })) });
  const doc: Doc = edits[docKey] ?? baseDoc();
  const isEdited = !!edits[docKey];

  const mutate = (fn: (d: Doc) => void) => {
    setEdits((prev) => {
      const cur = prev[docKey] ?? baseDoc();
      const next: Doc = { summary: cur.summary, sections: cur.sections.map((s) => ({ k: s.k, items: [...s.items] })) };
      fn(next);
      return { ...prev, [docKey]: next };
    });
  };
  const setSummary = (v: string) => mutate((d) => { d.summary = v; });
  const setHead = (i: number, v: string) => mutate((d) => { d.sections[i].k = v; });
  const setItem = (i: number, j: number, v: string) => mutate((d) => { d.sections[i].items[j] = v; });
  const addItem = (i: number) => mutate((d) => { d.sections[i].items.push(""); });
  const removeItem = (i: number, j: number) => mutate((d) => { d.sections[i].items.splice(j, 1); });
  const addSection = () => mutate((d) => { d.sections.push({ k: "新板块", items: [""] }); });
  const removeSection = (i: number) => mutate((d) => { d.sections.splice(i, 1); });
  const resetDoc = () => setEdits((prev) => { const n = { ...prev }; delete n[docKey]; return n; });
  // 一键生成：拉取最新系统汇总（清掉本周期手动编辑），并记录生成时间
  const regenerate = () => {
    setGenerating(true);
    setEditing(false);
    setTimeout(() => {
      resetDoc();
      const d = new Date();
      const stamp = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
      setGenAt((p) => ({ ...p, [docKey]: stamp }));
      setGenerating(false);
    }, 850);
  };

  // —— 右侧内容模块：基于「我的任务」派生「高光时刻 / 动态」，填充原本空置的右侧空间 ——
  const mineAll = mockCases.flatMap((c) => myTasksInCase(c, currentUser.name).map((x) => ({ c, ...x })));
  const doneT = mineAll.filter((x) => x.task.status === "已完成");
  const doingT = mineAll.filter((x) => x.task.status === "进行中");
  const acceptT = mineAll.filter((x) => x.task.status === "待接受");
  const ownedC = mockCases.filter((c) => c.owner === currentUser.name);
  const keyOwned = ownedC.find((c) => c.level === "L0") || ownedC.find((c) => c.level === "L1") || ownedC[0];
  const periodWord = period === "day" ? "今日" : period === "week" ? "本周" : period === "month" ? "本月" : "今年";

  // 日报专属：汇总每日 Case update。
  const relevantCases = Array.from(new Map<string, typeof mockCases[number]>(
    [...ownedC, ...mineAll.map((x) => x.c), ...mockCases]
      .sort((a, b) => (b.updatedAt || "").localeCompare(a.updatedAt || ""))
      .map((c) => [c.id, c] as const)
  ).values());
  const dailyCaseUpdates = relevantCases.slice(0, 4).map((c) => ({
    c,
    update: [...(c.timeline || [])].reverse().find((x) => x.content)?.content || c.aiSummary?.progress || "暂无新增说明",
  }));

  const digestPlain = period === "day"
    ? `\n每日 Case Update：\n${dailyCaseUpdates.map(({ c, update }) => `- ${c.code} ${c.name}：${update}`).join("\n")}`
    : "";
  const plain = `工作${m.label}（${dateLabel}）\n${doc.summary}${digestPlain}\n` + doc.sections.map((s) => `${s.k}：${s.items.filter(Boolean).join("；")}`).join("\n");
  const copy = () => {
    navigator.clipboard?.writeText(plain).then(() => { setCopied(true); setTimeout(() => setCopied(false), 2000); });
  };

  type Tone = "emerald" | "amber" | "violet" | "blue" | "teal";
  const TONE: Record<Tone, string> = {
    emerald: "bg-emerald-50 text-emerald-600",
    amber: "bg-amber-50 text-amber-600",
    violet: "bg-violet-50 text-violet-600",
    blue: "bg-[#0052D9]/8 text-[#0052D9]",
    teal: "bg-teal-50 text-teal-600",
  };
  const DOT: Record<Tone, string> = { emerald: "#16a34a", amber: "#d97706", violet: "#7c3aed", blue: "#0052D9", teal: "#0D9488" };

  const highlights: { icon: any; tone: Tone; text: string; meta: string }[] = [];
  if (doneT.length) highlights.push({ icon: CheckCircle2, tone: "emerald", text: `${periodWord}已完成 ${doneT.length} 项任务`, meta: "保持高效推进" });
  if (doneT[0]) highlights.push({ icon: Trophy, tone: "amber", text: `攻克「${doneT[0].task.title}」`, meta: `完成于 ${completedDate(doneT[0].task)}` });
  if (keyOwned) highlights.push({ icon: Crown, tone: "violet", text: `牵头 ${keyOwned.level} Case「${keyOwned.name}」`, meta: "作为 Case Owner 持续跟进" });
  if (doingT[0]) highlights.push({ icon: Zap, tone: "blue", text: `主导「${doingT[0].task.title}」`, meta: "进行中 · 按节奏推进" });

  const feedEvents: { act: string; tone: Tone; title: string }[] = [];
  doneT.slice(0, 2).forEach((x) => feedEvents.push({ act: "完成", tone: "emerald", title: x.task.title }));
  doingT.slice(0, 1).forEach((x) => feedEvents.push({ act: "推进", tone: "blue", title: x.task.title }));
  acceptT.slice(0, 1).forEach((x) => feedEvents.push({ act: "收到派单", tone: "teal", title: x.task.title }));
  if (keyOwned) feedEvents.push({ act: "更新", tone: "violet", title: `${keyOwned.name} 进展纪要` });
  // 时间标签随周期变化：日报到点、周报到日、月报到日期、年报到月份
  const feedTimes =
    period === "day" ? ["今天 11:02", "今天 09:18", "今天 14:30", "今天 15:46", "昨天 17:20"]
    : period === "week" ? ["周五", "周四", "周三", "周二", "周一"]
    : period === "month" ? ["06-20", "06-18", "06-12", "06-08", "06-03"]
    : ["6 月", "5 月", "4 月", "3 月", "2 月"];
  const feed = feedEvents.map((e, i) => ({ ...e, time: feedTimes[i] ?? feedTimes[feedTimes.length - 1] }));

  return (
    <>
      <div className="flex items-center gap-3 flex-wrap">
        <SectionHead icon={NotebookPen} tone="from-[#0052D9] to-[#7A3DFF]" title="智能汇总" sub="EA 智能汇总你的工作记录与高光时刻 · 每日 20:00 定时自动生成，也可一键刷新" />
        <div className="flex-1" />
        {/* 日期选择：上一/下一个周期 + 直接选日期 + 回到今天 */}
        <div className="inline-flex items-center gap-1.5">
          <div className="inline-flex items-center bg-white border border-slate-200 rounded-lg overflow-hidden">
            <button onClick={() => step(-1)} title="上一个" className="w-8 h-8 grid place-items-center text-slate-500 hover:bg-slate-50 hover:text-[#0052D9] transition-colors">
              <ChevronLeft size={15} />
            </button>
            <label className="relative h-8 px-3 flex items-center gap-1.5 border-x border-slate-200 cursor-pointer hover:bg-slate-50 min-w-[156px] justify-center" title="点击选择日期">
              <CalendarDays size={13} className="text-slate-400 shrink-0" />
              <span className="text-[12.5px] text-slate-700 tabular-nums">{dateLabel}</span>
              <input
                type="date"
                value={iso(anchor)}
                max={iso(today)}
                onChange={(e) => { if (e.target.value) setAnchor(new Date(e.target.value + "T00:00:00")); }}
                className="absolute inset-0 opacity-0 cursor-pointer"
              />
            </label>
            <button onClick={() => step(1)} disabled={atOrAfterToday} title="下一个" className="w-8 h-8 grid place-items-center text-slate-500 hover:bg-slate-50 hover:text-[#0052D9] disabled:opacity-30 disabled:hover:bg-transparent disabled:cursor-not-allowed transition-colors">
              <ChevronRight size={15} />
            </button>
          </div>
          {!isToday && (
            <button onClick={() => setAnchor(new Date(today))} className="h-8 px-2.5 rounded-lg border border-slate-200 text-[12px] text-slate-500 hover:text-[#0052D9] hover:border-[#0052D9]/40 transition-colors">
              回到今天
            </button>
          )}
        </div>
        <div className="inline-flex bg-slate-100 border border-slate-200 rounded-lg p-0.5">
          {(["day", "week", "month", "year"] as const).map((p) => (
            <button
              key={p}
              onClick={() => setPeriod(p)}
              className={`text-[12.5px] px-3 py-1.5 rounded-md transition-all ${period === p ? "bg-white text-slate-800 font-semibold shadow-sm" : "text-slate-500 hover:text-slate-700"}`}
            >
              {META[p].label}
            </button>
          ))}
        </div>
      </div>

      {/* 个人工作汇总：文档 + 动态 */}
      <div className="grid grid-cols-[minmax(0,1fr)_330px] gap-5 items-start">
        {/* 左：经典文档样式（样式 1） */}
        <div className="space-y-3 min-w-0">
          <div className="bg-white border border-slate-200/80 rounded-xl shadow-[0_1px_2px_0_rgba(15,23,42,0.04)] overflow-hidden">
            {/* 文档抬头：标题 + 元信息 + 操作 */}
            <div className="px-7 pt-6 flex items-start justify-between gap-3">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="text-[18px] font-bold text-slate-900 tracking-tight">{currentUser.name} 的工作{m.label}</h3>
                  <span className="text-[10px] text-[#0052D9] bg-[#0052D9]/8 border border-[#0052D9]/20 rounded px-1.5 py-px shrink-0 inline-flex items-center gap-1"><Sparkles size={10} /> EA 智能生成</span>
                  {isEdited && <span className="text-[10px] text-slate-500 bg-slate-100 border border-slate-200 rounded px-1.5 py-px shrink-0">已编辑</span>}
                </div>
                <div className="text-[11.5px] text-slate-400 mt-1.5 pb-3 border-b border-slate-100">{dateLabel} · {currentUser.name} · {currentUser.department} · {genAt[docKey] ? `已于 ${genAt[docKey]} 生成` : "每日 20:00 自动生成"}</div>
              </div>
              <div className="shrink-0 flex items-center gap-1.5">
                <button
                  onClick={regenerate}
                  disabled={generating}
                  title="重新生成最新智能汇总"
                  className={`h-8 px-2.5 rounded-lg text-[12px] font-medium inline-flex items-center gap-1 transition-colors ${generating ? "bg-[#0052D9]/8 text-[#0052D9] cursor-wait" : "bg-gradient-to-r from-[#0052D9] to-[#7A3DFF] text-white hover:shadow-md"}`}
                >
                  <Sparkles size={13} className={generating ? "animate-pulse" : ""} /> {generating ? "生成中…" : "一键生成"}
                </button>
                {editing ? (
                  <>
                    {isEdited && (
                      <button onClick={resetDoc} title="恢复为系统生成内容" className="h-8 px-2.5 rounded-lg border border-slate-200 text-[12px] text-slate-500 hover:text-[#0052D9] hover:border-[#0052D9]/40 transition-colors inline-flex items-center gap-1">
                        <RotateCcw size={13} /> 重置
                      </button>
                    )}
                    <button onClick={() => setEditing(false)} className="h-8 px-3 rounded-lg bg-[#0052D9] text-white text-[12px] font-medium hover:bg-[#003FA8] transition-colors inline-flex items-center gap-1">
                      <Check size={13} /> 完成
                    </button>
                  </>
                ) : (
                  <>
                    <button onClick={() => setEditing(true)} title="编辑日志内容" className="h-8 px-2.5 rounded-lg border border-slate-200 text-[12px] text-slate-600 hover:text-[#0052D9] hover:border-[#0052D9]/40 transition-colors inline-flex items-center gap-1">
                      <Pencil size={13} /> 编辑
                    </button>
                    <button
                      onClick={copy}
                      title="复制工作日志"
                      className={`w-8 h-8 grid place-items-center rounded-lg border transition-colors ${copied ? "border-emerald-200 text-emerald-600 bg-emerald-50" : "border-slate-200 text-slate-400 hover:text-[#0052D9] hover:border-[#0052D9]/40"}`}
                    >
                      {copied ? <Check size={15} /> : <Copy size={15} />}
                    </button>
                  </>
                )}
              </div>
            </div>

            {/* 正文：摘要 + 分节（经典单列文档，分节标题左侧蓝色竖条） */}
            <div className="px-7 pt-4 pb-7">
              {editing ? (
                <textarea
                  value={doc.summary}
                  onChange={(e) => setSummary(e.target.value)}
                  rows={2}
                  placeholder="一句话概述本周期工作…"
                  className="w-full text-[13.5px] text-slate-700 leading-[1.75] rounded-lg border border-slate-200 px-2.5 py-1.5 outline-none focus:border-[#0052D9] focus:ring-2 focus:ring-[#0052D9]/10 resize-y"
                />
              ) : (
                <p className="text-[13.5px] text-slate-600 leading-[1.75] whitespace-pre-wrap">{doc.summary}</p>
              )}

              <div className="mt-5 space-y-5">
                {doc.sections.map((s, i) => (
                  <div key={i}>
                    {editing ? (
                      <div className="flex items-stretch gap-1.5 mb-2.5">
                        <span className="w-[3px] rounded bg-[#0052D9] shrink-0" />
                        <input
                          value={s.k}
                          onChange={(e) => setHead(i, e.target.value)}
                          placeholder="板块标题"
                          className="flex-1 text-[13px] font-bold text-slate-800 rounded-md border border-slate-200 px-2 py-1 outline-none focus:border-[#0052D9]"
                        />
                        <button onClick={() => removeSection(i)} title="删除板块" className="w-7 grid place-items-center rounded text-slate-300 hover:text-red-500 hover:bg-red-50 transition-colors">
                          <Trash2 size={13} />
                        </button>
                      </div>
                    ) : (
                      <div className="text-[13px] font-bold text-slate-800 mb-2.5 border-l-[3px] border-[#0052D9] pl-2.5 leading-tight">{s.k}</div>
                    )}
                    <ul className="space-y-2 pl-1">
                      {s.items.map((it, j) => (
                        <li key={j} className="text-[13px] text-slate-600 leading-relaxed flex gap-2.5 items-start">
                          <span className="mt-[8px] w-1 h-1 rounded-full bg-slate-300 shrink-0" />
                          {editing ? (
                            <span className="flex-1 flex items-center gap-1">
                              <input
                                value={it}
                                onChange={(e) => setItem(i, j, e.target.value)}
                                placeholder="填写内容…"
                                className="flex-1 rounded-md border border-slate-200 px-2 py-1 text-[13px] text-slate-700 outline-none focus:border-[#0052D9]"
                              />
                              <button onClick={() => removeItem(i, j)} title="删除条目" className="w-5 h-5 grid place-items-center rounded text-slate-300 hover:text-red-500 transition-colors shrink-0">
                                <X size={12} />
                              </button>
                            </span>
                          ) : (
                            <span>{it}</span>
                          )}
                        </li>
                      ))}
                    </ul>
                    {editing && (
                      <button onClick={() => addItem(i)} className="mt-2 ml-1 text-[12px] text-[#0052D9] hover:text-[#003FA8] inline-flex items-center gap-1">
                        <Plus size={12} /> 添加条目
                      </button>
                    )}
                  </div>
                ))}
                {editing && (
                  <button onClick={addSection} className="w-full h-9 rounded-lg border border-dashed border-slate-300 text-[12px] text-slate-500 hover:text-[#0052D9] hover:border-[#0052D9]/40 transition-colors inline-flex items-center justify-center gap-1">
                    <Plus size={13} /> 添加板块
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* 右：我的动态 */}
        <div className="space-y-4">
          {/* 我的动态 */}
          <div className="bg-white border border-slate-200/80 rounded-xl shadow-[0_1px_2px_0_rgba(15,23,42,0.04)] overflow-hidden">
            <div className="px-4 h-11 flex items-center gap-2 border-b border-slate-100">
              <span className="w-6 h-6 rounded-md bg-[#0052D9]/8 text-[#0052D9] grid place-items-center"><Activity size={13} /></span>
              <span className="text-[13px] font-bold text-slate-800">我的动态</span>
            </div>
            <div className="p-4">
              <div className="relative pl-4">
                <div className="absolute left-[5px] top-1.5 bottom-1.5 w-px bg-slate-100" />
                <div className="space-y-3.5">
                  {feed.map((f, i) => (
                    <div key={i} className="relative">
                      <span className="absolute -left-[14px] top-1 w-2.5 h-2.5 rounded-full ring-2 ring-white" style={{ background: DOT[f.tone] }} />
                      <div className="text-[12.5px] leading-snug">
                        <b className="font-semibold" style={{ color: DOT[f.tone] }}>{f.act}</b>{" "}
                        <span className="text-slate-600">{f.title}</span>
                      </div>
                      <div className="text-[11px] text-slate-400 mt-0.5">{f.time}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
        </div>
    </>
  );
}

// ===== 我的任务：按 待接受 / 进行中 / 已完成 三状态分类 + 待接受用 IM 派单气泡 =====
type TaskItem = { c: any; task: TaskNode; depth: number; path: string[] };
type StatKey = "accept" | "doing" | "done";
type ViewKey = "prio" | "case" | "due" | "completed";

const URANK: Record<string, number> = { "非常紧急": 0, "紧急": 1, "一般": 2, "不紧急": 3 };
// 紧急度色值与思维导图 urgencyBar 同源：非常紧急 #FF3B30 / 紧急 #FF9500 / 一般 #38BDF8 / 不紧急 #94A3B8
const UCOL = (u: string) =>
  u === "非常紧急" ? "#FF3B30" : u === "紧急" ? "#FF9500" : u === "一般" ? "#38BDF8" : "#94A3B8";
// 思维导图规则：仅活跃状态显示紧急度色条，终态不显示
const ACTIVE_STATUS = new Set(["待接受", "进行中"]);

// 三状态取色：待接受=teal / 进行中=蓝（同 statusDot）/ 已完成=中性灰（与 teal 拉开距离，归档语义）
const STAT_META: Record<StatKey, { label: string; accent: string; bg: string; sub: string }> = {
  accept: { label: "待接受", accent: "#0D9488", bg: "#f1faf8", sub: "需要你确认" },
  doing: { label: "进行中", accent: "#0052D9", bg: "#f5f8ff", sub: "继续推进" },
  done: { label: "已完成", accent: "#64748b", bg: "#f6f8fb", sub: "已归档" },
};
// 各状态可用视图：默认按优先级；进行中可按截止日期(近→远)，已完成可按完成日期(新→旧)
const VIEWS: Record<StatKey, [ViewKey, string][]> = {
  accept: [["prio", "按优先级"], ["due", "按截止日期"], ["case", "按 Case 分组"]],
  doing: [["prio", "按优先级"], ["due", "按截止日期"], ["case", "按 Case 分组"]],
  done: [["prio", "按优先级"], ["completed", "按完成日期"], ["case", "按 Case 分组"]],
};
// 任务无真实完成时间字段 —— 由 id 派生一个稳定的「完成日期」用于排序/展示
const pad2 = (n: number) => String(n).padStart(2, "0");
const COMPLETE_BASE = new Date("2026-06-22T00:00:00");
const hashId = (s: string) => { let h = 0; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0; return h; };
const completedDaysAgo = (t: TaskNode) => hashId(t.id) % 30; // 0..29，越小越近
const completedDate = (t: TaskNode) => {
  const d = new Date(COMPLETE_BASE);
  d.setDate(d.getDate() - completedDaysAgo(t));
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
};
// 推断派单人（谁 @你 派的单）及关系
function dispatcherOf(c: any, task: TaskNode) {
  if (task.supervisor) return { name: task.supervisor, role: "mgr", rel: "你的主管" };
  if (c.owner === "系统自动") return { name: "系统", role: "sys", rel: "系统自动" };
  if (c.owner && c.owner !== currentUser.name) {
    const dept = ownerToDepartment[c.owner];
    if (dept && dept !== currentUser.department)
      return { name: c.owner, role: "cross", rel: "跨部门" };
    return { name: c.owner, role: "owner", rel: "Case Owner" };
  }
  return {
    name: departmentSupervisors[task.department] || departmentSupervisors[currentUser.department] || "主管",
    role: "mgr",
    rel: "你的主管",
  };
}

const lvNum = (lv: string) => parseInt(String(lv).slice(1)) || 9;

function MyTasksPanel({
  myTasks,
  onOpenCase,
  onOpenTask,
}: {
  myTasks: TaskItem[];
  onOpenCase: (id: string) => void;
  onOpenTask: (caseId: string, taskId: string) => void;
}) {
  const [statF, setStatF] = useState<StatKey>("accept");
  const [view, setView] = useState<ViewKey>("prio");

  const STATUS_OF: Record<StatKey, string> = { accept: "待接受", doing: "进行中", done: "已完成" };
  const counts: Record<StatKey, number> = {
    accept: myTasks.filter((x) => x.task.status === "待接受").length,
    doing: myTasks.filter((x) => x.task.status === "进行中").length,
    done: myTasks.filter((x) => x.task.status === "已完成").length,
  };

  const filtered = myTasks.filter((x) => x.task.status === STATUS_OF[statF]);

  const comp = (a: TaskItem, b: TaskItem) =>
    URANK[a.task.urgency] - URANK[b.task.urgency] || (a.task.dueIn ?? 99) - (b.task.dueIn ?? 99);

  const opts = VIEWS[statF];
  const curView: ViewKey = opts.some((o) => o[0] === view) ? view : opts[0][0];

  const pickStat = (k: StatKey) => {
    setStatF(k);
    if (!VIEWS[k].some((o) => o[0] === view)) setView(VIEWS[k][0][0]);
  };

  // 按当前视图分组
  const groups: { key: string; head: any; items: TaskItem[] }[] = (() => {
    // 按截止日期：近 → 远（正向），单列展示
    if (curView === "due")
      return [{ key: "due", head: null, items: [...filtered].sort((a, b) => (a.task.dueIn ?? 99) - (b.task.dueIn ?? 99)) }];
    // 按完成日期：新 → 旧（倒序），单列展示
    if (curView === "completed")
      return [{ key: "completed", head: null, items: [...filtered].sort((a, b) => completedDaysAgo(a.task) - completedDaysAgo(b.task)) }];
    if (curView === "prio")
      return ["非常紧急", "紧急", "一般", "不紧急"]
        .map((u) => ({
          u,
          items: filtered
            .filter((x) => x.task.urgency === u)
            .sort((a, b) => (a.task.dueIn ?? 99) - (b.task.dueIn ?? 99)),
        }))
        .filter((g) => g.items.length)
        .map((g) => ({
          key: g.u,
          head: (
            <div className="flex items-center gap-2.5 mb-2">
              <span className="w-2.5 h-2.5 rounded-full" style={{ background: UCOL(g.u) }} />
              <span className="text-[13px] font-semibold text-slate-800">{g.u}</span>
              <span className="text-[11px] text-slate-400 tabular-nums">{g.items.length}</span>
              <span className="flex-1 h-px bg-slate-100" />
            </div>
          ),
          items: g.items,
        }));
    // 按 Case 分组
    const ids = [...new Set(filtered.map((x) => x.c.id))];
    const minU = (id: string) => Math.min(...filtered.filter((x) => x.c.id === id).map((x) => URANK[x.task.urgency]));
    const minL = (id: string) => Math.min(...filtered.filter((x) => x.c.id === id).map((x) => lvNum(x.c.level)));
    ids.sort((a, b) => minU(a) - minU(b) || minL(a) - minL(b));
    return ids.map((id) => {
      const items = filtered.filter((x) => x.c.id === id).sort(comp);
      const c = items[0].c;
      return {
        key: id,
        head: (
          <button onClick={() => onOpenCase(c.id)} className="group w-full flex items-center gap-2.5 mb-2 text-left">
            <span className={`text-[10px] px-1.5 py-0.5 rounded border shrink-0 ${levelColors[c.level]}`}>{c.level}</span>
            <CaseProductPill caseItem={c} compact />
            <CaseMarkCodePill caseItem={c} compact />
            <span className="text-[13px] font-semibold text-slate-800 truncate group-hover:text-[#0052D9] transition-colors">{c.name}</span>
            <span className="text-[11px] text-slate-400 shrink-0">{items.length} 个任务</span>
            <span className="flex-1 h-px bg-slate-100" />
          </button>
        ),
        items,
      };
    });
  })();

  return (
    <div className="space-y-5">
      {/* 3 个状态分类（点击筛选） */}
      <div className="grid grid-cols-3 gap-3">
        {(Object.keys(STAT_META) as StatKey[]).map((k) => {
          const m = STAT_META[k];
          const on = statF === k;
          return (
            <button
              key={k}
              onClick={() => pickStat(k)}
              className={`relative text-left px-[18px] pt-[15px] pb-[14px] bg-white border rounded-xl overflow-hidden transition-all ${on ? "" : "border-slate-200 hover:border-slate-300"}`}
              style={on ? { borderColor: m.accent, background: m.bg, boxShadow: `0 8px 20px -14px ${m.accent}` } : undefined}
            >
              <span className="absolute left-0 right-0 top-0 h-[3px] origin-left transition-transform" style={{ background: m.accent, transform: on ? "scaleX(1)" : "scaleX(0)" }} />
              <div className="text-xs tracking-wide transition-colors" style={{ color: on ? m.accent : "#64748b", fontWeight: on ? 600 : 400 }}>{m.label}</div>
              <div className="text-[32px] leading-none font-bold tabular-nums mt-2.5" style={{ color: on ? m.accent : "#0f172a" }}>
                {counts[k]}
                <span className="text-xs text-slate-400 font-normal ml-1">件</span>
              </div>
              <div className="mt-2 text-[11px] flex items-center gap-1.5 text-slate-400">
                <span className="w-[5px] h-[5px] rounded-full" style={{ background: m.accent, opacity: on ? 1 : 0.55 }} />
                {m.sub}
              </div>
            </button>
          );
        })}
      </div>

      {/* 当前维度 + 视图分段控件 */}
      <div className="flex items-center gap-2.5">
        <div className="text-[13px] text-slate-700 font-semibold">
          当前：<span style={{ color: STAT_META[statF].accent }}>{STAT_META[statF].label}</span>
          <span className="text-slate-400 font-normal"> · {filtered.length} 个</span>
        </div>
        <div className="flex-1" />
        <span className="text-xs text-slate-400">视图</span>
        <div className="inline-flex bg-slate-100 border border-slate-200 rounded-lg p-0.5">
          {opts.map(([key, lab]) => (
            <button
              key={key}
              onClick={() => setView(key)}
              className={`text-[12.5px] px-3 py-1.5 rounded-md transition-all ${curView === key ? "bg-white text-slate-800 font-semibold shadow-sm" : "text-slate-500 hover:text-slate-700"}`}
            >
              {lab}
            </button>
          ))}
        </div>
      </div>

      {/* 内容 */}
      {filtered.length === 0 ? (
        <EmptyState
          text={statF === "accept" ? "没有待确认的任务 🎉" : "暂无任务"}
          hint={statF === "accept" ? "派给你的新任务会出现在这里" : "切换上方维度看看其他任务"}
        />
      ) : (
        <div className="space-y-6">
          {groups.map((g) => (
            <div key={g.key}>
              {g.head}
              {statF === "accept" ? (
                <div className="grid grid-cols-2 gap-3">
                  {g.items.map((x) => (
                    <IMCard key={x.task.id} x={x} onOpenCase={onOpenCase} onOpenTask={onOpenTask} />
                  ))}
                </div>
              ) : (
                <div className="space-y-2">
                  {g.items.map((x) => (
                    <TaskRow
                      key={x.task.id}
                      x={x}
                      onOpenCase={onOpenCase}
                      onOpenTask={onOpenTask}
                      trailing={
                        curView === "completed" ? (
                          <><CalendarCheck size={12} className="text-emerald-500" /> 完成于 {completedDate(x.task)}</>
                        ) : undefined
                      }
                    />
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// 待接受：IM 派单气泡
function IMCard({ x, onOpenCase, onOpenTask }: { x: TaskItem; onOpenCase: (id: string) => void; onOpenTask: (c: string, t: string) => void }) {
  const { c, task } = x;
  const d = dispatcherOf(c, task);
  return (
    <div className="relative flex bg-white border border-slate-200 rounded-xl p-4 pl-5 overflow-hidden">
      {/* 紧急度色条：复用思维导图 urgencyBar 的用色规则与样式（唯一彩色通道） */}
      <div className={`absolute left-0 top-3 bottom-3 w-[3px] rounded-r ${urgencyBar[task.urgency] || "bg-slate-300"}`} title={`紧急度：${task.urgency}`} />
      <div className="flex-1 min-w-0">
        <div className="text-[11.5px] text-slate-500 flex items-center gap-1.5 flex-wrap">
          <b className="text-slate-900">{d.name}</b>
          <span className="text-[#0052D9] font-semibold">@你</span>
          <span>· 请处理这个任务</span>
          <span className="text-[10px] font-semibold rounded px-1.5 py-px text-slate-500 bg-slate-100 border border-slate-200">{d.rel}</span>
        </div>
        <div className="bg-[#f7f9fc] border border-slate-100 rounded-xl rounded-tl-[3px] px-3 py-2.5 mt-1.5">
          <button onClick={() => onOpenTask(c.id, task.id)} className="text-sm font-semibold text-slate-800 leading-snug text-left hover:text-[#0052D9] transition-colors">
            {task.title}
          </button>
          <div className="mt-2 flex items-center gap-2 flex-wrap">
            <span className="inline-flex items-center gap-1 text-[11px] text-slate-500"><CalendarClock size={12} className="text-slate-400" /> {dueLabel(task.dueIn)}</span>
            <button onClick={() => onOpenCase(c.id)} className="text-[10.5px] text-slate-500 bg-slate-100 border border-slate-200 rounded-md px-2 py-0.5 inline-flex items-center gap-1.5 max-w-[210px] hover:text-[#0052D9] transition-colors">
              <span className={`text-[9px] px-1 rounded border shrink-0 ${levelColors[c.level]}`}>{c.level}</span>
              <CaseProductPill caseItem={c} compact />
              <span className="truncate">{c.name}</span>
            </button>
          </div>
        </div>
        <div className="mt-2.5 flex gap-2">
          <button className="bg-[#0052D9] text-white rounded-lg px-4 py-1.5 text-xs font-semibold hover:bg-[#003FA8] transition-colors">接受并开始</button>
          <button className="bg-white text-slate-500 border border-slate-200 rounded-lg px-3.5 py-1.5 text-xs hover:bg-slate-50 transition-colors">拒绝</button>
        </div>
      </div>
    </div>
  );
}

// 进行中 / 非常紧急 / 今日到期：列表行（标题可点进详情）
function TaskRow({ x, onOpenCase, onOpenTask, trailing, showDept }: { x: TaskItem; onOpenCase: (id: string) => void; onOpenTask: (c: string, t: string) => void; trailing?: React.ReactNode; showDept?: boolean }) {
  const { c, task } = x;
  // 思维导图规则：仅活跃状态显示紧急度色条，终态（已完成等）不显示
  const showBar = ACTIVE_STATUS.has(task.status);
  return (
    <div className="relative flex items-center gap-3 bg-white border border-slate-200 rounded-xl pl-4 pr-4 py-3 hover:shadow-[0_6px_18px_-12px_rgba(15,23,42,0.2)] transition-shadow">
      {showBar && (
        <div className={`absolute left-0 top-2 bottom-2 w-[3px] rounded-r ${urgencyBar[task.urgency] || "bg-slate-300"}`} title={`紧急度：${task.urgency}`} />
      )}
      <div className="w-[74px] shrink-0 flex items-center gap-1.5 text-[11px] text-slate-500">
        <StatusBadge status={task.status} size={14} /> {task.status}
      </div>
      <button onClick={() => onOpenTask(c.id, task.id)} className="flex-1 min-w-0 text-left text-[13px] text-slate-800 truncate hover:text-[#0052D9] transition-colors">
        {task.title}
      </button>
      <button onClick={() => onOpenCase(c.id)} className="hidden xl:flex items-center gap-1.5 text-[11px] text-slate-400 shrink-0 max-w-[210px] hover:text-[#0052D9] transition-colors">
        <span className={`text-[9px] px-1 rounded border shrink-0 ${levelColors[c.level]}`}>{c.level}</span>
        <CaseProductPill caseItem={c} compact />
        <span className="truncate">{c.name}</span>
      </button>
      <div className={`${showDept ? "w-[150px]" : "w-[96px]"} shrink-0 flex items-center gap-1.5 text-xs text-slate-500`}>
        <span className="w-5 h-5 rounded-full bg-[#0052D9]/8 text-[#0052D9] grid place-items-center text-[10px] font-medium shrink-0">{task.owner[0]}</span>
        <span className="truncate">{task.owner}</span>
        {showDept && task.department && (
          <span className="shrink-0 text-[10px] text-slate-500 px-1.5 py-0.5 rounded bg-slate-100" title={`归属部门：${task.department}`}>{task.department}</span>
        )}
      </div>
      <span className="shrink-0 inline-flex items-center gap-1 text-[11px] text-slate-500">
        {trailing ?? (<><CalendarClock size={12} className="text-slate-400" /> {dueLabel(task.dueIn)}</>)}
      </span>
    </div>
  );
}

