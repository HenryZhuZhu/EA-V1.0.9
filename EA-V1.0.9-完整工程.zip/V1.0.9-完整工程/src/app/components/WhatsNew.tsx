import { useState } from "react";
import { Sparkles, X, ArrowRight, ArrowLeft, Palette, BadgeCheck, Network, Inbox, BarChart3, MonitorPlay, Play, Keyboard, FileText, GitBranch, MousePointerClick, Maximize2 } from "lucide-react";

// 版本更新说明 —— V1.0.1 → V1.0.2。进入应用自动弹出（可勾选「本版本不再提示」）。
// 翻页式：两大亮点各一页 + 其它更新一页。key 升级（…_f）确保改版后重新弹出一次。
export const WHATSNEW_KEY = "ea_whatsnew_v1_0_2_f";

const HEROES = [
  {
    icon: Network,
    badge: "核心模块",
    title: "思维导图 · 把分析画成一棵树",
    desc: "以「怀疑方向 ＋ 执行任务」双层节点展开排查思路，分析过程一眼可循。",
    pills: [
      { icon: GitBranch, label: "双层节点树" },
      { icon: MousePointerClick, label: "四步引导上手" },
      { icon: BadgeCheck, label: "状态徽章 · 左色条" },
    ],
    enter: "Case 详情页 →「任务思维导图」",
  },
  {
    icon: MonitorPlay,
    badge: "本版亮点 · NEW",
    title: "演示模式 · 把 Case 讲成故事",
    desc: "一键进入双联视图（左导图 + 右详情），沿怀疑方向逐节点讲解，开会评审不再来回切。",
    pills: [
      { icon: Play, label: "逐节点讲解" },
      { icon: Keyboard, label: "键盘 ← → 翻页" },
      { icon: Maximize2, label: "一键沉浸演示" },
    ],
    enter: "Case 详情页右上角「演示模式」",
  },
];

const CARDS = [
  { icon: Palette, title: "视觉语言焕新", desc: "配色收敛 6 色 · 去紫，彩色只给信号。" },
  { icon: BadgeCheck, title: "状态 / 进度统一", desc: "StatusBadge 状态徽 + ProgressRing 进度环。" },
  { icon: Inbox, title: "工作台重构", desc: "任务分待接受/进行中/已完成，派单可接受拒绝。" },
  { icon: Sparkles, title: "智能汇总", desc: "日/周/月/年报在线编辑，新增个人主页。" },
  { icon: BarChart3, title: "团队看板对齐", desc: "复刻参考原型（Chart.js），离线可用。" },
  { icon: FileText, title: "列表去花哨", desc: "进度环 · 左色条 · 统一徽章，长列表更易扫。" },
];

export function WhatsNew({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [skip, setSkip] = useState(true);
  const [step, setStep] = useState(0);
  if (!open) return null;
  const TOTAL = 3; // 思维导图 / 演示模式 / 其它更新
  const last = step === TOTAL - 1;

  const close = () => {
    if (skip) { try { localStorage.setItem(WHATSNEW_KEY, "1"); } catch {} }
    onClose();
  };
  const next = () => (last ? close() : setStep((s) => s + 1));
  const prev = () => setStep((s) => Math.max(0, s - 1));

  return (
    <div
      className="fixed inset-0 z-[200] flex items-center justify-center p-6 bg-slate-900/55 backdrop-blur-sm"
      onClick={(e) => { if (e.target === e.currentTarget) close(); }}
    >
      <div className="w-full max-w-[580px] bg-white rounded-2xl shadow-2xl overflow-hidden animate-[fadeUp_.3s_ease]">
        {/* Header band */}
        <div className="relative px-8 pt-7 pb-6 bg-gradient-to-br from-[#0052D9] to-[#003a9e] text-white">
          <button
            onClick={close}
            title="关闭"
            className="absolute top-4 right-4 w-8 h-8 rounded-lg bg-white/15 hover:bg-white/25 flex items-center justify-center"
          >
            <X size={16} />
          </button>
          <span className="inline-flex items-center gap-1.5 text-[11.5px] font-semibold tracking-[0.1em] bg-white/15 rounded-full px-3 py-1">
            <Sparkles size={13} /> 版本更新 · V1.0.1 → V1.0.2
          </span>
          <h3 className="mt-3 text-[22px] font-bold leading-snug">EA Platform V1.0.2 焕新</h3>
          <p className="mt-1.5 text-[13px] text-white/75">两大亮点：思维导图模块 · 演示模式</p>
        </div>

        {/* Body — 固定高度的翻页区 */}
        <div className="px-8 py-7 min-h-[300px] flex flex-col">
          {step < 2 ? (
            (() => {
              const h = HEROES[step];
              const Icon = h.icon;
              return (
                <div className="flex-1">
                  <div className="flex items-center gap-3.5">
                    <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#0052D9] to-[#7A3DFF] text-white grid place-items-center shrink-0 shadow-lg">
                      <Icon size={28} />
                    </div>
                    <div>
                      <span className="text-[11px] font-bold tracking-wide text-[#0052D9] bg-[#0052D9]/10 rounded-full px-2.5 py-1">{h.badge}</span>
                      <div className="mt-1.5 text-[19px] font-bold text-slate-900 leading-tight">{h.title}</div>
                    </div>
                  </div>
                  <p className="mt-4 text-[14px] text-slate-600 leading-relaxed">{h.desc}</p>
                  <div className="mt-4 flex flex-wrap gap-2">
                    {h.pills.map((p) => {
                      const PIcon = p.icon;
                      return (
                        <span key={p.label} className="inline-flex items-center gap-1.5 text-[12.5px] font-medium text-[#0052D9] bg-white border border-[#0052D9]/20 rounded-full px-3 py-1.5">
                          <PIcon size={13} /> {p.label}
                        </span>
                      );
                    })}
                  </div>
                  <div className="mt-4 text-[12px] text-slate-400">进入方式：{h.enter}</div>
                </div>
              );
            })()
          ) : (
            <div className="flex-1">
              <div className="text-[14px] font-bold text-slate-700 mb-4">本版其它更新</div>
              <div className="grid grid-cols-2 gap-x-5 gap-y-3.5">
                {CARDS.map((c) => {
                  const Icon = c.icon;
                  return (
                    <div key={c.title} className="flex items-start gap-2.5">
                      <div className="w-7 h-7 rounded-lg bg-slate-100 text-slate-500 grid place-items-center shrink-0 mt-0.5">
                        <Icon size={15} />
                      </div>
                      <div className="min-w-0">
                        <div className="text-[13.5px] font-semibold text-slate-800 leading-tight">{c.title}</div>
                        <div className="text-[12px] text-slate-400 leading-snug mt-1">{c.desc}</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* 翻页点 */}
          <div className="flex items-center justify-center gap-2 mt-5">
            {Array.from({ length: TOTAL }).map((_, i) => (
              <button
                key={i}
                onClick={() => setStep(i)}
                className={`h-2 rounded-full transition-all ${i === step ? "w-6 bg-[#0052D9]" : "w-2 bg-slate-300 hover:bg-slate-400"}`}
              />
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="px-8 py-4 border-t border-slate-100 flex items-center gap-3">
          <label className="text-[12.5px] text-slate-400 flex items-center gap-1.5 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={skip}
              onChange={(e) => setSkip(e.target.checked)}
              className="w-4 h-4 rounded border-slate-300 accent-[#0052D9]"
            />
            不再提示
          </label>
          <div className="flex-1" />
          {step > 0 && (
            <button onClick={prev} className="h-9 px-3.5 rounded-lg text-slate-500 text-[13.5px] inline-flex items-center gap-1 hover:bg-slate-100">
              <ArrowLeft size={15} /> 上一页
            </button>
          )}
          <button
            onClick={next}
            className="h-9 px-5 rounded-lg bg-gradient-to-r from-[#0052D9] to-[#003FA8] text-white text-[13.5px] inline-flex items-center gap-1.5 hover:shadow-md"
          >
            {last ? "开始体验" : "下一页"} <ArrowRight size={15} />
          </button>
        </div>
      </div>

      <style>{`@keyframes fadeUp{from{opacity:0;transform:translateY(12px) scale(.98)}to{opacity:1;transform:none}}`}</style>
    </div>
  );
}
