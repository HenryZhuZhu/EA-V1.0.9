import { ReactNode } from "react";
import { Check } from "lucide-react";

// 通用图标选项卡片：复用「新建 Case · 物料选择」的样式
// （rounded-lg + 52px 高 + 图标槽 + 主/副标签 + 选中 ✓ + 选中 #0052D9 主色）
export function OptionCard({
  active,
  onClick,
  icon,
  label,
  sublabel,
  title,
  disabled,
}: {
  active: boolean;
  onClick: () => void;
  icon?: ReactNode;
  label: string;
  sublabel?: string;
  title?: string;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      title={title}
      disabled={disabled}
      onClick={onClick}
      className={`flex h-[52px] items-center gap-2 rounded-lg border px-2 transition-all disabled:opacity-40 ${
        active
          ? "border-[#0052D9] bg-[#0052D9]/[0.06] shadow-sm"
          : "border-slate-200 hover:border-[#0052D9]/40 hover:bg-slate-50"
      }`}
    >
      {icon != null && <span className="flex w-[30px] shrink-0 items-center justify-center">{icon}</span>}
      <span className="flex flex-col items-start leading-tight">
        <span className={`text-[11px] font-medium ${active ? "text-[#0052D9]" : "text-slate-700"}`}>{label}</span>
        {sublabel && <span className={`text-[9px] ${active ? "text-[#0052D9]/70" : "text-slate-400"}`}>{sublabel}</span>}
      </span>
      {active && <Check className="ml-auto h-3.5 w-3.5 shrink-0 text-[#0052D9]" />}
    </button>
  );
}
