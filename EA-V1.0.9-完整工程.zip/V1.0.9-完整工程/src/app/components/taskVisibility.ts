// 与新建 Case 使用相同的选项和表单预设；当前只保存设置，不实施访问控制。
export interface TaskVisibility {
  type: "all" | "partial";
  people: string[];
}

const PRESET_KEY = "ea_perm_preset_v1";

export function normalizeTaskVisibility(type: TaskVisibility["type"] = "all", people: string[] = []): TaskVisibility {
  if (type !== "all" && type !== "partial") throw new Error("请选择有效的可见范围。");
  if (type === "all") return { type, people: [] };
  if (!Array.isArray(people) || people.some((person) => typeof person !== "string")) throw new Error("请选择有效的可见人员。");
  const selected = [...new Set(people.map((person) => person.trim()).filter(Boolean))];
  if (!selected.length) throw new Error("部分人可见时，请选择可见人员。");
  return { type, people: selected };
}

export function loadTaskVisibilityPreset(): TaskVisibility {
  try {
    const preset = JSON.parse(localStorage.getItem(PRESET_KEY) || "null");
    if (preset) return normalizeTaskVisibility(preset.type, (preset.list ?? []).filter((item: { type: string }) => item.type === "user").map((item: { name: string }) => item.name));
  } catch { /* 预设损坏或存储不可用时，与 Case 一样默认全员可见。 */ }
  return { type: "all", people: [] };
}

export function saveTaskVisibilityPreset(visibility: TaskVisibility) {
  try {
    localStorage.setItem(PRESET_KEY, JSON.stringify({ type: visibility.type, list: visibility.people.map((name) => ({ id: `perm-${name}`, name, type: "user" })) }));
  } catch { /* 预设保存失败不影响已保存的任务；不把预设误当访问权限。 */ }
}