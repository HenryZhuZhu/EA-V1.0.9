import type { ComponentProps, ReactNode } from "react";
import { X } from "lucide-react";
import { CaseFilterFields } from "./CaseFilterFields";
import { CaseCustomFilterEditor, type CaseCustomFilterEditorProps } from "./CaseCustomFilterEditor";

export const CASE_FILTER_PANEL_CLASS_NAME = "z-40 flex w-[480px] max-w-[88vw] max-h-[min(80vh,var(--radix-popover-content-available-height))] flex-col overflow-hidden bg-white border border-slate-200 rounded-xl shadow-[0_16px_40px_-12px_rgba(15,23,42,0.25)] p-0";

// 只负责受控内容：范围、显示设置由调用方提供，查询和存储仍属于各列表。
export function CaseFilterPanel({ scopeContent, customEditor, displaySettings, onReset, onDone, ...fields }: ComponentProps<typeof CaseFilterFields> & {
  scopeContent?: ReactNode;
  customEditor?: CaseCustomFilterEditorProps;
  displaySettings?: ReactNode;
  onReset: () => void;
  onDone: () => void;
}) {
  return <div data-slot="case-filter-panel" className="flex min-h-0 flex-col overflow-hidden">
    <div className="min-h-0 overflow-y-auto overscroll-contain p-4">
      {scopeContent}
      <p className="mb-2 text-[11px] text-slate-400">筛选维度</p>
      <CaseFilterFields {...fields} />
      {customEditor && <CaseCustomFilterEditor {...customEditor} />}
      {displaySettings}
    </div>
    <div className="flex shrink-0 items-center justify-between border-t border-slate-100 px-4 py-3">
      <button type="button" onClick={onReset} className="h-8 px-3 rounded-lg text-xs text-slate-500 hover:text-[#0052D9] inline-flex items-center gap-1"><X size={12} />重置全部</button>
      <button type="button" onClick={onDone} className="h-8 px-4 rounded-lg text-xs bg-[#0052D9] text-white hover:bg-[#003FA8]">完成</button>
    </div>
  </div>;
}