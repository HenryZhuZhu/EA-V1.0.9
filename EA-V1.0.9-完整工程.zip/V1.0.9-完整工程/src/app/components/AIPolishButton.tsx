import { Sparkles, Loader2 } from "lucide-react";
import { useState } from "react";

interface Props {
  getText?: () => string;
  onPolished?: (text: string) => void;
  onClick?: () => void;        // 提供时覆盖默认「润色」行为（如：润色 + 识别填充 + 弹窗确认）
  size?: "sm" | "md";
  className?: string;
  hint?: string;
}

function polish(input: string): string {
  const trimmed = input.trim();
  if (!trimmed) {
    return "请补充背景信息、影响范围与已尝试措施，以便后续跟进。";
  }
  const withPunct = /[。.!?！？]$/.test(trimmed) ? trimmed : trimmed + "。";
  return `${withPunct}（已由 AI 润色：调整表述与措辞，使内容更清晰、专业。）`;
}

export function AIPolishButton({
  getText,
  onPolished,
  onClick,
  size = "sm",
  className = "",
  hint = "AI 润色",
}: Props) {
  const [loading, setLoading] = useState(false);

  const handleClick = () => {
    if (loading) return;
    setLoading(true);
    window.setTimeout(() => {
      if (onClick) {
        onClick();
      } else if (getText && onPolished) {
        onPolished(polish(getText()));
      }
      setLoading(false);
    }, 600);
  };

  const dim = size === "sm" ? "h-7 w-7" : "h-9 w-9";
  return (
    <button
      type="button"
      title={hint}
      onClick={handleClick}
      className={`${dim} inline-flex items-center justify-center rounded-md border transition-all shrink-0 ${
        loading
          ? "bg-[#7A3DFF] border-[#7A3DFF] text-white"
          : "bg-white border-slate-200 text-slate-500 hover:border-[#7A3DFF]/50 hover:text-[#7A3DFF]"
      } ${className}`}
    >
      {loading ? (
        <Loader2 size={size === "sm" ? 12 : 14} className="animate-spin" />
      ) : (
        <Sparkles size={size === "sm" ? 12 : 14} />
      )}
    </button>
  );
}
