import { useState } from "react";
import {
  Search, Package, FileText, Radar, ChevronRight, ChevronDown, ChevronUp, UserCheck, Filter, X,
} from "lucide-react";
import {
  Issue, IssueStatus,
  issueStatusColors, issueSourceColors, objectTypeColors,
  mockCases, fanoutCoverage, productById, currentUser,
} from "./data";
import { useIssues, isIssueRelevantTo } from "./domainStore";

function Chip({ text, cls }: { text: string; cls: string }) {
  return <span className={`inline-flex items-center px-1.5 py-0.5 rounded text-[11px] border ${cls}`}>{text}</span>;
}

interface Props {
  onOpenCase: (id: string) => void;
  onOpenIssue: (id: string) => void;
}

// Issue 中心：Issue 列表（同一个 Issue 详情下钻）
export function IssueHub({ onOpenCase, onOpenIssue }: Props) {
  return (
    <div className="space-y-3">
      <LedgerPerspective onOpenCase={onOpenCase} onOpenIssue={onOpenIssue} />
    </div>
  );
}

/* ---------------------- 视角二：Issue 列表 ---------------------- */
function LedgerPerspective({ onOpenCase, onOpenIssue }: { onOpenCase: (id: string) => void; onOpenIssue: (id: string) => void }) {
  const issues = useIssues();
  const [q, setQ] = useState("");
  const [product, setProduct] = useState("全部");
  const [onlyMine, setOnlyMine] = useState(false);
  const [statusFilter, setStatusFilter] = useState<IssueStatus | "全部">("全部");
  const [onlyRETs, setOnlyRETs] = useState(false);
  const [filterOpen, setFilterOpen] = useState(false);
  const [expandedIssueIds, setExpandedIssueIds] = useState<Record<string, boolean>>({});

  const toggleExpand = (issueId: string) => {
    setExpandedIssueIds((prev) => ({ ...prev, [issueId]: !prev[issueId] }));
  };

  // 产品维度筛选选项：汇总所有 Issue 受影响产品的 code
  const productOpts = ["全部", ...Array.from(new Set(
    issues.flatMap((i) => i.affectedProductIds.map((pid) => productById(pid)?.code).filter(Boolean) as string[])
  ))];

  const filtered = issues.filter((i) => {
    if (onlyMine && !isIssueRelevantTo(i, currentUser.name)) return false;
    if (onlyRETs && !i.retsSynced) return false;
    if (statusFilter !== "全部" && i.status !== statusFilter) return false;
    if (product !== "全部") {
      const codes = i.affectedProductIds.map((pid) => productById(pid)?.code).filter(Boolean) as string[];
      if (!codes.includes(product)) return false;
    }
    if (q.trim() && ![i.code, i.name, i.desc, i.rootCause ?? "", i.customer ?? ""].join(" ").toLowerCase().includes(q.trim().toLowerCase())) return false;
    return true;
  });
  const retsCount = issues.filter((i) => i.retsSynced).length;
  const activeFilterCount = (product !== "全部" ? 1 : 0) + (onlyMine ? 1 : 0) + (statusFilter !== "全部" ? 1 : 0) + (onlyRETs ? 1 : 0);
  const STATUS_OPTS = ["全部", "进行中", "已准备好解决方案", "解决方案验证中", "已结案"];

  return (
    <div className="space-y-4">
      {/* 头部：搜索 + 筛选 + 计数（对齐 Case 中心） */}
      <div className="bg-white border border-slate-200/80 rounded-xl px-3.5 py-3 shadow-[0_1px_2px_0_rgba(15,23,42,0.04)]">
        <div className="flex items-center gap-2 flex-wrap">
          {/* 搜索 */}
          <div className="relative w-[320px] max-w-full">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="搜索 Issue 编号 / 名称 / 根因 / 客户"
              className="w-full h-9 pl-9 pr-8 rounded-lg border border-slate-200 bg-white text-sm text-slate-700 placeholder:text-slate-400 outline-none focus:border-[#0052D9] focus:ring-2 focus:ring-[#0052D9]/10 transition-all"
            />
            {q && (
              <button onClick={() => setQ("")} title="清空搜索" className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
                <X size={13} />
              </button>
            )}
          </div>
          {/* 筛选弹层 */}
          <div className="relative">
            <button
              onClick={() => setFilterOpen((v) => !v)}
              className={`h-9 px-3 rounded-lg border text-sm inline-flex items-center gap-1.5 transition-colors ${
                filterOpen || activeFilterCount > 0
                  ? "border-[#0052D9]/40 bg-[#0052D9]/5 text-[#0052D9]"
                  : "border-slate-200 bg-white text-slate-600 hover:border-slate-300"
              }`}
            >
              <Filter size={13} /> 筛选
              {activeFilterCount > 0 && (
                <span className="inline-flex items-center justify-center min-w-[16px] h-4 px-1 rounded-full bg-[#0052D9] text-white text-[10px] tabular-nums">{activeFilterCount}</span>
              )}
              <ChevronDown size={13} className={`transition-transform ${filterOpen ? "rotate-180" : ""}`} />
            </button>
            {filterOpen && (
              <>
                <div className="fixed inset-0 z-30" onClick={() => setFilterOpen(false)} />
                <div className="absolute left-0 top-full mt-2 z-40 w-[420px] max-w-[88vw] bg-white border border-slate-200 rounded-xl shadow-[0_16px_40px_-12px_rgba(15,23,42,0.25)] p-4">
                  {/* 范围 */}
                  <div className="text-[11px] text-slate-400 mb-2">范围</div>
                  <div className="flex items-center gap-2 flex-wrap mb-3.5">
                    <button
                      onClick={() => setOnlyMine(false)}
                      className={`h-8 px-3 rounded-lg text-xs border inline-flex items-center gap-1.5 transition-colors ${!onlyMine ? "border-[#0052D9]/40 bg-[#0052D9]/5 text-[#0052D9]" : "border-slate-200 text-slate-600 hover:border-slate-300"}`}
                    >
                      <Package size={12} /> 全部
                    </button>
                    <button
                      onClick={() => setOnlyMine(true)}
                      className={`h-8 px-3 rounded-lg text-xs border inline-flex items-center gap-1.5 transition-colors ${onlyMine ? "border-[#0052D9]/40 bg-[#0052D9]/5 text-[#0052D9]" : "border-slate-200 text-slate-600 hover:border-slate-300"}`}
                    >
                      <UserCheck size={12} /> 只看与我相关
                    </button>
                    <button
                      onClick={() => setOnlyRETs((v) => !v)}
                      className={`h-8 px-3 rounded-lg text-xs border inline-flex items-center gap-1.5 transition-colors ${onlyRETs ? "border-[#7A3DFF]/40 bg-[#7A3DFF]/5 text-[#7A3DFF]" : "border-slate-200 text-slate-600 hover:border-slate-300"}`}
                    >
                      <Radar size={12} /> 已同步 RETs{retsCount > 0 && <span className="text-slate-400">·{retsCount}</span>}
                    </button>
                  </div>
                  {/* 筛选维度 */}
                  <div className="text-[11px] text-slate-400 mb-2">筛选维度</div>
                  <div className="flex items-center gap-3 flex-wrap">
                    <LedgerSelect label="状态" value={statusFilter} opts={STATUS_OPTS} onChange={(v) => setStatusFilter(v as IssueStatus | "全部")} />
                    <LedgerSelect label="产品" value={product} opts={productOpts} onChange={(v) => setProduct(v)} />
                  </div>
                  {/* 底部：重置 / 完成 */}
                  <div className="flex items-center justify-between mt-4 pt-3 border-t border-slate-100">
                    <button onClick={() => { setProduct("全部"); setOnlyMine(false); setStatusFilter("全部"); setOnlyRETs(false); }} className="h-8 px-3 rounded-lg text-xs text-slate-500 hover:text-[#0052D9] inline-flex items-center gap-1">
                      <X size={12} /> 重置全部
                    </button>
                    <button onClick={() => setFilterOpen(false)} className="h-8 px-4 rounded-lg text-xs bg-[#0052D9] text-white hover:bg-[#003FA8]">完成</button>
                  </div>
                </div>
              </>
            )}
          </div>
          {/* 计数靠右 */}
          <div className="ml-auto flex items-center gap-2">
            <span className="text-xs text-slate-500 tabular-nums">共 <b className="text-slate-800">{filtered.length}</b>/{issues.length}</span>
          </div>
        </div>
      </div>

      {/* 列表：A1 两列网格（等高对齐） */}
      <div className="grid grid-cols-2 gap-3 items-stretch">
        {filtered.map((i) => {
          const cov = fanoutCoverage(i);
          const issueCases = (i.caseIds
            .map((cid) => mockCases.find((c) => c.id === cid))
            .filter(Boolean) as typeof mockCases)
            .sort((a, b) => (b.updatedAt || "").localeCompare(a.updatedAt || ""));
          const expanded = !!expandedIssueIds[i.id];
          return (
            <div key={i.id} onClick={() => onOpenIssue(i.id)} className="relative flex flex-col rounded-lg border border-slate-200 bg-white hover:border-[#7A3DFF]/40 hover:shadow-sm transition-all p-3.5 cursor-pointer">
              {/* 标题行：编码 + 名称（点击进详情）｜右侧 Case */}
              <div className="flex items-start justify-between gap-2">
                <button onClick={() => onOpenIssue(i.id)} className="min-w-0 text-left flex items-center gap-2">
                  <span className="font-mono text-xs text-slate-400 shrink-0">{i.code}</span>
                  <span className="text-sm text-slate-900 truncate">{i.name}</span>
                </button>
                <button
                  onClick={(e) => { e.stopPropagation(); toggleExpand(i.id); }}
                  className="shrink-0 h-7 px-2 rounded border border-slate-200 text-[11px] text-slate-600 hover:bg-slate-50 inline-flex items-center gap-1"
                >
                  Case ({issueCases.length})
                  {expanded ? <ChevronUp size={13} /> : <ChevronDown size={13} />}
                </button>
              </div>

              {/* 描述 */}
              <button onClick={() => onOpenIssue(i.id)} className="block w-full text-left text-xs text-slate-500 mt-1 line-clamp-1">{i.desc}</button>

              {/* 产品行（更重要）+ 客诉 */}
              <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                {i.affectedProductIds.map((pid) => {
                  const p = productById(pid);
                  return p ? <Chip key={pid} text={p.code} cls="bg-[#0052D9]/8 text-[#0052D9] border-[#0052D9]/25" /> : null;
                })}
                {i.customer && <Chip text={`客诉·${i.customer}`} cls="bg-slate-50 text-slate-500 border-slate-200" />}
              </div>

              {/* 指标行：Case / fanout 紧凑徽标（底部对齐） */}
              <div className="flex items-center gap-2 mt-auto pt-3">
                <span className="text-[11px] text-slate-500 inline-flex items-center gap-1 px-2 py-1 rounded-md bg-slate-50 border border-slate-100"><FileText size={12} className="text-slate-400" />{i.caseIds.length} Case</span>
                <span className="text-[11px] text-slate-500 inline-flex items-center gap-1 px-2 py-1 rounded-md bg-slate-50 border border-slate-100"><Radar size={12} className="text-slate-400" />fanout {cov.total ? `${cov.done}/${cov.total}` : "—"}</span>
                <button onClick={() => onOpenIssue(i.id)} className="ml-auto shrink-0 text-slate-300 hover:text-slate-400">
                  <ChevronRight size={16} />
                </button>
              </div>

              {expanded && (
                <>
                  {/* 点击外部关闭的透明遮罩 */}
                  <div className="fixed inset-0 z-10" onClick={(e) => { e.stopPropagation(); toggleExpand(i.id); }} />
                  {/* S1 悬浮弹层：Case 列表浮在卡片下方，不占布局、不影响邻卡 */}
                  <div onClick={(e) => e.stopPropagation()} className="absolute z-20 left-3.5 right-3.5 top-full -mt-1 rounded-lg border border-slate-200 bg-white shadow-[0_16px_40px_-18px_rgba(15,23,42,0.4)] p-2 space-y-1.5 max-h-[280px] overflow-y-auto">
                    <div className="text-[11px] text-slate-400 px-1 pb-1">Case（{issueCases.length}）· 按更新时间倒序</div>
                    {issueCases.length > 0 ? issueCases.map((c) => (
                      <button key={c.id}
                        onClick={() => { toggleExpand(i.id); onOpenCase(c.id); }}
                        className="w-full text-left text-xs rounded border border-slate-100 bg-slate-50 px-2.5 py-1.5 flex items-center gap-2 hover:border-[#0052D9]/30 hover:bg-blue-50/50 transition-colors">
                        <span className="font-mono text-slate-400">{c.code}</span>
                        <span className="text-slate-700 truncate">{c.name}</span>
                      </button>
                    )) : (
                      <div className="text-xs text-slate-400 px-1 py-1">暂无关联 Case</div>
                    )}
                  </div>
                </>
              )}
            </div>
          );
        })}
        {filtered.length === 0 && <div className="text-center text-sm text-slate-400 py-16">无匹配 Issue</div>}
      </div>
    </div>
  );
}

function Metric({ icon: Icon, v, label }: { icon: any; v: any; label: string }) {
  return (
    <div>
      <div className="flex items-center justify-center gap-1 text-slate-700"><Icon size={13} className="text-slate-400" /><span className="text-sm tabular-nums">{v}</span></div>
      <div className="text-[10px] text-slate-400 mt-0.5">{label}</div>
    </div>
  );
}
function LedgerSelect({ label, value, opts, onChange }: { label: string; value: string; opts: string[]; onChange: (v: string) => void }) {
  return (
    <label className="inline-flex items-center gap-1 text-xs text-slate-500">
      <span>{label}</span>
      <select value={value} onChange={(e) => onChange(e.target.value)}
        className="h-8 px-2 text-sm rounded-md border border-slate-200 outline-none focus:border-[#0052D9] bg-white">
        {opts.map((o) => <option key={o} value={o}>{o}</option>)}
      </select>
    </label>
  );
}
