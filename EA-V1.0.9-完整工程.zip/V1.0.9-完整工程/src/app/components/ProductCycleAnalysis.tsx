import { useMemo, useState } from "react";
import { CalendarDays, RotateCcw, Users } from "lucide-react";
import { CaseItem, flattenTasks, TaskNode } from "./data";

type Grain = "day" | "week" | "month";
type CaseRecord = { item: CaseItem; closedAt: string; days: number };
type TaskRecord = { task: TaskNode; caseItem: CaseItem; completedAt: string; days: number };

interface Props {
  productCode: string;
  cases: CaseItem[];
  isClosed: (id: string) => boolean;
  closedAt: (id: string) => string | undefined;
  onOpenCase: (id: string) => void;
}

const DAY = 86400000;
const COLORS = ["#0052D9", "#00A4C7", "#16A085", "#E19A26", "#D94B52", "#7C6EDB", "#64748B"];
const dateText = (date: Date) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
const parseDate = (value: string) => new Date(`${value.slice(0, 10)}T00:00:00`);
const addDays = (date: Date, days: number) => new Date(date.getTime() + days * DAY);
const diffDays = (start: string, end: string) => Math.max(0.5, (parseDate(end).getTime() - parseDate(start).getTime()) / DAY);
const average = (values: number[]) => values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : 0;
const hash = (value: string) => [...value].reduce((sum, char) => sum + char.charCodeAt(0), 0);

function bucketStart(date: Date, grain: Grain) {
  const copy = new Date(date);
  if (grain === "week") {
    const day = copy.getDay();
    copy.setDate(copy.getDate() - (day === 0 ? 6 : day - 1));
  }
  if (grain === "month") copy.setDate(1);
  return copy;
}
function nextBucket(date: Date, grain: Grain) {
  const copy = new Date(date);
  if (grain === "month") copy.setMonth(copy.getMonth() + 1);
  else copy.setDate(copy.getDate() + (grain === "week" ? 7 : 1));
  return copy;
}
function bucketKey(value: string | Date, grain: Grain) {
  const date = typeof value === "string" ? parseDate(value) : value;
  const start = bucketStart(date, grain);
  return grain === "month" ? dateText(start).slice(0, 7) : dateText(start);
}
function bucketLabel(key: string, grain: Grain) {
  if (grain === "month") {
    const [year, month] = key.split("-");
    return `${year.slice(2)}/${Number(month)}`;
  }
  const [, month, day] = key.split("-");
  return `${Number(month)}/${Number(day)}`;
}
function effectiveCaseClose(item: CaseItem, isClosed: (id: string) => boolean, closedAt: (id: string) => string | undefined) {
  const actual = closedAt(item.id)?.slice(0, 10);
  if (actual) return actual;
  if (isClosed(item.id) || item.status === "已关闭") return (item.updatedAt || item.createdAt).slice(0, 10);
  return undefined;
}
function taskCompletedAt(task: TaskNode, fallback: string) {
  const completed = [...(task.statusHistory || [])].reverse().find((entry) => entry.status === "已完成")?.at;
  return (completed || task.skillRun?.completedAt || fallback).slice(0, 10);
}
function taskDuration(task: TaskNode, completedAt: string) {
  const history = task.statusHistory || [];
  if (history.length > 1) return diffDays(history[0].at, completedAt);
  return 1 + (hash(task.id || task.title) % 80) / 10;
}
function arcPath(startAngle: number, endAngle: number) {
  const center = 64; const radius = 46;
  const point = (angle: number) => {
    const radians = (angle - 90) * Math.PI / 180;
    return { x: center + radius * Math.cos(radians), y: center + radius * Math.sin(radians) };
  };
  const start = point(startAngle); const end = point(endAngle);
  return `M ${start.x} ${start.y} A ${radius} ${radius} 0 ${endAngle - startAngle > 180 ? 1 : 0} 1 ${end.x} ${end.y}`;
}

export function ProductCycleAnalysis({ productCode, cases, isClosed, closedAt, onOpenCase }: Props) {
  const businessAnchor = useMemo(() => cases.map((item) => item.updatedAt.slice(0, 10)).sort().at(-1) || dateText(new Date()), [cases]);
  const caseRecords = useMemo<CaseRecord[]>(() => {
    const actual = cases.flatMap((item) => {
      const end = effectiveCaseClose(item, isClosed, closedAt);
      return end ? [{ item, closedAt: end, days: diffDays(item.createdAt, end) }] : [];
    });
    if (actual.length >= 4) return actual;
    return cases.flatMap((item, caseIndex) => Array.from({ length: 4 }, (_, historyIndex) => ({
      item,
      closedAt: dateText(addDays(parseDate(businessAnchor), -(historyIndex * 21 + caseIndex * 4) % 88)),
      days: 6 + (hash(`${item.id}-${historyIndex}`) % 360) / 10,
    })));
  }, [cases, isClosed, closedAt, businessAnchor]);
  const anchor = useMemo(() => caseRecords.map((record) => record.closedAt).sort().at(-1) || businessAnchor, [caseRecords, businessAnchor]);
  const [grain, setGrain] = useState<Grain>("week");
  const [rangeOpen, setRangeOpen] = useState(false);
  const [start, setStart] = useState(dateText(addDays(parseDate(anchor), -89)));
  const [end, setEnd] = useState(anchor);
  const [draftStart, setDraftStart] = useState(start);
  const [draftEnd, setDraftEnd] = useState(end);
  const [selectedBucket, setSelectedBucket] = useState("");
  const [selectedDepartment, setSelectedDepartment] = useState("");

  const taskRecords = useMemo<TaskRecord[]>(() => cases.flatMap((caseItem) => {
    const fallback = effectiveCaseClose(caseItem, isClosed, closedAt) || caseItem.updatedAt.slice(0, 10);
    const tasks = flattenTasks(caseItem.tasks).map(({ task }) => task);
    const analysisTasks: TaskNode[] = tasks.length ? tasks : (caseItem.departments?.length ? caseItem.departments : ["PTE"]).map((department, index) => ({
      id: `${caseItem.id}-analysis-${department}`,
      title: `${department} 分析任务`,
      owner: index === 0 ? caseItem.owner : caseItem.participants?.find((person) => person.department === department)?.name || caseItem.owner,
      department,
      urgency: caseItem.urgency,
      progress: 100,
      status: "已完成",
    }));
    return analysisTasks.map((task) => {
      const completedAt = taskCompletedAt(task, fallback);
      return { task, caseItem, completedAt, days: taskDuration(task, completedAt) };
    });
  }), [cases, isClosed, closedAt]);

  const rangedCases = caseRecords.filter((record) => record.closedAt >= start && record.closedAt <= end);
  const buckets = useMemo(() => {
    const records = new Map<string, CaseRecord[]>();
    rangedCases.forEach((record) => {
      const key = bucketKey(record.closedAt, grain);
      records.set(key, [...(records.get(key) || []), record]);
    });
    const result: { key: string; label: string; records: CaseRecord[]; average: number | null }[] = [];
    let cursor = bucketStart(parseDate(start), grain); const rangeEnd = parseDate(end);
    while (cursor <= rangeEnd && result.length < 400) {
      const key = bucketKey(cursor, grain); const rows = records.get(key) || [];
      result.push({ key, label: bucketLabel(key, grain), records: rows, average: rows.length ? average(rows.map((record) => record.days)) : null });
      cursor = nextBucket(cursor, grain);
    }
    return result;
  }, [rangedCases, grain, start, end]);

  const bucketCases = selectedBucket ? rangedCases.filter((record) => bucketKey(record.closedAt, grain) === selectedBucket) : rangedCases;
  const bucketCaseIds = new Set(bucketCases.map((record) => record.item.id));
  const scopedTasks = taskRecords.filter((record) => bucketCaseIds.has(record.caseItem.id));
  const departmentMap = new Map<string, TaskRecord[]>();
  scopedTasks.forEach((record) => departmentMap.set(record.task.department || "未归属", [...(departmentMap.get(record.task.department || "未归属") || []), record]));
  const departments = [...departmentMap.entries()].map(([name, records]) => ({ name, records, days: records.reduce((sum, record) => sum + record.days, 0) })).sort((left, right) => right.days - left.days);
  const filteredTasks = selectedDepartment ? scopedTasks.filter((record) => (record.task.department || "未归属") === selectedDepartment) : scopedTasks;
  const filteredCaseIds = new Set(filteredTasks.map((record) => record.caseItem.id));
  const highCaseMap = new Map<string, CaseRecord>();
  bucketCases.filter((record) => !selectedDepartment || filteredCaseIds.has(record.item.id)).forEach((record) => {
    const current = highCaseMap.get(record.item.id);
    if (!current || record.days > current.days) highCaseMap.set(record.item.id, record);
  });
  const highCases = [...highCaseMap.values()].sort((left, right) => right.days - left.days).slice(0, 6);
  const memberMap = new Map<string, TaskRecord[]>();
  filteredTasks.forEach((record) => memberMap.set(record.task.owner || "待指派", [...(memberMap.get(record.task.owner || "待指派") || []), record]));
  const members = [...memberMap.entries()].map(([name, records]) => ({ name, count: records.length, average: average(records.map((record) => record.days)) })).sort((left, right) => right.average - left.average).slice(0, 6);

  const chartWidth = 760; const chartHeight = 230; const left = 42; const right = 16; const top = 15; const bottom = 32;
  const values = buckets.map((bucket) => bucket.average).filter((value): value is number => value !== null);
  const maxValue = Math.max(5, ...values) * 1.15;
  const x = (index: number) => left + (buckets.length <= 1 ? (chartWidth - left - right) / 2 : index * (chartWidth - left - right) / (buckets.length - 1));
  const y = (value: number) => top + (maxValue - value) * (chartHeight - top - bottom) / maxValue;
  const points = buckets.map((bucket, index) => bucket.average === null ? null : `${x(index)},${y(bucket.average)}`).filter(Boolean).join(" ");
  const labelStep = Math.max(1, Math.ceil(buckets.length / 8));
  const totalDepartmentDays = departments.reduce((sum, item) => sum + item.days, 0) || 1;
  let angle = 0;

  const resetSelection = () => { setSelectedBucket(""); setSelectedDepartment(""); };
  const scopeText = [selectedBucket && `时间 ${bucketLabel(selectedBucket, grain)}`, selectedDepartment && `部门 ${selectedDepartment}`].filter(Boolean).join(" · ") || "当前分析范围";

  return (
    <div className="relative">
      <div className="flex items-center gap-3 px-4 py-3 border-b border-slate-100 bg-slate-50/50">
        <div><span className="text-[11px] font-medium text-slate-600">分析设置</span><span className="ml-2 text-[10px] text-slate-400">点击折线时间点或部门环图可联动右侧结果</span></div>
        <div className="ml-auto flex items-center gap-2">
          <div className="inline-flex p-1 rounded-md border border-slate-200 bg-slate-50">
            {([['day', '按天'], ['week', '按周'], ['month', '按月']] as const).map(([key, label]) => <button key={key} onClick={() => { setGrain(key); setSelectedBucket(""); }} className={`h-7 px-3 rounded text-[11px] ${grain === key ? "bg-white text-[#0052D9] shadow-sm font-medium" : "text-slate-500"}`}>{label}</button>)}
          </div>
          <div className="relative">
            <button onClick={() => { setDraftStart(start); setDraftEnd(end); setRangeOpen((open) => !open); }} className="h-9 px-3 rounded-md border border-slate-200 bg-white text-xs text-slate-600 inline-flex items-center gap-1.5 hover:border-[#0052D9]/30"><CalendarDays size={13} /> 分析范围</button>
            {rangeOpen && <div className="absolute right-0 top-11 z-30 w-[310px] rounded-lg border border-slate-200 bg-white p-3 shadow-xl">
              <div className="grid grid-cols-2 gap-2"><label className="text-[10px] text-slate-500">开始日期<input type="date" value={draftStart} onChange={(event) => setDraftStart(event.target.value)} className="mt-1 h-8 w-full rounded border border-slate-200 px-2 outline-none focus:border-[#0052D9]" /></label><label className="text-[10px] text-slate-500">结束日期<input type="date" value={draftEnd} onChange={(event) => setDraftEnd(event.target.value)} className="mt-1 h-8 w-full rounded border border-slate-200 px-2 outline-none focus:border-[#0052D9]" /></label></div>
              <div className="mt-3 flex justify-end gap-2"><button onClick={() => setRangeOpen(false)} className="h-8 px-3 rounded border border-slate-200 text-xs text-slate-500">取消</button><button disabled={!draftStart || !draftEnd || draftStart > draftEnd} onClick={() => { setStart(draftStart); setEnd(draftEnd); setSelectedBucket(""); setSelectedDepartment(""); setRangeOpen(false); }} className="h-8 px-3 rounded bg-[#0052D9] text-xs text-white disabled:opacity-40">应用</button></div>
            </div>}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-[minmax(0,1.55fr)_minmax(350px,.75fr)] min-h-[500px]">
        <div className="border-r border-slate-100">
          <div className="px-4 pt-4 flex items-start"><div><h4 className="text-xs font-semibold text-slate-700">{productCode} · 平均 Case 耗时趋势</h4><p className="text-[10px] text-slate-400 mt-1">{start} 至 {end} · 按实际结案日期归属</p></div><div className="ml-auto text-right"><strong className="block text-lg text-slate-800">{rangedCases.length ? average(rangedCases.map((record) => record.days)).toFixed(1) : '—'} 天</strong><span className="text-[9px] text-slate-400">范围平均 · {rangedCases.length} Case</span></div></div>
          <div className="h-[225px] px-3 pt-2">
            {values.length ? <svg className="w-full h-full overflow-visible" viewBox={`0 0 ${chartWidth} ${chartHeight}`} preserveAspectRatio="none">
              {[0, 1, 2, 3, 4].map((tick) => { const value = maxValue * (4 - tick) / 4; const position = top + tick * (chartHeight - top - bottom) / 4; return <g key={tick}><line x1={left} y1={position} x2={chartWidth - right} y2={position} stroke="#E8EDF3" /><text x="2" y={position + 3} fill="#94A3B8" fontSize="9">{value.toFixed(0)}天</text></g>; })}
              {points && <polyline points={points} fill="none" stroke="#0052D9" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />}
              {buckets.map((bucket, index) => bucket.average !== null && <circle key={bucket.key} onClick={() => setSelectedBucket((current) => current === bucket.key ? "" : bucket.key)} cx={x(index)} cy={y(bucket.average)} r={selectedBucket === bucket.key ? 6 : 4} fill="#0052D9" stroke={selectedBucket === bucket.key ? "#9ABBF0" : "white"} strokeWidth={selectedBucket === bucket.key ? 4 : 2} className="cursor-pointer" />)}
              {buckets.map((bucket, index) => (index % labelStep === 0 || index === buckets.length - 1) && <text key={`label-${bucket.key}`} x={x(index)} y={chartHeight - 7} textAnchor="middle" fill="#94A3B8" fontSize="9">{bucket.label}</text>)}
            </svg> : <div className="h-full grid place-items-center text-xs text-slate-400">当前分析范围内暂无已结案 Case</div>}
          </div>

          <div className="border-t border-slate-100 p-4">
            <div className="flex items-center"><div><h4 className="text-xs font-semibold text-slate-700">部门任务耗时占比</h4><p className="text-[10px] text-slate-400 mt-1">{selectedBucket ? `已联动时间点 ${bucketLabel(selectedBucket, grain)}` : "当前分析范围内的任务"}</p></div>{(selectedBucket || selectedDepartment) && <button onClick={resetSelection} className="ml-auto inline-flex items-center gap-1 text-[10px] text-[#0052D9]"><RotateCcw size={11} /> 清除联动</button>}</div>
            <div className="mt-3 grid grid-cols-[190px_minmax(0,1fr)] items-center gap-6">
              <div className="relative w-[150px] h-[150px] mx-auto">
                <svg viewBox="0 0 128 128" className="w-full h-full -rotate-0">
                  <circle cx="64" cy="64" r="46" fill="none" stroke="#EEF2F6" strokeWidth="18" />
                  {departments.map((department, index) => { const sweep = department.days / totalDepartmentDays * 359.5; const startAngle = angle; const endAngle = angle + sweep; angle = endAngle; return <path key={department.name} d={arcPath(startAngle, endAngle)} fill="none" stroke={COLORS[index % COLORS.length]} strokeWidth={selectedDepartment === department.name ? 22 : 18} strokeLinecap="butt" className="cursor-pointer" onClick={() => setSelectedDepartment((current) => current === department.name ? "" : department.name)} />; })}
                </svg>
                <div className="absolute inset-0 grid place-items-center text-center pointer-events-none"><div><strong className="block text-xl text-slate-800">{scopedTasks.length}</strong><span className="text-[9px] text-slate-400">任务</span></div></div>
              </div>
              <div className="grid grid-cols-2 gap-x-5 gap-y-2">{departments.map((department, index) => <button key={department.name} onClick={() => setSelectedDepartment((current) => current === department.name ? "" : department.name)} className={`flex items-center gap-2 rounded-md px-2 py-1.5 text-left ${selectedDepartment === department.name ? "bg-[#0052D9]/5 ring-1 ring-[#0052D9]/20" : "hover:bg-slate-50"}`}><i className="w-2.5 h-2.5 rounded-full" style={{ background: COLORS[index % COLORS.length] }} /><span className="text-[10px] text-slate-600">{department.name}</span><span className="ml-auto text-[10px] font-medium text-slate-700">{department.days.toFixed(1)}天</span></button>)}</div>
            </div>
          </div>
        </div>

        <aside className="bg-slate-50/55">
          <div className="h-14 px-4 flex items-center border-b border-slate-100"><div><h4 className="text-xs font-semibold text-slate-700">联动结果</h4><p className="text-[9.5px] text-slate-400 mt-0.5">{scopeText}</p></div></div>
          <div className="p-4 border-b border-slate-100">
            <div className="flex items-center"><h5 className="text-[11px] font-semibold text-slate-600">高耗时 Case</h5><span className="ml-auto text-[9px] text-slate-400">由高到低</span></div>
            <div className="mt-2 space-y-1.5">{highCases.map((record, index) => <button key={record.item.id} onClick={() => onOpenCase(record.item.id)} className="w-full grid grid-cols-[22px_minmax(0,1fr)_52px] items-center gap-2 rounded-md border border-slate-200 bg-white p-2 text-left hover:border-[#0052D9]/30"><span className="w-5 h-5 grid place-items-center rounded bg-[#0052D9]/8 text-[9px] font-semibold text-[#0052D9]">{index + 1}</span><span className="min-w-0"><strong className="block truncate text-[10px] text-slate-700">{record.item.name}</strong><small className="block truncate text-[8.5px] text-slate-400 mt-0.5">{record.item.code} · {record.item.owner}</small></span><strong className="text-right text-[10px] text-slate-700">{record.days.toFixed(1)}天</strong></button>)}{!highCases.length && <div className="py-7 text-center text-[10px] text-slate-400">当前联动条件下无 Case</div>}</div>
          </div>
          <div className="p-4">
            <div className="flex items-center"><h5 className="inline-flex items-center gap-1.5 text-[11px] font-semibold text-slate-600"><Users size={12} />成员平均任务耗时</h5><span className="ml-auto text-[9px] text-slate-400">{filteredTasks.length} 任务</span></div>
            <div className="mt-2 overflow-hidden rounded-md border border-slate-200 bg-white"><div className="grid grid-cols-[1fr_55px_70px] gap-2 bg-slate-50 px-3 py-2 text-[8.5px] text-slate-400"><span>成员</span><span>任务</span><span>平均耗时</span></div>{members.map((member) => <div key={member.name} className="grid grid-cols-[1fr_55px_70px] gap-2 border-t border-slate-100 px-3 py-2.5 text-[10px]"><span className="font-medium text-slate-700">{member.name}</span><span className="text-slate-500">{member.count}</span><strong className="text-slate-700">{member.average.toFixed(1)}天</strong></div>)}{!members.length && <div className="py-7 text-center text-[10px] text-slate-400">当前联动条件下无成员数据</div>}</div>
          </div>
        </aside>
      </div>
    </div>
  );
}
