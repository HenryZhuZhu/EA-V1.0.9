import { useRef, useState } from "react";
import { Ban } from "lucide-react";
import { TaskDialog } from "./TaskDialog";

export function TerminateTaskModal({ title, onClose, onConfirm }: {
  title: string;
  onClose: () => void;
  onConfirm: (reason: string) => void;
}) {
  const [reason, setReason] = useState("");
  const [error, setError] = useState("");
  const submitting = useRef(false);
  const confirm = () => {
    if (!reason.trim() || submitting.current) return;
    submitting.current = true;
    try { onConfirm(reason.trim()); onClose(); }
    catch (cause) { setError(cause instanceof Error ? cause.message : "中止失败，请重试。"); }
    finally { submitting.current = false; }
  };
  return <TaskDialog title="中止任务" description="确认后任务将标记为已中止，不再继续执行。已保存的 Workspace 文档及附件会保留。" onClose={onClose} footer={<>
    <button type="button" onClick={onClose} className="h-9 rounded-md border border-slate-200 bg-white px-4 text-xs text-slate-600 hover:bg-slate-50">取消</button>
    <button type="button" onClick={confirm} disabled={!reason.trim()} className="inline-flex h-9 items-center gap-1.5 rounded-md border border-red-200 bg-red-50/60 px-4 text-xs font-medium text-red-600 hover:bg-red-50 disabled:cursor-not-allowed disabled:opacity-40"><Ban size={13} />确认中止</button>
  </>}>
    <div className="mb-4 rounded-lg border border-slate-200 bg-slate-50 px-3 py-3 text-sm text-slate-700">{title}</div>
    <label className="block text-xs font-medium text-slate-600">中止原因 <span className="text-red-400">*</span><textarea autoFocus required aria-label="中止原因" value={reason} onChange={(event) => { setReason(event.target.value); setError(""); }} placeholder="请说明不再继续执行此任务的原因" className="mt-2 min-h-[110px] w-full rounded-lg border border-slate-200 px-3 py-2.5 text-sm font-normal leading-relaxed outline-none focus:border-[#0052D9]" /></label>
    {error && <p role="alert" className="mt-3 text-xs text-red-600">{error}</p>}
  </TaskDialog>;
}