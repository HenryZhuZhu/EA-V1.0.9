import { useRef, useState } from "react";
import { ClipboardCheck } from "lucide-react";
import { Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis } from "recharts";
import type { CaseItem, TaskNode } from "./data";
import type { ClosureRecord } from "./closures";
import { calculateCaseScore } from "./caseScoreModel";
import { HoverCard, HoverCardContent, HoverCardTrigger } from "./ui/hover-card";

export function CaseScore({ record, tasks = record.tasks, closure, compact = false }: {
  record: CaseItem; tasks?: TaskNode[]; closure?: ClosureRecord; compact?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const dismissed = useRef(false);
  const dismiss = () => { dismissed.current = true; setOpen(false); };
  const score = calculateCaseScore(record, tasks, closure);
  if (compact) return <span data-case-score={score.total} data-case-id={record.id} role="img" aria-label={`Case 得分 ${score.total} 分`} title="Case 得分" className="inline-flex h-6 w-9 shrink-0 items-center gap-0.5">
    <ClipboardCheck size={12} className="shrink-0 text-slate-400" aria-hidden="true" />
    <span className="min-w-[3ch] text-left text-xs font-medium tabular-nums text-slate-600">{score.total}</span>
  </span>;
  return <HoverCard open={open} onOpenChange={next => { if (!next || !dismissed.current) setOpen(next); }} openDelay={180} closeDelay={160}>
    <HoverCardTrigger asChild>
      <button type="button" data-case-score={score.total} data-case-id={record.id}
        aria-label={`Case 得分 ${score.total} 分，查看评分依据`} aria-expanded={open}
        onPointerEnter={() => { dismissed.current = false; }}
        onFocus={() => { dismissed.current = false; }}
        onClick={event => { event.stopPropagation(); dismissed.current = false; setOpen(true); }}
        onKeyDown={event => { if (event.key === "Escape") { event.preventDefault(); dismiss(); } }}
        className="group/score flex h-5 w-full shrink-0 cursor-pointer items-center justify-between gap-2 rounded-sm text-left outline-none focus-visible:ring-2 focus-visible:ring-[#0052D9]/40">
        <span className="whitespace-nowrap text-xs text-slate-400">Case 得分</span>
        <span className="inline-flex h-5 items-center">
          <span className="min-w-[3ch] text-right text-xs font-medium tabular-nums text-slate-600 underline decoration-slate-300 underline-offset-4 transition-colors group-hover/score:text-[#0052D9] group-hover/score:decoration-[#0052D9]">{score.total}</span>
        </span>
      </button>
    </HoverCardTrigger>
    <HoverCardContent role="region" aria-label="Case 六维评分依据" side="left" align="start" sideOffset={10} collisionPadding={12}
      onEscapeKeyDown={dismiss}
      onKeyDown={event => { if (event.key === "Escape") { event.preventDefault(); dismiss(); } }}
      style={{ maxHeight: "min(680px, var(--radix-hover-card-content-available-height))" }}
      className="z-[90] w-[360px] max-w-[calc(100vw-24px)] overflow-y-auto border-slate-200 bg-white p-4 shadow-lg">
      <div className="flex items-center justify-between gap-3"><h4 className="text-sm font-medium text-slate-800">Case 得分依据</h4><span className="text-[10px] text-slate-400">原型试算</span></div>
      <div className="mt-1 truncate text-[11px] text-slate-500" title={record.name}>{record.name}</div>
      <div role="img" aria-label={`六边形评分图：${score.dimensions.map(dimension => `${dimension.label} ${dimension.value} 分`).join("，")}`} className="mx-auto h-[220px] w-[320px] max-w-full">
        <RadarChart width={320} height={220} cx={160} cy={110} outerRadius={72} data={score.dimensions}>
          <PolarGrid gridType="polygon" stroke="#e2e8f0" />
          <PolarAngleAxis dataKey="label" tick={{ fontSize: 11, fill: "#64748b" }} />
          <PolarRadiusAxis domain={[0, 100]} ticks={[0, 25, 50, 75, 100]} tick={false} axisLine={false} />
          <Radar dataKey="value" stroke="#0052D9" strokeWidth={2} fill="#00A4FF" fillOpacity={0.18} dot={{ r: 3, fill: "#0052D9" }} isAnimationActive={false} />
        </RadarChart>
      </div>
      <dl className="divide-y divide-slate-100 border-t border-slate-100">
        {score.dimensions.map(dimension => <div key={dimension.label} className="py-2">
          <div className="flex items-center gap-2 text-xs"><dt className="font-medium text-slate-700">{dimension.label}</dt><span className="text-[10px] text-slate-400">权重 {dimension.weight}%</span><dd className="ml-auto tabular-nums font-medium text-slate-600">{dimension.value}</dd></div>
          <div className="mt-0.5 text-[11px] leading-4 text-slate-500">{dimension.basis}</div>
        </div>)}
      </dl>
      <div className="flex items-center justify-between border-t border-slate-200 pt-2 text-xs"><span className="text-slate-600">加权总分</span><span className="font-medium tabular-nums text-slate-700">{score.total}</span></div>
      <p className="mt-2 text-[10px] leading-4 text-slate-400">基于当前记录完整度，不代表结论正确性或绩效评价。</p>
    </HoverCardContent>
  </HoverCard>;
}