import { ArrowDownUp } from "lucide-react";

export interface WorkbenchSortOption { value: string; label: string }
const chevron = { backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%2394a3b8' stroke-width='2'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E\")", backgroundRepeat: "no-repeat", backgroundPosition: "right 6px center" };

// 分析中心、我的 Case 与任务双栏共用排序入口；选择不计作筛选条件。
export function WorkbenchSort({ value, options, onChange, ariaLabel = "排序" }: {
  value: string; options: readonly WorkbenchSortOption[]; onChange: (value: string) => void; ariaLabel?: string;
}) {
  return <label className="inline-flex h-8 min-w-0 shrink-0 items-center gap-1 rounded-lg border border-slate-200 bg-white pl-2.5 pr-0.5 text-xs transition-colors">
    <ArrowDownUp size={12} className="shrink-0 text-slate-400" /><span className="shrink-0 text-slate-400">排序</span>
    <select aria-label={ariaLabel} title={options.find(option => option.value === value)?.label} value={value} onChange={event => { if (options.some(option => option.value === event.target.value)) onChange(event.target.value); }} className="h-7 min-w-0 max-w-[130px] cursor-pointer appearance-none bg-transparent pl-1 pr-5 text-xs text-slate-700 outline-none focus-visible:ring-2 focus-visible:ring-[#0052D9]/30" style={chevron}>
      {options.map(option => <option key={option.value} value={option.value} className="font-normal text-slate-700">{option.label}</option>)}
    </select>
  </label>;
}