import { useRef, useState, type ReactNode } from "react";
import * as Tabs from "@radix-ui/react-tabs";
import { Crown, ListRestart, Send } from "lucide-react";
import { currentUser, mockProducts, type CaseItem } from "./data";
import { updateStandaloneTaskStatus, type StandaloneTask } from "./standaloneTasks";
import { loadCaseTaskTree, respondToCaseTask, useCaseTaskRevision } from "./caseTaskTrees";
import { useClosures } from "./closures";
import { RejectTaskModal } from "./RejectTaskModal";
import { TaskStatusSummary } from "./TaskStatusSummary";
import { TaskSourceColumn } from "./TaskSourceColumn";
import { buildWorkbenchTasks, type WorkbenchTask } from "./taskWorkbenchModel";
import { createTaskWorkbenchState, selectTaskWorkbenchOverview, updateTaskWorkbenchState, type TaskWorkbenchAction } from "./taskWorkbenchState";

const SCOPES = [
  { key: "mine", label: "我负责", Icon: Crown },
  { key: "assigned", label: "我分派", Icon: Send },
] as const;

export function MyTaskWorkbench({ cases, tasks, onOpenTask, onOpenCase, onOpenStandaloneTask, embedded = false, recoveryPanel, recoveryCount = 0 }: {
  cases: CaseItem[]; tasks: StandaloneTask[];
  embedded?: boolean;
  recoveryPanel?: ReactNode; recoveryCount?: number;
  onOpenTask: (caseId: string, taskId: string) => void;
  onOpenCase: (id: string) => void; onOpenStandaloneTask: (id: string) => void;
}) {
  const [workbench, setWorkbench] = useState(createTaskWorkbenchState);
  const [scope, setScope] = useState<"mine" | "assigned" | "recovery">("mine");
  const [rejectingKey, setRejectingKey] = useState<string | null>(null);
  const [error, setError] = useState("");
  const lastTaskScope = useRef<"mine" | "assigned">("mine");
  const showingRecovery = scope === "recovery" && Boolean(recoveryPanel);
  const taskScope = scope === "recovery" ? lastTaskScope.current : scope;
  useCaseTaskRevision();
  const closures = useClosures();
  const rows = buildWorkbenchTasks(cases, tasks, { products: mockProducts, loadTree: c => loadCaseTaskTree(c.id, c.tasks), isClosed: closures.isClosed });
  const rejecting = rows.find(row => row.key === rejectingKey);
  const { counts, scopeCounts, caseRows, standaloneRows } = selectTaskWorkbenchOverview(rows, workbench, taskScope, currentUser.name);
  const dispatch = (action: TaskWorkbenchAction) => { setWorkbench(previous => updateTaskWorkbenchState(previous, action)); setError(""); };
  const commonResetKey = JSON.stringify([workbench.status, taskScope]);
  const openDetail = (row: WorkbenchTask) => {
    if (row.source === "case") onOpenTask(row.caseItem!.id, row.id); else onOpenStandaloneTask(row.id);
  };
  const respond = (row: WorkbenchTask, response: "accept" | "reject", reason?: string) => {
    if (row.source === "case") respondToCaseTask(row.caseItem!.id, row.id, response, reason);
    else updateStandaloneTaskStatus(row.id, response === "accept" ? "进行中" : "已拒绝", reason);
  };
  const takeAction = (row: WorkbenchTask) => {
    if (row.status !== "待接受") { openDetail(row); return; }
    try { respond(row, "accept"); setError(""); } catch (reason) { setError(reason instanceof Error ? reason.message : "操作失败，请重试。"); }
  };

  return <Tabs.Root value={showingRecovery ? "recovery" : taskScope} onValueChange={value => { if (value === "mine" || value === "assigned") { lastTaskScope.current = value; setScope(value); } else if (value === "recovery" && recoveryPanel) setScope(value); }} asChild><div className={`mx-auto flex h-full w-full flex-col gap-5 ${embedded ? "min-h-[480px]" : "min-h-[560px] max-w-[1400px] px-8 py-6"}`}>
    <header className={`flex shrink-0 items-center gap-4 ${embedded ? "justify-end" : "justify-between"}`}>{!embedded && <h1 className="text-xl font-semibold tracking-tight text-slate-900">我的任务</h1>}
      <Tabs.List aria-label="任务人员视角" className="inline-flex shrink-0 gap-1 rounded-lg bg-slate-100 p-1">{SCOPES.map(({ key, label, Icon }) => <Tabs.Trigger key={key} value={key} className="inline-flex h-8 items-center gap-1.5 rounded-md px-3 text-xs text-slate-500 data-[state=active]:bg-white data-[state=active]:font-medium data-[state=active]:text-[#0052D9] data-[state=active]:shadow-sm"><Icon size={12} />{label}<span className="text-[10px] tabular-nums">{scopeCounts[key]}</span></Tabs.Trigger>)}{recoveryPanel && <Tabs.Trigger value="recovery" aria-label="我发起的整改" className="inline-flex h-8 items-center gap-1.5 rounded-md px-3 text-xs text-slate-500 data-[state=active]:bg-white data-[state=active]:font-medium data-[state=active]:text-[#0052D9] data-[state=active]:shadow-sm"><ListRestart size={12} />我发起的整改<span aria-label={`共 ${recoveryCount} 条整改`} title="我发起的整改记录总数" className="text-[10px] tabular-nums">{recoveryCount}</span></Tabs.Trigger>}</Tabs.List>
    </header>
    <div hidden={showingRecovery} className="shrink-0"><TaskStatusSummary counts={counts} status={workbench.status} scope={taskScope} onChange={status => dispatch({ type: "status", status })} /></div>
    <Tabs.Content value={taskScope} forceMount hidden={showingRecovery} style={{ display: showingRecovery ? "none" : undefined }} asChild>
    <section id="task-status-content" aria-label={`${workbench.status}任务内容`} className="flex min-h-0 flex-1 flex-col gap-4">
    {error && <p role="alert" className="shrink-0 rounded-lg bg-red-50 px-3 py-2 text-xs text-red-600">{error}</p>}
    <section aria-label="任务列表" className="grid min-h-0 flex-1 grid-cols-2 gap-4">
      <TaskSourceColumn source="case" rows={caseRows} resetKey={commonResetKey} businessKey="" onShowTask={openDetail} onOpenCase={onOpenCase} onTakeAction={takeAction} onReject={row => setRejectingKey(row.key)} />
      <TaskSourceColumn source="standalone" rows={standaloneRows} resetKey={commonResetKey} businessKey="" onShowTask={openDetail} onOpenCase={onOpenCase} onTakeAction={takeAction} onReject={row => setRejectingKey(row.key)} />
    </section>
    </section>
    </Tabs.Content>
    {recoveryPanel && <Tabs.Content value="recovery" forceMount hidden={!showingRecovery} style={{ display: showingRecovery ? undefined : "none" }} className="min-h-0 flex-1 outline-none">{recoveryPanel}</Tabs.Content>}
    {rejecting && <RejectTaskModal title={rejecting.title} onClose={() => setRejectingKey(null)} onConfirm={reason => { respond(rejecting, "reject", reason); setError(""); }} />}
  </div></Tabs.Root>;
}