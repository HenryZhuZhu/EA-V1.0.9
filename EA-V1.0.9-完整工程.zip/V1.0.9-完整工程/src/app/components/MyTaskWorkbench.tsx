import { useState } from "react";
import * as Tabs from "@radix-ui/react-tabs";
import { Crown, Send } from "lucide-react";
import { currentUser, mockProducts, type CaseItem } from "./data";
import { updateStandaloneTaskStatus, type StandaloneTask } from "./standaloneTasks";
import { loadCaseTaskTree, respondToCaseTask, useCaseTaskRevision } from "./caseTaskTrees";
import { useClosures } from "./closures";
import { RejectTaskModal } from "./RejectTaskModal";
import { TaskStatusSummary } from "./TaskStatusSummary";
import { TaskSourceColumn } from "./TaskSourceColumn";
import { buildWorkbenchTasks, type WorkbenchTask } from "./taskWorkbenchModel";
import { createTaskWorkbenchState, selectTaskWorkbenchOverview, updateTaskWorkbenchState, type TaskWorkbenchAction } from "./taskWorkbenchState";

const SCOPES = [
  { key: "mine", label: "我负责", Icon: Crown },
  { key: "assigned", label: "我分派", Icon: Send },
] as const;

export function MyTaskWorkbench({ cases, tasks, onOpenTask, onOpenCase, onOpenStandaloneTask }: {
  cases: CaseItem[]; tasks: StandaloneTask[];
  onOpenTask: (caseId: string, taskId: string) => void;
  onOpenCase: (id: string) => void; onOpenStandaloneTask: (id: string) => void;
}) {
  const [workbench, setWorkbench] = useState(createTaskWorkbenchState);
  const [scope, setScope] = useState<"mine" | "assigned">("mine");
  const [rejectingKey, setRejectingKey] = useState<string | null>(null);
  const [error, setError] = useState("");
  useCaseTaskRevision();
  const closures = useClosures();
  const rows = buildWorkbenchTasks(cases, tasks, { products: mockProducts, loadTree: c => loadCaseTaskTree(c.id, c.tasks), isClosed: closures.isClosed });
  const rejecting = rows.find(row => row.key === rejectingKey);
  const { counts, scopeCounts, caseRows, standaloneRows } = selectTaskWorkbenchOverview(rows, workbench, scope, currentUser.name);
  const dispatch = (action: TaskWorkbenchAction) => { setWorkbench(previous => updateTaskWorkbenchState(previous, action)); setError(""); };
  const commonResetKey = JSON.stringify([workbench.status, scope]);
  const openDetail = (row: WorkbenchTask) => {
    if (row.source === "case") onOpenTask(row.caseItem!.id, row.id); else onOpenStandaloneTask(row.id);
  };
  const respond = (row: WorkbenchTask, response: "accept" | "reject", reason?: string) => {
    if (row.source === "case") respondToCaseTask(row.caseItem!.id, row.id, response, reason);
    else updateStandaloneTaskStatus(row.id, response === "accept" ? "进行中" : "已拒绝", reason);
  };
  const takeAction = (row: WorkbenchTask) => {
    if (row.status !== "待接受") { openDetail(row); return; }
    try { respond(row, "accept"); setError(""); } catch (reason) { setError(reason instanceof Error ? reason.message : "操作失败，请重试。"); }
  };

  return <Tabs.Root value={scope} onValueChange={value => { if (value === "mine" || value === "assigned") setScope(value); }} asChild><div className="mx-auto flex h-full min-h-[560px] w-full max-w-[1400px] flex-col gap-5 px-8 py-6">
    <header className="flex shrink-0 items-center justify-between gap-4"><h1 className="text-xl font-semibold tracking-tight text-slate-900">我的任务</h1>
      <Tabs.List aria-label="任务人员视角" className="inline-flex shrink-0 gap-1 rounded-lg bg-slate-100 p-1">{SCOPES.map(({ key, label, Icon }) => <Tabs.Trigger key={key} value={key} className="inline-flex h-8 items-center gap-1.5 rounded-md px-3 text-xs text-slate-500 data-[state=active]:bg-white data-[state=active]:font-medium data-[state=active]:text-[#0052D9] data-[state=active]:shadow-sm"><Icon size={12} />{label}<span className="text-[10px] tabular-nums">{scopeCounts[key]}</span></Tabs.Trigger>)}</Tabs.List>
    </header>
    <div className="shrink-0"><TaskStatusSummary counts={counts} status={workbench.status} scope={scope} onChange={status => dispatch({ type: "status", status })} /></div>
    <Tabs.Content value={scope} asChild>
    <section id="task-status-content" aria-label={`${workbench.status}任务内容`} className="flex min-h-0 flex-1 flex-col gap-4">
    {error && <p role="alert" className="shrink-0 rounded-lg bg-red-50 px-3 py-2 text-xs text-red-600">{error}</p>}
    <section aria-label="任务列表" className="grid min-h-0 flex-1 grid-cols-2 gap-4">
      <TaskSourceColumn source="case" rows={caseRows} resetKey={commonResetKey} businessKey="" onShowTask={openDetail} onOpenCase={onOpenCase} onTakeAction={takeAction} onReject={row => setRejectingKey(row.key)} />
      <TaskSourceColumn source="standalone" rows={standaloneRows} resetKey={commonResetKey} businessKey="" onShowTask={openDetail} onOpenCase={onOpenCase} onTakeAction={takeAction} onReject={row => setRejectingKey(row.key)} />
    </section>
    </section>
    </Tabs.Content>
    {rejecting && <RejectTaskModal title={rejecting.title} onClose={() => setRejectingKey(null)} onConfirm={reason => { respond(rejecting, "reject", reason); setError(""); }} />}
  </div></Tabs.Root>;
}