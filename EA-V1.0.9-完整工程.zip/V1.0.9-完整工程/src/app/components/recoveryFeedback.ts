import { useEffect, useState } from "react";
import { currentUser, flattenTasks, managerDeptScope, mockCases } from "./data";
import { allClosureRecords, useClosures } from "./closures";
import { loadCaseTaskTree, useCaseTaskRevision } from "./caseTaskTrees";
import { useStandaloneTasks } from "./standaloneTasks";
import { recoveryDifferences, type RecoveryEntry, type Recoverable } from "./recordRecovery";

export type RecoveryTarget = { kind: "case"; caseId: string } | { kind: "task"; caseId: string; taskId: string } | { kind: "standalone"; taskId: string };
export interface FeedbackRow {
  key: string; title: string; code: string; owner: string; target: RecoveryTarget;
  entry: RecoveryEntry; record: Recoverable; status: string; returns: number; approvalRejected?: boolean;
}
export interface ReminderPolicy { dueSoonDays: number; inactiveDays: number; repeatCount: number }
export const DEFAULT_REMINDERS: ReminderPolicy = { dueSoonDays: 1, inactiveDays: 7, repeatCount: 2 };
const KEY = "ea_v109_feedback_preferences";
type Preferences = { read: Record<string, string>; policies: Record<string, ReminderPolicy> };
let cache: Preferences | undefined;
const listeners = new Set<() => void>();
function load(): Preferences {
  if (!cache) {
    try { const raw = JSON.parse(localStorage.getItem(KEY) ?? "null"); cache = { read: raw?.read && typeof raw.read === "object" ? raw.read : {}, policies: raw?.policies && typeof raw.policies === "object" ? raw.policies : {} }; }
    catch { cache = { read: {}, policies: {} }; }
  }
  return cache!;
}
function persist(next: Preferences) {
  try { localStorage.setItem(KEY, JSON.stringify(next)); } catch { throw new Error("提醒设置保存失败，请重试。"); }
  cache = next; listeners.forEach(listener => listener());
}
export function canViewMyReturns(actor = currentUser.name) { return managerDeptScope(actor).length > 0; }
export function selectMyReturns(rows: FeedbackRow[], actor = currentUser.name) {
  return rows.filter(row => row.target.kind !== "standalone" && row.entry.kind === "return" && row.entry.by === actor);
}
export function feedbackToken(row: FeedbackRow) { return row.entry.submittedAt ?? row.entry.completedAt ?? ""; }
export function feedbackUnread(row: FeedbackRow, actor = currentUser.name) { const token = feedbackToken(row); return Boolean(token) && load().read[`${actor}:${row.key}`] !== token; }
export function markFeedbackRead(row: FeedbackRow) {
  if (row.entry.by !== currentUser.name && row.owner !== currentUser.name && !row.entry.recipients.includes(currentUser.name)) throw new Error("无权查看此反馈。");
  const token = feedbackToken(row); if (!token || !feedbackUnread(row)) return;
  persist({ ...load(), read: { ...load().read, [`${currentUser.name}:${row.key}`]: token } });
}
export function reminderPolicy(actor = currentUser.name): ReminderPolicy { return { ...DEFAULT_REMINDERS, ...load().policies[actor] }; }
export function setReminderPolicy(policy: ReminderPolicy) {
  if (!canViewMyReturns()) throw new Error("仅管理者可以设置监管提醒。");
  for (const [key, value] of Object.entries(policy)) if (!Number.isInteger(value) || value < (key === "dueSoonDays" ? 0 : 1) || value > 90) throw new Error("提醒天数或次数须在有效范围内。");
  persist({ ...load(), policies: { ...load().policies, [currentUser.name]: { ...policy } } });
}
function calendarDay(date: Date) { return Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()); }
export function recoveryProgress(row: FeedbackRow) {
  if (row.approvalRejected && !row.entry.completedAt) return "结案审核驳回";
  if (feedbackToken(row)) return "已提交整改结果";
  if (["已中止", "已拒绝"].includes(row.status)) return `${row.status}（未提交结果）`;
  return row.entry.startedAt ? "处理中" : "待处理";
}
export function recoveryAlerts(row: FeedbackRow, policy: ReminderPolicy = DEFAULT_REMINDERS, now = new Date()) {
  if (row.entry.completedAt || (row.entry.submittedAt && !row.approvalRejected)) return [];
  const alerts: { label: string; level: "warning" | "notice" }[] = [];
  if (row.entry.dueDate) {
    const deadline = new Date(`${row.entry.dueDate}T00:00:00`);
    if (Number.isFinite(deadline.getTime())) {
      const days = (calendarDay(deadline) - calendarDay(now)) / 86400000;
      if (days < 0) alerts.push({ label: `超期 ${-days} 天`, level: "warning" });
      else if (days <= policy.dueSoonDays) alerts.push({ label: days === 0 ? "今日到期" : `${days} 天内到期`, level: "notice" });
    }
  }
  const editedAt = new Date(row.entry.lastEditedAt ?? row.entry.at).getTime();
  if (Number.isFinite(editedAt) && now.getTime() - editedAt >= policy.inactiveDays * 86400000) alerts.push({ label: `${policy.inactiveDays} 天无实质更新`, level: "notice" });
  if (row.returns >= policy.repeatCount) alerts.push({ label: `已退回 ${row.returns} 次`, level: "warning" });
  return alerts;
}
export function feedbackSummary(row: FeedbackRow) {
  if (!feedbackToken(row)) return row.entry.reason;
  const changes = recoveryDifferences(row.entry);
  return changes.length ? changes.map(change => change.field).join("、") + "已更新" : "未记录可比对的内容变化，请查看原文档";
}
export function recoveryNotification(row: FeedbackRow, policy: ReminderPolicy, now = new Date()) {
  if (row.target.kind === "standalone" && row.entry.kind === "return") return null;
  if (row.entry.by !== currentUser.name && row.owner !== currentUser.name && !row.entry.recipients.includes(currentUser.name)) return null;
  const alerts = recoveryAlerts(row, policy, now).map(alert => alert.label);
  const event = feedbackToken(row) ? `submitted:${feedbackToken(row)}` : row.entry.startedAt ? `editing:${row.entry.lastEditedAt}` : `returned:${row.entry.at}`;
  const token = `${event}:${alerts.join(",")}`;
  const key = `notice:${currentUser.name}:${row.key}`;
  const label = alerts.length ? alerts.join(" · ") : feedbackToken(row) ? "已提交整改结果" : row.entry.startedAt ? "已开始修改" : row.entry.kind === "return" ? "收到整改要求" : "主管已重新开启";
  return { row, key, token, label, read: load().read[key] === token };
}
export function markRecoveryNotificationsRead(notices: NonNullable<ReturnType<typeof recoveryNotification>>[]) {
  const next = { ...load().read };
  for (const notice of notices) {
    const actual = recoveryNotification(notice.row, reminderPolicy());
    if (actual && actual.key === notice.key) next[actual.key] = actual.token;
  }
  persist({ ...load(), read: next });
}
export function sortFeedbackRows(rows: FeedbackRow[], policy: ReminderPolicy, now = new Date()) {
  const priority = (row: FeedbackRow) => recoveryAlerts(row, policy, now).some(alert => alert.label.startsWith("超期")) ? 0 : feedbackUnread(row) ? 1 : !feedbackToken(row) ? 2 : 3;
  return [...rows].sort((left, right) => priority(left) - priority(right) || (right.entry.submittedAt ?? right.entry.lastEditedAt ?? right.entry.at).localeCompare(left.entry.submittedAt ?? left.entry.lastEditedAt ?? left.entry.at) || left.key.localeCompare(right.key));
}
export function recoveryCategory(row: FeedbackRow, policy: ReminderPolicy = DEFAULT_REMINDERS, now = new Date()): "following" | "feedback" | "overdue" {
  if (feedbackToken(row) && !(row.approvalRejected && !row.entry.completedAt)) return "feedback";
  return recoveryAlerts(row, policy, now).some(alert => alert.label.startsWith("超期")) ? "overdue" : "following";
}
export function recoveryOverview(rows: FeedbackRow[], policy: ReminderPolicy, query = "", now = new Date()) {
  const text = query.trim().toLowerCase();
  const matching = sortFeedbackRows(rows, policy, now).filter(row => `${row.title} ${row.code} ${row.owner} ${row.entry.reason}`.toLowerCase().includes(text));
  const groups: Record<"following" | "feedback" | "overdue", FeedbackRow[]> = { following: [], feedback: [], overdue: [] };
  for (const row of matching) groups[recoveryCategory(row, policy, now)].push(row);
  return { rows: matching, groups, counts: { following: groups.following.length, feedback: groups.feedback.length, overdue: groups.overdue.length } };
}
export function useRecoveryFeedback() {
  useClosures(); useCaseTaskRevision(); const tasks = useStandaloneTasks();
  const [, setTick] = useState(0);
  useEffect(() => { const listener = () => setTick(value => value + 1); listeners.add(listener); const timer = setInterval(listener, 60000); return () => { listeners.delete(listener); clearInterval(timer); }; }, []);
  const rows: FeedbackRow[] = [];
  const add = (id: string, title: string, code: string, owner: string, target: RecoveryTarget, record: Recoverable, status: string, rejected = false) => {
    let returns = 0;
    for (const entry of record.recovery ?? []) {
      if (entry.kind === "return") returns++;
      if (entry.kind !== "supplement") rows.push({ key: `${id}:${entry.id}`, title, code, owner, target, entry, record, status, returns, approvalRejected: rejected && !entry.completedAt });
    }
  };
  for (const record of allClosureRecords()) {
    const item = mockCases.find(item => item.id === record.caseId);
    if (item) add(`case:${item.id}`, item.name, item.code, item.owner, { kind: "case", caseId: item.id }, record, item.status, record.approval?.kind === "closure" && record.approval.decision === "rejected");
  }
  for (const item of mockCases) for (const { task } of flattenTasks(loadCaseTaskTree(item.id, item.tasks))) if (task.code) add(`task:${item.id}:${task.id}`, task.title, task.code, task.owner, { kind: "task", caseId: item.id, taskId: task.id }, task, task.status);
  for (const task of tasks) if (!task.convertedCaseId) add(`free:${task.id}`, task.title, task.code, task.owner, { kind: "standalone", taskId: task.id }, task, task.status);
  return { rows, policy: reminderPolicy(), myReturns: selectMyReturns(rows) };
}