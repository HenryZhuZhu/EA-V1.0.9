import { DEFAULT_TASK_FILTERS, SUMMARY_STATUSES, defaultTaskSort, groupWorkbenchTasks, paginateTaskGroups, selectWorkbenchTasks, updateWorkbenchFilters, type SummaryStatus, type TaskFilters, type TaskGroupBy, type TaskScope, type TaskSortBy, type TaskSource, type WorkbenchTask } from "./taskWorkbenchModel";

export function taskScopeLabel(status: SummaryStatus, scope: TaskScope) {
  if (scope === "mine") return status === "待接受" ? "待我接受" : "我负责";
  if (scope === "participating") return status === "待接受" ? "待我协作" : "我参与";
  return "我分派";
}

// TF / Project 键仅用于兼容旧内存快照，不再提供或应用这两个筛选。
export interface TaskReferenceFilters { productKey?: string; tfKey?: string; projectKey?: string }
export type TaskColumnFilters = TaskFilters & TaskReferenceFilters;
export const TASK_REFERENCE_FIELDS = [
  { key: "productKey", kind: "产品" },
] as const;
export function taskColumnFilterCount(filters: TaskColumnFilters) {
  return TASK_REFERENCE_FIELDS.reduce((count, field) => count + Number(Boolean(filters[field.key])), 0) + Number(Boolean(filters.caseId)) + Number(Boolean(filters.creator));
}

export interface TaskStatusView {
  filters: TaskColumnFilters & { status: SummaryStatus };
  columnSorts?: Partial<Record<"case" | "standalone", TaskSortBy>>;
  // 兼容旧视图快照；当前页面不读取手动归类、排序偏好。
  groupBy: TaskGroupBy;
  sortBy: TaskSortBy;
  showBusiness: boolean;
  page: number;
}
export interface TaskWorkbenchState {
  status: SummaryStatus;
  views: Record<SummaryStatus, TaskStatusView>;
}
export type TaskWorkbenchAction =
  | { type: "status"; status: SummaryStatus }
  | { type: "column-filters"; patch: Partial<Pick<TaskColumnFilters, "scope" | "businessKind" | "businessKey" | "caseId" | "creator" | "productKey" | "tfKey" | "projectKey">> }
  | { type: "source"; source: TaskSource }
  | { type: "filters"; patch: Partial<TaskFilters> }
  | { type: "group"; groupBy: TaskGroupBy }
  | { type: "sort"; sortBy: TaskSortBy }
  | { type: "column-sort"; source: "case" | "standalone"; sortBy: TaskSortBy }
  | { type: "business" }
  | { type: "page"; page: number }
  | { type: "reset" };

export function createTaskWorkbenchState(): TaskWorkbenchState {
  const view = (status: SummaryStatus): TaskStatusView => ({ filters: { ...DEFAULT_TASK_FILTERS, status }, groupBy: "none", sortBy: defaultTaskSort(status), showBusiness: false, page: 1 });
  return { status: "待接受", views: { 待接受: view("待接受"), 进行中: view("进行中"), 已完成: view("已完成") } };
}

export function taskColumnSorts(state: TaskWorkbenchState): Record<"case" | "standalone", TaskSortBy> {
  const saved = state.views[state.status].columnSorts;
  const resolve = (value?: TaskSortBy) => value && ["priority", "due", "updated"].includes(value) ? value : defaultTaskSort(state.status);
  return { case: resolve(saved?.case), standalone: resolve(saved?.standalone) };
}

function currentFilters(filters: TaskFilters, status: SummaryStatus): TaskStatusView["filters"] {
  return { ...filters, status, caseId: filters.source === "case" ? filters.caseId : "", query: "", showUpgraded: false };
}

export function canFilterWorkbenchCases(filters: TaskFilters) {
  // Case Tab 的字段固定，不随人员关系或候选数量增减。
  return filters.source === "case";
}

export function paginateTaskWorkbench(rows: WorkbenchTask[], state: TaskWorkbenchState, now = new Date()) {
  // 只按主状态默认规则排序，完整结果排序后分页；旧归类、排序快照不再影响列表。
  return paginateTaskGroups(groupWorkbenchTasks(rows, "none", now, "", defaultTaskSort(state.status)), state.views[state.status].page);
}

// 每个主状态独立保留辅助条件和页码；任何辅助操作都不能退出主状态。
export function updateTaskWorkbenchState(state: TaskWorkbenchState, action: TaskWorkbenchAction): TaskWorkbenchState {
  if (action.type === "status") return action.status === state.status ? state : { ...state, status: action.status };
  const current = state.views[state.status];
  let next: TaskStatusView;
  switch (action.type) {
    case "column-sort":
      if (!["case", "standalone"].includes(action.source) || !["priority", "due", "updated"].includes(action.sortBy) || taskColumnSorts(state)[action.source] === action.sortBy) return state;
      next = { ...current, columnSorts: { ...current.columnSorts, [action.source]: action.sortBy } }; break;
    case "column-filters": next = { ...current, filters: { ...current.filters, ...action.patch, tfKey: "", projectKey: "", businessKind: "all", businessKey: "", source: "all", status: state.status, query: "", showUpgraded: false }, page: 1 }; break;
    // 来源是导航 Tab；source 仅沿用读取模型字段，不作为可清除的筛选项。
    case "source":
      if (action.source === current.filters.source) return state;
      next = { ...current, filters: currentFilters(updateWorkbenchFilters(current.filters, { source: action.source }), state.status), page: 1 }; break;
    case "filters": next = { ...current, filters: currentFilters(updateWorkbenchFilters(current.filters, action.patch), state.status), page: 1 }; break;
    case "group": next = { ...current, groupBy: action.groupBy, page: 1 }; break;
    case "sort": next = { ...current, sortBy: action.sortBy, page: 1 }; break;
    case "business": next = { ...current, showBusiness: !current.showBusiness }; break;
    case "page": next = { ...current, page: Math.max(1, Math.floor(action.page)) }; break;
    case "reset": next = { ...current, filters: { ...DEFAULT_TASK_FILTERS, source: current.filters.source, scope: current.filters.scope, status: state.status }, groupBy: "none", sortBy: defaultTaskSort(state.status), page: 1 }; break;
  }
  return { ...state, views: { ...state.views, [state.status]: next } };
}

export function statusViewRows(rows: WorkbenchTask[], status: SummaryStatus) {
  return rows.filter(row => !row.convertedCaseId && row.status === status);
}

export function selectTaskWorkbenchViews(rows: WorkbenchTask[], state: TaskWorkbenchState, actor: string) {
  // 顶部固定统计我负责的全部来源任务，不受下方辅助跟进视角与筛选影响。
  const { counts } = selectWorkbenchTasks(rows, { ...DEFAULT_TASK_FILTERS, scope: "mine", source: "all", status: null, query: "", showUpgraded: false }, actor);
  const filters = currentFilters(state.views[state.status].filters, state.status);
  const selection = selectWorkbenchTasks(statusViewRows(rows, state.status), filters, actor);
  return { counts, selection, filters };
}

// 双栏工作台：来源永远同时展示，不读取旧来源 Tab、分页、归类或手动排序偏好。
export function selectTaskWorkbenchColumns(rows: WorkbenchTask[], state: TaskWorkbenchState, actor: string, now = new Date()) {
  const saved = state.views[state.status].filters;
  const filters: TaskColumnFilters = { ...saved, productKey: saved.productKey ?? "", tfKey: "", projectKey: "", businessKind: "all", businessKey: "", source: "all", status: state.status, query: "", showUpgraded: false };
  const { counts } = selectWorkbenchTasks(rows, { ...DEFAULT_TASK_FILTERS, status: null }, actor);
  // 仅按产品的精确引用筛选；旧 TF / Project 和组合“任务涉及”条件均不生效。
  // 历史任务中的其他业务引用仍由读取模型保留，不修改原始数据。
  const currentRows = statusViewRows(rows, state.status).filter(row => TASK_REFERENCE_FIELDS.every(field => !filters[field.key] || row.business.some(ref => ref.kind === field.kind && ref.key === filters[field.key])));
  const caseSelection = selectWorkbenchTasks(currentRows, { ...filters, source: "case" }, actor);
  const standaloneSelection = selectWorkbenchTasks(currentRows, { ...filters, source: "standalone", caseId: "" }, actor);
  const columnSorts = taskColumnSorts(state);
  const sort = (selected: WorkbenchTask[], source: "case" | "standalone") => groupWorkbenchTasks(selected, "none", now, "", columnSorts[source]).flatMap(group => group.rows);
  const scopeCounts = {
    mine: caseSelection.scopeCounts.mine + standaloneSelection.scopeCounts.mine,
    participating: caseSelection.scopeCounts.participating + standaloneSelection.scopeCounts.participating,
    assigned: caseSelection.scopeCounts.assigned + standaloneSelection.scopeCounts.assigned,
  };
  return { counts, scopeCounts, filters, columnSorts, caseRows: sort(caseSelection.rows, "case"), standaloneRows: sort(standaloneSelection.rows, "standalone") };
}

export function selectTaskWorkbenchOverview(rows: WorkbenchTask[], state: TaskWorkbenchState, scope: "mine" | "assigned", actor: string, now = new Date()) {
  const current = state.views[state.status];
  const clean: TaskWorkbenchState = { ...state, views: { ...state.views, [state.status]: { ...current, columnSorts: undefined, filters: { ...DEFAULT_TASK_FILTERS, status: state.status, scope } } } };
  const selected = selectTaskWorkbenchColumns(rows, clean, actor, now);
  const summaryRows = rows.filter(row => SUMMARY_STATUSES.includes(row.status as SummaryStatus));
  const overview = selectWorkbenchTasks(summaryRows, { ...DEFAULT_TASK_FILTERS, scope, status: null }, actor);
  return { ...selected, counts: overview.counts, scopeCounts: overview.scopeCounts };
}