import { X, MessageSquarePlus, TrendingUp } from "lucide-react";
import { useState } from "react";

interface Props {
  open: boolean;
  onClose: () => void;
}

export function FeedbackPanel({ open, onClose }: Props) {
  const [text, setText] = useState("");
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-end" onClick={onClose}>
      <div className="absolute inset-0 bg-slate-900/20 backdrop-blur-[1px]"></div>
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-[420px] h-full bg-white shadow-2xl flex flex-col"
      >
        <div className="px-5 py-4 border-b border-slate-100 flex items-center">
          <div className="flex items-center gap-2">
            <MessageSquarePlus size={16} className="text-[#0052D9]" />
            <h3 className="text-slate-900">提建议 / 反馈</h3>
          </div>
          <button
            onClick={onClose}
            className="ml-auto w-7 h-7 rounded hover:bg-slate-100 flex items-center justify-center text-slate-500"
          >
            <X size={14} />
          </button>
        </div>

        <div className="p-5 flex-1 overflow-y-auto space-y-4">
          <div className="flex items-center gap-2 p-3 rounded-md bg-gradient-to-br from-[#0052D9]/5 to-[#00A4FF]/5 border border-[#0052D9]/20">
            <TrendingUp size={14} className="text-[#0052D9]" />
            <div className="text-xs text-slate-700">
              已收集 <b className="text-[#0052D9]">147</b> 条建议 · 本周新增 <b>9</b> · 用心使用的人一定能提出改进意见。
            </div>
          </div>

          <div>
            <div className="text-sm text-slate-700 mb-2">建议类型</div>
            <div className="flex flex-wrap gap-1.5">
              {["交互改进", "功能缺失", "Bug 反馈", "性能问题", "AI 能力", "其他"].map((t, i) => (
                <button
                  key={t}
                  className={`px-2.5 py-1 rounded text-xs border ${
                    i === 0
                      ? "bg-[#0052D9] text-white border-[#0052D9]"
                      : "border-slate-200 text-slate-600 hover:bg-slate-50"
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          <div>
            <div className="text-sm text-slate-700 mb-2">描述</div>
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="请描述你的建议或问题，最好包含复现步骤或期望行为..."
              className="w-full min-h-[140px] p-3 text-sm rounded-md border border-slate-200 bg-slate-50/60 focus:bg-white focus:border-[#0052D9] outline-none resize-y"
            />
          </div>

          <div>
            <div className="text-sm text-slate-700 mb-2">最近建议</div>
            <div className="space-y-2">
              {[
                { u: "李娜", t: "希望任务卡片支持批量切换负责人" },
                { u: "陈磊", t: "EFA 部门希望 AI 汇总分段展示" },
                { u: "王芳", t: "思维导图节点支持折叠" },
              ].map((m, i) => (
                <div key={i} className="p-2.5 rounded border border-slate-100 text-sm">
                  <div className="text-xs text-slate-500">{m.u} · 已采纳</div>
                  <div className="text-slate-700 mt-0.5">{m.t}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="p-4 border-t border-slate-100 flex gap-2">
          <button
            onClick={onClose}
            className="flex-1 h-9 rounded-md border border-slate-200 text-sm text-slate-700 hover:bg-slate-50"
          >
            取消
          </button>
          <button
            onClick={onClose}
            className="flex-1 h-9 rounded-md bg-[#0052D9] text-white text-sm hover:bg-[#003FA8]"
          >
            提交建议
          </button>
        </div>
      </div>
    </div>
  );
}
