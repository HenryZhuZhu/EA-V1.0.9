import { CalendarCheck, CalendarClock, Crown, GitBranch, ListChecks } from "lucide-react";
import { levelColors } from "./data";
import { CaseProductPill } from "./CaseProductPill";
import { CaseMarkCodePill } from "./CaseMarkCodePill";
import { CaseStatusBadge } from "./CaseStatusBadge";
import { taskRemainingDays } from "./taskWorkbenchModel";
import type { CaseWorkbenchRow } from "./caseWorkbenchModel";
import { RecoveryBadge } from "./RecoveryControls";

export function WorkbenchCaseCard({ row, onOpenCase }: { row: CaseWorkbenchRow; onOpenCase: (id: string) => void }) {
  const c = row.record;
  const days = taskRemainingDays(c);
  const due = days == null ? "未设置截止日期" : days > 0 ? `${days} 天到期` : days === 0 ? "今日到期" : `已逾期 ${-days} 天`;
  const urgency = c.urgency === "非常紧急" ? "#FF3B30" : c.urgency === "紧急" ? "#FF9500" : c.urgency === "一般" ? "#38BDF8" : "#94A3B8";
  return <article aria-label={c.name} className="group relative min-w-0 overflow-hidden rounded-xl border border-slate-200/80 bg-white transition-all hover:border-[#0052D9]/40 hover:shadow-[0_8px_24px_-12px_rgba(0,82,217,0.25)]">
    <span aria-hidden="true" className="absolute bottom-5 left-0 top-5 w-1 rounded-r" style={{ background: urgency }} />
    <button type="button" aria-label={`查看 Case ${c.name}`} onClick={() => onOpenCase(c.id)} className="block w-full p-5 text-left focus-visible:outline-2 focus-visible:outline-inset focus-visible:outline-[#0052D9]">
      <div className="mb-3 flex flex-wrap items-center gap-2">
        <span className={`rounded border px-1.5 py-0.5 text-[10px] ${levelColors[c.level]}`}>{c.level}</span>
        <CaseProductPill caseItem={c} compact /><CaseMarkCodePill caseItem={c} compact />
        {row.fanout && <span className="inline-flex items-center gap-1 rounded border border-[#00A4FF]/25 bg-[#00A4FF]/10 px-1.5 py-0.5 text-[10px] font-medium text-[#0284c7]"><GitBranch size={10} />Fanout</span>}
        <CaseStatusBadge status={row.status} />
        <RecoveryBadge record={row} />
        <span className="ml-auto font-mono text-[11px] tracking-wide text-slate-400">{c.code}</span>
      </div>
      <div title={c.name} className="line-clamp-1 text-[15px] leading-snug text-slate-900 transition-colors group-hover:text-[#0052D9]">{c.name}</div>
      <div className="mt-1.5 line-clamp-2 text-xs leading-relaxed text-slate-500">{c.reason || c.background || "—"}</div>
      <div className="mt-4 flex flex-wrap items-center gap-4 border-t border-dashed border-slate-200 pt-3 text-[11px] text-slate-500">
        <span className="flex items-center gap-1"><Crown size={11} />{c.owner}</span>
        <span className="flex items-center gap-1"><ListChecks size={11} />{row.taskCount} 任务</span>
        <span className="ml-auto flex items-center gap-1" title={row.status === "已结案" ? row.closedAt || row.updatedAt || "未记录结案时间" : c.dueDate}>
          {row.status === "已结案" ? <><CalendarCheck size={11} />{row.closedAt ? `结案 ${row.closedAt.slice(0, 10)}` : row.updatedAt ? `更新 ${row.updatedAt.slice(0, 10)}` : "未记录结案时间"}</> : <><CalendarClock size={11} />{due}</>}
        </span>
      </div>
    </button>
    {row.fanout && <div className="flex min-w-0 items-center gap-2 border-t border-slate-100 bg-slate-50/60 px-5 py-2 text-[11px]">
      <GitBranch size={12} className="shrink-0 text-sky-500" /><span className="shrink-0 text-slate-400">来源 Case</span>
      {row.sourceCase ? <button type="button" aria-label={`查看 Fanout 来源 Case ${row.sourceCase.name}`} title={`${row.sourceCase.code} · ${row.sourceCase.name}`} onClick={() => onOpenCase(row.sourceCase!.id)} className="min-w-0 truncate text-[#0052D9] hover:underline">{row.sourceCase.name}</button> : <span className="min-w-0 truncate text-slate-400" title={c.fanoutSourceCaseId}>{c.fanoutSourceCaseId ? "来源 Case 暂不可用" : "未记录来源 Case"}</span>}
    </div>}
  </article>;
}