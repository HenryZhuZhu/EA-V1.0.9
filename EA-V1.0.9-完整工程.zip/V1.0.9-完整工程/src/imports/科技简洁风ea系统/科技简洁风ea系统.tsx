import svgPaths from "./svg-7hnmlzv83y";

function Container1() {
  return (
    <div className="relative rounded-[8px] shrink-0 size-[27.986px]" style={{ backgroundImage: "linear-gradient(135deg, rgb(0, 164, 255) 0%, rgb(0, 157, 252) 9.0909%, rgb(0, 150, 248) 18.182%, rgb(0, 142, 245) 27.273%, rgb(0, 135, 242) 36.364%, rgb(0, 128, 238) 45.455%, rgb(0, 121, 235) 54.545%, rgb(0, 113, 231) 63.636%, rgb(0, 106, 228) 72.727%, rgb(0, 98, 224) 81.818%, rgb(0, 90, 221) 90.909%, rgb(0, 82, 217) 100%)" }} data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <p className="font-['Inter:Regular',sans-serif] font-normal leading-[24px] not-italic relative shrink-0 text-[16px] text-white whitespace-nowrap">E</p>
      </div>
    </div>
  );
}

function Container3() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#0f172b] text-[16px] top-[-2.11px] tracking-[0.4px] whitespace-nowrap">EA Platform</p>
    </div>
  );
}

function Container4() {
  return (
    <div className="h-[13.75px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[13.75px] left-0 not-italic text-[#90a1b9] text-[11px] top-[-1.11px] whitespace-nowrap">Engineering Portal</p>
    </div>
  );
}

function Container2() {
  return (
    <div className="h-[33.75px] relative shrink-0 w-[119.41px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Container3 />
        <Container4 />
      </div>
    </div>
  );
}

function Container() {
  return (
    <div className="absolute content-stretch flex gap-[7.986px] h-[55.99px] items-center left-0 pb-[1.111px] pl-[15.99px] pr-[16px] top-0 w-[234.878px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#f1f5f9] border-b-[1.111px] border-solid inset-0 pointer-events-none" />
      <Container1 />
      <Container2 />
    </div>
  );
}

function Container5() {
  return (
    <div className="h-[32.483px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[16.5px] left-[12px] not-italic text-[#90a1b9] text-[11px] top-[6.99px] tracking-[0.55px] uppercase whitespace-nowrap">工作台</p>
    </div>
  );
}

function Icon() {
  return (
    <div className="relative shrink-0 size-[15.99px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15.9896 15.9896">
        <g clipPath="url(#clip0_2003_445)" id="Icon">
          <path d={svgPaths.p32879c00} id="Vector" stroke="var(--stroke-0, #0052D9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33247" />
          <path d={svgPaths.p3cb2ec00} id="Vector_2" stroke="var(--stroke-0, #0052D9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33247" />
        </g>
        <defs>
          <clipPath id="clip0_2003_445">
            <rect fill="white" height="15.9896" width="15.9896" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Text() {
  return (
    <div className="flex-[141.076_0_0] h-[19.983px] min-w-px relative" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="flex-[1_0_0] font-['Inter:Medium','Noto_Sans_JP:Medium','Noto_Sans_SC:Medium',sans-serif] font-medium leading-[20px] min-w-px not-italic relative text-[#0052d9] text-[14px]">我的待办</p>
      </div>
    </div>
  );
}

function Text1() {
  return (
    <div className="bg-[#0052d9] h-[18.264px] relative rounded-[37282700px] shrink-0 w-[17.847px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[14.286px] left-[9.49px] not-italic text-[10px] text-center text-white top-px whitespace-nowrap">6</p>
      </div>
    </div>
  );
}

function Button() {
  return (
    <div className="h-[35.955px] relative rounded-[8px] shrink-0 w-full" data-name="Button">
      <div aria-hidden="true" className="absolute bg-[rgba(0,82,217,0.08)] inset-0 pointer-events-none rounded-[8px]" />
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[10px] items-center px-[11.997px] py-[8px] relative size-full">
          <Icon />
          <Text />
          <Text1 />
        </div>
      </div>
      <div className="absolute inset-0 pointer-events-none rounded-[inherit] shadow-[inset_2px_0px_0px_0px_#0052d9]" />
    </div>
  );
}

function Icon1() {
  return (
    <div className="relative shrink-0 size-[15.99px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15.9896 15.9896">
        <g clipPath="url(#clip0_2003_458)" id="Icon">
          <path d={svgPaths.p2a5c9340} id="Vector" stroke="var(--stroke-0, #45556C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33247" />
          <path d="M5.32987 6.66233V9.32727" id="Vector_2" stroke="var(--stroke-0, #45556C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33247" />
          <path d="M7.9948 6.66233V7.9948" id="Vector_3" stroke="var(--stroke-0, #45556C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33247" />
          <path d="M10.6597 6.66233V10.6597" id="Vector_4" stroke="var(--stroke-0, #45556C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33247" />
        </g>
        <defs>
          <clipPath id="clip0_2003_458">
            <rect fill="white" height="15.9896" width="15.9896" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Text2() {
  return (
    <div className="flex-[168.924_0_0] h-[19.983px] min-w-px relative" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="flex-[1_0_0] font-['Inter:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium leading-[20px] min-w-px not-italic relative text-[#45556c] text-[14px]">Case 中心</p>
      </div>
    </div>
  );
}

function Button1() {
  return (
    <div className="h-[35.955px] relative rounded-[8px] shrink-0 w-full" data-name="Button">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[10px] items-center px-[11.997px] py-[8px] relative size-full">
          <Icon1 />
          <Text2 />
        </div>
      </div>
    </div>
  );
}

function Icon2() {
  return (
    <div className="relative shrink-0 size-[15.99px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15.9896 15.9896">
        <g clipPath="url(#clip0_2003_428)" id="Icon">
          <path d={svgPaths.p2cdb3600} id="Vector" stroke="var(--stroke-0, #45556C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33247" />
          <path d={svgPaths.p10f69080} id="Vector_2" stroke="var(--stroke-0, #45556C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33247" />
          <path d={svgPaths.p23428380} id="Vector_3" stroke="var(--stroke-0, #45556C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33247" />
          <path d={svgPaths.p14e57340} id="Vector_4" stroke="var(--stroke-0, #45556C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33247" />
        </g>
        <defs>
          <clipPath id="clip0_2003_428">
            <rect fill="white" height="15.9896" width="15.9896" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Text3() {
  return (
    <div className="flex-[168.924_0_0] h-[19.983px] min-w-px relative" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="flex-[1_0_0] font-['Inter:Medium','Noto_Sans_JP:Medium','Noto_Sans_SC:Medium',sans-serif] font-medium leading-[20px] min-w-px not-italic relative text-[#45556c] text-[14px]">管理者视图</p>
      </div>
    </div>
  );
}

function Button2() {
  return (
    <div className="h-[35.955px] relative rounded-[8px] shrink-0 w-full" data-name="Button">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[10px] items-center px-[11.997px] py-[8px] relative size-full">
          <Icon2 />
          <Text3 />
        </div>
      </div>
    </div>
  );
}

function Navigation() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[1.997px] h-[843px] items-start left-0 overflow-clip pt-[11.997px] px-[7.986px] top-[56px] w-[235px]" data-name="Navigation">
      <Container5 />
      <Button />
      <Button1 />
      <Button2 />
    </div>
  );
}

function Container8() {
  return (
    <div className="relative rounded-[37282700px] shrink-0 size-[31.997px]" style={{ backgroundImage: "linear-gradient(135deg, rgb(0, 164, 255) 0%, rgb(0, 158, 252) 7.6923%, rgb(0, 152, 249) 15.385%, rgb(0, 146, 247) 23.077%, rgb(0, 140, 244) 30.769%, rgb(0, 133, 241) 38.462%, rgb(0, 127, 238) 46.154%, rgb(0, 121, 235) 53.846%, rgb(0, 115, 232) 61.538%, rgb(0, 108, 229) 69.231%, rgb(0, 102, 226) 76.923%, rgb(0, 96, 223) 84.615%, rgb(0, 89, 220) 92.308%, rgb(0, 82, 217) 100%)" }} data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[12px] text-white whitespace-nowrap">Z</p>
      </div>
    </div>
  );
}

function Container10() {
  return (
    <div className="content-stretch flex h-[19.983px] items-start overflow-clip relative shrink-0 w-full" data-name="Container">
      <p className="flex-[1_0_0] font-['Inter:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[20px] min-w-px not-italic relative text-[#0f172b] text-[14px]">张伟</p>
    </div>
  );
}

function Container11() {
  return (
    <div className="h-[13.75px] overflow-clip relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[13.75px] left-0 not-italic text-[#62748e] text-[11px] top-[-1.11px] whitespace-nowrap">PTE Engineer · PTE</p>
    </div>
  );
}

function Container9() {
  return (
    <div className="flex-[122.951_0_0] h-[33.733px] min-w-px relative" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Container10 />
        <Container11 />
      </div>
    </div>
  );
}

function Icon3() {
  return (
    <div className="relative shrink-0 size-[11.997px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11.9965 11.9965">
        <g id="Icon">
          <path d={svgPaths.p54f380} id="Vector" stroke="var(--stroke-0, #90A1B9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
          <path d={svgPaths.p1f1db00} id="Vector_2" stroke="var(--stroke-0, #90A1B9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
          <path d="M10.4969 5.99825H4.49869" id="Vector_3" stroke="var(--stroke-0, #90A1B9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
        </g>
      </svg>
    </div>
  );
}

function Button3() {
  return (
    <div className="relative rounded-[4px] shrink-0 size-[23.993px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center pl-[5.99px] pr-[6.007px] relative size-full">
        <Icon3 />
      </div>
    </div>
  );
}

function Container7() {
  return (
    <div className="bg-[#f8fafc] h-[49.705px] relative rounded-[8px] shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[7.986px] items-center px-[7.986px] py-[8px] relative size-full">
          <Container8 />
          <Container9 />
          <Button3 />
        </div>
      </div>
    </div>
  );
}

function Icon4() {
  return (
    <div className="absolute left-[31.74px] size-[11.997px] top-[7.99px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11.9965 11.9965">
        <g clipPath="url(#clip0_2003_408)" id="Icon">
          <path d={svgPaths.p1cbbae00} id="Vector" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
          <path d={svgPaths.p1d46aba0} id="Vector_2" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
          <path d={svgPaths.p1c4ccbca} id="Vector_3" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
          <path d={svgPaths.p2b0c6f00} id="Vector_4" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
          <path d={svgPaths.pb720500} id="Vector_5" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
          <path d={svgPaths.p29d8c900} id="Vector_6" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
        </g>
        <defs>
          <clipPath id="clip0_2003_408">
            <rect fill="white" height="11.9965" width="11.9965" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Button4() {
  return (
    <div className="flex-[103.455_0_0] h-[27.969px] min-w-px relative rounded-[4px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Icon4 />
        <p className="-translate-x-1/2 absolute font-['Inter:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium leading-[16px] left-[59.73px] not-italic text-[#62748e] text-[12px] text-center top-[5.99px] whitespace-nowrap">{` 帮助`}</p>
      </div>
    </div>
  );
}

function Icon5() {
  return (
    <div className="absolute left-[31.74px] size-[11.997px] top-[7.99px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11.9965 11.9965">
        <g clipPath="url(#clip0_2003_464)" id="Icon">
          <path d={svgPaths.p1c259a00} id="Vector" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
          <path d={svgPaths.p12cdfa80} id="Vector_2" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
        </g>
        <defs>
          <clipPath id="clip0_2003_464">
            <rect fill="white" height="11.9965" width="11.9965" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Button5() {
  return (
    <div className="flex-[103.455_0_0] h-[27.969px] min-w-px relative rounded-[4px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Icon5 />
        <p className="-translate-x-1/2 absolute font-['Inter:Medium','Noto_Sans_SC:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium leading-[16px] left-[59.73px] not-italic text-[#62748e] text-[12px] text-center top-[5.99px] whitespace-nowrap">{` 设置`}</p>
      </div>
    </div>
  );
}

function Container12() {
  return (
    <div className="content-stretch flex gap-[3.993px] h-[27.969px] items-start pr-[-0.017px] relative shrink-0 w-full" data-name="Container">
      <Button4 />
      <Button5 />
    </div>
  );
}

function Container6() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[7.986px] h-[110.764px] items-start left-0 pt-[13.108px] px-[11.997px] top-[899.24px] w-[234.878px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#f1f5f9] border-solid border-t-[1.111px] inset-0 pointer-events-none" />
      <Container7 />
      <Container12 />
    </div>
  );
}

function Sidebar() {
  return (
    <div className="absolute bg-white border-[#e2e8f0] border-r-[1.111px] border-solid h-[1010px] left-0 top-0 w-[235.99px]" data-name="Sidebar">
      <Container />
      <Navigation />
      <Container6 />
    </div>
  );
}

function Button6() {
  return (
    <div className="h-[24.01px] relative shrink-0 w-[56.875px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid overflow-clip relative rounded-[inherit] size-full">
        <p className="-translate-x-1/2 absolute font-['Inter:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium leading-[24px] left-[28px] not-italic text-[#62748e] text-[16px] text-center top-[-1.89px] whitespace-nowrap">EA 平台</p>
      </div>
    </div>
  );
}

function Icon6() {
  return (
    <div className="relative shrink-0 size-[13.993px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13.9931 13.9931">
        <g id="Icon">
          <path d={svgPaths.p7ee7d80} id="Vector" stroke="var(--stroke-0, #CAD5E2)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16609" />
        </g>
      </svg>
    </div>
  );
}

function Text5() {
  return (
    <div className="h-[19.983px] relative shrink-0 w-[56.007px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start overflow-clip relative rounded-[inherit] size-full">
        <p className="font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#0f172b] text-[14px] whitespace-nowrap">我的待办</p>
      </div>
    </div>
  );
}

function Text4() {
  return (
    <div className="h-[19.983px] relative shrink-0 w-[75.99px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[5.99px] items-center relative size-full">
        <Icon6 />
        <Text5 />
      </div>
    </div>
  );
}

function Container14() {
  return (
    <div className="absolute content-stretch flex gap-[5.99px] h-[24.01px] items-center left-[20px] top-[15.43px] w-[138.854px]" data-name="Container">
      <Button6 />
      <Text4 />
    </div>
  );
}

function Icon7() {
  return (
    <div className="absolute left-[7.99px] size-[13.993px] top-[8.99px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13.9931 13.9931">
        <g id="Icon">
          <path d="M2.91523 6.99655H11.0779" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16609" />
          <path d="M6.99655 2.91523V11.0779" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16609" />
        </g>
      </svg>
    </div>
  );
}

function Button7() {
  return (
    <div className="absolute bg-[#0052d9] h-[31.997px] left-[1220.09px] rounded-[8px] top-[11.44px] w-[93.976px]" data-name="Button">
      <Icon7 />
      <p className="-translate-x-1/2 absolute font-['Inter:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium leading-[20px] left-[53.97px] not-italic text-[14px] text-center text-white top-[5.01px] whitespace-nowrap">新建Case</p>
    </div>
  );
}

function Icon8() {
  return (
    <div className="absolute left-[12px] size-[13.993px] top-[7.88px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13.9931 13.9931">
        <g clipPath="url(#clip0_2003_420)" id="Icon">
          <path d={svgPaths.p2c89b600} id="Vector" stroke="var(--stroke-0, #0052D9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16609" />
          <path d={svgPaths.p1c06b200} id="Vector_2" stroke="var(--stroke-0, #0052D9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16609" />
          <path d="M6.99655 9.91178H7.00238" id="Vector_3" stroke="var(--stroke-0, #0052D9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16609" />
        </g>
        <defs>
          <clipPath id="clip0_2003_420">
            <rect fill="white" height="13.9931" width="13.9931" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Button8() {
  return (
    <div className="absolute border-[1.111px] border-[rgba(0,82,217,0.3)] border-solid h-[31.997px] left-[1330.05px] rounded-[8px] top-[11.44px] w-[102.205px]" data-name="Button">
      <Icon8 />
      <p className="-translate-x-1/2 absolute font-['Inter:Medium','Noto_Sans_JP:Medium','Noto_Sans_SC:Medium',sans-serif] font-medium leading-[20px] left-[59.98px] not-italic text-[#0052d9] text-[14px] text-center top-[3.9px] whitespace-nowrap">{` 系统建议`}</p>
    </div>
  );
}

function Icon9() {
  return (
    <div className="absolute left-[8px] size-[15.99px] top-[8px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15.9896 15.9896">
        <g clipPath="url(#clip0_2003_400)" id="Icon">
          <path d={svgPaths.pfcdfd30} id="Vector" stroke="var(--stroke-0, #45556C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33247" />
          <path d={svgPaths.p2178aa00} id="Vector_2" stroke="var(--stroke-0, #45556C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33247" />
        </g>
        <defs>
          <clipPath id="clip0_2003_400">
            <rect fill="white" height="15.9896" width="15.9896" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Text6() {
  return (
    <div className="absolute bg-[#fb2c36] content-stretch flex items-center justify-center left-[18px] px-[4px] rounded-[37282700px] size-[15.99px] top-[-2px]" data-name="Text">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[15px] not-italic relative shrink-0 text-[10px] text-center text-white whitespace-nowrap">3</p>
    </div>
  );
}

function Button9() {
  return (
    <div className="absolute left-[1448.25px] rounded-[8px] size-[31.997px] top-[11.44px]" data-name="Button">
      <Icon9 />
      <Text6 />
    </div>
  );
}

function Header() {
  return (
    <div className="absolute bg-white border-[#e2e8f0] border-b-[1.111px] border-solid h-[55.99px] left-0 top-0 w-[1500.243px]" data-name="Header">
      <Container14 />
      <Button7 />
      <Button8 />
      <Button9 />
    </div>
  );
}

function Icon10() {
  return (
    <div className="absolute left-0 size-[11.997px] top-[2px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11.9965 11.9965">
        <g clipPath="url(#clip0_2003_390)" id="Icon">
          <path d={svgPaths.p298d0480} id="Vector" stroke="var(--stroke-0, #7A3DFF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
          <path d="M9.99708 1.49956V3.49898" id="Vector_2" stroke="var(--stroke-0, #7A3DFF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
          <path d="M10.9968 2.49927H8.99738" id="Vector_3" stroke="var(--stroke-0, #7A3DFF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
          <path d="M1.99942 8.49752V9.49723" id="Vector_4" stroke="var(--stroke-0, #7A3DFF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
          <path d="M2.49927 8.99738H1.49956" id="Vector_5" stroke="var(--stroke-0, #7A3DFF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
        </g>
        <defs>
          <clipPath id="clip0_2003_390">
            <rect fill="white" height="11.9965" width="11.9965" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Container18() {
  return (
    <div className="h-[15.99px] relative shrink-0 w-full" data-name="Container">
      <Icon10 />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-[19.98px] not-italic text-[#62748e] text-[12px] top-0 tracking-[0.6px] uppercase whitespace-nowrap">Engineer Workspace · 2026-04-22</p>
    </div>
  );
}

function Heading() {
  return (
    <div className="h-[35.99px] relative shrink-0 w-full" data-name="Heading 1">
      <p className="absolute font-['Inter:Medium','Noto_Sans_JP:Medium','Noto_Sans_SC:Medium',sans-serif] font-medium leading-[36px] left-0 not-italic text-[#0f172b] text-[24px] top-[-1.78px] tracking-[-0.6px] whitespace-nowrap">早上好，张伟</p>
    </div>
  );
}

function Paragraph() {
  return (
    <div className="h-[22.726px] relative shrink-0 w-full" data-name="Paragraph">
      <div className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[0] left-0 not-italic text-[#62748e] text-[14px] top-[0.22px] whitespace-nowrap">
        <p className="leading-[22.75px] mb-0 text-[#1d293d]">AI 日报（yyyy-mm-dd）：</p>
        <p className="leading-[22.75px]">这是Ai总结的日报内容，在这里进行内容的展示，用户可以点击右侧按钮更新，复制</p>
      </div>
    </div>
  );
}

function Container17() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[7.986px] h-[90.677px] items-start left-0 top-0 w-[395.365px]" data-name="Container">
      <Container18 />
      <Heading />
      <Paragraph />
    </div>
  );
}

function TintShadow() {
  return (
    <div className="absolute inset-0 rounded-[1000px] shadow-[0px_8px_40px_0px_rgba(0,0,0,0.12)]" data-name="Tint + Shadow">
      <div aria-hidden="true" className="absolute inset-0 pointer-events-none rounded-[1000px]">
        <div className="absolute bg-[rgba(255,255,255,0.75)] inset-0 rounded-[1000px]" />
        <div className="absolute bg-white inset-0 mix-blend-saturation rounded-[1000px]" />
        <div className="absolute bg-[#999] inset-0 mix-blend-overlay rounded-[1000px]" />
        <div className="absolute bg-[#0091ff] inset-0 rounded-[1000px]" />
      </div>
    </div>
  );
}

function GlassEffect() {
  return <div className="absolute bg-[rgba(0,0,0,0)] inset-0 rounded-[296px]" data-name="Glass Effect" />;
}

function Icon11() {
  return (
    <div className="absolute left-[75.94px] size-[11.997px] top-[2px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11.9965 11.9965">
        <g id="Icon">
          <path d={svgPaths.p33e35100} id="Vector" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
          <path d={svgPaths.p3091f600} id="Vector_2" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
        </g>
      </svg>
    </div>
  );
}

function Button10() {
  return (
    <div className="absolute h-[15.99px] left-[1248.07px] top-[74.69px] w-[87.934px]" data-name="Button">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium','Noto_Sans_SC:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium leading-[16px] left-[36px] not-italic text-[#62748e] text-[12px] text-center top-0 whitespace-nowrap">{`查看完整周报 `}</p>
      <Icon11 />
    </div>
  );
}

function Header1() {
  return (
    <div className="absolute h-[98.663px] left-[32px] top-[32px] w-[1336.007px]" data-name="Header">
      <Container17 />
      <div className="absolute content-stretch flex gap-[4px] h-[30px] items-center justify-center left-[1147.89px] px-[20px] py-[6px] rounded-[1000px] top-[68.01px] w-[80px]" data-name="Button - Liquid Glass - Text">
        <TintShadow />
        <GlassEffect />
        <div className="content-stretch flex h-[36px] items-center justify-center relative rounded-[100px] shrink-0" data-name="Text">
          <div className="flex flex-col font-['SF_Pro:Medium',sans-serif] font-[510] justify-center leading-[0] relative shrink-0 text-[12px] text-center text-white whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100", fontFeatureSettings: "'ss16'" }}>
            <p className="leading-[normal]">更新日报</p>
          </div>
        </div>
      </div>
      <Button10 />
    </div>
  );
}

function Button11() {
  return (
    <div className="absolute drop-shadow-[0px_1px_1.5px_rgba(0,0,0,0.1),0px_1px_1px_rgba(0,0,0,0.1)] h-[31.997px] left-[2px] rounded-[8px] top-[2px] w-[115.521px]" style={{ backgroundImage: "linear-gradient(rgb(0, 82, 217) 0%, rgb(0, 80, 211) 11.111%, rgb(0, 78, 206) 22.222%, rgb(0, 76, 200) 33.333%, rgb(0, 73, 195) 44.444%, rgb(0, 71, 189) 55.556%, rgb(0, 69, 184) 66.667%, rgb(0, 67, 179) 77.778%, rgb(0, 65, 173) 88.889%, rgb(0, 63, 168) 100%)" }} data-name="Button">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium leading-[20px] left-[57.99px] not-italic text-[14px] text-center text-white top-[5.01px] whitespace-nowrap">我的 Case · 1</p>
    </div>
  );
}

function Button12() {
  return (
    <div className="absolute h-[31.997px] left-[117.52px] rounded-[8px] top-[2px] w-[116.059px]" data-name="Button">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium','Noto_Sans_JP:Medium','Noto_Sans_SC:Medium',sans-serif] font-medium leading-[20px] left-[58.49px] not-italic text-[#45556c] text-[14px] text-center top-[5.01px] whitespace-nowrap">我的任务 · 11</p>
    </div>
  );
}

function Container19() {
  return (
    <div className="absolute bg-white border-[#e2e8f0] border-[1.111px] border-solid drop-shadow-[0px_1px_1.5px_rgba(0,0,0,0.1),0px_1px_1px_rgba(0,0,0,0.1)] h-[38.212px] left-[32px] rounded-[10px] top-[162.66px] w-[237.795px]" data-name="Container">
      <Button11 />
      <Button12 />
    </div>
  );
}

function Container22() {
  return <div className="absolute bg-[#f7a000] h-[80.99px] left-0 rounded-br-[4px] rounded-tr-[4px] top-[20px] w-[1.997px]" data-name="Container" />;
}

function Container23() {
  return (
    <div className="absolute content-stretch flex h-[16.51px] items-start left-[20px] top-[20px] w-[292.691px]" data-name="Container">
      <p className="flex-[1_0_0] font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[16.5px] min-w-px not-italic relative text-[#62748e] text-[11px] tracking-[0.55px] uppercase">我作为 Owner</p>
    </div>
  );
}

function Container24() {
  return (
    <div className="absolute font-normal h-[31.997px] left-[20px] not-italic top-[44.5px] w-[292.691px] whitespace-nowrap" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] leading-[32px] left-0 text-[#0f172b] text-[32px] top-[-1.44px] tracking-[-0.8px]">1</p>
      <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] leading-[16px] left-[25.95px] text-[#90a1b9] text-[12px] top-[15.56px]">件</p>
    </div>
  );
}

function Text7() {
  return <div className="absolute bg-[#f7a000] left-0 rounded-[37282700px] size-[3.993px] top-[6.25px]" data-name="Text" />;
}

function Container25() {
  return (
    <div className="absolute h-[16.51px] left-[20px] top-[84.48px] w-[292.691px]" data-name="Container">
      <Text7 />
      <p className="absolute font-['Inter:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[16.5px] left-[7.99px] not-italic text-[#62748e] text-[11px] top-[-1px] whitespace-nowrap">负责整体进度</p>
    </div>
  );
}

function Container21() {
  return (
    <div className="absolute bg-white h-[120.99px] left-[333px] top-px w-[332.691px]" data-name="Container">
      <Container22 />
      <Container23 />
      <Container24 />
      <Container25 />
    </div>
  );
}

function Container27() {
  return <div className="absolute bg-[#e54545] h-[80.99px] left-0 rounded-br-[4px] rounded-tr-[4px] top-[20px] w-[1.997px]" data-name="Container" />;
}

function Container28() {
  return (
    <div className="absolute content-stretch flex h-[16.51px] items-start left-[20px] top-[20px] w-[292.708px]" data-name="Container">
      <p className="flex-[1_0_0] font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[16.5px] min-w-px not-italic relative text-[#62748e] text-[11px] tracking-[0.55px] uppercase">非常紧急 Case</p>
    </div>
  );
}

function Container29() {
  return (
    <div className="absolute font-normal h-[31.997px] left-[20px] not-italic top-[44.5px] w-[292.708px] whitespace-nowrap" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] leading-[32px] left-0 text-[#0f172b] text-[32px] top-[-1.44px] tracking-[-0.8px]">1</p>
      <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] leading-[16px] left-[25.95px] text-[#90a1b9] text-[12px] top-[15.56px]">件</p>
    </div>
  );
}

function Text8() {
  return <div className="absolute bg-[#e54545] left-0 rounded-[37282700px] size-[3.993px] top-[6.25px]" data-name="Text" />;
}

function Container30() {
  return (
    <div className="absolute h-[16.51px] left-[20px] top-[84.48px] w-[292.708px]" data-name="Container">
      <Text8 />
      <p className="absolute font-['Inter:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[16.5px] left-[7.99px] not-italic text-[#e7000b] text-[11px] top-[-1px] whitespace-nowrap">优先关注</p>
    </div>
  );
}

function Container26() {
  return (
    <div className="absolute bg-white h-[120.99px] left-[666.68px] top-px w-[332.708px]" data-name="Container">
      <Container27 />
      <Container28 />
      <Container29 />
      <Container30 />
    </div>
  );
}

function Container20() {
  return (
    <div className="absolute h-[123px] left-[31.89px] rounded-[14px] top-[233.01px] w-[1002px]" data-name="Container">
      <div aria-hidden="true" className="absolute bg-[rgba(226,232,240,0.7)] inset-0 pointer-events-none rounded-[14px]" />
      <div className="overflow-clip relative rounded-[inherit] size-full">
        <Container21 />
        <Container26 />
      </div>
      <div className="absolute inset-0 pointer-events-none rounded-[inherit] shadow-[inset_0px_1px_0px_0px_rgba(255,255,255,0.5)]" />
      <div aria-hidden="true" className="absolute border-[1.111px] border-[rgba(226,232,240,0.7)] border-solid inset-0 pointer-events-none rounded-[14px]" />
    </div>
  );
}

function Container32() {
  return <div className="absolute bg-[#0052d9] h-[80.99px] left-0 rounded-br-[4px] rounded-tr-[4px] top-[20px] w-[1.997px]" data-name="Container" />;
}

function Container33() {
  return (
    <div className="absolute content-stretch flex h-[16.51px] items-start left-[20px] top-[20px] w-[292.708px]" data-name="Container">
      <p className="flex-[1_0_0] font-['Inter:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[16.5px] min-w-px not-italic relative text-[#62748e] text-[11px] tracking-[0.55px] uppercase">进行中 Case</p>
    </div>
  );
}

function Container34() {
  return (
    <div className="absolute font-normal h-[31.997px] left-[20px] not-italic top-[44.5px] w-[292.708px] whitespace-nowrap" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] leading-[32px] left-0 text-[#0f172b] text-[32px] top-[-1.44px] tracking-[-0.8px]">1</p>
      <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] leading-[16px] left-[25.95px] text-[#90a1b9] text-[12px] top-[15.56px]">件</p>
    </div>
  );
}

function Text9() {
  return <div className="absolute bg-[#0052d9] left-0 rounded-[37282700px] size-[3.993px] top-[6.25px]" data-name="Text" />;
}

function Container35() {
  return (
    <div className="absolute h-[16.51px] left-[20px] top-[84.48px] w-[292.708px]" data-name="Container">
      <Text9 />
      <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[16.5px] left-[7.99px] not-italic text-[#62748e] text-[11px] top-[-1px] whitespace-nowrap">跨部门协作</p>
    </div>
  );
}

function Container31() {
  return (
    <div className="absolute bg-white h-[120.99px] left-[31.89px] top-[234.01px] w-[332.708px]" data-name="Container">
      <Container32 />
      <Container33 />
      <Container34 />
      <Container35 />
    </div>
  );
}

function Icon12() {
  return (
    <div className="relative shrink-0 size-[13.993px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13.9931 13.9931">
        <g clipPath="url(#clip0_2003_404)" id="Icon">
          <path d={svgPaths.p18e6380} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16609" />
          <path d="M2.91523 12.244H11.0779" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16609" />
        </g>
        <defs>
          <clipPath id="clip0_2003_404">
            <rect fill="white" height="13.9931" width="13.9931" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Container37() {
  return (
    <div className="drop-shadow-[0px_1px_1.5px_#fee685,0px_1px_1px_#fee685] relative rounded-[10px] shrink-0 size-[27.986px]" style={{ backgroundImage: "linear-gradient(135deg, rgb(255, 185, 0) 0%, rgb(254, 154, 0) 100%)" }} data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center pl-[6.997px] pr-[6.996px] relative size-full">
        <Icon12 />
      </div>
    </div>
  );
}

function Heading1() {
  return (
    <div className="h-[26.997px] relative shrink-0 w-full" data-name="Heading 3">
      <p className="absolute font-['Inter:Medium','Noto_Sans_JP:Medium','Noto_Sans_SC:Medium',sans-serif] font-medium leading-[27px] left-0 not-italic text-[#0f172b] text-[18px] top-[0.22px] whitespace-nowrap">我作为 Owner 的 Case</p>
    </div>
  );
}

function Paragraph1() {
  return (
    <div className="content-stretch flex h-[15.99px] items-start relative shrink-0 w-full" data-name="Paragraph">
      <p className="font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#62748e] text-[12px] whitespace-nowrap">关注整体进度、风险与跨部门协作 · 共 1 个</p>
    </div>
  );
}

function Container38() {
  return (
    <div className="h-[44.983px] relative shrink-0 w-[227.934px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[1.997px] items-start relative size-full">
        <Heading1 />
        <Paragraph1 />
      </div>
    </div>
  );
}

function Container36() {
  return (
    <div className="content-stretch flex gap-[10px] h-[44.983px] items-center pr-[1070.087px] relative shrink-0 w-[1336.007px]" data-name="Container">
      <Container37 />
      <Container38 />
    </div>
  );
}

function Container40() {
  return <div className="absolute bg-[#e54545] h-[124.913px] left-0 rounded-br-[4px] rounded-tr-[4px] top-[20px] w-[1.997px]" data-name="Container" />;
}

function Container41() {
  return (
    <div className="absolute bg-[#fff7ed] border-[#ffd6a8] border-[1.111px] border-solid h-[21.215px] left-[20px] rounded-[4px] top-[20px] w-[25.208px]" data-name="Container">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[15px] left-[5.99px] not-italic text-[#f54900] text-[10px] top-[2.11px] whitespace-nowrap">L2</p>
    </div>
  );
}

function Container42() {
  return (
    <div className="absolute bg-[#fb2c36] h-[18.993px] left-[53.19px] rounded-[4px] top-[21.11px] w-[51.979px]" data-name="Container">
      <p className="absolute font-['Inter:Medium','Noto_Sans_JP:Medium','Noto_Sans_SC:Medium',sans-serif] font-medium leading-[15px] left-[5.99px] not-italic text-[10px] text-white top-[2.11px] whitespace-nowrap">非常紧急</p>
    </div>
  );
}

function Text10() {
  return (
    <div className="absolute h-[16.51px] left-[593.56px] top-[22.34px] w-[44.219px]" data-name="Text">
      <p className="absolute font-['Consolas:Medium',sans-serif] leading-[16.5px] left-0 not-italic text-[#90a1b9] text-[11px] top-[-0.89px] tracking-[0.275px] whitespace-nowrap">001.003</p>
    </div>
  );
}

function Container43() {
  return (
    <div className="absolute content-stretch flex h-[20.625px] items-start left-[20px] overflow-clip top-[53.21px] w-[617.778px]" data-name="Container">
      <p className="flex-[1_0_0] font-['Inter:Medium',sans-serif] font-medium leading-[20.625px] min-w-px not-italic relative text-[#0f172b] text-[15px]">DDR5 X-die CP1 yield drop @Site A</p>
    </div>
  );
}

function Container44() {
  return (
    <div className="absolute h-[19.479px] left-[20px] overflow-clip top-[79.83px] w-[617.778px]" data-name="Container">
      <p className="absolute font-['Inter:Medium','Noto_Sans_JP:Medium','Noto_Sans_SC:Medium',sans-serif] font-medium leading-[19.5px] left-0 not-italic text-[#62748e] text-[12px] top-[-0.89px] whitespace-nowrap">客户反馈批量良率低于基线 3.5%，需立即定位并给出改善方案。</p>
    </div>
  );
}

function Icon13() {
  return (
    <div className="absolute left-0 size-[10.99px] top-[2.76px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9896 10.9896">
        <g clipPath="url(#clip0_2003_376)" id="Icon">
          <path d={svgPaths.p2cbc1100} id="Vector" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.9158" />
          <path d={svgPaths.pa9fe880} id="Vector_2" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.9158" />
          <path d="M5.9527 2.7474H9.6159" id="Vector_3" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.9158" />
          <path d="M5.9527 5.4948H9.6159" id="Vector_4" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.9158" />
          <path d="M5.9527 8.2422H9.6159" id="Vector_5" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.9158" />
        </g>
        <defs>
          <clipPath id="clip0_2003_376">
            <rect fill="white" height="10.9896" width="10.9896" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Text11() {
  return (
    <div className="absolute h-[16.51px] left-0 top-[12px] w-[46.684px]" data-name="Text">
      <Icon13 />
      <p className="absolute font-['Inter:Medium','Noto_Sans_JP:Medium','Noto_Sans_SC:Medium',sans-serif] font-medium leading-[16.5px] left-[14.98px] not-italic text-[#62748e] text-[11px] top-[-1px] whitespace-nowrap">{` 6 任务`}</p>
    </div>
  );
}

function Icon14() {
  return (
    <div className="absolute left-0 size-[10.99px] top-[2.76px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9896 10.9896">
        <g clipPath="url(#clip0_2003_366)" id="Icon">
          <path d={svgPaths.p133d280} id="Vector" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.9158" />
          <path d="M7.3264 0.9158V2.7474" id="Vector_2" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.9158" />
          <path d="M3.6632 0.9158V2.7474" id="Vector_3" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.9158" />
          <path d="M1.3737 4.579H3.6632" id="Vector_4" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.9158" />
          <path d={svgPaths.p3c07a000} id="Vector_5" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.9158" />
          <path d={svgPaths.p83bb700} id="Vector_6" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.9158" />
        </g>
        <defs>
          <clipPath id="clip0_2003_366">
            <rect fill="white" height="10.9896" width="10.9896" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Text12() {
  return (
    <div className="absolute h-[16.51px] left-[62.67px] top-[12px] w-[57.674px]" data-name="Text">
      <Icon14 />
      <p className="absolute font-['Inter:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium leading-[16.5px] left-[14.98px] not-italic text-[#62748e] text-[11px] top-[-1px] whitespace-nowrap">{` 2 天到期`}</p>
    </div>
  );
}

function Text13() {
  return (
    <div className="absolute content-stretch flex h-[16.51px] items-start left-[574.38px] top-[12px] w-[43.403px]" data-name="Text">
      <p className="font-['Inter:Medium','Noto_Sans_JP:Medium','Noto_Sans_SC:Medium',sans-serif] font-medium leading-[16.5px] not-italic relative shrink-0 text-[#fb2c36] text-[11px] whitespace-nowrap">● 有风险</p>
    </div>
  );
}

function Container45() {
  return (
    <div className="absolute border-[#e2e8f0] border-dashed border-t-[1.111px] h-[29.618px] left-[20px] top-[115.3px] w-[617.778px]" data-name="Container">
      <Text11 />
      <Text12 />
      <Text13 />
    </div>
  );
}

function Button13() {
  return (
    <div className="absolute bg-white border-[1.111px] border-[rgba(226,232,240,0.8)] border-solid h-[167.135px] left-0 overflow-clip rounded-[14px] top-0 w-[660px]" data-name="Button">
      <Container40 />
      <Container41 />
      <Container42 />
      <Text10 />
      <Container43 />
      <Container44 />
      <Container45 />
    </div>
  );
}

function Container39() {
  return (
    <div className="h-[167.135px] relative shrink-0 w-full" data-name="Container">
      <Button13 />
    </div>
  );
}

function Section() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[15.99px] h-[228.108px] items-start left-[32px] top-[388.07px] w-[1336.007px]" data-name="Section">
      <Container36 />
      <Container39 />
    </div>
  );
}

function Icon15() {
  return (
    <div className="absolute left-[533.52px] size-[10.99px] top-[18.75px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9896 10.9896">
        <g clipPath="url(#clip0_2003_449)" id="Icon">
          <path d={svgPaths.p245b9540} id="Vector" stroke="var(--stroke-0, #90A1B9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.9158" />
          <path d={svgPaths.pf5f5780} id="Vector_2" stroke="var(--stroke-0, #90A1B9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.9158" />
        </g>
        <defs>
          <clipPath id="clip0_2003_449">
            <rect fill="white" height="10.9896" width="10.9896" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Container46() {
  return (
    <div className="absolute h-[32.5px] left-[32px] top-[648.18px] w-[1336.007px]" data-name="Container">
      <Icon15 />
      <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[16.5px] left-[552.5px] not-italic text-[#90a1b9] text-[11px] top-[14.99px] whitespace-nowrap">数据刷新于 2026-04-22 11:05 · 每 5 分钟自动同步</p>
    </div>
  );
}

function Container16() {
  return (
    <div className="absolute h-[712.674px] left-[50.12px] top-0 w-[1400px]" data-name="Container">
      <Header1 />
      <div className="absolute left-[561.89px] overflow-clip size-[16px] top-[126.01px]" data-name="Copy">
        <div className="absolute inset-[8.33%]" data-name="Icon">
          <div className="absolute inset-[-6%]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.9333 14.9333">
              <path d={svgPaths.p36ba8a00} id="Icon" stroke="var(--stroke-0, #1E1E1E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.6" />
            </svg>
          </div>
        </div>
      </div>
      <Container19 />
      <Container20 />
      <Container31 />
      <Section />
      <Container46 />
    </div>
  );
}

function Container15() {
  return (
    <div className="h-[712.674px] relative shrink-0 w-full" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\\'0 0 1500.2 712.67\\' xmlns=\\'http://www.w3.org/2000/svg\\' preserveAspectRatio=\\'none\\'><rect x=\\'0\\' y=\\'0\\' height=\\'100%\\' width=\\'100%\\' fill=\\'url(%23grad)\\' opacity=\\'1\\'/><defs><radialGradient id=\\'grad\\' gradientUnits=\\'userSpaceOnUse\\' cx=\\'0\\' cy=\\'0\\' r=\\'10\\' gradientTransform=\\'matrix(0 -28.507 -90.015 0 1500.2 0)\\'><stop stop-color=\\'rgba(122,61,255,0.05)\\' offset=\\'0\\'/><stop stop-color=\\'rgba(0,0,0,0)\\' offset=\\'0.55\\'/></radialGradient></defs></svg>'), url('data:image/svg+xml;utf8,<svg viewBox=\\'0 0 1500.2 712.67\\' xmlns=\\'http://www.w3.org/2000/svg\\' preserveAspectRatio=\\'none\\'><rect x=\\'0\\' y=\\'0\\' height=\\'100%\\' width=\\'100%\\' fill=\\'url(%23grad)\\' opacity=\\'1\\'/><defs><radialGradient id=\\'grad\\' gradientUnits=\\'userSpaceOnUse\\' cx=\\'0\\' cy=\\'0\\' r=\\'10\\' gradientTransform=\\'matrix(0 -35.634 -120.02 0 0 0)\\'><stop stop-color=\\'rgba(0,82,217,0.06)\\' offset=\\'0\\'/><stop stop-color=\\'rgba(0,0,0,0)\\' offset=\\'0.6\\'/></radialGradient></defs></svg>')" }} data-name="Container">
      <Container16 />
    </div>
  );
}

function MainContent() {
  return (
    <div className="absolute content-stretch flex flex-col h-[954.01px] items-start left-0 overflow-clip top-[55.99px] w-[1500.243px]" data-name="Main Content">
      <Container15 />
    </div>
  );
}

function Container13() {
  return (
    <div className="absolute h-[1010px] left-[235.99px] top-0 w-[1500.243px]" data-name="Container">
      <Header />
      <MainContent />
    </div>
  );
}

function Icon16() {
  return (
    <div className="relative shrink-0 size-[13.993px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13.9931 13.9931">
        <g clipPath="url(#clip0_2003_425)" id="Icon">
          <path d={svgPaths.p2aa68940} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16609" />
        </g>
        <defs>
          <clipPath id="clip0_2003_425">
            <rect fill="white" height="13.9931" width="13.9931" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Container48() {
  return (
    <div className="relative rounded-[10px] shrink-0 size-[35.99px]" style={{ backgroundImage: "linear-gradient(135deg, rgb(49, 65, 88) 0%, rgb(15, 23, 43) 100%)" }} data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center pl-[10.99px] pr-[11.007px] relative size-full">
        <Icon16 />
      </div>
    </div>
  );
}

function Text14() {
  return <div className="absolute bg-[#fb2c36] left-[32px] rounded-[37282700px] shadow-[0px_0px_0px_0px_white] size-[5.99px] top-[-2px]" data-name="Text" />;
}

function Button14() {
  return (
    <div className="absolute drop-shadow-[0px_1px_1.5px_rgba(0,0,0,0.1),0px_1px_1px_rgba(0,0,0,0.1)] left-0 rounded-[10px] size-[35.99px] top-[3.99px]" style={{ backgroundImage: "linear-gradient(135deg, rgb(0, 82, 217) 0%, rgb(0, 88, 220) 7.1429%, rgb(0, 95, 223) 14.286%, rgb(0, 101, 225) 21.429%, rgb(0, 107, 228) 28.571%, rgb(0, 113, 231) 35.714%, rgb(0, 118, 234) 42.857%, rgb(0, 124, 236) 50%, rgb(0, 130, 239) 57.143%, rgb(0, 136, 242) 64.286%, rgb(0, 141, 244) 71.429%, rgb(0, 147, 247) 78.571%, rgb(0, 153, 250) 85.714%, rgb(0, 158, 252) 92.857%, rgb(0, 164, 255) 100%)" }} data-name="Button">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[16.5px] left-[18.37px] not-italic text-[11px] text-center text-white top-[8.74px] whitespace-nowrap">iT</p>
      <Text14 />
    </div>
  );
}

function Text15() {
  return <div className="absolute bg-[#fb2c36] left-[32px] rounded-[37282700px] shadow-[0px_0px_0px_0px_white] size-[5.99px] top-[-2px]" data-name="Text" />;
}

function Button15() {
  return (
    <div className="absolute drop-shadow-[0px_1px_1.5px_rgba(0,0,0,0.1),0px_1px_1px_rgba(0,0,0,0.1)] left-0 rounded-[10px] size-[35.99px] top-[47.97px]" style={{ backgroundImage: "linear-gradient(135deg, rgb(122, 61, 255) 0%, rgb(125, 67, 255) 7.1429%, rgb(129, 72, 255) 14.286%, rgb(132, 77, 255) 21.429%, rgb(136, 82, 255) 28.571%, rgb(140, 87, 255) 35.714%, rgb(144, 91, 255) 42.857%, rgb(148, 96, 255) 50%, rgb(151, 100, 255) 57.143%, rgb(155, 104, 255) 64.286%, rgb(159, 108, 255) 71.429%, rgb(163, 112, 255) 78.571%, rgb(168, 116, 255) 85.714%, rgb(172, 119, 255) 92.857%, rgb(176, 123, 255) 100%)" }} data-name="Button">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[16.5px] left-[18.09px] not-italic text-[11px] text-center text-white top-[8.74px] whitespace-nowrap">1C</p>
      <Text15 />
    </div>
  );
}

function Button16() {
  return (
    <div className="absolute content-stretch drop-shadow-[0px_1px_1.5px_rgba(0,0,0,0.1),0px_1px_1px_rgba(0,0,0,0.1)] flex items-center justify-center left-0 rounded-[10px] size-[35.99px] top-[91.94px]" style={{ backgroundImage: "linear-gradient(135deg, rgb(0, 181, 120) 0%, rgb(10, 184, 123) 11.111%, rgb(18, 187, 125) 22.222%, rgb(25, 191, 128) 33.333%, rgb(30, 194, 130) 44.444%, rgb(35, 197, 133) 55.556%, rgb(39, 200, 135) 66.667%, rgb(43, 203, 138) 77.778%, rgb(47, 207, 140) 88.889%, rgb(51, 210, 143) 100%)" }} data-name="Button">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16.5px] not-italic relative shrink-0 text-[11px] text-center text-white whitespace-nowrap">Sh</p>
    </div>
  );
}

function Container49() {
  return (
    <div className="flex-[891.059_0_0] min-h-px relative w-[35.99px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid overflow-clip relative rounded-[inherit] size-full">
        <Button14 />
        <Button15 />
        <Button16 />
      </div>
    </div>
  );
}

function Container50() {
  return (
    <div className="h-[26.979px] relative shrink-0 w-[13.49px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[13.5px] not-italic relative shrink-0 text-[#90a1b9] text-[9px] whitespace-nowrap">工具箱</p>
      </div>
    </div>
  );
}

function Container47() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[11.997px] h-[1010px] items-center left-0 py-[15.99px] top-0 w-[54.878px]" data-name="Container">
      <Container48 />
      <Container49 />
      <Container50 />
    </div>
  );
}

function Icon17() {
  return (
    <div className="relative shrink-0 size-[11.997px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11.9965 11.9965">
        <g id="Icon">
          <path d={svgPaths.pa593100} id="Vector" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
        </g>
      </svg>
    </div>
  );
}

function Button17() {
  return (
    <div className="absolute bg-white content-stretch drop-shadow-[0px_1px_1.5px_rgba(0,0,0,0.1),0px_1px_1px_rgba(0,0,0,0.1)] flex items-center justify-center left-[-12px] pl-[5.99px] pr-[6.007px] py-[1.111px] rounded-[37282700px] size-[23.993px] top-[63.99px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-[1.111px] border-solid inset-0 pointer-events-none rounded-[37282700px]" />
      <Icon17 />
    </div>
  );
}

function Sidebar1() {
  return (
    <div className="absolute bg-[rgba(255,255,255,0.7)] border-[#e2e8f0] border-l-[1.111px] border-solid h-[1010px] left-[1736.23px] top-0 w-[55.99px]" data-name="Sidebar">
      <Container47 />
      <Button17 />
    </div>
  );
}

function Icon18() {
  return (
    <div className="absolute left-[15.99px] size-[15.99px] top-[15.99px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15.9896 15.9896">
        <g clipPath="url(#clip0_2003_356)" id="Icon">
          <path d={svgPaths.p9570a00} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33247" />
          <path d="M13.3247 1.9987V4.66363" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33247" />
          <path d="M14.6571 3.33117H11.9922" id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33247" />
          <path d="M2.66493 11.326V12.6584" id="Vector_4" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33247" />
          <path d="M3.33117 11.9922H1.9987" id="Vector_5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33247" />
        </g>
        <defs>
          <clipPath id="clip0_2003_356">
            <rect fill="white" height="15.9896" width="15.9896" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Button18() {
  return (
    <div className="absolute drop-shadow-[0px_10px_7.5px_rgba(0,0,0,0.1),0px_4px_3px_rgba(0,0,0,0.1)] h-[47.986px] left-[1662.5px] rounded-[37282700px] top-[938.02px] w-[105.729px]" style={{ backgroundImage: "linear-gradient(155.589deg, rgb(0, 164, 255) 0%, rgb(0, 158, 252) 7.1429%, rgb(0, 153, 250) 14.286%, rgb(0, 147, 247) 21.429%, rgb(0, 141, 244) 28.571%, rgb(0, 136, 242) 35.714%, rgb(0, 130, 239) 42.857%, rgb(0, 124, 236) 50%, rgb(0, 118, 234) 57.143%, rgb(0, 113, 231) 64.286%, rgb(0, 107, 228) 71.429%, rgb(0, 101, 225) 78.571%, rgb(0, 95, 223) 85.714%, rgb(0, 88, 220) 92.857%, rgb(0, 82, 217) 100%)" }} data-name="Button">
      <Icon18 />
      <p className="-translate-x-1/2 absolute font-['Inter:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium leading-[20px] left-[64.97px] not-italic text-[14px] text-center text-white top-[12.99px] whitespace-nowrap">EA 助手</p>
    </div>
  );
}

function Body() {
  return (
    <div className="h-[1010px] relative shrink-0 w-full" style={{ backgroundImage: "linear-gradient(150.597deg, rgb(248, 250, 252) 0%, rgb(255, 255, 255) 50%, rgb(248, 250, 252) 100%)" }} data-name="Body">
      <Sidebar />
      <Container13 />
      <Sidebar1 />
      <Button18 />
    </div>
  );
}

export default function ea() {
  return (
    <div className="bg-white content-stretch flex flex-col items-start pr-[-0.222px] relative size-full" data-name="科技简洁风EA系统">
      <Body />
    </div>
  );
}