import svgPaths from "./svg-midsttwl4x";

function Container1() {
  return (
    <div className="relative rounded-[8px] shrink-0 size-[28px]" style={{ backgroundImage: "linear-gradient(135deg, rgb(0, 164, 255) 0%, rgb(0, 157, 252) 9.0909%, rgb(0, 150, 248) 18.182%, rgb(0, 142, 245) 27.273%, rgb(0, 135, 242) 36.364%, rgb(0, 128, 238) 45.455%, rgb(0, 121, 235) 54.545%, rgb(0, 113, 231) 63.636%, rgb(0, 106, 228) 72.727%, rgb(0, 98, 224) 81.818%, rgb(0, 90, 221) 90.909%, rgb(0, 82, 217) 100%)" }} data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <p className="font-['Inter:Regular',sans-serif] font-normal leading-[24px] not-italic relative shrink-0 text-[16px] text-white whitespace-nowrap">E</p>
      </div>
    </div>
  );
}

function Container3() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#0f172b] text-[16px] top-[-1.89px] tracking-[0.4px] whitespace-nowrap">EA Platform</p>
    </div>
  );
}

function Container4() {
  return (
    <div className="h-[13.75px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[13.75px] left-0 not-italic text-[#90a1b9] text-[11px] top-[-0.89px] whitespace-nowrap">Engineering Portal</p>
    </div>
  );
}

function Container2() {
  return (
    <div className="h-[33.75px] relative shrink-0 w-[119.472px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Container3 />
        <Container4 />
      </div>
    </div>
  );
}

function Container() {
  return (
    <div className="absolute content-stretch flex gap-[8px] h-[56px] items-center left-0 pb-[0.889px] px-[16px] top-0 w-[235.111px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#f1f5f9] border-b-[0.889px] border-solid inset-0 pointer-events-none" />
      <Container1 />
      <Container2 />
    </div>
  );
}

function Container5() {
  return (
    <div className="h-[32.5px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[16.5px] left-[12px] not-italic text-[#90a1b9] text-[11px] top-[7.89px] tracking-[0.55px] uppercase whitespace-nowrap">工作台</p>
    </div>
  );
}

function Icon() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p1168a680} id="Vector" stroke="var(--stroke-0, #0052D9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.pf8d0500} id="Vector_2" stroke="var(--stroke-0, #0052D9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Text() {
  return (
    <div className="flex-[141.236_0_0] h-[20px] min-w-px relative" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium','Noto_Sans_JP:Medium','Noto_Sans_SC:Medium',sans-serif] font-medium leading-[20px] left-0 not-italic text-[#0052d9] text-[14px] top-[-0.11px] whitespace-nowrap">我的待办</p>
      </div>
    </div>
  );
}

function Text1() {
  return (
    <div className="bg-[#0052d9] h-[18.278px] relative rounded-[29826200px] shrink-0 w-[17.875px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[14.286px] left-[9px] not-italic text-[10px] text-center text-white top-[1.89px] whitespace-nowrap">7</p>
      </div>
    </div>
  );
}

function Button() {
  return (
    <div className="h-[36px] relative rounded-[8px] shrink-0 w-full" data-name="Button">
      <div aria-hidden="true" className="absolute bg-[rgba(0,82,217,0.08)] inset-0 pointer-events-none rounded-[8px]" />
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[10px] items-center px-[12px] py-[8px] relative size-full">
          <Icon />
          <Text />
          <Text1 />
        </div>
      </div>
      <div className="absolute inset-0 pointer-events-none rounded-[inherit] shadow-[inset_2px_0px_0px_0px_#0052d9]" />
    </div>
  );
}

function Icon1() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p3159e300} id="Vector" stroke="var(--stroke-0, #45556C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M5.33333 6.66667V9.33333" id="Vector_2" stroke="var(--stroke-0, #45556C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M8 6.66667V8" id="Vector_3" stroke="var(--stroke-0, #45556C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M10.6667 6.66667V10.6667" id="Vector_4" stroke="var(--stroke-0, #45556C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Text2() {
  return (
    <div className="flex-[169.111_0_0] h-[20px] min-w-px relative" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium leading-[20px] left-0 not-italic text-[#45556c] text-[14px] top-[-0.11px] whitespace-nowrap">Case 中心</p>
      </div>
    </div>
  );
}

function Button1() {
  return (
    <div className="h-[36px] relative rounded-[8px] shrink-0 w-full" data-name="Button">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[10px] items-center px-[12px] py-[8px] relative size-full">
          <Icon1 />
          <Text2 />
        </div>
      </div>
    </div>
  );
}

function Icon2() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p32887f80} id="Vector" stroke="var(--stroke-0, #45556C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p3694d280} id="Vector_2" stroke="var(--stroke-0, #45556C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p1f197700} id="Vector_3" stroke="var(--stroke-0, #45556C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p3bf3e100} id="Vector_4" stroke="var(--stroke-0, #45556C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Text3() {
  return (
    <div className="flex-[169.111_0_0] h-[20px] min-w-px relative" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium','Noto_Sans_JP:Medium','Noto_Sans_SC:Medium',sans-serif] font-medium leading-[20px] left-0 not-italic text-[#45556c] text-[14px] top-[-0.11px] whitespace-nowrap">管理者视图</p>
      </div>
    </div>
  );
}

function Button2() {
  return (
    <div className="h-[36px] relative rounded-[8px] shrink-0 w-full" data-name="Button">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[10px] items-center px-[12px] py-[8px] relative size-full">
          <Icon2 />
          <Text3 />
        </div>
      </div>
    </div>
  );
}

function Navigation() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[2px] h-[605px] items-start left-0 overflow-clip pt-[12px] px-[8px] top-[56px] w-[235px]" data-name="Navigation">
      <Container5 />
      <Button />
      <Button1 />
      <Button2 />
    </div>
  );
}

function Container8() {
  return (
    <div className="relative rounded-[29826200px] shrink-0 size-[32px]" style={{ backgroundImage: "linear-gradient(135deg, rgb(0, 164, 255) 0%, rgb(0, 158, 252) 7.6923%, rgb(0, 152, 249) 15.385%, rgb(0, 146, 247) 23.077%, rgb(0, 140, 244) 30.769%, rgb(0, 133, 241) 38.462%, rgb(0, 127, 238) 46.154%, rgb(0, 121, 235) 53.846%, rgb(0, 115, 232) 61.538%, rgb(0, 108, 229) 69.231%, rgb(0, 102, 226) 76.923%, rgb(0, 96, 223) 84.615%, rgb(0, 89, 220) 92.308%, rgb(0, 82, 217) 100%)" }} data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[12px] text-white whitespace-nowrap">Z</p>
      </div>
    </div>
  );
}

function Container10() {
  return (
    <div className="h-[20px] overflow-clip relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#0f172b] text-[14px] top-[-0.11px] whitespace-nowrap">张伟</p>
    </div>
  );
}

function Container11() {
  return (
    <div className="h-[13.75px] overflow-clip relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[13.75px] left-0 not-italic text-[#62748e] text-[11px] top-[-0.89px] whitespace-nowrap">PTE Engineer · PTE</p>
    </div>
  );
}

function Container9() {
  return (
    <div className="flex-[123.111_0_0] h-[33.75px] min-w-px relative" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Container10 />
        <Container11 />
      </div>
    </div>
  );
}

function Icon3() {
  return (
    <div className="relative shrink-0 size-[12px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g id="Icon">
          <path d={svgPaths.p3ce80d20} id="Vector" stroke="var(--stroke-0, #90A1B9)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M8 8.5L10.5 6L8 3.5" id="Vector_2" stroke="var(--stroke-0, #90A1B9)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M10.5 6H4.5" id="Vector_3" stroke="var(--stroke-0, #90A1B9)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function Button3() {
  return (
    <div className="relative rounded-[4px] shrink-0 size-[24px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center px-[6px] relative size-full">
        <Icon3 />
      </div>
    </div>
  );
}

function Container7() {
  return (
    <div className="bg-[#f8fafc] h-[49.75px] relative rounded-[8px] shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[8px] items-center p-[8px] relative size-full">
          <Container8 />
          <Container9 />
          <Button3 />
        </div>
      </div>
    </div>
  );
}

function Icon4() {
  return (
    <div className="absolute left-[31.78px] size-[12px] top-[7.99px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g clipPath="url(#clip0_2003_1245)" id="Icon">
          <path d={svgPaths.p3e7757b0} id="Vector" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M2.465 2.465L4.585 4.585" id="Vector_2" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M7.415 4.585L9.535 2.465" id="Vector_3" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M7.415 7.415L9.535 9.535" id="Vector_4" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M4.585 7.415L2.465 9.535" id="Vector_5" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p3edd6c00} id="Vector_6" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
        <defs>
          <clipPath id="clip0_2003_1245">
            <rect fill="white" height="12" width="12" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Button4() {
  return (
    <div className="flex-[103.556_0_0] h-[27.986px] min-w-px relative rounded-[4px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Icon4 />
        <p className="-translate-x-1/2 absolute font-['Inter:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium leading-[16px] left-[59.78px] not-italic text-[#62748e] text-[12px] text-center top-[6px] whitespace-nowrap">{` 帮助`}</p>
      </div>
    </div>
  );
}

function Icon5() {
  return (
    <div className="absolute left-[31.78px] size-[12px] top-[7.99px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g clipPath="url(#clip0_2003_1266)" id="Icon">
          <path d={svgPaths.pd282f0} id="Vector" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" />
          <path d={svgPaths.p24092800} id="Vector_2" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
        <defs>
          <clipPath id="clip0_2003_1266">
            <rect fill="white" height="12" width="12" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Button5() {
  return (
    <div className="flex-[103.556_0_0] h-[27.986px] min-w-px relative rounded-[4px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Icon5 />
        <p className="-translate-x-1/2 absolute font-['Inter:Medium','Noto_Sans_SC:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium leading-[16px] left-[59.78px] not-italic text-[#62748e] text-[12px] text-center top-[6px] whitespace-nowrap">{` 设置`}</p>
      </div>
    </div>
  );
}

function Container12() {
  return (
    <div className="content-stretch flex gap-[4px] h-[27.986px] items-start relative shrink-0 w-full" data-name="Container">
      <Button4 />
      <Button5 />
    </div>
  );
}

function Container6() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] h-[110.625px] items-start left-0 pt-[12.889px] px-[12px] top-[660.93px] w-[235.111px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#f1f5f9] border-solid border-t-[0.889px] inset-0 pointer-events-none" />
      <Container7 />
      <Container12 />
    </div>
  );
}

function Sidebar() {
  return (
    <div className="absolute bg-white border-[#e2e8f0] border-r-[0.889px] border-solid h-[771.556px] left-0 top-0 w-[236px]" data-name="Sidebar">
      <Container />
      <Navigation />
      <Container6 />
    </div>
  );
}

function Button6() {
  return (
    <div className="h-[24px] relative shrink-0 w-[56.875px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid overflow-clip relative rounded-[inherit] size-full">
        <p className="-translate-x-1/2 absolute font-['Inter:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium leading-[24px] left-[28px] not-italic text-[#62748e] text-[16px] text-center top-[-1.22px] whitespace-nowrap">EA 平台</p>
      </div>
    </div>
  );
}

function Icon6() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="Icon">
          <path d="M5.25 10.5L8.75 7L5.25 3.5" id="Vector" stroke="var(--stroke-0, #CAD5E2)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
        </g>
      </svg>
    </div>
  );
}

function Text5() {
  return (
    <div className="flex-[1_0_0] h-[20px] min-w-px relative" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid overflow-clip relative rounded-[inherit] size-full">
        <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#0f172b] text-[14px] top-[-0.11px] whitespace-nowrap">我的待办</p>
      </div>
    </div>
  );
}

function Text4() {
  return (
    <div className="flex-[1_0_0] h-[20px] min-w-px relative" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[6px] items-center relative size-full">
        <Icon6 />
        <Text5 />
      </div>
    </div>
  );
}

function Container14() {
  return (
    <div className="absolute content-stretch flex gap-[6px] h-[24px] items-center left-[20px] top-[15.56px] w-[138.875px]" data-name="Container">
      <Button6 />
      <Text4 />
    </div>
  );
}

function Icon7() {
  return (
    <div className="absolute left-[8px] size-[14px] top-[9px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="Icon">
          <path d="M2.91667 7H11.0833" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d="M7 2.91667V11.0833" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
        </g>
      </svg>
    </div>
  );
}

function Button7() {
  return (
    <div className="absolute bg-[#0052d9] h-[32px] left-[795.33px] rounded-[8px] top-[11.56px] w-[94px]" data-name="Button">
      <Icon7 />
      <p className="-translate-x-1/2 absolute font-['Inter:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium leading-[20px] left-[54px] not-italic text-[14px] text-center text-white top-[5.89px] whitespace-nowrap">新建Case</p>
    </div>
  );
}

function Icon8() {
  return (
    <div className="absolute left-[12px] size-[14px] top-[8.11px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g clipPath="url(#clip0_2003_1257)" id="Icon">
          <path d={svgPaths.pc012c00} id="Vector" stroke="var(--stroke-0, #0052D9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d={svgPaths.p24950300} id="Vector_2" stroke="var(--stroke-0, #0052D9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
          <path d="M7 9.91667H7.00583" id="Vector_3" stroke="var(--stroke-0, #0052D9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
        </g>
        <defs>
          <clipPath id="clip0_2003_1257">
            <rect fill="white" height="14" width="14" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Button8() {
  return (
    <div className="absolute border-[0.889px] border-[rgba(0,82,217,0.3)] border-solid h-[32px] left-[905.33px] rounded-[8px] top-[11.56px] w-[101.778px]" data-name="Button">
      <Icon8 />
      <p className="-translate-x-1/2 absolute font-['Inter:Medium','Noto_Sans_JP:Medium','Noto_Sans_SC:Medium',sans-serif] font-medium leading-[20px] left-[60px] not-italic text-[#0052d9] text-[14px] text-center top-[5px] whitespace-nowrap">{` 系统建议`}</p>
    </div>
  );
}

function Icon9() {
  return (
    <div className="absolute left-[8px] size-[16px] top-[8px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d={svgPaths.p1ce3c700} id="Vector" stroke="var(--stroke-0, #45556C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d={svgPaths.p1a06de00} id="Vector_2" stroke="var(--stroke-0, #45556C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Text6() {
  return (
    <div className="absolute bg-[#fb2c36] content-stretch flex items-center justify-center left-[18px] px-[4px] rounded-[29826200px] size-[16px] top-[-2px]" data-name="Text">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[15px] not-italic relative shrink-0 text-[10px] text-center text-white whitespace-nowrap">3</p>
    </div>
  );
}

function Button9() {
  return (
    <div className="absolute left-[1023.11px] rounded-[8px] size-[32px] top-[11.56px]" data-name="Button">
      <Icon9 />
      <Text6 />
    </div>
  );
}

function TopBar() {
  return (
    <div className="absolute bg-white border-[#e2e8f0] border-b-[0.889px] border-solid h-[56px] left-0 top-0 w-[1075.111px]" data-name="TopBar">
      <Container14 />
      <Button7 />
      <Button8 />
      <Button9 />
    </div>
  );
}

function Icon10() {
  return (
    <div className="absolute left-0 size-[12px] top-[1.99px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g clipPath="url(#clip0_2003_1272)" id="Icon">
          <path d={svgPaths.pecd8080} id="Vector" stroke="var(--stroke-0, #7A3DFF)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M10 1.5V3.5" id="Vector_2" stroke="var(--stroke-0, #7A3DFF)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M11 2.5H9" id="Vector_3" stroke="var(--stroke-0, #7A3DFF)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M2 8.5V9.5" id="Vector_4" stroke="var(--stroke-0, #7A3DFF)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M2.5 9H1.5" id="Vector_5" stroke="var(--stroke-0, #7A3DFF)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
        <defs>
          <clipPath id="clip0_2003_1272">
            <rect fill="white" height="12" width="12" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Container17() {
  return (
    <div className="h-[15.986px] relative shrink-0 w-full" data-name="Container">
      <Icon10 />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-[20px] not-italic text-[#62748e] text-[12px] top-0 tracking-[0.6px] uppercase whitespace-nowrap">Engineer Workspace</p>
    </div>
  );
}

function Heading() {
  return (
    <div className="h-[36px] relative shrink-0 w-full" data-name="Heading 1">
      <p className="absolute font-['Inter:Medium','Noto_Sans_JP:Medium','Noto_Sans_SC:Medium',sans-serif] font-medium leading-[36px] left-0 not-italic text-[#0f172b] text-[24px] top-[-1.33px] tracking-[-0.6px] whitespace-nowrap">早上好，张伟</p>
    </div>
  );
}

function Paragraph() {
  return (
    <div className="h-[22.75px] relative shrink-0 w-full" data-name="Paragraph">
      <div className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[0] left-0 not-italic text-[#62748e] text-[14px] top-[0.01px] w-[569px]">
        <p className="leading-[22.75px] mb-0 text-[#1d293d]">AI 日报（yyyy-mm-dd）：</p>
        <p className="leading-[22.75px]">这是Ai总结的日报内容，在这里进行内容的展示，用户可以点击右侧按钮更新，复制</p>
      </div>
    </div>
  );
}

function Container16() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] h-[90.736px] items-start left-0 top-0 w-[395.375px]" data-name="Container">
      <Container17 />
      <Heading />
      <Paragraph />
    </div>
  );
}

function TintShadow() {
  return (
    <div className="absolute inset-0 rounded-[1000px] shadow-[0px_8px_40px_0px_rgba(0,0,0,0.12)]" data-name="Tint + Shadow">
      <div aria-hidden="true" className="absolute inset-0 pointer-events-none rounded-[1000px]">
        <div className="absolute bg-[rgba(255,255,255,0.75)] inset-0 rounded-[1000px]" />
        <div className="absolute bg-white inset-0 mix-blend-saturation rounded-[1000px]" />
        <div className="absolute bg-[#999] inset-0 mix-blend-overlay rounded-[1000px]" />
        <div className="absolute bg-[#0091ff] inset-0 rounded-[1000px]" />
      </div>
    </div>
  );
}

function GlassEffect() {
  return <div className="absolute bg-[rgba(0,0,0,0)] inset-0 rounded-[296px]" data-name="Glass Effect" />;
}

function Icon11() {
  return (
    <div className="absolute left-[76px] size-[12px] top-[1.99px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g id="Icon">
          <path d="M3.5 3.5H8.5V8.5" id="Vector" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M3.5 8.5L8.5 3.5" id="Vector_2" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function Button10() {
  return (
    <div className="absolute h-[15.986px] left-[904.44px] top-[74.75px] w-[88px]" data-name="Button">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium','Noto_Sans_SC:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium leading-[16px] left-[36px] not-italic text-[#62748e] text-[12px] text-center top-0 whitespace-nowrap">{`查看完整周报 `}</p>
      <Icon11 />
    </div>
  );
}

function Header() {
  return (
    <div className="absolute h-[98.736px] left-[32px] top-[32px] w-[992.444px]" data-name="Header">
      <Container16 />
      <div className="absolute content-stretch flex gap-[4px] h-[30px] items-center justify-center left-[806px] px-[20px] py-[6px] rounded-[1000px] top-[68px] w-[80px]" data-name="Button - Liquid Glass - Text">
        <TintShadow />
        <GlassEffect />
        <div className="content-stretch flex h-[36px] items-center justify-center relative rounded-[100px] shrink-0" data-name="Text">
          <div className="flex flex-col font-['SF_Pro:Medium','Noto_Sans_JP:Medium','Noto_Sans_SC:Medium',sans-serif] font-[510] justify-center leading-[0] relative shrink-0 text-[12px] text-center text-white whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100", fontFeatureSettings: "'ss16'" }}>
            <p className="leading-[normal]">更新日报</p>
          </div>
        </div>
      </div>
      <Button10 />
    </div>
  );
}

function Button11() {
  return (
    <div className="absolute h-[32px] left-[2px] rounded-[8px] top-[2px] w-[115.542px]" data-name="Button">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium leading-[20px] left-[58px] not-italic text-[#45556c] text-[14px] text-center top-[5.89px] whitespace-nowrap">我的 Case · 1</p>
    </div>
  );
}

function Button12() {
  return (
    <div className="absolute drop-shadow-[0px_1px_1.5px_rgba(0,0,0,0.1),0px_1px_1px_rgba(0,0,0,0.1)] h-[32px] left-[117.54px] rounded-[8px] top-[2px] w-[116.083px]" style={{ backgroundImage: "linear-gradient(rgb(0, 82, 217) 0%, rgb(0, 80, 212) 10%, rgb(0, 78, 207) 20%, rgb(0, 76, 202) 30%, rgb(0, 74, 197) 40%, rgb(0, 72, 192) 50%, rgb(0, 71, 187) 60%, rgb(0, 69, 182) 70%, rgb(0, 67, 178) 80%, rgb(0, 65, 173) 90%, rgb(0, 63, 168) 100%)" }} data-name="Button">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium','Noto_Sans_JP:Medium','Noto_Sans_SC:Medium',sans-serif] font-medium leading-[20px] left-[58px] not-italic text-[14px] text-center text-white top-[5.89px] whitespace-nowrap">我的任务 · 7</p>
    </div>
  );
}

function Container18() {
  return (
    <div className="absolute bg-white border-[#e2e8f0] border-[0.889px] border-solid drop-shadow-[0px_1px_1.5px_rgba(0,0,0,0.1),0px_1px_1px_rgba(0,0,0,0.1)] h-[37.778px] left-[32px] rounded-[10px] top-[162.74px] w-[237.403px]" data-name="Container">
      <Button11 />
      <Button12 />
    </div>
  );
}

function Container20() {
  return <div className="absolute bg-[#e54545] h-[81px] left-0 rounded-br-[4px] rounded-tr-[4px] top-[20px] w-[2px]" data-name="Container" />;
}

function Container21() {
  return (
    <div className="absolute h-[16.5px] left-[20px] top-[20px] w-[206.917px]" data-name="Container">
      <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[16.5px] left-0 not-italic text-[#62748e] text-[11px] top-[-0.11px] tracking-[0.55px] uppercase whitespace-nowrap">非常紧急</p>
    </div>
  );
}

function Text7() {
  return (
    <div className="absolute h-[32px] left-0 top-0 w-[17.972px]" data-name="Text">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[32px] left-0 not-italic text-[#0f172b] text-[32px] top-[-1.44px] tracking-[-0.8px] whitespace-nowrap">4</p>
    </div>
  );
}

function Container22() {
  return (
    <div className="absolute h-[32px] left-[20px] top-[44.5px] w-[206.917px]" data-name="Container">
      <Text7 />
      <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[16px] left-[25.97px] not-italic text-[#90a1b9] text-[12px] top-[16px] whitespace-nowrap">件</p>
    </div>
  );
}

function Text8() {
  return <div className="absolute bg-[#e54545] left-0 rounded-[29826200px] size-[4px] top-[6.25px]" data-name="Text" />;
}

function Container23() {
  return (
    <div className="absolute h-[16.5px] left-[20px] top-[84.5px] w-[206.917px]" data-name="Container">
      <Text8 />
      <p className="absolute font-['Inter:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[16.5px] left-[8px] not-italic text-[#e7000b] text-[11px] top-[-0.11px] whitespace-nowrap">2 项已逾期</p>
    </div>
  );
}

function Container24() {
  return <div className="absolute bg-[#0052d9] h-[81px] left-0 rounded-br-[4px] rounded-tr-[4px] top-[20px] w-[2px]" data-name="Container" />;
}

function Container25() {
  return (
    <div className="absolute h-[16.5px] left-[20px] top-[20px] w-[206.917px]" data-name="Container">
      <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[16.5px] left-0 not-italic text-[#62748e] text-[11px] top-[-0.11px] tracking-[0.55px] uppercase whitespace-nowrap">我的任务（含子）</p>
    </div>
  );
}

function Container26() {
  return (
    <div className="absolute font-normal h-[32px] left-[20px] not-italic top-[44.5px] w-[206.917px] whitespace-nowrap" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] leading-[32px] left-0 text-[#0f172b] text-[32px] top-[-1.44px] tracking-[-0.8px]">7</p>
      <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] leading-[16px] left-[25px] text-[#90a1b9] text-[12px] top-[16.5px]">件</p>
    </div>
  );
}

function Text9() {
  return <div className="absolute bg-[#0052d9] left-0 rounded-[29826200px] size-[4px] top-[6.25px]" data-name="Text" />;
}

function Container27() {
  return (
    <div className="absolute h-[16.5px] left-[20px] top-[84.5px] w-[206.917px]" data-name="Container">
      <Text9 />
      <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[16.5px] left-[8px] not-italic text-[#62748e] text-[11px] top-[-0.11px] whitespace-nowrap">分布 3 个 Case</p>
    </div>
  );
}

function StatCell1() {
  return (
    <div className="absolute bg-white h-[121px] left-[-247px] top-0 w-[246.917px]" data-name="StatCell">
      <Container24 />
      <Container25 />
      <Container26 />
      <Container27 />
    </div>
  );
}

function StatCell() {
  return (
    <div className="absolute bg-white h-[121px] left-[249px] top-px w-[246.917px]" data-name="StatCell">
      <Container20 />
      <Container21 />
      <Container22 />
      <Container23 />
      <StatCell1 />
    </div>
  );
}

function Container28() {
  return <div className="absolute bg-[#f7a000] h-[81px] left-0 rounded-br-[4px] rounded-tr-[4px] top-[20px] w-[2px]" data-name="Container" />;
}

function Container29() {
  return (
    <div className="absolute h-[16.5px] left-[20px] top-[20px] w-[206.917px]" data-name="Container">
      <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[16.5px] left-0 not-italic text-[#62748e] text-[11px] top-[-0.11px] tracking-[0.55px] uppercase whitespace-nowrap">今日到期</p>
    </div>
  );
}

function Container30() {
  return (
    <div className="absolute font-normal h-[32px] left-[20px] not-italic top-[44.5px] w-[206.917px] whitespace-nowrap" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] leading-[32px] left-0 text-[#0f172b] text-[32px] top-[-1.44px] tracking-[-0.8px]">1</p>
      <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] leading-[16px] left-[25.97px] text-[#90a1b9] text-[12px] top-[16px]">件</p>
    </div>
  );
}

function Text10() {
  return <div className="absolute bg-[#f7a000] left-0 rounded-[29826200px] size-[4px] top-[6.25px]" data-name="Text" />;
}

function Container31() {
  return (
    <div className="absolute h-[16.5px] left-[20px] top-[84.5px] w-[206.917px]" data-name="Container">
      <Text10 />
      <p className="absolute font-['Inter:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[16.5px] left-[8px] not-italic text-[#62748e] text-[11px] top-[-0.11px] whitespace-nowrap">优先完成</p>
    </div>
  );
}

function StatCell2() {
  return (
    <div className="absolute bg-white h-[121px] left-[496.92px] top-px w-[246.917px]" data-name="StatCell">
      <Container28 />
      <Container29 />
      <Container30 />
      <Container31 />
    </div>
  );
}

function Container19() {
  return (
    <div className="absolute h-[122px] left-[32px] rounded-[14px] top-[233px] w-[744px]" data-name="Container">
      <div aria-hidden="true" className="absolute bg-[rgba(226,232,240,0.7)] inset-0 pointer-events-none rounded-[14px]" />
      <div className="overflow-clip relative rounded-[inherit] size-full">
        <StatCell />
        <StatCell2 />
      </div>
      <div className="absolute inset-0 pointer-events-none rounded-[inherit] shadow-[inset_0px_1px_0px_0px_rgba(255,255,255,0.5)]" />
      <div aria-hidden="true" className="absolute border-[0.889px] border-[rgba(226,232,240,0.7)] border-solid inset-0 pointer-events-none rounded-[14px]" />
    </div>
  );
}

function Icon12() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="Icon">
          <path d={svgPaths.p698ed80} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
        </g>
      </svg>
    </div>
  );
}

function Container34() {
  return (
    <div className="drop-shadow-[0px_1px_1.5px_#bedbff,0px_1px_1px_#bedbff] relative rounded-[10px] shrink-0 size-[28px]" style={{ backgroundImage: "linear-gradient(135deg, rgb(0, 82, 217) 0%, rgb(30, 81, 220) 9.0909%, rgb(46, 80, 224) 18.182%, rgb(58, 79, 227) 27.273%, rgb(68, 77, 231) 36.364%, rgb(77, 75, 234) 45.455%, rgb(86, 74, 238) 54.545%, rgb(93, 72, 241) 63.636%, rgb(101, 69, 245) 72.727%, rgb(108, 67, 248) 81.818%, rgb(115, 64, 251) 90.909%, rgb(122, 61, 255) 100%)" }} data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center px-[7px] relative size-full">
        <Icon12 />
      </div>
    </div>
  );
}

function Heading1() {
  return (
    <div className="h-[27px] relative shrink-0 w-full" data-name="Heading 3">
      <p className="absolute font-['Inter:Medium','Noto_Sans_JP:Medium','Noto_Sans_SC:Medium',sans-serif] font-medium leading-[27px] left-0 not-italic text-[#0f172b] text-[18px] top-[-0.22px] whitespace-nowrap">我的任务列表</p>
    </div>
  );
}

function Paragraph1() {
  return (
    <div className="content-stretch flex h-[15.986px] items-start relative shrink-0 w-full" data-name="Paragraph">
      <p className="font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#62748e] text-[12px] whitespace-nowrap">7 个 · 跨 3 个 Case</p>
    </div>
  );
}

function Container35() {
  return (
    <div className="flex-[1_0_0] h-[44.986px] min-w-px relative" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[2px] items-start relative size-full">
        <Heading1 />
        <Paragraph1 />
      </div>
    </div>
  );
}

function Container33() {
  return (
    <div className="absolute content-stretch flex gap-[10px] h-[44.986px] items-center left-0 top-0 w-[146px]" data-name="Container">
      <Container34 />
      <Container35 />
    </div>
  );
}

function Container32() {
  return (
    <div className="h-[44.986px] relative shrink-0 w-full" data-name="Container">
      <Container33 />
    </div>
  );
}

function Icon13() {
  return (
    <div className="relative shrink-0 size-[15px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
        <g id="Icon">
          <path d={svgPaths.p5aee0f2} id="Vector" stroke="var(--stroke-0, #0052D9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
        </g>
      </svg>
    </div>
  );
}

function Text11() {
  return (
    <div className="bg-[#fff7ed] h-[20.778px] relative rounded-[4px] shrink-0 w-[24.778px]" data-name="Text">
      <div aria-hidden="true" className="absolute border-[#ffd6a8] border-[0.889px] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[15px] left-[6.89px] not-italic text-[#f54900] text-[10px] top-[2.78px] whitespace-nowrap">L2</p>
      </div>
    </div>
  );
}

function Text12() {
  return (
    <div className="h-[16.5px] relative shrink-0 w-[44.25px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Consolas:Medium',sans-serif] leading-[16.5px] left-0 not-italic text-[#90a1b9] text-[11px] top-[-0.22px] tracking-[0.275px] whitespace-nowrap">001.003</p>
      </div>
    </div>
  );
}

function Text13() {
  return (
    <div className="flex-[702.097_0_0] h-[20px] min-w-px relative" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid overflow-clip relative rounded-[inherit] size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[20px] left-0 not-italic text-[#1d293d] text-[14px] top-[-0.11px] whitespace-nowrap">DDR5 X-die CP1 yield drop @Site A</p>
      </div>
    </div>
  );
}

function Text14() {
  return <div className="h-[15.986px] relative shrink-0 w-[46.958px]" data-name="Text" />;
}

function Button13() {
  return (
    <div className="absolute bg-[#f8fafc] content-stretch flex gap-[10px] h-[45.667px] items-center left-[0.89px] pb-[12.889px] pl-[20px] pr-[97.583px] pt-[12px] top-[0.89px] w-[990.667px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#f1f5f9] border-b-[0.889px] border-solid inset-0 pointer-events-none" />
      <Icon13 />
      <Text11 />
      <Text12 />
      <Text13 />
      <Text14 />
      <p className="font-['Inter:Bold','Noto_Sans_JP:Medium','Noto_Sans_SC:Medium',sans-serif] font-bold leading-[0] not-italic relative shrink-0 text-[#1d293d] text-[0px] whitespace-nowrap">
        <span className="leading-[16px] text-[12px]">3</span>
        <span className="font-['Inter:Medium','Noto_Sans_JP:Medium','Noto_Sans_SC:Medium',sans-serif] font-medium leading-[16px] text-[#62748e] text-[12px]">{` 个任务`}</span>
      </p>
    </div>
  );
}

function Container40() {
  return <div className="bg-[#fb2c36] h-[33.764px] relative rounded-br-[4px] rounded-tr-[4px] shrink-0 w-[2px]" data-name="Container" />;
}

function Container41() {
  return (
    <div className="bg-[#fb2c36] h-[19px] relative rounded-[4px] shrink-0 w-[52px]" data-name="Container">
      <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[15px] left-[6px] not-italic text-[10px] text-white top-[1.89px] whitespace-nowrap">非常紧急</p>
    </div>
  );
}

function Container42() {
  return (
    <div className="h-[20px] overflow-clip relative shrink-0 w-[459px]" data-name="Container">
      <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#1d293d] text-[14px] top-[-0.11px] whitespace-nowrap">ICC2 分布分析与 Pattern 定位</p>
    </div>
  );
}

function Text15() {
  return (
    <div className="h-[17px] relative shrink-0 w-[52px]" data-name="Text">
      <p className="absolute font-['Inter:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[16.5px] left-0 not-italic text-[#62748e] text-[11px] top-[-0.11px] tracking-[0.275px] whitespace-nowrap">PTE · 张伟</p>
    </div>
  );
}

function Icon14() {
  return (
    <div className="absolute left-[14.32px] size-[11px] top-[2.49px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
        <g clipPath="url(#clip0_2003_1233)" id="Icon">
          <path d={svgPaths.p2b85b880} id="Vector" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
          <path d="M7.33333 0.916667V2.75" id="Vector_2" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
          <path d="M3.66667 0.916667V2.75" id="Vector_3" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
          <path d="M1.375 4.58333H3.66667" id="Vector_4" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
          <path d={svgPaths.p25f3fc00} id="Vector_5" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
          <path d={svgPaths.p6cd8c00} id="Vector_6" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
        </g>
        <defs>
          <clipPath id="clip0_2003_1233">
            <rect fill="white" height="11" width="11" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Text16() {
  return (
    <div className="h-[15.986px] relative shrink-0 w-[96px]" data-name="Text">
      <Icon14 />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-[29.32px] not-italic text-[#62748e] text-[12px] top-0 whitespace-nowrap">2026-04-22</p>
    </div>
  );
}

function Text17() {
  return (
    <div className="bg-[#fef2f2] h-[25.764px] relative rounded-[8px] shrink-0 w-[80px]" data-name="Text">
      <div aria-hidden="true" className="absolute border-[#ffc9c9] border-[0.889px] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <p className="-translate-x-1/2 absolute font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[16px] left-[40.29px] not-italic text-[#e7000b] text-[12px] text-center top-[4.89px] tracking-[-0.3px] whitespace-nowrap">今日</p>
    </div>
  );
}

function Container39() {
  return (
    <div className="content-stretch flex gap-[16px] items-center py-[8px] relative shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[rgba(241,245,249,0.7)] border-b-[0.889px] border-solid inset-0 pointer-events-none" />
      <Container40 />
      <Container41 />
      <div className="bg-[#0091ff] content-stretch flex gap-[8px] h-[19px] items-center justify-center p-[8px] relative rounded-[8px] shrink-0" data-name="Tag">
        <p className="font-['Roboto:SemiBold',sans-serif] font-semibold leading-[16px] relative shrink-0 text-[#f5f5f5] text-[11px] tracking-[0.5px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
          进行中
        </p>
      </div>
      <Container42 />
      <Text15 />
      <Text16 />
      <Text17 />
      <p className="font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[16.5px] not-italic relative shrink-0 text-[#62748e] text-[11px] whitespace-nowrap">同意</p>
      <p className="font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[16.5px] not-italic relative shrink-0 text-[#62748e] text-[11px] whitespace-nowrap">拒绝</p>
    </div>
  );
}

function Container44() {
  return <div className="bg-[#fb2c36] h-[33.764px] relative rounded-br-[4px] rounded-tr-[4px] shrink-0 w-[2px]" data-name="Container" />;
}

function Container45() {
  return (
    <div className="bg-[#fb2c36] h-[19px] relative rounded-[4px] shrink-0 w-[52px]" data-name="Container">
      <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[15px] left-[6px] not-italic text-[10px] text-white top-[1.89px] whitespace-nowrap">非常紧急</p>
    </div>
  );
}

function Container46() {
  return (
    <div className="h-[20px] overflow-clip relative shrink-0 w-[459px]" data-name="Container">
      <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#1d293d] text-[14px] top-[-0.11px] whitespace-nowrap">输出 Pattern P_ICC2_07 调整方案评审稿</p>
    </div>
  );
}

function Text18() {
  return (
    <div className="h-[17px] relative shrink-0 w-[54px]" data-name="Text">
      <p className="absolute font-['Inter:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[16.5px] left-0 not-italic text-[#62748e] text-[11px] top-0 tracking-[0.275px] whitespace-nowrap">PTE · 张伟</p>
    </div>
  );
}

function Icon15() {
  return (
    <div className="absolute left-[14.32px] size-[11px] top-[2.49px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
        <g clipPath="url(#clip0_2003_1233)" id="Icon">
          <path d={svgPaths.p2b85b880} id="Vector" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
          <path d="M7.33333 0.916667V2.75" id="Vector_2" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
          <path d="M3.66667 0.916667V2.75" id="Vector_3" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
          <path d="M1.375 4.58333H3.66667" id="Vector_4" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
          <path d={svgPaths.p25f3fc00} id="Vector_5" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
          <path d={svgPaths.p6cd8c00} id="Vector_6" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
        </g>
        <defs>
          <clipPath id="clip0_2003_1233">
            <rect fill="white" height="11" width="11" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Text19() {
  return (
    <div className="h-[15.986px] relative shrink-0 w-[96px]" data-name="Text">
      <Icon15 />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-[29.32px] not-italic text-[#62748e] text-[12px] top-0 whitespace-nowrap">2026-04-23</p>
    </div>
  );
}

function Text20() {
  return (
    <div className="bg-[#fef2f2] h-[25.764px] relative rounded-[8px] shrink-0 w-[80px]" data-name="Text">
      <div aria-hidden="true" className="absolute border-[#ffc9c9] border-[0.889px] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <p className="-translate-x-1/2 absolute font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[16px] left-[40.65px] not-italic text-[#e7000b] text-[12px] text-center top-[4.89px] tracking-[-0.3px] whitespace-nowrap">1 天</p>
    </div>
  );
}

function Container43() {
  return (
    <div className="content-stretch flex gap-[16px] items-center py-[8px] relative shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[rgba(241,245,249,0.7)] border-b-[0.889px] border-solid inset-0 pointer-events-none" />
      <Container44 />
      <Container45 />
      <div className="bg-[#e5a000] content-stretch flex gap-[8px] h-[19px] items-center justify-center p-[8px] relative rounded-[8px] shrink-0" data-name="Tag">
        <p className="font-['Roboto:SemiBold',sans-serif] font-semibold leading-[16px] relative shrink-0 text-[#f5f5f5] text-[11px] tracking-[0.5px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
          待同意
        </p>
      </div>
      <Container46 />
      <Text18 />
      <Text19 />
      <Text20 />
      <p className="font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[16.5px] not-italic relative shrink-0 text-[#009efc] text-[11px] whitespace-nowrap">同意</p>
      <p className="font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[16.5px] not-italic relative shrink-0 text-[#009efc] text-[11px] whitespace-nowrap">拒绝</p>
    </div>
  );
}

function Container48() {
  return (
    <div className="bg-[#ff6900] h-[19px] relative rounded-[4px] shrink-0 w-[32px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[15px] left-[6px] not-italic text-[10px] text-white top-[1.89px] whitespace-nowrap">紧急</p>
      </div>
    </div>
  );
}

function Container49() {
  return (
    <div className="h-[20px] relative shrink-0 w-[477px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid overflow-clip relative rounded-[inherit] size-full">
        <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#1d293d] text-[14px] top-[-0.11px] whitespace-nowrap">同步 EFA 切片初步结论至客户沟通稿</p>
      </div>
    </div>
  );
}

function Text21() {
  return (
    <div className="h-[16.5px] relative shrink-0 w-[52.431px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[16.5px] left-0 not-italic text-[#62748e] text-[11px] top-[-0.11px] tracking-[0.275px] whitespace-nowrap">PTE · 张伟</p>
      </div>
    </div>
  );
}

function Icon16() {
  return (
    <div className="absolute left-[14.32px] size-[11px] top-[2.49px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
        <g clipPath="url(#clip0_2003_1233)" id="Icon">
          <path d={svgPaths.p2b85b880} id="Vector" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
          <path d="M7.33333 0.916667V2.75" id="Vector_2" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
          <path d="M3.66667 0.916667V2.75" id="Vector_3" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
          <path d="M1.375 4.58333H3.66667" id="Vector_4" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
          <path d={svgPaths.p25f3fc00} id="Vector_5" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
          <path d={svgPaths.p6cd8c00} id="Vector_6" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
        </g>
        <defs>
          <clipPath id="clip0_2003_1233">
            <rect fill="white" height="11" width="11" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Text22() {
  return (
    <div className="h-[15.986px] relative shrink-0 w-[96px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Icon16 />
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-[29.32px] not-italic text-[#62748e] text-[12px] top-0 whitespace-nowrap">2026-04-25</p>
      </div>
    </div>
  );
}

function Text23() {
  return (
    <div className="bg-[#fffbeb] h-[25.764px] relative rounded-[8px] shrink-0 w-[80px]" data-name="Text">
      <div aria-hidden="true" className="absolute border-[#fee685] border-[0.889px] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[16px] left-[40.65px] not-italic text-[#e17100] text-[12px] text-center top-[4.89px] tracking-[-0.3px] whitespace-nowrap">3 天</p>
      </div>
    </div>
  );
}

function Container47() {
  return (
    <div className="relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[16px] items-center px-[20px] py-[12px] relative size-full">
          <Container48 />
          <div className="bg-[#e5a000] h-[19px] relative rounded-[8px] shrink-0" data-name="Tag">
            <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center justify-center p-[8px] relative size-full">
              <p className="font-['Roboto:SemiBold',sans-serif] font-semibold leading-[16px] relative shrink-0 text-[#f5f5f5] text-[11px] tracking-[0.5px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
                待同意
              </p>
            </div>
          </div>
          <Container49 />
          <Text21 />
          <Text22 />
          <Text23 />
          <p className="font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[16.5px] not-italic relative shrink-0 text-[#009efc] text-[11px] whitespace-nowrap">同意</p>
          <p className="font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[16.5px] not-italic relative shrink-0 text-[#009efc] text-[11px] whitespace-nowrap">拒绝</p>
        </div>
      </div>
    </div>
  );
}

function Container38() {
  return (
    <div className="absolute content-stretch flex flex-col h-[151.069px] items-start left-[0.89px] top-[46.56px] w-[990.667px]" data-name="Container">
      <Container39 />
      <Container43 />
      <Container47 />
    </div>
  );
}

function Container37() {
  return (
    <div className="bg-white h-[198.514px] relative rounded-[14px] shrink-0 w-full" data-name="Container">
      <div className="overflow-clip relative rounded-[inherit] size-full">
        <Button13 />
        <Container38 />
      </div>
      <div aria-hidden="true" className="absolute border-[0.889px] border-[rgba(226,232,240,0.8)] border-solid inset-0 pointer-events-none rounded-[14px] shadow-[0px_1px_2px_0px_rgba(15,23,42,0.04)]" />
    </div>
  );
}

function Icon17() {
  return (
    <div className="relative shrink-0 size-[15px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
        <g id="Icon">
          <path d={svgPaths.p5aee0f2} id="Vector" stroke="var(--stroke-0, #0052D9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
        </g>
      </svg>
    </div>
  );
}

function Text24() {
  return (
    <div className="bg-[#fffbeb] h-[20.778px] relative rounded-[4px] shrink-0 w-[24.778px]" data-name="Text">
      <div aria-hidden="true" className="absolute border-[#fee685] border-[0.889px] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[15px] left-[6.89px] not-italic text-[#e17100] text-[10px] top-[2.78px] whitespace-nowrap">L3</p>
      </div>
    </div>
  );
}

function Text25() {
  return (
    <div className="h-[16.5px] relative shrink-0 w-[44.25px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Consolas:Medium',sans-serif] leading-[16.5px] left-0 not-italic text-[#90a1b9] text-[11px] top-[-0.22px] tracking-[0.275px] whitespace-nowrap">001.004</p>
      </div>
    </div>
  );
}

function Text26() {
  return (
    <div className="flex-[702.097_0_0] h-[20px] min-w-px relative" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid overflow-clip relative rounded-[inherit] size-full">
        <p className="absolute font-['Inter:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium leading-[20px] left-0 not-italic text-[#1d293d] text-[14px] top-[-0.11px] whitespace-nowrap">LPDDR5 FT Retest Rate 偏高</p>
      </div>
    </div>
  );
}

function Text27() {
  return (
    <div className="h-[15.986px] relative shrink-0 w-[46.958px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Inter:Bold','Noto_Sans_JP:Medium','Noto_Sans_SC:Medium',sans-serif] font-bold leading-[0] not-italic relative shrink-0 text-[#1d293d] text-[0px] whitespace-nowrap">
          <span className="leading-[16px] text-[12px]">1</span>
          <span className="font-['Inter:Medium','Noto_Sans_JP:Medium','Noto_Sans_SC:Medium',sans-serif] font-medium leading-[16px] text-[#62748e] text-[12px]">{` 个任务`}</span>
        </p>
      </div>
    </div>
  );
}

function Button14() {
  return (
    <div className="bg-[#f8fafc] h-[45.667px] relative shrink-0 w-full" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#f1f5f9] border-b-[0.889px] border-solid inset-0 pointer-events-none" />
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[10px] items-center pb-[12.889px] pl-[20px] pr-[97.583px] pt-[12px] relative size-full">
          <Icon17 />
          <Text24 />
          <Text25 />
          <Text26 />
          <Text27 />
        </div>
      </div>
    </div>
  );
}

function Container52() {
  return (
    <div className="bg-[#ff6900] h-[19px] relative rounded-[4px] shrink-0 w-[32px]" data-name="Container">
      <p className="absolute font-['Inter:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[15px] left-[6px] not-italic text-[10px] text-white top-[1.89px] whitespace-nowrap">紧急</p>
    </div>
  );
}

function Container53() {
  return (
    <div className="h-[20px] overflow-clip relative shrink-0 w-[479px]" data-name="Container">
      <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular','Noto_Sans_KR:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#1d293d] text-[14px] top-[-0.11px] whitespace-nowrap">Contact 清洁周期对照实验</p>
    </div>
  );
}

function Text28() {
  return (
    <div className="h-[16.5px] relative shrink-0 w-[52.431px]" data-name="Text">
      <p className="absolute font-['Inter:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[16.5px] left-0 not-italic text-[#62748e] text-[11px] top-[-0.11px] tracking-[0.275px] whitespace-nowrap">PTE · 张伟</p>
    </div>
  );
}

function Icon18() {
  return (
    <div className="absolute left-[14.32px] size-[11px] top-[2.49px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
        <g clipPath="url(#clip0_2003_1233)" id="Icon">
          <path d={svgPaths.p2b85b880} id="Vector" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
          <path d="M7.33333 0.916667V2.75" id="Vector_2" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
          <path d="M3.66667 0.916667V2.75" id="Vector_3" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
          <path d="M1.375 4.58333H3.66667" id="Vector_4" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
          <path d={svgPaths.p25f3fc00} id="Vector_5" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
          <path d={svgPaths.p6cd8c00} id="Vector_6" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
        </g>
        <defs>
          <clipPath id="clip0_2003_1233">
            <rect fill="white" height="11" width="11" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Text29() {
  return (
    <div className="h-[15.986px] relative shrink-0 w-[96px]" data-name="Text">
      <Icon18 />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-[29.32px] not-italic text-[#62748e] text-[12px] top-0 whitespace-nowrap">2026-04-24</p>
    </div>
  );
}

function Text30() {
  return (
    <div className="bg-[#fffbeb] h-[25.764px] relative rounded-[8px] shrink-0 w-[80px]" data-name="Text">
      <div aria-hidden="true" className="absolute border-[#fee685] border-[0.889px] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <p className="-translate-x-1/2 absolute font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[16px] left-[40.65px] not-italic text-[#e17100] text-[12px] text-center top-[4.89px] tracking-[-0.3px] whitespace-nowrap">2 天</p>
    </div>
  );
}

function Container51() {
  return (
    <div className="h-[49.764px] relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[16px] items-center px-[20px] py-[12px] relative size-full">
          <Container52 />
          <div className="bg-[#e5a000] content-stretch flex gap-[8px] h-[19px] items-center justify-center p-[8px] relative rounded-[8px] shrink-0" data-name="Tag">
            <p className="font-['Roboto:SemiBold',sans-serif] font-semibold leading-[16px] relative shrink-0 text-[#f5f5f5] text-[11px] tracking-[0.5px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
              待同意
            </p>
          </div>
          <Container53 />
          <Text28 />
          <Text29 />
          <Text30 />
          <p className="font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[16.5px] not-italic relative shrink-0 text-[#009efc] text-[11px] whitespace-nowrap">同意</p>
          <p className="font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[16.5px] not-italic relative shrink-0 text-[#009efc] text-[11px] whitespace-nowrap">拒绝</p>
        </div>
      </div>
    </div>
  );
}

function Container50() {
  return (
    <div className="bg-white h-[97.208px] relative rounded-[14px] shrink-0 w-full" data-name="Container">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col items-start p-[0.889px] relative size-full">
          <Button14 />
          <Container51 />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border-[0.889px] border-[rgba(226,232,240,0.8)] border-solid inset-0 pointer-events-none rounded-[14px] shadow-[0px_1px_2px_0px_rgba(15,23,42,0.04)]" />
    </div>
  );
}

function Icon19() {
  return (
    <div className="relative shrink-0 size-[15px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
        <g id="Icon">
          <path d={svgPaths.p5aee0f2} id="Vector" stroke="var(--stroke-0, #0052D9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" />
        </g>
      </svg>
    </div>
  );
}

function Text31() {
  return (
    <div className="bg-[#fef2f2] h-[20.778px] relative rounded-[4px] shrink-0 w-[24.778px]" data-name="Text">
      <div aria-hidden="true" className="absolute border-[#ffc9c9] border-[0.889px] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[15px] left-[6.89px] not-italic text-[#e7000b] text-[10px] top-[2.78px] whitespace-nowrap">L1</p>
      </div>
    </div>
  );
}

function Text32() {
  return (
    <div className="h-[16.5px] relative shrink-0 w-[44.25px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Consolas:Medium',sans-serif] leading-[16.5px] left-0 not-italic text-[#90a1b9] text-[11px] top-[-0.22px] tracking-[0.275px] whitespace-nowrap">001.002</p>
      </div>
    </div>
  );
}

function Text33() {
  return (
    <div className="flex-[702.097_0_0] h-[20px] min-w-px relative" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid overflow-clip relative rounded-[inherit] size-full">
        <p className="absolute font-['Inter:Medium','Noto_Sans_JP:Medium','Noto_Sans_SC:Medium',sans-serif] font-medium leading-[20px] left-0 not-italic text-[#1d293d] text-[14px] top-[-0.11px] whitespace-nowrap">DDR4 Lot 退货影响分析</p>
      </div>
    </div>
  );
}

function Text34() {
  return (
    <div className="h-[15.986px] relative shrink-0 w-[46.958px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Inter:Bold','Noto_Sans_JP:Medium','Noto_Sans_SC:Medium',sans-serif] font-bold leading-[0] not-italic relative shrink-0 text-[#1d293d] text-[0px] whitespace-nowrap">
          <span className="leading-[16px] text-[12px]">3</span>
          <span className="font-['Inter:Medium','Noto_Sans_JP:Medium','Noto_Sans_SC:Medium',sans-serif] font-medium leading-[16px] text-[#62748e] text-[12px]">{` 个任务`}</span>
        </p>
      </div>
    </div>
  );
}

function Button15() {
  return (
    <div className="absolute bg-[#f8fafc] content-stretch flex gap-[10px] h-[45.667px] items-center left-[0.89px] pb-[12.889px] pl-[20px] pr-[97.583px] pt-[12px] top-[0.89px] w-[990.667px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#f1f5f9] border-b-[0.889px] border-solid inset-0 pointer-events-none" />
      <Icon19 />
      <Text31 />
      <Text32 />
      <Text33 />
      <Text34 />
    </div>
  );
}

function Container57() {
  return <div className="bg-[#fb2c36] h-[33.764px] relative rounded-br-[4px] rounded-tr-[4px] shrink-0 w-[2px]" data-name="Container" />;
}

function Container58() {
  return (
    <div className="bg-[#fb2c36] h-[19px] relative rounded-[4px] shrink-0 w-[52px]" data-name="Container">
      <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[15px] left-[6px] not-italic text-[10px] text-white top-[1.89px] whitespace-nowrap">非常紧急</p>
    </div>
  );
}

function Container59() {
  return (
    <div className="h-[20px] overflow-clip relative shrink-0 w-[460px]" data-name="Container">
      <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#1d293d] text-[14px] top-[-0.11px] whitespace-nowrap">回片复测数据汇总（PTE 配合）</p>
    </div>
  );
}

function Text35() {
  return (
    <div className="h-[16.5px] relative shrink-0 w-[52.431px]" data-name="Text">
      <p className="absolute font-['Inter:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[16.5px] left-0 not-italic text-[#62748e] text-[11px] top-[-0.11px] tracking-[0.275px] whitespace-nowrap">PTE · 张伟</p>
    </div>
  );
}

function Icon20() {
  return (
    <div className="absolute left-[14.32px] size-[11px] top-[2.49px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
        <g clipPath="url(#clip0_2003_1233)" id="Icon">
          <path d={svgPaths.p2b85b880} id="Vector" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
          <path d="M7.33333 0.916667V2.75" id="Vector_2" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
          <path d="M3.66667 0.916667V2.75" id="Vector_3" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
          <path d="M1.375 4.58333H3.66667" id="Vector_4" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
          <path d={svgPaths.p25f3fc00} id="Vector_5" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
          <path d={svgPaths.p6cd8c00} id="Vector_6" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
        </g>
        <defs>
          <clipPath id="clip0_2003_1233">
            <rect fill="white" height="11" width="11" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Text36() {
  return (
    <div className="h-[15.986px] relative shrink-0 w-[96px]" data-name="Text">
      <Icon20 />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-[29.32px] not-italic text-[#62748e] text-[12px] top-0 whitespace-nowrap">2026-04-23</p>
    </div>
  );
}

function Text37() {
  return (
    <div className="bg-[#fef2f2] h-[25.764px] relative rounded-[8px] shrink-0 w-[80px]" data-name="Text">
      <div aria-hidden="true" className="absolute border-[#ffc9c9] border-[0.889px] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <p className="-translate-x-1/2 absolute font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[16px] left-[40.65px] not-italic text-[#e7000b] text-[12px] text-center top-[4.89px] tracking-[-0.3px] whitespace-nowrap">1 天</p>
    </div>
  );
}

function Container56() {
  return (
    <div className="absolute content-stretch flex gap-[16px] items-center left-[0.11px] py-[8px] top-[0.44px] w-[991px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[rgba(241,245,249,0.7)] border-b-[0.889px] border-solid inset-0 pointer-events-none" />
      <Container57 />
      <Container58 />
      <div className="bg-[#0091ff] content-stretch flex gap-[8px] h-[19px] items-center justify-center p-[8px] relative rounded-[8px] shrink-0" data-name="Tag">
        <p className="font-['Roboto:SemiBold',sans-serif] font-semibold leading-[16px] relative shrink-0 text-[#f5f5f5] text-[11px] tracking-[0.5px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
          进行中
        </p>
      </div>
      <Container59 />
      <Text35 />
      <Text36 />
      <Text37 />
      <p className="font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[16.5px] not-italic relative shrink-0 text-[#62748e] text-[11px] whitespace-nowrap">同意</p>
      <p className="font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[16.5px] not-italic relative shrink-0 text-[#62748e] text-[11px] whitespace-nowrap">拒绝</p>
    </div>
  );
}

function Container61() {
  return <div className="bg-[#fb2c36] h-[33.764px] relative rounded-br-[4px] rounded-tr-[4px] shrink-0 w-[2px]" data-name="Container" />;
}

function Text38() {
  return (
    <div className="h-[12px] relative shrink-0 w-[8.514px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular','Noto_Sans:Regular',sans-serif] font-normal leading-[12px] left-0 not-italic text-[#cad5e2] text-[12px] top-[0.22px] whitespace-nowrap">└</p>
      </div>
    </div>
  );
}

function Text39() {
  return (
    <div className="bg-[#fb2c36] h-[19px] relative rounded-[4px] shrink-0 w-[52px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[15px] left-[6px] not-italic text-[10px] text-white top-[1.89px] whitespace-nowrap">非常紧急</p>
      </div>
    </div>
  );
}

function Container62() {
  return (
    <div className="content-stretch flex gap-[6px] h-[19px] items-center pl-[20px] relative shrink-0 w-[86.514px]" data-name="Container">
      <Text38 />
      <Text39 />
    </div>
  );
}

function Container63() {
  return (
    <div className="h-[20px] overflow-clip relative shrink-0 w-[427px]" data-name="Container">
      <p className="absolute font-['Inter:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#1d293d] text-[14px] top-[-0.11px] whitespace-nowrap">PTE 侧 datalog 整合</p>
    </div>
  );
}

function Text40() {
  return (
    <div className="h-[16.5px] relative shrink-0 w-[52.431px]" data-name="Text">
      <p className="absolute font-['Inter:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[16.5px] left-0 not-italic text-[#62748e] text-[11px] top-[-0.11px] tracking-[0.275px] whitespace-nowrap">PTE · 张伟</p>
    </div>
  );
}

function Icon21() {
  return (
    <div className="absolute left-[14.32px] size-[11px] top-[2.49px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
        <g clipPath="url(#clip0_2003_1233)" id="Icon">
          <path d={svgPaths.p2b85b880} id="Vector" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
          <path d="M7.33333 0.916667V2.75" id="Vector_2" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
          <path d="M3.66667 0.916667V2.75" id="Vector_3" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
          <path d="M1.375 4.58333H3.66667" id="Vector_4" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
          <path d={svgPaths.p25f3fc00} id="Vector_5" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
          <path d={svgPaths.p6cd8c00} id="Vector_6" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
        </g>
        <defs>
          <clipPath id="clip0_2003_1233">
            <rect fill="white" height="11" width="11" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Text41() {
  return (
    <div className="h-[15.986px] relative shrink-0 w-[96px]" data-name="Text">
      <Icon21 />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-[29.32px] not-italic text-[#62748e] text-[12px] top-0 whitespace-nowrap">2026-04-23</p>
    </div>
  );
}

function Text42() {
  return (
    <div className="bg-[#fef2f2] h-[25.764px] relative rounded-[8px] shrink-0 w-[80px]" data-name="Text">
      <div aria-hidden="true" className="absolute border-[#ffc9c9] border-[0.889px] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <p className="-translate-x-1/2 absolute font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[16px] left-[40.65px] not-italic text-[#e7000b] text-[12px] text-center top-[4.89px] tracking-[-0.3px] whitespace-nowrap">1 天</p>
    </div>
  );
}

function Container60() {
  return (
    <div className="absolute content-stretch flex gap-[16px] items-center left-0 py-[8px] top-[50.65px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[rgba(241,245,249,0.7)] border-b-[0.889px] border-solid inset-0 pointer-events-none" />
      <Container61 />
      <Container62 />
      <div className="bg-[#0091ff] content-stretch flex gap-[8px] h-[19px] items-center justify-center p-[8px] relative rounded-[8px] shrink-0" data-name="Tag">
        <p className="font-['Roboto:SemiBold',sans-serif] font-semibold leading-[16px] relative shrink-0 text-[#f5f5f5] text-[11px] tracking-[0.5px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
          进行中
        </p>
      </div>
      <Container63 />
      <Text40 />
      <Text41 />
      <Text42 />
      <p className="font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[16.5px] not-italic relative shrink-0 text-[#62748e] text-[11px] whitespace-nowrap">同意</p>
      <p className="font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[16.5px] not-italic relative shrink-0 text-[#62748e] text-[11px] whitespace-nowrap">拒绝</p>
    </div>
  );
}

function Container65() {
  return (
    <div className="bg-[#ff6900] h-[19px] relative rounded-[4px] shrink-0 w-[32px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[15px] left-[6px] not-italic text-[10px] text-white top-[1.89px] whitespace-nowrap">紧急</p>
      </div>
    </div>
  );
}

function Container66() {
  return (
    <div className="h-[20px] relative shrink-0 w-[479px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid overflow-clip relative rounded-[inherit] size-full">
        <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#1d293d] text-[14px] top-[-0.11px] whitespace-nowrap">Refresh timing margin 复测</p>
      </div>
    </div>
  );
}

function Text43() {
  return (
    <div className="h-[16.5px] relative shrink-0 w-[52.431px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[16.5px] left-0 not-italic text-[#62748e] text-[11px] top-[-0.11px] tracking-[0.275px] whitespace-nowrap">PTE · 张伟</p>
      </div>
    </div>
  );
}

function Icon22() {
  return (
    <div className="absolute left-[14.32px] size-[11px] top-[2.49px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
        <g clipPath="url(#clip0_2003_1233)" id="Icon">
          <path d={svgPaths.p2b85b880} id="Vector" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
          <path d="M7.33333 0.916667V2.75" id="Vector_2" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
          <path d="M3.66667 0.916667V2.75" id="Vector_3" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
          <path d="M1.375 4.58333H3.66667" id="Vector_4" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
          <path d={svgPaths.p25f3fc00} id="Vector_5" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
          <path d={svgPaths.p6cd8c00} id="Vector_6" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
        </g>
        <defs>
          <clipPath id="clip0_2003_1233">
            <rect fill="white" height="11" width="11" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Text44() {
  return (
    <div className="h-[15.986px] relative shrink-0 w-[96px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Icon22 />
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[16px] left-[29.32px] not-italic text-[#62748e] text-[12px] top-0 whitespace-nowrap">2026-04-24</p>
      </div>
    </div>
  );
}

function Text45() {
  return (
    <div className="bg-[#fffbeb] h-[25.764px] relative rounded-[8px] shrink-0 w-[80px]" data-name="Text">
      <div aria-hidden="true" className="absolute border-[#fee685] border-[0.889px] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[16px] left-[40.65px] not-italic text-[#e17100] text-[12px] text-center top-[4.89px] tracking-[-0.3px] whitespace-nowrap">2 天</p>
      </div>
    </div>
  );
}

function Container64() {
  return (
    <div className="absolute content-stretch flex gap-[16px] h-[49.764px] items-center left-0 px-[20px] py-[12px] top-[101.31px] w-[990.667px]" data-name="Container">
      <Container65 />
      <div className="bg-[#e5a000] h-[19px] relative rounded-[8px] shrink-0" data-name="Tag">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center justify-center p-[8px] relative size-full">
          <p className="font-['Roboto:SemiBold',sans-serif] font-semibold leading-[16px] relative shrink-0 text-[#f5f5f5] text-[11px] tracking-[0.5px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
            待同意
          </p>
        </div>
      </div>
      <Container66 />
      <Text43 />
      <Text44 />
      <Text45 />
      <p className="font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[16.5px] not-italic relative shrink-0 text-[#009efc] text-[11px] whitespace-nowrap">同意</p>
      <p className="font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[16.5px] not-italic relative shrink-0 text-[#009efc] text-[11px] whitespace-nowrap">拒绝</p>
    </div>
  );
}

function Container55() {
  return (
    <div className="absolute h-[151.069px] left-[0.89px] top-[46.56px] w-[990.667px]" data-name="Container">
      <Container56 />
      <Container60 />
      <Container64 />
    </div>
  );
}

function Container54() {
  return (
    <div className="bg-white h-[198.514px] relative rounded-[14px] shrink-0 w-full" data-name="Container">
      <div className="overflow-clip relative rounded-[inherit] size-full">
        <Button15 />
        <Container55 />
      </div>
      <div aria-hidden="true" className="absolute border-[0.889px] border-[rgba(226,232,240,0.8)] border-solid inset-0 pointer-events-none rounded-[14px] shadow-[0px_1px_2px_0px_rgba(15,23,42,0.04)]" />
    </div>
  );
}

function Container36() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] h-[518.236px] items-start relative shrink-0 w-full" data-name="Container">
      <Container37 />
      <Container50 />
      <Container54 />
    </div>
  );
}

function Section() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[16px] h-[579.222px] items-start left-[32px] top-[387.29px] w-[992.444px]" data-name="Section">
      <Container32 />
      <Container36 />
    </div>
  );
}

function Icon23() {
  return (
    <div className="absolute left-[361.67px] size-[11px] top-[18.75px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11 11">
        <g id="Icon">
          <path d={svgPaths.p9580980} id="Vector" stroke="var(--stroke-0, #90A1B9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
          <path d={svgPaths.p96c1ff0} id="Vector_2" stroke="var(--stroke-0, #90A1B9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.916667" />
        </g>
      </svg>
    </div>
  );
}

function Container67() {
  return (
    <div className="absolute h-[32.5px] left-[32px] top-[998.51px] w-[992.444px]" data-name="Container">
      <Icon23 />
      <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[16.5px] left-[380.67px] not-italic text-[#90a1b9] text-[11px] top-[15.89px] whitespace-nowrap">数据刷新于 2026-04-22 11:05 · 每 5 分钟自动同步</p>
    </div>
  );
}

function Container15() {
  return (
    <div className="absolute h-[1063.014px] left-0 top-0 w-[1056.444px]" data-name="Container">
      <Header />
      <Container18 />
      <Container19 />
      <Section />
      <Container67 />
      <div className="absolute h-0 left-[36px] top-[154.51px] w-[996.005px]">
        <div className="absolute inset-[-1px_0_0_0]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 996.005 1">
            <line id="Line 1" stroke="var(--stroke-0, #E2E8F0)" x2="996.005" y1="0.5" y2="0.5" />
          </svg>
        </div>
      </div>
      <div className="absolute left-[562px] overflow-clip size-[16px] top-[123px]" data-name="Copy">
        <div className="absolute inset-[8.33%]" data-name="Icon">
          <div className="absolute inset-[-6%]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.9333 14.9333">
              <path d={svgPaths.p36ba8a00} id="Icon" stroke="var(--stroke-0, #1E1E1E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.6" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function MyTodo() {
  return (
    <div className="h-[1063.014px] relative shrink-0 w-full" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\\'0 0 1056.3 1063\\' xmlns=\\'http://www.w3.org/2000/svg\\' preserveAspectRatio=\\'none\\'><rect x=\\'0\\' y=\\'0\\' height=\\'100%\\' width=\\'100%\\' fill=\\'url(%23grad)\\' opacity=\\'1\\'/><defs><radialGradient id=\\'grad\\' gradientUnits=\\'userSpaceOnUse\\' cx=\\'0\\' cy=\\'0\\' r=\\'10\\' gradientTransform=\\'matrix(0 -42.521 -63.38 0 1056.3 0)\\'><stop stop-color=\\'rgba(122,61,255,0.05)\\' offset=\\'0\\'/><stop stop-color=\\'rgba(0,0,0,0)\\' offset=\\'0.55\\'/></radialGradient></defs></svg>'), url('data:image/svg+xml;utf8,<svg viewBox=\\'0 0 1056.3 1063\\' xmlns=\\'http://www.w3.org/2000/svg\\' preserveAspectRatio=\\'none\\'><rect x=\\'0\\' y=\\'0\\' height=\\'100%\\' width=\\'100%\\' fill=\\'url(%23grad)\\' opacity=\\'1\\'/><defs><radialGradient id=\\'grad\\' gradientUnits=\\'userSpaceOnUse\\' cx=\\'0\\' cy=\\'0\\' r=\\'10\\' gradientTransform=\\'matrix(0 -53.151 -84.507 0 0 0)\\'><stop stop-color=\\'rgba(0,82,217,0.06)\\' offset=\\'0\\'/><stop stop-color=\\'rgba(0,0,0,0)\\' offset=\\'0.6\\'/></radialGradient></defs></svg>')" }} data-name="MyTodo">
      <Container15 />
    </div>
  );
}

function MainContent() {
  return (
    <div className="absolute content-stretch flex flex-col h-[1076px] items-start left-0 overflow-clip pr-[18.667px] top-[56px] w-[1075px]" data-name="Main Content">
      <MyTodo />
    </div>
  );
}

function Container13() {
  return (
    <div className="absolute h-[1132px] left-[236px] top-0 w-[1075px]" data-name="Container">
      <TopBar />
      <MainContent />
    </div>
  );
}

function Icon24() {
  return (
    <div className="relative shrink-0 size-[14px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
        <g id="Icon">
          <path d={svgPaths.p13db7b00} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16667" />
        </g>
      </svg>
    </div>
  );
}

function Container69() {
  return (
    <div className="relative rounded-[10px] shrink-0 size-[36px]" style={{ backgroundImage: "linear-gradient(135deg, rgb(49, 65, 88) 0%, rgb(15, 23, 43) 100%)" }} data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center px-[11px] relative size-full">
        <Icon24 />
      </div>
    </div>
  );
}

function Text46() {
  return <div className="absolute bg-[#fb2c36] left-[32px] rounded-[29826200px] shadow-[0px_0px_0px_0px_white] size-[6px] top-[-2px]" data-name="Text" />;
}

function Button16() {
  return (
    <div className="absolute drop-shadow-[0px_1px_1.5px_rgba(0,0,0,0.1),0px_1px_1px_rgba(0,0,0,0.1)] left-0 rounded-[10px] size-[36px] top-[4px]" style={{ backgroundImage: "linear-gradient(135deg, rgb(0, 82, 217) 0%, rgb(0, 88, 220) 7.1429%, rgb(0, 95, 223) 14.286%, rgb(0, 101, 225) 21.429%, rgb(0, 107, 228) 28.571%, rgb(0, 113, 231) 35.714%, rgb(0, 118, 234) 42.857%, rgb(0, 124, 236) 50%, rgb(0, 130, 239) 57.143%, rgb(0, 136, 242) 64.286%, rgb(0, 141, 244) 71.429%, rgb(0, 147, 247) 78.571%, rgb(0, 153, 250) 85.714%, rgb(0, 158, 252) 92.857%, rgb(0, 164, 255) 100%)" }} data-name="Button">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[16.5px] left-[18.38px] not-italic text-[11px] text-center text-white top-[9.64px] whitespace-nowrap">iT</p>
      <Text46 />
    </div>
  );
}

function Text47() {
  return <div className="absolute bg-[#fb2c36] left-[32px] rounded-[29826200px] shadow-[0px_0px_0px_0px_white] size-[6px] top-[-2px]" data-name="Text" />;
}

function Button17() {
  return (
    <div className="absolute drop-shadow-[0px_1px_1.5px_rgba(0,0,0,0.1),0px_1px_1px_rgba(0,0,0,0.1)] left-0 rounded-[10px] size-[36px] top-[48px]" style={{ backgroundImage: "linear-gradient(135deg, rgb(122, 61, 255) 0%, rgb(125, 67, 255) 7.1429%, rgb(129, 72, 255) 14.286%, rgb(132, 77, 255) 21.429%, rgb(136, 82, 255) 28.571%, rgb(140, 87, 255) 35.714%, rgb(144, 91, 255) 42.857%, rgb(148, 96, 255) 50%, rgb(151, 100, 255) 57.143%, rgb(155, 104, 255) 64.286%, rgb(159, 108, 255) 71.429%, rgb(163, 112, 255) 78.571%, rgb(168, 116, 255) 85.714%, rgb(172, 119, 255) 92.857%, rgb(176, 123, 255) 100%)" }} data-name="Button">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[16.5px] left-[18.1px] not-italic text-[11px] text-center text-white top-[9.64px] whitespace-nowrap">1C</p>
      <Text47 />
    </div>
  );
}

function Button18() {
  return (
    <div className="absolute content-stretch drop-shadow-[0px_1px_1.5px_rgba(0,0,0,0.1),0px_1px_1px_rgba(0,0,0,0.1)] flex items-center justify-center left-0 rounded-[10px] size-[36px] top-[92px]" style={{ backgroundImage: "linear-gradient(135deg, rgb(0, 181, 120) 0%, rgb(10, 184, 123) 11.111%, rgb(18, 187, 125) 22.222%, rgb(25, 191, 128) 33.333%, rgb(30, 194, 130) 44.444%, rgb(35, 197, 133) 55.556%, rgb(39, 200, 135) 66.667%, rgb(43, 203, 138) 77.778%, rgb(47, 207, 140) 88.889%, rgb(51, 210, 143) 100%)" }} data-name="Button">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16.5px] not-italic relative shrink-0 text-[11px] text-center text-white whitespace-nowrap">Sh</p>
    </div>
  );
}

function Container70() {
  return (
    <div className="flex-[652.556_0_0] min-h-px relative w-[36px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid overflow-clip relative rounded-[inherit] size-full">
        <Button16 />
        <Button17 />
        <Button18 />
      </div>
    </div>
  );
}

function Container71() {
  return (
    <div className="h-[27px] relative shrink-0 w-[13.5px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[13.5px] not-italic relative shrink-0 text-[#90a1b9] text-[9px] whitespace-nowrap">工具箱</p>
      </div>
    </div>
  );
}

function Container68() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[12px] h-[771.556px] items-center left-0 py-[16px] top-0 w-[55.111px]" data-name="Container">
      <Container69 />
      <Container70 />
      <Container71 />
    </div>
  );
}

function Icon25() {
  return (
    <div className="relative shrink-0 size-[12px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g id="Icon">
          <path d="M7.5 9L4.5 6L7.5 3" id="Vector" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" />
        </g>
      </svg>
    </div>
  );
}

function Button19() {
  return (
    <div className="absolute bg-white content-stretch drop-shadow-[0px_1px_1.5px_rgba(0,0,0,0.1),0px_1px_1px_rgba(0,0,0,0.1)] flex items-center justify-center left-[-12px] px-[6px] py-[0.889px] rounded-[29826200px] size-[24px] top-[64px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-[0.889px] border-solid inset-0 pointer-events-none rounded-[29826200px]" />
      <Icon25 />
    </div>
  );
}

function ToolRail() {
  return (
    <div className="absolute bg-[rgba(255,255,255,0.7)] border-[#e2e8f0] border-l-[0.889px] border-solid h-[771.556px] left-[1311.11px] top-0 w-[56px]" data-name="ToolRail">
      <Container68 />
      <Button19 />
    </div>
  );
}

function Icon26() {
  return (
    <div className="absolute left-[16px] size-[16px] top-[16px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g clipPath="url(#clip0_2003_1205)" id="Icon">
          <path d={svgPaths.p874e300} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M13.3333 2V4.66667" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M14.6667 3.33333H12" id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M2.66667 11.3333V12.6667" id="Vector_4" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M3.33333 12H2" id="Vector_5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
        <defs>
          <clipPath id="clip0_2003_1205">
            <rect fill="white" height="16" width="16" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Button20() {
  return (
    <div className="absolute drop-shadow-[0px_10px_7.5px_rgba(0,0,0,0.1),0px_4px_3px_rgba(0,0,0,0.1)] h-[48px] left-[1237.33px] rounded-[29826200px] top-[699.56px] w-[105.778px]" style={{ backgroundImage: "linear-gradient(155.592deg, rgb(0, 164, 255) 0%, rgb(0, 158, 252) 7.1429%, rgb(0, 153, 250) 14.286%, rgb(0, 147, 247) 21.429%, rgb(0, 141, 244) 28.571%, rgb(0, 136, 242) 35.714%, rgb(0, 130, 239) 42.857%, rgb(0, 124, 236) 50%, rgb(0, 118, 234) 57.143%, rgb(0, 113, 231) 64.286%, rgb(0, 107, 228) 71.429%, rgb(0, 101, 225) 78.571%, rgb(0, 95, 223) 85.714%, rgb(0, 88, 220) 92.857%, rgb(0, 82, 217) 100%)" }} data-name="Button">
      <Icon26 />
      <p className="-translate-x-1/2 absolute font-['Inter:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium leading-[20px] left-[65px] not-italic text-[14px] text-center text-white top-[13.89px] whitespace-nowrap">EA 助手</p>
    </div>
  );
}

function App() {
  return (
    <div className="h-[1132px] relative shrink-0 w-full" style={{ backgroundImage: "linear-gradient(140.374deg, rgb(248, 250, 252) 0%, rgb(255, 255, 255) 50%, rgb(248, 250, 252) 100%)" }} data-name="App">
      <Sidebar />
      <Container13 />
      <ToolRail />
      <Button20 />
    </div>
  );
}

export default function ea() {
  return (
    <div className="bg-white content-stretch flex flex-col items-start pr-[-0.111px] relative size-full" data-name="科技简洁风EA系统">
      <App />
    </div>
  );
}