import svgPaths from "./svg-m5mayd8qpb";
import imgFrame from "./9ceeaf988dc4b1da34067bbe05061b1875db0092.png";

function Container1() {
  return (
    <div className="relative rounded-[8px] shrink-0 size-[27.986px]" style={{ backgroundImage: "linear-gradient(135deg, rgb(0, 164, 255) 0%, rgb(0, 157, 252) 9.0909%, rgb(0, 150, 248) 18.182%, rgb(0, 142, 245) 27.273%, rgb(0, 135, 242) 36.364%, rgb(0, 128, 238) 45.455%, rgb(0, 121, 235) 54.545%, rgb(0, 113, 231) 63.636%, rgb(0, 106, 228) 72.727%, rgb(0, 98, 224) 81.818%, rgb(0, 90, 221) 90.909%, rgb(0, 82, 217) 100%)" }} data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <p className="font-['Inter:Regular',sans-serif] font-normal leading-[24px] not-italic relative shrink-0 text-[16px] text-white whitespace-nowrap">E</p>
      </div>
    </div>
  );
}

function Container3() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[20px] left-0 not-italic text-[#0f172b] text-[16px] top-[-2.11px] tracking-[0.4px] whitespace-nowrap">EA Platform</p>
    </div>
  );
}

function Container4() {
  return (
    <div className="h-[13.75px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[13.75px] left-0 not-italic text-[#90a1b9] text-[11px] top-[-1.11px] whitespace-nowrap">Engineering Portal</p>
    </div>
  );
}

function Container2() {
  return (
    <div className="h-[33.75px] relative shrink-0 w-[119.41px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Container3 />
        <Container4 />
      </div>
    </div>
  );
}

function Container() {
  return (
    <div className="absolute content-stretch flex gap-[7.986px] h-[55.99px] items-center left-0 pb-[1.111px] pl-[15.99px] pr-[16px] top-0 w-[234.878px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#f1f5f9] border-b-[1.111px] border-solid inset-0 pointer-events-none" />
      <Container1 />
      <Container2 />
    </div>
  );
}

function Container5() {
  return (
    <div className="h-[32.483px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[16.5px] left-[12px] not-italic text-[#90a1b9] text-[11px] top-[6.99px] tracking-[0.55px] uppercase whitespace-nowrap">工作台</p>
    </div>
  );
}

function Icon() {
  return (
    <div className="relative shrink-0 size-[15.99px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15.9896 15.9896">
        <g clipPath="url(#clip0_2003_2800)" id="Icon">
          <path d={svgPaths.p32879c00} id="Vector" stroke="var(--stroke-0, #45556C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33247" />
          <path d={svgPaths.p3cb2ec00} id="Vector_2" stroke="var(--stroke-0, #45556C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33247" />
        </g>
        <defs>
          <clipPath id="clip0_2003_2800">
            <rect fill="white" height="15.9896" width="15.9896" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Text() {
  return (
    <div className="flex-[141.076_0_0] h-[19.983px] min-w-px relative" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="flex-[1_0_0] font-['Inter:Medium','Noto_Sans_JP:Medium','Noto_Sans_SC:Medium',sans-serif] font-medium leading-[20px] min-w-px not-italic relative text-[#45556c] text-[14px]">我的待办</p>
      </div>
    </div>
  );
}

function Text1() {
  return (
    <div className="bg-[#f1f5f9] h-[18.264px] relative rounded-[37282700px] shrink-0 w-[17.847px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[14.286px] left-[9.49px] not-italic text-[#62748e] text-[10px] text-center top-px whitespace-nowrap">6</p>
      </div>
    </div>
  );
}

function Button() {
  return (
    <div className="h-[35.955px] relative rounded-[8px] shrink-0 w-full" data-name="Button">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[10px] items-center px-[11.997px] py-[8px] relative size-full">
          <Icon />
          <Text />
          <Text1 />
        </div>
      </div>
    </div>
  );
}

function Icon1() {
  return (
    <div className="relative shrink-0 size-[15.99px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15.9896 15.9896">
        <g clipPath="url(#clip0_2003_434)" id="Icon">
          <path d={svgPaths.p19726a00} id="Vector" stroke="var(--stroke-0, #45556C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33247" />
          <path d={svgPaths.p17bb1b80} id="Vector_2" stroke="var(--stroke-0, #45556C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33247" />
        </g>
        <defs>
          <clipPath id="clip0_2003_434">
            <rect fill="white" height="15.9896" width="15.9896" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Text2() {
  return (
    <div className="flex-[141.076_0_0] h-[19.983px] min-w-px relative" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="flex-[1_0_0] font-['Inter:Medium','Noto_Sans_JP:Medium','Noto_Sans_SC:Medium',sans-serif] font-medium leading-[20px] min-w-px not-italic relative text-[#45556c] text-[14px]">我的审批</p>
      </div>
    </div>
  );
}

function Text3() {
  return (
    <div className="bg-[#f1f5f9] h-[18.264px] relative rounded-[37282700px] shrink-0 w-[17.847px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[14.286px] left-[9.49px] not-italic text-[#62748e] text-[10px] text-center top-px whitespace-nowrap">3</p>
      </div>
    </div>
  );
}

function Button1() {
  return (
    <div className="h-[35.955px] relative rounded-[8px] shrink-0 w-full" data-name="Button">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[10px] items-center px-[11.997px] py-[8px] relative size-full">
          <Icon1 />
          <Text2 />
          <Text3 />
        </div>
      </div>
    </div>
  );
}

function Icon2() {
  return (
    <div className="relative shrink-0 size-[15.99px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15.9896 15.9896">
        <g clipPath="url(#clip0_2003_458)" id="Icon">
          <path d={svgPaths.p2a5c9340} id="Vector" stroke="var(--stroke-0, #45556C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33247" />
          <path d="M5.32987 6.66233V9.32727" id="Vector_2" stroke="var(--stroke-0, #45556C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33247" />
          <path d="M7.9948 6.66233V7.9948" id="Vector_3" stroke="var(--stroke-0, #45556C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33247" />
          <path d="M10.6597 6.66233V10.6597" id="Vector_4" stroke="var(--stroke-0, #45556C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33247" />
        </g>
        <defs>
          <clipPath id="clip0_2003_458">
            <rect fill="white" height="15.9896" width="15.9896" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Text4() {
  return (
    <div className="flex-[168.924_0_0] h-[19.983px] min-w-px relative" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="flex-[1_0_0] font-['Inter:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium leading-[20px] min-w-px not-italic relative text-[#45556c] text-[14px]">Case 中心</p>
      </div>
    </div>
  );
}

function Button2() {
  return (
    <div className="h-[35.955px] relative rounded-[8px] shrink-0 w-full" data-name="Button">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[10px] items-center px-[11.997px] py-[8px] relative size-full">
          <Icon2 />
          <Text4 />
        </div>
      </div>
    </div>
  );
}

function Icon3() {
  return (
    <div className="relative shrink-0 size-[15.99px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15.9896 15.9896">
        <g clipPath="url(#clip0_2003_428)" id="Icon">
          <path d={svgPaths.p2cdb3600} id="Vector" stroke="var(--stroke-0, #45556C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33247" />
          <path d={svgPaths.p10f69080} id="Vector_2" stroke="var(--stroke-0, #45556C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33247" />
          <path d={svgPaths.p23428380} id="Vector_3" stroke="var(--stroke-0, #45556C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33247" />
          <path d={svgPaths.p14e57340} id="Vector_4" stroke="var(--stroke-0, #45556C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33247" />
        </g>
        <defs>
          <clipPath id="clip0_2003_428">
            <rect fill="white" height="15.9896" width="15.9896" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Text5() {
  return (
    <div className="flex-[168.924_0_0] h-[19.983px] min-w-px relative" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="flex-[1_0_0] font-['Inter:Medium','Noto_Sans_JP:Medium','Noto_Sans_SC:Medium',sans-serif] font-medium leading-[20px] min-w-px not-italic relative text-[#45556c] text-[14px]">管理者视图</p>
      </div>
    </div>
  );
}

function Button3() {
  return (
    <div className="h-[35.955px] relative rounded-[8px] shrink-0 w-full" data-name="Button">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[10px] items-center px-[11.997px] py-[8px] relative size-full">
          <Icon3 />
          <Text5 />
        </div>
      </div>
    </div>
  );
}

function Navigation() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[1.997px] h-[780.816px] items-start left-0 overflow-clip pt-[11.997px] px-[7.986px] top-[56px] w-[234.878px]" data-name="Navigation">
      <Container5 />
      <Button />
      <Button1 />
      <Button2 />
      <Button3 />
    </div>
  );
}

function Container8() {
  return (
    <div className="relative rounded-[37282700px] shrink-0 size-[31.997px]" style={{ backgroundImage: "linear-gradient(135deg, rgb(0, 164, 255) 0%, rgb(0, 158, 252) 7.6923%, rgb(0, 152, 249) 15.385%, rgb(0, 146, 247) 23.077%, rgb(0, 140, 244) 30.769%, rgb(0, 133, 241) 38.462%, rgb(0, 127, 238) 46.154%, rgb(0, 121, 235) 53.846%, rgb(0, 115, 232) 61.538%, rgb(0, 108, 229) 69.231%, rgb(0, 102, 226) 76.923%, rgb(0, 96, 223) 84.615%, rgb(0, 89, 220) 92.308%, rgb(0, 82, 217) 100%)" }} data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[12px] text-white whitespace-nowrap">Z</p>
      </div>
    </div>
  );
}

function Container10() {
  return (
    <div className="content-stretch flex h-[19.983px] items-start overflow-clip relative shrink-0 w-full" data-name="Container">
      <p className="flex-[1_0_0] font-['Inter:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[20px] min-w-px not-italic relative text-[#0f172b] text-[14px]">张伟</p>
    </div>
  );
}

function Container11() {
  return (
    <div className="h-[13.75px] overflow-clip relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[13.75px] left-0 not-italic text-[#62748e] text-[11px] top-[-1.11px] whitespace-nowrap">PTE Engineer · PTE</p>
    </div>
  );
}

function Container9() {
  return (
    <div className="flex-[122.951_0_0] h-[33.733px] min-w-px relative" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Container10 />
        <Container11 />
      </div>
    </div>
  );
}

function Icon4() {
  return (
    <div className="relative shrink-0 size-[11.997px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11.9965 11.9965">
        <g id="Icon">
          <path d={svgPaths.p54f380} id="Vector" stroke="var(--stroke-0, #90A1B9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
          <path d={svgPaths.p1f1db00} id="Vector_2" stroke="var(--stroke-0, #90A1B9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
          <path d="M10.4969 5.99825H4.49869" id="Vector_3" stroke="var(--stroke-0, #90A1B9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
        </g>
      </svg>
    </div>
  );
}

function Button4() {
  return (
    <div className="relative rounded-[4px] shrink-0 size-[23.993px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center pl-[5.99px] pr-[6.007px] relative size-full">
        <Icon4 />
      </div>
    </div>
  );
}

function Container7() {
  return (
    <div className="bg-[#f8fafc] h-[49.705px] relative rounded-[8px] shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[7.986px] items-center px-[7.986px] py-[8px] relative size-full">
          <Container8 />
          <Container9 />
          <Button4 />
        </div>
      </div>
    </div>
  );
}

function Icon5() {
  return (
    <div className="absolute left-[31.74px] size-[11.997px] top-[7.99px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11.9965 11.9965">
        <g clipPath="url(#clip0_2003_408)" id="Icon">
          <path d={svgPaths.p1cbbae00} id="Vector" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
          <path d={svgPaths.p1d46aba0} id="Vector_2" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
          <path d={svgPaths.p1c4ccbca} id="Vector_3" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
          <path d={svgPaths.p2b0c6f00} id="Vector_4" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
          <path d={svgPaths.pb720500} id="Vector_5" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
          <path d={svgPaths.p29d8c900} id="Vector_6" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
        </g>
        <defs>
          <clipPath id="clip0_2003_408">
            <rect fill="white" height="11.9965" width="11.9965" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Button5() {
  return (
    <div className="flex-[103.455_0_0] h-[27.969px] min-w-px relative rounded-[4px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Icon5 />
        <p className="-translate-x-1/2 absolute font-['Inter:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium leading-[16px] left-[59.73px] not-italic text-[#62748e] text-[12px] text-center top-[5.99px] whitespace-nowrap">{` 帮助`}</p>
      </div>
    </div>
  );
}

function Icon6() {
  return (
    <div className="absolute left-[31.74px] size-[11.997px] top-[7.99px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11.9965 11.9965">
        <g clipPath="url(#clip0_2003_464)" id="Icon">
          <path d={svgPaths.p1c259a00} id="Vector" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
          <path d={svgPaths.p12cdfa80} id="Vector_2" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
        </g>
        <defs>
          <clipPath id="clip0_2003_464">
            <rect fill="white" height="11.9965" width="11.9965" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Button6() {
  return (
    <div className="flex-[103.455_0_0] h-[27.969px] min-w-px relative rounded-[4px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Icon6 />
        <p className="-translate-x-1/2 absolute font-['Inter:Medium','Noto_Sans_SC:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium leading-[16px] left-[59.73px] not-italic text-[#62748e] text-[12px] text-center top-[5.99px] whitespace-nowrap">{` 设置`}</p>
      </div>
    </div>
  );
}

function Container12() {
  return (
    <div className="content-stretch flex gap-[3.993px] h-[27.969px] items-start pr-[-0.017px] relative shrink-0 w-full" data-name="Container">
      <Button5 />
      <Button6 />
    </div>
  );
}

function Container6() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[7.986px] h-[110.764px] items-start left-0 pt-[13.108px] px-[11.997px] top-[899.24px] w-[234.878px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#f1f5f9] border-solid border-t-[1.111px] inset-0 pointer-events-none" />
      <Container7 />
      <Container12 />
    </div>
  );
}

function Sidebar() {
  return (
    <div className="absolute bg-white border-[#e2e8f0] border-r-[1.111px] border-solid h-[1010px] left-0 top-0 w-[235.99px]" data-name="Sidebar">
      <Container />
      <Navigation />
      <Container6 />
    </div>
  );
}

function Button7() {
  return (
    <div className="h-[24.01px] relative shrink-0 w-[56.875px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid overflow-clip relative rounded-[inherit] size-full">
        <p className="-translate-x-1/2 absolute font-['Inter:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium leading-[24px] left-[28px] not-italic text-[#62748e] text-[16px] text-center top-[-1.89px] whitespace-nowrap">EA 平台</p>
      </div>
    </div>
  );
}

function Icon7() {
  return (
    <div className="relative shrink-0 size-[13.993px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13.9931 13.9931">
        <g id="Icon">
          <path d={svgPaths.p7ee7d80} id="Vector" stroke="var(--stroke-0, #CAD5E2)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16609" />
        </g>
      </svg>
    </div>
  );
}

function Text7() {
  return (
    <div className="h-[19.983px] relative shrink-0 w-[63.681px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start overflow-clip relative rounded-[inherit] size-full">
        <p className="font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#0f172b] text-[14px] whitespace-nowrap">新建 Case</p>
      </div>
    </div>
  );
}

function Text6() {
  return (
    <div className="h-[19.983px] relative shrink-0 w-[83.663px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[5.99px] items-center relative size-full">
        <Icon7 />
        <Text7 />
      </div>
    </div>
  );
}

function Container14() {
  return (
    <div className="absolute content-stretch flex gap-[5.99px] h-[24.01px] items-center left-[20px] top-[15.43px] w-[146.528px]" data-name="Container">
      <Button7 />
      <Text6 />
    </div>
  );
}

function Icon8() {
  return (
    <div className="absolute left-[7.99px] size-[13.993px] top-[8.99px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13.9931 13.9931">
        <g id="Icon">
          <path d="M2.91523 6.99655H11.0779" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16609" />
          <path d="M6.99655 2.91523V11.0779" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16609" />
        </g>
      </svg>
    </div>
  );
}

function Button8() {
  return (
    <div className="absolute bg-[#0052d9] h-[31.997px] left-[1220.09px] rounded-[8px] top-[11.44px] w-[93.976px]" data-name="Button">
      <Icon8 />
      <p className="-translate-x-1/2 absolute font-['Inter:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium leading-[20px] left-[53.97px] not-italic text-[14px] text-center text-white top-[5.01px] whitespace-nowrap">新建Case</p>
    </div>
  );
}

function Icon9() {
  return (
    <div className="absolute left-[12px] size-[13.993px] top-[7.88px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13.9931 13.9931">
        <g clipPath="url(#clip0_2003_420)" id="Icon">
          <path d={svgPaths.p2c89b600} id="Vector" stroke="var(--stroke-0, #0052D9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16609" />
          <path d={svgPaths.p1c06b200} id="Vector_2" stroke="var(--stroke-0, #0052D9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16609" />
          <path d="M6.99655 9.91178H7.00238" id="Vector_3" stroke="var(--stroke-0, #0052D9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16609" />
        </g>
        <defs>
          <clipPath id="clip0_2003_420">
            <rect fill="white" height="13.9931" width="13.9931" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Button9() {
  return (
    <div className="absolute border-[1.111px] border-[rgba(0,82,217,0.3)] border-solid h-[31.997px] left-[1330.05px] rounded-[8px] top-[11.44px] w-[102.205px]" data-name="Button">
      <Icon9 />
      <p className="-translate-x-1/2 absolute font-['Inter:Medium','Noto_Sans_JP:Medium','Noto_Sans_SC:Medium',sans-serif] font-medium leading-[20px] left-[59.98px] not-italic text-[#0052d9] text-[14px] text-center top-[3.9px] whitespace-nowrap">{` 系统建议`}</p>
    </div>
  );
}

function Icon10() {
  return (
    <div className="absolute left-[8px] size-[15.99px] top-[8px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15.9896 15.9896">
        <g clipPath="url(#clip0_2003_400)" id="Icon">
          <path d={svgPaths.pfcdfd30} id="Vector" stroke="var(--stroke-0, #45556C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33247" />
          <path d={svgPaths.p2178aa00} id="Vector_2" stroke="var(--stroke-0, #45556C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33247" />
        </g>
        <defs>
          <clipPath id="clip0_2003_400">
            <rect fill="white" height="15.9896" width="15.9896" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Text8() {
  return (
    <div className="absolute bg-[#fb2c36] content-stretch flex items-center justify-center left-[18px] px-[4px] rounded-[37282700px] size-[15.99px] top-[-2px]" data-name="Text">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[15px] not-italic relative shrink-0 text-[10px] text-center text-white whitespace-nowrap">3</p>
    </div>
  );
}

function Button10() {
  return (
    <div className="absolute left-[1448.25px] rounded-[8px] size-[31.997px] top-[11.44px]" data-name="Button">
      <Icon10 />
      <Text8 />
    </div>
  );
}

function TopBar() {
  return (
    <div className="absolute bg-white border-[#e2e8f0] border-b-[1.111px] border-solid h-[55.99px] left-0 top-0 w-[1500.243px]" data-name="TopBar">
      <Container14 />
      <Button8 />
      <Button9 />
      <Button10 />
    </div>
  );
}

function Icon11() {
  return (
    <div className="absolute left-0 size-[11.997px] top-[2px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11.9965 11.9965">
        <g clipPath="url(#clip0_2003_390)" id="Icon">
          <path d={svgPaths.p298d0480} id="Vector" stroke="var(--stroke-0, #7A3DFF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
          <path d="M9.99708 1.49956V3.49898" id="Vector_2" stroke="var(--stroke-0, #7A3DFF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
          <path d="M10.9968 2.49927H8.99738" id="Vector_3" stroke="var(--stroke-0, #7A3DFF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
          <path d="M1.99942 8.49752V9.49723" id="Vector_4" stroke="var(--stroke-0, #7A3DFF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
          <path d="M2.49927 8.99738H1.49956" id="Vector_5" stroke="var(--stroke-0, #7A3DFF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
        </g>
        <defs>
          <clipPath id="clip0_2003_390">
            <rect fill="white" height="11.9965" width="11.9965" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Container18() {
  return (
    <div className="h-[15.99px] relative shrink-0 w-full" data-name="Container">
      <Icon11 />
      <p className="absolute font-['Inter:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[16px] left-[19.98px] not-italic text-[#62748e] text-[12px] top-0 tracking-[0.6px] uppercase whitespace-nowrap">New Case · 怀疑目标 → 执行动作</p>
    </div>
  );
}

function Heading() {
  return (
    <div className="h-[35.99px] relative shrink-0 w-full" data-name="Heading 1">
      <p className="absolute font-['Inter:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium leading-[36px] left-0 not-italic text-[#0f172b] text-[24px] top-[-1.78px] tracking-[-0.6px] whitespace-nowrap">新建 Case</p>
    </div>
  );
}

function Paragraph() {
  return (
    <div className="h-[22.726px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[22.75px] left-0 not-italic text-[#62748e] text-[14px] top-[0.22px] whitespace-nowrap">先填写 Case 基础信息，再以怀疑目标 / 执行动作的形式拆解任务。</p>
    </div>
  );
}

function Container17() {
  return (
    <div className="h-[90.677px] relative shrink-0 w-[418.09px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[7.986px] items-start relative size-full">
        <Container18 />
        <Heading />
        <Paragraph />
      </div>
    </div>
  );
}

function Button11() {
  return (
    <div className="h-[35.99px] relative rounded-[8px] shrink-0 w-[62.205px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-[1.111px] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Inter:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium leading-[20px] left-[31.1px] not-italic text-[#314158] text-[14px] text-center top-[7px] whitespace-nowrap">取消</p>
      </div>
    </div>
  );
}

function Button12() {
  return (
    <div className="bg-[#fffbeb] h-[35.99px] opacity-40 relative rounded-[8px] shrink-0 w-[62.205px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#ffd230] border-[1.111px] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center px-[17.111px] py-[1.111px] relative size-full">
        <p className="font-['Inter:Medium','Noto_Sans_SC:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium leading-[20px] not-italic relative shrink-0 text-[#bb4d00] text-[14px] text-center whitespace-nowrap">暂存</p>
      </div>
    </div>
  );
}

function Icon12() {
  return (
    <div className="absolute left-[15.99px] size-[13.993px] top-[10.99px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13.9931 13.9931">
        <g id="Icon">
          <path d={svgPaths.p1da17890} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16609" />
        </g>
      </svg>
    </div>
  );
}

function Button13() {
  return (
    <div className="h-[35.99px] opacity-40 relative rounded-[8px] shrink-0 w-[124.4px]" style={{ backgroundImage: "linear-gradient(90deg, rgb(0, 82, 217) 0%, rgb(0, 80, 212) 10%, rgb(0, 78, 207) 20%, rgb(0, 76, 202) 30%, rgb(0, 74, 197) 40%, rgb(0, 72, 192) 50%, rgb(0, 71, 187) 60%, rgb(0, 69, 182) 70%, rgb(0, 67, 178) 80%, rgb(0, 65, 173) 90%, rgb(0, 63, 168) 100%)" }} data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <Icon12 />
        <p className="-translate-x-1/2 absolute font-['Inter:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium leading-[20px] left-[67.42px] not-italic text-[14px] text-center text-white top-[8.32px] whitespace-nowrap">{`提交 Case `}</p>
      </div>
    </div>
  );
}

function Container19() {
  return (
    <div className="h-[36px] relative shrink-0 w-[264px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[7.986px] items-start relative size-full">
        <Button11 />
        <Button12 />
        <Button13 />
      </div>
    </div>
  );
}

function Container16() {
  return (
    <div className="absolute content-stretch flex h-[90.677px] items-end justify-between left-[32px] top-[32px] w-[1136.007px]" data-name="Container">
      <Container17 />
      <Container19 />
    </div>
  );
}

function Text9() {
  return <div className="absolute bg-[#7a3dff] left-[12px] rounded-[37282700px] size-[5.99px] top-[13.25px]" data-name="Text" />;
}

function Container20() {
  return (
    <div className="absolute bg-[rgba(122,61,255,0.05)] border-[1.111px] border-[rgba(122,61,255,0.2)] border-solid h-[34.705px] left-[32px] rounded-[8px] top-[146.67px] w-[422.066px]" data-name="Container">
      <Text9 />
      <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular','Noto_Sans_KR:Regular',sans-serif] font-normal leading-[16.5px] left-[25.97px] not-italic text-[#62748e] text-[11px] top-[6.99px] whitespace-nowrap">{`提交后将自动路由至对应任务执行者待办信息中，对应人员可在"我的待办"查看。`}</p>
    </div>
  );
}

function Container22() {
  return (
    <div className="absolute bg-[rgba(0,82,217,0.08)] content-stretch flex items-center justify-center left-[20px] rounded-[8px] size-[23.993px] top-[13.49px]" data-name="Container">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16.5px] not-italic relative shrink-0 text-[#0052d9] text-[11px] whitespace-nowrap">1</p>
    </div>
  );
}

function Heading1() {
  return (
    <div className="absolute h-[26.997px] left-[51.98px] top-[12px] w-[117.795px]" data-name="Heading 3">
      <p className="absolute font-['Inter:Medium','Noto_Sans_JP:Medium','Noto_Sans_SC:Medium',sans-serif] font-medium leading-[27px] left-0 not-italic text-[#0f172b] text-[18px] top-[0.22px] whitespace-nowrap">Case 基础信息</p>
    </div>
  );
}

function Text10() {
  return (
    <div className="absolute content-stretch flex h-[16.51px] items-start left-[989.24px] top-[17.24px] w-[124.549px]" data-name="Text">
      <p className="font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[16.5px] not-italic relative shrink-0 text-[#90a1b9] text-[11px] whitespace-nowrap">含产品 / 物料 / 失效 信息</p>
    </div>
  );
}

function Container21() {
  return (
    <div className="absolute border-[#f1f5f9] border-b-[1.111px] border-solid h-[52.101px] left-0 top-0 w-[1133.785px]" data-name="Container">
      <Container22 />
      <Heading1 />
      <Text10 />
    </div>
  );
}

function Container24() {
  return (
    <div className="content-stretch flex h-[15.99px] items-start relative shrink-0 w-full" data-name="Container">
      <p className="flex-[1_0_0] font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[0] min-w-px not-italic relative text-[#45556c] text-[12px] tracking-[0.3px]">
        <span className="leading-[16px]">{`Case 名称 `}</span>
        <span className="leading-[16px] text-[#fb2c36]">*</span>
      </p>
    </div>
  );
}

function TextInput() {
  return (
    <div className="bg-[rgba(248,250,252,0.6)] flex-[1049.809_0_0] h-[40px] min-w-px relative rounded-[8px]" data-name="Text Input">
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-[1.111px] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <div className="flex flex-row items-center size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center px-[12px] relative size-full">
          <p className="font-['Inter:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#1d293d] text-[14px] whitespace-nowrap">输入关键词，系统将联想历史/进行中相似 Case 以避免重复</p>
        </div>
      </div>
    </div>
  );
}

function Icon13() {
  return (
    <div className="relative shrink-0 size-[13.993px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13.9931 13.9931">
        <g clipPath="url(#clip0_2003_2832)" id="Icon">
          <path d={svgPaths.p37362800} id="Vector" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16609" />
          <path d={svgPaths.p7937880} id="Vector_2" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16609" />
          <path d="M6.99655 11.0779V12.827" id="Vector_3" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16609" />
        </g>
        <defs>
          <clipPath id="clip0_2003_2832">
            <rect fill="white" height="13.9931" width="13.9931" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function VoiceInputButton() {
  return (
    <div className="bg-white relative rounded-[8px] shrink-0 size-[35.99px]" data-name="VoiceInputButton">
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-[1.111px] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center pl-[10.99px] pr-[11.007px] py-[1.111px] relative size-full">
        <Icon13 />
      </div>
    </div>
  );
}

function CreateCase1() {
  return (
    <div className="h-[40px] relative shrink-0 w-full" data-name="CreateCase">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[7.986px] items-center relative size-full">
          <TextInput />
          <VoiceInputButton />
        </div>
      </div>
    </div>
  );
}

function Field() {
  return (
    <div className="content-stretch flex flex-col gap-[5.99px] h-[61.979px] items-start relative shrink-0 w-full" data-name="Field">
      <Container24 />
      <CreateCase1 />
    </div>
  );
}

function Container26() {
  return (
    <div className="content-stretch flex h-[15.99px] items-start relative shrink-0 w-full" data-name="Container">
      <p className="flex-[1_0_0] font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[0] min-w-px not-italic relative text-[#45556c] text-[12px] tracking-[0.3px]">
        <span className="leading-[16px]">{`Case Owner（负责人） `}</span>
        <span className="leading-[16px] text-[#fb2c36]">*</span>
      </p>
    </div>
  );
}

function TextInput1() {
  return (
    <div className="absolute bg-[rgba(248,250,252,0.6)] content-stretch flex h-[40px] items-center left-0 pl-[32px] pr-[12px] rounded-[8px] top-0 w-[538.889px]" data-name="Text Input">
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-[1.111px] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <p className="font-['Inter:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#1d293d] text-[14px] whitespace-nowrap">张伟</p>
    </div>
  );
}

function Icon14() {
  return (
    <div className="absolute left-[12px] size-[11.997px] top-[14px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11.9965 11.9965">
        <g id="Icon">
          <path d={svgPaths.p1644c680} id="Vector" stroke="var(--stroke-0, #0052D9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
          <path d={svgPaths.p27ee7440} id="Vector_2" stroke="var(--stroke-0, #0052D9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
        </g>
      </svg>
    </div>
  );
}

function CreateCase2() {
  return (
    <div className="h-[40px] relative shrink-0 w-full" data-name="CreateCase">
      <TextInput1 />
      <Icon14 />
    </div>
  );
}

function Field1() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[5.99px] h-[61.979px] items-start left-0 top-0 w-[538.889px]" data-name="Field">
      <Container26 />
      <CreateCase2 />
    </div>
  );
}

function Container27() {
  return (
    <div className="content-stretch flex h-[15.99px] items-start relative shrink-0 w-full" data-name="Container">
      <p className="flex-[1_0_0] font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[0] min-w-px not-italic relative text-[#45556c] text-[12px] tracking-[0.3px]">
        <span className="leading-[16px]">{`截止日期 `}</span>
        <span className="leading-[16px] text-[#fb2c36]">*</span>
      </p>
    </div>
  );
}

function CreateCase3() {
  return (
    <div className="bg-[rgba(248,250,252,0.6)] h-[40px] relative rounded-[8px] shrink-0 w-full" data-name="CreateCase">
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-[1.111px] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function Field2() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[5.99px] h-[61.979px] items-start left-[554.88px] top-0 w-[538.906px]" data-name="Field">
      <Container27 />
      <CreateCase3 />
    </div>
  );
}

function Container25() {
  return (
    <div className="h-[61.979px] relative shrink-0 w-full" data-name="Container">
      <Field1 />
      <Field2 />
    </div>
  );
}

function Container28() {
  return (
    <div className="content-stretch flex h-[15.99px] items-start relative shrink-0 w-full" data-name="Container">
      <p className="flex-[1_0_0] font-['Inter:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[0] min-w-px not-italic relative text-[#45556c] text-[12px] tracking-[0.3px]">
        <span className="leading-[16px]">{`发起事由 · 现象 `}</span>
        <span className="leading-[16px] text-[#fb2c36]">*</span>
      </p>
    </div>
  );
}

function TextArea() {
  return (
    <div className="absolute bg-[rgba(248,250,252,0.6)] h-[66.181px] left-0 rounded-[8px] top-0 w-[1093.785px]" data-name="Text Area">
      <div className="content-stretch flex items-start overflow-clip pl-[12px] pr-[40px] py-[12px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#1d293d] text-[14px] whitespace-nowrap">观察到什么现象，为什么要开这个 Case ...</p>
      </div>
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-[1.111px] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function Icon15() {
  return (
    <div className="absolute left-[6.88px] size-[11.997px] top-[6.88px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11.9965 11.9965">
        <g clipPath="url(#clip0_2003_2839)" id="Icon">
          <path d={svgPaths.p1a011580} id="Vector" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
          <path d={svgPaths.pb6b0680} id="Vector_2" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
          <path d="M5.99825 9.49723V10.9968" id="Vector_3" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
        </g>
        <defs>
          <clipPath id="clip0_2003_2839">
            <rect fill="white" height="11.9965" width="11.9965" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function VoiceInputButton1() {
  return (
    <div className="absolute bg-white border-[#e2e8f0] border-[1.111px] border-solid left-[1057.81px] rounded-[8px] size-[27.986px] top-[7.99px]" data-name="VoiceInputButton">
      <Icon15 />
    </div>
  );
}

function CreateCase4() {
  return (
    <div className="h-[72.413px] relative shrink-0 w-full" data-name="CreateCase">
      <TextArea />
      <VoiceInputButton1 />
    </div>
  );
}

function Field3() {
  return (
    <div className="content-stretch flex flex-col gap-[5.99px] h-[94.392px] items-start relative shrink-0 w-full" data-name="Field">
      <Container28 />
      <CreateCase4 />
    </div>
  );
}

function Container29() {
  return (
    <div className="content-stretch flex h-[15.99px] items-start relative shrink-0 w-full" data-name="Container">
      <p className="flex-[1_0_0] font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[16px] min-w-px not-italic relative text-[#45556c] text-[12px] tracking-[0.3px]">{`背景（What & Why） `}</p>
    </div>
  );
}

function TextArea1() {
  return (
    <div className="absolute bg-[rgba(248,250,252,0.6)] h-[66.181px] left-0 rounded-[8px] top-0 w-[1093.785px]" data-name="Text Area">
      <div className="content-stretch flex items-start overflow-clip pl-[12px] pr-[40px] py-[12px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#1d293d] text-[14px] whitespace-nowrap">范围 / 影响 / 客户侧情况 / 已尝试措施...</p>
      </div>
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-[1.111px] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function Icon16() {
  return (
    <div className="absolute left-[6.88px] size-[11.997px] top-[6.88px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11.9965 11.9965">
        <g clipPath="url(#clip0_2003_2839)" id="Icon">
          <path d={svgPaths.p1a011580} id="Vector" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
          <path d={svgPaths.pb6b0680} id="Vector_2" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
          <path d="M5.99825 9.49723V10.9968" id="Vector_3" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
        </g>
        <defs>
          <clipPath id="clip0_2003_2839">
            <rect fill="white" height="11.9965" width="11.9965" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function VoiceInputButton2() {
  return (
    <div className="absolute bg-white border-[#e2e8f0] border-[1.111px] border-solid left-[1057.81px] rounded-[8px] size-[27.986px] top-[7.99px]" data-name="VoiceInputButton">
      <Icon16 />
    </div>
  );
}

function CreateCase5() {
  return (
    <div className="h-[72.413px] relative shrink-0 w-full" data-name="CreateCase">
      <TextArea1 />
      <VoiceInputButton2 />
    </div>
  );
}

function Field4() {
  return (
    <div className="content-stretch flex flex-col gap-[5.99px] h-[94.392px] items-start relative shrink-0 w-full" data-name="Field">
      <Container29 />
      <CreateCase5 />
    </div>
  );
}

function Container31() {
  return (
    <div className="content-stretch flex h-[15.99px] items-start relative shrink-0 w-full" data-name="Container">
      <p className="flex-[1_0_0] font-['Inter:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[16px] min-w-px not-italic relative text-[#45556c] text-[12px] tracking-[0.3px]">{`层级 `}</p>
    </div>
  );
}

function Button14() {
  return (
    <div className="flex-[104.583_0_0] h-[35.99px] min-w-px relative rounded-[8px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-[1.111px] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[16px] left-[52.69px] not-italic text-[#45556c] text-[12px] text-center top-[10px] whitespace-nowrap">L1</p>
      </div>
    </div>
  );
}

function Button15() {
  return (
    <div className="flex-[104.583_0_0] h-[35.99px] min-w-px relative rounded-[8px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-[1.111px] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[16px] left-[53.19px] not-italic text-[#45556c] text-[12px] text-center top-[10px] whitespace-nowrap">L2</p>
      </div>
    </div>
  );
}

function Button16() {
  return (
    <div className="flex-[104.583_0_0] h-[35.99px] min-w-px relative rounded-[8px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-[1.111px] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[16px] left-[53.19px] not-italic text-[#45556c] text-[12px] text-center top-[10px] whitespace-nowrap">L3</p>
      </div>
    </div>
  );
}

function Button17() {
  return (
    <div className="flex-[104.583_0_0] h-[35.99px] min-w-px relative rounded-[8px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-[1.111px] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[16px] left-[53.19px] not-italic text-[#45556c] text-[12px] text-center top-[10px] whitespace-nowrap">L4</p>
      </div>
    </div>
  );
}

function Button18() {
  return (
    <div className="bg-[#f8fafc] drop-shadow-[0px_1px_1.5px_rgba(0,0,0,0.1),0px_1px_1px_rgba(0,0,0,0.1)] flex-[104.583_0_0] h-[35.99px] min-w-px relative rounded-[8px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-[1.111px] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[16px] left-[53.19px] not-italic text-[#45556c] text-[12px] text-center top-[10px] whitespace-nowrap">L5</p>
      </div>
    </div>
  );
}

function CreateCase6() {
  return (
    <div className="h-[35.99px] relative shrink-0 w-full" data-name="CreateCase">
      <div className="content-stretch flex gap-[3.993px] items-start relative size-full">
        <Button14 />
        <Button15 />
        <Button16 />
        <Button17 />
        <Button18 />
      </div>
    </div>
  );
}

function Field5() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[5.99px] h-[57.969px] items-start left-0 top-0 w-[538.889px]" data-name="Field">
      <Container31 />
      <CreateCase6 />
    </div>
  );
}

function Container32() {
  return (
    <div className="content-stretch flex h-[15.99px] items-start relative shrink-0 w-full" data-name="Container">
      <p className="flex-[1_0_0] font-['Inter:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[16px] min-w-px not-italic relative text-[#45556c] text-[12px] tracking-[0.3px]">{`紧急程度 `}</p>
    </div>
  );
}

function Button19() {
  return (
    <div className="flex-[131.736_0_0] h-[35.99px] min-w-px relative rounded-[8px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-[1.111px] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Inter:Medium','Noto_Sans_JP:Medium','Noto_Sans_SC:Medium',sans-serif] font-medium leading-[16.5px] left-[65.89px] not-italic text-[#45556c] text-[11px] text-center top-[8.74px] whitespace-nowrap">非常紧急</p>
      </div>
    </div>
  );
}

function Button20() {
  return (
    <div className="flex-[131.736_0_0] h-[35.99px] min-w-px relative rounded-[8px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-[1.111px] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Inter:Medium','Noto_Sans_SC:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium leading-[16.5px] left-[65.88px] not-italic text-[#45556c] text-[11px] text-center top-[8.74px] whitespace-nowrap">紧急</p>
      </div>
    </div>
  );
}

function Button21() {
  return (
    <div className="bg-[#0052d9] drop-shadow-[0px_1px_1.5px_rgba(0,0,0,0.1),0px_1px_1px_rgba(0,0,0,0.1)] flex-[131.736_0_0] h-[35.99px] min-w-px relative rounded-[8px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#0052d9] border-[1.111px] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Inter:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium leading-[16.5px] left-[65.88px] not-italic text-[11px] text-center text-white top-[8.74px] whitespace-nowrap">一般</p>
      </div>
    </div>
  );
}

function Button22() {
  return (
    <div className="flex-[131.736_0_0] h-[35.99px] min-w-px relative rounded-[8px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-[1.111px] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Inter:Medium','Noto_Sans_JP:Medium','Noto_Sans_SC:Medium',sans-serif] font-medium leading-[16.5px] left-[65.88px] not-italic text-[#45556c] text-[11px] text-center top-[8.74px] whitespace-nowrap">不紧急</p>
      </div>
    </div>
  );
}

function CreateCase7() {
  return (
    <div className="content-stretch flex gap-[3.993px] h-[35.99px] items-start pr-[-0.017px] relative shrink-0 w-full" data-name="CreateCase">
      <Button19 />
      <Button20 />
      <Button21 />
      <Button22 />
    </div>
  );
}

function Field6() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[5.99px] h-[57.969px] items-start left-[554.88px] top-0 w-[538.906px]" data-name="Field">
      <Container32 />
      <CreateCase7 />
    </div>
  );
}

function Container30() {
  return (
    <div className="h-[57.969px] relative shrink-0 w-full" data-name="Container">
      <Field5 />
      <Field6 />
    </div>
  );
}

function Container34() {
  return (
    <div className="content-stretch flex h-[15.99px] items-start relative shrink-0 w-full" data-name="Container">
      <p className="flex-[1_0_0] font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[16px] min-w-px not-italic relative text-[#45556c] text-[12px] tracking-[0.3px]">权限</p>
    </div>
  );
}

function Button23() {
  return (
    <div className="h-[36px] relative rounded-[8px] shrink-0 w-[111px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-[1.111px] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Inter:Medium','Noto_Sans_JP:Medium','Noto_Sans_SC:Medium',sans-serif] font-medium leading-[16px] left-[52.69px] not-italic text-[#45556c] text-[12px] text-center top-[10px] whitespace-nowrap">全员可见</p>
      </div>
    </div>
  );
}

function Button24() {
  return (
    <div className="h-[36px] relative rounded-[8px] shrink-0 w-[111px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#0091ff] border-[1.111px] border-solid inset-0 pointer-events-none rounded-[8px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="-translate-x-1/2 absolute font-['Inter:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium leading-[16px] left-[52.69px] not-italic text-[#009efc] text-[12px] text-center top-[10px] whitespace-nowrap">部分人可见</p>
      </div>
    </div>
  );
}

function CreateCase8() {
  return (
    <div className="h-[35.99px] relative shrink-0 w-full" data-name="CreateCase">
      <div className="content-stretch flex gap-[3.993px] items-start relative size-full">
        <Button23 />
        <Button24 />
      </div>
    </div>
  );
}

function Field7() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[5.99px] h-[57.969px] items-start left-0 top-0 w-[538.889px]" data-name="Field">
      <Container34 />
      <CreateCase8 />
    </div>
  );
}

function Container33() {
  return (
    <div className="h-[57.969px] relative shrink-0 w-full" data-name="Container">
      <Field7 />
    </div>
  );
}

function Black() {
  return <div className="absolute bg-[#0066e2] inset-0 opacity-5" data-name="Black" />;
}

function Delete() {
  return (
    <div className="relative shrink-0 size-[12px]" data-name="delete">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g id="delete">
          <path d={svgPaths.pefa7780} fill="var(--fill-0, #1D1B20)" id="icon" />
        </g>
      </svg>
    </div>
  );
}

function StateLayer() {
  return (
    <div className="bg-[#f1f5f9] content-stretch flex gap-[8px] h-[40px] items-center justify-center px-[16px] py-[10px] relative shrink-0" data-name="State-layer">
      <div className="overflow-clip relative shrink-0 size-[20px]" data-name="Icon">
        <div className="absolute inset-[16.67%]" data-name="icon">
          <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13.3333 13.3333">
            <path d={svgPaths.p7662700} fill="var(--fill-0, #49454F)" id="icon" />
          </svg>
        </div>
      </div>
      <div className="flex flex-col font-['Roboto:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[#49454f] text-[14px] tracking-[0.1px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[20px]">人名</p>
      </div>
      <Delete />
    </div>
  );
}

function Content() {
  return (
    <div className="h-full relative rounded-[16px] shrink-0 w-[93px]" data-name="Content">
      <div className="content-stretch flex flex-col items-center justify-center overflow-clip relative rounded-[inherit] size-full">
        <StateLayer />
      </div>
      <div aria-hidden="true" className="absolute border border-[#cac4d0] border-solid inset-0 pointer-events-none rounded-[16px]" />
    </div>
  );
}

function ToggleButtonOutline() {
  return (
    <div className="absolute content-stretch flex h-[20px] items-center justify-center left-[23.67px] top-[37.75px] w-[71px]" data-name="Toggle button - outline">
      <Content />
    </div>
  );
}

function Delete1() {
  return (
    <div className="relative shrink-0 size-[12px]" data-name="delete">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 12">
        <g id="delete">
          <path d={svgPaths.pefa7780} fill="var(--fill-0, #1D1B20)" id="icon" />
        </g>
      </svg>
    </div>
  );
}

function StateLayer1() {
  return (
    <div className="bg-[#f1f5f9] content-stretch flex gap-[8px] h-[40px] items-center justify-center px-[16px] py-[10px] relative shrink-0" data-name="State-layer">
      <div className="overflow-clip relative shrink-0 size-[20px]" data-name="Icon">
        <div className="absolute bottom-1/4 left-0 right-0 top-1/4" data-name="icon">
          <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 10">
            <path d={svgPaths.p83b9700} fill="var(--fill-0, #49454F)" id="icon" />
          </svg>
        </div>
      </div>
      <div className="flex flex-col font-['Roboto:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[#49454f] text-[14px] tracking-[0.1px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[20px]">部门名称</p>
      </div>
      <Delete1 />
    </div>
  );
}

function Content1() {
  return (
    <div className="h-full relative rounded-[16px] shrink-0 w-[123px]" data-name="Content">
      <div className="content-stretch flex flex-col items-center justify-center overflow-clip relative rounded-[inherit] size-full">
        <StateLayer1 />
      </div>
      <div aria-hidden="true" className="absolute border border-[#cac4d0] border-solid inset-0 pointer-events-none rounded-[16px]" />
    </div>
  );
}

function ToggleButtonOutline1() {
  return (
    <div className="absolute content-stretch flex h-[20px] items-center justify-center left-[154.67px] top-[37.75px] w-[71px]" data-name="Toggle button - outline">
      <Content1 />
    </div>
  );
}

function Field8() {
  return (
    <div className="h-[58px] relative shrink-0 w-[539px]" data-name="Field">
      <div className="absolute bg-white h-[30px] left-0 min-w-[120px] rounded-[62px] top-0 w-[361px]" data-name="Search">
        <div className="content-stretch flex gap-[8px] items-center min-w-[inherit] overflow-clip px-[16px] py-[12px] relative rounded-[inherit] size-full">
          <p className="flex-[1_0_0] font-['Inter:Regular',sans-serif] font-normal leading-none min-w-px not-italic relative text-[#b3b3b3] text-[16px]">请输入工号、邮箱、姓名、群组或部门搜索</p>
        </div>
        <div aria-hidden="true" className="absolute border border-[#d9d9d9] border-solid inset-[-0.5px] pointer-events-none rounded-[62.5px]" />
      </div>
      <div className="absolute content-stretch flex flex-col h-[24px] items-center justify-center left-[366.99px] overflow-clip px-[16px] rounded-[6px] top-0" data-name="Push Button">
        <div className="absolute inset-0 overflow-clip" data-name="BG">
          <Black />
        </div>
        <div className="flex flex-col font-['SF_Pro:Medium',sans-serif] font-[510] justify-center leading-[0] relative shrink-0 text-[#0091ff] text-[13px] text-center whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
          <p className="leading-[16px]">添加</p>
        </div>
      </div>
      <ToggleButtonOutline />
      <ToggleButtonOutline1 />
    </div>
  );
}

function Container35() {
  return (
    <div className="content-stretch flex h-[15.99px] items-start relative shrink-0 w-full" data-name="Container">
      <p className="flex-[1_0_0] font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[0] min-w-px not-italic relative text-[#45556c] text-[12px] tracking-[0.3px]">
        <span className="leading-[16px]">{`定级理由 `}</span>
        <span className="leading-[16px] text-[#fb2c36]">*</span>
      </p>
    </div>
  );
}

function TextArea2() {
  return (
    <div className="absolute bg-[rgba(248,250,252,0.6)] h-[66.181px] left-0 rounded-[8px] top-0 w-[1093.785px]" data-name="Text Area">
      <div className="content-stretch flex items-start overflow-clip pl-[12px] pr-[40px] py-[12px] relative rounded-[inherit] size-full">
        <p className="font-['Inter:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#1d293d] text-[14px] whitespace-nowrap">说明为什么定为 L5：影响范围 / 跨部门数 / 客户优先级 等</p>
      </div>
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-[1.111px] border-solid inset-0 pointer-events-none rounded-[8px]" />
    </div>
  );
}

function Icon17() {
  return (
    <div className="absolute left-[6.88px] size-[11.997px] top-[6.88px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11.9965 11.9965">
        <g clipPath="url(#clip0_2003_2839)" id="Icon">
          <path d={svgPaths.p1a011580} id="Vector" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
          <path d={svgPaths.pb6b0680} id="Vector_2" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
          <path d="M5.99825 9.49723V10.9968" id="Vector_3" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
        </g>
        <defs>
          <clipPath id="clip0_2003_2839">
            <rect fill="white" height="11.9965" width="11.9965" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function VoiceInputButton3() {
  return (
    <div className="absolute bg-white border-[#e2e8f0] border-[1.111px] border-solid left-[1057.81px] rounded-[8px] size-[27.986px] top-[7.99px]" data-name="VoiceInputButton">
      <Icon17 />
    </div>
  );
}

function CreateCase9() {
  return (
    <div className="h-[72.413px] relative shrink-0 w-full" data-name="CreateCase">
      <TextArea2 />
      <VoiceInputButton3 />
    </div>
  );
}

function Field9() {
  return (
    <div className="content-stretch flex flex-col gap-[5.99px] h-[94.392px] items-start relative shrink-0 w-full" data-name="Field">
      <Container35 />
      <CreateCase9 />
    </div>
  );
}

function Icon18() {
  return (
    <div className="absolute left-[11.11px] size-[10.99px] top-[11.09px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9896 10.9896">
        <g clipPath="url(#clip0_2003_2821)" id="Icon">
          <path d={svgPaths.p28488000} id="Vector" stroke="var(--stroke-0, #90A1B9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.9158" />
        </g>
        <defs>
          <clipPath id="clip0_2003_2821">
            <rect fill="white" height="10.9896" width="10.9896" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Text11() {
  return (
    <div className="absolute content-stretch flex h-[16.51px] items-start left-[26.09px] top-[9.1px] w-[276.163px]" data-name="Text">
      <p className="font-['Inter:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[16.5px] not-italic relative shrink-0 text-[#62748e] text-[11px] whitespace-nowrap">L5 仅可分派给本部门（PTE）；如需跨部门请上调层级。</p>
    </div>
  );
}

function Container36() {
  return (
    <div className="bg-[#f8fafc] h-[34.705px] relative rounded-[4px] shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#f1f5f9] border-[1.111px] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <Icon18 />
      <Text11 />
    </div>
  );
}

function Container38() {
  return (
    <div className="content-stretch flex h-[15.99px] items-start relative shrink-0 w-full" data-name="Container">
      <p className="flex-[1_0_0] font-['Inter:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[16px] min-w-px not-italic relative text-[#62748e] text-[12px]">产品 / 物料 / 失效信息</p>
    </div>
  );
}

function TextInput2() {
  return (
    <div className="absolute bg-white content-stretch flex h-[35.99px] items-center left-0 px-[10px] rounded-[4px] top-[19.98px] w-[356.597px]" data-name="Text Input">
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-[1.111px] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <p className="font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#62748e] text-[14px] whitespace-nowrap">如：DDR5-X-6400</p>
    </div>
  );
}

function SmallField() {
  return (
    <div className="absolute h-[55.972px] left-0 top-0 w-[356.597px]" data-name="SmallField">
      <p className="absolute font-['Inter:Medium','Noto_Sans_SC:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium leading-[16px] left-0 not-italic text-[#62748e] text-[12px] top-0 whitespace-nowrap">产品编码</p>
      <TextInput2 />
    </div>
  );
}

function TextInput3() {
  return (
    <div className="absolute bg-white content-stretch flex h-[35.99px] items-center left-0 px-[10px] rounded-[4px] top-[19.98px] w-[356.597px]" data-name="Text Input">
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-[1.111px] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <p className="font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#62748e] text-[14px] whitespace-nowrap">如：XDIE-A0</p>
    </div>
  );
}

function SmallField1() {
  return (
    <div className="absolute h-[55.972px] left-[368.59px] top-0 w-[356.597px]" data-name="SmallField">
      <p className="absolute font-['Inter:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium leading-[16px] left-0 not-italic text-[#62748e] text-[12px] top-0 whitespace-nowrap">案件物料</p>
      <TextInput3 />
    </div>
  );
}

function TextInput4() {
  return (
    <div className="absolute bg-white content-stretch flex h-[35.99px] items-center left-0 px-[10px] rounded-[4px] top-[19.98px] w-[356.597px]" data-name="Text Input">
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-[1.111px] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <p className="font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#62748e] text-[14px] whitespace-nowrap">如：16Gb</p>
    </div>
  );
}

function SmallField2() {
  return (
    <div className="absolute h-[55.972px] left-[737.19px] top-0 w-[356.597px]" data-name="SmallField">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[16px] left-0 not-italic text-[#62748e] text-[12px] top-0 whitespace-nowrap">Density</p>
      <TextInput4 />
    </div>
  );
}

function TextInput5() {
  return (
    <div className="absolute bg-white content-stretch flex h-[35.99px] items-center left-0 px-[10px] rounded-[4px] top-[19.98px] w-[356.597px]" data-name="Text Input">
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-[1.111px] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <p className="font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#62748e] text-[14px] whitespace-nowrap">如：x16</p>
    </div>
  );
}

function SmallField3() {
  return (
    <div className="absolute h-[55.972px] left-0 top-[67.97px] w-[356.597px]" data-name="SmallField">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[16px] left-0 not-italic text-[#62748e] text-[12px] top-0 whitespace-nowrap">IO Type</p>
      <TextInput5 />
    </div>
  );
}

function TextInput6() {
  return (
    <div className="absolute bg-white content-stretch flex h-[35.99px] items-center left-0 px-[10px] rounded-[4px] top-[19.98px] w-[356.597px]" data-name="Text Input">
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-[1.111px] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <p className="font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#62748e] text-[14px] whitespace-nowrap">如：CP1 / FT</p>
    </div>
  );
}

function SmallField4() {
  return (
    <div className="absolute h-[55.972px] left-[368.59px] top-[67.97px] w-[356.597px]" data-name="SmallField">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[16px] left-0 not-italic text-[#62748e] text-[12px] top-0 whitespace-nowrap">Fail Stage</p>
      <TextInput6 />
    </div>
  );
}

function TextInput7() {
  return (
    <div className="absolute bg-white content-stretch flex h-[35.99px] items-center left-0 px-[10px] rounded-[4px] top-[19.98px] w-[356.597px]" data-name="Text Input">
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-[1.111px] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <p className="font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#62748e] text-[14px] whitespace-nowrap">客户名称</p>
    </div>
  );
}

function SmallField5() {
  return (
    <div className="absolute h-[55.972px] left-[737.19px] top-[67.97px] w-[356.597px]" data-name="SmallField">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[16px] left-0 not-italic text-[#62748e] text-[12px] top-0 whitespace-nowrap">Customer</p>
      <TextInput7 />
    </div>
  );
}

function TextInput8() {
  return (
    <div className="absolute bg-white content-stretch flex h-[35.99px] items-center left-0 px-[10px] rounded-[4px] top-[19.98px] w-[356.597px]" data-name="Text Input">
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-[1.111px] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <p className="font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#62748e] text-[14px] whitespace-nowrap">平台</p>
    </div>
  );
}

function SmallField6() {
  return (
    <div className="absolute h-[55.972px] left-0 top-[135.94px] w-[356.597px]" data-name="SmallField">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[16px] left-0 not-italic text-[#62748e] text-[12px] top-0 whitespace-nowrap">Fail Platform</p>
      <TextInput8 />
    </div>
  );
}

function TextInput9() {
  return (
    <div className="absolute bg-white content-stretch flex h-[35.99px] items-center left-0 px-[10px] rounded-[4px] top-[19.98px] w-[356.597px]" data-name="Text Input">
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-[1.111px] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <p className="font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#62748e] text-[14px] whitespace-nowrap">失效模式</p>
    </div>
  );
}

function SmallField7() {
  return (
    <div className="absolute h-[55.972px] left-[368.59px] top-[135.94px] w-[356.597px]" data-name="SmallField">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[16px] left-0 not-italic text-[#62748e] text-[12px] top-0 whitespace-nowrap">Fail Mode</p>
      <TextInput9 />
    </div>
  );
}

function TextInput10() {
  return (
    <div className="absolute bg-white content-stretch flex h-[35.99px] items-center left-0 px-[10px] rounded-[4px] top-[19.98px] w-[356.597px]" data-name="Text Input">
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-[1.111px] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <p className="font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#62748e] text-[14px] whitespace-nowrap">如：360</p>
    </div>
  );
}

function SmallField8() {
  return (
    <div className="absolute h-[55.972px] left-[737.19px] top-[135.94px] w-[356.597px]" data-name="SmallField">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[16px] left-0 not-italic text-[#62748e] text-[12px] top-0 whitespace-nowrap">PPM</p>
      <TextInput10 />
    </div>
  );
}

function TextInput11() {
  return (
    <div className="absolute bg-white content-stretch flex h-[35.99px] items-center left-0 px-[10px] rounded-[4px] top-[19.98px] w-[356.597px]" data-name="Text Input">
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-[1.111px] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <p className="font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#62748e] text-[14px] whitespace-nowrap">PD 关联编号</p>
    </div>
  );
}

function SmallField9() {
  return (
    <div className="absolute h-[55.972px] left-0 top-[203.91px] w-[356.597px]" data-name="SmallField">
      <p className="absolute font-['Inter:Medium',sans-serif] font-medium leading-[16px] left-0 not-italic text-[#62748e] text-[12px] top-0 whitespace-nowrap">PD ID</p>
      <TextInput11 />
    </div>
  );
}

function Container39() {
  return (
    <div className="h-[259.878px] relative shrink-0 w-full" data-name="Container">
      <SmallField />
      <SmallField1 />
      <SmallField2 />
      <SmallField3 />
      <SmallField4 />
      <SmallField5 />
      <SmallField6 />
      <SmallField7 />
      <SmallField8 />
      <SmallField9 />
    </div>
  );
}

function Container37() {
  return (
    <div className="content-stretch flex flex-col gap-[7.986px] h-[292.951px] items-start pt-[9.097px] relative shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-dashed border-t-[1.111px] inset-0 pointer-events-none" />
      <Container38 />
      <Container39 />
    </div>
  );
}

function Container23() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[15.99px] h-[1036px] items-start left-[0.22px] pt-[20px] px-[20px] top-[52.52px] w-[1134px]" data-name="Container">
      <Field />
      <Container25 />
      <Field3 />
      <Field4 />
      <Container30 />
      <Container33 />
      <Field8 />
      <Field9 />
      <Container36 />
      <Container37 />
    </div>
  );
}

function Section() {
  return (
    <div className="absolute bg-white border-[1.111px] border-[rgba(226,232,240,0.8)] border-solid h-[1149px] left-[32px] overflow-clip rounded-[14px] shadow-[0px_1px_2px_0px_rgba(15,23,42,0.04)] top-[205px] w-[1136px]" data-name="Section">
      <Container21 />
      <Container23 />
    </div>
  );
}

function Container41() {
  return (
    <div className="absolute bg-[rgba(122,61,255,0.1)] content-stretch flex items-center justify-center left-[20px] rounded-[8px] size-[23.993px] top-[13.49px]" data-name="Container">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16.5px] not-italic relative shrink-0 text-[#7a3dff] text-[11px] whitespace-nowrap">2</p>
    </div>
  );
}

function Heading2() {
  return (
    <div className="absolute h-[26.997px] left-[51.98px] top-[12px] w-[125.938px]" data-name="Heading 3">
      <p className="absolute font-['Inter:Medium','Noto_Sans_JP:Medium','Noto_Sans_SC:Medium',sans-serif] font-medium leading-[27px] left-0 not-italic text-[#0f172b] text-[18px] top-[0.22px] whitespace-nowrap">拆解任务并分派</p>
    </div>
  );
}

function Icon19() {
  return (
    <div className="absolute left-0 size-[10.99px] top-[2.76px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9896 10.9896">
        <g clipPath="url(#clip0_2003_2847)" id="Icon">
          <path d={svgPaths.p1baf48f0} id="Vector" stroke="var(--stroke-0, #90A1B9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.9158" />
          <path d={svgPaths.p247c6a00} id="Vector_2" stroke="var(--stroke-0, #90A1B9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.9158" />
          <path d={svgPaths.p18e19b40} id="Vector_3" stroke="var(--stroke-0, #90A1B9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.9158" />
          <path d={svgPaths.p2d559240} id="Vector_4" stroke="var(--stroke-0, #90A1B9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.9158" />
          <path d="M5.4948 5.4948V3.6632" id="Vector_5" stroke="var(--stroke-0, #90A1B9)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.9158" />
        </g>
        <defs>
          <clipPath id="clip0_2003_2847">
            <rect fill="white" height="10.9896" width="10.9896" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Text12() {
  return (
    <div className="absolute h-[16.51px] left-[185.9px] top-[17.24px] w-[145.139px]" data-name="Text">
      <Icon19 />
      <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[16.5px] left-[14.98px] not-italic text-[#90a1b9] text-[11px] top-[-1px] whitespace-nowrap">{` 与 Case 详情脑图保持一致`}</p>
    </div>
  );
}

function Text13() {
  return (
    <div className="absolute content-stretch flex h-[16.51px] items-start left-[1034.53px] top-[17.24px] w-[79.253px]" data-name="Text">
      <p className="font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[0] not-italic relative shrink-0 text-[#62748e] text-[0px] whitespace-nowrap">
        <span className="leading-[16.5px] text-[11px]">{`共 `}</span>
        <span className="font-['Inter:Bold','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-bold leading-[16.5px] text-[#1d293d] text-[11px]">0</span>
        <span className="leading-[16.5px] text-[11px]">{` 个怀疑目标`}</span>
      </p>
    </div>
  );
}

function Container40() {
  return (
    <div className="absolute border-[#f1f5f9] border-b-[1.111px] border-solid h-[52.101px] left-0 top-0 w-[1133.785px]" data-name="Container">
      <Container41 />
      <Heading2 />
      <Text12 />
      <Text13 />
    </div>
  );
}

function Group() {
  return (
    <div className="absolute contents left-[19.8px] top-[194.93px]">
      <div className="absolute bg-white h-[159px] left-[19.8px] rounded-[10px] top-[194.93px] w-[374px]" data-name="Component 1">
        <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-[-1px] pointer-events-none rounded-[11px]" />
        <div className="absolute bg-white inset-0 rounded-[10px]" />
        <div className="absolute bg-white inset-[12%_86.13%_77%_4.2%] rounded-[10px]">
          <div aria-hidden="true" className="absolute border border-[#e17100] border-solid inset-[-0.5px] pointer-events-none rounded-[10.5px]" />
        </div>
        <div className="absolute bg-[#fe9a00] inset-[12%_70.17%_77%_15.97%] rounded-[10px]">
          <div aria-hidden="true" className="absolute border border-[#e17100] border-solid inset-[-0.5px] pointer-events-none rounded-[10.5px]" />
        </div>
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal inset-[13.5%_89.5%_79%_7.35%] leading-[normal] not-italic text-[10px] text-black whitespace-nowrap">L2</p>
        <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal inset-[13.5%_71.64%_79%_18.28%] leading-[normal] not-italic text-[10px] text-white whitespace-nowrap">非常紧急</p>
        <p className="absolute font-['Inter:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal inset-[37%_28.36%_53.5%_5.04%] leading-[normal] not-italic text-[16px] text-black whitespace-nowrap">这是一个Case的名称，这是一个Case的名称</p>
        <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal inset-[88%_77.1%_4.5%_4.2%] leading-[normal] not-italic text-[#62748e] text-[12px] whitespace-nowrap">Fail Stage：SLT</p>
        <p className="absolute font-['Inter:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal inset-[88%_51.26%_4.5%_34.45%] leading-[normal] not-italic text-[#62748e] text-[12px] whitespace-nowrap">发起人：xxx</p>
        <p className="absolute font-['Inter:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal inset-[88%_8.82%_4.5%_63.03%] leading-[normal] not-italic text-[#62748e] text-[12px] whitespace-nowrap">发起日期：yyyy-mm-dd</p>
      </div>
      <div className="absolute inset-[31%_49.79%_64.22%_45.79%] overflow-clip" data-name="Plus circle">
        <div className="absolute inset-[8.33%]" data-name="Icon">
          <div className="absolute inset-[-6.15%_-6.22%]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 36.1453 36.5">
              <path d={svgPaths.p2cb36d80} id="Icon" stroke="var(--stroke-0, #0091FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="4" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function AnalysisCanvas() {
  return (
    <div className="absolute h-[815.99px] left-[29.89px] right-[188.89px] top-[58.89px]" data-name="AnalysisCanvas">
      <Group />
      <div className="absolute bg-white h-[92px] left-[485.8px] rounded-[10px] top-[53.93px] w-[374px]" data-name="Component 1">
        <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-[-1px] pointer-events-none rounded-[11px]" />
        <div className="absolute bg-white inset-0 rounded-[10px]" />
        <p className="absolute font-['Inter:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal inset-[37%_28.36%_53.5%_5.04%] leading-[normal] not-italic text-[16px] text-black whitespace-nowrap">​</p>
      </div>
      <div className="absolute bg-white h-[215px] left-[509px] rounded-[10px] top-[173px] w-[374px]" data-name="Component 2">
        <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-[-1px] pointer-events-none rounded-[11px]" />
        <div className="absolute bg-white inset-0 rounded-[10px]" />
        <p className="absolute font-['Inter:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal inset-[37%_28.36%_53.5%_5.04%] leading-[normal] not-italic text-[16px] text-black whitespace-nowrap">​</p>
      </div>
      <div className="absolute bg-white h-[215px] left-[509.2px] rounded-[10px] top-[410.07px] w-[374px]" data-name="Component 3">
        <div aria-hidden="true" className="absolute border border-[#e2e8f0] border-solid inset-[-1px] pointer-events-none rounded-[11px]" />
        <div className="absolute bg-white inset-0 rounded-[10px]" />
        <p className="absolute font-['Inter:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal inset-[37%_28.36%_53.5%_5.04%] leading-[normal] not-italic text-[16px] text-black whitespace-nowrap">​</p>
      </div>
      <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal inset-[27.13%_28.91%_71.4%_66.51%] leading-[normal] not-italic text-[10px] text-white whitespace-nowrap">非常紧急</p>
      <div className="absolute bg-[#fe9a00] inset-[26.84%_28.54%_71.02%_65.52%] rounded-[10px]">
        <div aria-hidden="true" className="absolute border border-[#e17100] border-solid inset-[-0.5px] pointer-events-none rounded-[10.5px]" />
      </div>
      <div className="absolute bg-[#fe9a00] inset-[55.89%_28.52%_41.96%_65.54%] rounded-[10px]">
        <div aria-hidden="true" className="absolute border border-[#e17100] border-solid inset-[-0.5px] pointer-events-none rounded-[10.5px]" />
      </div>
      <div className="absolute bg-white inset-[26.84%_35.38%_71.02%_60.48%] rounded-[10px]">
        <div aria-hidden="true" className="absolute border border-[#e17100] border-solid inset-[-0.5px] pointer-events-none rounded-[10.5px]" />
      </div>
      <div className="absolute bg-white inset-[55.89%_35.36%_41.96%_60.5%] rounded-[10px]">
        <div aria-hidden="true" className="absolute border border-[#e17100] border-solid inset-[-0.5px] pointer-events-none rounded-[10.5px]" />
      </div>
      <div className="absolute bg-[rgba(0,164,255,0.85)] h-[34px] left-[485.8px] rounded-tl-[10px] rounded-tr-[10px] top-[53.93px] w-[374px]" />
      <div className="absolute bg-[#7241fb] h-[34px] left-[508.8px] rounded-tl-[10px] rounded-tr-[10px] top-[172.93px] w-[374px]" />
      <div className="absolute bg-[#7241fb] h-[34px] left-[509px] rounded-tl-[10px] rounded-tr-[10px] top-[410px] w-[374px]" />
      <div className="absolute left-[835px] overflow-clip size-[16px] top-[419px]" data-name="Edit">
        <div className="absolute inset-[7.83%_7.83%_8.33%_8.33%]" data-name="Icon">
          <div className="absolute inset-[-5.96%]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15.0142 15.0142">
              <path d={svgPaths.p3b948100} id="Icon" stroke="var(--stroke-0, #F5F5F5)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.6" />
            </svg>
          </div>
        </div>
      </div>
      <div className="absolute left-[859px] overflow-clip size-[18px] top-[418px]" data-name="delete">
        <div className="absolute inset-[12.5%_16.67%]" data-name="icon">
          <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 13.5">
            <path d={svgPaths.p20105700} fill="var(--fill-0, #FEF7FF)" id="icon" />
          </svg>
        </div>
      </div>
      <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal inset-[7.47%_28.98%_90.2%_59.16%] leading-[normal] not-italic text-[16px] text-white">思路/怀疑方向</p>
      <p className="absolute font-['Inter:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal inset-[22.05%_30.72%_75.62%_61.84%] leading-[normal] not-italic text-[16px] text-white">执行动作</p>
      <p className="absolute font-['Inter:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal inset-[51.1%_30.7%_46.57%_61.86%] leading-[normal] not-italic text-[16px] text-white">执行动作</p>
      <p className="absolute font-['Inter:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal inset-[13.1%_15.95%_84.57%_59.16%] leading-[normal] not-italic text-[16px] text-black">这是思路/怀疑方向的文本内容</p>
      <p className="absolute font-['Inter:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal inset-[30.88%_13.95%_66.79%_61.17%] leading-[normal] not-italic text-[16px] text-black">这是执行动作的名称</p>
      <p className="absolute font-['Inter:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal inset-[59.94%_13.92%_37.74%_61.19%] leading-[normal] not-italic text-[16px] text-black">这是执行动作的名称</p>
      <p className="absolute font-['Inter:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal inset-[40.44%_24.28%_57.72%_60.94%] leading-[normal] not-italic text-[12px] text-black">这是执行动作里的字段</p>
      <p className="absolute font-['Inter:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal inset-[69.24%_24.74%_28.92%_60.48%] leading-[normal] not-italic text-[12px] text-black">这是执行动作里的字段</p>
      <p className="absolute font-['Inter:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal inset-[40.44%_7.9%_57.72%_76.98%] leading-[normal] not-italic text-[12px] text-black">这是执行动作里的字段</p>
      <p className="absolute font-['Inter:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal inset-[69.24%_8.36%_28.92%_76.52%] leading-[normal] not-italic text-[12px] text-black">这是执行动作里的字段</p>
      <p className="absolute font-['Inter:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal inset-[36.77%_23.94%_61.4%_60.94%] leading-[normal] not-italic text-[12px] text-black">这是执行动作里的字段</p>
      <p className="absolute font-['Inter:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal inset-[65.56%_24.4%_32.6%_60.48%] leading-[normal] not-italic text-[12px] text-black">这是执行动作里的字段</p>
      <p className="absolute font-['Inter:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal inset-[36.77%_7.9%_61.4%_76.98%] leading-[normal] not-italic text-[12px] text-black">这是执行动作里的字段</p>
      <p className="absolute font-['Inter:Regular','Noto_Sans_SC:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal inset-[65.56%_8.36%_32.6%_76.52%] leading-[normal] not-italic text-[12px] text-black">这是执行动作里的字段</p>
      <div className="absolute left-[811px] overflow-clip size-[16px] top-[62px]" data-name="Edit">
        <div className="absolute inset-[7.83%_7.83%_8.33%_8.33%]" data-name="Icon">
          <div className="absolute inset-[-5.96%]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15.0142 15.0142">
              <path d={svgPaths.p3b948100} id="Icon" stroke="var(--stroke-0, #F5F5F5)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.6" />
            </svg>
          </div>
        </div>
      </div>
      <div className="absolute left-[834px] overflow-clip size-[16px] top-[183px]" data-name="Edit">
        <div className="absolute inset-[7.83%_7.83%_8.33%_8.33%]" data-name="Icon">
          <div className="absolute inset-[-5.96%]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15.0142 15.0142">
              <path d={svgPaths.p3b948100} id="Icon" stroke="var(--stroke-0, #F5F5F5)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.6" />
            </svg>
          </div>
        </div>
      </div>
      <div className="absolute h-[165.527px] left-[395.5px] top-[108.5px] w-[90.5px]">
        <div className="absolute inset-[0_-0.53%_-0.3%_0]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 91.0101 166.176">
            <path d={svgPaths.p251ca740} id="Vector 2" stroke="var(--stroke-0, #CAD5E2)" />
          </svg>
        </div>
      </div>
      <div className="absolute h-[133.5px] left-[497.5px] top-[149.5px] w-[11px]">
        <div className="absolute inset-[0_0_-0.37%_-4.55%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11.5 134">
            <path d="M0.5 0V133.5H11.5" id="Vector 3" stroke="var(--stroke-0, #CAD5E2)" />
          </svg>
        </div>
      </div>
      <div className="absolute content-stretch flex flex-col gap-[8px] items-center left-[528px] p-[8px] top-[580px]" data-name="Navigation Button">
        <div className="overflow-clip relative shrink-0 size-[24px]" data-name="Thumbs up">
          <div className="absolute inset-[8.33%_9.66%_8.33%_8.33%]" data-name="Icon">
            <div className="absolute inset-[-6.25%_-6.35%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22.1826 22.5001">
                <path d={svgPaths.p24249500} id="Icon" stroke="var(--stroke-0, #757575)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" />
              </svg>
            </div>
          </div>
        </div>
        <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-none not-italic relative shrink-0 text-[#757575] text-[14px] text-center whitespace-nowrap">​</p>
      </div>
      <div className="absolute content-stretch flex flex-col gap-[8px] items-center left-[528px] p-[8px] top-[350px]" data-name="Navigation Button">
        <div className="overflow-clip relative shrink-0 size-[24px]" data-name="Thumbs up">
          <div className="absolute inset-[8.33%_9.66%_8.33%_8.33%]" data-name="Icon">
            <div className="absolute inset-[-6.25%_-6.35%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22.1826 22.5001">
                <path d={svgPaths.p24249500} id="Icon" stroke="var(--stroke-0, #757575)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" />
              </svg>
            </div>
          </div>
        </div>
        <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-none not-italic relative shrink-0 text-[#757575] text-[14px] text-center whitespace-nowrap">​</p>
      </div>
      <div className="absolute content-stretch flex flex-col gap-[8px] items-center left-[605px] p-[8px] top-[581px]" data-name="Navigation Button">
        <div className="overflow-clip relative shrink-0 size-[24px]" data-name="Message circle">
          <div className="absolute inset-[12.5%]" data-name="Icon">
            <div className="absolute inset-[-6.94%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.5001 20.5001">
                <path d={svgPaths.p2e6e5ff0} id="Icon" stroke="var(--stroke-0, #757575)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" />
              </svg>
            </div>
          </div>
        </div>
        <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-none not-italic relative shrink-0 text-[#757575] text-[14px] text-center whitespace-nowrap">​</p>
      </div>
      <div className="absolute content-stretch flex flex-col gap-[8px] items-center left-[605px] p-[8px] top-[351px]" data-name="Navigation Button">
        <div className="overflow-clip relative shrink-0 size-[24px]" data-name="Message circle">
          <div className="absolute inset-[12.5%]" data-name="Icon">
            <div className="absolute inset-[-6.94%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20.5001 20.5001">
                <path d={svgPaths.p2e6e5ff0} id="Icon" stroke="var(--stroke-0, #757575)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" />
              </svg>
            </div>
          </div>
        </div>
        <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold leading-none not-italic relative shrink-0 text-[#757575] text-[14px] text-center whitespace-nowrap">​</p>
      </div>
      <div className="absolute h-[251px] left-[497.5px] top-[283.5px] w-[11px]">
        <div className="absolute inset-[0_0_-0.2%_-4.55%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11.5 251.5">
            <path d="M0.5 0V251H11.5" id="Vector 4" stroke="var(--stroke-0, #CAD5E2)" />
          </svg>
        </div>
      </div>
      <div className="absolute left-[835px] overflow-clip size-[18px] top-[61px]" data-name="delete">
        <div className="absolute inset-[12.5%_16.67%]" data-name="icon">
          <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 13.5">
            <path d={svgPaths.p20105700} fill="var(--fill-0, #FEF7FF)" id="icon" />
          </svg>
        </div>
      </div>
      <div className="absolute left-[858px] overflow-clip size-[18px] top-[182px]" data-name="delete">
        <div className="absolute inset-[12.5%_16.67%]" data-name="icon">
          <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 13.5">
            <path d={svgPaths.p20105700} fill="var(--fill-0, #FEF7FF)" id="icon" />
          </svg>
        </div>
      </div>
      <div className="absolute bg-white h-[29px] left-[513px] top-[638px] w-[355px]">
        <div aria-hidden="true" className="absolute border border-[#cad5e2] border-dashed inset-[-0.5px] pointer-events-none" />
      </div>
      <p className="absolute font-['Inter:Regular','Noto_Sans_JP:Regular','Noto_Sans_SC:Regular',sans-serif] font-normal leading-[normal] left-[679px] not-italic text-[#94a3b8] text-[12px] top-[645px] whitespace-nowrap">添加执行动作</p>
      <div className="absolute left-[643px] overflow-clip size-[24px] top-[641px]" data-name="Icon / PlusOutlined">
        <div className="absolute inset-[14.84%_16.41%]" data-name="Vector">
          <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16.125 16.875">
            <g id="Vector">
              <path d={svgPaths.p23faec80} fill="black" fillOpacity="0.45" />
              <path d={svgPaths.p3a946300} fill="black" fillOpacity="0.45" />
            </g>
          </svg>
        </div>
      </div>
    </div>
  );
}

function Container43() {
  return (
    <div className="absolute bg-[rgba(248,250,252,0.4)] border-[#e2e8f0] border-[1.111px] border-dashed h-[823px] left-[20px] right-[20px] rounded-[10px] top-[56px]" data-name="Container">
      <AnalysisCanvas />
      <div className="absolute h-[39px] left-[924.89px] overflow-clip top-[334.89px] w-[38px]" data-name="Plus circle">
        <div className="absolute inset-[8.33%]" data-name="Icon">
          <div className="absolute inset-[-6.15%_-6.32%]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 35.6667 36.5">
              <path d={svgPaths.p11ee9000} id="Icon" stroke="var(--stroke-0, #0091FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="4" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame() {
  return (
    <div className="absolute h-[31px] left-[120px] overflow-clip top-[8px] w-[246px]" data-name="Frame">
      <img alt="" className="absolute block inset-0 max-w-none size-full" height="31" src={imgFrame} width="246" />
    </div>
  );
}

function Container42() {
  return (
    <div className="absolute h-[935px] left-[-0.11px] top-[51.89px] w-[1134px]" data-name="Container">
      <Container43 />
      <div className="-translate-y-1/2 absolute flex flex-col font-['Roboto:Medium','Noto_Sans_JP:Medium','Noto_Sans_SC:Medium',sans-serif] font-medium justify-center leading-[0] left-[24px] text-[#62748e] text-[14px] top-[24px] tracking-[0.1px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[20px]">Case参与人员</p>
      </div>
      <Frame />
    </div>
  );
}

function Section1() {
  return (
    <div className="absolute bg-white border-[1.111px] border-[rgba(226,232,240,0.8)] border-solid h-[966px] left-[32px] overflow-clip rounded-[14px] shadow-[0px_1px_2px_0px_rgba(15,23,42,0.04)] top-[1377px] w-[1136px]" data-name="Section">
      <Container40 />
      <Container42 />
    </div>
  );
}

function Container15() {
  return (
    <div className="absolute h-[2387px] left-[141px] top-0 w-[1200px]" data-name="Container">
      <Container16 />
      <Container20 />
      <Section />
      <Section1 />
    </div>
  );
}

function CreateCase() {
  return (
    <div className="h-[2387px] relative shrink-0 w-full" style={{ backgroundImage: "url('data:image/svg+xml;utf8,<svg viewBox=\\'0 0 1481.1 2387\\' xmlns=\\'http://www.w3.org/2000/svg\\' preserveAspectRatio=\\'none\\'><rect x=\\'0\\' y=\\'0\\' height=\\'100%\\' width=\\'100%\\' fill=\\'url(%23grad)\\' opacity=\\'1\\'/><defs><radialGradient id=\\'grad\\' gradientUnits=\\'userSpaceOnUse\\' cx=\\'0\\' cy=\\'0\\' r=\\'10\\' gradientTransform=\\'matrix(0 -119.35 -118.49 0 0 0)\\'><stop stop-color=\\'rgba(0,82,217,0.05)\\' offset=\\'0\\'/><stop stop-color=\\'rgba(0,0,0,0)\\' offset=\\'0.6\\'/></radialGradient></defs></svg>')" }} data-name="CreateCase">
      <Container15 />
    </div>
  );
}

function MainContent() {
  return (
    <div className="absolute content-stretch flex flex-col h-[2387px] items-start left-0 overflow-clip pr-[18.889px] top-[56px] w-[1500px]" data-name="Main Content">
      <CreateCase />
    </div>
  );
}

function Container13() {
  return (
    <div className="absolute h-[2423px] left-[236px] top-0 w-[1500px]" data-name="Container">
      <TopBar />
      <MainContent />
    </div>
  );
}

function Icon20() {
  return (
    <div className="relative shrink-0 size-[13.993px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13.9931 13.9931">
        <g clipPath="url(#clip0_2003_425)" id="Icon">
          <path d={svgPaths.p2aa68940} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.16609" />
        </g>
        <defs>
          <clipPath id="clip0_2003_425">
            <rect fill="white" height="13.9931" width="13.9931" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Container45() {
  return (
    <div className="relative rounded-[10px] shrink-0 size-[35.99px]" style={{ backgroundImage: "linear-gradient(135deg, rgb(49, 65, 88) 0%, rgb(15, 23, 43) 100%)" }} data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center pl-[10.99px] pr-[11.007px] relative size-full">
        <Icon20 />
      </div>
    </div>
  );
}

function Text14() {
  return <div className="absolute bg-[#fb2c36] left-[32px] rounded-[37282700px] shadow-[0px_0px_0px_0px_white] size-[5.99px] top-[-2px]" data-name="Text" />;
}

function Button25() {
  return (
    <div className="absolute drop-shadow-[0px_1px_1.5px_rgba(0,0,0,0.1),0px_1px_1px_rgba(0,0,0,0.1)] left-0 rounded-[10px] size-[35.99px] top-[3.99px]" style={{ backgroundImage: "linear-gradient(135deg, rgb(0, 82, 217) 0%, rgb(0, 88, 220) 7.1429%, rgb(0, 95, 223) 14.286%, rgb(0, 101, 225) 21.429%, rgb(0, 107, 228) 28.571%, rgb(0, 113, 231) 35.714%, rgb(0, 118, 234) 42.857%, rgb(0, 124, 236) 50%, rgb(0, 130, 239) 57.143%, rgb(0, 136, 242) 64.286%, rgb(0, 141, 244) 71.429%, rgb(0, 147, 247) 78.571%, rgb(0, 153, 250) 85.714%, rgb(0, 158, 252) 92.857%, rgb(0, 164, 255) 100%)" }} data-name="Button">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[16.5px] left-[18.37px] not-italic text-[11px] text-center text-white top-[8.74px] whitespace-nowrap">iT</p>
      <Text14 />
    </div>
  );
}

function Text15() {
  return <div className="absolute bg-[#fb2c36] left-[32px] rounded-[37282700px] shadow-[0px_0px_0px_0px_white] size-[5.99px] top-[-2px]" data-name="Text" />;
}

function Button26() {
  return (
    <div className="absolute drop-shadow-[0px_1px_1.5px_rgba(0,0,0,0.1),0px_1px_1px_rgba(0,0,0,0.1)] left-0 rounded-[10px] size-[35.99px] top-[47.97px]" style={{ backgroundImage: "linear-gradient(135deg, rgb(122, 61, 255) 0%, rgb(125, 67, 255) 7.1429%, rgb(129, 72, 255) 14.286%, rgb(132, 77, 255) 21.429%, rgb(136, 82, 255) 28.571%, rgb(140, 87, 255) 35.714%, rgb(144, 91, 255) 42.857%, rgb(148, 96, 255) 50%, rgb(151, 100, 255) 57.143%, rgb(155, 104, 255) 64.286%, rgb(159, 108, 255) 71.429%, rgb(163, 112, 255) 78.571%, rgb(168, 116, 255) 85.714%, rgb(172, 119, 255) 92.857%, rgb(176, 123, 255) 100%)" }} data-name="Button">
      <p className="-translate-x-1/2 absolute font-['Inter:Medium',sans-serif] font-medium leading-[16.5px] left-[18.09px] not-italic text-[11px] text-center text-white top-[8.74px] whitespace-nowrap">1C</p>
      <Text15 />
    </div>
  );
}

function Button27() {
  return (
    <div className="absolute content-stretch drop-shadow-[0px_1px_1.5px_rgba(0,0,0,0.1),0px_1px_1px_rgba(0,0,0,0.1)] flex items-center justify-center left-0 rounded-[10px] size-[35.99px] top-[91.94px]" style={{ backgroundImage: "linear-gradient(135deg, rgb(0, 181, 120) 0%, rgb(10, 184, 123) 11.111%, rgb(18, 187, 125) 22.222%, rgb(25, 191, 128) 33.333%, rgb(30, 194, 130) 44.444%, rgb(35, 197, 133) 55.556%, rgb(39, 200, 135) 66.667%, rgb(43, 203, 138) 77.778%, rgb(47, 207, 140) 88.889%, rgb(51, 210, 143) 100%)" }} data-name="Button">
      <p className="font-['Inter:Medium',sans-serif] font-medium leading-[16.5px] not-italic relative shrink-0 text-[11px] text-center text-white whitespace-nowrap">Sh</p>
    </div>
  );
}

function Container46() {
  return (
    <div className="flex-[891.059_0_0] min-h-px relative w-[35.99px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid overflow-clip relative rounded-[inherit] size-full">
        <Button25 />
        <Button26 />
        <Button27 />
      </div>
    </div>
  );
}

function Container47() {
  return (
    <div className="h-[26.979px] relative shrink-0 w-[13.49px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">
        <p className="font-['Inter:Regular','Noto_Sans_JP:Regular',sans-serif] font-normal leading-[13.5px] not-italic relative shrink-0 text-[#90a1b9] text-[9px] whitespace-nowrap">工具箱</p>
      </div>
    </div>
  );
}

function Container44() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[11.997px] h-[1010px] items-center left-0 py-[15.99px] top-0 w-[54.878px]" data-name="Container">
      <Container45 />
      <Container46 />
      <Container47 />
    </div>
  );
}

function Icon21() {
  return (
    <div className="relative shrink-0 size-[11.997px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11.9965 11.9965">
        <g id="Icon">
          <path d={svgPaths.pa593100} id="Vector" stroke="var(--stroke-0, #62748E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="0.999708" />
        </g>
      </svg>
    </div>
  );
}

function Button28() {
  return (
    <div className="absolute bg-white content-stretch drop-shadow-[0px_1px_1.5px_rgba(0,0,0,0.1),0px_1px_1px_rgba(0,0,0,0.1)] flex items-center justify-center left-[-12px] pl-[5.99px] pr-[6.007px] py-[1.111px] rounded-[37282700px] size-[23.993px] top-[63.99px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#e2e8f0] border-[1.111px] border-solid inset-0 pointer-events-none rounded-[37282700px]" />
      <Icon21 />
    </div>
  );
}

function ToolRail() {
  return (
    <div className="absolute bg-[rgba(255,255,255,0.7)] border-[#e2e8f0] border-l-[1.111px] border-solid h-[1010px] left-[1736.23px] top-0 w-[55.99px]" data-name="ToolRail">
      <Container44 />
      <Button28 />
    </div>
  );
}

function Icon22() {
  return (
    <div className="absolute left-[15.99px] size-[15.99px] top-[15.99px]" data-name="Icon">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15.9896 15.9896">
        <g clipPath="url(#clip0_2003_356)" id="Icon">
          <path d={svgPaths.p9570a00} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33247" />
          <path d="M13.3247 1.9987V4.66363" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33247" />
          <path d="M14.6571 3.33117H11.9922" id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33247" />
          <path d="M2.66493 11.326V12.6584" id="Vector_4" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33247" />
          <path d="M3.33117 11.9922H1.9987" id="Vector_5" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33247" />
        </g>
        <defs>
          <clipPath id="clip0_2003_356">
            <rect fill="white" height="15.9896" width="15.9896" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Button29() {
  return (
    <div className="absolute drop-shadow-[0px_10px_7.5px_rgba(0,0,0,0.1),0px_4px_3px_rgba(0,0,0,0.1)] h-[47.986px] left-[1662.5px] rounded-[37282700px] top-[938.02px] w-[105.729px]" style={{ backgroundImage: "linear-gradient(155.589deg, rgb(0, 164, 255) 0%, rgb(0, 158, 252) 7.1429%, rgb(0, 153, 250) 14.286%, rgb(0, 147, 247) 21.429%, rgb(0, 141, 244) 28.571%, rgb(0, 136, 242) 35.714%, rgb(0, 130, 239) 42.857%, rgb(0, 124, 236) 50%, rgb(0, 118, 234) 57.143%, rgb(0, 113, 231) 64.286%, rgb(0, 107, 228) 71.429%, rgb(0, 101, 225) 78.571%, rgb(0, 95, 223) 85.714%, rgb(0, 88, 220) 92.857%, rgb(0, 82, 217) 100%)" }} data-name="Button">
      <Icon22 />
      <p className="-translate-x-1/2 absolute font-['Inter:Medium','Noto_Sans_JP:Medium',sans-serif] font-medium leading-[20px] left-[64.97px] not-italic text-[14px] text-center text-white top-[12.99px] whitespace-nowrap">EA 助手</p>
    </div>
  );
}

function App() {
  return (
    <div className="h-[2439px] relative shrink-0 w-full" style={{ backgroundImage: "linear-gradient(126.309deg, rgb(248, 250, 252) 0%, rgb(255, 255, 255) 50%, rgb(248, 250, 252) 100%)" }} data-name="App">
      <Sidebar />
      <Container13 />
      <ToolRail />
      <Button29 />
    </div>
  );
}

export default function ea() {
  return (
    <div className="bg-white content-stretch flex flex-col items-start pr-[-0.222px] relative size-full" data-name="科技简洁风EA系统">
      <App />
    </div>
  );
}