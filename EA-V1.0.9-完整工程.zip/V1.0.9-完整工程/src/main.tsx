
  import { createRoot } from "react-dom/client";
  import App from "./app/App.tsx";
  import { CreateCaseLab } from "./app/components/CreateCaseLab";
  import "./styles/index.css";
  import { restoreRecoveryDemoActor } from "./app/components/RecoveryCenter";

  restoreRecoveryDemoActor();
  const __root = createRoot(document.getElementById("root")!);

  // 隔离迭代入口：仅当 URL 带 ?lab=create 时渲染实验版「新建 Case」（CreateCaseLab），
  // 主流程（<App/> 及真实「新建 Case」按钮走原 CreateCase）完全不受影响。
  // 用静态 import（非 import()）避免代码分包破坏离线单文件构建。
  if (new URLSearchParams(window.location.search).get("lab") === "create") {
    __root.render(
      <div className="min-h-screen bg-white">
        <CreateCaseLab onDone={() => { window.location.href = window.location.pathname; }} />
      </div>,
    );
  } else {
    __root.render(<App />);
  }
  