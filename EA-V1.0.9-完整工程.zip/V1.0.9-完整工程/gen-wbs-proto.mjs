import { build } from "esbuild";
import { writeFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import path from "node:path";

const here = path.dirname(fileURLToPath(import.meta.url));
const output = path.resolve(here, "../Case-WBS-任务工作分解表.html");

const bundled = await build({
  entryPoints: [path.join(here, "src/app/components/data.ts")],
  bundle: true,
  platform: "node",
  format: "cjs",
  write: false,
});
const module = { exports: {} };
new Function("module", "exports", bundled.outputFiles[0].text)(module, module.exports);
const { mockCases } = module.exports;

const esc = (value = "") => String(value)
  .replaceAll("&", "&amp;")
  .replaceAll("<", "&lt;")
  .replaceAll(">", "&gt;")
  .replaceAll('"', "&quot;")
  .replaceAll("'", "&#039;");

const flatTasks = (nodes, parent = null, prefix = "", depth = 0) => {
  const rows = [];
  nodes.forEach((node, index) => {
    const wbs = prefix ? `${prefix}.${index + 1}` : `${index + 1}`;
    rows.push({ node, parent, wbs, depth });
    rows.push(...flatTasks(node.children ?? [], node, wbs, depth + 1));
  });
  return rows;
};

const tag = (text, cls = "") => text ? `<span class="tag ${cls}">${esc(text)}</span>` : "";
const valueOrDash = (value) => value === undefined || value === null || value === "" ? "—" : esc(value);
const multiline = (value) => value ? esc(value).replaceAll("\n", "<br>") : "—";

const detailLine = (label, value) => {
  if (value === undefined || value === null || value === "" || (Array.isArray(value) && !value.length)) return "";
  const display = Array.isArray(value) ? value.join("、") : value;
  return `<div class="detail-line"><b>${esc(label)}</b><span>${multiline(display)}</span></div>`;
};

const taskRow = (entry, caseItem) => {
  const { node, parent, wbs, depth } = entry;
  const kind = node.code ? "执行任务" : "思路 / 怀疑方向";
  const isThought = !node.code;
  const attachments = (node.attachments ?? []).map((item) => item.name);
  const recommended = node.recommendedActions ?? [];
  const statusHistory = (node.statusHistory ?? []).map((item) => `${item.status} · ${item.at}${item.by ? ` · ${item.by}` : ""}`);
  const comments = node.comments ?? [];
  const searchText = [
    caseItem.code, caseItem.name, node.code, node.title, parent?.title, node.owner, node.department,
    node.site, node.status, node.urgency, node.expectation, node.suspicion, node.conclusion,
    node.validity, node.note, node.type, attachments.join(" "), recommended.join(" "),
  ].filter(Boolean).join(" ").toLowerCase();

  const cardDetails = [
    detailLine("主管", node.supervisor),
    detailLine("站点管理员", node.siteOwner),
    detailLine("任务类型", node.type),
    detailLine("分类标签", node.category),
    detailLine("怀疑描述", node.suspicion),
    detailLine("分派附言", node.note),
    detailLine("推荐动作", recommended),
    detailLine("附件", attachments),
    detailLine("语音备注", node.voiceNote ? "已附语音备注" : ""),
    detailLine("点赞 / 评论", (node.likes || comments.length) ? `${node.likes ?? 0} 赞 · ${comments.length} 条评论` : ""),
    detailLine("返工源任务", node.reworkOf),
    detailLine("返工理由", node.reworkReason),
    detailLine("中止理由", node.terminateReason),
    detailLine("拒绝理由", node.rejectReason),
    detailLine("状态历史", statusHistory),
  ].filter(Boolean).join("");

  return `<tr class="wbs-row" data-case="${esc(caseItem.code)}" data-kind="${isThought ? "thought" : "task"}" data-status="${esc(node.status)}" data-search="${esc(searchText)}">
    <td class="sticky-col wbs-cell"><span class="wbs-code">${esc(wbs)}</span></td>
    <td><span class="depth depth-${Math.min(depth, 5)}">${depth + 1}</span></td>
    <td>${tag(kind, isThought ? "thought" : "task")}</td>
    <td class="mono">${valueOrDash(node.code)}</td>
    <td class="title-cell" style="--depth:${depth}">
      <div class="node-title">${esc(node.title)}</div>
      ${parent ? `<div class="parent-line">上级：${esc(parent.title)}</div>` : `<div class="parent-line">Case 根节点</div>`}
    </td>
    <td>
      <div class="strong">${valueOrDash(node.owner)}</div>
      <div class="sub">${valueOrDash(node.department)}${node.site ? ` · ${esc(node.site)}` : ""}</div>
    </td>
    <td>
      <div class="stack">${tag(node.status, `status-${node.status}`)}${tag(node.urgency, `urgency-${node.urgency}`)}</div>
      <div class="progress"><i style="width:${Math.max(0, Math.min(100, Number(node.progress) || 0))}%"></i></div>
      <div class="sub">进度 ${Number(node.progress) || 0}%</div>
    </td>
    <td>
      <div>${node.requestedDueDate ? `期望 ${esc(node.requestedDueDate)}` : "—"}</div>
      <div class="sub">${node.dueDate ? `截止 ${esc(node.dueDate)}` : "未设置截止日期"}${typeof node.dueIn === "number" ? ` · ${node.dueIn} 天` : ""}</div>
    </td>
    <td class="long-cell">${multiline(node.expectation ?? node.suspicion)}</td>
    <td class="long-cell">
      <div>${multiline(node.conclusion)}</div>
      ${node.validity ? `<div class="mt6">${tag(`结论${node.validity}`, `validity-${node.validity}`)}</div>` : ""}
    </td>
    <td class="details-cell">${cardDetails || '<span class="muted">无补充信息</span>'}</td>
  </tr>`;
};

const metaItem = (label, value, wide = false) => value === undefined || value === null || value === "" ? "" : `
  <div class="meta-item${wide ? " wide" : ""}"><span>${esc(label)}</span><strong>${multiline(value)}</strong></div>`;

const caseSection = (caseItem, index) => {
  const rows = flatTasks(caseItem.tasks);
  const tasks = rows.filter((row) => row.node.code);
  const thoughts = rows.filter((row) => !row.node.code);
  const done = tasks.filter((row) => row.node.status === "已完成").length;
  const participants = (caseItem.participants ?? []).map((person) => `${person.name} · ${person.department}`).join("、");
  const meta = [
    metaItem("发起事由", caseItem.reason, true),
    metaItem("背景（What & Why）", caseItem.background, true),
    metaItem("影响", caseItem.impact, true),
    metaItem("层级定义理由", caseItem.levelReason, true),
    metaItem("Owner", caseItem.owner),
    metaItem("参与人", participants),
    metaItem("协作部门", caseItem.departments.join("、")),
    metaItem("产品 / 物料", `${caseItem.product} / ${caseItem.material}`),
    metaItem("规格", [caseItem.density, caseItem.ioType, caseItem.failPackage].filter(Boolean).join(" · ")),
    metaItem("失效阶段 / 平台", [caseItem.failStage, caseItem.failPlatform].filter(Boolean).join(" / ")),
    metaItem("失效模式", caseItem.failMode),
    metaItem("失效率 / PPM", [caseItem.failRatio, caseItem.ppm ? `${caseItem.ppm} PPM` : ""].filter(Boolean).join(" / ")),
    metaItem("客户", caseItem.customer),
    metaItem("PD ID", caseItem.pdId),
    metaItem("创建 / 更新", `${caseItem.createdAt} / ${caseItem.updatedAt}`),
    metaItem("AI 进展", caseItem.aiSummary?.progress, true),
    metaItem("AI 方法", caseItem.aiSummary?.method, true),
    metaItem("AI 结论", caseItem.aiSummary?.conclusion, true),
    metaItem("AI 方案", caseItem.aiSummary?.solution, true),
    metaItem("AI 风险", caseItem.aiSummary?.risk, true),
  ].filter(Boolean).join("");

  const caseSearch = [caseItem.code, caseItem.name, caseItem.owner, caseItem.product, caseItem.material, caseItem.failMode].filter(Boolean).join(" ").toLowerCase();
  return `<details class="case-section" data-case-section="${esc(caseItem.code)}" data-case-search="${esc(caseSearch)}" ${index < 5 ? "open" : ""}>
    <summary>
      <div class="case-index">${String(index + 1).padStart(2, "0")}</div>
      <div class="case-summary-main">
        <div class="case-code">${esc(caseItem.code)}</div>
        <h2>${esc(caseItem.name)}</h2>
        <div class="case-tags">${tag(caseItem.level, `level-${caseItem.level}`)}${tag(caseItem.urgency, `urgency-${caseItem.urgency}`)}${tag(caseItem.status, "case-status")}</div>
      </div>
      <div class="case-kpis">
        <div><strong>${rows.length}</strong><span>全部节点</span></div>
        <div><strong>${thoughts.length}</strong><span>思路方向</span></div>
        <div><strong>${tasks.length}</strong><span>执行任务</span></div>
        <div><strong>${done}</strong><span>已完成</span></div>
      </div>
      <span class="chevron">⌄</span>
    </summary>
    <div class="case-content">
      <div class="case-meta">${meta}</div>
      ${rows.length ? `<div class="table-wrap">
        <table>
          <thead><tr>
            <th class="sticky-col">WBS</th><th>层级</th><th>节点类型</th><th>任务编号</th><th>卡片名称 / 上级节点</th>
            <th>责任信息</th><th>状态 / 紧急度 / 进度</th><th>时间计划</th><th>预期 / 怀疑方向</th><th>结论 / 有效性</th><th>卡片基本信息</th>
          </tr></thead>
          <tbody>${rows.map((row) => taskRow(row, caseItem)).join("")}</tbody>
        </table>
        <div class="filter-empty" hidden>当前筛选条件下没有匹配节点</div>
      </div>` : `<div class="case-empty"><strong>尚未拆解任务</strong><span>该 Case 已保留在 WBS 总表中，当前没有思路、怀疑方向或执行任务卡片。</span></div>`}
    </div>
  </details>`;
};

const allRows = mockCases.flatMap((caseItem) => flatTasks(caseItem.tasks).map((row) => ({ ...row, caseItem })));
const allTasks = allRows.filter((row) => row.node.code);
const allThoughts = allRows.filter((row) => !row.node.code);
const allDone = allTasks.filter((row) => row.node.status === "已完成");
const generatedAt = new Intl.DateTimeFormat("zh-CN", { dateStyle: "long", timeStyle: "short", timeZone: "Asia/Shanghai" }).format(new Date());

const caseOptions = mockCases.map((item) => `<option value="${esc(item.code)}">${esc(item.code)} · ${esc(item.name)}</option>`).join("");
const caseNav = mockCases.map((item, index) => `<button data-jump="${esc(item.code)}"><b>${String(index + 1).padStart(2, "0")}</b><span>${esc(item.code)}</span></button>`).join("");

const html = `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=1440, initial-scale=1" />
  <title>EA Platform · Case WBS 任务工作分解表</title>
  <style>
    :root{--blue:#0052D9;--blue2:#00A4FF;--ink:#0f172a;--muted:#64748b;--line:#e2e8f0;--soft:#f8fafc;--panel:#fff;--shadow:0 10px 30px rgba(15,23,42,.08)}
    *{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;min-width:1180px;background:#f4f7fb;color:var(--ink);font-family:Inter,"PingFang SC","Microsoft YaHei",system-ui,sans-serif;font-size:13px}
    button,input,select{font:inherit}.app-header{position:sticky;top:0;z-index:20;height:64px;background:rgba(255,255,255,.96);border-bottom:1px solid var(--line);backdrop-filter:blur(12px);display:flex;align-items:center;padding:0 28px;gap:18px}
    .brand{font-size:17px;font-weight:720;letter-spacing:.2px}.brand small{display:block;color:#94a3b8;font-size:10px;font-weight:500;letter-spacing:.7px;margin-top:2px}.header-sep{width:1px;height:28px;background:var(--line)}
    .header-title{font-size:14px;color:#475569}.generated{margin-left:auto;color:#94a3b8;font-size:11px}.layout{display:grid;grid-template-columns:230px minmax(0,1fr);min-height:calc(100vh - 64px)}
    .side{position:sticky;top:64px;height:calc(100vh - 64px);background:#fff;border-right:1px solid var(--line);padding:20px 14px;overflow:auto}.side h3{font-size:11px;color:#94a3b8;font-weight:650;letter-spacing:1px;margin:2px 10px 12px;text-transform:uppercase}
    .case-nav{display:flex;flex-direction:column;gap:4px}.case-nav button{border:0;background:transparent;border-radius:8px;padding:8px 10px;display:grid;grid-template-columns:28px 1fr;gap:6px;align-items:center;text-align:left;color:#64748b;cursor:pointer}.case-nav button:hover{background:#eff6ff;color:var(--blue)}.case-nav b{font-size:11px;color:#94a3b8}.case-nav span{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-size:11px}
    main{min-width:0;padding:28px}.hero{display:flex;align-items:flex-end;justify-content:space-between;gap:24px;margin-bottom:20px}.eyebrow{font-size:11px;color:var(--blue);font-weight:700;letter-spacing:1px;text-transform:uppercase}.hero h1{margin:5px 0 6px;font-size:28px;letter-spacing:-.5px}.hero p{margin:0;color:#64748b;line-height:1.7}.hero-actions{display:flex;gap:8px}.btn{height:36px;border:1px solid var(--line);border-radius:8px;background:#fff;color:#475569;padding:0 13px;cursor:pointer}.btn:hover{border-color:#94a3b8}.btn.primary{background:var(--blue);border-color:var(--blue);color:#fff}
    .metrics{display:grid;grid-template-columns:repeat(6,1fr);gap:10px;margin-bottom:16px}.metric{background:#fff;border:1px solid var(--line);border-radius:12px;padding:14px 16px;box-shadow:0 1px 2px rgba(15,23,42,.03)}.metric span{display:block;color:#64748b;font-size:11px}.metric strong{display:block;font-size:24px;margin-top:6px}.metric.accent{background:linear-gradient(135deg,#eff6ff,#fff);border-color:#bfdbfe}.metric.accent strong{color:var(--blue)}
    .toolbar{position:sticky;top:76px;z-index:15;display:grid;grid-template-columns:minmax(220px,1.4fr) minmax(250px,1fr) 150px 160px auto;gap:8px;background:rgba(244,247,251,.95);padding:10px 0;margin-bottom:8px;backdrop-filter:blur(10px)}.control{height:38px;border:1px solid var(--line);border-radius:8px;background:#fff;color:#334155;padding:0 11px;outline:none;min-width:0}.control:focus{border-color:var(--blue);box-shadow:0 0 0 3px rgba(0,82,217,.1)}.toolbar-buttons{display:flex;gap:7px;justify-content:flex-end}
    .case-section{background:#fff;border:1px solid var(--line);border-radius:14px;margin:12px 0;box-shadow:0 2px 8px rgba(15,23,42,.035);overflow:hidden;scroll-margin-top:128px}.case-section[hidden]{display:none}.case-section>summary{list-style:none;display:grid;grid-template-columns:44px minmax(380px,1fr) auto 20px;gap:16px;align-items:center;padding:18px 20px;cursor:pointer}.case-section>summary::-webkit-details-marker{display:none}.case-section[open]>summary{border-bottom:1px solid var(--line);background:linear-gradient(90deg,#f8fbff,#fff)}
    .case-index{width:38px;height:38px;border-radius:10px;background:#eff6ff;color:var(--blue);display:flex;align-items:center;justify-content:center;font-weight:750}.case-code{font:600 11px ui-monospace,SFMono-Regular,Menlo,monospace;color:#94a3b8}.case-summary-main h2{font-size:17px;margin:4px 0 8px}.case-tags,.stack{display:flex;flex-wrap:wrap;gap:5px}.case-kpis{display:flex;gap:22px}.case-kpis div{min-width:52px;text-align:right}.case-kpis strong{display:block;font-size:17px}.case-kpis span{font-size:10px;color:#94a3b8}.chevron{color:#94a3b8;font-size:20px;transition:transform .2s}.case-section[open] .chevron{transform:rotate(180deg)}
    .case-content{padding:16px}.case-meta{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;margin-bottom:14px}.meta-item{background:#f8fafc;border:1px solid #eef2f7;border-radius:8px;padding:9px 10px;min-height:55px}.meta-item.wide{grid-column:span 2}.meta-item span{display:block;color:#94a3b8;font-size:10px;margin-bottom:4px}.meta-item strong{font-size:12px;color:#475569;line-height:1.55;font-weight:560}
    .table-wrap{border:1px solid var(--line);border-radius:10px;overflow:auto;max-width:100%}table{border-collapse:separate;border-spacing:0;min-width:1900px;width:100%;background:#fff}th{position:sticky;top:0;z-index:3;background:#f8fafc;color:#64748b;font-size:10px;letter-spacing:.2px;text-align:left;padding:10px;border-bottom:1px solid var(--line);white-space:nowrap}td{vertical-align:top;padding:10px;border-bottom:1px solid #edf2f7;color:#475569;line-height:1.5;max-width:270px}tbody tr:hover td{background:#fbfdff}.sticky-col{position:sticky;left:0;z-index:2;background:#fff}th.sticky-col{z-index:5;background:#f8fafc}.wbs-code{font:700 12px ui-monospace,SFMono-Regular,Menlo,monospace;color:var(--blue)}.mono{font:500 11px ui-monospace,SFMono-Regular,Menlo,monospace;color:#64748b;white-space:nowrap}.depth{width:24px;height:24px;border-radius:6px;display:inline-flex;align-items:center;justify-content:center;background:#f1f5f9;color:#64748b;font-weight:700}.depth-0{background:#dbeafe;color:#1d4ed8}.depth-1{background:#ede9fe;color:#6d28d9}.depth-2{background:#fef3c7;color:#a16207}.title-cell{padding-left:calc(10px + var(--depth) * 14px);min-width:270px}.node-title{font-weight:650;color:#1e293b}.parent-line,.sub,.muted{color:#94a3b8;font-size:10px;margin-top:3px}.strong{font-weight:650;color:#334155}.long-cell{min-width:250px}.details-cell{min-width:300px}.detail-line{display:grid;grid-template-columns:76px 1fr;gap:6px;margin-bottom:4px}.detail-line b{font-size:10px;color:#94a3b8}.detail-line span{font-size:11px}.progress{width:100px;height:3px;background:#e2e8f0;border-radius:9px;margin-top:8px;overflow:hidden}.progress i{display:block;height:100%;background:var(--blue);border-radius:9px}.mt6{margin-top:6px}
    .tag{display:inline-flex;align-items:center;min-height:20px;padding:2px 7px;border-radius:5px;border:1px solid #e2e8f0;background:#f8fafc;color:#64748b;font-size:10px;font-weight:650;white-space:nowrap}.tag.thought{background:#fffbeb;color:#b45309;border-color:#fde68a}.tag.task{background:#eff6ff;color:#1d4ed8;border-color:#bfdbfe}.level-L1,.urgency-非常紧急{background:#fef2f2;color:#dc2626;border-color:#fecaca}.level-L2,.urgency-紧急{background:#fff7ed;color:#ea580c;border-color:#fed7aa}.level-L3{background:#fffbeb;color:#ca8a04;border-color:#fde68a}.level-L4,.urgency-一般,.status-进行中{background:#eff6ff;color:#2563eb;border-color:#bfdbfe}.level-L5,.urgency-不紧急{background:#f8fafc;color:#64748b}.status-已完成,.validity-有效{background:#ecfdf5;color:#059669;border-color:#a7f3d0}.validity-部分有效{background:#fffbeb;color:#d97706;border-color:#fde68a}.validity-无效{background:#f1f5f9;color:#64748b}.case-status{background:#f8fafc;color:#475569}
    .row-hidden{display:none}.filter-empty{padding:28px;text-align:center;color:#94a3b8;background:#fff}.case-empty{padding:28px;border:1px dashed #cbd5e1;border-radius:10px;background:#f8fafc;text-align:center}.case-empty strong{display:block;color:#475569}.case-empty span{display:block;color:#94a3b8;margin-top:5px}.footer{padding:30px;text-align:center;color:#94a3b8;font-size:11px}
    @media print{body{min-width:0;background:#fff}.app-header,.side,.toolbar,.hero-actions{display:none!important}.layout{display:block}.hero{margin:0 0 12px}main{padding:0}.metrics{grid-template-columns:repeat(6,1fr)}.case-section{break-inside:avoid;box-shadow:none}.case-section:not([open])>.case-content{display:block}.table-wrap{overflow:visible}table{font-size:9px}.footer{display:none}}
  </style>
</head>
<body>
  <header class="app-header">
    <div class="brand">EA Platform<small>ENGINEERING PORTAL</small></div><div class="header-sep"></div>
    <div class="header-title">Case WBS · 任务工作分解表</div><div class="generated">生成时间：${esc(generatedAt)}</div>
  </header>
  <div class="layout">
    <aside class="side"><h3>Case 目录</h3><div class="case-nav">${caseNav}</div></aside>
    <main>
      <section class="hero">
        <div><div class="eyebrow">Work Breakdown Structure</div><h1>Case WBS 任务工作分解表</h1><p>按 Case 汇总思路、怀疑方向与全部执行任务；WBS 编码对应任务树层级。</p></div>
        <div class="hero-actions"><button class="btn" id="collapseAll">全部收起</button><button class="btn" id="expandAll">全部展开</button><button class="btn" id="exportCsv">导出筛选结果</button><button class="btn primary" onclick="window.print()">打印 / PDF</button></div>
      </section>
      <section class="metrics">
        <div class="metric accent"><span>Case 总数</span><strong id="metricCases">${mockCases.length}</strong></div>
        <div class="metric"><span>有任务树 Case</span><strong>${mockCases.filter((item) => item.tasks.length).length}</strong></div>
        <div class="metric"><span>全部节点</span><strong id="metricNodes">${allRows.length}</strong></div>
        <div class="metric"><span>思路 / 怀疑方向</span><strong id="metricThoughts">${allThoughts.length}</strong></div>
        <div class="metric"><span>执行任务</span><strong id="metricTasks">${allTasks.length}</strong></div>
        <div class="metric"><span>已完成任务</span><strong id="metricDone">${allDone.length}</strong></div>
      </section>
      <section class="toolbar">
        <input class="control" id="search" placeholder="搜索 Case、任务、人员、结论、附件…" />
        <select class="control" id="caseFilter"><option value="all">全部 Case</option>${caseOptions}</select>
        <select class="control" id="kindFilter"><option value="all">全部节点类型</option><option value="thought">思路 / 怀疑方向</option><option value="task">执行任务</option></select>
        <select class="control" id="statusFilter"><option value="all">全部状态</option><option>待开始</option><option>待接受</option><option>进行中</option><option>已拒绝</option><option>已完成</option><option>已中止</option></select>
        <div class="toolbar-buttons"><button class="btn" id="resetFilters">重置筛选</button></div>
      </section>
      <div id="cases">${mockCases.map(caseSection).join("")}</div>
      <div class="footer">EA Platform · Case WBS · 数据来源 app/src/app/components/data.ts</div>
    </main>
  </div>
  <script>
    (function(){
      var search=document.getElementById('search');
      var caseFilter=document.getElementById('caseFilter');
      var kindFilter=document.getElementById('kindFilter');
      var statusFilter=document.getElementById('statusFilter');
      var sections=Array.from(document.querySelectorAll('.case-section'));
      function applyFilters(){
        var q=search.value.trim().toLowerCase();
        var selectedCase=caseFilter.value;
        var kind=kindFilter.value;
        var status=statusFilter.value;
        var visibleCases=0,visibleNodes=0,visibleThoughts=0,visibleTasks=0,visibleDone=0;
        sections.forEach(function(section){
          var sectionCase=section.dataset.caseSection;
          var caseMatch=selectedCase==='all'||selectedCase===sectionCase;
          var qMatchesCase=!q||(section.dataset.caseSearch||'').includes(q);
          var rows=Array.from(section.querySelectorAll('.wbs-row'));
          var shown=0;
          rows.forEach(function(row){
            var ok=caseMatch&&(qMatchesCase||(row.dataset.search||'').includes(q))&&(kind==='all'||row.dataset.kind===kind)&&(status==='all'||row.dataset.status===status);
            row.classList.toggle('row-hidden',!ok);
            if(ok){shown++;visibleNodes++;if(row.dataset.kind==='thought')visibleThoughts++;else visibleTasks++;if(row.dataset.status==='已完成'&&row.dataset.kind==='task')visibleDone++;}
          });
          var showSection=caseMatch&&((rows.length===0&&(!q||qMatchesCase))||shown>0);
          section.hidden=!showSection;
          if(showSection){visibleCases++;if(q||kind!=='all'||status!=='all')section.open=true;}
          var empty=section.querySelector('.filter-empty');if(empty)empty.hidden=shown>0;
        });
        document.getElementById('metricCases').textContent=visibleCases;
        document.getElementById('metricNodes').textContent=visibleNodes;
        document.getElementById('metricThoughts').textContent=visibleThoughts;
        document.getElementById('metricTasks').textContent=visibleTasks;
        document.getElementById('metricDone').textContent=visibleDone;
      }
      [search,caseFilter,kindFilter,statusFilter].forEach(function(control){control.addEventListener(control.tagName==='INPUT'?'input':'change',applyFilters);});
      document.getElementById('resetFilters').addEventListener('click',function(){search.value='';caseFilter.value='all';kindFilter.value='all';statusFilter.value='all';applyFilters();});
      document.getElementById('expandAll').addEventListener('click',function(){sections.filter(function(s){return !s.hidden;}).forEach(function(s){s.open=true;});});
      document.getElementById('collapseAll').addEventListener('click',function(){sections.forEach(function(s){s.open=false;});});
      document.querySelectorAll('[data-jump]').forEach(function(button){button.addEventListener('click',function(){var target=document.querySelector('[data-case-section="'+button.dataset.jump+'"]');if(target){target.hidden=false;target.open=true;target.scrollIntoView({behavior:'smooth',block:'start'});}});});
      document.getElementById('exportCsv').addEventListener('click',function(){
        var lines=[['Case','WBS','节点类型','任务编号','卡片名称','上级节点','负责人','部门/站点','状态','紧急度','进度','期望时间','截止时间','预期/怀疑','结论','有效性']];
        document.querySelectorAll('.case-section:not([hidden]) .wbs-row:not(.row-hidden)').forEach(function(row){
          var cells=Array.from(row.cells).map(function(cell){return cell.innerText.replace(/\s+/g,' ').trim();});
          lines.push([row.dataset.case,cells[0],cells[2],cells[3],cells[4],cells[4],cells[5],cells[5],row.dataset.status,cells[6],cells[6],cells[7],cells[7],cells[8],cells[9],cells[9]]);
        });
        var csv='\uFEFF'+lines.map(function(line){return line.map(function(value){return '"'+String(value||'').replace(/"/g,'""')+'"';}).join(',');}).join('\\n');
        var url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));var a=document.createElement('a');a.href=url;a.download='EA-Case-WBS.csv';a.click();URL.revokeObjectURL(url);
      });
      applyFilters();
    })();
  </script>
</body>
</html>`;

await writeFile(output, html, "utf8");
console.log(`Wrote ${output} (${(Buffer.byteLength(html) / 1024).toFixed(1)} KB)`);
