import { readFileSync, writeFileSync, readdirSync } from "node:fs";
import { join } from "node:path";

const distDir = "dist";
const assetsDir = join(distDir, "assets");
let html = readFileSync(join(distDir, "index.html"), "utf8");

const assets = readdirSync(assetsDir);
const jsFile = assets.find((f) => f.endsWith(".js"));
const cssFile = assets.find((f) => f.endsWith(".css"));
const js = readFileSync(join(assetsDir, jsFile), "utf8");
const css = readFileSync(join(assetsDir, cssFile), "utf8");

// Inline the big stylesheet as a <style> block (the small html/body <style>
// already in the template is left untouched).
// Use replacement FUNCTIONS, not strings: the bundle contains "$&" / "$1"
// sequences that String.replace would otherwise interpret as match references.
html = html.replace(
  /<link[^>]*rel="stylesheet"[^>]*>/,
  () => `<style>${css}</style>`
);

// Inline the entry module script. Vite's entry chunk already begins with the
// modulepreload polyfill, so dropping the file contents straight in reproduces
// the original single-file structure.
html = html.replace(
  /<script[^>]*type="module"[^>]*><\/script>/,
  () => `<script type="module">\n${js}\n</script>`
);

writeFileSync("EA系统-离线版.html", html);
console.log("wrote EA系统-离线版.html from", jsFile, "+", cssFile);
